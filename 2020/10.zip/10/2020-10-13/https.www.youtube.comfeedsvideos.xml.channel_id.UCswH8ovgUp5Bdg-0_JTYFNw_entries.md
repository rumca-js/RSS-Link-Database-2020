# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Is Caring For The Environment A Privilege?! | Russell Brand
 - [https://www.youtube.com/watch?v=cUZLCzcBsfo](https://www.youtube.com/watch?v=cUZLCzcBsfo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-10-13 00:00:00+00:00

A clip from my #UnderTheSkin podcast with Kate Nelson aka. Plastic Free Mermaid. You can listen this entire podcast "#154 Why We Must Wake Up To Plastic Free Life" over on Luminary here: http://luminary.link/russell

Kate is an long-time plastics activist and she is on the brink of banning plastics in Australia, but needs your help! Find out more: iquitplastics.com/blog/ban-plastics-australia"

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

