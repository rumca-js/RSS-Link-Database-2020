# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Family shares moment with daughter after dream school acceptance
 - [https://www.cnn.com/videos/us/2020/10/13/acfc-father-daughter-moment-the-goods-vpx.cnn](https://www.cnn.com/videos/us/2020/10/13/acfc-father-daughter-moment-the-goods-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 23:57:29+00:00

Anderson Cooper showcases family moments from viewers, including one father witnessing when his daughter got accepted into her dream school. Watch "Full Circle" every Monday, Tuesday and Friday at 6pm E.T.

## Second giant 'murder hornet' escapes after it was captured by scientists in Washington
 - [https://www.cnn.com/2020/10/13/us/murder-hornet-track-washington-trnd/index.html](https://www.cnn.com/2020/10/13/us/murder-hornet-track-washington-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 23:30:19+00:00

Another "murder" hornet that could have led scientists to its nest has evaded experts once more, following a lost signal.

## Obama to hit the campaign trail for Biden in final stretch
 - [https://www.cnn.com/2020/10/13/politics/obama-biden-campaign/index.html](https://www.cnn.com/2020/10/13/politics/obama-biden-campaign/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 23:27:04+00:00

Former President Barack Obama is expected to hit the campaign trail next week, Democratic officials tell CNN, as he looks to step up his work in support of his one-time partner -- former Vice President Joe Biden -- in the final stretch of the election.

## Utah hiker shares what he was thinking when he faced cougar
 - [https://www.cnn.com/videos/us/2020/10/13/utah-hiker-kyle-burgess-cougar-video-sot-acfc-vpx.cnn](https://www.cnn.com/videos/us/2020/10/13/utah-hiker-kyle-burgess-cougar-video-sot-acfc-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 23:14:31+00:00

Hiker Kyle Burgess tells CNN's Anderson Cooper what was going through his mind when encountered a cougar that stalked him for six minutes on a trail in Utah. Watch "Full Circle" ever Monday, Tuesday and Friday at 6pm E.T.

## 10 people have died in Nigeria's ongoing protests over police brutality, Amnesty International says
 - [https://www.cnn.com/2020/10/13/africa/nigeria-police-sars-victims-intl/index.html](https://www.cnn.com/2020/10/13/africa/nigeria-police-sars-victims-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 22:00:16+00:00

At least 10 people have died in protests over police brutality in Nigeria, Amnesty International said Tuesday.

## CNN's Dana Bash: This moment will impress both Democrats and Republicans
 - [https://www.cnn.com/videos/politics/2020/10/13/amy-coney-barrett-notepad-empty-bash-vpx.cnn](https://www.cnn.com/videos/politics/2020/10/13/amy-coney-barrett-notepad-empty-bash-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 17:58:01+00:00

CNN's Dana Bash discusses a moment from Judge Amy Coney Barrett's Supreme Court confirmation hearing where she raises an empty notepad after being asked if she had taken any notes.

## Lonely Planet ranks ultimate travel destinations in new list
 - [https://www.cnn.com/travel/article/lonely-planet-ultimate-travel-list-2020/index.html](https://www.cnn.com/travel/article/lonely-planet-ultimate-travel-list-2020/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 17:03:21+00:00

Many of us have been forced to rethink travel plans in the wake of Covid-19, but if you're soothing your canceled-vacation-blues by daydreaming about future adventures, Lonely Planet's new "Ultimate Travel List" might be just what you need.

## Cristiano Ronaldo tests positive for coronavirus
 - [https://www.cnn.com/2020/10/13/football/cristiano-ronaldo-coronavirus-spt-intl/index.html](https://www.cnn.com/2020/10/13/football/cristiano-ronaldo-coronavirus-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 14:58:10+00:00

Cristiano Ronaldo has tested positive for coronavirus, the Portuguese Football Federation said in a statement Tuesday.

## Fauci says he's 'not going to walk away' as Trump revives criticism
 - [https://www.cnn.com/collections/trump-2020-intl-101220/](https://www.cnn.com/collections/trump-2020-intl-101220/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 14:40:37+00:00



## Feinstein grills Barrett on Roe v. Wade at confirmation hearing: 'It's distressing not to get a straight answer'
 - [https://www.cnn.com/collections/barrett-hearing-intl-101220/](https://www.cnn.com/collections/barrett-hearing-intl-101220/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 14:38:58+00:00



## Kanye West and other stars join global protests over police brutality in Nigeria
 - [https://www.cnn.com/2020/10/13/africa/global-end-sars-protests-nigeria-intl/index.html](https://www.cnn.com/2020/10/13/africa/global-end-sars-protests-nigeria-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 14:38:40+00:00

US rapper Kanye West has joined a growing list of international celebrities speaking out in support of large protests against police brutality in Nigeria.

## Facebook donates $1.3 million to boost WWII code-breaking site Bletchley Park
 - [https://www.cnn.com/2020/10/13/tech/facebook-bletchley-park-donation-scli-gbr-intl/index.html](https://www.cnn.com/2020/10/13/tech/facebook-bletchley-park-donation-scli-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 14:37:24+00:00

Facebook has made a £1 million ($1.3 million) donation to the museum at Bletchley Park, where British code-breakers decrypted messages sent using Nazi Germany's Enigma cipher and contributed to an Allied victory in World War II, after the site was forced to cut dozens of jobs as a result of the pandemic.

## The 10 Senate seats most likely to flip, 3 weeks from Election Day
 - [https://www.cnn.com/2020/10/13/politics/election-2020-senate-race-rankings-three-weeks/index.html](https://www.cnn.com/2020/10/13/politics/election-2020-senate-race-rankings-three-weeks/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 14:33:23+00:00

It's been a rough couple of weeks for President Donald Trump, and that's squeezing some GOP senators who were already facing competitive reelections.

## Cougar stalks and lunges at Utah hiker
 - [https://www.cnn.com/videos/us/2020/10/13/utah-hiker-cougar-video-orig-sb.cnn](https://www.cnn.com/videos/us/2020/10/13/utah-hiker-cougar-video-orig-sb.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 14:24:31+00:00

Utah hiker Kyle Burgess captured this dramatic video of his dangerous encounter with a cougar.

## Turkey issues detention warrants for 167 over suspected Gulen links, state media reports
 - [https://www.cnn.com/2020/10/13/europe/turkey-detention-warrants-gulen-links-intl/index.html](https://www.cnn.com/2020/10/13/europe/turkey-detention-warrants-gulen-links-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 14:22:35+00:00

Turkish police detained dozens of people on Tuesday in a search for 167 suspects, many of them active duty soldiers, in a move against supporters of a Muslim preacher the government accuses of organizing a failed coup in 2016, state media reported.

## Fauci reacts to Trump ad: This is disappointing
 - [https://www.cnn.com/videos/politics/2020/10/12/dr-anthony-fauci-trump-ad-sot-tapper-lead-vpx.cnn](https://www.cnn.com/videos/politics/2020/10/12/dr-anthony-fauci-trump-ad-sot-tapper-lead-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 14:19:52+00:00

Dr. Anthony Fauci told CNN's Jake Tapper the Trump campaign should remove their ad featuring his comments which he says were used out of context.

## The fried chicken sandwich with a claw
 - [https://www.cnn.com/travel/article/fried-chicken-claw-sandwich-birdbox/index.html](https://www.cnn.com/travel/article/fried-chicken-claw-sandwich-birdbox/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 14:14:07+00:00

The claw! The claw!

## Senator repeatedly presses Amy Coney Barrett on Roe v. Wade case
 - [https://www.cnn.com/videos/politics/2020/10/13/amy-coney-barrett-supreme-court-hearing-roe-v-wade-feinstein-vpx.cnn](https://www.cnn.com/videos/politics/2020/10/13/amy-coney-barrett-supreme-court-hearing-roe-v-wade-feinstein-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 14:13:17+00:00

Sen. Dianne Feinstein (D-CA) repeatedly questions Supreme Court nominee Amy Coney Barrett on whether she believes Roe v. Wade was wrongly decided.

## 'Lies kill': Van Jones calls out Giuliani's false claim to Trump supporters
 - [https://www.cnn.com/videos/politics/2020/10/13/giuliani-no-deaths-coronavirus-misleading-claim-van-jones-vpx.cnn](https://www.cnn.com/videos/politics/2020/10/13/giuliani-no-deaths-coronavirus-misleading-claim-van-jones-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 13:37:05+00:00

CNN's Van Jones reacted to President Trump's personal attorney Rudy Giuliani falsely claiming people don't die of coroanvirus anymore.

## Justin Bieber launches Crocs collection
 - [https://www.cnn.com/style/article/justin-bieber-crocs-intl-scli/index.html](https://www.cnn.com/style/article/justin-bieber-crocs-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 13:32:56+00:00

This year has certainly been unexpected, and what better icing on the cake than Justin Bieber launching his new collection of.... Crocs.

## Why a fancy new iPhone will be a tougher sell than ever
 - [https://www.cnn.com/collections/intl-apple-iphone-1013/](https://www.cnn.com/collections/intl-apple-iphone-1013/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 13:14:07+00:00



## Man who dismissed Covid-19 and then survived it says he is an example for doubters
 - [https://www.cnn.com/2020/10/12/health/texas-coronavirus-skeptic-turned-survivor-guilt/index.html](https://www.cnn.com/2020/10/12/health/texas-coronavirus-skeptic-turned-survivor-guilt/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 12:54:05+00:00

For months, Tony Green was skeptical that the threat of Covid-19 was real. Then he hosted a small family gathering in June where everyone got sick.

## How Biden's lead over Trump in polls differs from Clinton's in 2016
 - [https://www.cnn.com/videos/politics/2020/10/13/enten-2020-election-poll-forecast-2016-comparison-newday-vpx.cnn](https://www.cnn.com/videos/politics/2020/10/13/enten-2020-election-poll-forecast-2016-comparison-newday-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 12:48:09+00:00

CNN's Harry Enten gives an in-depth comparison of what the polls show us about the 2020 presidential race between Joe Biden and President Donald Trump, compared to Trump's 2016 race against Hillary Clinton.

## IMF cuts its global economic forecasts for 2021 and warns of 'long, uneven' recovery
 - [https://www.cnn.com/2020/10/13/economy/imf-economic-outlook-coronavirus/index.html](https://www.cnn.com/2020/10/13/economy/imf-economic-outlook-coronavirus/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 12:30:16+00:00

A strong comeback in 2021 is needed to help the global economy heal from the coronavirus pandemic. But the International Monetary Fund is downgrading its forecasts for next year, and warning of a long, slow recovery that will stoke poverty and damage growth.

## Trump's Supreme Court pick declined to give her views on Roe v. Wade, a landmark 1973 abortion ruling
 - [https://www.cnn.com/politics/live-news/amy-coney-barrett-hearing-10-13-20/index.html](https://www.cnn.com/politics/live-news/amy-coney-barrett-hearing-10-13-20/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 12:29:59+00:00



## How Ghana is reinventing itself as a top tourist destination
 - [https://www.cnn.com/travel/article/ghana-best-things-to-do/index.html](https://www.cnn.com/travel/article/ghana-best-things-to-do/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 11:24:54+00:00

Slotted into the underbelly of Africa's northwestern huddle, Ghana is a country that's steadily reinventing itself.

## Boris Johnson splits from his top scientists on coronavirus
 - [https://www.cnn.com/collections/intl-coronavirus-1013/](https://www.cnn.com/collections/intl-coronavirus-1013/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 11:22:30+00:00



## Teenage 'computer genius' could become the first millennial saint
 - [https://www.cnn.com/2020/10/13/world/teenager-beatified-church-intl-scli/index.html](https://www.cnn.com/2020/10/13/world/teenager-beatified-church-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 11:19:17+00:00

A teenage "computer genius" could be on the path to sainthood after he was beatified by the Catholic Church.

## Analysis: Senate's quiet shift on religious freedom vs. abortion
 - [https://www.cnn.com/2020/10/13/politics/what-matters-october-12/index.html](https://www.cnn.com/2020/10/13/politics/what-matters-october-12/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 10:45:27+00:00

Supreme Court confirmation hearings kicked off Monday and that arguably wasn't the biggest news event of the day.

## How a sports psychologist helped teenager Iga Swiatek win her first tennis grand slam
 - [https://www.cnn.com/2020/10/13/tennis/iga-swiatek-tennis-french-open-psychologist-spt-intl/index.html](https://www.cnn.com/2020/10/13/tennis/iga-swiatek-tennis-french-open-psychologist-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 10:44:46+00:00

Polish teenager Iga Swiatek says support from a sports psychologist was a key factor in helping her to win the French Open final on Saturday.

## Opinion: Democrats are aiming for a bigger win
 - [https://www.cnn.com/2020/10/12/opinions/amy-coney-barrett-supreme-court-confirmation-honig/index.html](https://www.cnn.com/2020/10/12/opinions/amy-coney-barrett-supreme-court-confirmation-honig/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 10:32:49+00:00

Senate Democrats are losing the battle, but they're aiming to win the war.

## Opinion: Why the American desert is turning blue
 - [https://www.cnn.com/2020/10/13/politics/southwest-swing-states-2020/index.html](https://www.cnn.com/2020/10/13/politics/southwest-swing-states-2020/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 10:30:15+00:00

For years, the Southwest shimmered like a mirage to Democrats thirsting for a political breakthrough in the desert.

## Navy begins defusing biggest World War II bomb ever found in Poland
 - [https://www.cnn.com/2020/10/13/europe/polish-navy-defusing-world-war-bomb-scli-intl/index.html](https://www.cnn.com/2020/10/13/europe/polish-navy-defusing-world-war-bomb-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 10:21:17+00:00

Navy divers on Monday began a five-day operation to defuse the largest unexploded World War II bomb ever found in Poland, forcing more than 750 people to evacuate their homes.

## The world risks becoming an 'uninhabitable hell,' UN warns
 - [https://www.cnn.com/2020/10/13/world/un-natural-disasters-climate-intl-hnk/index.html](https://www.cnn.com/2020/10/13/world/un-natural-disasters-climate-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 10:07:56+00:00

There has been a "staggering" rise in natural disasters over the past 20 years and the climate crisis is to blame, the United Nations said Monday.

## No more 'fake crowd noise' as fans return to the MLB for first time since March
 - [https://www.cnn.com/2020/10/13/sport/mlb-fans-return-covid-19-baseball-south-korea-new-zealand-rugby-spt-intl/index.html](https://www.cnn.com/2020/10/13/sport/mlb-fans-return-covid-19-baseball-south-korea-new-zealand-rugby-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 10:01:56+00:00

Instead of fake crowd noise, baseball stars are reacquainting themselves with some old friends -- fans and the sounds they make.

## These European countries are seeing record rises in Covid-19 cases
 - [https://www.cnn.com/videos/world/2020/10/13/europe-coronavirus-covid-19-cases-second-wave-vanier-pkg-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2020/10/13/europe-coronavirus-covid-19-cases-second-wave-vanier-pkg-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 09:59:00+00:00

Europe is now reporting more daily infections than the United States, Brazil, or India - the countries that have been driving the global case count for months - as public apathy grows towards coronavirus guidelines. CNN's Cyril Vanier reports.

## Nadal's French Open record is 'one of the best in sport,' rival says
 - [https://www.cnn.com/2020/10/13/tennis/rafael-nadal-andy-murray-french-open-tennis-spt-intl/index.html](https://www.cnn.com/2020/10/13/tennis/rafael-nadal-andy-murray-french-open-tennis-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 09:43:36+00:00

Andy Murray thinks Rafael Nadal's 13 French Open titles is among the greatest achievements in sporting history and one that will never be topped.

## Black History Month and the sad story of a 6-year-old boy who inspired it
 - [https://www.cnn.com/2020/10/13/opinions/uk-black-history-month-akyaaba-addai-sebo-intl-gbr/index.html](https://www.cnn.com/2020/10/13/opinions/uk-black-history-month-akyaaba-addai-sebo-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 09:28:37+00:00

Black History Month (BHM) is a celebration of our diversity -- all the colors of the rainbow that sparkle out of the black hole of creation. We share common roots in the dark, tropical wombs of our mothers and our strength lies in the variety within our oneness.

## These Republican senators are distancing themselves from Trump
 - [https://www.cnn.com/videos/politics/2020/10/12/gop-senators-distancing-from-trump-election-keilar-nr-sot-vpx.cnn](https://www.cnn.com/videos/politics/2020/10/12/gop-senators-distancing-from-trump-election-keilar-nr-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 09:19:38+00:00

CNN's Brianna Keilar breaks down how some vulnerable Republican senators are attempting to distance themselves from President Donald Trump ahead of the 2020 election.

## See how British police are trying to enforce coronavirus restrictions
 - [https://www.cnn.com/videos/world/2020/10/13/england-coronavirus-covid-19-rules-enforcement-mclean-pkg-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2020/10/13/england-coronavirus-covid-19-rules-enforcement-mclean-pkg-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 09:17:29+00:00

The British government has instituted increased Covid-19 restrictions over the past few weeks, which many Brits appear to be ignoring. Only 89 fines have been issued for mask violations and 38 for breaking travel quarantine in England and Wales, according to the National Police Chiefs' Council. CNN's Scott McLean reports.

## Machu Picchu opens to let one stranded tourist visit
 - [https://www.cnn.com/travel/article/jesse-takayama-machu-picchu-intl-hnk/index.html](https://www.cnn.com/travel/article/jesse-takayama-machu-picchu-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 09:10:18+00:00

Like many travelers around the world, Jesse Takayama found his dream trip thwarted by the spread of Covid-19.

## The future of golf could be shorter than you think
 - [https://www.cnn.com/2020/10/13/golf/short-golf-course-tiger-woods-cmd-spc-spt-intl/index.html](https://www.cnn.com/2020/10/13/golf/short-golf-course-tiger-woods-cmd-spc-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 08:02:52+00:00

There can surely be no greater advert for golf than an 11-year-old boy hitting a hole-in-one on the inaugural tee shot at the opening of a Tiger Woods-designed short course in front of the 15-time major winner himself.

## Dozens killed in floods across Southeast Asia as tropical storm Nangka approaches
 - [https://www.cnn.com/2020/10/13/asia/vietnam-cambodia-nangka-intl-hnk/index.html](https://www.cnn.com/2020/10/13/asia/vietnam-cambodia-nangka-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 07:44:09+00:00

Nearly 40 people have died in Vietnam and Cambodia and scores more were missing, including rescuers, due to prolonged heavy rain and flash flooding as tropical storm Nangka edged towards the Vietnamese coast on Tuesday.

## Pakistan's TikTok ban is not about China
 - [https://www.cnn.com/2020/10/13/tech/tiktok-pakistan-ban-intl-hnk/index.html](https://www.cnn.com/2020/10/13/tech/tiktok-pakistan-ban-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 07:29:32+00:00

Pakistan is taking a cue from its close ally China on internet censorship by banning, of all things, a Chinese social media app.

## Malaysia's Anwar submits documents to king to show support to form new government
 - [https://www.cnn.com/2020/10/13/asia/malaysia-anwar-king-intl-hnk/index.html](https://www.cnn.com/2020/10/13/asia/malaysia-anwar-king-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 07:29:10+00:00

Malaysian opposition leader Anwar Ibrahim on Tuesday met the country's king and said he submitted documents proving his "strong and convincing" parliamentary support to form government and that Prime Minister Muhyiddin Yassin should resign.

## Johnson & Johnson pauses Covid-19 vaccine trial after 'unexplained illness'
 - [https://www.cnn.com/2020/10/12/health/johnson-coronavirus-vaccine-pause-bn/index.html](https://www.cnn.com/2020/10/12/health/johnson-coronavirus-vaccine-pause-bn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 03:15:11+00:00

Drugmaker Johnson & Johnson said Monday it has paused the advanced clinical trial of its experimental coronavirus vaccine because of an unexplained illness in one of the volunteers.

## This country is putting business before the environment and that could be disastrous for its rainforests
 - [https://www.cnn.com/2020/10/12/asia/indonesia-omnibus-law-environment-intl-hnk/index.html](https://www.cnn.com/2020/10/12/asia/indonesia-omnibus-law-environment-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 02:54:33+00:00

Last week, Indonesia's parliament passed a controversial and sweeping jobs law that environmentalists say will have a disastrous impact on the country's forests and rich biodiversity.

## CNN speaks to Trump supporters at Florida rally: What if Trump asked you to put on a mask?
 - [https://www.cnn.com/videos/politics/2020/10/13/trump-rally-supporters-covid-19-sots-tuchman-ac360-vpx.cnn](https://www.cnn.com/videos/politics/2020/10/13/trump-rally-supporters-covid-19-sots-tuchman-ac360-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 01:26:17+00:00

CNN's Gary Tuchman speaks to Trump supporters at the President's rally in Sanford, Florida, about masks and the coronavirus.

## Regretful Trump voters: 'I got it wrong'
 - [https://www.cnn.com/2020/10/12/politics/women-voters-pennslyvania/index.html](https://www.cnn.com/2020/10/12/politics/women-voters-pennslyvania/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-13 00:40:43+00:00

They are all nervous.

