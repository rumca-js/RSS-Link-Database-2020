# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Czy warto kupić nowego iPhone’a? Podsumowanie premiery iPhone’ów 12 - iPhone 12, 12 Pro, 12 mini
 - [https://www.youtube.com/watch?v=qeX2kdYJ7Ro](https://www.youtube.com/watch?v=qeX2kdYJ7Ro)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-10-14 00:00:00+00:00

Link do całej konferencji: https://youtu.be/KR0g-1hnQPA

Moje sociale:
Insta: http://bit.ly/InstaKlawiatur 
Twitter: http://bit.ly/TTKlawitera
FB: http://bit.ly/FBKlawiatur

