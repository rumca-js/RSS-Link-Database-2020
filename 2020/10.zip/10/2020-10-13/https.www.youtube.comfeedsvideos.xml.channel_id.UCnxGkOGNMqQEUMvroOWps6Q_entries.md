# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Joe Rogan Further Investigates Chris Cuomo's Fake Weights
 - [https://www.youtube.com/watch?v=f-vqylbvECs](https://www.youtube.com/watch?v=f-vqylbvECs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-10-14 00:00:00+00:00

#1549 w/Tom Papa:
https://open.spotify.com/episode/4AxcFcBQtquaEdwiveS49O

## Joe Rogan's Thoughts on The Social Dilemma
 - [https://www.youtube.com/watch?v=_WFbJc6HnF0](https://www.youtube.com/watch?v=_WFbJc6HnF0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-10-14 00:00:00+00:00

#1549 w/Tom Papa:
https://open.spotify.com/episode/4AxcFcBQtquaEdwiveS49O

## The Current State of Coronavirus Confusion
 - [https://www.youtube.com/watch?v=l_QuZhQ8EV0](https://www.youtube.com/watch?v=l_QuZhQ8EV0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-10-14 00:00:00+00:00

#1549 w/Tom Papa:
https://open.spotify.com/episode/4AxcFcBQtquaEdwiveS49O

## Roy Jones Jr. On Getting Robbed in the Olympics
 - [https://www.youtube.com/watch?v=CTarX5lWGys](https://www.youtube.com/watch?v=CTarX5lWGys)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-10-13 00:00:00+00:00

#1548 w/Roy Jones Jr.:
https://open.spotify.com/episode/2AVQYJl4gbUq5T02IYvnHt

## Roy Jones Jr. on Facing Mike Tyson
 - [https://www.youtube.com/watch?v=j4rl2CInLz4](https://www.youtube.com/watch?v=j4rl2CInLz4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-10-13 00:00:00+00:00

#1548 w/Roy Jones Jr.:
https://open.spotify.com/episode/2AVQYJl4gbUq5T02IYvnHt

