# Source:Ryan George, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ, language:en-US

## When Sketchy People Write Tell-All Books
 - [https://www.youtube.com/watch?v=1sJ7fMoFTnE](https://www.youtube.com/watch?v=1sJ7fMoFTnE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ
 - date published: 2020-10-13 00:00:00+00:00

Get 68% off NordVPN! Only $3.71/mo, plus get an additional month FREE at https://nordvpn.com/ryangeorge or use coupon code: ryangeorge

Hi there hello please click the subscribe button and turn on notifications so I can feed my cats.
Twitter/Instagram: @TheRyanGeorge

Check out NordVPN on YouTube: https://www.youtube.com/watch?v=yCWNRzoQGis

