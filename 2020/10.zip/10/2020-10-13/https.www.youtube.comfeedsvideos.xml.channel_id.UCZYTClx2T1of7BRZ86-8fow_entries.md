# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## These Horrifying Sea Slugs Smell Like Watermelon Candies
 - [https://www.youtube.com/watch?v=fG3sYClwYBs](https://www.youtube.com/watch?v=fG3sYClwYBs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2020-10-13 00:00:00+00:00

These fun looking sea slugs have a few unique features, not the least of which is the fact that they defend themselves by smelling like watermelon candies.

Hosted by: Michael Aranda

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Bd_Tmprd, Harrison Mills, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Sam Buck, Christopher R Boucher, Eric Jensen, Lehel Kovacs, Adam Brainard, Greg, Ash, Sam Lutfi, Piya Shedden, KatieMarie Magnone, Scott Satovsky Jr, Charles Southerland, charles george, Alex Hackman, Chris Peters, Kevin Bealer
----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://doi.org/10.1098/rstb.1989.0042
https://doi.org/10.1080/10236249209378807
https://doi.org/10.1111/nph.14178
https://doi.org/10.1007/PL00012669
https://doi.org/10.1007/BF01633100
https://www.montereybayaquarium.org/animals/animals-a-to-z/melibe 
https://www.centralcoastbiodiversity.org/hooded-nudibranch-bull-melibe-leonina.html 

Images:
https://vimeo.com/115747242
https://commons.wikimedia.org/wiki/File:Melibe_leonina_feeding.jpg
https://commons.wikimedia.org/wiki/File:Melibe_leonina_at_Monterey_Bay_Aquarium_in_2016.jpg
https://commons.wikimedia.org/wiki/File:Melibe_leonina_from_Santa_Cruz,_California.jpg
https://commons.wikimedia.org/wiki/File:Doriopsilla_BEP_7795.jpg
https://commons.wikimedia.org/wiki/File:Melibe_leonina,_Big_Sur_2.jpg
https://www.istockphoto.com/photo/whole-and-sliced-ginger-gm174822165-22729003
https://www.istockphoto.com/photo/green-forest-gm1173733640-326122715

