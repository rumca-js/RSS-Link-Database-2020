# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## This New A.I. Can Write Anything, Even Code (GPT-3)
 - [https://www.youtube.com/watch?v=Te5rOTcE4J4](https://www.youtube.com/watch?v=Te5rOTcE4J4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2020-10-13 00:00:00+00:00

Sign up to Morning Brew for free today here: http://cen.yt/morningbrewcoldfusion2

--- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. GPT-3 certainly is something.

ColdFusion Merch:
INTERNATIONAL: https://store.coldfusioncollective.com/
AUSTRALIA: https://shop.coldfusioncollective.com/

If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- New Thinking Book written by Dagogo Altraide ---
This book was rated the 9th best technology history book by book authority.
In the book you’ll learn the stories of those who invented the things we use everyday and how it all fits together to form our modern world.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

--- ColdFusion Social Media ---
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusionTV

Sources:

https://arxiv.org/pdf/1712.00676.pdf

https://www.technologyreview.com/2020/08/22/1007539/gpt3-openai-language-generator-artificial-intelligence-ai-opinion/

https://medium.com/towards-artificial-intelligence/crazy-gpt-3-use-cases-232c22142044


https://www.zdnet.com/article/what-is-gpt-3-everything-business-needs-to-know-about-openais-breakthrough-ai-language-program/

https://towardsdatascience.com/will-gpt-3-kill-coding-630e4518c04d

https://www.technologyreview.com/2020/07/20/1005454/openai-machine-learning-language-generator-gpt-3-nlp/


https://slate.com/technology/2020/09/language-ai-gpt-3-free-speech-harassment.html

https://fortune.com/2020/09/29/artificial-intelligence-openai-gpt3-toxic/

Einstein interview: https://twitter.com/maraoz/status/1285466920268029952?s=20


//Soundtrack//

Hiatus - Cloud City

Winter Flags -Winter Flags

Burn Water - Nostalgia Dreams

Sworn - Sorry

Croquet Club - Only You Can Tell

Vesky - Remembrance

Brock Hewitt - Peaceful

Cahb - Secrets

Burn Water - Dissapear

» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide

Why are you still reading?

