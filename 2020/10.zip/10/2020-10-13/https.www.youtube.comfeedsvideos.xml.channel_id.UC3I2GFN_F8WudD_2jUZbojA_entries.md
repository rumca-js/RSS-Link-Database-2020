# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Fenne Lily - Performance and Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=pIUtTCCDOIk](https://www.youtube.com/watch?v=pIUtTCCDOIk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-14 00:00:00+00:00

http://KEXP.ORG presents Fenne Lily sharing an exclusive live performance of songs from her latest album, BREACH, and talking to DJ Abbie live on KEXP. Recorded October 7, 2020.

Songs:
Birthday
I, Nietzsche
Elliott
Berlin
I Used To Hate My Body But Now I Just Hate You

Band:
Fenne Lily - guitar + vox
Joe Sherrin - guitar + keys
Kane Eagle - bass

Videographer: Nick Gaven
Editor: Josh Jarman
Sound Engineer/Mixer: Tim Rowing-Parker 

https://www.fenne-lily.com
http://kexp.org

