# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## Oculus Quest 2 Review: The New VR Standard
 - [https://www.youtube.com/watch?v=K-ycDPkv-LE](https://www.youtube.com/watch?v=K-ycDPkv-LE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-10-13 00:00:00+00:00

Hello! Welcome to my Oculus Quest 2 review. I have been sincerely enjoying my time with the Oculus Quest 2 and I can certainly sayb it a pretty fantastic VR headset. Is it an Index killer? OR Reverb G2 killer though? I don't think so. Is it the new king of VR? Well, it may sell the most, but it's not the best, however the value proposition is one I just cannot ignore. This headset is a review unit from Oculus but i can absolutely guarantee a review that only holds the bias of myself. 

Buy a Quest 2: (affiliate link)
https://amzn.to/3lIftmM (256gb)
https://amzn.to/371J1r6 (64gb)

My links:
2nd Channel and Meetup video:
https://www.youtube.com/watch?v=pZO_KOqt46Q
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill

