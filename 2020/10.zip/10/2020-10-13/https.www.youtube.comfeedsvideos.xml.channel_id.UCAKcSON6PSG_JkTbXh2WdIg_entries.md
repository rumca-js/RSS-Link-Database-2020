# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Listen to Looch: get to know Clarence Avant
 - [https://www.youtube.com/watch?v=twfS1uxBna0](https://www.youtube.com/watch?v=twfS1uxBna0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-10-14 00:00:00+00:00

Mary Lucia talks about the Netflix documentary, "The Black Godfather." It tells the story of Clarence Avant, a highly influential person not only in music and entertainment, but also in Civil Rights, politics, and Black culture at large.

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#clarenceavant #netflix #marylucia

## Seratones - three songs in The Current studio (2019)
 - [https://www.youtube.com/watch?v=dnP8Rdi2QDo](https://www.youtube.com/watch?v=dnP8Rdi2QDo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-10-14 00:00:00+00:00

Seratones' in-studio performance of "Gotta Get To Know Ya" is featured on Live Current Volume 16. Watch Seratones perform that song and two more in this awesome session recorded in our studio in September 2019.

SONGS PERFORMED
0:00 "Gotta Get To Know Ya"
2:19 "Power"
6:02 "Over You"

PERSONNEL
AJ Haynes – vocals, guitar
Travis Stewart – lead guitar
Adam Davis – bass
Tyran Coker – keys
Jesse Gabriel – drums 

CREDITS
Video & Photo: Mary Mathis
Audio: Michael DeMark
Production: Derrick Stevens

FIND MORE:
2019 studio session: https://www.thecurrent.org/feature/2019/09/19/watch-brittany-howard-live-in-concert-at-the-palace-theatre
2019 AJ Haynes' Guitar Collection interview:
https://www.thecurrent.org/feature/2019/09/24/the-current-guitar-collection-aj-haynes-of-seratones-fender-jazzmaster
2020 Seratones set at The Current's 15th anniversary concert:
https://www.thecurrent.org/feature/2020/01/19/watch-seratones-soulful-set-at-first-avenue

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#seratones #ajhaynes

## Low Cut Connie - three songs in The Current studio (2016; 2017)
 - [https://www.youtube.com/watch?v=hKzQ9riP2Ck](https://www.youtube.com/watch?v=hKzQ9riP2Ck)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-10-13 00:00:00+00:00

On Tuesday, Oct. 13, Low Cut Connie will release the much-anticipated double album, "Private Lives." At The Current, we've enjoyed a friendship with Low Cut Connie that has resulted in a number of studio sessions, a Day Party during SXSW and a MicroShow at the Bryant-Lake Bowl, not to mention frontman Adam Weiner's special radio series, The Connie Club. In recognition of the new album coming out, here are three unforgettable in-studio performances by Low Cut Connie.

SONGS PERFORMED
0:00 "Boozophilia" (2016)
4:08 "Dirty Water" (2017)
8:12 "Revolution Rock n Roll" (2017)

PERSONNEL
Adam Weiner – piano and vocals
Will Donnelly – guitar
Dan Finnemore – drums (2016)
James Everhart – guitar
Larry Scotton – bass (2016), drums (2017)
Lucas Rinz – bass (2017)

CREDITS
Video & Photo: Nate Ryan
Audio: Michael DeMark
Production: Anna Weggel; Derrick Stevens

FIND MORE:
2016 studio session: https://www.thecurrent.org/feature/2016/02/26/low-cut-connie-perform-in-the-current-studio
2017 studio session: https://www.thecurrent.org/feature/2017/05/27/low-cut-connie-keep-the-swagger-in-rock-n-roll
2018 Rock the Garden performance:
thecurrent.org/feature/2018/07/02/low-cut-connie-ignite-the-crowd-at-rock-the-garden
2019 The Current Day Party during SXSW:
https://www.thecurrent.org/feature/2019/03/17/watch-low-cut-connie-perform-at-the-current-day-party-in-austin-texas-sxsw
2020 Adam Weiner MicroShow at the Bryant Lake Bowl:
https://www.thecurrent.org/feature/2020/02/03/low-cut-connie-adam-weiner-plays-a-solo-microshow
2020 Adam Weiner of Low Cut Connie Virtual Session:
https://www.thecurrent.org/feature/2020/04/28/adam-weiner-of-low-cut-connie-plays-an-uplifting-live-virtual-session

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#lowcutconnie #adamweiner

