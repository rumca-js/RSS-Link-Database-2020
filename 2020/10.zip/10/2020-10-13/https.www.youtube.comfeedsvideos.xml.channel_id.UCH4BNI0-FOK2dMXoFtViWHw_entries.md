# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## 4 Ways the Universe Might End (All of Them Are Bad)
 - [https://www.youtube.com/watch?v=8uQgiv_Uy7w](https://www.youtube.com/watch?v=8uQgiv_Uy7w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2020-10-13 00:00:00+00:00

PBS Member Stations rely on viewers like you. To support your local station, go to: http://to.pbs.org/DonateOKAY
↓ More info and sources below ↓

Subscribe to my new show Overview!! ►► https://youtu.be/Lt9qYvKFumM  
And remember: The universe will end, but not for a while… probably

I don’t want to alarm you, but the world is going to end. All of this. Gone. And scientists are certain all of this will happen. On the bright side this isn’t going to happen for 4-5 billion years. It makes me wonder: In a universe bigger than we can fathom, across eons of time, could… all of it end? Everything? The whole universe? Yes. And it probably will. Here’s how.

Note: The copy of "The End of Everything (Astrophysically Speaking)" discussed in this episode was provided free of charge by the publisher. As in "the physical copy you see on screen." I also bought the book myself because I love astrophysics! But that version is on my Kindle :)

Special thanks to Dr. Katie Mack ►► https://twitter.com/AstroKatie 
Check out Dr. Mack’s new book “The End of Everything (Astrophysically Speaking)”: https://amzn.to/3nFydVz  (Public library: http://www.worldcat.org/oclc/1124333594 )

Finally, we’re on PATREON! Join the community ►► https://www.patreon.com/itsokaytobesmart
SUBSCRIBE so you don’t miss a video! ►► http://bit.ly/iotbs_sub 

Special thanks to our Brain Trust Patrons:
AlecZero
Amy Sowada
Baerbel Winkler
Benjamin Teinby
Denzel Holmes
Diego Lombeida
Dustin
Eric Meer
George Gladding
Jay Stephens
Karen Haskell
Marcus Tuepker
Oliver and Arden Bradshaw
Peter Ehrnstrom
Robert Young
Salih Arslan
Vincbis
Zenimal

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/

