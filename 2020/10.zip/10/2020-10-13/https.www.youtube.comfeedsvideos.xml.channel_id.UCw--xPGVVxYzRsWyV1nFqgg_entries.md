# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Books I Changed My Mind On
 - [https://www.youtube.com/watch?v=Vt2qpR89d8M](https://www.youtube.com/watch?v=Vt2qpR89d8M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-10-14 00:00:00+00:00

Just me rambling about some books I reviewed now that I have new thoughts on them. 

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

## JK Rowling Industry Backlash💣 To Sleep In A Sea Of Stars MOVIE🎥 Jemisin MacArthur🏆-FANTASY NEWS
 - [https://www.youtube.com/watch?v=wh4P8QzpApw](https://www.youtube.com/watch?v=wh4P8QzpApw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-10-13 00:00:00+00:00

Let’s jump into the fantasy news… Oh boy.

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

NEWS:
--
0:13 - N.K. Jemisin names MacArthur Fellow
https://www.tor.com/2020/10/06/n-k-jemisin-has-been-named-a-macarthur-fellow/ 

0:42 - Son Of The Storm Excerpt
https://io9.gizmodo.com/a-tense-traveler-awaits-a-crucial-meeting-in-this-first-1845220185 

1:19 - To Sleep In A Sea Of Stars Movie
https://deadline.com/2020/10/to-sleep-in-a-sea-of-stars-christopher-paolini-book-optioned-by-made-up-stories-snoot-entertainment-1234593826/ 

2:12 - Response To Rowling
https://www.theguardian.com/books/2020/oct/09/stephen-king-margaret-atwood-roxane-gay-champion-trans-rights-open-letter-jk-rowling

5:28 - Lives of Saints Excerpt
https://ew.com/books/leigh-bardugo-the-lives-of-saints-excerpt/

6:54 - Dresden Sit down
https://www.youtube.com/watch?v=MPu4pfWTQu0

7:02 - The Expanse Season 5
https://tvline.com/2020/10/08/the-expanse-season-5-premiere-date-trailer/ 

8:26 - Resident Alien
https://www.youtube.com/watch?v=26wdrAj8DmE

9:16 - Janeway Returns
https://www.tor.com/2020/10/08/kate-mulgrew-returns-to-role-of-captain-janeway-in-star-trek-prodigy/ 

9:45 - The Stand Trailer
https://www.youtube.com/watch?v=l--4gu4CQBM 

11:12 - Green Lantern Show ordered
https://www.comingsoon.net/tv/news/1151386-greg-berlantis-green-lantern-series-order-hbo-max
--

