# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## The Haunting of Bly Manor - Review
 - [https://www.youtube.com/watch?v=KnU4kJny0Y8](https://www.youtube.com/watch?v=KnU4kJny0Y8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-10-14 00:00:00+00:00

So, it's different than you might think, but certainly worth talking about. Here's my review for the NETFLIX series THE HAUNTING OF BLY MANOR!

#HauntingOfBlyManor #BlyManor

