## Facebook to ban ads discouraging vaccination
 - [https://www.theguardian.com/technology/2020/oct/13/facebook-vaccine-ads-ban](https://www.theguardian.com/technology/2020/oct/13/facebook-vaccine-ads-ban)
 - RSS feed: https://www.theguardian.com
 - date published: 2020-10-13 13:18:42+00:00

Facebook to ban ads discouraging vaccination

