# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## How do I get started? Just get a coca cola can!
 - [https://www.youtube.com/watch?v=bTMZZi4GPBQ](https://www.youtube.com/watch?v=bTMZZi4GPBQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-10-14 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
🔵 Curriculum through excuses: https://www.youtube.com/watch?v=vAVbrm2lV_4
🔵 Thanks Roy Hendrickson: https://www.youtube.com/watch?v=6kxyw-53RyY
🔵 Thanks Mr. Pelinkovic: https://www.youtube.com/watch?v=9dvYG9ifoBM
👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W
🔵 http://www.theaudiobeat.com/visits/thiel_audio_carries_on.htm

## Macbook repair shop leaks Hunter Biden emails - what would YOUR repair shop have done?
 - [https://www.youtube.com/watch?v=nKzu6-92SV8](https://www.youtube.com/watch?v=nKzu6-92SV8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-10-14 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
https://nypost.com/2020/10/14/email-reveals-how-hunter-biden-introduced-ukrainian-biz-man-to-dad/ Post a message on screen http://bit.ly/postamessage Or else I will read it in the normal chat if it is not swamped.

## YELP PROVES MY POINT!
 - [https://www.youtube.com/watch?v=qYzK8Nny_Yo](https://www.youtube.com/watch?v=qYzK8Nny_Yo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-10-13 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
🔵 https://www.kolotv.com/2020/10/13/local-business-owner-concerned-over-yelps-racism-accusation-alerts/
🔵 https://www.youtube.com/watch?v=KXAY_NYbY0E
👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

