# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Brian Rose is Running for Mayor - I PREDICTED THIS!?
 - [https://www.youtube.com/watch?v=F9iwY_A84f4](https://www.youtube.com/watch?v=F9iwY_A84f4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-10-14 00:00:00+00:00

ahahahahahahahahahaha
brian rose thinks he's going to be the next mayor of London. I break down why Mr. London Real -betchadidn'tdonate Rose is just grifting yet again, this time on a new topic. Politics. 

personally I think he's going to fail, but we'll have to see.  He must be just enough of a sociopath to pull it off.

twitter: https://twitter.com/coffeebreak_YT

## Fake Gurus Are Accusing Each Other Of Scamming You
 - [https://www.youtube.com/watch?v=84QQUSQNpIc](https://www.youtube.com/watch?v=84QQUSQNpIc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-10-13 00:00:00+00:00

he's a fake guru, no HE'S A FAKE GURU, NO THAT GUY IS THE REAL FAKE GURU! who's the realest fake guru of them all? Let's find out!

CLICK THE LINK BELOW TO GET MY FAKE GURU SPOTTER COURSE FOR ONLY $69,000,000 (flash sale for first 500 customers)
https://bit.ly/313FLbf 

To learn how to make money online, stop looking online and build a skill or read a book. Oh and stop looking to online marketers for mentorship

#fakeguru #coffeezilla

