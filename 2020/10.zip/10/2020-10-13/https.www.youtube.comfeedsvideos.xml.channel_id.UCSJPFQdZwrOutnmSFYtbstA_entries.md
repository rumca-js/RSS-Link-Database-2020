# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Is The Boys Losing Its Way?
 - [https://www.youtube.com/watch?v=VhAv2lPxkGs](https://www.youtube.com/watch?v=VhAv2lPxkGs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-10-14 00:00:00+00:00

After watching Season 2 of Amazon's The Boys, it's time to ask the question - does it measure up to Season 1, or is this show starting to lose its way?

