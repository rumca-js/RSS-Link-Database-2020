# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## Big Pharma is Broken (Documentary)
 - [https://www.youtube.com/watch?v=OiOAPu-sfOI](https://www.youtube.com/watch?v=OiOAPu-sfOI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2020-10-14 00:00:00+00:00

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join 

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
📸 Follow me on IG:@jaketran // http://bit.ly/jt-ig
👨👦👦 Join the Tran Mafia Family here: https://bit.ly/patreon-jt
💬 Join the community Discord: http://discord.gg/BmK8EnQ

Stuff I use & recommend:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
🏠 The real estate investing course I love & recommend: https://jake.yt/RE
🌐 Most flexible, affordable website hosting: https://jake.yt/bhd
🖥️ Website platform I use & love: https://jake.yt/kd
💽 Editing software I've used for 7+ years: https://jake.yt/ccd
📒 Online bookkeeping software I use& love: https://jake.yt/benchd 
🧾 Best affordable bookkeeping software: https://jake.yt/fbd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd
📚 Get 3 free audiobooks for life: https://amzn.to/2v58PSu
🎥 My video gear, setup, tech, books: https://jake.yt/stored

✉️ Email me: jake@jaketran.io

Subscribe to the backup channel on LBRY, use reward code "jake-cast" for free coin: https://bit.ly/LBRY-jt

📰 Sources & visuals: https://bit.ly/3nGormg

-----------------------
Howard Jacobson runs a pharmacy in Long Island New York. A common drug Howard and other pharmacies sell is called Metformin. The drug itself only costs Jacobson $1.61. If the patient paid with cash out-of-pocket for the drug, Jacobson would sell it to them for $4.00, earning him a respectable $2.39 in profit. The patient used their insurance plan where the patient had to pay $10.84 for the drug instead of $4. Jacobson the pharmacist ends up making only $1.93 in profit. Higher cost for the patient, lower profit for the pharmacy. That whopping $8.91 goes to the insurance company and their middlemen. 

Manufacturers sell their products to retailers. Consumers buy those products from the retailers at a higher price. That way the retailers make some profit to keep for themselves, and they get to buy more products from the manufacturers. The big pharma supply chain is a lot more complicated. 

Big Pharma companies spend billions to develop drugs and to try to get them to pass the FDA. This is the first reason why drugs can get so expensive. They are doing all the work, so it’s a little bit more understandable.

Wholesalers transport the drugs and sell them to the pharmacies. The patient gets prescribed medication from their doctor and goes to the pharmacy to get their meds. Most patients have health insurance to save money on big medical expenses. They use their insurance to pay for prescription meds. For the remainder of the costs, the pharmacy sends a bill to the patient’s insurance company. The patient feels as if they're getting their money’s worth from their insurance. 

Insurance companies are in the business of making money, not giving away free charity. Patients pay their monthly bill for insurance, and when medical bills arise, the patient would pay the entire bill themselves, and the insurance companies would just sit back and collect that monthly bill. The lower the copay they pay, the more you have to fork up to cover their costs and the less profit you make. 

Drug companies pay a commission back to the insurance company. We call these “rebates”. And the people responsible for negotiating how big of a rebate, the insurance companies get falls onto the broker.

Brokers are those middlemen that negotiate with the drug makers to get as much money back for the insurance companies as possible.

It’s easy to blame drug companies, insurance companies and their “Pharmacy Benefit Managers,”. Everyone gets stuck with a higher bill. Mix in the other incentives of drug companies, insurance companies, middlemen and prices for things like big pharma drugs and everything else - skyrocket!
-----------------------

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2020 Jake Tran. All rights reserved.

DISCLAIMER: These videos are for entertainment purposes only. This is not meant to be financial advice. Please always do your due diligence and never stop learning.

AFFILIATE DISCLOSURE: Some of the links in this video description are affiliate links, meaning, at no additional cost to you, I may earn a commission if you click through and make a purchase and/or opt-in. I only promote products that I 100% believe in.

