# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Aloe Blacc - Hold On Tight - live MUZO.FM
 - [https://www.youtube.com/watch?v=hY_kHEisojI](https://www.youtube.com/watch?v=hY_kHEisojI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-10-14 00:00:00+00:00

Aloe Blacc na żywo w MUZO.FM. Utwór Hold On Tight pochodzi z najnowszej płyty artysty - All Love Everything. 


Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Aloe Blacc: http://www.facebook.com/aloeblacc
Instagram Aloe Blacc: http://www.instagram.com/aloeblacc
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm


Aloe Blacc Hold On Tight lyrics

Where's your smile gone 'cause it don't shine no more
There's a light on but you don't open the door
When you're ready
You can tell me what's wrong

I've had trouble and
There's no hiding that
If you're struggling
Let me know where you're at
Life gets heavy
And that road can be long

When the rain comes
And the sky is falling down
In your darkest hour
When there's no one around
It won't be long
Keep your head strong
Hold on tight to me
Hold on tight, hold on

When you feel like crying
Go on let it out
Just remember
The sun is shining behind the clouds
It won't be long
'Til your pain’s gone
So hold on tight to me
Hold on tight, hold on

Sometimes a worry can 
Get the best of us
And I understand
How you could lose your trust
Let me show you that
Here is where you belong

I can be your shoulder to cry on
You will find comfort in my arms
I can be your shelter on solid ground

When the rain comes
And the sky is falling down
In your darkest hour
When there's no one around
It won't be long
Keep your head strong
Hold on tight to me
Hold on tight, hold on

When you feel like crying
Go on let it out
Just remember
The sun is shining behind the clouds
It won't be long
'Til your pain’s gone
So hold on tight to me
Hold on tight, hold on

Hold on tight to me
Hold on tight to me 
Hold on tight to me
Hold on tight to me
Hold on tight to me
Hold on tight to me
Hold on tight 
Hold on tight, hold on

When the rain comes
And the sky is falling down
In your darkest hour
When there's no one around
It won't be long
Keep your head strong
Hold on tight to me
Hold on tight, hold on

When you feel like crying
Go on let it out
Just remember
The sun is shining behind the clouds
It won't be long
'Til your pain's gone
So hold on tight to me
Hold on tight, hold on

Hold on tight to me 
Hold on tight to me 
Hold on tight to me
Hold on tight to me 
Hold on tight to me 
Hold on tight to me 
Hold on tight 
Hold on tight, hold on

## Katie Melua - Interview MUZO.FM
 - [https://www.youtube.com/watch?v=ZL_LeiaVu90](https://www.youtube.com/watch?v=ZL_LeiaVu90)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-10-13 00:00:00+00:00

Katie Melua - wywiad MUZO.FM. Artystka opowiada o najnowszej płycie - Album No. 8, swojej karierze i koncertach, na które nie każdy by się odważył. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Katie Melua: http://www.facebook.com/katiemeluamusic
Instagram Katie Melua: http://www.instagram.com/katiemeluaofficial
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm

