# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Apple iPhone 12 Lineup Reactions!
 - [https://www.youtube.com/watch?v=k1v7_zScivQ](https://www.youtube.com/watch?v=k1v7_zScivQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-10-14 00:00:00+00:00

iPhone 12 Reactions. iPhone 12 Mini thoughts. And iPhone 12 Pro facts. MagSafe is back!
That shirt! http://shop.MKBHD.com
ExpressVPN: http://expressvpn.com/MKBHD

5G Explained: https://youtu.be/_CTUs_2hq6Y
On the iPhone with no Charger: https://youtu.be/8IB7JcKJEeI

0:00 Intro
0:47 HomePod Mini
2:36 iPhone 12
10:10 iPhone 12 Mini
10:56 iPhone 12 Pros
17:02 ExpressVPN

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Drugs by Alltta
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

## Google Pixel 5 Impressions: A New Strategy?
 - [https://www.youtube.com/watch?v=stsJe7pJaKU](https://www.youtube.com/watch?v=stsJe7pJaKU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-10-14 00:00:00+00:00

Pixel 5 unboxing and my really real, actual very first impressions of a phone I've never seen before.

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Jordyn Edmonds http://smarturl.it/jordynedmonds
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by Google for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

## OnePlus 8T Review: The Awkward Middle Child!
 - [https://www.youtube.com/watch?v=VHt0LqGZVSY](https://www.youtube.com/watch?v=VHt0LqGZVSY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-10-14 00:00:00+00:00

OnePlus 8T sits between their high-end and budget and it can't too close to either.
That shirt! http://shop.MKBHD.com
OnePlus skins: http://dbrand.com/8T

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: http://youtube.com/20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by OnePlus for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

