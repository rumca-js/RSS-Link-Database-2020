# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Apple iPhone 12 REACTION!
 - [https://www.youtube.com/watch?v=9wJn6nOEr7Q](https://www.youtube.com/watch?v=9wJn6nOEr7Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-10-14 00:00:00+00:00

Visit https://www.squarespace.com/LTT and use offer code LTT for 10% off

Add Honey for FREE and start saving today at https://joinhoney.com/ltt
Thanks, Honey for sponsoring!

Today Apple announced the iPhone 12, iPhone 12 Mini, iPhone 12 Pro, and iPhone 12 Pro Max. They also announced the HomePod mini. But let's not talk about that. (we talk about it)

Buy iPhones:
On Amazon (PAID LINK): https://geni.us/MwXtH
On Newegg (PAID LINK): https://geni.us/qEMzkDb
On Best Buy (PAID LINK): https://geni.us/Prd8o

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1257446-apple-iphone-12-reaction/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Private Internet Access VPN: https://lmg.gg/pialinus2
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

#AppleEvent #iPhone12

## Which game settings cause the most lag? - Nvidia Reflex Latency Analyzer
 - [https://www.youtube.com/watch?v=aL5YTWRpzoA](https://www.youtube.com/watch?v=aL5YTWRpzoA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-10-14 00:00:00+00:00

Check out Storyblocks Video at https://www.videoblocks.com/LinusTechTips

Nvidia’s G-SYNC module hasn’t had a lot of love lately, but that all changes with new Reflex-enabled displays like the ASUS ROG SWIFT PG259QNR, which can tell you just how slow your game really is.

Discuss on the forum: https://linustechtips.com/main/topic/1257734-stop-guessing-which-game-settings-to-use/

Buy ASUS ROG SWIFT PG259QN Non-Reflex
On B&H (PAID LINK): https://geni.us/wLBgQJS

Buy Razer Deathadder Pro
On Amazon (PAID LINK): https://geni.us/5B5mTG
On Newegg (PAID LINK): https://geni.us/6YykPc

Buy ASUS ROG Chakram
On Amazon (PAID LINK): https://geni.us/dzmJNA
On Newegg (PAID LINK): https://geni.us/fAKAtbT
On B&H (PAID LINK): https://geni.us/oXB3

Purchases made through some store links may provide some compensation to Linus Media Group.

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Private Internet Access VPN: https://lmg.gg/pialinus2
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

## Does Amazon Prime Day Suck?
 - [https://www.youtube.com/watch?v=D-jmpOft9hM](https://www.youtube.com/watch?v=D-jmpOft9hM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-10-13 00:00:00+00:00

Thanks to Honey for sponsoring our Amazon Prime Day coverage! Try it now at https://www.joinhoney.com/primeday

Honey automatically applies the best coupon codes to save you money at different online checkouts.

Prime Day Spreadsheet: https://docs.google.com/spreadsheets/d/1KcTYFsWgO886nyoRQieDMhQZVZzuljUAgnqkmoXwRds/edit#gid=0

Shop Amazon Prime Day 2020 Deals (PAID LINK): https://geni.us/SAaNjV

Buy Intel Core i3-10100
On Amazon (PAID LINK): https://geni.us/YMaK
On Newegg (PAID LINK): https://geni.us/4J3r1AU
On Best Buy (PAID LINK): https://geni.us/LBPYz

Buy ASROCK B460 PRO4
On Amazon (PAID LINK): https://geni.us/ogljS
On Newegg (PAID LINK): https://geni.us/9aPz

Buy Crucial 8GB DDR4 2666 RAM
On Amazon (PAID LINK): https://geni.us/gjBad7d
On Newegg (PAID LINK): https://geni.us/tYtJMZF

Buy ASUS GeForce GTX 1070 DUAL
On Amazon (PAID LINK): https://geni.us/OMBRv
On Newegg (PAID LINK): https://geni.us/GMbbB2

Buy SanDisk SSD PLUS 1TB
On Amazon (PAID LINK): https://geni.us/l4KTAI
On Newegg (PAID LINK): https://geni.us/QNJo
On Best Buy (PAID LINK): https://geni.us/KVmxy

Buy Phanteks Eclipse P400A Case
On Amazon (PAID LINK): https://geni.us/YX7O0
On Newegg (PAID LINK): https://geni.us/qWBgc

Buy EVGA 450 BR PSU
On Amazon (PAID LINK): https://geni.us/DiAJQ
On Newegg (PAID LINK): https://geni.us/wBu6KPK
On Best Buy (PAID LINK): https://geni.us/yhyl

Buy Logitech G502 SE Hero
On Amazon (PAID LINK): https://geni.us/8BQBwj
On Newegg (PAID LINK): https://geni.us/OIUq
On Best Buy (PAID LINK): https://geni.us/7gb0Ie

Buy Redragon K552 Mechanical Keyboard
On Amazon (PAID LINK): https://geni.us/FGbOHq
On Newegg (PAID LINK): https://geni.us/XoxM9
On Best Buy (PAID LINK): https://geni.us/ZR71cl

Buy HyperX CloudX Stinger Core
On Amazon (PAID LINK): https://geni.us/I3i0I
On Newegg (PAID LINK): https://geni.us/WCy1
On Best Buy (PAID LINK): https://geni.us/ou5wnNC

Buy Acer SB220Q Monitor
On Amazon (PAID LINK): https://geni.us/mK4DfZL
On Newegg (PAID LINK): https://geni.us/T2bs7Jn

Purchases made through some store links may provide some compensation to Linus Media Group.

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Private Internet Access VPN: https://lmg.gg/pialinus2
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

