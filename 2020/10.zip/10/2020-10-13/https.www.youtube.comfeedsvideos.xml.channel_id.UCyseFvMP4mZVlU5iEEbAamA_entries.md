# Source:Salvatore Ganacci, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyseFvMP4mZVlU5iEEbAamA, language:en-US

## Grakour
 - [https://www.youtube.com/watch?v=cxDBCvPnv40](https://www.youtube.com/watch?v=cxDBCvPnv40)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyseFvMP4mZVlU5iEEbAamA
 - date published: 2020-10-13 18:10:56+00:00

Follow Salvatore
https://www.instagram.com/salvatoreganacci

Directed by Vedran Rupic, Produced by Business Club Royale

Credits
Director: Vedran Rupic
Producer: Christian Kuosmanen & Sia Masoodian
Creative producer: Gustav Sundström
DOP: Lionel Cabrera

