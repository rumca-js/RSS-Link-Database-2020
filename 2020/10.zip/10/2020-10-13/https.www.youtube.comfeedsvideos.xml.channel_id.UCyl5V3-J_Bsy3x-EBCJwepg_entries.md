# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Greg Koukl Talks Owning Atheist Celebrities/Converting Lady Gaga/20th Century Horrors
 - [https://www.youtube.com/watch?v=ULmxHfZIJHI](https://www.youtube.com/watch?v=ULmxHfZIJHI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-10-13 00:00:00+00:00

Today on The Babylon Bee Podcast, Kyle and Ethan welcome back Christian apologist Greg Koukl of Stand To Reason. He is the author of Tactics and The Story of Reality. They analyze celebrity quotes about God and religion, discuss the horrors of the 20th century world wars, and reveal how Greg would convert Lady Gaga in 30 seconds using his tactics. They also get into the concept of “wokeness” and how awful a lot of modern worship songs really are.

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Gain Access to the Exclusive Content and Writing Forum: https://babylonbee.com/plans

The Official Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

