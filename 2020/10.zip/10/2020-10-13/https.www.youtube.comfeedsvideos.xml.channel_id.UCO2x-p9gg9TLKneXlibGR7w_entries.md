# Source:Snazzy Labs, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w, language:en-US

## iPhone 12 Pro Is Confusing...
 - [https://www.youtube.com/watch?v=Fs_sJiOEpTU](https://www.youtube.com/watch?v=Fs_sJiOEpTU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w
 - date published: 2020-10-14 00:00:00+00:00

Snazzy Labs discusses the new iPhone 12 models. Things are mostly good. But there's some weird stuff.
Sign up for Setapp today! https://setapp.com/?utm_source=snazzylabs&utm_campaign=bigsur&utm_medium=sponsorship

Subscribe to my friends on YouTube who are always great sports when I tease them a bit and make fantastic content (much better than mine!): @ReneRitchie and @TLD 

Purchase iPhone 11 on Amazon - https://amzn.to/3nQO8jW
Purchase iPhone 11 Pro on Amazon - https://amzn.to/33Z0kHI
Subscribe to my podcast Flashback! - http://relay.fm/flashback
Follow me on Twitter - http://twitter.com/snazzyq
Follow me on Instagram - http://instagram.com/snazzyq

Apple announced the new iPhone 12 models on October 13, 2020 in a livestreamed Apple Event keynote. The new HomePod mini was announced along with the iPhone 12, iPhone 12 mini, iPhone 12 Pro, and iPhone 12 Pro Max. There's a lot to cover—from 5G mmWave to the cameras, to the new design, to the new MagSafe charging and accessories (cases, magnetic wallets, car mounts, etc), and a whole lot more! Let's get into it in this iPhone 12 First Look.

