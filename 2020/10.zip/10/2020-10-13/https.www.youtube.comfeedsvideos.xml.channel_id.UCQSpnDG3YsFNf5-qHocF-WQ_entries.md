# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## Why I'm NOT Getting the New iPhone 12
 - [https://www.youtube.com/watch?v=uXLtMZrvRkM](https://www.youtube.com/watch?v=uXLtMZrvRkM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2020-10-14 00:00:00+00:00

Do you agree?
⇒ Become a channel member for exclusive features! Check it out here: https://www.youtube.com/ThioJoe/join

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV

My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

#Apple #iPhone #iPhone12 #Tech #ThioJoe

## The Best Tech Deals: Amazon Prime Day 2020 (NEVERMIND DEALS ARE OVER YA BLEW IT)
 - [https://www.youtube.com/watch?v=z7W031CENic](https://www.youtube.com/watch?v=z7W031CENic)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2020-10-13 00:00:00+00:00

🡇 Prime Trials: 🡇
30 Day Free Trial: https://amzn.to/3do1aR7
6 Month Student Free Trial: https://amzn.to/377I68V

🡇 Amazon Devices: 🡇
Echo Dot 3rd Gen: https://amzn.to/3iYB4W2
Echo Auto: https://amzn.to/3dmozCJ
Echo Flex: https://amzn.to/2GSoieI
Ring Doorbell 3: https://amzn.to/2FtZgSG
Audible Membership: https://www.audible.com/ep/lto
Kindle Unlimited: https://amazon.com/kindle-dbs/hz/subscribe/ku?_encoding=UTF8&sa-no-redirect=1&shoppingPortalEnabled=true

🡇 More Deals 🡇
Blink Mini Camera: https://amzn.to/3lUvrdF
Samsung Galaxy S20 5G: https://amzn.to/2GZ1lGv
Google Pixel 4: https://amzn.to/2GSovP2
Logitech G502 SE: https://amzn.to/2SSV1Tz
Razer Basalisk Wireless: https://amzn.to/3iVAp7U
Corsair K95: https://amzn.to/3jVrvbZ
Apple Airpods: https://amzn.to/3lEm95h
Apple Airpods Pro: https://amzn.to/2SNq3wl
23andMe Genetic Test: https://amzn.to/3iYCkse
iRobot Roomba i6+: https://amzn.to/34XoWQ8
Samsung 860 Pro 1TB SSD: https://amzn.to/2GYujXd

(NOTE: These are Amazon affiliate links so I may get a commission if you buy them)

