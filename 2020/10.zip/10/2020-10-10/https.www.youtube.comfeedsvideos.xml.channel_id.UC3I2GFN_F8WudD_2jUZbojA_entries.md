# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Courtney Marie Andrews - Break The Spell (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=dlPLgcLvTgI](https://www.youtube.com/watch?v=dlPLgcLvTgI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-11 00:00:00+00:00

http://KEXP.ORG presents Courtney Marie Andrews performing "Break The Spell" exclusively for KEXP. Recorded at the Almanack Arts Colony in Nantucket, MA.

Performed by Courtney Marie Andrews, Liz Cooper and Molly Sarle
Recorded by Rob Ackroyd and Joe Valle
Filmed by AAC Technical Director Chris Holmes in The Barn at Almanack

http://courtneymarieandrews.com
https://www.almanackartscolony.org
http://kexp.org

## Courtney Marie Andrews - If I Told (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=NDB7J7KUnds](https://www.youtube.com/watch?v=NDB7J7KUnds)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-11 00:00:00+00:00

http://KEXP.ORG presents Courtney Marie Andrews performing "If I Told" exclusively for KEXP. Recorded at the Almanack Arts Colony in Nantucket, MA.

Performed by Courtney Marie Andrews, Liz Cooper and Molly Sarle
Recorded by Rob Ackroyd and Joe Valle
Filmed by AAC Technical Director Chris Holmes in The Barn at Almanack

http://courtneymarieandrews.com
https://www.almanackartscolony.org
http://kexp.org

## Courtney Marie Andrews - Interview and Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=tBK8g7bv9j4](https://www.youtube.com/watch?v=tBK8g7bv9j4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-11 00:00:00+00:00

http://KEXP.ORG presents Courtney Marie Andrews sharing songs recorded exclusively for KEXP and talking to Greg Vandy, host of The Roadhouse on KEXP. Recorded on October 6, 2020.

Recorded by Rob Ackroyd and Joe Valle at the Almanack Arts Colony in Nantucket
Filmed by AAC Technical Director Chris Holmes in The Barn at Almanack
Performed by Courtney Marie Andrews, Liz Cooper and Molly Sarle, with Liam Benzvi on "One Of These Days"

http://courtneymarieandrews.com
https://www.almanackartscolony.org
http://kexp.org

## Courtney Marie Andrews - It Must Be Someone Else's Fault (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=K3PZtH72_Us](https://www.youtube.com/watch?v=K3PZtH72_Us)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-11 00:00:00+00:00

http://KEXP.ORG presents Courtney Marie Andrews performing "It Must Be Someone Else's Fault" exclusively for KEXP. Recorded at the Almanack Arts Colony in Nantucket, MA.

Performed by Courtney Marie Andrews, Liz Cooper and Molly Sarle
Recorded by Rob Ackroyd and Joe Valle
Filmed by AAC Technical Director Chris Holmes in The Barn at Almanack

http://courtneymarieandrews.com
https://www.almanackartscolony.org
http://kexp.org

## Courtney Marie Andrews - One Of These Days (Live on KEXP)
 - [https://www.youtube.com/watch?v=1aXakslBJ4g](https://www.youtube.com/watch?v=1aXakslBJ4g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-11 00:00:00+00:00

http://KEXP.ORG presents Courtney Marie Andrews covering "One Of These Days" exclusively for KEXP. Recorded at the Almanack Arts Colony in Nantucket, MA.

Performed by Courtney Marie Andrews, Liz Cooper, Molly Sarle and Liam Benzvi
Recorded by Rob Ackroyd and Joe Valle
Filmed by AAC Technical Director Chris Holmes in The Barn at Almanack

http://courtneymarieandrews.com
https://www.almanackartscolony.org
http://kexp.org

## Courtney Marie Andrews - Ships In The Night (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=B8q_1hMMNbg](https://www.youtube.com/watch?v=B8q_1hMMNbg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-11 00:00:00+00:00

http://KEXP.ORG presents Courtney Marie Andrews performing "Ships In The Night" exclusively for KEXP. Recorded at the Almanack Arts Colony in Nantucket, MA.

Performed by Courtney Marie Andrews, Liz Cooper and Molly Sarle
Recorded by Rob Ackroyd and Joe Valle
Filmed by AAC Technical Director Chris Holmes in The Barn at Almanack

http://courtneymarieandrews.com
https://www.almanackartscolony.org
http://kexp.org

## IDLES - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=vKuVLVr1WyA](https://www.youtube.com/watch?v=vKuVLVr1WyA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-11 00:00:00+00:00

http://KEXP.ORG presents IDLES sharing songs recorded exclusively for KEXP from Abbey Road Studios. 

Songs:
Model Village
Mr. Motivator
War
Grounds

Filmed and edited by Ground Work:
Director - Will Dohrn
Executive Producer - Aaron Z. Willson
Producer - Callum Harrison
Editor - Will Dohrn
Production Manager - Lana Salfiti
Director of Photography - Spike Morris
Camera Op - Austin Phillips
Camera Op - Oscar Oldershaw
Camera Assistant - Nacho Munoz Deleon
Gaffer - Helio Riberio

https://shopus.idlesband.com
https://ground-work.co
http://kexp.org

