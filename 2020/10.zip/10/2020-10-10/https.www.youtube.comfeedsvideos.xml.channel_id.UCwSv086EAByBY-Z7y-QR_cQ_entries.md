# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Nowe zalecenia! Zakładaj maseczkę po każdym kęsie podczas jedzenia!
 - [https://www.youtube.com/watch?v=PwMrHmUY8ZY](https://www.youtube.com/watch?v=PwMrHmUY8ZY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2020-10-11 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Mroczne Podcasty: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
👀 Tatusiek: http://bit.ly/3aSCheE
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
🔒 Dołącz do Spółdzielni
https://discord.gg/RSEUaR3
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/2ETKSyN
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
---------------------------------------------------------------
✅źródła:
https://bit.ly/3lqMljI
-------------------------------------------------------------
💡 Tagi: #maseczki #covid-19
--------------------------------------------------------------

## Mimo zakazu Łukasz Szumowski i Przemysław Czarnek odwiedzili bliskich w szpitalu! Analiza sytuacji
 - [https://www.youtube.com/watch?v=HJKaQOGkF2g](https://www.youtube.com/watch?v=HJKaQOGkF2g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2020-10-10 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Mroczne Podcasty: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
👀 Tatusiek: http://bit.ly/3aSCheE
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
🔒 Dołącz do Spółdzielni
https://discord.gg/RSEUaR3
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/2ETKSyN
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
---------------------------------------------------------------
🖼Grafika - wykorzystano elementy ze stron: 
gov.pl - http://bit.ly/2lVWjQr
wikipedia.org / Adrian Grycuk - https://bit.ly/36U0gKT
---------------------------------------------------------------
✅źródła:
https://bit.ly/30OfrSf
https://bit.ly/36THnbk
https://bit.ly/3iO51rU
https://bit.ly/34JjCjl
https://bit.ly/30SvzSx
https://bit.ly/33MOekT
-------------------------------------------------------------
💡 Tagi: #Szumowski #Czarnek
--------------------------------------------------------------

