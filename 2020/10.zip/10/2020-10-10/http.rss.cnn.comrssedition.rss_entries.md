# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Shaquille O'Neal: 'I voted for the first time, and it feels good'
 - [https://www.cnn.com/2020/10/10/us/shaquille-oneal-vote-first-time-trnd/index.html](https://www.cnn.com/2020/10/10/us/shaquille-oneal-vote-first-time-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 22:58:24+00:00

Shaquille O'Neal says he may get "roasted" for admitting it, but the towering former NBA star had something to confess this week.

## Fact check: Five false claims Trump made in his speech
 - [https://www.cnn.com/2020/10/10/politics/fact-check-trump-first-speech-coronavirus-diagnosis/index.html](https://www.cnn.com/2020/10/10/politics/fact-check-trump-first-speech-coronavirus-diagnosis/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 22:24:18+00:00

In President Donald Trump's first public event since his coronavirus diagnosis, he continued to mislead the public about the virus, his accomplishments and former Vice President Joe Biden.

## Colin Kaepernick calls for abolishing police and prisons
 - [https://www.cnn.com/2020/10/10/us/kaepernick-essays-call-for-abolishing-police-trnd/index.html](https://www.cnn.com/2020/10/10/us/kaepernick-essays-call-for-abolishing-police-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 21:34:52+00:00

Colin Kaepernick is calling for abolishing the police and prison institutions as part of a new series of essays.

## Trump holds public event despite unclear Covid-19 status
 - [https://www.cnn.com/videos/politics/2020/10/10/white-house-first-event-trump-coronavirus-dr-faust-vpx.cnn](https://www.cnn.com/videos/politics/2020/10/10/white-house-first-event-trump-coronavirus-dr-faust-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 20:38:07+00:00

President Trump, in his first public event since he was diagnosed with coronavirus, gave a brief, campaign-style speech from the balcony of the White House.

## John Oliver is being honored with his name on a sewage plant after 'fight' with a Connecticut town
 - [https://www.cnn.com/2020/10/10/us/john-oliver-danbury-sewage-plant-trnd/index.html](https://www.cnn.com/2020/10/10/us/john-oliver-danbury-sewage-plant-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 19:54:14+00:00

It's official, a sewage plant in Danbury, Connecticut will be named after John Oliver after the comedian got into a tiff with the town's mayor.

## Texas teen has the world's longest legs
 - [https://www.cnn.com/2020/10/10/us/texas-teenager-guinness-record-long-legs-trnd/index.html](https://www.cnn.com/2020/10/10/us/texas-teenager-guinness-record-long-legs-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 19:35:59+00:00

Maci Currin isn't all legs, but they do make up 60 percent of her total height.

## Unseeded teenager Iga Swiatek wins the French Open
 - [https://www.cnn.com/2020/10/10/tennis/kenin-swiatek-french-open-tennis-intl-spt/index.html](https://www.cnn.com/2020/10/10/tennis/kenin-swiatek-french-open-tennis-intl-spt/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 18:39:37+00:00

Iga Swiatek stormed past Sofia Kenin 6-4 6-1 to win the French Open and become Poland's first ever grand slam singles champion.

## Trump's $1.8 trillion stimulus proposal faces opposition from Pelosi and Senate GOP
 - [https://www.cnn.com/2020/10/10/politics/stimulus-talks-pelosi-senate-gop-trump/index.html](https://www.cnn.com/2020/10/10/politics/stimulus-talks-pelosi-senate-gop-trump/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 18:37:45+00:00

House Speaker Nancy Pelosi and Senate Republicans on Saturday balked at President Donald Trump's roughly $1.8 trillion stimulus proposal, making it all but certain Congress won't pass an economic relief package before Election Day.

## Chained and locked up, why some Nigerians turn to religion first to treat the mentally ill
 - [https://www.cnn.com/2020/10/10/africa/mental-health-religious-treatment-nigeria/index.html](https://www.cnn.com/2020/10/10/africa/mental-health-religious-treatment-nigeria/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 16:09:50+00:00

When Alvan Godwin suffered a psychotic episode linked to schizophrenia in November 2018, his parents took him to church for prayers. His mother was of the opinion that his illness was a 'spiritual attack' linked to evil spirits.

## North Korea unveils massive new ballistic missile in military parade
 - [https://www.cnn.com/2020/10/10/asia/north-korea-military-parade-new-missiles-intl-hnk/index.html](https://www.cnn.com/2020/10/10/asia/north-korea-military-parade-new-missiles-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 14:28:00+00:00

North Korea unveiled what analysts believe to be one of the world's largest ballistic missiles at a military parade celebrating the 75th anniversary of the Workers' Party broadcast on state-run television on Saturday.

## Is it safe to travel for the holidays this year?
 - [https://www.cnn.com/travel/article/holiday-travel-safety-2020-pandemic/index.html](https://www.cnn.com/travel/article/holiday-travel-safety-2020-pandemic/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 13:06:19+00:00

The end of the year is sneaking up, and people are weighing travel plans to join friends and family for the holidays -- all against the backdrop of a deadly pandemic.

## Biden enters final weeks in commanding position as Trump wastes precious days
 - [https://www.cnn.com/2020/10/10/politics/2020-election-biden-trump/index.html](https://www.cnn.com/2020/10/10/politics/2020-election-biden-trump/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 12:41:07+00:00

Joe Biden is in a commanding position as the presidential race enters its final stretch, leading President Donald Trump in polling and fundraising and on offense to expand his pathways to victory while Trump struggles to defend must-win states.

## Frozen out by Arsenal, Mesut Ozil is proving an expensive problem for the club
 - [https://www.cnn.com/2020/10/10/football/ozil-arsenal-contract-legacy-spt-intl/index.html](https://www.cnn.com/2020/10/10/football/ozil-arsenal-contract-legacy-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 11:38:42+00:00

It all started so well for Mesut Ozil and Arsenal.

## Several regions sound alarm as US reports most Covid-19 daily cases in nearly 2 months
 - [https://www.cnn.com/2020/10/10/health/us-coronavirus-saturday/index.html](https://www.cnn.com/2020/10/10/health/us-coronavirus-saturday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 11:30:10+00:00

Just as the US reported the highest number of daily Covid-19 infections in nearly two months, several experts offered grim outlooks if Americans don't take the right precautions.

## Pompeo will release Clinton emails following Trump criticism
 - [https://www.cnn.com/2020/10/09/politics/pompeo-clinton-emails/index.html](https://www.cnn.com/2020/10/09/politics/pompeo-clinton-emails/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 11:10:00+00:00

Secretary of State Mike Pompeo on Friday announced he would release more of former Secretary of State Hillary Clinton's emails -- an openly political move on behalf of President Donald Trump ahead of the November election and a year after a State Department investigation concluded there was no "persuasive evidence" of widespread mishandling of classified information by Clinton or her aides.

## Marcus Rashford awarded MBE in Queen's Birthday honors list
 - [https://www.cnn.com/2020/10/10/football/marcus-rashford-manchester-united-gbr-spt-intl-scli/index.html](https://www.cnn.com/2020/10/10/football/marcus-rashford-manchester-united-gbr-spt-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 10:59:55+00:00

Star footballer turned political activist Marcus Rashford has been honored by Queen Elizabeth II in recognition of his campaign to feed vulnerable children during the coronavirus crisis.

## Scotland's whisky islands are dealing with an almighty Covid hangover
 - [https://www.cnn.com/travel/article/scotland-whisky-islands-covid/index.html](https://www.cnn.com/travel/article/scotland-whisky-islands-covid/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 08:50:49+00:00

Off the southwest coast of Scotland lies a collection of small islands that make some of the most distinctive whiskies in the world.

## Miami Heat still alive in NBA Finals after thrilling 111-108 win over LA Lakers in Game 5
 - [https://www.cnn.com/2020/10/10/sport/la-lakers-miami-heat-nba-finals-game-5-spt-intl/index.html](https://www.cnn.com/2020/10/10/sport/la-lakers-miami-heat-nba-finals-game-5-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 06:46:48+00:00

The Los Angels Lakers were a little more than 20 seconds away from winning their 17th NBA title.

## Barbie confronts racism in viral video and shows how to be a White ally
 - [https://www.cnn.com/2020/10/10/us/barbie-vlog-teaches-allyship-trnd/index.html](https://www.cnn.com/2020/10/10/us/barbie-vlog-teaches-allyship-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 06:04:57+00:00

Barbie sat down for a real talk about racism with her good friend Nikki in the Dreamhouse -- and nothing was off limits.

## Federal judge blocks Texas governor's directive limiting ballot drop boxes to one per county
 - [https://www.cnn.com/2020/10/09/politics/texas-ballot-drop-boxes/index.html](https://www.cnn.com/2020/10/09/politics/texas-ballot-drop-boxes/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 04:12:18+00:00

A federal judge late Friday blocked Texas Gov. Greg Abbott's directive that limited ballot drop boxes to one per county.

## The Nobels honored 4 women this year. But the awards still lack diversity
 - [https://www.cnn.com/2020/10/10/world/nobel-prize-diversity-2020-intl/index.html](https://www.cnn.com/2020/10/10/world/nobel-prize-diversity-2020-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 04:01:27+00:00

Four women were honored during this year's memorable Nobel Prize week. But the prestigious award still has a diversity problem.

## Hurricane Delta leaves hundreds of thousands without power as it pummels parts of Louisiana and Texas
 - [https://www.cnn.com/2020/10/09/weather/hurricane-delta-friday/index.html](https://www.cnn.com/2020/10/09/weather/hurricane-delta-friday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 02:23:29+00:00

With fierce sideways rain pelting their homes and lashing winds tearing at their roofs -- or the tarps covering the holes in the roofs from a previous storm -- hundreds of thousands of people in Louisiana and southeast Texas waited out the fury of Hurricane Delta in the dark on Friday night.

## Jay-Z and Team Roc pay fees for those arrested in Wisconsin protests
 - [https://www.cnn.com/2020/10/09/entertainment/jay-z-team-roc-alvin-cole-family-trnd/index.html](https://www.cnn.com/2020/10/09/entertainment/jay-z-team-roc-alvin-cole-family-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 02:18:55+00:00

Jay-Z showed his support of protesters this week by paying the fees for those arrested and fined in Wauwatosa, Wisconsin, where demonstrators are calling for justice in the death of Alvin Cole at the hands of police, according to a spokeswoman for Team Roc.

## Armenia and Azerbaijan agree on a ceasefire, Russian foreign ministry says
 - [https://www.cnn.com/2020/10/09/europe/azerbaijan-armenia-cease-fire/index.html](https://www.cnn.com/2020/10/09/europe/azerbaijan-armenia-cease-fire/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 02:18:49+00:00

Armenia and Azerbaijan have agreed to a ceasefire in their conflict over the enclave of Nagorno Karabakh, according to a readout published by the Russian Foreign Ministry.

## Former principal who said he couldn't confirm that the Holocaust was real is rehired to a new position
 - [https://www.cnn.com/2020/10/09/us/florida-principal-holocaust-rehired-trnd/index.html](https://www.cnn.com/2020/10/09/us/florida-principal-holocaust-rehired-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 01:16:21+00:00

A former high school principal in Florida, who was fired last year after appearing to cast doubt on the historical truth of the Holocaust, has been rehired in a new position.

## US caution over vaccine gives China a head-start
 - [https://www.cnn.com/2020/10/09/asia/china-covid-vaccine-global-race-intl-hnk/index.html](https://www.cnn.com/2020/10/09/asia/china-covid-vaccine-global-race-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 01:11:47+00:00

• Live updates: British doctors say government's Covid measures are not working

## Trump invites thousands to hear him speak at White House
 - [https://www.cnn.com/2020/10/09/politics/trump-covid-friday/index.html](https://www.cnn.com/2020/10/09/politics/trump-covid-friday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 01:05:14+00:00

President Donald Trump will emerge from his Covid-forced isolation Saturday for a speech from a White House balcony, allowing the public their first independent glimpse in days of a leader recovering from coronavirus.

## Two Maine police officers who allegedly beat porcupines to death while on duty have been fired
 - [https://www.cnn.com/2020/10/09/us/police-porcupines-trnd/index.html](https://www.cnn.com/2020/10/09/us/police-porcupines-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 00:42:39+00:00

Two Maine police officers were fired from the Rockland Police Department following a criminal and internal investigation into allegations leveled against them.

## Trump's law-and-order mantra goes missing in wake of domestic terror plot against Democratic governor
 - [https://www.cnn.com/2020/10/09/politics/trump-gretchen-whitmer-law-and-order/index.html](https://www.cnn.com/2020/10/09/politics/trump-gretchen-whitmer-law-and-order/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-10 00:35:42+00:00

Over the summer, as racial justice demonstrations swept through American cities, President Donald Trump warned he would wield the powers of government to suppress violence. Embracing a "law and order" mantle, Trump himself announced from the East Room a surge of federal agents and castigated groups such as Black Lives Matter as cultivating "hate."

