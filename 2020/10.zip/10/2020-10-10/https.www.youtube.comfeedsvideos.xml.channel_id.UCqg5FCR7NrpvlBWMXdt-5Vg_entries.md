# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Cyberpunk 2077 Crunch, Online Toxicity and Platform Responsibility | The Escapist Show
 - [https://www.youtube.com/watch?v=Rr9PIu4bOyI](https://www.youtube.com/watch?v=Rr9PIu4bOyI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-10-11 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

This week on The Escapist Show, we discuss our time playing Crash 4, Spelunky 2 and Star Wars: Squadrons, the Cyberpunk 2077 crunch news, the online toxicity surrounding it and being responsible with your platform.

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Timestamps
0:00 - 13:28 - Crash 4, Spelunky 2 and Squadrons discussion
13:29 - 38:28 - Cyberpunk 2077 crunch, online toxicity and platform responsibility

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Hubie Halloween, The Witches and Possessor Uncut | The Escapist Movie Podcast
 - [https://www.youtube.com/watch?v=-rsmx_bCR2U](https://www.youtube.com/watch?v=-rsmx_bCR2U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-10-10 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

This week on The Escapist Movie Podcast, Bob Chipman, Jack Packard, and Darren Mooney continue talking about spooky movies.

Hubie Halloween is the newest Adam Sandler production that has more funny voices than structure. The Witches remake on HBO Max updates the look, but might miss the horror and Possessor Uncut is a simple story told with the trademark goopy Cronenberg vibe.

Timestamps
2:28 - 29:29 - Hubie Halloween
29:30 - 58:44  - The Witches
58:45 - 1:16:00 - Possessor Uncut

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

