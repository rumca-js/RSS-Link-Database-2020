# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## 10 Cool Chrome Extensions You Gotta See!
 - [https://www.youtube.com/watch?v=7Rs_6u-kjSc](https://www.youtube.com/watch?v=7Rs_6u-kjSc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2020-10-10 00:00:00+00:00

Really cool chrome extensions you should know about!
Timetamps:
0:00 Introduction
0:15 Toucan
1:35 Relaxing Sounds
2:25 "Trim"
3:18 MarkUp for Chrome
4:07 Netflix Party
4:46 Just Read
5:29 OneTab
6:29 Workona
7:59 Suspicious Site Reporter
8:51 Link to Text Fragment

Links:
• Toucan: https://chrome.google.com/webstore/detail/toucan/lokjgaehpcnlmkebpmjiofccpklbmoci
• Relaxing Sounds: https://chrome.google.com/webstore/detail/relaxing-sounds-giovesoft/gpgbpbpobbgnaognooilkmncoonaedao
• "Trim": https://chrome.google.com/webstore/detail/trim-imdb-ratings-on-netf/lpgajkhkagnpdjklmpgjeplmgffnhhjj
• MarkUp for Chrome: https://chrome.google.com/webstore/detail/markup-for-chrome/llbkdcpbiogplgmefnkbgcdfiopfphbc/
• Netflix Party: https://chrome.google.com/webstore/detail/netflix-party/oocalimimngaihdkbihfgmpkcpnmlaoa
• Just Read: https://chrome.google.com/webstore/detail/just-read/dgmanlpmmkibanfdgjocnabmcaclkmod
• OneTab: https://chrome.google.com/webstore/detail/onetab/chphlpgkkbolifaimnlloiipkdnihall
• Workona: https://chrome.google.com/webstore/detail/workona/ailcmbgekjpnablpdkmaaccecekgdhlh
• Suspicious Site Reporter: https://chrome.google.com/webstore/detail/suspicious-site-reporter/jknemblkbdhdcpllfgbfekkdciegfboi
• Link to Text Fragment: https://chrome.google.com/webstore/detail/link-to-text-fragment/pbcodcjpfjdpcineamnnmbkkmkdpajjg

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV

My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

#Chrome #Tech #ThioJoe

