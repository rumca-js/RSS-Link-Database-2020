# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Aloe Blacc - My Way - live MUZO.FM
 - [https://www.youtube.com/watch?v=A4jYgVdG4Ew](https://www.youtube.com/watch?v=A4jYgVdG4Ew)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-10-10 00:00:00+00:00

Aloe Blacc na żywo w MUZO.FM. Utwór My Way pochodzi z najnowszej płyty artysty - All Love Everything. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Aloe Blacc: http://www.facebook.com/aloeblacc
Instagram Aloe Blacc: http://www.instagram.com/aloeblacc
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm


Aloe Blacc My Way lyrics

I've been sad, I've been lost 
I've been down and out and lonely 
I've been suffering at a job, in a world that tries to own me
But when I wake up every morning there's an image of a better place 
’Cause the harder that we grind 
Then the sweeter is the glory

People say I’m foolish
People say I’m blinded by faith
But if I run out of air 
If I crash I don’t care 
I’m gonna do it my way

I can make it through this
You can throw the world in my face
But the fear gives me life
And I swear 'til I die
I’m gonna do it my way
Aye, gonna do it my way
Aye, gonna do it my way

So put me down and criticize me with your lies and with your parody
In the darkness I don't hide, ’cause I got pride that gives me clarity 
I still wake up in the morning with a vision of a better life
You see the option of defeat is just not written in my story

People say I’m foolish
People say I'm blinded by faith
But if I run out of air
If I crash I don’t care 
I’m gonna do it my way

I can make it through this
You can throw the world in my face
But the fear gives me life
And I swear 'til I die
I’m gonna do it my way
Aye, gonna do it my way
Aye, gonna do it my way 

Every time they build a wall around me
I will tear it down and say
I'ma live my dreams
Gotta live my dreams

Even when the floods rush round to drown me
I just hold my breath and pray 
Let me live my dreams
Every single one of my 
I ain't quitting none of my dreams

People say I'm foolish
People say I'm blinded by faith
But if I run out of air 
If I crash I don’t care 
I’m gonna do it my way

I can make it through this
You can throw the world in my face
But the fear gives me life
And I swear 'til I die
I’m gonna do it my way
Let me fly through the air, if I crash I don't care
I’m gonna do it my way 
’Cause the fear gives me life
And I swear, 'til I die
I’m gonna do it my way

