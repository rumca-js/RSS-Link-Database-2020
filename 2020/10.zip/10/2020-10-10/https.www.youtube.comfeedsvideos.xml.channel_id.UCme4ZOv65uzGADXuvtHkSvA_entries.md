# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Ewangelia według św. Marka || Rozdział 12
 - [https://www.youtube.com/watch?v=Zc8wbrciD44](https://www.youtube.com/watch?v=Zc8wbrciD44)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-10-11 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! 
 
UWAGA WYZWANIE i to życiodajne!
Codziennie razem czytamy 1 rozdział życiodajnego SŁOWA BOGA. 
Dołącz do nas! Razem przeczytamy całe Pismo Święte!

Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Historie potłuczone [#15] O Blance, co się w bracie zakochała
 - [https://www.youtube.com/watch?v=f6He6mgBCUQ](https://www.youtube.com/watch?v=f6He6mgBCUQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-10-11 00:00:00+00:00

@Langustanapalmie   #historiepotłuczone #podcast

Historie potłuczone to opowieści o córkach i synach Boga, pięknych i brzydkich, świętych i grzesznych, szczęśliwych i na skraju rozpaczy. To opowieści o drodze, którą idzie się do nieba i o zakrętach i chaszczach, które spychają do piekła. To opowieści o ludziach po prostu. Czyli o nas.

Muzyka: Kai Engel: Brand New World, http://freemusicarchive.org/music/Kai_Engel/
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Mocno stronniczy [#15] Najgorszy odcinek w historii Youtuba
 - [https://www.youtube.com/watch?v=V383xr9AdmM](https://www.youtube.com/watch?v=V383xr9AdmM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-10-11 00:00:00+00:00

@STREFAWODZA @Langustanapalmie 

Takich dwóch, jak Ci to nie ma :) Zapraszamy co niedzielę o godz: 10:oo, na premierę zupełnie niesłychanej serii ojców Tomasza Nowaka OP i Adama Szustaka OP.

zdjęcia i montaż: Marcin Jończyk
grafika: Sylwia Smoczyńska
dźwięk: Mateusz Irysik
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#202] Nie czujesz Boga? Bo jesteś trupem!
 - [https://www.youtube.com/watch?v=STmMkZgPgKc](https://www.youtube.com/watch?v=STmMkZgPgKc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-10-10 00:00:00+00:00

#cnn #kazaniedookienka @Langustanapalmie 

Kazanie XXVIII Niedzielę zwykłą, Rok A 

1. czytanie (Iz 25, 6-10a)

Pan Zastępów przygotuje dla wszystkich ludów na tej górze ucztę z tłustego mięsa, ucztę z wybornych win, z najpożywniejszego mięsa, z najwyborniejszych win. Zedrze On na tej górze zasłonę, zapuszczoną na twarz wszystkich ludów, i całun, który okrywał wszystkie narody; raz na zawsze zniszczy śmierć. Wtedy Pan Bóg otrze łzy z każdego oblicza, zdejmie hańbę ze swego ludu na całej ziemi, bo Pan przyrzekł.
I powiedzą w owym dniu: Oto nasz Bóg, Ten, któremu zaufaliśmy, że nas wybawi; oto Pan, w którym złożyliśmy naszą ufność; cieszmy się i radujmy z Jego zbawienia! Albowiem ręka Pana spocznie na tej górze.

2. czytanie (Flp 4, 12-14. 19-20)

Bracia: Umiem cierpieć biedę, umiem też korzystać z obfitości. Do wszystkich w ogóle warunków jestem zaprawiony: i być sytym, i głód cierpieć, korzystać z obfitości i doznawać niedostatku. Wszystko mogę w Tym, który mnie umacnia. W każdym razie dobrze uczyniliście, biorąc udział w moim ucisku.
A Bóg mój według swego bogactwa zaspokoi wspaniale w Chrystusie Jezusie każdą waszą potrzebę. Bogu zaś i Ojcu naszemu chwała na wieki wieków. Amen.

Ewangelia (Mt 22, 1-14)

Jezus w przypowieściach mówił do arcykapłanów i starszych ludu: «Królestwo niebieskie podobne jest do króla, który wyprawił ucztę weselną swemu synowi. Posłał więc swoje sługi, żeby zaproszonych zwołali na ucztę, lecz ci nie chcieli przyjść.
Posłał jeszcze raz inne sługi z poleceniem: „Powiedzcie zaproszonym: Oto przygotowałem moją ucztę; woły i tuczne zwierzęta ubite i wszystko jest gotowe. Przyjdźcie na ucztę!” Lecz oni zlekceważyli to i odeszli: jeden na swoje pole, drugi do swego kupiectwa, a inni pochwycili jego sługi i znieważywszy, pozabijali. Na to król uniósł się gniewem. Posłał swe wojska i kazał wytracić owych zabójców, a miasto ich spalić. Wtedy rzekł swoim sługom: „Uczta weselna wprawdzie jest gotowa, lecz zaproszeni nie byli jej godni. Idźcie więc na rozstajne drogi i zaproście na ucztę wszystkich, których spotkacie”. Słudzy ci wyszli na drogi i sprowadzili wszystkich, których napotkali: złych i dobrych. I sala weselna zapełniła się biesiadnikami.
Wszedł król, żeby się przypatrzyć biesiadnikom, i zauważył tam człowieka nieubranego w strój weselny. Rzekł do niego: „Przyjacielu, jakże tu wszedłeś, nie mając stroju weselnego?” Lecz on oniemiał. Wtedy król rzekł sługom: „Zwiążcie mu ręce i nogi i wyrzućcie go na zewnątrz, w ciemności! Tam będzie płacz i zgrzytanie zębów”. Bo wielu jest powołanych, lecz mało wybranych».

________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Ewangelia według św. Marka || Rozdział 11
 - [https://www.youtube.com/watch?v=TjMG90hhG4I](https://www.youtube.com/watch?v=TjMG90hhG4I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-10-10 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! 
 
UWAGA WYZWANIE i to życiodajne!
Codziennie razem czytamy 1 rozdział życiodajnego SŁOWA BOGA. 
Dołącz do nas! Razem przeczytamy całe Pismo Święte!

Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Targ intencji || październik 2020
 - [https://www.youtube.com/watch?v=Uu-uzhsOZg4](https://www.youtube.com/watch?v=Uu-uzhsOZg4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-10-10 00:00:00+00:00

Targ intencji na październik 2020.
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

♫ Słuchaj jako PODCAST Langusty: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
iTunes → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWHx

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#632] Po wodzie
 - [https://www.youtube.com/watch?v=fRxxk_Xby80](https://www.youtube.com/watch?v=fRxxk_Xby80)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-10-10 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał  
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie


♫ Słuchaj jako PODCAST Langusty: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
iTunes → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWHx

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

