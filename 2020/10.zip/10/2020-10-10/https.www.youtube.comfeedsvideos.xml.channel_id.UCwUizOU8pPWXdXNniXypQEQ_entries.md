# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Are You Outsourcing Your Truth? - Authentic JP
 - [https://www.youtube.com/watch?v=RISAjTGhRO0](https://www.youtube.com/watch?v=RISAjTGhRO0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-10-10 00:00:00+00:00

Are you outsourcing your truth? Just a little something to think about for your personal empowerment. #SincereSaturday

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

