# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Heart Bones - full session at The Current (2020)
 - [https://www.youtube.com/watch?v=ENRB4IKc7g4](https://www.youtube.com/watch?v=ENRB4IKc7g4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-10-11 00:00:00+00:00

The Local Show on October 11 will include live-performance highlights by Heart Bones. In February 2020, just before the pandemic took hold, Heart Bones — fronted by the duo of Sean Tillmann and Sabrina Ellis — visited The Current studio to perform songs from their album, "Hot Dish." A tour was meant to follow, but global events dictated otherwise. Nevertheless, enjoy this spirited and catchy performance that will get you dancing along with the band.

SONGS PERFORMED
0:00 "Open Relations"
4:03 "I Like Your Way"
7:26 "Don’t Read the Comments"

PERSONNEL
Sabrina Ellis - vocals
Sean Tillmann - vocals and guitar
Aaron Baum - synthesizer and vocals
Ryan Mach - drums and percussion
Adam Hurlburt - bass and guitar

CREDITS
Video & Photo: Nate Ryan
Audio: Michael DeMark
Production: Jesse Wiza

FIND MORE:
2018 studio session: https://www.thecurrent.org/feature/2018/11/20/heart-bones-perform-in-the-current-studio
2019 performance at The Current's Day Party during SXSW 2019: https://www.thecurrent.org/feature/2019/03/15/watch-heart-bones-perform-at-the-current-day-party-in-austin-texas-sxsw
2019 Rock The Garden performance:
https://www.thecurrent.org/feature/2019/07/19/watch-heart-bones-double-your-pleasure-at-rock-the-garden
2020 studio session:
https://www.thecurrent.org/feature/2020/02/18/heart-bones-current-studio

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#heartbones #seantillmann #sabrinaellis

## Blu DeTiger: Virtual Session
 - [https://www.youtube.com/watch?v=4qMWQ8j7Dpc](https://www.youtube.com/watch?v=4qMWQ8j7Dpc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-10-10 00:00:00+00:00

Blu DeTiger joins us for a virtual session to perform a few tracks she's released this summer, and talks to us about sharpening her skills while playing bass over DJ sets in New York clubs, finding success on Tik Tok, and what she'll be releasing later this fall.

SONGS PLAYED
05:11 Cotton Candy Lemonade
17:30 Figure It Out

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

CREDITS
Host: Jim McGuinn
Producer: Jesse Wiza
Technical Director: Peter Ecklund

