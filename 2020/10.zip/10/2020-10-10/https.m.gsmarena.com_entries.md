## EU's Digital Service Act will force makers to allow you to uninstall bloatware
 - [https://m.gsmarena.com/eus_digital_service_act_will_allow_you_to_uninstall_bloatware-news-45578.php](https://m.gsmarena.com/eus_digital_service_act_will_allow_you_to_uninstall_bloatware-news-45578.php)
 - RSS feed: https://m.gsmarena.com
 - date published: 2020-10-10 18:35:47+00:00

EU's Digital Service Act will force makers to allow you to uninstall bloatware

