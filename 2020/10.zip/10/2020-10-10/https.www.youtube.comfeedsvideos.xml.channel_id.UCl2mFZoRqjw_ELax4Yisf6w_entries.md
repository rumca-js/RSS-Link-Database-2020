# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Yelp moderates racism with public attention alerts
 - [https://www.youtube.com/watch?v=KXAY_NYbY0E](https://www.youtube.com/watch?v=KXAY_NYbY0E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-10-11 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
👉 https://blog.yelp.com/2020/10/new-consumer-alert-on-yelp-takes-firm-stance-against-racism
👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my You can find this on eBay with a broken flash very cheaply(mine was about $250)
🔵 Microphone: https://amzn.to/2GoiSb0 You can find this used cheaply.
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

