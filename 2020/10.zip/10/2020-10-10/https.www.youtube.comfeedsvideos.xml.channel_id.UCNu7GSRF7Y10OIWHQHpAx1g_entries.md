# Source:BezPlanu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g, language:pl-PL

## Fenomen przyrodniczy w Albanii - Blue Eye
 - [https://www.youtube.com/watch?v=MKlTjAkBZN4](https://www.youtube.com/watch?v=MKlTjAkBZN4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g
 - date published: 2020-10-11 00:00:00+00:00

Polak w Albanii:
https://www.youtube.com/channel/UCdpv6izdAwfAgRzZ5AK0Qeg

Wszystkie odcinki chronologicznie: http://bit.ly/2MqAO7Q
(można też klikać w kartę "Następny odcinek" pojawiającą się pod koniec każdego filmu po prawej stronie u góry)

Wsparcie Patronite: http://bit.ly/2KsFTZk 
Instagram: http://instagram.com/bezplanu_czukesky 
Facebook: https://www.facebook.com/BezPlanu.tv 

Czas akcji: 20 października 2019 r.

