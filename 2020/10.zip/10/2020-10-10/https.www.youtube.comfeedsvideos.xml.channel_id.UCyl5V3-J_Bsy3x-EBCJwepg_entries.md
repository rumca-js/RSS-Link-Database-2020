# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Babylon Bee Writers React To Ridiculous Fact Check
 - [https://www.youtube.com/watch?v=RgweRYx7LdI](https://www.youtube.com/watch?v=RgweRYx7LdI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-10-11 00:00:00+00:00

The Babylon Bee, the very obvious satire site, has been fact checked by multiple news organizations for such headlines as Whether A Priest, A Rabbi, and A Minister Really Walking Into A Bar Together, Ninth Circuit Court Overturns Death Of Ruth Bader Ginsburg, Ocasio-Cortez Appears On ‘The Price Is Right,’ Guesses Everything is Free. 

Come hear how hard hitting journalism took down the Babylon Bee in the most hilarious of ways. 

See the full show here:
https://youtu.be/-rodN2LSSVw

Subscribe to the Babylon Bee to help fund more satirical news for USA Today to fact check. 

Hit the Bell to get your daily dose of fake news that you can trust.

## Hate Mail Accuses Bee Editor Of Being A Secret Leftist
 - [https://www.youtube.com/watch?v=TOM3tcnQrZU](https://www.youtube.com/watch?v=TOM3tcnQrZU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-10-10 00:00:00+00:00

Hate mail to the Babylon Bee is always one of our most popular segments. Come see the comments and emails that real people send out to the Babylon Bee.

See the full show here:
https://youtu.be/-rodN2LSSVw

Subscribe to the Babylon Bee to get more fake news you can trust. 

Hit the bell to see more from the guy in the Zelda T-shirt and quiet plaid shirt guy.

## The Best Babylon Bee Headlines Written By Kids
 - [https://www.youtube.com/watch?v=Xq-E5nHYYRQ](https://www.youtube.com/watch?v=Xq-E5nHYYRQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-10-10 00:00:00+00:00

Babylon Bee subscribers were asked to send in headline ideas from their kids. We read the best ones pre-recorded live. Enjoy these hilarious ideas that may or not be fact checked by Snopes by the time this comes out. 

See the full show here:
https://youtu.be/-rodN2LSSVw

Subscribe to the Babylon Bee to help children everywhere learn the power of having parents that pay for a premium subscription with the Babylon Bee

Hit the Bell to get your daily dose of fake news that you can trust.

## Trump Supporter Changes Mind After Pres Gets COVID - BNN Week In Review 10-9-2020
 - [https://www.youtube.com/watch?v=gIzh9cJZHaU](https://www.youtube.com/watch?v=gIzh9cJZHaU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-10-10 00:00:00+00:00

Trump got COVID-19 this week. How did his supporters handle it? Guy Curtis and Samantha Kurlock interview one Trump supporter who has changed his mind.

