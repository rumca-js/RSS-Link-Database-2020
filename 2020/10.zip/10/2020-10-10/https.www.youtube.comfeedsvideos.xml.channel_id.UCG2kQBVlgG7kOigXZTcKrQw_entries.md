# Source:Kołem się toczy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw, language:pl-PL

## Bajeczna inwersja w ALPACH. Austria bez planu (i z pięknymi widokami!)
 - [https://www.youtube.com/watch?v=kxWSsiyRuyU](https://www.youtube.com/watch?v=kxWSsiyRuyU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw
 - date published: 2020-10-11 00:00:00+00:00

Zostaw suba, podaj dalej! :) Dziś pokręcimy się po Styrii i Górnej Austrii. Dokładniej mówiąc po Kalkalpen, czyli Północnych Alpach Wapiennych, a także po okolicach Ausseerland (Szczyt Loser) gdzie miał miejsce najlepszy wschód w tym roku. 

Chcesz wspomóc kanał? Kup moje książki lub kurs filmowo-montażowy 
Kurs ►► https://www.kursfilmowaniaimontazu.pl/
Zarabianie na podróżach ►► https://bit.ly/2BysGNg
Twoja Samodzielna Podróż ►► http://bitly.com/2bOhhZv

Zapraszam też na:
Facebook: http://bit.ly/2flU84f
Instagram: http://bit.ly/2eTrIMc
Blog: http://kolemsietoczy.pl/

Muzyka: Artlist oraz Nevaeh https://soundcloud.com/nevaxh

No i Spis treści tego alpejskiego odcinka:

00:00 - 00:47 Trekking w austriackich Alpach, gdzie jechać?
00:48 - 03:46 Kalkalpen Park Narodowy Alp Wapiennych
03:47 - 04:21 Trekking na Hoher Nock. Wejście na najwyższy szczyt
04:22 - 05:47 Hallstatt - zwiedzanie, czy warto?
05:47 - 09:10 Wejście na Loser (Ausseerland). 2 trekking w Alpach
09:11 - 13:40 Inwersja w Alpach!
13:41 - 17:35 Styria. Austria środkowa rowerem

