# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week: Czy badanie na covid powoduje wyciek mózgu? A także: Sony Xperia I mark II, Pixel Buds
 - [https://www.youtube.com/watch?v=l07j-lsOgvs](https://www.youtube.com/watch?v=l07j-lsOgvs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-10-11 00:00:00+00:00

Dziś w odcinku: podłe żarty z poważnych tematów, czyli kolejna normalna niedziela.
Insta: http://bit.ly/InstaKlawiatur 
Twitter: http://bit.ly/TTKlawitera
FB: http://bit.ly/FBKlawiatur
Centrum Testów: https://bit.ly/3jP4ebD

Źródła:
iPhone 12 przecieki: https://bit.ly/3iQMICu
OnePlus 8T: https://bit.ly/2SN8koM
Sony Xperia I mark II: https://bit.ly/3jRFNtR
Słuchawki Bose w Centrum Testów: https://bit.ly/3nE7wkb
Reklama perfum Kenzo World: https://bit.ly/31cv1Yb
Pixel Buds recenzja: https://bit.ly/34Ndfvf
Co jest w środku PS5: https://bit.ly/2H0fe7d
Nowe słuchawki Devialet Gemini: https://bit.ly/34PuIn1
Wyciekający mózg: https://bit.ly/34OtBDY
I dlaczego raczej nie jest to możliwe: https://bit.ly/30XDqOK

