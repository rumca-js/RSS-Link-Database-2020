# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Australia, Europe and the untreated
 - [https://www.youtube.com/watch?v=axbsErEDkNg](https://www.youtube.com/watch?v=axbsErEDkNg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2020-10-10 00:00:00+00:00



## UK Coronavirus Weekend Update
 - [https://www.youtube.com/watch?v=U_78EiIezNk](https://www.youtube.com/watch?v=U_78EiIezNk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2020-10-10 00:00:00+00:00

Global

Cases, + 350,000 (Friday) = 36,361,054 

Deaths, 1,056,186

UK

ONS Infection survey, (9th October)

19,933 people in 9,179 households

25 September to 1 October 2020

https://www.ons.gov.uk/peoplepopulationandcommunity/healthandsocialcare/conditionsanddiseases/bulletins/coronaviruscovid19infectionsurveypilot/englandwalesandnorthernireland9october2020

England

224,400 people, community, had the coronavirus

(Previous weeks 116,600)

1 in 240 people

17,200 new cases per day

Highest rates, older teenagers and young adults

North East, North West, and Yorkshire and the Humber

North west

Increased hospitalisations correlated with increased cases in over 60s

Wales

6,100 infections in the week

(Previous week, 6,400)

1 in 500 people

Northern Ireland

1 in 500 people

Scotland

Population, 5.5 million

https://www.gov.scot/publications/coronavirus-covid-19-daily-data-for-scotland/

Cases, + 1,246 (Friday)

16.2% of positive tests (18,890 tests)

Deaths, + 6

Symptom tracker app

https://covid.joinzoe.com/data#levels-over-time

https://coronavirus.data.gov.uk/cases

Hospitalisations

https://coronavirus.data.gov.uk/healthcare

HAIs

https://www.telegraph.co.uk/news/2020/10/09/government-urged-pause-new-restrictions-cases-covid-caught-hospital/

England

18 % of patients in hospital with Covid-19

Tested positive for the first time seven days or more after admission

## US Coronavirus Weekend Update
 - [https://www.youtube.com/watch?v=9Cf0kpWT7l0](https://www.youtube.com/watch?v=9Cf0kpWT7l0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2020-10-10 00:00:00+00:00

US

Cases, 7, 665, 150

Deaths, 213,795

CDC forecast

Deaths, 233,000 by end of October

Third leading cause of death in US

Pre COVID

https://www.cdc.gov/nchs/fastats/deaths.htm
Heart disease: 647,457
Cancer: 599,108
Accidents (unintentional injuries): 169,936
Chronic lower respiratory diseases: 160,201
Stroke (cerebrovascular diseases): 146,383
Alzheimer’s disease: 121,404
Diabetes: 83,564
Influenza and Pneumonia: 55,672
Nephritis, nephrotic syndrome and nephrosis: 50,633
Intentional self-harm (suicide): 47,173
Dr Deborah Birx

Small private gatherings with people we know

25% increase in cases in past 2 weeks

Pennsylvania

New York

New Jersey

Connecticut

Vermont

New Hampshire

NYC

Cases, + 500

Highest since June

Broadway, closed until June 2021

President looking better

No longer taking any medications

Antibody treatment

https://uk.reuters.com/article/uk-health-coronavirus-usa-astrazeneca/u-s-astrazeneca-strike-deal-for-covid-19-antibody-treatment-touted-by-trump-idUKKBN26U2HO

Operation Warp Speed

U.S. government

Awarded $486 million to AstraZeneca

100,000 doses of antibody treatment

Regeneron, July, treatment for 300,000 people

Especially for high-risk population

Government was expecting to provide more than 1 million free doses 

Regeneron and Eli Lilly, applied for FDA emergency use authorizations

Eli Lilly said on Friday it had not signed an agreement with Operation Warp Speed.

Trials for prophylaxis (12 months) and treatment

