## WHO official urges world leaders to stop using lockdowns as primary virus control method | Washington Examiner
 - [https://www.washingtonexaminer.com/news/who-official-urges-world-leaders-to-stop-using-lockdowns-as-primary-virus-control-method](https://www.washingtonexaminer.com/news/who-official-urges-world-leaders-to-stop-using-lockdowns-as-primary-virus-control-method)
 - RSS feed: https://www.washingtonexaminer.com
 - date published: 2020-10-10 19:51:18+00:00

WHO official urges world leaders to stop using lockdowns as primary virus control method | Washington Examiner

