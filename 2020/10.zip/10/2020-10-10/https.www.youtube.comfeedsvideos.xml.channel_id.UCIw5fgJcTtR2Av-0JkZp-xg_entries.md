# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## Honey Badger Don't Care (Remixing The Crazy Nastyass Honey Badger by Randall)
 - [https://www.youtube.com/watch?v=NtCiPRL8fig](https://www.youtube.com/watch?v=NtCiPRL8fig)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2020-10-11 00:00:00+00:00

Support my music on Patreon: https://www.patreon.com/yuriwong Full track: 2:33

The Honey Badger is an awesome video featuring nature documentary footage with voiceover narration provided by the one and only Randall. Watch it here: https://www.youtube.com/watch?v=4r7wHMg5Yjg
Thanks for your amazing creation, Randall!

The video, titled "The Crazy Nastyass Honey Badger (original narration by Randall)" features footage taken from a National Geographic special on the ornery and tough honey badgers, which aired in 2007. You have to watch it, it's a work of art.

Some excerpts of Randall's genius:
"This is the honey badger. Watch it run in slow motion.

It's pretty badass. Look. It runs all over the place. "Whoa! Watch out!" says that bird.

Eew, it's got a snake! Oh! It's chasing a jackal! Oh my gosh!

Oh, the honey badger is just crazy!

The honey badger has been referred to by the Guiness Book of World Records as the most fearless animal in the animal kingdom. It really doesn't give a shit. If it's hungry, it's hungry.

Eew! What's that in its mouth? Oh, it's got a cobra? Oh, it runs backwards? Now watch this: look a snake's up in the tree. Honey badger don't care. It just takes what it wants. Whenever it's hungry it just -- Eew, and it eats, snakes... Watch it dig! Look at that digging.

The honey badger is really pretty badass. It has no regard for any other animal whatsoever. Look at him, he's just grunting, and eating snakes. Eew! What's that? A mouse? Oh that's nasty. They're so nasty. Oh look it's chasing things and eating them."

Sampled and created on the Teenage Engineering OP-1 and completed in Logic Pro X using stock plugins and instruments.

