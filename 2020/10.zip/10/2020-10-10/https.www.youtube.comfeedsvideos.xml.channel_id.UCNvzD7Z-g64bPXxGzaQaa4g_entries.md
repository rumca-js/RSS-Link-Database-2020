# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 5 Most Ambitious Games That Were Never Released [Part 2]
 - [https://www.youtube.com/watch?v=ykczFQCP-1w](https://www.youtube.com/watch?v=ykczFQCP-1w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-10-11 00:00:00+00:00

Continuing our series ranking exciting games that were either cancelled or disappeared. Read more via the sources below.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Sources

#5
https://massivelyop.com/2019/12/18/chronicles-of-elyria-begins-putting-unclaimed-land-up-for-sale-for-a-limited-time/
https://www.kickstarter.com/projects/soulboundstudios/chronicles-of-elyria-epic-story-mmorpg-with-aging
https://www.elyrianlife.com/news/chronicles-of-elyria-reaches-3-million-crowdfunding/

#4
https://www.youtube.com/watch?v=g5iM0PndX4I&ab_channel=Identity
https://store.steampowered.com/app/792990/Identity/#app_reviews_hash

#3
https://www.youtube.com/watch?v=aV1AlVq33Po&ab_channel=Punish
https://www.reddit.com/r/pcgaming/comments/cdoxc3/raw_kickstarter_suspended_scam_confirmed/

#2
https://www.eurogamer.net/articles/2013-09-26-lucasarts-spills-the-beans-on-what-star-wars-1313-could-have-been
https://www.youtube.com/watch?v=J_1_Nvn7DPM&

#1
https://metalgear.fandom.com/wiki/Metal_Gear_Solid:_Rising
https://www.youtube.com/watch?v=j7fddFXzJXM
https://www.destructoid.com/stories/metal-gear-rising-was-canceled-revengeance-isn-t-mgs-217728.phtml

