# Source:Luetin09, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC8RfCCzWsMgNspTI-GTFenQ, language:en-US

## 40K INDOMITUS BOX - NECRON & ULTRAS - LT's ARMY UPDATE 1.4 | WARHAMMER 40K MINIS
 - [https://www.youtube.com/watch?v=qK1-X_iSLOw](https://www.youtube.com/watch?v=qK1-X_iSLOw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC8RfCCzWsMgNspTI-GTFenQ
 - date published: 2020-10-27 00:00:00+00:00

► Siege Studios: https://siegestudios.co.uk/
► Goblin Gaming: (Get - 20% off 40K Products) https://tinyurl.com/6vwcayvj
► Premium Storage Solutions: https://www.crystal-fortress.com/
► Subscribe: http://goo.gl/oeZMBS 
► Patreon: https://www.patreon.com/Luetin 
► Twitch: http://www.twitch.tv/Luetin
► Twitter: http://twitter.com/luetin09

Exit23Games Turbodork:
https://exit23.games/collections/turbo-dork-paints

Rosemary Co 313
https://www.rosemaryandco.com/series-313?filter_name=313

0:00 Intro
1:57 The Indomitus Journey
11:36 Monopose
16:57 Indomitus Marines & Progression
22:01 Turbodork Metallic Paints
28:13 Current Brushes
32:53 Upcoming Projects
34:59 Necron Force - Siege Studios
42:43 Indomitus Necrons
51:20 New Codex Thoughts

► BGM Credits:
► Kevin MacLeod (Royalty Free Music): http://incompetech.com/music/
► https://epidemicsound.com

This video is an opinion editorial commentary.
Copyright Disclaimer Under Section 107 of the Copyright Act 1976, allowance is made for fair use purposes such as criticism, commentary, parody, news reporting, teaching, scholarship, and research.

All works used in this video (Images, audio etc) belong to their respective authors
(This does not include the audio commentary or licensed BGM).

Games workshop, Warhammer 40,000, Warhammer, 40k, Space Marine Etc are all Trademarks of Games Workshop Ltd. Games Workshop does not endorse or support the 'Lore' videos. All views and opinions expressed in this video belong to Luetin09 and in no way reflect the views or opinions of Games Workshop Ltd.

