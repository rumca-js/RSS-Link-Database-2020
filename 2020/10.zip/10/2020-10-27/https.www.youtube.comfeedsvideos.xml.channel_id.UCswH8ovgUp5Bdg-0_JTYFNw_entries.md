# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Is This How We Should Respond To Crisis? | Russell Brand
 - [https://www.youtube.com/watch?v=GQhq1v60PeI](https://www.youtube.com/watch?v=GQhq1v60PeI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-10-27 00:00:00+00:00

Taken from my #UnderTheSkin podcast with the incredibly insightful political analyst and metamodernist Seth Abramson!
You can listen to the rest of this podcast on Luminary: http://luminary.link/russell

Seth’s new book Proof of Corruption is available now: https://us.macmillan.com/books/9781250273000

Proof of Corruption concludes a series that includes 2018's Proof of Collusion and 2019's Proof of Conspiracy.

Listen to Seth’s podcast, Proof: A Pre-Election Special, here:
https://www.youtube.com/channel/UC_mrr4WnNM5peXgfFU443Cg

sethabramson.net
Twitter: @SethAbramson
Instagram: @seth.abramson

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

