# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## Laptop Total Disassembly and New Thermal Pasting
 - [https://www.youtube.com/watch?v=ub3b35865B0](https://www.youtube.com/watch?v=ub3b35865B0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-10-28 00:00:00+00:00

I wanted to cool down my laptop (ThinkPad X220)'s running speed so I repasted my computer's thermal paste. It's a good idea to do this every once in a while. This basically requires a total disassembly and removal of the mother board. It's not that hard and I show the process. I did run into a stripped screw, but some pliers did the work.

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE: https://lukesmith.xyz/donate 💰😎👌💯
OR affiliate links to things l use:
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://brave.com/luk005 Get the Brave browser.
https://lbry.tv/$/invite/@Luke View my videos on LBRY. Get a bonus for joining.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase. We both get $10 in Bitcoin when you buy or sell $100 in cryptocurrencies.

## rsync is a Based File Sync Program (& if you don't use it, you're wrong.)
 - [https://www.youtube.com/watch?v=iTnWIKHtOnA](https://www.youtube.com/watch?v=iTnWIKHtOnA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-10-27 00:00:00+00:00

If you want to copy files, make backups, transfer massive files, update your website, update files smartly minimizing bandwidth, rsync is basically the best. It's a command line tool for file transfer and is easily scriptable. I use it actually all the time for moving stuff on or off my local computer.

rsync makes keeping your website up to date mega-easy. To setup a website, see this based playlist:
https://www.youtube.com/watch?v=bdKZVIGRAKQ&list=PL-p5XmQHB_JRRnoQyjOfioJdDmu87DIJc
Links to a registrar (Epik) and server provider (Vultr) below:

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE: https://lukesmith.xyz/donate 💰😎👌💯
OR affiliate links to things l use:
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://brave.com/luk005 Get the Brave browser.
https://lbry.tv/$/invite/@Luke View my videos on LBRY. Get a bonus for joining.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase. We both get $10 in Bitcoin when you buy or sell $100 in cryptocurrencies.

