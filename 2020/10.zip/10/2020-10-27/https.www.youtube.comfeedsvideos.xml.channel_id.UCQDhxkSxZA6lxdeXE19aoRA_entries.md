# Source:Hugh Jeffreys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA, language:en-US

## iPhone 12 Anti Repair Design - Teardown and Repair Assessment
 - [https://www.youtube.com/watch?v=FY7DtKMBxBw](https://www.youtube.com/watch?v=FY7DtKMBxBw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA
 - date published: 2020-10-28 00:00:00+00:00

Apple says they are aiming for zero climate impact by 2030.
So to me that says a device should be able to be repaired when the time comes to, preventing it from becoming e-waste. But is that true?
--------------------------------------Socials-------------------------------------
Website: https://www.hughjeffreys.com 
Instagram: http://instagram.com/hughjeffreys
Twitter: https://twitter.com/hughjeffreys
---------------------------------------Links---------------------------------------
Get parts, tools, and thousands of free repair guides from iFixit at: 
    https://iFixit.com/hughjeffreys
Australia Store: https://ifix.gd/2FPxhKy
(DISCLAIMER: This description contains affiliate links, which means that if you click on one of the product links, l will receive a small commission.)
#iphone12 #righttorepair

