# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Scream 4 - (Re-Review)
 - [https://www.youtube.com/watch?v=N35UuB0TsP8](https://www.youtube.com/watch?v=N35UuB0TsP8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-10-27 00:00:00+00:00

Nearly 10 years after its release, I revisit Scream 4. Here's my re-review for SCREAM 4

#Scream

## Stephen King's SILVER BULLET - Movie Review
 - [https://www.youtube.com/watch?v=u7V1SoDkyak](https://www.youtube.com/watch?v=u7V1SoDkyak)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-10-27 00:00:00+00:00

Thanks to Crowd Cow for sponsoring.  Get $15 off your first order and an extra 5% off everything if you become a member at http://crowdcow.com/jeremy

A classic Stephen King werewolf story as far as I'm concerned. Here, I talk about the movie that scared me as a child. Here's my review for SILVER BULLET!

#SilverBullet #StephenKing

