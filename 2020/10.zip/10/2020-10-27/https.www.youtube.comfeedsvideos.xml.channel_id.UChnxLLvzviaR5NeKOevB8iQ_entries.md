# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## hindsight (music video)
 - [https://www.youtube.com/watch?v=xBYug1VT8a8](https://www.youtube.com/watch?v=xBYug1VT8a8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2020-10-28 00:00:00+00:00

THIS VIDEO CONTAINS RAPIDLY FLASHING IMAGES
a music video for a song that is on an album
https://fanlink.to/rmrhindsight
Please vote: https://www.vote411.org/

LYRICS: 
Weighing on my mind
It's weighing on my mind
I can never let it go

Scars are the sign
I did a bad thing
Something I know better now

I'm in love with a memory
I'm in love with the memory of you

Easy on my mind
It’s easy on my mind
I know I can let it go

Everybody have
They have a bad time
No one wants to say it no

This is an S.O.S.
Someone help me get out of this place

Pull me outside
Pull me outside
I can give you all my strings
The world is a spark and my house is ablaze
Grab all the important things

We will burn the effigy
We will burn the effigy of you

We will burn the memory
We will burn the memory of you

We will say enough is enough

That’s enough
Settle down
I've been waiting

This is an S.O.S.
Someone help me get out of this place
------------------------------------
Thank you for watching. My name is Jeremy, and this is Red Means Recording. I've been making music for a few decades now, and this channel is a place to make music and to talk about the tools and techniques to make music with. We'll use synths, drum machines, modular gear, and software. 

If you'd like to support the channel, I have a Patreon:  http://bit.ly/rmrpatreon

I have music as "Jeremy Blake" on all the major services: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

I have some merch here: http://bit.ly/rmrshirts

And you can connect with me here: 
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

