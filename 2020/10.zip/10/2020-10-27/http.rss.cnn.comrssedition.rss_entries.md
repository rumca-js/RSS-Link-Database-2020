# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## 'Borat' creator shows unseen footage of prank on 'Colbert'
 - [https://www.cnn.com/videos/media/2020/10/27/borat-unseen-footage-orig-jk.cnn](https://www.cnn.com/videos/media/2020/10/27/borat-unseen-footage-orig-jk.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 22:51:58+00:00

"Borat" creator Sacha Baron Cohen went on CBS' "The Late Show with Stephen Colbert" to show unseen footage of what happened when the far-right audience he trolled realized his identity.

## Melania Trump slams Democrats during first solo campaign event
 - [https://www.cnn.com/videos/politics/2020/10/27/melania-trump-pennsylvania-pandemic-sot-vpx.cnn](https://www.cnn.com/videos/politics/2020/10/27/melania-trump-pennsylvania-pandemic-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 21:46:42+00:00

First lady Melania Trump went after Democrats in her first solo campaign event of 2020, saying they politicized the Covid-19 pandemic.

## CNN reporter asks Trump: Did you blow it on Covid-19?
 - [https://www.cnn.com/videos/politics/2020/10/27/trump-covid-19-election-jim-acosta-tsr-vpx.cnn](https://www.cnn.com/videos/politics/2020/10/27/trump-covid-19-election-jim-acosta-tsr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 21:37:54+00:00

President Trump is upset about media coverage of the coronavirus pandemic despite surging infections and hospitalizations in the US.

## Protests in Italy over anti-virus measures turn violent
 - [https://www.cnn.com/videos/world/2020/10/27/italy-protests-covid-restrictions-lon-orig-mrg.cnn](https://www.cnn.com/videos/world/2020/10/27/italy-protests-covid-restrictions-lon-orig-mrg.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 19:19:47+00:00

Demonstrations took place in several cities of Northern Italy on Monday, following new restrictions to curb the country's second wave of Covid.

## Meteorite that fell to Earth in 2018 reveals its secrets
 - [https://www.cnn.com/2020/10/27/world/fireball-meteorite-organic-compounds-scn-trnd/index.html](https://www.cnn.com/2020/10/27/world/fireball-meteorite-organic-compounds-scn-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 17:52:35+00:00

A 12-million-year-old meteorite that fell to Earth in January 2018 is covered in more than 2,600 organic compounds, according to new research. Meteorites such as this one likely acted as messengers early in Earth's history, delivering the building blocks of life, the researchers said.

## Prince Harry says he grew up unaware of unconscious bias
 - [https://www.cnn.com/videos/world/2020/10/27/prince-harry-unconcsious-bias-gq-hutchinson-orig-vstop-bdk.cnn](https://www.cnn.com/videos/world/2020/10/27/prince-harry-unconcsious-bias-gq-hutchinson-orig-vstop-bdk.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 17:43:07+00:00

Prince Harry credits his marriage to Meghan Markle in opening his eyes to understanding unconscious racial bias.

## See the aftermath of violent anti-lockdown protests in Italy
 - [https://www.cnn.com/videos/world/2020/10/27/italy-coronavirus-covid-19-protests-restrictions-aftermath-wedeman-ctw-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2020/10/27/italy-coronavirus-covid-19-protests-restrictions-aftermath-wedeman-ctw-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 16:32:59+00:00

Protesters have clashed with police in northern Italy, as demonstrations erupted across the country over government restrictions aimed at quelling a second wave of Covid-19. CNN's Ben Wedeman reports.

## Judge rejects DOJ's attempt to defend Trump in E. Jean Carroll rape defamation lawsuit
 - [https://www.cnn.com/2020/10/27/politics/e-jean-carroll-defamation-lawsuit-trump/index.html](https://www.cnn.com/2020/10/27/politics/e-jean-carroll-defamation-lawsuit-trump/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 16:13:15+00:00

A federal judge on Tuesday denied the Justice Department's effort to intervene in a defamation lawsuit brought against President Donald Trump by a longtime magazine columnist who has alleged he raped her, paving the way for the case to proceed.

## Brett Kavanaugh foreshadows how the US Supreme Court could disrupt vote counting
 - [https://www.cnn.com/2020/10/27/politics/kavanaugh-supreme-court-trump-biden/index.html](https://www.cnn.com/2020/10/27/politics/kavanaugh-supreme-court-trump-biden/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 16:10:57+00:00

Justice Brett Kavanaugh on Monday night set the battle lines for how the Supreme Court should consider post-election lawsuits that could determine the outcome of the presidential race.

## Hearings begin into killings of Nigerian protesters
 - [https://www.cnn.com/2020/10/27/africa/nigerian-protesters-hearings-intl/index.html](https://www.cnn.com/2020/10/27/africa/nigerian-protesters-hearings-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 15:35:50+00:00

A week after the killing of activists protesting police brutality in Nigeria's largest city, a Lagos state government judicial panel began hearings into the violence on Tuesday.

## Brian May 'nearly lost' his life after heart attack
 - [https://www.cnn.com/2020/10/27/entertainment/brian-may-heart-attack-grateful-intl-scli-gbr/index.html](https://www.cnn.com/2020/10/27/entertainment/brian-may-heart-attack-grateful-intl-scli-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 15:27:22+00:00

Queen guitarist Brian May has said he is "grateful" to be alive after suffering a heart attack, a stomach hemorrhage and other health complications this year.

## Biden makes late push for red states
 - [https://www.cnn.com/2020/10/27/politics/2020-election-biden-trump/index.html](https://www.cnn.com/2020/10/27/politics/2020-election-biden-trump/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 15:23:49+00:00

Democratic presidential nominee Joe Biden's campaign is making a late push into deeper-red states in the final week before the 2020 election, chasing a number of possible paths to 270 electoral votes while President Donald Trump focuses on defending a narrower set of states that he won four years ago but where polls show he now trails.

## Juventus faces nervy wait on Ronaldo's coronavirus test results
 - [https://www.cnn.com/2020/10/27/football/cristiano-ronaldo-coronavirus-juventus-barcelona-champions-league-spt-intl/index.html](https://www.cnn.com/2020/10/27/football/cristiano-ronaldo-coronavirus-juventus-barcelona-champions-league-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 15:12:03+00:00

Cristiano Ronaldo is expected to find out later on Tuesday if he will be able to play in the highly anticipated Champions League clash against Barcelona and Lionel Messi

## Jack Ma is making history again with the Ant IPO, and getting even more wealthy while doing it
 - [https://www.cnn.com/2020/10/27/tech/jack-ma-ant-ipo-intl-hnk/index.html](https://www.cnn.com/2020/10/27/tech/jack-ma-ant-ipo-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 15:04:48+00:00

Billionaire tech tycoon Jack Ma is raising more than $34 billion in yet another record breaking IPO, further cementing his place in history as one of the world's great tech entrepreneurs.

## The tiny soccer team that's revolutionizing the game
 - [https://www.cnn.com/2020/10/27/football/midtjylland-fc-champions-league-innovative-spt-intl/index.html](https://www.cnn.com/2020/10/27/football/midtjylland-fc-champions-league-innovative-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 14:14:26+00:00

You need to be a bit of a European geography expert to pinpoint the city of Herning -- population 50,000 -- in Denmark.

## 'Sarah Cooper: Everything's Fine' gives the Trump satirist a bigger stage on Netflix
 - [https://www.cnn.com/2020/10/27/entertainment/sarah-cooper-everythings-fine-review/index.html](https://www.cnn.com/2020/10/27/entertainment/sarah-cooper-everythings-fine-review/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 14:13:07+00:00

Sarah Cooper's spot-on parodies of President Trump turned her into a social-media sensation, a promotional opportunity that didn't present an obvious way to translate that into a more expansive version. Happily, her guest-star-studded Netflix variety special incorporates her most famous shtick -- satirically lip-synching Trump speeches and interviews -- while adding a few extremely clever sketches and, perhaps inevitably, a couple clunkier bits akin to the last 15 minutes of "Saturday Night Live."

## Analysis: Trump tries to distract Americans on pandemic as polls fail to budge
 - [https://www.cnn.com/2020/10/27/politics/donald-trump-confirmation-amy-coney-barrett-joe-biden-election-2020-supreme-court/index.html](https://www.cnn.com/2020/10/27/politics/donald-trump-confirmation-amy-coney-barrett-joe-biden-election-2020-supreme-court/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 13:55:48+00:00

President Donald Trump claimed a place in history Monday when Amy Coney Barrett's confirmation secured a dominant conservative majority on the Supreme Court, but the pomp of his victory lap could not disguise the reality of a pandemic that has placed his presidency in deep peril a week before the election.

## Why 2020 could be the year of the young voter
 - [https://www.cnn.com/2020/10/27/politics/young-voters-2020-election/index.html](https://www.cnn.com/2020/10/27/politics/young-voters-2020-election/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 13:52:24+00:00

Just after sunup on a Saturday morning, when most college students are still sound asleep, sophomore Libby Klinger stands outside her dorm waiting to be picked up.

## This is how American students are getting out the vote
 - [https://www.cnn.com/videos/politics/2020/10/26/campus-shutdown-pa-voting-zw-js-orig.cnn](https://www.cnn.com/videos/politics/2020/10/26/campus-shutdown-pa-voting-zw-js-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 13:39:04+00:00

Usually college campuses in Pennsylvania would be filled with volunteers trying to register and cajole the ever-elusive student voter. But during the pandemic, Democrats have had to rewrite their campus playbook to encourage progressive first-time voters to cast their ballots.

## Investors are getting another chance to tap into the sports betting craze
 - [https://www.cnn.com/2020/10/27/investing/genius-sports-dmy-technology-merger/index.html](https://www.cnn.com/2020/10/27/investing/genius-sports-dmy-technology-merger/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 13:32:03+00:00

Investors may soon have another way to back the fast growing sports betting market in the United States.

## The weaponization of a first lady's image
 - [https://www.cnn.com/style/article/the-weaponization-of-a-first-ladys-image/index.html](https://www.cnn.com/style/article/the-weaponization-of-a-first-ladys-image/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 13:00:57+00:00

The role of first lady of the United States is one of the most visible public positions in the world. From the moment votes are counted, and often during campaigning in the preceding months, the spouse of a newly elected president is thrust into the spotlight, where she remains for the duration of his term.

## An artist tried to send Londoners a free print -- but thousands have been stolen
 - [https://www.cnn.com/style/article/stik-art-prints-theft-police-scli-intl-gbr/index.html](https://www.cnn.com/style/article/stik-art-prints-theft-police-scli-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 12:51:50+00:00

Thousands of prints by the street artist STIK, which were intended to be distributed as a gift to London residents after months of hardship during the coronavirus pandemic, have been stolen, police said on Tuesday.

## Novak Djokovic targets Pete Sampras' year-end world No. 1 record in Vienna
 - [https://www.cnn.com/2020/10/27/tennis/novak-djokovic-pete-sampras-tennis-spt-intl/index.html](https://www.cnn.com/2020/10/27/tennis/novak-djokovic-pete-sampras-tennis-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 12:42:38+00:00

While unable to edge closer to Roger Federer and Rafael Nadal in the grand slam leaderboard in the second half of the tennis season, Novak Djokovic is chasing one record that could see him outstrip his rivals.

## Strong early youth voter turnout in 2020 election
 - [https://www.cnn.com/videos/politics/2020/10/27/youth-vote-university-of-virginia-bash-newday-pkg-vpx.cnn](https://www.cnn.com/videos/politics/2020/10/27/youth-vote-university-of-virginia-bash-newday-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 12:41:17+00:00

CNN's Dana Bash speaks with students on both sides of the aisle at the University of Virginia about why they are voting, and the general youth voter turnout for the 2020 election.

## How early voting is consistent with the polls
 - [https://www.cnn.com/2020/10/27/politics/early-voting-analysis/index.html](https://www.cnn.com/2020/10/27/politics/early-voting-analysis/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 12:38:36+00:00

More folks are voting early than ever before. As of Monday afternoon, more than 60 million people have voted so far. That not only surpasses where we were at this point in 2016, it blows past the total number of people who voted early that year.

## Oil companies aren't out of the woods yet
 - [https://www.cnn.com/2020/10/27/investing/premarket-stocks-trading/index.html](https://www.cnn.com/2020/10/27/investing/premarket-stocks-trading/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 12:14:17+00:00

It wasn't long ago that the steepest plunge in demand in history erased profits at big oil companies and forced them to dramatically cut costs.

## Reality bites for Putin's Covid-19 vaccine as concerns over efficacy and safety linger
 - [https://www.cnn.com/2020/10/27/health/russia-coronavirus-vaccine-sputnik-v-reality-check/index.html](https://www.cnn.com/2020/10/27/health/russia-coronavirus-vaccine-sputnik-v-reality-check/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 12:06:10+00:00

In August, Russian state media rolled out the red carpet for a bombshell announcement -- President Vladimir Putin, from his residence outside Moscow, unveiled what he said was the world's first registered coronavirus vaccine, meant to bring Russia closer to the end of a devastating pandemic.

## With Barrett seated, Republicans push for Supreme Court hearing of Pennsylvania voting case
 - [https://www.cnn.com/2020/10/27/politics/election-2020-supreme-court-voting-challenge/index.html](https://www.cnn.com/2020/10/27/politics/election-2020-supreme-court-voting-challenge/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 12:00:12+00:00

With Amy Coney Barrett now seated on the Supreme Court, Republicans are pushing for reconsideration of a Pennsylvania case on mail-in voting -- the first potential test of how the new justice will handle election challenges.

## Is this the strongest US economy in history? CNN fact checks Trump
 - [https://www.cnn.com/videos/politics/2020/10/27/us-economy-trump-reality-check-avlon-newday-vpx.cnn](https://www.cnn.com/videos/politics/2020/10/27/us-economy-trump-reality-check-avlon-newday-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 11:39:16+00:00

CNN's John Avlon fact checks President Donald Trump's claims on the US economy after Trump said that "this is the greatest economy in our history."

## It's politics versus science as the UK battles coronavirus
 - [https://www.cnn.com/videos/world/2020/10/27/coronavirus-policy-science-vs-politics-isa-soares-pkg-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2020/10/27/coronavirus-policy-science-vs-politics-isa-soares-pkg-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 11:36:45+00:00

Around the world, politicians and scientists are having to work more closely together than ever before. With different priorities - and often very different personalities - the tensions are beginning to show. CNN's Isa Soares reports.

## These destinations were overwhelmed by tourists. Here's how they're doing now
 - [https://www.cnn.com/travel/article/overtourism-coronavirus/index.html](https://www.cnn.com/travel/article/overtourism-coronavirus/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 11:05:21+00:00

Overtourism was the travel buzzword of 2019, as destinations around the globe, from the hiking trails of Machu Picchu to the canals of Venice, battled the impact of throngs of visitors.

## Zlatan Ibrahimovic scores twice as Serie A leader AC Milan draws against AS Roma
 - [https://www.cnn.com/2020/10/27/football/ac-milan-as-roma-serie-a-football-spt-intl/index.html](https://www.cnn.com/2020/10/27/football/ac-milan-as-roma-serie-a-football-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 10:40:45+00:00

AC Milan dropped points in Serie A for the first time this season after a thrilling 3-3 draw against AS Roma at the San Siro on Monday.

## Therapy patients in Finland blackmailed after data breach
 - [https://www.cnn.com/2020/10/27/tech/finland-therapy-patients-blackmailed-data-breach-intl/index.html](https://www.cnn.com/2020/10/27/tech/finland-therapy-patients-blackmailed-data-breach-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 10:33:09+00:00

The confidential records of thousands of psychotherapy patients in Finland have been hacked and some are now facing the threat of blackmail.

## How is Israel's coronavirus response doing now?
 - [https://www.cnn.com/videos/world/2020/10/27/israel-coronavirus-covid-19-pandemic-liebermann-pkg-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2020/10/27/israel-coronavirus-covid-19-pandemic-liebermann-pkg-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 10:23:36+00:00

New cases of coronavirus are down in Israel following the reimposition of restrictions six weeks ago. CNN's Oren Liebermann looks at the lessons from a small desert town that went into lockdown ahead of the country, and how Israel is faring in the fight against the virus.

## Can Biden cause an upset in this red state?
 - [https://www.cnn.com/videos/politics/2020/10/21/georgia-2020-john-king-magic-wall-orig.cnn](https://www.cnn.com/videos/politics/2020/10/21/georgia-2020-john-king-magic-wall-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 10:02:27+00:00

While Joe Biden needs record turnout among African Americans to win Georgia, President Trump will be relying on the white, rural, working class. John King breaks down the numbers.

## HSBC plans to speed up restructuring as profits drop 36%
 - [https://www.cnn.com/2020/10/27/business/hsbc-stock-earnings-intl-hnk/index.html](https://www.cnn.com/2020/10/27/business/hsbc-stock-earnings-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 09:42:29+00:00

HSBC is speeding up its mammoth restructuring plan as the bank continues to grapple with ongoing headaches, from ultra-low interest rates and geopolitical tensions to the economic impact of the coronavirus pandemic.

## A four-day week worked for my company -- now it can help businesses come back from Covid
 - [https://www.cnn.com/2020/10/19/opinions/four-day-week-normal-spc-intl/index.html](https://www.cnn.com/2020/10/19/opinions/four-day-week-normal-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 09:15:15+00:00

In 2018, I initiated an experiment in my company, Perpetual Guardian, a New Zealand-based statutory supervisor and trustee company, to determine if I could get better productivity from my employees in exchange for a four-day week, with five days' pay.  We called this the 100:80:100™ rule -- 100% pay, 80% time, 100% productivity.

## At least 7 dead, dozens injured after blast in Pakistani city of Peshawar
 - [https://www.cnn.com/2020/10/27/asia/pakistan-peshawar-blast-intl-hnk/index.html](https://www.cnn.com/2020/10/27/asia/pakistan-peshawar-blast-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 08:25:52+00:00

Seven people have died and at least 70 more have been injured in a blast at a religious seminary on Tuesday in the northern Pakistani city of Peshawar, according to local authorities.

## Remembering the Black cabaret star Britain almost forgot
 - [https://www.cnn.com/style/article/leslie-hutchinson-black-history-month-gbr-intl/index.html](https://www.cnn.com/style/article/leslie-hutchinson-black-history-month-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 07:33:35+00:00

He was one of the biggest cabaret stars in the world in the 1920s and 1930s, wooed high society and recorded hundreds of songs. But today Leslie "Hutch" Hutchinson is barely remembered in Britain, the place he called home for most of his life.

## Emily Ratajkowski announces pregnancy in essay about gender, power and motherhood
 - [https://www.cnn.com/style/article/emily-ratajkowski-pregnant-vogue-intl-hnk-scli/index.html](https://www.cnn.com/style/article/emily-ratajkowski-pregnant-vogue-intl-hnk-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 06:07:01+00:00

Model Emily Ratajkowski has announced her pregnancy with a personal essay exploring questions of her unborn child's gender and identity.

## India to sign defensive agreement with US following Himalayan standoff with China
 - [https://www.cnn.com/collections/intl-china/](https://www.cnn.com/collections/intl-china/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 04:47:37+00:00



## Uyghurs are desperate for action in Xinjiang. Some say only Trump can help
 - [https://www.cnn.com/2020/10/26/asia/trump-biden-china-xinjiang-intl-hnk/index.html](https://www.cnn.com/2020/10/26/asia/trump-biden-china-xinjiang-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 04:14:49+00:00

When Donald Trump won the United States presidency in 2016, Uyghur exile and US citizen Erkin Sidick was stunned and disappointed.

## Why the GOP hold on Texas is loosening
 - [https://www.cnn.com/2020/10/27/politics/texas-2020-election-democrats/index.html](https://www.cnn.com/2020/10/27/politics/texas-2020-election-democrats/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 04:01:25+00:00

The huge surge of early voting in Texas' rapidly growing cities and inner suburbs likely marks the end of unchallenged Republican dominance in America's second largest state -- a seismic shift in the nation's electoral landscape.

## Immunity to Covid-19 wanes over time, study suggests
 - [https://www.cnn.com/2020/10/26/health/covid-19-immunity-wanes-large-study-finds/index.html](https://www.cnn.com/2020/10/26/health/covid-19-immunity-wanes-large-study-finds/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 03:59:32+00:00

A study of hundreds of thousands of people across England suggests immunity to the coronavirus is gradually wearing off - at least according to one measure.

## First 'murder hornet' nest found in the US removed
 - [https://www.cnn.com/videos/us/2020/10/26/murder-hornet-nest-removal-washington-orig-dp-llr.cnn](https://www.cnn.com/videos/us/2020/10/26/murder-hornet-nest-removal-washington-orig-dp-llr.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 02:48:03+00:00

Scientists have eradicated what's believed to be the first Asian giant hornet nest in the United States.

## These voters are dancing their way to the polls
 - [https://www.cnn.com/videos/politics/2020/10/27/dancing-early-voting-lines-jeanne-moos-vpx.cnn](https://www.cnn.com/videos/politics/2020/10/27/dancing-early-voting-lines-jeanne-moos-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 02:39:16+00:00

Latest dance hotspot...early voting lines. CNN's Jeanne Moos reports on dancing while voting.

## Trump walked off interview in 1990 when asked tough questions about his casino
 - [https://www.cnn.com/videos/business/2020/10/26/donald-trump-walks-out-of-intv-1990-pkg-vpx.cnn](https://www.cnn.com/videos/business/2020/10/26/donald-trump-walks-out-of-intv-1990-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 01:00:54+00:00

In a 1990 CNN interview reviewed by CNN's KFile, President Donald Trump walked off when reporter Charles Feldman pressed him on questions over the financial stability of his Atlantic City casinos.

## Minnesota reports three Covid-19 outbreaks related to Trump campaign events in September
 - [https://www.cnn.com/2020/10/26/politics/covid-outbreaks-trump-campaign-events/index.html](https://www.cnn.com/2020/10/26/politics/covid-outbreaks-trump-campaign-events/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-27 00:36:49+00:00

The Minnesota Department of Health is reporting three Covid-19 outbreaks related to Trump campaign events held in the state in September.

