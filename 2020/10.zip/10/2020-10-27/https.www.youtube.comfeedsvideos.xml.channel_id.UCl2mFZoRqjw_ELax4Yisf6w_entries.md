# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## I NEED YOUR HELP!
 - [https://www.youtube.com/watch?v=3kGqPjSDp14](https://www.youtube.com/watch?v=3kGqPjSDp14)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-10-28 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
I would highly appreciate if you can help me edit this wiki with content from my videos, and the forum. 

🔵 Wiki: https://wiki2.rossmanngroup.com/index.php?title=Troubleshooting_Guides
🔵Videos: https://www.youtube.com/playlist?list=PLkVbIsAWN2lsHdY7ldAAgtJug50pRNQv0
🔵 Forum posts: https://boards.rossmanngroup.com/forums/macbook-logic-board-repair-questions.15/

