# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## The Most Dangerous Disease in the World
 - [https://www.youtube.com/watch?v=SkJPDXrlP6w](https://www.youtube.com/watch?v=SkJPDXrlP6w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-10-27 00:00:00+00:00

Grab your Primally Pure Deodorant Here - https://primallypure.com/jp

In this video, learn all about the most dangerous disease in the world, intelligence. You’ll understand what you need to do to help slow the spread of this disease. If we all work together and follow the proper social guidelines, we can rid the world of intelligence once and for all.

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

