## RIAA's YouTube-DL Takedown Ticks Off Developers and GitHub's CEO * TorrentFreak
 - [https://torrentfreak.com/riaas-youtube-dl-takedown-ticks-of-developers-and-githubs-ceo-201027/](https://torrentfreak.com/riaas-youtube-dl-takedown-ticks-of-developers-and-githubs-ceo-201027/)
 - RSS feed: https://torrentfreak.com
 - date published: 2020-10-27 20:11:38+00:00

RIAA's YouTube-DL Takedown Ticks Off Developers and GitHub's CEO * TorrentFreak

