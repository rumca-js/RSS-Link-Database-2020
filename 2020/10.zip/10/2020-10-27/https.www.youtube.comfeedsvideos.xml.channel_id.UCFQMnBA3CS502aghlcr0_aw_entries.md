# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Addressing FAKE RUMORS about me...
 - [https://www.youtube.com/watch?v=AbHAOFVgWyY](https://www.youtube.com/watch?v=AbHAOFVgWyY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-10-27 00:00:00+00:00

it's not true! I want to address this serious accusation against me, and nip this one in the bud. 

#hobbit #conspiracy

