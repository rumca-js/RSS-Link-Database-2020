# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Doug Wilson Talks Worshipers Being Arrested/Sex Robots/Postmillennialism
 - [https://www.youtube.com/watch?v=z7sDi95SA5M](https://www.youtube.com/watch?v=z7sDi95SA5M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-10-27 00:00:00+00:00

Today on The Babylon Bee Podcast, Kyle and Ethan talk to Doug Wilson. Doug is a pastor, author of over 90 books, most recently of Ride, Sally, Ride, and the host of Man Rampant. His church got in the news recently for a non-socially distanced, unmasked 'Psalm Sing' in Moscow, Idaho that landed several members of their church in jail. They talk about what happened at the Psalm Sing, why churches are disengaging with the culture and politics, and why a Christian would write a book about sex robots.

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Gain Access to the Exclusive Content and Writing Forum: https://babylonbee.com/plans

The Official Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

## Douglas Wilson on The Babylon Bee Podcast | Preview
 - [https://www.youtube.com/watch?v=8cTFa_Nqy0w](https://www.youtube.com/watch?v=8cTFa_Nqy0w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-10-27 00:00:00+00:00

🎙 Tomorrow Pastor Douglas Wilson joins Kyle and Ethan on The Babylon Bee podcast.

Subscribe today! ▶️ http://bit.ly/TheBeeYouTube

## Facebook Censors The Bee For Making A Monty Python Reference
 - [https://www.youtube.com/watch?v=XYKlJ0RvOH8](https://www.youtube.com/watch?v=XYKlJ0RvOH8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-10-27 00:00:00+00:00

Babylon Bee posted an article titled “Senator Hirono Demands ACB Be Weighed Against A Duck To See If She Is A Witch.” This refers to Monty Python and even after a human noted this, the article was shut down. Come hear the Babylon Bee Writers reflect on the Facebook Censorship. 

See the full show here:
https://youtu.be/IVv0u5QprUE

Subscribe to the Babylon Bee to help keep us stronger than Mark Zuckerburg. 

Hit the Bell to get your daily dose of fake news that you can trust.

