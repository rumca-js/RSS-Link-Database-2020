# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Eels -  two songs at The Current (2018)
 - [https://www.youtube.com/watch?v=XCZhEGhNSRM](https://www.youtube.com/watch?v=XCZhEGhNSRM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-10-28 00:00:00+00:00

This Friday, Oct. 30, Eels will release "Earth to Dora," their thirteenth studio album. In recognition of that, here are two performances from the most recent time Eels visited our studio, which was in 2018. They treated us to a song from their new-at-the-time album, "The Deconstruction," as well as a track from their 1996 debut album, "Beautiful Freak." Of that latter tune, "My Beloved Monster," a lot of people may recognize it from "Shrek."
"It was my tune first," E clarified at the time. "Shrek took it off our first album."

SONGS PERFORMED
0:00 "My Beloved Monster"
1:51 "Today Is The Day"

PERSONNEL
E (Mark Oliver Everett) - vocals, guitar
The Chet (Jeff Lyster) - guitar

CREDITS
Video & Photo: Nate Ryan
Audio: Michael DeMark and Brandon Smith
Production: Derrick Stevens

FIND MORE:
2008 studio session: https://www.thecurrent.org/feature/2008/04/07/the_eels
2010 studio session:
https://www.thecurrent.org/feature/2010/10/03/eels-live
2013 studio session:
https://www.thecurrent.org/feature/2013/02/22/eels
2018 studio session:
https://www.thecurrent.org/feature/2018/06/05/eels-perform-in-the-current-studio

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#eels #eelsband #markolivereverett

## Mountain Goats - two live performances (2011; 2017)
 - [https://www.youtube.com/watch?v=u7T4_2pIIqs](https://www.youtube.com/watch?v=u7T4_2pIIqs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-10-27 00:00:00+00:00

Last Friday, Oct. 23, Mountain Goats — the music project of John Darnielle — released a new album, "Getting Into Knives." With that in mind, we're sharing two cool performances by Mountain Goats: one from 2011 as part of Wits, and one from 2017 recorded live in our studio.

SONGS PERFORMED
0:00 "Dirty Stinking Mouthpiece" (2011)
4:08 "We Do It Different on the West Coast" (2017)

PERSONNEL
John Darnielle – vocals, guitar, piano
John Munson – bass (2011)
Joe Savage – pedal steel (2011)
Richard Medek – drums (2011)
Steve Roehm – vibraphone (2011)
Janey Winterbauer – vocals (2011)
Matt Douglas – saxophone (2017)

CREDITS
Video & Photo: Nate Ryan; Eric Schleicher; Ashley Halbach; Chris Worlow
Audio: Rob Byers; Erik Stromstad; Michael DeMark
Production: Larissa Anderson; Derrick Stevens

FIND MORE:
2011 Wits episode: https://www.witsradio.org/episodes/twelve/index.html
2017 studio session: https://www.thecurrent.org/feature/2017/07/07/john-darnielle-of-mountain-goats-shares-whats-on-his-mind

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#mountaingoats #johndarnielle

