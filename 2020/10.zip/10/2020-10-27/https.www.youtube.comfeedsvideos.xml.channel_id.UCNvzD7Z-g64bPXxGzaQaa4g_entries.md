# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## PS5: 10 Things You NEED TO KNOW
 - [https://www.youtube.com/watch?v=wFKgdPIiRNo](https://www.youtube.com/watch?v=wFKgdPIiRNo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-10-28 00:00:00+00:00

The release of Sony's PlayStation 5 is right around the corner, so we've got you covered on release date info, exclusive games, hardware, and more. Are you getting a PS5? Let us know!
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 10 BIG Upcoming Games That Have Gone SILENT
 - [https://www.youtube.com/watch?v=jhznTvjtZvo](https://www.youtube.com/watch?v=jhznTvjtZvo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-10-27 00:00:00+00:00

Some exciting games have been announced, but we haven't heard much about them lately. Here are some games that have gone quiet in recent months and years.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

