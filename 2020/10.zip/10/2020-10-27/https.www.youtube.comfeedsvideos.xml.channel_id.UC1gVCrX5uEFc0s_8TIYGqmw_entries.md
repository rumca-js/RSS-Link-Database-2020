# Source:Olden days, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC1gVCrX5uEFc0s_8TIYGqmw, language:en-US

## Playing Boules 100 years ago - [ 60 FPS - Color - 4K ] - Old footage restoration with AI
 - [https://www.youtube.com/watch?v=AJ7jg-iNMrA](https://www.youtube.com/watch?v=AJ7jg-iNMrA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1gVCrX5uEFc0s_8TIYGqmw
 - date published: 2020-10-28 00:00:00+00:00

In the South of France, the game evolved into jeu provençal (or boule lyonnaise), in which players rolled their boules or ran three steps before throwing a boule. The game was extremely popular in France in the second half of the 19th century.

This movie was filmed by Louis Lumiere in 1896 at his vacation residence Clos des Plages in La Ciotat. Here you can get more information about this palace (French language).
🔗 https://soutenir.fondation-patrimoine.org/projects/palais-lumiere-a-la-ciotat-fr

🔗 Wikipedia:
https://en.wikipedia.org/wiki/Boules

Original video was processed with Deep Learning algorithms to achieve modern look and quality. Here is the process:

1. Footage stabilization and noise/dust/scratches removal with After Effects and Neat Video ✔️
🔗 https://www.neatvideo.com/?linkID=p7845
2. Restoration with DeepRemaster, removing scratches and film damage ✔️
🔗 https://github.com/satoshiiizuka/siggraphasia2019_remastering
3. Frame interpolation to get smooth look using DAIN method. Result is 60 FPS video ✔️
🔗 https://github.com/baowenbo/DAIN
4. Colorization using DeOldify with NoGAN. Colors are not accurate, only for ambient mood ✔️
🔗 https://github.com/jantic/DeOldify
5. Upscaling using Topaz Video Enhance AI, upscale preserving detail and reducing noise ✔️
🔗 https://topazlabs.com/video-enhance-ai/ref/755/
⭐⭐⭐ 15% DISCOUNT CODE: oldendays15
6. Automation with Python scripts and AWS Thinkbox Deadline as queue manager ✔️
🔗 https://www.awsthinkbox.com/deadline
7. RTX 2070 Super 8GB, 32GB RAM, Ryzen 9 3900X 12-core. Approx 48hrs/10min video processing.

🎵 Intro Music:
Timelapse by boomopera
https://1.envato.market/om6ao

Social Media:
https://www.facebook.com/oldendayschannel
https://www.twitter.com/OldenDaysYT
https://www.instagram.com/oldendayschannel
https://www.pinterest.ca/OldenDaysYT/old-footage-restoration
https://www.patreon.com/oldendays

#deoldify #colorize #upscale #topazlabs #veai #dain #60fps #4k

## Childhood 120 years ago - [ 60 FPS - Color - 4K ] - Old footage restoration with AI
 - [https://www.youtube.com/watch?v=g1T2tHQrBWg](https://www.youtube.com/watch?v=g1T2tHQrBWg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1gVCrX5uEFc0s_8TIYGqmw
 - date published: 2020-10-27 00:00:00+00:00

Lumiere used his camera as a tool for preserving memories of his loved ones. Most children at the beginning of this movie are his closest family.
Kids at the beach catching shrimps, the scene was shot by Alexandre Promio, one of his best camera operators, at the beach in England in 1896.
Last scene is a baby strollers parade to the nursery in Paris 1897. This movie reminds us of the diagonal perspective when the train arrives at the station, this time the locomotive is the strollers perfectly aligned. Film finishes with a funny ending of a baby leaving nursery.  

Original video was processed with Deep Learning algorithms to achieve modern look and quality. Here is the process:

1. Footage stabilization and noise/dust/scratches removal with After Effects and Neat Video ✔️
🔗 https://www.neatvideo.com/?linkID=p7845
2. Restoration with DeepRemaster, removing scratches and film damage ✔️
🔗 https://github.com/satoshiiizuka/siggraphasia2019_remastering
3. Frame interpolation to get smooth look using DAIN method. Result is 60 FPS video ✔️
🔗 https://github.com/baowenbo/DAIN
4. Colorization using DeOldify with NoGAN. Colors are not accurate, only for ambient mood ✔️
🔗 https://github.com/jantic/DeOldify
5. Upscaling using Topaz Video Enhance AI, upscale preserving detail and reducing noise ✔️
🔗 https://topazlabs.com/video-enhance-ai/ref/755/
⭐⭐⭐ 15% DISCOUNT CODE: oldendays15
6. Automation with Python scripts and AWS Thinkbox Deadline as queue manager ✔️
🔗 https://www.awsthinkbox.com/deadline
7. RTX 2070 Super 8GB, 32GB RAM, Ryzen 9 3900X 12-core. Approx 48hrs/10min video processing.

🎵 Intro Music:
Timelapse by boomopera
https://1.envato.market/om6ao

Social Media:
https://www.facebook.com/oldendayschannel
https://www.twitter.com/OldenDaysYT
https://www.instagram.com/oldendayschannel
https://www.pinterest.ca/OldenDaysYT/old-footage-restoration
https://www.patreon.com/oldendays

#deoldify #colorize #upscale #topazlabs #veai #dain #60fps #4k

