## Introducing homo augmentus - Nokia Bell Labs
 - [https://www.bell-labs.com/institute/blog/introducing-homo-augmentus/](https://www.bell-labs.com/institute/blog/introducing-homo-augmentus/)
 - RSS feed: https://www.bell-labs.com
 - date published: 2020-10-27 10:07:50+00:00

Introducing homo augmentus - Nokia Bell Labs

