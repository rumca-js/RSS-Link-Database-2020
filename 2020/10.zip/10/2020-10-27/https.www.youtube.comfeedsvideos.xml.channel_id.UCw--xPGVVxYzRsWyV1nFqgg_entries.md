# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Steven Erikson Talks Building Malazan, FaceBook Post, & MORE!
 - [https://www.youtube.com/watch?v=jtwA_ja3gwI](https://www.youtube.com/watch?v=jtwA_ja3gwI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-10-28 00:00:00+00:00

My interview with Steven Erikson the author of the Malazan series! 

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

0:00 Intro
00:45 FaceBook Post
09:30 Abercrombie Comment
10:46 Developing Malazan
13:30 Malazan’s lack of notes
14:47 Cocreating Malazan
20:05 Malazan’s Magic
25:17 Joy in writing
26:56 Erikson’s Prose
29:43 Post Interview chat

## Bethesda SABOTAGE Lawsuit⚖️ Audible EXPOSED Refund Issue💰 Dragonlance Lawsuit🐉 -FANTASY NEWS
 - [https://www.youtube.com/watch?v=vzSPeVC3CDI](https://www.youtube.com/watch?v=vzSPeVC3CDI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-10-27 00:00:00+00:00

Fantasy News is getting into the legal things today… OH BOY! 
Checkout Campfire Blaze Here: https://www.campfiretechnology.com/blaze/?utm_source=youtube&utm_medium=video&utm_campaign=GreeneQ420

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

--
News time stamps
0:00 Intro
0:51 Joe Abercrombie Cover Copy
1:19 British Fantasy Awards
1:31 Gainman Netflix Sandman comment 
3:43 Audible Issue
8:26 Emilia Clarke Thrones Anger
9:36 Bethesda Lawsuit Update
12:54 Moon Knight Casting
13:08 Dragonlance Lawsuit
15:54 Mercy Sparx
16:10 Battlestar Galactica Movie
16:37 Netflix Anime Plan
17:35 Evil Dead Update
17:50 Wheel Of Time Leaks
--

Sources:
Joe Abercrombie Cover Copy : https://joeabercrombie.com/the-wisdom-of-crowds-cover-copy/ 
Fantasy Awards : http://www.britishfantasysociety.org/awards/british-fantasy-awards-2020-shortlists/
Gaiman Netflix Sandman comment : https://twitter.com/neilhimself/status/1320402264461377536
Audible Issue : https://www.reddit.com/r/Fantasy/comments/jgq0v1/attack_of_the_audible_returns/ 
Emilia Clarke Thrones Reveal : https://www.indiewire.com/2020/10/emilia-clarke-fought-thrones-creators-daenerys-too-cold-1234594404/ 
Bethesda Lawsuit Update : https://www.pcgamer.com/bethesda-intentionally-sabotaged-rune-2-to-protect-the-elder-scrolls-lawsuit-update-claims/ 
Moon Knight Casting : https://deadline.com/2020/10/moon-knight-oscar-isaac-marvel-1234602805/
Dragonlance Lawsuit : https://www.youtube.com/watch?v=a_MzZdltbbE 
Wizard of the Coast Lawsuit Article: https://www.polygon.com/2020/10/19/21523673/dragonlance-authors-weis-hickman-sue-wizards-of-the-coast-dungeons-and-dragons 
Mery Sparx : https://deadline.com/2020/10/mgm-comic-book-mercy-sparx-movie-she-demon-from-hell-existential-crisis-1234600385/ 
Battlestar Galactica Movie : https://variety.com/2020/film/news/battlestar-galactica-movie-simon-kinberg-writer-producer-1234813660/ 
Netflix Anime Plan : https://deadline.com/2020/10/netflix-plans-anime-content-strikes-deals-with-4-producers-japan-korea-1234602414/ 
Evil Dead Update : https://bloody-disgusting.com/movie/3638230/bruce-campbell-says-evil-dead-rise-will-put-female-heroine-urban-deadites/
Wheel Of Time Leaks : https://www.reddit.com/r/WoT/comments/jhhkqf/fal_dara_set_photos/

