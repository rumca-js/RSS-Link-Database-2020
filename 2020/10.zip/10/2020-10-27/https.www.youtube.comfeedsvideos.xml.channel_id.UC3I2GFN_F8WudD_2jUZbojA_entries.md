# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Oddisee - Go To Mars (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=-3rlVtsVSTg](https://www.youtube.com/watch?v=-3rlVtsVSTg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-28 00:00:00+00:00

http://KEXP.ORG presents Oddisee performing live at Sign of The Wagon in York, PA. Recorded exclusively for KEXP.

Lead vocal - Oddisee
Keys & back up vocals - Ralph Real
Bass - Dennis Turner
Drums & back up vocals - Jon Laine
Guitar - Saint Ezekiel
Filmed & Edited - Lawrence Miner
Audio mixed - Delph

http://oddisee.co
http://kexp.org

## Oddisee - I Thought You Were Fate (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=OtIcxPH9tCc](https://www.youtube.com/watch?v=OtIcxPH9tCc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-28 00:00:00+00:00

http://KEXP.ORG presents Oddisee performing live at Sign of The Wagon in York, PA. Recorded exclusively for KEXP.

Lead vocal - Oddisee
Keys & back up vocals - Ralph Real
Bass - Dennis Turner
Drums & back up vocals - Jon Laine
Guitar - Saint Ezekiel
Filmed & Edited - Lawrence Miner
Audio mixed - Delph

http://oddisee.co
http://kexp.org

## Oddisee - No Skips (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=SLZrKGLSKqo](https://www.youtube.com/watch?v=SLZrKGLSKqo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-28 00:00:00+00:00

http://KEXP.ORG presents Oddisee performing live at Sign of The Wagon in York, PA. Recorded exclusively for KEXP.

Lead vocal - Oddisee
Keys & back up vocals - Ralph Real
Bass - Dennis Turner
Drums & back up vocals - Jon Laine
Guitar - Saint Ezekiel
Filmed & Edited - Lawrence Miner
Audio mixed - Delph

http://oddisee.co
http://kexp.org

## Oddisee - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=L2qePpYRnNw](https://www.youtube.com/watch?v=L2qePpYRnNw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-28 00:00:00+00:00

http://KEXP.ORG presents Oddisee sharing a live performance recorded exclusively for KEXP and talking to Gabriel Teodros. Recorded October 21, 2020.

Songs:
The Cure
I Thought You Were Fate
Still Strange
No Skips
Go To Mars

Lead vocal - Oddisee
Keys & back up vocals - Ralph Real
Bass - Dennis Turner
Drums & back up vocals - Jon Laine
Guitar - Saint Ezekiel
Filmed & Edited - Lawrence Miner
Audio mixed - Delph
Filmed & recorded at - Sign of The Wagon in York, PA

All songs from Oddisee’s Odd Cure available on Outer Note Label

http://oddisee.co
http://kexp.org

## Oddisee - Still Strange (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=xMRBjOtYZ94](https://www.youtube.com/watch?v=xMRBjOtYZ94)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-28 00:00:00+00:00

http://KEXP.ORG presents Oddisee performing live at Sign of The Wagon in York, PA. Recorded exclusively for KEXP.

Lead vocal - Oddisee
Keys & back up vocals - Ralph Real
Bass - Dennis Turner
Drums & back up vocals - Jon Laine
Guitar - Saint Ezekiel
Filmed & Edited - Lawrence Miner
Audio mixed - Delph

http://oddisee.co
http://kexp.org

## Oddisee - The Cure (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=nZt3_j_wdp8](https://www.youtube.com/watch?v=nZt3_j_wdp8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-28 00:00:00+00:00

http://KEXP.ORG presents Oddisee performing live at Sign of The Wagon in York, PA. Recorded exclusively for KEXP.

Lead vocal - Oddisee
Keys & back up vocals - Ralph Real
Bass - Dennis Turner
Drums & back up vocals - Jon Laine
Guitar - Saint Ezekiel
Filmed & Edited - Lawrence Miner
Audio mixed - Delph

http://oddisee.co
http://kexp.org

