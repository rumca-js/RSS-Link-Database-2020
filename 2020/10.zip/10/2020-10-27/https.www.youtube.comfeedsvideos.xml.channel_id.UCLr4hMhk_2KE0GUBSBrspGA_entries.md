# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Ile razy trzeba zrzucić iPhone'a 12 z czterech metrów? iPhone 12 i Samsung s20
 - [https://www.youtube.com/watch?v=CWPTokzlIv0](https://www.youtube.com/watch?v=CWPTokzlIv0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-10-27 00:00:00+00:00

Odpowiedź znajdziecie w tym filmie. Jest też informacja bonusowa - ile razy trzeba zrzucić Samsunga s20 z 4 metrów. TLDW: wiele ;)
iPhone 12 na Allegro - https://bit.ly/2HD7SqG

Moje sociale:
Insta: http://bit.ly/InstaKlawiatur 
Twitter: http://bit.ly/TTKlawitera
FB: http://bit.ly/FBKlawiatur

