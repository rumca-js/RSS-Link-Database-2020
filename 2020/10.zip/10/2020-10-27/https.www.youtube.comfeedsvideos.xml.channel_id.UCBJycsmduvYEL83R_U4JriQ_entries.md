# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## PlayStation 5 Unboxing & Accessories!
 - [https://www.youtube.com/watch?v=QtMzV73NAgk](https://www.youtube.com/watch?v=QtMzV73NAgk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-10-27 00:00:00+00:00

Sony PS5 is has arrived! This is the unboxing experience. #hype

That shirt! http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: http://youtube.com/20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Console provided by Sony for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

