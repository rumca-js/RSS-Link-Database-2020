# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Horrifyingly Average - The Haunting of Bly Manor
 - [https://www.youtube.com/watch?v=2lPs9QjUUFQ](https://www.youtube.com/watch?v=2lPs9QjUUFQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-10-27 00:00:00+00:00

So I watched The Haunting of Bly Manor and... it wasn't what I'd hoped for. Join me as I break down the spiritual sequel to The Haunting of Hill House.

