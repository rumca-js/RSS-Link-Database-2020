# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## The Oculus Quest 2 has been HACKED
 - [https://www.youtube.com/watch?v=XBTqn5vyb-4](https://www.youtube.com/watch?v=XBTqn5vyb-4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-10-27 00:00:00+00:00

The Oculus Quest 2 has officially been rooted. This is probably some of the most exciting news we've seen regarding the Quest 2 and the VR industry lately. Also I will be covering the DecaGear One, a new VR headset from a seemingly unknown company that is promising some of the best, industry leading specs and features for a price that is lower than all of its competition. This is probably one of the most exciting, important weeks of news we have had all year, and Im here for it. I will also be holding a live interview with DecaGear later this week at Twitch.tv/Thrilluwu

Here are my links:
2nd Channel and Meetup video:
https://www.youtube.com/watch?v=pZO_KOqt46Q
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill

Sources:
https://www.tweaktown.com/news/75874/decagear-1-is-4k-vr-headset-with-face-and-hip-tracking-for-449/index.html
https://www.roadtovr.com/decagear-background-roadmap-or-kuntzman/
https://twitter.com/OculusSupport/status/1320439489278476288
https://twitter.com/CixLiv/status/1320068735730733056?ref_src=twsrc%5Etfw%7Ctwcamp%5Etweetembed%7Ctwterm%5E1320068735730733056%7Ctwgr%5Eshare_3%2Ccontainerclick_1&ref_url=https%3A%2F%2Fwww.engadget.com%2Ffacebook-bans-oculus-owners-with-multiple-headsets-191421857.html
https://www.techradar.com/news/oculus-quest-vr-headsets-are-being-held-to-ransom-by-facebook-and-your-vr-games-are-at-risk
https://www.popsci.com/story/technology/vr-headset-display-tech-solar-panels/
https://www.engadget.com/samsung-stanford-10000-ppi-oled-display-200949600.html
https://community.openmr.ai/t/sde-and-ppi-pimax-vs-valve-index-vs-others/20032
https://www.deca.net/decagear/order/
https://www.gamesindustry.biz/articles/2019-11-28-phil-spencer-nobodys-asking-for-vr-on-xbox
https://www.reddit.com/r/VR_memes/
https://www.facebook.com/terms.php

