# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## These Voracious Ants Are Their Own Mobile Home
 - [https://www.youtube.com/watch?v=20N0yUUOavc](https://www.youtube.com/watch?v=20N0yUUOavc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2020-10-28 00:00:00+00:00

Army ants move around a lot, which means they can't build a nest like other ants do. So, to build their shelters, they came up with another, way weirder solution... 

Go to http://Brilliant.org/SciShow to try their Introduction to Neural Networks course. The first 200 subscribers get 20% off an annual Premium subscription. 

Hosted by: Rose Bear Don't Walk

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Bd_Tmprd, Harrison Mills, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Sam Buck, Christopher R Boucher, Eric Jensen, Lehel Kovacs, Adam Brainard, Greg, Ash, Sam Lutfi, Piya Shedden, KatieMarie Magnone, Scott Satovsky Jr, Charles Southerland, charles george, Alex Hackman, Chris Peters, Kevin Bealer
----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:

https://pubmed.ncbi.nlm.nih.gov/12750466/
https://pubmed.ncbi.nlm.nih.gov/30460107/
https://doi.org/10.1007/s00040-002-8286-y
https://doi.org/10.1016/S0065-2806(06)33003-2
https://doi.org/10.1111/j.1365-3032.1989.tb01109.x
https://doi.org/10.2307/1948466 
https://doi.org/10.1101/134064
https://doi.org/10.2307/1931686 
https://expeditions.fieldmuseum.org/army-ants

## Technicolor Dream Fish: How Tilefish Flash
 - [https://www.youtube.com/watch?v=t0B4KHsCiUs](https://www.youtube.com/watch?v=t0B4KHsCiUs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2020-10-27 00:00:00+00:00

Lots of animals can change the color of their skin, but there's nothing quite like the chameleon sand tilefish, which can change its appearance in an instant and flash the colors of the rainbow.

Hosted by: Rose Bear Don't Walk

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Bd_Tmprd, Harrison Mills, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Sam Buck, Christopher R Boucher, Eric Jensen, Lehel Kovacs, Adam Brainard, Greg, Ash, Sam Lutfi, Piya Shedden, KatieMarie Magnone, Scott Satovsky Jr, Charles Southerland, charles george, Alex Hackman, Chris Peters, Kevin Bealer
----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://onlinelibrary.wiley.com/doi/epdf/10.1111/pcmr.12581
https://onlinelibrary.wiley.com/doi/abs/10.1111/jai.14062?af=R
https://www.nature.com/scitable/topicpage/cephalopod-camouflage-cells-and-organs-of-the-144048968/
https://onlinelibrary.wiley.com/doi/pdf/10.1111/pcmr.12040
https://journals.plos.org/plosbiology/article?id=10.1371/journal.pbio.0060025 
http://repositorio.ispa.pt/bitstream/10400.12/1483/1/AE%204%20109-111.pdf
https://www.sciencedirect.com/science/article/abs/pii/S0018506X08001682?via%3Dihub
https://www.ncbi.nlm.nih.gov/books/NBK21521/

Images:
https://onlinelibrary.wiley.com/doi/abs/10.1111/pcmr.12581
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5804272/
https://www.youtube.com/watch?v=ZkbrL4f6hVs&ab_channel=SteveWinkworth
https://www.eurekalert.org/multimedia/pub/46942.php?from=219852
https://commons.wikimedia.org/wiki/File:Guppy_pho_0048.jpg
https://www.istockphoto.com/photo/chemical-formula-structural-formula-and-3d-ball-and-stick-model-of-norepinephrine-gm1279708107-378227658
https://www.istockphoto.com/photo/panther-chameleon-gm594444402-101907299
https://www.istockphoto.com/photo/palawan-el-nido-entalula-island-beach-philippines-gm985553596-267375526
https://www.istockphoto.com/photo/holographic-foil-background-cute-multi-colored-pearl-bubble-beads-abstract-reptile-gm1125389932-295824626

