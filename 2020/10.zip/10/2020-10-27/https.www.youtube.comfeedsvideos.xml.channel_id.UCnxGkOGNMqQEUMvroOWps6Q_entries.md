# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Glenn Greenwald Reflects on Breaking the Edward Snowden Story
 - [https://www.youtube.com/watch?v=eQboG1Eeb0g](https://www.youtube.com/watch?v=eQboG1Eeb0g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-10-28 00:00:00+00:00

#1556 w/Glenn Greenwald:
https://open.spotify.com/episode/6ryXHBRMkkIlAK2vCtAE2v

## Glenn Greenwald on How Media's Trump Fear Mongering is Reminiscent of Bush Era Tactics
 - [https://www.youtube.com/watch?v=qRDrgp5otfE](https://www.youtube.com/watch?v=qRDrgp5otfE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-10-28 00:00:00+00:00

#1556 w/Glenn Greenwald:
https://open.spotify.com/episode/6ryXHBRMkkIlAK2vCtAE2v

## Glenn Greenwald on Hunter Biden's Laptop, Lack of News Coverage
 - [https://www.youtube.com/watch?v=vk1rSvnvXoY](https://www.youtube.com/watch?v=vk1rSvnvXoY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-10-28 00:00:00+00:00

#1556 w/Glenn Greenwald:
https://open.spotify.com/episode/6ryXHBRMkkIlAK2vCtAE2v

## Alex Jones on Bohemian Grove, Skull & Bones, Epstein
 - [https://www.youtube.com/watch?v=QjTkEyM_aTc](https://www.youtube.com/watch?v=QjTkEyM_aTc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-10-27 00:00:00+00:00

#1555 w/Alex Jones and Tim Dillon:
https://open.spotify.com/episode/0Ts4ONY3v7HvDw1s3bPpzm

## Alex Jones on Hunter Biden's Laptop, Trump
 - [https://www.youtube.com/watch?v=7Kp_uT_7NjM](https://www.youtube.com/watch?v=7Kp_uT_7NjM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-10-27 00:00:00+00:00

#1555 w/Alex Jones and Tim Dillon:
https://open.spotify.com/episode/0Ts4ONY3v7HvDw1s3bPpzm

## Alex Jones' Take on Covid Lockdowns, Operation Lockstep
 - [https://www.youtube.com/watch?v=E9tZ60BMqlo](https://www.youtube.com/watch?v=E9tZ60BMqlo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-10-27 00:00:00+00:00

#1555 w/Alex Jones and Tim Dillon:
https://open.spotify.com/episode/0Ts4ONY3v7HvDw1s3bPpzm

