# Source:Vlog Casha, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg, language:pl-PL

## Kars - Rosyjskie miasto w Turcji?
 - [https://www.youtube.com/watch?v=hnsS6-1yitw](https://www.youtube.com/watch?v=hnsS6-1yitw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg
 - date published: 2020-10-17 00:00:00+00:00

🗺️ Turcja 2020 #8. Po kilku dniach spędzonych z dziewczynami z Iranu nadszedł czas, aby ruszyć dalej. Dziś luźna relacja z dnia w miejscowości Kars.

❗ Zostań Patronem kanału! 
https://patronite.pl/vlogcasha

Vlogi z Turcji (2019-2020): https://bit.ly/31VPCR3
Vlogi z Kolumbii: https://bit.ly/36tqlhH
🌏 Vlogi z Azji Płd-Wsch: https://bit.ly/2wrM9t2
🇦🇺 Vlogi z Australii: https://bit.ly/2OJWYOy
🇺🇸 Vlogi z życia i podróży w USA: https://bit.ly/2ya73NV
🚙Vlogi z autostopu 2018: https://bit.ly/2NbHzos

▸ Instagram: https://www.instagram.com/vlogcasha
▸ Facebook: https://www.facebook.com/vlogcasha/
#PodróżeCasha #CashWTurcji #Turcja

