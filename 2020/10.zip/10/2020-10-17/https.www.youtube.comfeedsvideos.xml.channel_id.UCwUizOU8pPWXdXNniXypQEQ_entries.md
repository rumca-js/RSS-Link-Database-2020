# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## How To Change Someone’s Mind About the Election
 - [https://www.youtube.com/watch?v=brQcuncO4wc](https://www.youtube.com/watch?v=brQcuncO4wc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-10-17 00:00:00+00:00

Get your Awakened Shirt Here - https://awakenwithjp.com/shop
Check out Brent's Channel - https://www.youtube.com/c/brentpella/

In this video you’ll learn how to change someone’s mind about the election 100% of the time. It’s super easy to change peoples minds about politics.

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

