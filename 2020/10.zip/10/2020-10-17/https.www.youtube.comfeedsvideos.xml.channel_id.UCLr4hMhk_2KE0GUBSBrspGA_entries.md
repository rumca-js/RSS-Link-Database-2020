# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week: Założę sobie radio! Radio na Spotify, HomePod Mini, autonomiczne samochody
 - [https://www.youtube.com/watch?v=YUOjZz-TUxU](https://www.youtube.com/watch?v=YUOjZz-TUxU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-10-18 00:00:00+00:00

Póki co jednak mam dla Was technologiczne podsumowanie tygodnia. 

Moje sociale
Insta: http://bit.ly/InstaKlawiatur 
Twitter: http://bit.ly/TTKlawitera
FB: http://bit.ly/FBKlawiatur

Swój głos i paluchy dołożył @siematupalmowski 

Źródła: 
Najlepsze podsumowanie konferencji apple: https://youtu.be/X7SWLpWqgxs
Gorsze, bo moje podsumowanie: https://youtu.be/qeX2kdYJ7Ro
HomePod Mini: https://bit.ly/3o2SkNL
Załóż sobie radio na Spotify: https://tcrn.ch/3lVH6ss
Carl Pei odchodzi z OnePlusa: https://cnet.co/31j2mQS
Autonomiczne samochody wracają: https://bit.ly/3m1vnIK
Ukradli nam lampkę: https://youtu.be/7-YglcRipKE

