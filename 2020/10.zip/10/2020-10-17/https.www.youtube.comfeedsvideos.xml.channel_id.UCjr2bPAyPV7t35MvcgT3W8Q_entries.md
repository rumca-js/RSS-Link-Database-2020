# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## Location Tracking Is Actually Unstoppable
 - [https://www.youtube.com/watch?v=GMIY4J8jAUc](https://www.youtube.com/watch?v=GMIY4J8jAUc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2020-10-18 00:00:00+00:00

Your phone (Android or iPhone) is tracking your location even if you disable Location Services, turn on airplane mode, and disable Bluetooth. Learn how to stop it once and for all. 
Join my channel https://www.youtube.com/channel/UCjr2bPAyPV7t35MvcgT3W8Q/join
Support me through Patreon: https://www.patreon.com/thehatedone 

- or donate anonymously:

Monero: 84DYxU8rPzQ88SxQqBF6VBNfPU9c5sjDXfTC1wXkgzWJfVMQ9zjAULL6rd11ASRGpxD1w6jQrMtqAGkkqiid5ef7QDroTPp

Bitcoin: 1HkDxXAVDFhBHSyRjam5WW5uoY88sxn5qz

Sources:

GPS
https://www.nytimes.com/interactive/2018/12/10/business/location-data-privacy-apps.html
https://tracki.com/pages/how-gps-tracker-works-and-cell-phone-tower-triangulation-accuracy

Cell tower triangulation 
https://www.101computing.net/cell-phone-trilateration-algorithm/
https://tracki.com/pages/how-gps-tracker-works-and-cell-phone-tower-triangulation-accuracy
https://www.ghacks.net/2018/08/13/google-may-track-your-location-even-if-you-disable-location-tracking/
https://apnews.com/828aefab64d4411bac257a07c1af0ecb/AP-Exclusive:-Google-tracks-your-movements,-like-it-or-not 
https://qz.com/1131515/google-collects-android-users-locations-even-when-location-services-are-disabled/

WiFi positioning and radio triangulation 
https://transition.fcc.gov/pshs/911/Apps%20Wrkshp%202015/911_Help_SMS_WhitePaper0515.pdf

Bluetooth beacons and surveillance
https://www.privacyinternational.org/explainer/3536/bluetooth-tracking-and-covid-19-tech-primer
https://medium.com/supplyframe-hardware/bluetooth-indoor-positioning-and-asset-tracking-solutions-8c78cae0a03
https://www.nytimes.com/interactive/2019/06/14/opinion/bluetooth-wireless-tracking-privacy.html
https://www.wsj.com/articles/coronavirus-tracking-apps-raise-questions-about-bluetooth-security-11588239000


Ultrasonic cross-device tracking 
https://arstechnica.com/tech-policy/2015/11/beware-of-ads-that-use-inaudible-sound-to-link-your-phone-tv-tablet-and-pc/
https://www.zdnet.com/article/hundreds-of-apps-are-using-ultrasonic-sounds-to-track-your-ad-habits/
https://techcrunch.com/2014/07/24/silverpush-audio-beacons/
https://www.campaignlive.com/article/retailers-shoppers-resist-apples-ibeacon-signals/1363907
https://arstechnica.com/gadgets/2015/07/meet-googles-eddystone-a-flexible-open-source-ibeacon-fighter/


Follow me:
https://twitter.com/The_HatedOne_
https://www.bitchute.com/TheHatedOne/
https://www.reddit.com/r/thehatedone/
https://www.minds.com/The_HatedOne

The footage and images featured in the video were for critical analysis, commentary and parody, which are protected under the Fair Use laws of the United States Copyright act of 1976.

