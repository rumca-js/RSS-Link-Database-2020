# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Babylon Bee Reads Hate Mail After Being Featured in the New York Times
 - [https://www.youtube.com/watch?v=iVOLg4WQ6Uo](https://www.youtube.com/watch?v=iVOLg4WQ6Uo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-10-18 00:00:00+00:00

The Babylon Bee’s very own Kyle Mann was featured in a New York Times article. You can read the full interview below. Come see the most hateful responses to the New York Times posting the interview with Kyle. 

New York Times Article:
https://www.nytimes.com/2020/10/11/us/politics/babylon-bee-conservative-satire.html

See the full show here:
https://www.youtube.com/watch?v=MZ_rQ_y-LP4

Subscribe to the Babylon Bee to help us keep Trump informed 
Hit the Bell to get your daily dose of fake news that you can trust.

## Amy Barrett's Crucifix Causes Democrats to Hiss in Terror
 - [https://www.youtube.com/watch?v=L_hVMwCcC1w](https://www.youtube.com/watch?v=L_hVMwCcC1w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-10-17 00:00:00+00:00

The Babylon News Network presents must-see footage of a scene in the U.S. Senate where Amy Coney Barrett put her rosary and crucifix to work on some possessed senators.

## Dictionary Definitions Are Getting Memory-Holed
 - [https://www.youtube.com/watch?v=0JpkejG5W7I](https://www.youtube.com/watch?v=0JpkejG5W7I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-10-17 00:00:00+00:00

Kyle and Ethan talk about the absurdity of the Liberals changing the definition of sexual preference after it was asked during the hearings of Amy Coney Barett. They discuss how this world is becoming more and more like the 1984 novel and how they are hiding in plain sight. 

See the full show here:
https://www.youtube.com/watch?v=MZ_rQ_y-LP4

Subscribe to the Babylon Bee to let us know you still want the truest satire out there. 

Hit the Bell to get your daily dose of fake news that you can trust.

