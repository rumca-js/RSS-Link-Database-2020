# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## How to Claim "Free" Money the Government Owes You! (No Joke)
 - [https://www.youtube.com/watch?v=jgQ8ufkenIQ](https://www.youtube.com/watch?v=jgQ8ufkenIQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2020-10-17 00:00:00+00:00

• NEW CHANNEL ▶️ Actual School: What They Should've Taught You: https://www.youtube.com/ActualSchool
• The new channel will have life tips, skills, plus investing & Finance

