# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Think You Need Therapy? First Watch This... | Russell Brand
 - [https://www.youtube.com/watch?v=1nZ6e_xdGfI](https://www.youtube.com/watch?v=1nZ6e_xdGfI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-10-18 00:00:00+00:00

Therapy has been a consistent and important element in my life. I have had various types of therapist, mentors and group therapy over time. If you've ever wondered what going to a therapist is really like - hopefully this might help. I feel like most people would benefit from going to a therapist at some point in their own life - in order to gain objective perspectives on the various issues and relationships in your life.

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

