# Source:SciFun, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCWTA5Yd0rAkQt5-9etIFoBA, language:pl-PL

## Nogi stonogi i kryształy kwasu
 - [https://www.youtube.com/watch?v=NYq9SPm3zRo](https://www.youtube.com/watch?v=NYq9SPm3zRo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCWTA5Yd0rAkQt5-9etIFoBA
 - date published: 2020-10-18 00:00:00+00:00

Kryształy, krystalizacja, stonogi.
Link do książki: http://bit.ly/jak-dlugo-trwa-teraz
https://instagram.com/darekhoffmann/

