# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Aquanox Deep Descent | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=1HinKgm9VP0](https://www.youtube.com/watch?v=1HinKgm9VP0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-10-18 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Will Cruz reviews Aquanox Deep Descent, developed by Digital Arrow.

Aquanox Deep Descent on Steam: https://store.steampowered.com/app/254370/Aquanox_Deep_Descent/

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Cyberpunk 2077, Media Gatekeeping & Next-Gen Excitement | The Escapist Show
 - [https://www.youtube.com/watch?v=fq3ZHfbPlcQ](https://www.youtube.com/watch?v=fq3ZHfbPlcQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-10-18 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

This week on The Escapist Show, we talk a little bit more about Spelunky 2 and Star Wars Squadrons, plus new details on the Cyberpunk 2077 crunch situation and even more social media drama. We end the episode on some next-gen excitement, and promise that next week we'll be getting back to the fun stuff.

Timestamps
1:39 - 4:41 - Spelunky 2
4:42 - 7:33 - Star Wars Squadrons
7:34 - 9:32 - Infliction
9:33 - 18:47 - Cyberpunk crunch and media gatekeeping
18:48 - 27:47 - Next-gen excitement


Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Onee Chanbara ORIGIN | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=7oWNy9DkV90](https://www.youtube.com/watch?v=7oWNy9DkV90)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-10-17 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Jesse Galena reviews Onee Chanbara ORIGIN, developed by Tamsoft.

Onee Chanbara ORIGIN on Steam: https://store.steampowered.com/app/1232460/Onee_Chanbara_ORIGIN/

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## The Excellence of The Haunting of Bly Manor | The Escapist Movie Podcast
 - [https://www.youtube.com/watch?v=DNxORN1Hywk](https://www.youtube.com/watch?v=DNxORN1Hywk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-10-17 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Timestamps
1:32 - 22:12 - Disney Does Streaming
22:13 - 39:53 - All the Spider-men
39:54 - 1:05:23 - The Haunting of Bly Manor
1:05:24 - 1:10:02 - The Haunting of Bly Manor Spoilers

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

