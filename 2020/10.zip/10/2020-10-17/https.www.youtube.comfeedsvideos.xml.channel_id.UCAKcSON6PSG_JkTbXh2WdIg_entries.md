# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Bob Mould - three songs for The Current (2013; 2014; 2019)
 - [https://www.youtube.com/watch?v=lblJaz1CcGo](https://www.youtube.com/watch?v=lblJaz1CcGo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-10-17 00:00:00+00:00

Happy birthday to Bob Mould! Born this day (October 16) in Malone, N.Y., Bob Mould has been a longtime friend of The Current. In celebration of his birthday, here are three cool performances Bob Mould has done for The Current through the years.

SONGS PERFORMED
0:00 "The Descent" (Rock the Garden 2013)
3:45 "I Don't Know You Anymore" (2014)
6:39 "Sunny Love Song" (2019)

PERSONNEL
Bob Mould – guitar and vocals
Jason Narducy – bass
Jon Wurster – drums

CREDITS
Video & Photo: Dan Huiting; Leah Garaas; Nate Ryan
Audio: Michael DeMark; Wesley Berger
Production: Derrick Stevens; Jade; Anna Weggel

FIND MORE:
2008 studio session:
https://www.thecurrent.org/feature/2008/02/06/bob_mould
2009 studio session:
https://www.thecurrent.org/feature/2009/03/31/bob_mould
2011 performance in the Forum at MPR:
https://www.thecurrent.org/feature/2011/06/15/bob-mould-live
2014 studio session:
https://www.thecurrent.org/feature/2014/06/13/bob-mould-performs-in-the-current-studio
2014 Guitar Collection interview:
https://www.thecurrent.org/feature/2014/06/18/the-current-s-guitar-collection-bob-mould
2017 MicroShow at the Turf Club:
https://www.thecurrent.org/feature/2017/04/17/bob-mould-performs-microshow-at-the-turf-club-in-st-paul
2019 studio session:
https://www.thecurrent.org/feature/2019/03/29/bob-mould-performs-on-oake--riley-in-the-morning
2020 interview with Andrea Swensson:
https://www.thecurrent.org/feature/2020/06/05/bob-mould-talks-about-american-crisis

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#bobmould #bobmouldmusic

