# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## DON'T buy AirPods… yet
 - [https://www.youtube.com/watch?v=ThhP4ivBVMo](https://www.youtube.com/watch?v=ThhP4ivBVMo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-10-18 00:00:00+00:00

Go to https://privacy.com/linus ​to get $5 off your first purchase!

SmartDeploy: Claim your free IT software (worth $882!) at https://smartdeploy.com/linus

Think Airpods are the only option? THINK AGAIN. Here are some Airpod alternatives you should check out before you give Apple your money.

Mic Audio Comparison: https://www.youtube.com/watch?v=Y3xLq78oJmI

Buy Apple Airpods Pro
On Amazon (PAID LINK): https://geni.us/IJbL
On Newegg (PAID LINK): https://geni.us/xJLq
On B&H (PAID LINK): https://geni.us/HorxT4
On Best Buy (PAID LINK): https://geni.us/0bE9B

Buy Samsung Galaxy Buds Live
On Samsung (PAID LINK): https://shop-links.co/1721097186511946959
On Amazon (PAID LINK): https://geni.us/ggQz
On Newegg (PAID LINK): https://geni.us/mdXbo9w
On B&H (PAID LINK): https://geni.us/9AOe
On Best Buy (PAID LINK): https://geni.us/j5Ho0

Buy Samsung Galaxy Buds+
On Samsung (PAID LINK): https://shop-links.co/1721097266426629154
On Amazon (PAID LINK): https://geni.us/nvmxh6
On Newegg (PAID LINK): https://geni.us/5NnxoU
On B&H (PAID LINK): https://geni.us/eB2bLn

Buy Google Pixel Buds 2
On Newegg (PAID LINK): https://geni.us/D3qQy
On B&H (PAID LINK): https://geni.us/Ov9u6xR
On Best Buy (PAID LINK): https://geni.us/dZf4Lo3

Buy LG TONE Free
On Amazon (PAID LINK): https://geni.us/4LkMc
On Newegg (PAID LINK): https://geni.us/0EVFx2
On B&H (PAID LINK): https://geni.us/BvoQ9
On LG: https://bit.ly/LinusTechTips_LGTONEFree_FN6
On Best Buy (PAID LINK): https://geni.us/NFzqPF

Buy OnePlus Buds
On Amazon (PAID LINK): https://geni.us/gzmkBa
On Newegg (PAID LINK): https://geni.us/kSXR
On B&H (PAID LINK): https://geni.us/qd4c

Buy Sennheiser MOMENTUM True Wireless 2
On Amazon (PAID LINK): https://geni.us/sJwlu
On Newegg (PAID LINK): https://geni.us/Ey0j
On B&H (PAID LINK): https://geni.us/AldAz
On Best Buy (PAID LINK): https://geni.us/ST3QOt

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: **LINK TO DISCUSSION THREAD**


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Private Internet Access VPN: https://lmg.gg/pialinus2
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

## I bought a TRANSPARENT TV for $7000 :*(
 - [https://www.youtube.com/watch?v=oPOhKULOL4o](https://www.youtube.com/watch?v=oPOhKULOL4o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-10-17 00:00:00+00:00

Receive a $25 credit for Ting today when you sign up at https://linus.ting.com/

Why on earth would anyone want a transparent TV?...

Check out our early access video platform, Floatplane! http://floatplane.com

Buy a new TV:
On Amazon (PAID LINK): https://geni.us/Lji0Mar
On Newegg (PAID LINK): https://geni.us/aRCO
On B&H (PAID LINK): https://geni.us/lm9a7
On Best Buy (PAID LINK): https://shop-links.co/1728222750643642585

Purchases made through some store links may provide some compensation to Linus Media Group.

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Private Internet Access VPN: https://lmg.gg/pialinus2
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

