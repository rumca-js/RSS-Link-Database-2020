# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 5 Ray Tracing Mods That Show NEXT-GEN GRAPHICS [4K]
 - [https://www.youtube.com/watch?v=I4BYYlASXgM](https://www.youtube.com/watch?v=I4BYYlASXgM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-10-18 00:00:00+00:00

Ray tracing seemingly is the graphics technology of the future. Thankfully, some game modders are already showcasing it in brilliant ways.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

5. The Witcher 3 Raytrace mod
Patreon page: https://www.patreon.com/mcflypg/posts

4. Batman: Arkham Knight - ReShade Ray Tracing shader mod
Patreon page: https://www.patreon.com/mcflypg

3. Fallout 4 - ReShade Ray Tracing shader mod
Patreon page: https://www.patreon.com/mcflypg

2. Watchdogs - Natural & Realistic Lighting for Watch_dogs
mod page: https://forums.guru3d.com/threads/natural-realistic-lighting-for-watch_dogs.407372/

1. GTA 5 - Realism Beyond Ray-Tracing Graphics mod
Patreon page: https://www.patreon.com/Oreoshaman

## XBOX SERIES X: 10 TESTS We Ran For 10 Days [4K]
 - [https://www.youtube.com/watch?v=uEKVVog3Dug](https://www.youtube.com/watch?v=uEKVVog3Dug)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-10-17 00:00:00+00:00

Microsoft sent us an Xbox Series X. Here are some first impressions and some cool things we did with it.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

