# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Son Rompe Pera - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=n46HvMIsSuQ](https://www.youtube.com/watch?v=n46HvMIsSuQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-17 00:00:00+00:00

http://KEXP.ORG presents Son Rompe Pera sharing a live session recorded exclusively for KEXP.

Songs:
Proteus
FOS
Reina de Cumbias
Ay David!
El Palo Poste

Band:
Kacho: Marimba + voice
Mongo: Marimba + voice
Kilos: Percussion + voice
Ritchie: Drums
Raul: Bass + voice

Recorded by El Corral
Recording assistants: Armando Lara
Mix y master: Miguel "Eme" Rodríguez
Video directed by: Ramiro Medina Flores
Video produced by: We Are Not Zombies
Video photography by: Antonio Lomelí
Video Edited by: Thalía Hernández Special thanks to: Timo, Michi, Papi y Chalo, Ale y Pasifloreando, Garage Pizza, MonsterFly Studios

https://linktr.ee/sonrompepera
http://kexp.org

