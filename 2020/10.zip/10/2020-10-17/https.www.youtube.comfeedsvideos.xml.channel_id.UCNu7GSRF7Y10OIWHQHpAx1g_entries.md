# Source:BezPlanu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g, language:pl-PL

## Odcinek o niczym. No dobra: posprzątałem plażę
 - [https://www.youtube.com/watch?v=k8qHJFO-rFo](https://www.youtube.com/watch?v=k8qHJFO-rFo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g
 - date published: 2020-10-18 00:00:00+00:00

Wspomniany odcinek z kanału Polak w Albanii:
https://youtu.be/o1k4wMaDQ5E

Wszystkie odcinki chronologicznie: http://bit.ly/2MqAO7Q
(można też klikać w kartę "Następny odcinek" pojawiającą się pod koniec każdego filmu po prawej stronie u góry)

Wsparcie Patronite: http://bit.ly/2KsFTZk 
Instagram: http://instagram.com/bezplanu_czukesky 
Facebook: https://www.facebook.com/BezPlanu.tv 

Subtitles by Justyna Obruśnik justyna.obrusnik@gmail.com

Czas akcji: 14 października 2019 r. (Albania), 17 października 2020 r. (Filipiny)

