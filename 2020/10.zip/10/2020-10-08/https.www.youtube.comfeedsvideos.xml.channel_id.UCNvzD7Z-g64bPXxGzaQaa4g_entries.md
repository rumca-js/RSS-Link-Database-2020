# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## CYBERPUNK 2077 MAP LEAKED, GAMESTOP PARTNERS WITH XBOX, & MORE
 - [https://www.youtube.com/watch?v=NAXCL8MNhto](https://www.youtube.com/watch?v=NAXCL8MNhto)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-10-09 00:00:00+00:00

Brought to you by Raycon. Go to https://buyraycon.com/gameranx for 15% off your order!

PS5 backwards compatibility is detailed alongside a hardware teardown, GameStop joins forces with Microsoft, Cyberpunk's map looks awesome, and more stuff in a week full of gaming news.


 discord.gg/gameranx                                                



 ~~~~STORIES~~~~


Cyberpunk map
https://www.eurogamer.net/amp/2020-10-05-heres-the-full-map-of-cyberpunk-2077s-night-city?__twitter_impression=true

Microsoft/GameStop join forces
https://www.businessinsider.com/gamestop-microsoft-partnership-sends-games-retailers-shares-up-44-2020-10

PS5 teardown
https://youtu.be/CaAY-jAjm0w

Extra PS5 backwards compat details
https://twitter.com/Nibellion/status/1314589131528429568


Rambo, Rain, and Mileena in MK11
https://youtu.be/dDKG5dlkHmk

Outriders trailer (Feb 2)
https://youtu.be/lVB98xP6gds

The Medium trailer (Dec. 10)https://youtu.be/_zQe9pPSkM8

Xbox ad:
https://youtu.be/DIMAujZpry0

Mafia noir mode
https://www.gamespot.com/articles/mafia-definitive-edition-adds-a-black-and-white-noir-mode-with-update-103/1100-6483061/

GamePass maybe to iOS
https://www.gamasutra.com/view/news/371662/Report_Microsoft_will_deploy_browserbased_solution_to_bring_Xbox_Game_Pass_to_iOS.php


Resident Evil 
https://deadline.com/2020/10/resident-evil-reboot-kaya-scodelario-robbie-amell-hannah-john-kamen-origin-story-1234591729/

## Baldur's Gate 3 - Before You Buy
 - [https://www.youtube.com/watch?v=s7-39QT378g](https://www.youtube.com/watch?v=s7-39QT378g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-10-08 00:00:00+00:00

Baldur's Gate 3 is now available in early access form. They're asking for your money, so we decided to take a look at what you get.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## Top 10 NEW Racing Games of 2020
 - [https://www.youtube.com/watch?v=DWt2U5yrsWc](https://www.youtube.com/watch?v=DWt2U5yrsWc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-10-08 00:00:00+00:00

There were tons of great racing games in 2020 for PC, PS4, Xbox One, Series X, Switch, and PS5. From racing cars to motorcycles, we've got you covered.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Hotshot Racing
PC PS4 XBOX ONE SWITCH
Aug 13, 2020

WRC 9
PC, PS4, XBOX ONE SWITCH
Sep 1, 2020

SnowRunner
PC PS4 XBOX ONE
Apr 28, 2020

RIDE 4
PC PS4 XBOX ONE
Oct 8, 2020

Art of Rally
PC
2020

F1 2020
PC PS4 XBOX ONE
July 6, 2020

Inertial Drift
PC PS4 XBOX ONE SWITCH
Sep 11, 2020

Need for Speed Hot Pursuit Remastered
PC PS4 XBOX ONE SWITCH
Nov 6, 2020

DIRT 5
PC PS4 XBOX ONE XBOX SERIES X PS5
OCT 6, 2020

Gran Turismo 7
PS5
Q4 2020

