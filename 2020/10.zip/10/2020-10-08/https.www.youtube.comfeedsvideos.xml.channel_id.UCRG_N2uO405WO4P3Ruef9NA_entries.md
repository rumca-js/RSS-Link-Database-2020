# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Google gave a HUGE boost to cheap cameras
 - [https://www.youtube.com/watch?v=Jhfx52WSYFk](https://www.youtube.com/watch?v=Jhfx52WSYFk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2020-10-09 00:00:00+00:00

Sponsored by Brilliant. The first 200 people to sign up get 20% off an annual plan at https://brilliant.org/TFC 

This video on Nebula: https://watchnebula.com/videos/the-friday-checkout-google-just-gave-cheap-phones-a-huge-boost

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► In this video ◄◄◄ 

This week Google brings its Pixel camera magic to Android Go, Samsung makes a TON of money, Ratio comes to the Play Store and PayTM launches an "app store".

The Friday Checkout ep. 18

Ratio: https://play.google.com/store/apps/details?id=com.bllocosn

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► Quiz ◄◄◄ 

Weekly tech quiz: 
https://crrowd.com/quiz 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► TechAltar links ◄◄◄ 

Merch: 
https://enthusiast.store 

Crrowd Discord: 
https://discord.gg/npKQebe 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 

If you want to support TechAltar directly: 
https://flattr.com/@techaltar 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► Attributions ◄◄◄ 
Music by Edemski: 
https://soundcloud.com/edemski 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► Timestamps ◄◄◄ 

0:00 Intro 
0:37 Android Go Camera magic
2:19 Samsung makes a TON of money
3:05 Ratio in the Play Store
3:59 PayTM launches an "app store"

