# Source:Veritasium, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA, language:en-US

## Why Gravity is NOT a Force
 - [https://www.youtube.com/watch?v=XRr1kaXKBsU](https://www.youtube.com/watch?v=XRr1kaXKBsU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA
 - date published: 2020-10-09 00:00:00+00:00

The General Theory of Relativity tells us gravity is not a force, gravitational fields don't exist. Objects tend to move on straight paths through curved spacetime. Thanks to Caséta by Lutron for sponsoring this video. Find out more at: https://www.lutron.com/veritasium

Huge thanks to Prof. Geraint Lewis for hours of consulting on this video so I could get these ideas straight in my own brain. Check out his YouTube channel: https://ve42.co/gfl or his books: https://ve42.co/GFLbooks

Amazing VFX, compositing, and editing by Jonny Hyman
2D animations by Ivy Tello
Filmed by Steven Warren and Raquel Nuno
Special thanks to Petr Lebedev for reviews and script consultation
Music by Jonny Hyman and from Epidemic Sound https://epidemicsound.com

Rocket made by Goodnight and Co.
Screen images in rocket by Geoff Barrett

Slow motion rocket exhaust footage from Joe Barnard at BPS.Space
https://www.youtube.com/channel/UCILl8ozWuxnFYXIe2svjHhg

