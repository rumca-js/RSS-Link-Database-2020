# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Get Dead Soon/Fact Checks/Bee Kid Pitches News Show 10.9.2020
 - [https://www.youtube.com/watch?v=-rodN2LSSVw](https://www.youtube.com/watch?v=-rodN2LSSVw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-10-09 00:00:00+00:00

Today on The Babylon Bee Podcast, Kyle and Ethan talk about the week’s biggest stories like Democrats hoping Trump “gets dead soon” after coming down with coronavirus, USA Today keeping the internet safe from satire, and Bee kids sending The Babylon Bee their best headline pitches. 

Kyle and Ethan also talk about murderous witches, Satanic billboards, and fat bears and get a chance to speak with filmmaker Matt Chastain about his new movie Small Group.

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Gain Access to the Exclusive Content and Writing Forum: https://babylonbee.com/plans

The Official Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

## Kevin Sorbo Talks About An Inappropriate Looking Prop On Andromeda
 - [https://www.youtube.com/watch?v=b1YlKsq0oN0](https://www.youtube.com/watch?v=b1YlKsq0oN0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-10-08 00:00:00+00:00

Kevin Sorbo tells a story about bad Hollywood props on the set of Andromeda. Before Kevin Sorbo was exiled from Hollywood sets he was able to get a full view of all the craziness that is Hollywood. 

Check out the full episode in all its craziness ▶️ 
https://www.youtube.com/watch?v=xEAMkTq3eH4

Subscribe to the Babylon Bee to gaze upon the world on fire with a smile on your face. 

Hit the bell to get our content before the haters do.

## What Does Kevin Sorbo Really Feel About Antifa And Wearing Masks?
 - [https://www.youtube.com/watch?v=9rrnrZEC1oA](https://www.youtube.com/watch?v=9rrnrZEC1oA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-10-08 00:00:00+00:00

Kevin Sorbo talks about why this is not the new normal. Come hear the tough questions he wants to ask Antifa members, his feelings about masks, and a new movie that Kevin Sorbo Directed and starred in. 

See the whole episode in all its greatness: 
https://www.youtube.com/watch?v=xEAMkTq3eH4

Subscribe to the Babylon Bee to hear the life of a conservative Christian in Hollywood

Hit the bell to get all the content before it gets censored.

