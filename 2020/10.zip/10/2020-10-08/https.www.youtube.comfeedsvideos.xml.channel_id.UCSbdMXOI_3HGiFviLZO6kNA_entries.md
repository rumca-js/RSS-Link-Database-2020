# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## The 7 Types of VR Users
 - [https://www.youtube.com/watch?v=DJeDT13GGIM](https://www.youtube.com/watch?v=DJeDT13GGIM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-10-09 00:00:00+00:00

Here are the 7 people you'll meet in VR. Virtual Reality is cool. You'll meet lots of cool people if you put on a headset. You should try it. 

2nd Channel and Meetup video:
https://www.youtube.com/watch?v=pZO_KOqt46Q
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill

