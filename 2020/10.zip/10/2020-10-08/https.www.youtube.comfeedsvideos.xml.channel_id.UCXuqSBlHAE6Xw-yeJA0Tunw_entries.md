# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## AMD Winning the Hearts of Gamers with Ryzen 5000 - WAN Show October 9 , 2020
 - [https://www.youtube.com/watch?v=jj6tXD4tSk8](https://www.youtube.com/watch?v=jj6tXD4tSk8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-10-09 00:00:00+00:00

Save 10% at Ridge Wallet with offer code LINUS at https://www.ridge.com/Linus

Visit https://www.squarespace.com/WAN and use offer code WAN for 10% off

Get a 15-day free trial for unlimited backup at https://backblaze.com/WAN

Check out Carpool Critics, our new movie podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Podcast Download: https://dts.podtrac.com/redirect.mp3/traffic.libsyn.com/secure/linustechtips/AMD_Winning_the_Hearts_of_Gamers_with_Ryzen_5000_-_WAN_Show_October_9__2020.mp3

Timestamps: (Courtesy of Michael O'Brien)
00:00:00 - Stream Start!
00:00:02 - Hey, Welcome to the WAN Show Ladies and Gentlemen!
00:00:10 - Topic #1: AMD Announced 3rd Gen CPUs (Jump to 00:02:25)
00:00:32 - Topic #2: DriveSavers' Drama (Jump to 00:24:36)
00:01:01 - Topic #5: PS5 Teardown (Jump to 01:05:25)
00:01:17 - Topic #3: Starlink Entering Public Beta (Jump to 00:41:12)
00:01:23 - Topic #4: MSI Drama (Jump to 00:47:18)
00:01:32 - Intro
00:02:21 - Topic #1: AMD Announced 3rd Gen CPUs
 00:03:11 - What CPUs were announced
 00:04:31 - Claimed performance uplift
 00:05:45 - AMD vs Intel platform differences
00:06:31 - 'SUP YO! HOW YOU DOIN'?!
00:10:08 - Unofficial Topic #1: LTT's Floatplane Presence
 00:10:32 - LTT vs Slow Mo Guys, mebe?
 00:11:48 - LTT's LG C10 coverage anecdote
00:16:44 - Back to Topic #1, take 2
 00:16:51 - But Rocket Lake?
 00:18:57 - Intel's virtualization - AMD's
00:19:29 - Unofficial Topic #2: Wendell's Collection Habits
 00:20:49 - No, seriously.
00:22:40 - Back to Topic #1, take 3
 00:22:52 - Would Luke go all Red?
00:24:32 - Topic #2: DriveSavers' Drama
 00:25:36 - Allegations against LTT
 00:27:11 - Repair vs Recycle
 00:29:24 - iPad Rehab's Claim & Rebuttal
 00:32:04 - Linus' take
00:33:39 - Back to UT #2: The Wendell Call
 00:35:56 - Stop changing the subject!
 00:38:34 - The "businessman" stance
 00:39:46 - You can find Wendell at...
00:41:08 - Topic #3: Starlink Entering Public Beta
 00:41:34 - Maybe Feb 18th, 2021?
 00:42:14 - But First Responders
 00:43:32 - GMC's Hummer is still around
00:44:38 - Sponsors!
 00:44:41 - Ridge Wallet - Offer code Linus for 10% off - ridge.com/linus
 00:45:28 - BackBlaze - backblaze.com/wan
 00:46:17 - SquareSpace - Offer code WAN for 10% off - squarespace.com/wan
00:47:14 - Topic #4: MSI Scalping Drama
 00:47:25 - Coincidence of MSI Sponsorship
 00:48:30 - Linus was right
 00:51:56 - Linus @ NCIX & how this could have happened
 00:54:53 - Why the sales were unnoticed
 00:57:23 - Linus' summation & hot take
01:01:05 - Unofficial Topic #3: R9 5950X - Dead End?
01:03:05 - Unofficial Topic #4: MSI's corrective action
01:05:25 - Topic #5: PS5 Teardown
 01:05:31 - Linus' & Luke's takeaways
 01:07:42 - Forward thinking against industry trends
 01:08:25 - Liquid metal talks & repairability
 01:12:54 - PS4 games that are NOT compatible
01:15:38 - Unofficial Topic #5: Apple's T2's Security Vulnerability
 01:16:34 - A significant downside
 01:17:38 - An upside
01:18:44 - Superchats!
 01:18:51 - Fabian, lttstore.com
 01:20:41 - Sick burn!
 01:24:27 - lttstore.com masks
01:27:17 - Bye!
01:27:23 - Outtro!

## Intel lost the game - AMD Ryzen 5000 Reveal
 - [https://www.youtube.com/watch?v=5uWXfoX1x3A](https://www.youtube.com/watch?v=5uWXfoX1x3A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-10-08 00:00:00+00:00

Get 50% off your first 3 months of FreshBooks when you sign up for a paid plan at https://www.freshbooks.com/techtips

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire

Dr. Lisa Su has guided AMD in three short years from being the scrappy underdog to finally overtaking Intel’s best in nearly every category. Where do we go from here?

Watch the AMD Where Gaming Begins event VOD: https://www.youtube.com/watch?v=iuiO6rqYV4o

Buy AMD Ryzen 5600X, 5800X, 5900X, 5950X,
Coming soon

Buy AMD Ryzen 5 3600XT CPU
On Amazon (PAID LINK): https://geni.us/RC4u1f
On Newegg (PAID LINK): https://geni.us/RgT9bt
On B&H (PAID LINK): https://geni.us/ZuCB

Buy AMD Ryzen 7 3800XT CPU
On Amazon (PAID LINK): https://geni.us/k9dpZt
On Newegg (PAID LINK): https://geni.us/5moRXBL
On B&H (PAID LINK): https://geni.us/N3u7M

Buy AMD Ryzen 9 3900XT CPU
On Amazon (PAID LINK): https://geni.us/LEwas
On Newegg (PAID LINK): https://geni.us/TgAf0M
On B&H (PAID LINK): https://geni.us/lDDf86

Buy AMD Ryzen 5 CPU
On Amazon (PAID LINK): https://geni.us/mXjP
On Newegg (PAID LINK): https://geni.us/fCC0
On B&H (PAID LINK): https://geni.us/dQuvv

Buy AMD Ryzen 7 CPU
On Amazon (PAID LINK): https://geni.us/uIwiD
On Newegg (PAID LINK): https://geni.us/zOQCj
On B&H (PAID LINK): https://geni.us/xNVr

Buy AMD Ryzen 9 CPU
On Amazon (PAID LINK): https://geni.us/BFGqj
On Newegg (PAID LINK): https://geni.us/egxdB
On B&H (PAID LINK): https://geni.us/ueLe

Buy an Intel 10th Gen CPU
On Amazon (PAID LINK): https://geni.us/vBmJ
On Newegg (PAID LINK): https://geni.us/tJ2lRVU
On B&H (PAID LINK): https://geni.us/V93LES

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1255613-intel-lost-the-game/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Private Internet Access VPN: https://lmg.gg/pialinus2
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

