# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Gov. Whitmer on CNN: After kidnapping plot, they're attacking me
 - [https://www.cnn.com/videos/politics/2020/10/08/michigan-governor-whitmer-ebof-trump-miller-response-sot-vpx.cnn](https://www.cnn.com/videos/politics/2020/10/08/michigan-governor-whitmer-ebof-trump-miller-response-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 23:38:53+00:00

Michigan Gov. Gretchen Whitmer tells CNN's Erin Burnett that senior Trump campaign adviser Jason Miller's criticism of her on Fox News after 13 people were charged for plotting to kidnap her "says everything you need to know about the White House."

## Black Versace executive frisked for weapons after jaywalking
 - [https://www.cnn.com/videos/us/2020/10/08/versace-executive-racially-profiled-police-orig-mg.cnn](https://www.cnn.com/videos/us/2020/10/08/versace-executive-racially-profiled-police-orig-mg.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 23:35:45+00:00

A Versace executive said he was stopped and searched by police officers while walking in Beverly Hills because he is Black. Police denied the claims saying it was because of a jaywalking offense.

## Trump and Biden wouldn't be the first. See 1960's 'virtual' presidential debate
 - [https://www.cnn.com/videos/business/2020/10/08/trump-biden-virtual-debate-jfk-nixon-zw-orig.cnn-business](https://www.cnn.com/videos/business/2020/10/08/trump-biden-virtual-debate-jfk-nixon-zw-orig.cnn-business)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 23:18:45+00:00

President Trump and Joe Biden won't be the first Presidential candidates to debate remotely. That distinction goes to Sen. John F. Kennedy and Richard Nixon during the 1960 race.

## Analysis: Mitch McConnell admitted what we all know about Trump
 - [https://www.cnn.com/2020/10/08/politics/mitch-mcconnell-donald-trump-coronavirus-protocols/index.html](https://www.cnn.com/2020/10/08/politics/mitch-mcconnell-donald-trump-coronavirus-protocols/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 23:09:27+00:00

At an event back home in Kentucky on Thursday, Mitch McConnell acknowledged what we all know: Donald Trump and his White House are not even coming close to following the accepted guidelines on how to limit the spread of the coronavirus.

## 11 states set new Covid-19 daily case record
 - [https://www.cnn.com/videos/health/2020/10/08/coronavirus-daily-wrap-nick-watt-dnt-sitroom-vpx.cnn](https://www.cnn.com/videos/health/2020/10/08/coronavirus-daily-wrap-nick-watt-dnt-sitroom-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 23:00:49+00:00

The coronavirus outbreak is intensifying across the United States, with much of the country moving in the wrong direction and some states enforcing new restrictions CNN's Nick Watt reports.

## 'Flood the streets': Scientist reveals the White House note that made him speak out
 - [https://www.cnn.com/videos/politics/2020/10/08/rick-bright-speaking-out-tapper-intv-sot-lead-vpx.cnn](https://www.cnn.com/videos/politics/2020/10/08/rick-bright-speaking-out-tapper-intv-sot-lead-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 22:19:09+00:00

Rick Bright, the ousted director of the office involved in developing a coronavirus vaccine, explains to CNN's Jake Tapper why he is speaking out against the Trump administration.

## Thousands of abandoned chicks die at Madrid's airport
 - [https://www.cnn.com/videos/world/2020/10/08/thousands-of-chicks-died-at-madrid-airport-lon-orig-na.cnn](https://www.cnn.com/videos/world/2020/10/08/thousands-of-chicks-died-at-madrid-airport-lon-orig-na.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 19:17:09+00:00

About 23,000 baby chicks have died after being abandoned in transit at Madrid Barajas International Airport in Spain.

## It's not just the risk of death - here's why you don't want Covid-19
 - [https://www.cnn.com/videos/health/2020/10/08/uncommon-covid-symptoms-orig-mg.cnn](https://www.cnn.com/videos/health/2020/10/08/uncommon-covid-symptoms-orig-mg.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 15:22:55+00:00

There's a lot that we still don't understand about Covid-19 and we are just beginning to see the long-term effects, such as hair loss, stroke, heart failure.

## Hear Trump tell Fox he won't participate in debate: I'm not going to waste my time
 - [https://www.cnn.com/videos/politics/2020/10/08/trump-biden-second-presidential-debate-virtual-vpx.cnn](https://www.cnn.com/videos/politics/2020/10/08/trump-biden-second-presidential-debate-virtual-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 12:40:16+00:00

President Trump said he would not participate in a remote debate after the Commission on Presidential Debates announced the second presidential debate would be virtual for both candidates' safety. Democratic presidential nominee Joe Biden says he would participate in a virtual debate.

## Nigerian migrant worker burned alive in Libya
 - [https://www.cnn.com/2020/10/08/middleeast/nigerian-worker-libya-burned-intl/index.html](https://www.cnn.com/2020/10/08/middleeast/nigerian-worker-libya-burned-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 09:46:51+00:00

Three men stormed a factory in Tripoli, doused a Nigerian worker in petrol, and set him on fire, according to a statement by the interior ministry, in a new reported attack on migrants in the north African country.  Libyan capita

## Full video: Watch Harris and Pence square off
 - [https://www.cnn.com/videos/politics/2020/10/07/vice-presidential-debate-full-video-2020-dbx-vpx.cnn](https://www.cnn.com/videos/politics/2020/10/07/vice-presidential-debate-full-video-2020-dbx-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 09:37:15+00:00

Vice President Mike Pence and Sen. Kamala Harris (D-CA) square off in the only vice presidential debate of the 2020 election season in Salt Lake City, Utah.

## Leaders of Greek neo-Nazi group found guilty of running criminal organization
 - [https://www.cnn.com/2020/10/07/europe/golden-dawn-guilty-leadership-intl/index.html](https://www.cnn.com/2020/10/07/europe/golden-dawn-guilty-leadership-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 09:21:15+00:00

The leaders of Greece's neo-Nazi group Golden Dawn were found guilty Wednesday of forming and running a criminal organization under the cloak of a political party, in a landmark decision hailed as a victory for democracy and human rights.

## Novak Djokovic plays through pain to reach French Open semifinals
 - [https://www.cnn.com/2020/10/08/tennis/novak-djokovic-injury-french-open-semifinals-pablo-carreno-busta-spt-intl/index.html](https://www.cnn.com/2020/10/08/tennis/novak-djokovic-injury-french-open-semifinals-pablo-carreno-busta-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 08:29:33+00:00

World No.1 Novak Djokovic is into the French Open semifinals for the 10th time in his career, but his body didn't make it easy for him.

## Are the kids all right? Supporting your teen's mental health through Covid-19
 - [https://www.cnn.com/2020/10/08/health/teen-mental-health-pandemic-wellness/index.html](https://www.cnn.com/2020/10/08/health/teen-mental-health-pandemic-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 08:28:18+00:00

Less than a month into the academic year at Brophy College Preparatory in Phoenix, Alex, a 17-year-old high school senior, is feeling the strain of life in an uncertain time.

## In US-Russia aerial encounters, 'the greatest risk is miscalculation'
 - [https://www.cnn.com/2020/10/08/europe/us-navy-flight-black-sea-intl-hnk/index.html](https://www.cnn.com/2020/10/08/europe/us-navy-flight-black-sea-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 08:27:42+00:00

Thirty thousand feet in the air, a United States Navy crewman jumps to his feet and rushes toward a large window in the reconnaissance jet.

## Pence does his best but Harris won't let him explain away Trump's failures
 - [https://www.cnn.com/2020/10/08/politics/kamala-harris-mike-pence-trump-debate/index.html](https://www.cnn.com/2020/10/08/politics/kamala-harris-mike-pence-trump-debate/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 08:12:44+00:00

Vice President Mike Pence tried his best on Wednesday to recast the reality of Donald Trump's presidency, but Sen. Kamala Harris, the Democratic pick for his job, refused to let him spin away the nation's current dire plight during their single debate.

## Coronavirus looms over vice presidential debate
 - [https://www.cnn.com/collections/post-vp-debate-intl-0811/](https://www.cnn.com/collections/post-vp-debate-intl-0811/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 08:03:03+00:00



## Cooper slams Covid-19 infected Trump: Gay people with HIV can be arrested
 - [https://www.cnn.com/videos/politics/2020/10/08/cooper-trump-coronavirus-infection-reckless-hiv-comparison-vpx.cnn](https://www.cnn.com/videos/politics/2020/10/08/cooper-trump-coronavirus-infection-reckless-hiv-comparison-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 08:00:45+00:00

CNN's Anderson Cooper calls out President Donald Trump's reckless behavior while being infected with coronavirus.

## Prince William launches Nobel-like prize for the environment
 - [https://www.cnn.com/2020/10/07/world/prince-william-earthshot-prize-environment-gbr-intl/index.html](https://www.cnn.com/2020/10/07/world/prince-william-earthshot-prize-environment-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 07:58:36+00:00

Britain's Prince William is dedicating $65 million to create a new environmental award, in an effort to inspire solutions to some of the Earth's most pressing challenges.

## VP debate fact check: Daniel Dale selects the 'lie of the night'
 - [https://www.cnn.com/videos/politics/2020/10/08/daniel-dale-vice-presidential-debate-fact-check-supercut-vpx-sot.cnn](https://www.cnn.com/videos/politics/2020/10/08/daniel-dale-vice-presidential-debate-fact-check-supercut-vpx-sot.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 07:49:06+00:00

CNN's Daniel Dale fact checks Vice President Mike Pence and Sen. Kamala Harris's key moments from the 2020 vice presidential debate.

## Singapore introduces 'cruises to nowhere' for travel-starved locals
 - [https://www.cnn.com/travel/article/singapore-cruises-to-nowhere-intl-hnk/index.html](https://www.cnn.com/travel/article/singapore-cruises-to-nowhere-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 07:35:56+00:00

Move over, flights to nowhere -- cruises to nowhere may be the next big thing in Covid-safe travel.

## Experts weigh in: Who won?
 - [https://www.cnn.com/2020/10/08/opinions/who-won-vp-debate-roundup/index.html](https://www.cnn.com/2020/10/08/opinions/who-won-vp-debate-roundup/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 07:05:07+00:00

CNN Opinion asked contributors for their takes on how Mike Pence and Kamala Harris did at the vice presidential debate. The views expressed in these commentaries are their own.

## Canada will ban single-use plastic items by the end of next year
 - [https://www.cnn.com/2020/10/07/world/plastic-ban-canada-trnd/index.html](https://www.cnn.com/2020/10/07/world/plastic-ban-canada-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 07:04:59+00:00

Travelers to Canada should not expect to see some everyday plastic items starting next year.

## Mirim Lee admits she 'had no motivation to play golf' before winning her debut major
 - [https://www.cnn.com/2020/10/07/golf/mirim-lee-ana-inspiration-win-south-korea-golf-spc-spt-intl/index.html](https://www.cnn.com/2020/10/07/golf/mirim-lee-ana-inspiration-win-south-korea-golf-spc-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 06:54:59+00:00

You might have thought in the build-up to a golf major, players would be champing at the bit to be out on the course, tweaking and honing their games.

## Fact check: Pence echoes Trump's false claims
 - [https://www.cnn.com/2020/10/07/politics/fact-check-kamala-harris-mike-pence-debate/index.html](https://www.cnn.com/2020/10/07/politics/fact-check-kamala-harris-mike-pence-debate/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 06:36:48+00:00

Vice President Mike Pence echoed some of President Donald Trump's most common falsehoods and misleading statements during the lone vice presidential debate with Sen. Kamala Harris on Wednesday night -- though in a more restrained, neatly packaged way.

## Police officer won't face charges in deadly shooting of 17-year-old
 - [https://www.cnn.com/2020/10/07/us/wauwatosa-wisconsin-police-shooting-alvin-cole/index.html](https://www.cnn.com/2020/10/07/us/wauwatosa-wisconsin-police-shooting-alvin-cole/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 06:35:37+00:00

A police officer in Wauwatosa, Wisconsin, will not face criminal charges in the shooting death of 17-year-old Alvin Cole, an attorney representing Cole's family said.

## N Korean diplomat who went missing in Italy 2 years ago defected to S Korea
 - [https://www.cnn.com/2020/10/08/asia/north-korea-diplomat-jo-song-gil-intl-hnk/index.html](https://www.cnn.com/2020/10/08/asia/north-korea-diplomat-jo-song-gil-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 05:12:37+00:00

A top North Korean diplomat who went missing in Italy two years ago is now living in South Korea, making him one of the regime's most high profile officials to defect in decades.

## Hits and misses from the only vice presidential debate
 - [https://www.cnn.com/2020/10/07/politics/vice-presidential-debate-hits-and-misses/index.html](https://www.cnn.com/2020/10/07/politics/vice-presidential-debate-hits-and-misses/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 05:12:29+00:00

The first -- and only -- vice presidential debate between Mike Pence and Kamala Harris is over.

## Fly lands on Pence's head during debate
 - [https://www.cnn.com/videos/politics/2020/10/08/mike-pence-fly-on-head-debate-sot-vpx.cnn](https://www.cnn.com/videos/politics/2020/10/08/mike-pence-fly-on-head-debate-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 04:46:17+00:00

Watch the moment a fly landed on Vice President Mike Pence's head while he was debating Sen. Kamala Harris during the only vice presidential debate of the 2020 election.

## Harris forced Pence to defend Trump often in their debate
 - [https://www.cnn.com/2020/10/07/politics/us-election-vice-presidential-debate/index.html](https://www.cnn.com/2020/10/07/politics/us-election-vice-presidential-debate/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 04:37:02+00:00

Highlights | In photos: The 2020 VP debate | Road to 270

## Trump threatens China with big price 'for what they've done to the world'
 - [https://www.cnn.com/2020/10/08/asia/trump-pence-china-debate-covid-intl-hnk/index.html](https://www.cnn.com/2020/10/08/asia/trump-pence-china-debate-covid-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 04:34:45+00:00

United States President Donald Trump has again hit out at China over the coronavirus, promising Beijing will "pay a big price for what they've done to the world."

## The Pence question Harris wouldn't answer
 - [https://www.cnn.com/videos/politics/2020/10/08/pence-harris-court-packing-dbx-2020.cnn](https://www.cnn.com/videos/politics/2020/10/08/pence-harris-court-packing-dbx-2020.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 04:10:45+00:00

Sen. Kamala Harris (D-CA) ducked Vice President Mike Pence's question about whether a Biden administration would seek to add seats to the Supreme Court if the Trump administration pushes through the nomination of Amy Coney Barrett to replace former Justice Ruth Bader Ginsburg.

## Samsung earnings soar as smartphone sales rebound and rival Huawei struggles
 - [https://www.cnn.com/2020/10/08/tech/samsung-earnings-3q-intl-hnk/index.html](https://www.cnn.com/2020/10/08/tech/samsung-earnings-3q-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 04:02:50+00:00

Samsung predicts its profit jumped nearly 60% last quarter, suggesting it could soon retake its position as the world's top smartphone seller from embattled Chinese rival Huawei.

## JPMorgan Chase commits $30 billion to advance racial equity
 - [https://www.cnn.com/2020/10/08/business/jpmorgan-chase-racial-equity/index.html](https://www.cnn.com/2020/10/08/business/jpmorgan-chase-racial-equity/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 04:01:56+00:00

JPMorgan Chase is committing $30 billion over the next five years to promote racial equality.

## See who undecided voters thought won the VP debate
 - [https://www.cnn.com/videos/politics/2020/10/08/arizona-undecided-voter-panel-vice-presidential-debate-reaction-sidner-vpx.cnn](https://www.cnn.com/videos/politics/2020/10/08/arizona-undecided-voter-panel-vice-presidential-debate-reaction-sidner-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 04:01:07+00:00

CNN's Sara Sidner asks undecided voters in Arizona who they thought won the only vice presidential debate of the 2020 election between Vice President Mike Pence and vice presidential candidate Kamala Harris.

## Reports: Tennessee Titans players under investigation following Covid-19 cases
 - [https://www.cnn.com/2020/10/07/us/nfl-tennessee-titans-investigation/index.html](https://www.cnn.com/2020/10/07/us/nfl-tennessee-titans-investigation/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 03:50:46+00:00

The NFL and the players union are investigating members of the Tennessee Titans for possibly violating health protocols, ESPN and the NFL Network reported Wednesday.

## Record-setter. Patent holder. Eddie Van Halen's achievements as legendary as his guitar playing
 - [https://www.cnn.com/2020/10/07/entertainment/eddie-van-halen-achievements-trnd/index.html](https://www.cnn.com/2020/10/07/entertainment/eddie-van-halen-achievements-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 02:19:36+00:00

Even in the decadent '80s, known for its over-the-top guitar shredding and showmanship, Eddie Van Halen was a towered presence.

## Pence repeatedly interrupts Harris: Mr. Vice President, I am speaking
 - [https://www.cnn.com/videos/politics/2020/10/07/kamala-harris-mike-pence-i-am-speaking-moment-dbx-2020-vpx.cnn](https://www.cnn.com/videos/politics/2020/10/07/kamala-harris-mike-pence-i-am-speaking-moment-dbx-2020-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 02:11:20+00:00

Sen. Kamala Harris hit back at Vice President Mike Pence after interrupting one of her answers about coronavirus during the only vice presidential debate of the 2020 election.

## CNN correspondent fights off raccoon seconds before returning to live shot
 - [https://www.cnn.com/2020/10/07/us/joe-johns-raccoon-encounter-trnd/index.html](https://www.cnn.com/2020/10/07/us/joe-johns-raccoon-encounter-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 01:21:07+00:00

While there are not really normal days in Washington anymore, CNN Senior Washington Correspondent Joe Johns had a little more excitement added to his day, thanks to a raccoon.

## Biden crosses 270 threshold in CNN's Electoral College outlook for first time
 - [https://www.cnn.com/2020/10/07/politics/electoral-college-joe-biden-donald-trump/index.html](https://www.cnn.com/2020/10/07/politics/electoral-college-joe-biden-donald-trump/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-08 01:20:06+00:00

• Opinion: How Trump could win -- and have Harris as his VP

