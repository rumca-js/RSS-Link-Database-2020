# Source:Olden days, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC1gVCrX5uEFc0s_8TIYGqmw, language:en-US

## Scarlet Street (1945) Full Movie - [ Color - 4K ] - Old footage restoration with Machine Learning
 - [https://www.youtube.com/watch?v=72koIWWz5r8](https://www.youtube.com/watch?v=72koIWWz5r8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1gVCrX5uEFc0s_8TIYGqmw
 - date published: 2020-10-09 00:00:00+00:00

When a man in mid-life crisis befriends a young woman, her venal fiancé persuades her to con him out of the fortune they mistakenly assume he possesses.

Director: Fritz Lang
Stars: Edward G. Robinson, Joan Bennett, Dan Duryea

IMDB:
🔗 https://www.imdb.com/title/tt0038057/

Original video was processed with Deep Learning algorithms to achieve modern look and quality. Here is the process:

1. Footage stabilization and noise/dust/scratches removal with After Effects and Neat Video ✔️
🔗 https://www.neatvideo.com/?linkID=p7845
2. Restoration with DeepRemaster, removing scratches and film damage ✔️
🔗 https://github.com/satoshiiizuka/siggraphasia2019_remastering
3. Frame interpolation to get smooth look using DAIN method. Result is 60 FPS video ✔️
🔗 https://github.com/baowenbo/DAIN
4. Colorization using DeOldify with NoGAN. Colors are not accurate, only for ambient mood ✔️
🔗 https://github.com/jantic/DeOldify
5. Upscaling using Topaz Video Enhance AI, upscale preserving detail and reducing noise ✔️
🔗 https://topazlabs.com/video-enhance-ai/ref/755/
⭐⭐⭐ 15% DISCOUNT CODE: oldendays15
6. Automation with Python scripts and AWS Thinkbox Deadline as queue manager ✔️
🔗 https://www.awsthinkbox.com/deadline
7. RTX 2070 Super 8GB, 32GB RAM, Ryzen 9 3900X 12-core. Approx 48hrs/10min video processing.

🎵 Intro Music:
Timelapse by boomopera
https://1.envato.market/om6ao

Social Media:
https://www.facebook.com/oldendayschannel
https://www.twitter.com/OldenDaysYT
https://www.instagram.com/oldendayschannel
https://www.pinterest.ca/OldenDaysYT/old-footage-restoration
https://www.patreon.com/oldendays

#deoldify #colorize #upscale #topazlabs #veai #dain #60fps #4k

## Snowball Fight in Lyon, France 1896 - [ 60 FPS - Color - 4K ] - Old footage restoration with AI
 - [https://www.youtube.com/watch?v=AjToVdbPxbw](https://www.youtube.com/watch?v=AjToVdbPxbw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1gVCrX5uEFc0s_8TIYGqmw
 - date published: 2020-10-09 00:00:00+00:00

Wintertime in Lyon. About a dozen people, men and women, are having a snowball fight in the middle of a tree-lined street. The cyclist coming along the road becomes the target of opportunity. He falls off his bicycle. He's not hurt, but he rides back the way he came, as the fight continues. Uh-oh. He forgot his cap in the snow.

Director: Louis Lumière

IMDB:
🔗 https://www.imdb.com/title/tt0000041/

Original video was processed with Deep Learning algorithms to achieve modern look and quality. Here is the process:

1. Footage stabilization and noise/dust/scratches removal with After Effects and Neat Video ✔️
🔗 https://www.neatvideo.com/?linkID=p7845
2. Restoration with DeepRemaster, removing scratches and film damage ✔️
🔗 https://github.com/satoshiiizuka/siggraphasia2019_remastering
3. Frame interpolation to get smooth look using DAIN method. Result is 60 FPS video ✔️
🔗 https://github.com/baowenbo/DAIN
4. Colorization using DeOldify with NoGAN. Colors are not accurate, only for ambient mood ✔️
🔗 https://github.com/jantic/DeOldify
5. Upscaling using Topaz Video Enhance AI, upscale preserving detail and reducing noise ✔️
🔗 https://topazlabs.com/video-enhance-ai/ref/755/
⭐⭐⭐ 15% DISCOUNT CODE: oldendays15
6. Automation with Python scripts and AWS Thinkbox Deadline as queue manager ✔️
🔗 https://www.awsthinkbox.com/deadline
7. RTX 2070 Super 8GB, 32GB RAM, Ryzen 9 3900X 12-core. Approx 48hrs/10min video processing.

🎵 Intro Music:
Timelapse by boomopera
https://1.envato.market/om6ao

Social Media:
https://www.facebook.com/oldendayschannel
https://www.twitter.com/OldenDaysYT
https://www.instagram.com/oldendayschannel
https://www.pinterest.ca/OldenDaysYT/old-footage-restoration
https://www.patreon.com/oldendays

#deoldify #colorize #upscale #topazlabs #veai #dain #60fps #4k

