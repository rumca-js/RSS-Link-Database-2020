# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Blue + Around the World MASHUP | Daft Punk | Pomplamoose
 - [https://www.youtube.com/watch?v=1xdA6IJW8hQ](https://www.youtube.com/watch?v=1xdA6IJW8hQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2020-10-08 00:00:00+00:00

All of our Daft Punk covers are now on one Daft Pomp album. Also there is vinyl. It’s very exciting. Get your limited edition 😎 vinyl at http://pomplamoose.com

 Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 A mashup of Eiffel 65's "Blue (Da Ba Dee)" and Daft Punk's "Around the World"

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

CREDITS

Lead Vocals: Nataly Dawn
Keys: Jack Conte
Guitar: Ryan Lerman 
Bass: Nick Campbell
Drums: Tamir Barzilay
Background vocals: Loren Battley
Engineer: Tim Sonnefeld 
Assistant Engineer: Tyler Karmen
Mixing/Mastering: Yianni AP
Producer: Ben Rose
Video Director: George Sloan
DP: Ricky Chavez
Camera Operators: Ricky Chavez, Merlin Showalter & Sammy Rothman
Video Editor: Dominic Mercurio

Recorded at 64 Sound in Los Angeles.

