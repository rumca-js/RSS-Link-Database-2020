# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Eorl the Young: Founder of Rohan | Tolkien Explained
 - [https://www.youtube.com/watch?v=c2EHaA44CRw](https://www.youtube.com/watch?v=c2EHaA44CRw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2020-10-09 00:00:00+00:00

How did the realm of Rohan come to be? In this video, we pick up with the rule of Eorl, Lord of the Éothéod. When the realm of Gondor is attacked by a group of Easterlings known as the Balchoth, Lord Cirion, the Ruling Steward of Gondor, calls for aid from their friends of old.  The events lead to the formation of Rohan and an alliance that would last well beyond the War of the Ring.

Hit subscribe - and the bell - so you never miss a video from Nerd of the Rings! 


-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner. 

The Red Arrow - Aleksander Karcz
The Rohirrim - Julia Alex
Rohirrim - Onur Bakar
The Red Arrow - Paula DiSante
The Oath of Cirion and Eorl - Ted Nasmith
The Oath of Cirion and Eorl - Anke Eissman
Gandalf and Shadowfax - John Howe
At the Crossing of the Mering Stream - steamey
Edoras - Bakarov
The Golden Hall of Meduseld - The Brothers Hildebrandt
Helm's Dike - Mariusz Gandzel
Orthanc in the Second Age - Ted Nasmith
King Theoden Armor - Robbie McSweeney
The Teeth of Scatha - Matthew Stewart
The Riders of Rohan - Ted Nasmith
Eorl musters the North - Wouter Florusse

#rohan #tolkien #lordoftherings

