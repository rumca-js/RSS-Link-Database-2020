# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Aloe Blacc - I Need A Dollar - live MUZO.FM
 - [https://www.youtube.com/watch?v=qUFt072idN8](https://www.youtube.com/watch?v=qUFt072idN8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-10-08 00:00:00+00:00

Aloe Blacc na żywo w MUZO.FM. Utwór I Need A Dollar pochodzi z płyty Good Things. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Aloe Blacc: http://www.facebook.com/aloeblacc
Instagram Aloe Blacc: http://www.instagram.com/aloeblacc
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm


Aloe Blacc I Need A Dollar lyrics

I need a dollar dollar, a dollar is what I need
Hey hey
Well I need a dollar dollar, a dollar is what I need
Hey hey
And I said I need dollar dollar, a dollar is what I need
And if I share with you my story would you share your dollar with me

Bad times are comin' and I reap what I don't sow
Hey hey
Well let me tell you somethin' all that glitters ain't gold
Hey hey
It's been a long old trouble long old troublesome road
And I'm looking for somebody come and help me carry this load

I need a dollar dollar, a dollar is what I need
Hey hey
Well I need a dollar dollar, a dollar is what I need
Well I don't know if I'm walking on solid ground
'Cause everything around me is falling down
And all I want is for someone to help me

I had a job but the boss man let me go
He said
I'm sorry but I won't be needing your help no more
I said
Please mister boss man I need this job more than you know
But he gave me my last paycheck and he sent me on out the door

Well I need a dollar dollar, a dollar is what I need
Hey hey
Said I need a dollar dollar, a dollar is what I need
Hey hey
And I need a dollar dollar, a dollar is what I need
And if I share with you my story would you share your dollar with me

Well I don't know if I'm walking on solid ground
'Cause everything around me is crumbling down
And all I want is for someone to help me

What in the world am I gonna to do tomorrow
Is there someone whose dollar that I can borrow
Who can help me take away my sorrow
Maybe it's inside the bottle
Maybe it's inside the bottle
Maybe it's inside the bottle

I had some good old buddy his names is whiskey and wine
Hey hey
And for my good old buddy I spent my last dime
Hey hey
My wine is good to me it helps me pass the time
And my good old buddy whiskey keeps me warmer than the sunshine

Your mom of mayhem just a child has got his own
Hey Hey
If god has plans for me I hope it ain't, written in stone
Hey Hey
Because I've been working working myself down to the bone
And I swear on grandpas grave I'll be paid when I come home

Well I need a dollar dollar, a dollar is what I need
Hey hey
Said need a dollar dollar, a dollar is what I need
Hey hey
Well I need a dollar dollar, a dollar is what I need hey hey
And if I share with you my story would you share your dollar with me

Come on share your dollar with me
Go ahead share your dollar with me
Come on share your dollar give me your dollar
Share your dollar with me
Come on share your dollar with me

## Asaf Avidan - No Words - live MUZO.FM
 - [https://www.youtube.com/watch?v=e0WXDMY50CA](https://www.youtube.com/watch?v=e0WXDMY50CA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-10-08 00:00:00+00:00

Asaf Avidan na żywo w MUZO.FM. Utwór No Words pochodzi z najnowszej płyty Asafa Avidana Anagnorisis. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Asaf Avidan: http://www.facebook.com/asafavidanmusic
Instagram Asaf Avidan: http://www.instagram.com/asafavidanmusic
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm


Asaf Avidan No Words - lyrics

Damn, these endless powers
For giving me false hope
And if I could, I would change nothing
Except the world in which we cry
I can't hear no words
In this spinning oversaturated blur
Damn, all the wildflowers
For giving up so short
And If I could, I would change something
Inside your eyes, when you were mine
I can't hear no words
In this spinning oversaturated blur
Damn, these senseless hours
Of looking for a song
And if I knew I would have nothing
Except this world in which we try
And I can't hear no words
In this spinning oversaturated blur

