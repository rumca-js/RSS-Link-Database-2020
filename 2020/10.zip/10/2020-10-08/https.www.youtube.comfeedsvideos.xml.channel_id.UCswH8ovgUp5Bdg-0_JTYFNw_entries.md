# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Trump VS Covid - Who Won?! | Russell Brand
 - [https://www.youtube.com/watch?v=mR52Cg__xYM](https://www.youtube.com/watch?v=mR52Cg__xYM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-10-08 00:00:00+00:00

Following #DonaldTrump's diagnosis with covid / coronavirus, I have a look at some of most fascinating and strange things he has said subsequently. 
With the presidential election upon us soon, is #Trump using his battle with coronavirus as a tool to win?

If you like this video, check out my other videos on Trump & politics here: https://www.youtube.com/playlist?list=PL5BY9veyhGt4_ysy1teRGQ8hl_WDdgTzS

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

