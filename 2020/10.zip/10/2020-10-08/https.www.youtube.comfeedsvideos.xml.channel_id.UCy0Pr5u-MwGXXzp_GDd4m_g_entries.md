# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## Explaining the Pandemic to my Past Self Part 3
 - [https://www.youtube.com/watch?v=Pbdk_lBCxJk](https://www.youtube.com/watch?v=Pbdk_lBCxJk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2020-10-08 00:00:00+00:00

What would happen if I tried to explain what's happening now to the June 2020 version of myself?
Part 1 here: https://youtu.be/Ms7capx4Cb8
Part 2 here: https://youtu.be/xdyDpP2s-og

