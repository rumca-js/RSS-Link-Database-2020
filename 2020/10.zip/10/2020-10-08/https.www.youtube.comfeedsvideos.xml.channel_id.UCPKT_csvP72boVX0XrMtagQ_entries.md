# Source:Cercle, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ, language:en-US

## NTO - Lac de Soi | Cercle Stories
 - [https://www.youtube.com/watch?v=2eZcYbXrI5A](https://www.youtube.com/watch?v=2eZcYbXrI5A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ
 - date published: 2020-10-09 00:00:00+00:00

NTO playing the first Cercle Stories for a live session on Lac de Soi, a 5°C lake at 2247 meters high, in collaboration with Région Dents du Midi, in Switzerland. 

Cercle Stories is our new short video concept, it's a one track live session for our Cercle Records releases. 

☞ Cercle Records: 
NTO - Lac de Soi : https://Cercle.lnk.to/ntolacdesoi

☞ Support us and get access to exclusive videos & perks: https://Cercle.lnk.to/Patreon
☞ Listen to our playlists, tracks & sets: https://Cercle.lnk.to/Playlists
☞ Subscribe to our newsletter to know about our next shows: https://Cercle.lnk.to/Members
☞ Subscribe to our YouTube channel: https://Cercle.lnk.to/ytcercle

☞ NTO
https://www.instagram.com/ntomusic/
https://www.facebook.com/nto.music
https://open.spotify.com/artist/7ry8L53T4oJtSIogGYuioq
https://music.apple.com/fr/artist/nto/128862535

Video credits:

Artist: NTO
Location: Lac de Soi, Région Dents du Midi, Suisse
Producer: Derek Barbolla
Artistic director: Philippe Tuchmann
Director: Pol Souchier
DOP, Editing & Post-production: Mathieu Glissant (Saison Unique Production)
Cameramen: Mickaël Fidjili & Mathieu Glissant
Drone pilot: Alexis Olas
FPV drone pilot: Vincent Galard assisted by Kevin Kervevan (R Project)
Technical Manager: Aurélien Moisan
Production team: Anaïs de Framond, Dan Aufseesser, Armand Prouhèze, Robert Naescher, Lionel Métraux
ODT: Tom Puippe & Thomas Leparmentier
Technicians: Loïc Gargasson, Felix Michel, Kevin Klein, Adrien Boulanger, Arnaud Colard, Emile Schaer & Luc Perrenoud
Communication: Anaëlle Rouquette
Stage design: Marvin Weymeersch & Cameron Heal

--
Special thanks to:
Région Dents du Midi and especially to Tom Puippe & Thomas Leparmentier for this amazing partnership in order to launch Cercle Stories. 
Galerie Joseph. 

______

Follow us on http://www.cercle.io

