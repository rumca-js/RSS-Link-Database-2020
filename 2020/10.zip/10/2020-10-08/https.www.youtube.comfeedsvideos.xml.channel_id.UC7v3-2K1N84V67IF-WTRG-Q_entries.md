# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## The Boys: Season 2 - FINALE (My Thoughts)
 - [https://www.youtube.com/watch?v=vo56UVlyLYE](https://www.youtube.com/watch?v=vo56UVlyLYE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-10-09 00:00:00+00:00

THE BOYS Season 2 has wrapped, so let's talk about the finale!

#TheBoys

## Hubie Halloween - Movie Review
 - [https://www.youtube.com/watch?v=cO-CUtXusFI](https://www.youtube.com/watch?v=cO-CUtXusFI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-10-08 00:00:00+00:00

Well, I suppose this counts as part as my Halloween Movie Review Extravaganza. It's an Adam Sandler Halloween Comedy on Netflix. Here's my review for HUBIE HALLOWEEN!

#HubieHalloween

