# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## IDLES - Grounds (Live on KEXP)
 - [https://www.youtube.com/watch?v=-5Kjolg-HlY](https://www.youtube.com/watch?v=-5Kjolg-HlY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-09 00:00:00+00:00

http://KEXP.ORG presents IDLES  performing "Grounds", recorded exclusively for KEXP. 

Recorded at Abbey Road Studios. Filmed and edited by Ground Work:
Director - Will Dohrn
Executive Producer - Aaron Z. Willson
Producer - Callum Harrison
Editor - Will Dohrn
Production Manager - Lana Salfiti
Director of Photography - Spike Morris
Camera Op - Austin Phillips
Camera Op - Oscar Oldershaw
Camera Assistant - Nacho Munoz Deleon
Gaffer - Helio Riberio

https://shopus.idlesband.com
https://ground-work.co
http://kexp.org

## IDLES - Model Village (Live on KEXP)
 - [https://www.youtube.com/watch?v=tE-JbxbZHTY](https://www.youtube.com/watch?v=tE-JbxbZHTY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-09 00:00:00+00:00

http://KEXP.ORG presents IDLES  performing "Model Village", recorded exclusively for KEXP. 

Recorded at Abbey Road Studios. Filmed and edited by Ground Work:
Director - Will Dohrn
Executive Producer - Aaron Z. Willson
Producer - Callum Harrison
Editor - Will Dohrn
Production Manager - Lana Salfiti
Director of Photography - Spike Morris
Camera Op - Austin Phillips
Camera Op - Oscar Oldershaw
Camera Assistant - Nacho Munoz Deleon
Gaffer - Helio Riberio

https://shopus.idlesband.com
https://ground-work.co
http://kexp.org

## IDLES - Mr. Motivator (Live on KEXP)
 - [https://www.youtube.com/watch?v=soPHPXfbg8w](https://www.youtube.com/watch?v=soPHPXfbg8w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-09 00:00:00+00:00

http://KEXP.ORG presents IDLES  performing "Mr. Motivator", recorded exclusively for KEXP. 

Recorded at Abbey Road Studios. Filmed and edited by Ground Work:
Director - Will Dohrn
Executive Producer - Aaron Z. Willson
Producer - Callum Harrison
Editor - Will Dohrn
Production Manager - Lana Salfiti
Director of Photography - Spike Morris
Camera Op - Austin Phillips
Camera Op - Oscar Oldershaw
Camera Assistant - Nacho Munoz Deleon
Gaffer - Helio Riberio

https://shopus.idlesband.com
https://ground-work.co
http://kexp.org

## IDLES - War (Live on KEXP)
 - [https://www.youtube.com/watch?v=6Blcq7Ske7I](https://www.youtube.com/watch?v=6Blcq7Ske7I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-09 00:00:00+00:00

http://KEXP.ORG presents IDLES  performing "War", recorded exclusively for KEXP. 

Recorded at Abbey Road Studios. Filmed and edited by Ground Work:
Director - Will Dohrn
Executive Producer - Aaron Z. Willson
Producer - Callum Harrison
Editor - Will Dohrn
Production Manager - Lana Salfiti
Director of Photography - Spike Morris
Camera Op - Austin Phillips
Camera Op - Oscar Oldershaw
Camera Assistant - Nacho Munoz Deleon
Gaffer - Helio Riberio

https://shopus.idlesband.com
https://ground-work.co
http://kexp.org

## IDLES performance and interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=uDnVWgkfH1E](https://www.youtube.com/watch?v=uDnVWgkfH1E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-09 00:00:00+00:00

http://KEXP.ORG presents IDLES sharing songs recorded exclusively for KEXP and talking with Kevin Cole. Recorded Thursday, October 1, 2020.

Songs:
Model Village
Mr. Motivator
War
Grounds

Recorded at Abbey Road Studios. Filmed and edited by Ground Work:
Director - Will Dohrn
Executive Producer - Aaron Z. Willson
Producer - Callum Harrison
Editor - Will Dohrn
Production Manager - Lana Salfiti
Director of Photography - Spike Morris
Camera Op - Austin Phillips
Camera Op - Oscar Oldershaw
Camera Assistant - Nacho Munoz Deleon
Gaffer - Helio Riberio

https://shopus.idlesband.com
https://ground-work.co
http://kexp.org

