# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Colin Quinn Remembers Tough Crowd
 - [https://www.youtube.com/watch?v=SYSESexbI3A](https://www.youtube.com/watch?v=SYSESexbI3A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-10-08 00:00:00+00:00

#1547 w/Colin Quinn:
https://open.spotify.com/episode/11JDrGSsaOIczYZhWUTsNh

## Colin Quinn on Why Post Lockdown NYC is Not Like NYC in the 80's
 - [https://www.youtube.com/watch?v=cSYxu6wE5jE](https://www.youtube.com/watch?v=cSYxu6wE5jE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-10-08 00:00:00+00:00

#1547 w/Colin Quinn:
https://open.spotify.com/episode/11JDrGSsaOIczYZhWUTsNh

## Colin Quinn's Odd Encounter with Bill Cosby
 - [https://www.youtube.com/watch?v=EmxFDvxO07g](https://www.youtube.com/watch?v=EmxFDvxO07g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-10-08 00:00:00+00:00

#1547 w/Colin Quinn:
https://open.spotify.com/episode/11JDrGSsaOIczYZhWUTsNh

