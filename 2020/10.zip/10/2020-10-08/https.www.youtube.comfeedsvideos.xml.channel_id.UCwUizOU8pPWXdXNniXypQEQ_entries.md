# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## If the Pandemic Thinking Was Applied To Everything
 - [https://www.youtube.com/watch?v=dEkxWTsBINI](https://www.youtube.com/watch?v=dEkxWTsBINI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-10-08 00:00:00+00:00

Get your Magnesium Breakthrough Here - https://MagnesiumBreakthrough.com/JP

This video will show you what it would be like if the pandemic thinking was applied to everything. Using emotional reactions with zero logic would make us better off in all areas of our lives.

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

