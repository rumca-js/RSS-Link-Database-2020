# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## The History Guy Lance Geiger On The Subjects That Surprised Him Most | Random Thursday
 - [https://www.youtube.com/watch?v=7K71gJUQXfY](https://www.youtube.com/watch?v=7K71gJUQXfY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2020-10-08 00:00:00+00:00

Listen to the full interview with Lance here: https://answerswithjoe.com/interview-lance-geiger-history-guy/


Lance Geiger, also known as The History Guy on YouTube revels in stories of forgotten history. I've been following his channel for a while and with such a crazy year going on, I wanted to talk to him to get his historical perspective, and it didn't disappoint.

Check out his channel here:
https://www.youtube.com/channel/UC4sEmXUuWIFlxRIFBRV6VXQ


Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

