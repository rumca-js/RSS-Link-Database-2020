# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## LET'S DEBATE: WoT Hype🥳 Characterization 💏 Teeth🦷
 - [https://www.youtube.com/watch?v=pIXn2QbetA8](https://www.youtube.com/watch?v=pIXn2QbetA8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-10-09 00:00:00+00:00

Let’s debate the sci-fi and fantasy genres! 

Checkout campfire for free the month of October here: https://www.campfiretechnology.com/blaze/?utm_source=youtube&utm_medium=video&utm_campaign=GreeneQ420 

Art Provided by: https://www.instagram.com/yoichi.art/

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

## The Watch - Live Trailer Reaction ( Discworld Adaptation )
 - [https://www.youtube.com/watch?v=R5w9DtMk0Jw](https://www.youtube.com/watch?v=R5w9DtMk0Jw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-10-09 00:00:00+00:00

Let's talk about The Watch a discworld adaptation. 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

## Lord Of The Rings - Review (Does It Hold Up?)
 - [https://www.youtube.com/watch?v=ZKabGaa9deE](https://www.youtube.com/watch?v=ZKabGaa9deE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-10-08 00:00:00+00:00

My review of the Lord of the Rings books through the lens of how they hold up to a modern audience. 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

