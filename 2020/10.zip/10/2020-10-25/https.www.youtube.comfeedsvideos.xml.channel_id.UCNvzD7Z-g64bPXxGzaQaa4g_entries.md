# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Is Bethesda Taking Too Long With Elder Scrolls 6?
 - [https://www.youtube.com/watch?v=ZnpruoKzyiM](https://www.youtube.com/watch?v=ZnpruoKzyiM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-10-26 00:00:00+00:00

The Elder Scrolls 6 has been announced, but with no confirmed release date all we've been able to do is speculate about gameplay and in-game location. Is Bethesda taking too long? Let's dive in.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Sources:
https://www.dsogaming.com/news/dont-expect-any-news-for-the-elder-scrolls-6-or-starfield-in-2020/
https://www.denofgeek.com/games/the-elder-scrolls-6-how-long-is-it/
https://bethesda.net/en/article/4IwKWIj174Cb2QNTTtBAEb/todd-howard-on-joining-xbox
https://www.pcgamer.com/skyrim-grandma-shirley-curry-will-be-in-the-elder-scrolls-6/
https://www.reddit.com/r/TESVI/comments/jcecc3/microsoft_has_seemingly_made_a_deal_with_an/
https://www.reddit.com/r/TESVI/comments/gnqywb/in_case_anyone_needed_any_more_confirmation_that/ 
https://kotaku.com/xbox-boss-phil-spencer-on-series-x-launch-halo-infinit-1845392984

## 10 CRAZY Things PS4 Owners Have Done
 - [https://www.youtube.com/watch?v=ORfsgOtGOfo](https://www.youtube.com/watch?v=ORfsgOtGOfo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-10-25 00:00:00+00:00

PlayStation fans have done some CRAZY things surrounding their PS4s and their fandom. Here are the weirdest examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

#10
https://www.dailymail.co.uk/news/article-4940290/Gamer-sets-PS4-TV-play-McDonalds.html
+
https://twitter.com/coyotetrips/status/1218197418707210243

#9
https://www.gamesradar.com/teen-buys-ps4-for-dollar9-by-disguising-it-as-fruit-gets-arrested-after-trying-it-again/

#8
https://soranews24.com/2014/02/24/we-try-to-get-the-first-ps4-sold-in-japan-and-so-does-this-guy-dressed-like-a-move-controller/

#7
https://kotaku.com/garbage-man-finds-working-ps4-in-the-trash-1818567831

#6
https://www.dailymail.co.uk/news/article-6882559/Man-tells-mothers-murder-trial-raised-alarm-console-finding-father-lying-dead.html

#5
https://www.playstationlifestyle.net/2018/05/21/psn-user-banned-for-claiming-his-dad-works-for-sony/

#4
https://kotaku.com/teenager-sentenced-to-40-years-in-prison-for-killing-ma-1782499393

#3  
https://www.instagram.com/end_of_line_designs/

#2
https://www.vg247.com/2020/02/01/guy-turns-treadmill-ps4-controller-plays-death-stranding/
+
https://www.youtube.com/watch?v=jR_HbXOajEc&feature=emb_title&ab_channel=CyclicoderJ

#1
https://imgur.com/r/playstation/LmVDP
https://www.reddit.com/r/playstation/comments/619lnc/my_ps4_pro_cooling_mod/
+
https://www.youtube.com/watch?v=yxdE14j1PNE&feature=emb_title&ab_channel=FanlessGuy



BONUS
https://hackaday.com/2015/02/05/add-extra-storage-to-your-ps4-with-retro-flair/

## Top 10 NEW Games of November 2020
 - [https://www.youtube.com/watch?v=YmijwlCRMws](https://www.youtube.com/watch?v=YmijwlCRMws)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-10-25 00:00:00+00:00

November 2020 is filled with tons of games to pay attention to thanks to the upcoming launch of PS5 /Xbox Series X and beyond. Here's a roundup of the big ones.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1



#10 Destruction AllStars 

Platform: PS5

Release date: November 12, 2020



#9 Godfall 

Platform: PC, PS5

Release date: November 12, 2020



#8 Sackboy: A Big Adventure 

Platform: PS5, PS4

Release date: November 12, 2020



#7 Dirt 5

XSX November 10 

PS4, XBOX ONE, PC November 6, 2020

PS5 November 12, 2020



#6 Demon's Souls 

Platform:  PS5

Release date: November 12, 2020



#5 Yakuza: Like a Dragon  

Platform: November 10, 2020 PS4

PC XBOX ONE XSX November 10, 2020



#4 Assassin's Creed Valhalla 

Platform: PC, XSX, PS4, XBOX ONE, Stadia November 10

PS5 November 12, 2020



#3 Marvel's Spider-Man PS5 Miles Morales 

Platform: PS5, PS4

Release date: November 12, 2020



#2 Call of Duty: Black Ops Cold War 

Platform: PC, PS5, XSX, PS4, XBOX ONE 

Release date: November 13, 2020



#1 Cyberpunk 2077 

Platform: PC, PS4, XBOX ONE, Stadia


Release date: November 19, 2020





BONUS

The Pathless 

Platform: PC, PS5, PS4 

Release date: November 12, 2020



Need for Speed: Hot Pursuit Remastered 

Platform : PC, PS4, XBOX ONE

Release date : November 6, 2020

Switch 13 November 2020

