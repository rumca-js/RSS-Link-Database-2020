# Source:Snazzy Labs, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w, language:en-US

## This Linux PC Runs macOS Faster Than a Real Mac
 - [https://www.youtube.com/watch?v=-Otg7JFMuVw](https://www.youtube.com/watch?v=-Otg7JFMuVw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w
 - date published: 2020-10-25 00:00:00+00:00

This hackintosh isn't a hacintosh... it's actually a Linux PC running macOS as a virtualized OS. And it's fast. Like, really fast.

Manjaro KDE Plasma: https://manjaro.org/downloads/official/kde/
Install snapd: https://snapcraft.io/docs/installing-snap-on-manjaro-linux
Sosumi: https://snapcraft.io/sosumi
macOS-Simple-KVM: https://github.com/foxlet/macOS-Simple-KVM
If macOS-Simple-KVM documentation isn't simple enough, this is a more in-depth guide: https://passthroughpo.st/new-and-improved-mac-os-tutorial-part-1-the-basics/

Purchase an AMD Ryzen 5 3600 gaming PC - https://amzn.to/31DH4Oa

Subscribe to my podcast Flashback! - http://relay.fm/flashback
Follow me on Twitter - http://twitter.com/snazzyq
Follow me on Instagram - http://instagram.com/snazzyq

