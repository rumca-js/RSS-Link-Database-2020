# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## iPhone 12 Review: Just Got Real!
 - [https://www.youtube.com/watch?v=X1b3C2081-Q](https://www.youtube.com/watch?v=X1b3C2081-Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-10-25 00:00:00+00:00

iPhone 12 is the first of a lot of things for the iPhone. It's pretty damn good.
That shirt! http://shop.MKBHD.com
iPhone 12 cases: https://dbrand.com/iphone-12-cases

0:00 Intro
0:57 New Flat Design
2:17 Ceramic Shield
3:58 MagSafe
7:43 Battery Life
8:08 The Display
8:55 5G Just Got Real
12:30 New Cameras
14:21 HDR Just Got Real
16:05 iPhone Stuff
17:14 TL;DW

The 5G song: https://youtu.be/59T1gJHURMo

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: On and On Pt 2 by Hocus Pocus
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by Apple for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

