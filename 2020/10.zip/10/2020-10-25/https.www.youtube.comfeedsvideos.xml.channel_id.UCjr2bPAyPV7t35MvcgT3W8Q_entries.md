# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## Your Phone Is Listening - Ultrasonic Cross-Device Tracking
 - [https://www.youtube.com/watch?v=j1FfVK6sj4I](https://www.youtube.com/watch?v=j1FfVK6sj4I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2020-10-26 00:00:00+00:00

Join my channel and become a member to enjoy perks https://www.youtube.com/channel/UCjr2bPAyPV7t35MvcgT3W8Q/join
Support me through Patreon: https://www.patreon.com/thehatedone 

- or donate anonymously:

Monero: 84DYxU8rPzQ88SxQqBF6VBNfPU9c5sjDXfTC1wXkgzWJfVMQ9zjAULL6rd11ASRGpxD1w6jQrMtqAGkkqiid5ef7QDroTPp

Bitcoin: 1HkDxXAVDFhBHSyRjam5WW5uoY88sxn5qz

Sources
Ultrasonic cross-device tracking: https://intellisec.de/pubs/2016-batmobile.pdf
https://techcrunch.com/2014/07/24/silverpush-audio-beacons/
https://www.wired.com/2016/11/block-ultrasonic-signals-didnt-know-tracking/
https://www.cbsnews.com/news/google-removes-apps-that-use-ultrasonic-frequencies-to-track-users/
https://www.zdnet.com/article/hundreds-of-apps-are-using-ultrasonic-sounds-to-track-your-ad-habits/
https://www.wired.com/story/ultrasonic-signals-wild-west-of-wireless-tech/
https://arstechnica.com/information-technology/2016/11/how-to-block-the-ultrasonic-signals-you-didnt-know-were-tracking-you/
https://arstechnica.com/tech-policy/2015/11/beware-of-ads-that-use-inaudible-sound-to-link-your-phone-tv-tablet-and-pc/
https://www.forbes.com/sites/thomasbrewster/2015/11/16/silverpush-ultrasonic-tracking/
https://intellisec.de/pubs/2016-batmobile.pdf
Ultrasonic malware https://arstechnica.com/information-technology/2013/12/scientist-developed-malware-covertly-jumps-air-gaps-using-inaudible-sound/
Gyroscope ultrasonic tracking https://caslab.csl.yale.edu/publications/matyunin2018zeropermission.pdf
Passive-speaker ultrasonic tracking https://www.sciencedirect.com/science/article/pii/S2214212619304697
Soundwave hacking https://fortune.com/2016/10/30/soundwave-hacking/
https://www.blackhat.com/eu-16/briefings.html#talking-behind-your-back-attacks-and-countermeasures-of-ultrasonic-cross-device-tracking
Apple https://appleinsider.com/articles/20/09/08/future-apple-devices-may-use-sound-outside-of-human-hearing-to-signal-each-other
https://www.comparitech.com/blog/information-security/block-ultrasonic-tracking-apps/
Fileless malware https://www.comparitech.com/blog/information-security/fileless-malware-attacks/ 
Cross-device tracking explained https://cdt.org/insights/cross-device-tracking-requires-strong-privacy-and-security-standards/
https://www.campaignlive.com/article/why-cross-device-tracking-latest-obsession-marketers/1361742
https://www.campaignlive.com/article/retailers-shoppers-resist-apples-ibeacon-signals/1363907
https://arstechnica.com/gadgets/2015/07/meet-googles-eddystone-a-flexible-open-source-ibeacon-fighter/
Ultrasound firewall https://phys.org/news/2018-05-ultrasound-firewall-mobile.html
Credits
Music by: CO.AG Music https://www.youtube.com/channel/UCcavSftXHgxLBWwLDm_bNvA

Follow me:
https://twitter.com/The_HatedOne_
https://www.bitchute.com/TheHatedOne/
https://www.reddit.com/r/thehatedone/
https://www.minds.com/The_HatedOne

The footage and images featured in the video were for critical analysis, commentary and parody, which are protected under the Fair Use laws of the United States Copyright act of 1976.

