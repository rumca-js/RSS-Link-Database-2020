# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Céu - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=B4fyViIOmCM](https://www.youtube.com/watch?v=B4fyViIOmCM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-26 00:00:00+00:00

http://KEXP.ORG presents Céu sharing songs recorded exclusively for KEXP and talking with Wo' Pop's Darek Mazzone.

Songs:
Arrastar-te-ei
Pardo
Forçar o verão
Lendo
Coreto

http://www.ceumusic.com
http://kexp.org

## Céu - Arrastar-te-ei (Live on KEXP at Home) (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=cAEdDKjV4e8](https://www.youtube.com/watch?v=cAEdDKjV4e8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-26 00:00:00+00:00

http://KEXP.ORG presents Céu performing live, recorded exclusively for KEXP.

Watch full all songs and interview with KEXP's Darek Mazzone here: https://youtu.be/B4fyViIOmCM

http://www.ceumusic.com
http://kexp.org

## Céu - Coreto (Live on KEXP at Home) (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=mpFVLoiGZxU](https://www.youtube.com/watch?v=mpFVLoiGZxU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-26 00:00:00+00:00

http://KEXP.ORG presents Céu performing live, recorded exclusively for KEXP.

Watch full all songs and interview with KEXP's Darek Mazzone here: https://youtu.be/B4fyViIOmCM

http://www.ceumusic.com
http://kexp.org

## Céu - Forçar o verão (Live on KEXP at Home) (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=ButcULovkAI](https://www.youtube.com/watch?v=ButcULovkAI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-26 00:00:00+00:00

http://KEXP.ORG presents Céu performing live, recorded exclusively for KEXP.

Watch full all songs and interview with KEXP's Darek Mazzone here: https://youtu.be/B4fyViIOmCM

http://www.ceumusic.com
http://kexp.org

## Céu - Lenda (Live on KEXP at Home) (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=lP_NLy70uNQ](https://www.youtube.com/watch?v=lP_NLy70uNQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-26 00:00:00+00:00

http://KEXP.ORG presents Céu performing live, recorded exclusively for KEXP.

Watch full all songs and interview with KEXP's Darek Mazzone here: https://youtu.be/B4fyViIOmCM

http://www.ceumusic.com
http://kexp.org

## Céu - Pardo (Live on KEXP at Home) (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=g2QwPPPMP5o](https://www.youtube.com/watch?v=g2QwPPPMP5o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-26 00:00:00+00:00

http://KEXP.ORG presents Céu performing live, recorded exclusively for KEXP.

Watch full all songs and interview with KEXP's Darek Mazzone here: https://youtu.be/B4fyViIOmCM

http://www.ceumusic.com
http://kexp.org

