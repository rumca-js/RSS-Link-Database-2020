# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## The All Corsair Gaming Setup!
 - [https://www.youtube.com/watch?v=wEIKFxHzzac](https://www.youtube.com/watch?v=wEIKFxHzzac)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-10-26 00:00:00+00:00

Thanks, Corsair, for sponsoring this video!

Corsair’s stable of products is massive, covering everything from mice and keyboards to pc cases and SSDs. You name it, they probably have it covered. So what do you do with that knowledge? Build an entire game streaming setup of course!! Let’s see how far we can really get with an all Corsair build.

Buy Corsair 275R AirFlow
On Amazon (PAID LINK): https://geni.us/Epea
On Best Buy (PAID LINK): https://shop-links.co/1721651042747329821
On Newegg (PAID LINK): https://geni.us/QVvPZZ

Buy AMD Ryzen 3700x
On Amazon (PAID LINK): https://geni.us/eAKzXPH
On Best Buy (PAID LINK): https://shop-links.co/1721651066176804391
On Newegg (PAID LINK): https://geni.us/nwMfC
On B&H (PAID LINK): https://geni.us/xRIBBVp

Buy Corsair MP600
On Amazon (PAID LINK): https://geni.us/ggB8
On Best Buy (PAID LINK): https://shop-links.co/1721651082975659173
On Newegg (PAID LINK): https://geni.us/yZRv

Buy Corsair 32GB Vengeance LPX DDR4 3200Mhz RAM
On Amazon (PAID LINK): https://geni.us/5EAZP
On Newegg (PAID LINK): https://geni.us/FJIS
On B&H (PAID LINK): https://geni.us/IIZnp

Buy Corsair H100i Pro RGB
On Amazon (PAID LINK): https://geni.us/RUsJ0W
On Best Buy (PAID LINK): https://shop-links.co/1721651111901879658
On Newegg (PAID LINK): https://geni.us/vqnfR

Buy Corsair RM 750x PSU
On Amazon (PAID LINK): https://geni.us/0gHX
On Best Buy (PAID LINK): https://shop-links.co/1721651143348813517
On Newegg (PAID LINK): https://geni.us/sqLWi

Buy Corsair K100 Optical Mechanical keyboard
On Amazon (PAID LINK): https://geni.us/fBLD
On Best Buy (PAID LINK): https://shop-links.co/1721651174086154723
On Newegg (PAID LINK): https://geni.us/Acba

Buy Corsair Dark Core RGB Pro
On Amazon (PAID LINK): https://geni.us/r8FQaL
On Best Buy (PAID LINK): https://shop-links.co/1721651194867528604
On Newegg (PAID LINK): https://geni.us/Ui8K04v

Buy Corsair iCUE LT100 Smart Lighting Tower
On Amazon (PAID LINK): https://geni.us/B6AXOz
On Best Buy (PAID LINK): https://shop-links.co/1721651224503418604
On Newegg (PAID LINK): https://geni.us/pczcLnm

Buy Elgato Stream Deck
On Amazon (PAID LINK): https://geni.us/SDrxU
On Best Buy (PAID LINK): https://shop-links.co/1721651244286490733
On Newegg (PAID LINK): https://geni.us/dPs3
On B&H (PAID LINK): https://geni.us/lAF0Yu

Buy Elgato Ring Light
On Amazon (PAID LINK): https://geni.us/bugdIfu
On Best Buy (PAID LINK): https://shop-links.co/1721651273832825363

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://lmg.gg/FQPB2


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Private Internet Access VPN: https://lmg.gg/pialinus2
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

## Water Cooling the RTX 3090 is... More Complicated
 - [https://www.youtube.com/watch?v=Pzh98abhAio](https://www.youtube.com/watch?v=Pzh98abhAio)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-10-25 00:00:00+00:00

*Free 32GB Flash Drive & 32GB Micro SD Card: https://rebrand.ly/x7ym0
Join the Micro Center Community: https://rebrand.ly/3uey2
Micro Center Custom PC Builder: https://rebrand.ly/6goyb

Save 10% and Free Worldwide Shipping at Ridge Wallets by using offer code LINUS at https://www.ridge.com/LINUS

We want to build some water cooled PCs with the RTX 3090, but just how small of a radiator can we use and still have reasonable temps?

Buy ASUS ROG Strix RTX 3090 GPU
On Amazon (PAID LINK): https://geni.us/lc5Ku
On Best Buy (PAID LINK): https://shop-links.co/1721650990659551270
On Newegg (PAID LINK): https://geni.us/c7AqSn

Buy EK-Quantum Vector Strix RTX 3080/3090 D-RGB
On EK's site at https://lmg.gg/bcqmp

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1261579-can-this-cool-an-rtx-3090/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Private Internet Access VPN: https://lmg.gg/pialinus2
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

