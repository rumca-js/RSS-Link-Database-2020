# Source:BezPlanu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g, language:pl-PL

## Tu była "zielona" stolica Europy - Lazarat
 - [https://www.youtube.com/watch?v=n2RIoOXztps](https://www.youtube.com/watch?v=n2RIoOXztps)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g
 - date published: 2020-10-25 00:00:00+00:00

Polak w Albanii: https://bit.ly/3cYgl3o
(wspomniany odcinek z Lazaratu i Gjirokaster - link podam po publikacji)

Filmy o Lazaracie:
https://bit.ly/3jm2rtu
https://bit.ly/2TkAtnr

Wszystkie odcinki chronologicznie: http://bit.ly/2MqAO7Q
(można też klikać w kartę "Następny odcinek" pojawiającą się pod koniec każdego filmu po prawej stronie u góry)

Wsparcie Patronite: http://bit.ly/2KsFTZk 
Instagram: http://instagram.com/bezplanu_czukesky 
Facebook: https://www.facebook.com/BezPlanu.tv 

Czas akcji: 14 października 2019 r. (Albania), 17 października 2020 r. (Filipiny)

