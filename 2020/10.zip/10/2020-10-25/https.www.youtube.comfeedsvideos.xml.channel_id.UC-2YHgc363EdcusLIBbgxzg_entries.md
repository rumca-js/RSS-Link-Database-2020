# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## The Funeral Industry Is Burying Us | Answers With Joe
 - [https://www.youtube.com/watch?v=25Iyps1irjc](https://www.youtube.com/watch?v=25Iyps1irjc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2020-10-26 00:00:00+00:00

For 20% off your first order, visit http://www.MackWeldon.com/joescott AND ENTER PROMO CODE: joescott
The funeral industry is a $16 billion industry that has an enormous environmental footprint. The numbers are staggering, really. But there are options that we can make that can change that. It just requires us to think about some pretty heavy stuff.

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

https://www.aljazeera.com/news/2020/10/3/egypt-unveils-59-ancient-coffins-in-major-archaeological-discover

https://www.theatlantic.com/technology/archive/2015/08/koko-the-talking-gorilla-sign-language-francine-patterson/402307/

https://www.lhlic.com/consumer-resources/average-funeral-cost/

http://www.nhfuneral.org/uploads/1/1/7/5/117550115/the_science_behind_green_burial.pdf

https://science.howstuffworks.com/environmental/green-science/mushroom-burial-suit.htm

http://coeio.com/infinity-burial-project/

https://www.nerdwallet.com/blog/insurance/things-to-be-after-you-die/

0:00 - :20 Shortest Intro Ever
:20 - 2:25 Ancient Burial Practices
2:25 - 3:36 How Embalming Became Popular
3:36 - 5:42 THE GRUESOME STUFF - How Embalming Works
5:42 - 8:51 The Environmental impact of Funerals
8:51 - 13:03 Green Burial Options
13:03 - 15:30 Interesting and Bizarre Funeral Options
15:30 - 18:37 Sponsor Read And Close

