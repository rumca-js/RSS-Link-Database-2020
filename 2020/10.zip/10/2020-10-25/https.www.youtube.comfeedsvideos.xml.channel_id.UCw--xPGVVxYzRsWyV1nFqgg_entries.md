# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Lord Of The Rings 2020 Recast!
 - [https://www.youtube.com/watch?v=IA9JZqvyFNw](https://www.youtube.com/watch?v=IA9JZqvyFNw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-10-25 00:00:00+00:00

Casting the lord of the ring movies with actors currently working in hollywood today that might fit the part. This was WAAYYYY harder than I thought it would be. Why is it so hard to cast hobbits?! Anyway, enjoy a 2020 recasting of the lord of the rings! 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

