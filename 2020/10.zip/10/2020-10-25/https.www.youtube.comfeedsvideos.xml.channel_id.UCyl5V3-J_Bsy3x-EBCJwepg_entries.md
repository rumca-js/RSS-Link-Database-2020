# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Babylon Bee Writers Read Hilarious Hate Mail
 - [https://www.youtube.com/watch?v=eClufDCikB4](https://www.youtube.com/watch?v=eClufDCikB4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-10-26 00:00:00+00:00

Every week, we read delicious hate mail from our haters. This one calls us out for partaking in “destructive activities.”

See the full show here:
https://www.youtube.com/watch?v=IVv0u5QprUE&t=770s

If you want to become a subscriber and be able to see more hate mail reads go to this link
https://babylonbee.com/plans

Subscribe to the Babylon Bee to help us continue to read hate mail in mildly offensive accents

Hit the Bell to get your daily dose of fake news that you can trust.

## Jordan Peterson Returns To Find Americans Worshiping Golden Statue Of Karl Marx
 - [https://www.youtube.com/watch?v=GSr4dJPvSRE](https://www.youtube.com/watch?v=GSr4dJPvSRE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-10-26 00:00:00+00:00

Dr. Jordan Peterson emerged this week and was dismayed to find millions of Americans worshipping at the altar of a golden Karl Marx statue. Overtaken with righteous anger, he smashed his stone tablets containing 12 Rules for Life into tiny pieces.

Subscribe to the Babylon Bee to help us continue to read hate mail in mildly offensive accents.

Hit the Bell to get your daily dose of fake news that you can trust.

