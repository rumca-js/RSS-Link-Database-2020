# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week: Jak znaleźć miłość oraz słuchawki Huawei Freebuds Pro, Huawei Mate 40pro, autopilot Tesla
 - [https://www.youtube.com/watch?v=Nkjhh1oXfzI](https://www.youtube.com/watch?v=Nkjhh1oXfzI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-10-25 00:00:00+00:00

Jak przestraszyć niedźwiedzia? Oraz jak uczciwie przetestować słuchawki firmy, która Cię nie lubi? Odpowiedzi na wszystkie te pytania znajdziecie w dzisiejszym odcinku!

Moje sociale:
Insta: http://bit.ly/InstaKlawiatur 
Twitter: http://bit.ly/TTKlawitera
FB: http://bit.ly/FBKlawiatur
Mieszko: https://bit.ly/3jthzFs

Źródła:
Recenzja Pixela 5 MKBHD: https://bit.ly/31F6paB
Słuchawki Huawei Freebuds Pro: http://bit.ly/2WuJZpz
Huawei Mate 40 pro: https://bit.ly/3dWHrIP
Monster Wolf: https://cnet.co/3dXvH8O
Autopilot w Tesli: https://bit.ly/3ju7ubo
WeChat i TikTok jednak zostają w USA: https://bit.ly/2J1yJgN
Fleetwood Mac wraca dzięki TikTokowi: https://bit.ly/2HteIyZ

