# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Apex Legends - Official “Promise” Stories From The Outlands Cinematic Trailer
 - [https://www.youtube.com/watch?v=EG2BpTNF5Fk](https://www.youtube.com/watch?v=EG2BpTNF5Fk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-10-26 00:00:00+00:00

Nearly a century ago, Dr. Mary Somers was hired to solve a cataclysmic energy crisis. Her search for answers would take her to the edge of the universe. Before Mary left Olympus, she promised her son she’d return. But was it a promise she’d be able to keep?

## Watch Dogs: Legion’s Recruiting Is Hilarious
 - [https://www.youtube.com/watch?v=AIi_ztm_--k](https://www.youtube.com/watch?v=AIi_ztm_--k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-10-26 00:00:00+00:00

Watch Dogs: Legion is an open-world game set in London where you recruit almost anyone and add their funny, useful, and eccentric skills to your team’s roster.

In trailers for the game, Ubisoft has advertised that you can recruit practically anyone in Watch Dogs Legion. Of course, that doesn't mean you should.

In the video above, we walk through some of our favorite recruits. These men and women are the best of the best (in our humble opinion, anyway), and we encourage you to keep an eye out for them when you jump into Watch Dogs Legion.

When Ubisoft says that you can recruit almost anyone in Watch Dogs Legion, the developer means it. Our list of favorite recruits includes a shit-kicking granny (yes, it's that one--you've all seen her), a 70-year dominatrix with a powerful spiked bat, a gold-colored performance artist, and a sex worker with a mean spending habit.

Each brings their own unique skill set to the table, whether that's silently taking out enemies, antagonizing guards, hacking computers, sabotaging equipment, beating baddies to a pulp, or pulling off perfect shots in the middle of a firefight. Humans are inherently flawed though. So recruits can have notable weaknesses too--some are just for laughs but others can pose genuine problems that you'll have to consider before putting them into the field. 

Watch Dogs Legion launches for Xbox One, PS4, and PC on October 29. Want to play the game on next-gen? You'll have to wait a bit longer--Legion releases for Xbox Series X|S on November 10 and PS5 on November 12.

## Xbox Series X|S – Official Next-Gen Walkthrough – Full Demo
 - [https://www.youtube.com/watch?v=F0dnrY2TnWA](https://www.youtube.com/watch?v=F0dnrY2TnWA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-10-26 00:00:00+00:00

Please enjoy this full demo walkthrough of the Xbox Series X|S platform experience – including UI/UX, refreshed interface, dashboard design, and more – ahead of the November 10th next-gen launch.

## Mario Kart Live Vs. My Cats
 - [https://www.youtube.com/watch?v=WtN9i1Y7BJg](https://www.youtube.com/watch?v=WtN9i1Y7BJg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-10-25 00:00:00+00:00

Mario Kart Live brings racing into your living room, making your home--and your pets--an obstacles to overcome. So how does it fare against two cats in a studio apartment?

Mario Kart Live for Nintendo Switch lives up to its name, bringing Mario Kart into reality with its remote control Mario Kart that you can race through your own customizable courses. Everyone's living situation will make for their own unique obstacles and hurdles to overcome depending on the shape and size of the room you're playing in.

For Kurt Indovina, his studio apartment isn't the only obstacle he has to maneuver—he also has two cats. In this video, Kurt builds a course in his apartment and puts it to the test while trying to also dodge and steer around Mario's new towering foes: his two cats named Megatron and Lili. 

Controlling the kart with the Nintendo Switch, Kurt gets to see his living room, and cats, from a point of view like he’s never seen before thanks to the camera attached to the remote control Mario Kart. How will the cats fare against Mario as he zips around the floors of Kurt's humble abode?

Don't worry, no cats were harmed while making this video. Kurt loves them far too much.

