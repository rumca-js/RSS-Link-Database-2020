# Source:The Linux Experiment, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw, language:en-US

## This Linux laptop is a beast - Juno Computers Neptune 15 First Impressions
 - [https://www.youtube.com/watch?v=IFrVSpczsFU](https://www.youtube.com/watch?v=IFrVSpczsFU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw
 - date published: 2020-10-25 00:00:00+00:00

I received this beast on tuesday. It's made by a company you might not have heard of, called Juno computers. They operate ouf of London, and much like Slimbook or Tuxedo, they offer laptops based on Clevo designs, as well as desktops.

Disclaimer: I haven't received any money for this video, and I don't get to keep the laptop either, so be nice ;) 

Join this channel to get access to a monthly patroncast and vote on the next topics I'll cover:
https://www.youtube.com/channel/UC5UAwBUum7CPN5buc-_N1Fw/join

Support the channel on Patreon: 
https://www.patreon.com/thelinuxexperiment

Follow me on Twitter : http://twitter.com/thelinuxEXP

My Gaming on Linux Channel: https://www.youtube.com/channel/UCaw_Lz7oifDb-PZCAcZ07kw

Follow me on LBRY: https://lbry.tv/@TheLinuxExperiment:e

The Linux Experiment merch: get your goodies there! https://teespring.com/en-GB/stores/the-linux-experiment

This one here is the Neptune 15. It's a 15.6'' laptop, with a full HD IPS panel, running at 144hz. It's all made out of black aluminium, and it's pretty lightweight for the power it packs: 4.4 pounds, or 2 kilos, for a 10th gen intel core i7 CPU, with 8 cores and 16 threads, an RTX 2060 with 6gb of memory, and 16gb of RAM. My test unit came with 256Gb of SSD, but you can actually configure that up: it can go up to and RTX2080 Super Max-Q, 64Gb of RAM, and 4Tb of storage.

They have multiple keyboard options, mine came with as US qwerty keyboard, but you could get a bunch of other layouts as well.

The I/O is pretty excellent. On the left side, you've got a micro SD card slot, a USB A port, a headset and a microphone jack. On the right side, you have 2 more USB A, and an ethernet port

And on the back, a minidisplay port, an HDMI port, the plug for the barrel charger, and a thunderbolt 3 port for data, not charging. It didn't seem to be recognized by GNOME though, but maybe it only activates with something plugged in.


Now that it's out of the box, and I had a few days to play around with it, here are some first impressions.

First, that panel. It's good. It doesn't go ultra bright, but it's matte, so basically no reflections whatsoever. And that 144hz refresh rate is simply amazing. I didn't think this mattered at all, but after using it for a few hours each day, going back to my 60hz displays on my desktop was a bit of a shock. It really does make a difference.
The viewing angles are fantastic as well, with no loss of color, or color shifting.


The webcam is pretty standard, at 720p, nothing special, you won't look like a potato during your video conferences, but it's nothing to write home about.

I thought maybe the power button would double as a fingerprint scanner, but it doesn't seem to be the case, but you still get a full size keyboard, with number pad, and, more importantly for some people, RGB. You can tweak the backlight to whatever color you want, and Juno Computers included a small utility in the top bar to let you tweak that.

By the way, another utility allows you to change the fan speed if you want, and switch profiles between the intel,  or nvidia card, with an "nvidia on demand mode", which pairs well with GNOME's ability to open apps using the dedicated GPU.

Other than that, the Ubuntu install is a pretty much stock OEM install of 20.04, with the latest Nvidia drivers included as well.

The build quality is very nice, thanks to the aluminium, we'll have to see if the black texture doesn't scratch off too easily after a few more weeks of use. The screen hinge is pretty sturdy, and doesn't wobble much.

There is a bit of give around the keyboard when you type, and you'll definitely see it, but the keys feel good as well, good amount of travel, and satisfying, muffled sound. It lacks a bit  of bounceback for my taste, but it's still pretty good. There is also some amount of flex on the back of the panel, but that's not somewhere where you'll be pressing most of the time, so it's not worrying.

Now, the windows key here, I could have done without. Building a Linux computer means selling it to Linux guys, and making the extra effort to remove that key and replace it by something else, a SUPER logo, or a Juno computers logo, or an Ubuntu logo even, would have been cool.

Now the trackpad seems excellent. It's super smooth, very precise, it really glides super well. Once I got some gestures set up in there, it's going to be a dream. Only problem: this 2 button layout. I've gotten used to a clicky trackpad, where two finger clicking does a right click, and going back to that seems a bit old school for me, but I'm sure some people will see this as an advantage.

It's a dream gaming laptop: beautiful without too much in the way of GAMER LOOKZ, apart from the RGB in the keyboard, and since the panel goes only to 1080p, the RTX2060 or up is largely enough to run at 144Hz and make sure you have a super smooth gaming experience.

