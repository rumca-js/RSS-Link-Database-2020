# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## US Navy identifies crew killed in training aircraft crash in southern Alabama
 - [https://www.cnn.com/2020/10/25/us/navy-alabama-plane-crash-trnd/index.html](https://www.cnn.com/2020/10/25/us/navy-alabama-plane-crash-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 23:24:17+00:00

The US Navy has identified the two-person crew killed Friday when a training aircraft crashed in a small town outside Mobile, Alabama.

## British forces storm oil tanker that was 'subject to suspected hijacking' off Isle of Wight
 - [https://www.cnn.com/2020/10/25/uk/isle-of-wight-tanker-nave-andromeda-intl/index.html](https://www.cnn.com/2020/10/25/uk/isle-of-wight-tanker-nave-andromeda-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 23:12:07+00:00

British police officers are responding to an ongoing incident on board an oil tanker off the Isle of Wight, an island in the English Channel.

## The awakening of 'Generation Y' in Nigeria
 - [https://www.cnn.com/2020/10/25/africa/nigeria-end-sars-protests-analysis-intl/index.html](https://www.cnn.com/2020/10/25/africa/nigeria-end-sars-protests-analysis-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 22:05:11+00:00

For nearly two weeks angry young Nigerians have taken to the streets, blocking major roads across cities in Africa's most populous nation.

## An all-Black group is arming itself and demanding change
 - [https://www.cnn.com/2020/10/25/us/nfac-black-armed-group/index.html](https://www.cnn.com/2020/10/25/us/nfac-black-armed-group/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 18:21:53+00:00

When two loud bangs rang out on the streets of Lafayette, Louisiana, no one knew where the gunshots came from as protesters gathered to demand justice for another Black man killed by police.

## Stelter: Trump isn't fighting the media, he's resisting reality
 - [https://www.cnn.com/videos/media/2020/10/25/stelter-open-trump-coronavirus-pandemic-media-coverage-rs-vpx.cnn](https://www.cnn.com/videos/media/2020/10/25/stelter-open-trump-coronavirus-pandemic-media-coverage-rs-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 16:49:22+00:00

CNN's Brian Stelter breaks down President Donald Trump's attempts to play down the Covid-19 pandemic as cases surge across the country and nearly 225,000 Americans have died from the virus.

## Alexandria Ocasio-Cortez discusses where she disagrees with Biden
 - [https://www.cnn.com/videos/politics/2020/10/25/alexandria-ocasio-cortez-reacts-to-biden-fracking-intv-sotu-vpx.cnn](https://www.cnn.com/videos/politics/2020/10/25/alexandria-ocasio-cortez-reacts-to-biden-fracking-intv-sotu-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 15:38:46+00:00

Rep. Alexandria Ocasio-Cortez speaks with CNN's Jake Tapper about Democratic presidential nominee Joe Biden's position that he would not ban fracking in the United States if he were elected.

## See how Kamala Harris repsonded to White House admission on pandemic
 - [https://www.cnn.com/videos/politics/2020/10/25/kamala-harris-reacts-to-mark-meadows-intv-not-going-to-control-coronavirus-pandemic-sot-vpx.cnn](https://www.cnn.com/videos/politics/2020/10/25/kamala-harris-reacts-to-mark-meadows-intv-not-going-to-control-coronavirus-pandemic-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 15:12:45+00:00

Democratic vice presidential nominee Sen. Kamala Harris responds to White House Chief of Staff Mark Meadows saying in an interview with CNN that the US is "not going to control" the coronavirus pandemic, as cases surge across the country.

## Fareed's prediction: Donald Trump will lose the 2020 election
 - [https://www.cnn.com/videos/politics/2020/10/25/fareed-zakaria-take-trump-2020-election-america-gps-intv-vpx.cnn](https://www.cnn.com/videos/politics/2020/10/25/fareed-zakaria-take-trump-2020-election-america-gps-intv-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 14:47:09+00:00

CNN's Fareed Zakaria explains why he thought Donald Trump would not win the 2016 election and goes on to predict President Trump will not win the 2020 election.

## Pence's top aides test positive for Covid-19
 - [https://www.cnn.com/2020/10/24/politics/mac-short-coronavirus-positive-test/index.html](https://www.cnn.com/2020/10/24/politics/mac-short-coronavirus-positive-test/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 14:11:58+00:00

Marc Short, chief of staff to Vice President Mike Pence, has been diagnosed with Covid-19, the vice president's office announced in a statement, marking the second top Pence aide to test positive this week.

## Road to 270: This state could be a 'game over' win for Biden
 - [https://www.cnn.com/videos/politics/2020/10/25/trump-biden-electoral-map-magic-wall-john-king-ip-vpx.cnn](https://www.cnn.com/videos/politics/2020/10/25/trump-biden-electoral-map-magic-wall-john-king-ip-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 13:54:53+00:00

CNN's John King breaks down the spending and traveling of President Trump and former Vice President Joe Biden in the run-up to Election Day.

## Tributes pour in for 'greatest champion in UFC history' Khabib Nurmagomedov after shock of his retirement
 - [https://www.cnn.com/2020/10/25/sport/nurmagomedov-retirement-reaction-ufc-spt-intl/index.html](https://www.cnn.com/2020/10/25/sport/nurmagomedov-retirement-reaction-ufc-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 13:37:41+00:00

Following his stunning retirement after his most recent title defense, tributes have poured in to praise the undefeated Ultimate Fighting Championship (UFC) career of Khabib Nurmagomedov.

## US reports second highest day of coronavirus cases since the pandemic began. The highest day was Friday
 - [https://www.cnn.com/2020/10/25/health/us-coronavirus-sunday/index.html](https://www.cnn.com/2020/10/25/health/us-coronavirus-sunday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 13:31:11+00:00

• Boy was given money to 'go on vacation.' He may have been sold as cheap labor.

## How Biden has more paths than Trump to 270 electoral votes
 - [https://www.cnn.com/2020/10/25/politics/paths-to-270-analysis/index.html](https://www.cnn.com/2020/10/25/politics/paths-to-270-analysis/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 13:12:58+00:00

Poll of the week: A new Muhlenberg College/Morning Call poll of likely Pennsylvania voters finds former Vice President Joe Biden at 51% to President Donald Trump's 44%.

## Analysis: Trump denies the coronavirus surge as Biden and Obama condemn his approach
 - [https://www.cnn.com/2020/10/25/politics/joe-biden-donald-trump-barack-obama-coronavirus-stimulus/index.html](https://www.cnn.com/2020/10/25/politics/joe-biden-donald-trump-barack-obama-coronavirus-stimulus/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 13:00:56+00:00

President Donald Trump continued to deny the nation's deepening Covid-19 crisis as he crisscrossed the country this weekend, even as the virus spread among top administration and campaign advisers.

## First 'murder hornet' nest found in US successfully removed
 - [https://www.cnn.com/2020/10/25/us/murder-hornet-nest-removal-washington-trnd-scli/index.html](https://www.cnn.com/2020/10/25/us/murder-hornet-nest-removal-washington-trnd-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 12:50:00+00:00

The first nest of giant "murder hornets" ever discovered in the United States has been eliminated, two days after it was located in Washington state.

## The last US president facing re-election troubles like Trump's was Jimmy Carter in 1980. But the incumbent can't be written off just yet.
 - [https://www.cnn.com/2020/10/25/politics/election-2020-trump-carter-scenario/index.html](https://www.cnn.com/2020/10/25/politics/election-2020-trump-carter-scenario/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 12:33:46+00:00

The last president facing re-election troubles like Donald Trump's was Jimmy Carter in 1980. Injured by recession and impotent against a national crisis, Carter lost big.

## Tropical storm Zeta forms, could reach US Gulf Coast by midweek
 - [https://www.cnn.com/2020/10/25/us/tropical-storm-zeta/index.html](https://www.cnn.com/2020/10/25/us/tropical-storm-zeta/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 12:16:29+00:00

A tropical depression east of Mexico strengthened Sunday morning into Tropical Storm Zeta and could reach the US Gulf Coast by midweek.

## Opinion: The ghost haunting the 2020 election
 - [https://www.cnn.com/2020/10/25/opinions/the-ghost-haunting-the-2020-election-opinion-weekly-column-galant/index.html](https://www.cnn.com/2020/10/25/opinions/the-ghost-haunting-the-2020-election-opinion-weekly-column-galant/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 12:15:14+00:00

What is haunting the campaign of 2020?

## Senate to advance Amy Coney Barrett's Supreme Court nomination in key procedural vote
 - [https://www.cnn.com/2020/10/25/politics/senate-procedural-vote-amy-coney-barrett-supreme-court/index.html](https://www.cnn.com/2020/10/25/politics/senate-procedural-vote-amy-coney-barrett-supreme-court/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 12:06:53+00:00

The Senate is set to take a key procedural vote Sunday to advance Judge Amy Coney Barrett's Supreme Court nomination, paving the way for a final confirmation vote, which will likely take place Monday evening, just days before the November 3 election where control of Congress and the White House are at stake.

## 'SNL' has Baldwin's Trump and Carrey's Biden go head to head in the final debate
 - [https://www.cnn.com/2020/10/25/media/snl-trump-biden-final-debate/index.html](https://www.cnn.com/2020/10/25/media/snl-trump-biden-final-debate/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 11:14:25+00:00

"Tonight we have a mute button because it was either that or tranquilizer darts."

## France condemns 'unacceptable' comments from Turkey's Erdogan and recalls ambassador
 - [https://www.cnn.com/2020/10/25/europe/erdogan-macron-france-muslims-intl/index.html](https://www.cnn.com/2020/10/25/europe/erdogan-macron-france-muslims-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 10:59:32+00:00

France has condemned Turkish President Recep Tayyip Erdogan over comments he made about Emmanuel Macron's mental health and treatment of Muslims.

## Trump promised to win the trade war with China. He failed.
 - [https://www.cnn.com/2020/10/24/economy/us-china-trade-war-intl-hnk/index.html](https://www.cnn.com/2020/10/24/economy/us-china-trade-war-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 09:10:22+00:00

US President Donald Trump started a trade war with China to fix what he's repeatedly blasted as an unfair relationship between the world's two largest economies.

## Family raised $2 million for their baby's life-saving medical treatment. They got it for free.
 - [https://www.cnn.com/2020/10/25/us/baby-sma-2-million-treatment-life-for-lucy-health-trnd/index.html](https://www.cnn.com/2020/10/25/us/baby-sma-2-million-treatment-life-for-lucy-health-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 09:02:50+00:00

A Canadian family that spent months frantically raising millions of dollars for a one-time gene therapy treatment to save their daughter's life has received the treatment for free.

## Europe's clocks go back. Here's how to stay positive as the nights draw in
 - [https://www.cnn.com/2020/10/24/europe/clocks-changing-scli-intl-gbr/index.html](https://www.cnn.com/2020/10/24/europe/clocks-changing-scli-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 08:15:05+00:00

The clocks are turning back one hour across Europe at 2am on Sunday October 25, giving everyone across the continent an extra hour in bed, and signaling the start of winter.

## Infectious disease expert issues stark warning about US
 - [https://www.cnn.com/videos/health/2020/10/24/osterholm-us-highest-number-of-covid-19-cases-ctn-vpx.cnn](https://www.cnn.com/videos/health/2020/10/24/osterholm-us-highest-number-of-covid-19-cases-ctn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 07:15:49+00:00

As the United States records its highest single day total for new Covid-19 cases, infectious disease expert Michael Osterholm warns that the country will see some of the darkest days in its history until a vaccine is made widely available.

## No matter who wins the US election, the world's 'fake news' problem is here to stay
 - [https://www.cnn.com/2020/10/25/world/trump-fake-news-legacy-intl/index.html](https://www.cnn.com/2020/10/25/world/trump-fake-news-legacy-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 04:16:00+00:00

US President Donald Trump and Russian President Vladimir Putin were in high spirits, smirking and jovial, when they appeared in front of the press corps at the annual G20 summit in Osaka, Japan, in 2019.

## The newspaper that gave Black Britain a megaphone
 - [https://www.cnn.com/2020/10/25/media/the-voice-newspaper-black-history-month/index.html](https://www.cnn.com/2020/10/25/media/the-voice-newspaper-black-history-month/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 04:15:13+00:00

When clashes between residents and police erupted onto the streets of Brixton in 1981, in the heart of London's African-Caribbean community, the British press largely told one side of the story.

## Samsung chairman Lee Kun-hee dies after long illness
 - [https://www.cnn.com/2020/10/24/business/samsung-lee-kun-hee-intl-hnk/index.html](https://www.cnn.com/2020/10/24/business/samsung-lee-kun-hee-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 02:29:52+00:00

Lee Kun-hee, the chairman of South Korean electronics giant Samsung, died Sunday at the age of 78, the company said. He had been comatose since suffering a heart attack in 2014.

## Boy was given money to 'go on vacation.' He may have been sold as cheap labor.
 - [https://www.cnn.com/2020/10/24/asia/india-covid-child-trafficking-intl-hnk-dst/index.html](https://www.cnn.com/2020/10/24/asia/india-covid-child-trafficking-intl-hnk-dst/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-10-25 01:15:01+00:00

One evening in August, a 14-year-old boy snuck out of his home and boarded a private bus to travel from his village in Bihar to Jaipur, a chaotic, crowded and historical city 800 miles away in India's Rajasthan state.

