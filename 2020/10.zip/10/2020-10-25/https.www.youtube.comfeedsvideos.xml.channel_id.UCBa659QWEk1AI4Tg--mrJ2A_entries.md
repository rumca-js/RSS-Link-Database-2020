# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## My unlicensed hovercraft bar is technically legal
 - [https://www.youtube.com/watch?v=ZLF7yife8YE](https://www.youtube.com/watch?v=ZLF7yife8YE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2020-10-26 00:00:00+00:00

If you want to sell alcohol in England, you need a license. But the Licensing Act 2003 has some unusual exceptions. • Thanks to Marc and the team from the Axceler-8 Hovercraft Centre: http://hovercraftcentre.co.uk/ • Behind the scenes: https://www.youtube.com/watch?v=UQXqkBiqRCI

Licensing Act 2003: https://www.legislation.gov.uk/ukpga/2003/17/contents

Filmed safely: https://www.tomscott.com/safe/

Camera: Matt Gray https://mattg.co.uk
Logistics and original idea: Jonty Wareing https://twitter.com/jonty
Thanks to: Rob Hiseman
Editor: Michelle Martin https://twitter.com/mrsmmartin
Audio mix: Graham Haerther

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

