# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Huawei Mate 40 Pro Impressions: Technically Awesome!
 - [https://www.youtube.com/watch?v=j5zvFXmSGKY](https://www.youtube.com/watch?v=j5zvFXmSGKY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-10-22 00:00:00+00:00

Huawei's new smartphone is technically really good. But don't buy it. Again.

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Jordyn Edmonds http://smarturl.it/jordynedmonds
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by Huawei for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

## iPad Air 2020: The Real iPad Pro Killer!
 - [https://www.youtube.com/watch?v=nDy32xoXM4o](https://www.youtube.com/watch?v=nDy32xoXM4o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-10-21 00:00:00+00:00

iPad Air 4 takes iPad Pro and drops the bells and whistles for a very fair price.

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: On and On by Hocus Pocus
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Tablet provided by Apple for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

