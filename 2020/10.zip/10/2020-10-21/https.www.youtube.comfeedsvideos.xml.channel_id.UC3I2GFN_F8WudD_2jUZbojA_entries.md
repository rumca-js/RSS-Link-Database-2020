# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Gabriel Garzón-Montano - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=Xss3plgOjfE](https://www.youtube.com/watch?v=Xss3plgOjfE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-22 00:00:00+00:00

http://KEXP.ORG presents Gabriel Garzón-Montano sharing a stripped-down performance recorded exclusively for KEXP.

Golden Wings
Fruit Flies
Everything is Everything
Strange Relationship (Prince Cover)
17 Days/Pleas (Prince and the Revolution/Moses Sumney Mashup)
Bloom
Agüita
Anacaona (Cheo Feliciano Cover)
Todo Tiene Su Final (Willie Colón & Héctor Lavoe Cover)
El Malo (Willie Colón & Héctor Lavoe Cover)
6 8
Someone
Lullaby
Muñeca

https://gabrielgarzonmontano.com
http://kexp.org

## Gabriel Garzón-Montano - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=igizra8rxJI](https://www.youtube.com/watch?v=igizra8rxJI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-21 00:00:00+00:00

http://KEXP.ORG presents Gabriel Garzón-Montano sharing an exclusive stripped-down performance and talking with Cheryl Waters. Recorded October 14, 2020.

Golden Wings
Fruit Flies
Everything is Everything
Strange Relationship (Prince Cover)
17 Days/Pleas (Prince and the Revolution/Moses Sumney Mashup)
Bloom
Agüita
Anacaona (Cheo Feliciano Cover)
Todo Tiene Su Final (Willie Colón & Héctor Lavoe Cover)
El Malo (Willie Colón & Héctor Lavoe Cover)
6 8
Someone
Lullaby
Muñeca

https://gabrielgarzonmontano.com
http://kexp.org

