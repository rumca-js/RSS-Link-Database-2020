# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Independence Day: Resurgence - May Be The Dumbest Movie Ever Made
 - [https://www.youtube.com/watch?v=9UIOmInIv7g](https://www.youtube.com/watch?v=9UIOmInIv7g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-10-21 00:00:00+00:00

The Roland Emmerich sequel to 1996's classic action blockbuster Independence Day, Resurgence takes everything fun about the original and promptly dumps it, replacing it with an incoherent plot, terrible characters, meaningless action and over the top disaster scenes. The result is quite possibly the dumbest movie ever made.

