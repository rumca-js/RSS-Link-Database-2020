# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## The majority of Facebook's traffic now uses QUIC and HTTP/3
 - [https://engineering.fb.com/networking-traffic/how-facebook-is-bringing-quic-to-billions/](https://engineering.fb.com/networking-traffic/how-facebook-is-bringing-quic-to-billions/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2020-10-21 16:40:46+00:00

<p>Article URL: <a href="https://engineering.fb.com/networking-traffic/how-facebook-is-bringing-quic-to-billions/">https://engineering.fb.com/networking-traffic/how-facebook-is-bringing-quic-to-billions/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=24849498">https://news.ycombinator.com/item?id=24849498</a></p>
<p>Points: 28</p>
<p># Comments: 0</p>

## Reducing Abusive Notification Content
 - [https://blog.chromium.org/2020/10/reducing-abusive-notification-content.html](https://blog.chromium.org/2020/10/reducing-abusive-notification-content.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2020-10-21 16:40:30+00:00

<p>Article URL: <a href="https://blog.chromium.org/2020/10/reducing-abusive-notification-content.html">https://blog.chromium.org/2020/10/reducing-abusive-notification-content.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=24849496">https://news.ycombinator.com/item?id=24849496</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## To write better, you need to develop a habit of writing
 - [https://bookpub.club/post/to-write-better-you-need-to-develop-a-habit-of-writing--1603298302647x354487348376371200](https://bookpub.club/post/to-write-better-you-need-to-develop-a-habit-of-writing--1603298302647x354487348376371200)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2020-10-21 16:39:42+00:00

<p>Article URL: <a href="https://bookpub.club/post/to-write-better-you-need-to-develop-a-habit-of-writing--1603298302647x354487348376371200">https://bookpub.club/post/to-write-better-you-need-to-develop-a-habit-of-writing--1603298302647x354487348376371200</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=24849485">https://news.ycombinator.com/item?id=24849485</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Facebook Container for Firefox
 - [https://www.mozilla.org/en-US/firefox/facebookcontainer/](https://www.mozilla.org/en-US/firefox/facebookcontainer/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2020-10-21 16:35:25+00:00

<p>Article URL: <a href="https://www.mozilla.org/en-US/firefox/facebookcontainer/">https://www.mozilla.org/en-US/firefox/facebookcontainer/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=24849452">https://news.ycombinator.com/item?id=24849452</a></p>
<p>Points: 40</p>
<p># Comments: 8</p>

## LinkedIn will scan the browser to identify extensions
 - [https://prophitt.me/a-look-at-how-linkedin-exfiltrates-extension-data-from-your-browser](https://prophitt.me/a-look-at-how-linkedin-exfiltrates-extension-data-from-your-browser)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2020-10-21 16:19:35+00:00

<p>Article URL: <a href="https://prophitt.me/a-look-at-how-linkedin-exfiltrates-extension-data-from-your-browser">https://prophitt.me/a-look-at-how-linkedin-exfiltrates-extension-data-from-your-browser</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=24849282">https://news.ycombinator.com/item?id=24849282</a></p>
<p>Points: 29</p>
<p># Comments: 8</p>

## Show HN: App Performance Monitoring (APM) for mobile apps
 - [https://instabug.com/product/app-performance-monitoring](https://instabug.com/product/app-performance-monitoring)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2020-10-21 15:51:39+00:00

<p>Article URL: <a href="https://instabug.com/product/app-performance-monitoring">https://instabug.com/product/app-performance-monitoring</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=24849006">https://news.ycombinator.com/item?id=24849006</a></p>
<p>Points: 14</p>
<p># Comments: 5</p>

## The businesses where Google is biggest and the ones where it isn’t
 - [https://www.wsj.com/articles/the-businesses-where-google-is-biggest-and-the-ones-where-it-isnt-11603293145](https://www.wsj.com/articles/the-businesses-where-google-is-biggest-and-the-ones-where-it-isnt-11603293145)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2020-10-21 15:48:35+00:00

<p>Article URL: <a href="https://www.wsj.com/articles/the-businesses-where-google-is-biggest-and-the-ones-where-it-isnt-11603293145">https://www.wsj.com/articles/the-businesses-where-google-is-biggest-and-the-ones-where-it-isnt-11603293145</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=24848984">https://news.ycombinator.com/item?id=24848984</a></p>
<p>Points: 67</p>
<p># Comments: 28</p>

## Gardening Your Twitter
 - [https://steipete.com/posts/growing-your-twitter-followers/](https://steipete.com/posts/growing-your-twitter-followers/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2020-10-21 15:28:45+00:00

<p>Article URL: <a href="https://steipete.com/posts/growing-your-twitter-followers/">https://steipete.com/posts/growing-your-twitter-followers/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=24848782">https://news.ycombinator.com/item?id=24848782</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Justice Department: Resolution with Purdue Pharma and Sackler Family
 - [https://www.justice.gov/opa/pr/justice-department-announces-global-resolution-criminal-and-civil-investigations-opioid](https://www.justice.gov/opa/pr/justice-department-announces-global-resolution-criminal-and-civil-investigations-opioid)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2020-10-21 15:20:25+00:00

<p>Article URL: <a href="https://www.justice.gov/opa/pr/justice-department-announces-global-resolution-criminal-and-civil-investigations-opioid">https://www.justice.gov/opa/pr/justice-department-announces-global-resolution-criminal-and-civil-investigations-opioid</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=24848681">https://news.ycombinator.com/item?id=24848681</a></p>
<p>Points: 36</p>
<p># Comments: 20</p>

## Neural Decipherment via Minimum-Cost Flow: From Ugaritic to Linear B
 - [https://arxiv.org/abs/1906.06718](https://arxiv.org/abs/1906.06718)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2020-10-21 15:12:05+00:00

<p>Article URL: <a href="https://arxiv.org/abs/1906.06718">https://arxiv.org/abs/1906.06718</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=24848588">https://news.ycombinator.com/item?id=24848588</a></p>
<p>Points: 11</p>
<p># Comments: 5</p>

## BPF, XDP, Packet Filters and UDP
 - [https://fly.io/blog/bpf-xdp-packet-filters-and-udp/](https://fly.io/blog/bpf-xdp-packet-filters-and-udp/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2020-10-21 14:47:26+00:00

<p>Article URL: <a href="https://fly.io/blog/bpf-xdp-packet-filters-and-udp/">https://fly.io/blog/bpf-xdp-packet-filters-and-udp/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=24848391">https://news.ycombinator.com/item?id=24848391</a></p>
<p>Points: 49</p>
<p># Comments: 4</p>

## Behavioral nudges reduce failure to appear for court
 - [https://science.sciencemag.org/content/early/2020/10/07/science.abb6591](https://science.sciencemag.org/content/early/2020/10/07/science.abb6591)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2020-10-21 14:44:14+00:00

<p>Article URL: <a href="https://science.sciencemag.org/content/early/2020/10/07/science.abb6591">https://science.sciencemag.org/content/early/2020/10/07/science.abb6591</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=24848355">https://news.ycombinator.com/item?id=24848355</a></p>
<p>Points: 51</p>
<p># Comments: 20</p>

## Attempts to make Python fast
 - [https://sethops1.net/post/attempts-to-make-python-fast/](https://sethops1.net/post/attempts-to-make-python-fast/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2020-10-21 14:40:29+00:00

<p>Article URL: <a href="https://sethops1.net/post/attempts-to-make-python-fast/">https://sethops1.net/post/attempts-to-make-python-fast/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=24848318">https://news.ycombinator.com/item?id=24848318</a></p>
<p>Points: 88</p>
<p># Comments: 75</p>

## Why traditional reinforcement learning will probably not yield AGI [pdf]
 - [https://philpapers.org/archive/ALETAT-12.pdf](https://philpapers.org/archive/ALETAT-12.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2020-10-21 14:33:13+00:00

<p>Article URL: <a href="https://philpapers.org/archive/ALETAT-12.pdf">https://philpapers.org/archive/ALETAT-12.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=24848249">https://news.ycombinator.com/item?id=24848249</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Taplytics (YC W14) Is Hiring Senior Software Eng and Eng Team Lead in Canada
 - [https://jobs.lever.co/taplytics/](https://jobs.lever.co/taplytics/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2020-10-21 13:56:43+00:00

<p>Article URL: <a href="https://jobs.lever.co/taplytics/">https://jobs.lever.co/taplytics/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=24847912">https://news.ycombinator.com/item?id=24847912</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Learning to Decapsulate Integrated Circuits Using Acid Deposition
 - [https://jcjc-dev.com/2020/10/20/learning-to-decap-ics/](https://jcjc-dev.com/2020/10/20/learning-to-decap-ics/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2020-10-21 13:12:29+00:00

<p>Article URL: <a href="https://jcjc-dev.com/2020/10/20/learning-to-decap-ics/">https://jcjc-dev.com/2020/10/20/learning-to-decap-ics/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=24847500">https://news.ycombinator.com/item?id=24847500</a></p>
<p>Points: 31</p>
<p># Comments: 2</p>

## United States vs. Google
 - [https://stratechery.com/2020/united-states-v-google/](https://stratechery.com/2020/united-states-v-google/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2020-10-21 12:56:58+00:00

<p>Article URL: <a href="https://stratechery.com/2020/united-states-v-google/">https://stratechery.com/2020/united-states-v-google/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=24847350">https://news.ycombinator.com/item?id=24847350</a></p>
<p>Points: 148</p>
<p># Comments: 99</p>

## PayPal to allow cryptocurrency buying, selling and shopping on its network
 - [https://www.reuters.com/article/paypal-cryptocurrency/paypal-to-allow-cryptocurrency-buying-selling-and-shopping-on-its-network-idINL1N2HB14U](https://www.reuters.com/article/paypal-cryptocurrency/paypal-to-allow-cryptocurrency-buying-selling-and-shopping-on-its-network-idINL1N2HB14U)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2020-10-21 11:56:00+00:00

<p>Article URL: <a href="https://www.reuters.com/article/paypal-cryptocurrency/paypal-to-allow-cryptocurrency-buying-selling-and-shopping-on-its-network-idINL1N2HB14U">https://www.reuters.com/article/paypal-cryptocurrency/paypal-to-allow-cryptocurrency-buying-selling-and-shopping-on-its-network-idINL1N2HB14U</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=24846905">https://news.ycombinator.com/item?id=24846905</a></p>
<p>Points: 538</p>
<p># Comments: 188</p>

## Hands-Free Coding: How I develop software using dictation and eye-tracking
 - [https://joshwcomeau.com/accessibility/hands-free-coding/](https://joshwcomeau.com/accessibility/hands-free-coding/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2020-10-21 11:53:16+00:00

<p>Article URL: <a href="https://joshwcomeau.com/accessibility/hands-free-coding/">https://joshwcomeau.com/accessibility/hands-free-coding/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=24846887">https://news.ycombinator.com/item?id=24846887</a></p>
<p>Points: 247</p>
<p># Comments: 53</p>

## Prologue: A web framework written in Nim
 - [https://github.com/planety/prologue/releases/tag/v0.4.0](https://github.com/planety/prologue/releases/tag/v0.4.0)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2020-10-21 11:44:02+00:00

<p>Article URL: <a href="https://github.com/planety/prologue/releases/tag/v0.4.0">https://github.com/planety/prologue/releases/tag/v0.4.0</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=24846828">https://news.ycombinator.com/item?id=24846828</a></p>
<p>Points: 123</p>
<p># Comments: 39</p>

