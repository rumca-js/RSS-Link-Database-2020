# Source:Veritasium, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA, language:en-US

## What Actually Expands In An Expanding Universe?
 - [https://www.youtube.com/watch?v=9DrBQg_n2Uo](https://www.youtube.com/watch?v=9DrBQg_n2Uo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA
 - date published: 2020-10-23 00:00:00+00:00

As the universe expands, #expanding #space is said to "stretch" photons. But if it stretches photons, does it also stretch molecules, galaxies and you? A portion of this video was sponsored by Salesforce. Go to https://salesforce.com/veritasium to learn more.

Special thanks to Geraint Lewis - this video was based on his paper "On the relativity of redshifts"
https://arxiv.org/abs/1605.08634
Check out his YouTube channel: https://ve42.co/gfl and books: https://ve42.co/GFLbooks

References:
Expanding Space: the Root of all Evil?
Matthew J. Francis, Luke A. Barnes, J. Berian James, Geraint F. Lewis
https://arxiv.org/abs/0707.0380

Editing and VFX by Trenton Oliver
Thumbnail by Ignat Berbeci

Music from https://epidemicsound.com

#SMB #smallbiz #startups #SalesforceEssentials

