# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## How Tolkien Can Help Your Writing Process
 - [https://www.youtube.com/watch?v=vOFl8UFxsLc](https://www.youtube.com/watch?v=vOFl8UFxsLc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-10-23 00:00:00+00:00

Kyle and Ethan get advice from one of the world’s leading J.R.R Tolkien and C.S. Lewis Scholar on how Tolkien and the Inklings can help all of us be more creative. Glyer shares insight into the historic writing group: The Inklings and how they were able to influence each other without imitating each other. 

See the full show here:
https://www.youtube.com/watch?v=C56VVnBQS30

Subscribe to the Babylon Bee to help bring Tolkien into your heart

Hit the Bell to get your daily dose of fake news that you can trust.

## The Election Prediction Machine - BNN Week In Review 10-23-2020
 - [https://www.youtube.com/watch?v=1vZt8t2CXTo](https://www.youtube.com/watch?v=1vZt8t2CXTo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-10-23 00:00:00+00:00

Election 2020 is fast approaching and Americans want to know: what will happen? Guy Curtis and Samantha Kurlock take a look into America's future with Dr. Malcolm Farnsworth's election prediction machine.

## Trump Tweets The Bee/Jordan Peterson Returns/Facebook Kills Comedy News Show 10.23.2020
 - [https://www.youtube.com/watch?v=IVv0u5QprUE](https://www.youtube.com/watch?v=IVv0u5QprUE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-10-23 00:00:00+00:00

Today on The Babylon Bee Podcast, Kyle and Ethan talk about the week’s top stories like President Trump tweeting out a Babylon Bee story, Jordan Peterson returning with the 12 Rules For Life on stone tablets, and how Facebook is murdering comedy. The Babylon Bee also has some updated and more realistic travel posters to America’s big cities. Tune in for more weird news, cool stories, a trip to the mailbag and, of course, glorious hate mail.

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Gain Access to the Exclusive Content and Writing Forum: https://babylonbee.com/plans

The Official Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

## What Made CS Lewis Throw Narnia In The Trash
 - [https://www.youtube.com/watch?v=WIcOOoEuev4](https://www.youtube.com/watch?v=WIcOOoEuev4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-10-22 00:00:00+00:00

One of the world's leading Scholars on Tolkien and C.S. Lewis, tells the story of how Tolkien almost made C.S. Lewis throw out the Narnia stories. 

Diana Glyer has been studying the Inklings, which is a writers group that consisted of many top authors, including J.R.R. Tolkien and C.S. Lewis, who discussed and shared their work with each other.

See the full show here:
https://www.youtube.com/watch?v=C56VVnBQS30

Subscribe to the Babylon Bee to help bring Tolkien into your heart

Hit the Bell to get your daily dose of fake news that you can trust.

