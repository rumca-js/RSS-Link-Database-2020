# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## The Muscle Song (Memorize Your Anatomy) | SCIENCE SONGS
 - [https://www.youtube.com/watch?v=VmcQfCcGScY](https://www.youtube.com/watch?v=VmcQfCcGScY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2020-10-22 00:00:00+00:00

Thank you Google for sponsoring a portion of this video! To learn more about how Google helps protect your information online, visit http://passwords.google.com
The END OF THE UNIVERSE Song: https://youtu.be/o6UPfdhOHIY


Song created by Mitchell Moffit

LYRICS:

VERSE 1
See the chest
You can flex
Your pectoralis
Major out 
Minor in
So that you can press
Underneath
On the ribs
Is the serratus
Anterior
For boxing fitness

Turn the neck
Sternocloidomastoid is here
Omohyoid
Sternohyoid
Work in tandem dear
On the back
Now the trapezius appear
Upper, Middle and Inferior

Shoulders up
Shoulders down 
Feel the deltoids work
Abduction of your little arms
The biceps brachii
And brachialis
Flex the elbow, looking strong

Turn around
The triceps
Cause extension
In the shape of a horseshoe
To the forearm
Brachioradialis
Carpi ulnaris times two

Add the carpi radialis; flexor, extensor, too
The hand has many muscles, that we’re not going through

CHORUS
This is the muscle song 
So sing along
600 plus
That you can trust
To move you on your way

Smooth, Cardiac and 
Skeletal soft tissue
Changing posture
Locomotion
Organs too

VERSE 2
Give me abs
Can’t resists
Rectus abdominis
Tendinous
Inscriptions
For some definit
Got obliques
With technique
To rotate and twist
Intercostals move the chest and ribs

The longest
Muscle is
The sartorius
Adductors
Longus
And Gracilis
Tensor Fascaie latae
And Pectineus
It’s your thigh
And here we cannot miss

Take a look
The Quadriceps
In four parts
Rectus femoris on top
On the outside
Vastus lateralis
Medialis near the crotch

Down below
The vastus intermedius 
Sits on the long femur
With the quads
You can walk
You can run, jump, squat
Extend the knee
Be a dancer

CHORUS
This is the muscle song 
So sing along
600 plus
That you can trust
To move you on your way

Smooth, Cardiac and 
Skeletal soft tissue
Evolutionary wonders
Inside you

FINALE
Rhomboids
Retract the shoulder blade with major minor
Infraspinatus, and teres make the shoulder liner

Lats are looking broader
Erector spinae will make you taller

Glutes!
Are freakin huge!
The largest muscles they include
The maximus, the medius and minimus
Hamstring placement just below with

IT band, adductor magnus
Biceps femoris are flexors
Semitendinosus too
And Semimembranosus ooh

Calves can flex the foot for you
The gastrocnemius for jumping too
The soleus points down your toes
So you can put on all your clothes

And cover all your muscles
And move

