# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## A Guided Meditation for Anxiety | Russell Brand
 - [https://www.youtube.com/watch?v=zq85xzRg6SM](https://www.youtube.com/watch?v=zq85xzRg6SM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-10-22 00:00:00+00:00

I get asked a lot about how to help with anxiety. Here is a guided meditation for you, that hopefully will help you with that anxiety.

If you suffer from Anxiety - this video might help too: https://youtu.be/TfX4dNo4Khw

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

