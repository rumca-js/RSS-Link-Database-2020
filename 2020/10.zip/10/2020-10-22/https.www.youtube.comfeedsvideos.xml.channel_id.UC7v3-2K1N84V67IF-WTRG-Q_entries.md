# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Constantine - Movie Review
 - [https://www.youtube.com/watch?v=A0nu8PlwLJs](https://www.youtube.com/watch?v=A0nu8PlwLJs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-10-23 00:00:00+00:00

Keanu plays a very American John Constantine. But how has the movie aged? For better? For worse? Here's my review for CONSTANTINE!

#Constantine

## Train To Busan - Movie Review
 - [https://www.youtube.com/watch?v=PjStfWnfDVI](https://www.youtube.com/watch?v=PjStfWnfDVI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-10-23 00:00:00+00:00

A Korean zombie apocalypse film that takes place on a train...to Busan. Here's my review for TRAIN TO BUSAN!

#TrainToBusan

