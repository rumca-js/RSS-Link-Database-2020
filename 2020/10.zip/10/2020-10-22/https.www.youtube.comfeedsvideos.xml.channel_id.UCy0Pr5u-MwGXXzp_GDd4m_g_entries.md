# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## Add it to the list?
 - [https://www.youtube.com/watch?v=89gkCNQAtNA](https://www.youtube.com/watch?v=89gkCNQAtNA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2020-10-22 00:00:00+00:00

When a friend recommends a new show, book or podcast... do you add it to the list? Get Surfshark VPN at https://surfshark.deals/nolke - Enter promo code NOLKE for 83% off and 3 extra months for FREE!

