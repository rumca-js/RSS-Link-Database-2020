## Google Paid Apple Billions To Dominate Search On iPhones, Justice Department Says : NPR
 - [https://www.npr.org/2020/10/22/926290942/google-paid-apple-billions-to-dominate-search-on-iphones-justice-department-says](https://www.npr.org/2020/10/22/926290942/google-paid-apple-billions-to-dominate-search-on-iphones-justice-department-says)
 - RSS feed: https://www.npr.org
 - date published: 2020-10-22 16:32:28+00:00

Google Paid Apple Billions To Dominate Search On iPhones, Justice Department Says : NPR

