# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## PS5 NEW FACEPLATES, BETHESDA TO SURVIVE WITHOUT PS5? & MORE
 - [https://www.youtube.com/watch?v=0uDxCCRoSLM](https://www.youtube.com/watch?v=0uDxCCRoSLM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-10-23 00:00:00+00:00

Thanks ExpressVPN for sponsoring. Go to https://expressvpn.com/gameranx and find out how you can get 3 months free.

An accessory gets a head start on custom PS5 faceplates, Phil Spencer talks Bethesda, Tom Holland is revealed as Nathan Drake, new game trailers, and more in a week full of gaming news.

Jake's other channel: https://youtu.be/eFL2QWVncac

discord.gg/gameranx                                                



 ~~~~STORIES~~~~

Custom PS5 faceplates
https://www.playstationlifestyle.net/2020/10/22/custom-ps5-faceplates-outer-shell-blue-matte-black-chrome-red-platestation5/

Xbox boss on Bethesda
https://kotaku.com/xbox-boss-phil-spencer-on-series-x-launch-halo-infinit-1845392984

Vampire The Masquerade Bloodlines 2 changes:
https://www.gamesindustry.biz/articles/2020-10-20-vampire-the-masquerade-bloodlines-2-loses-another-narrative-designer

Tom Holland Uncharted
https://www.theverge.com/2020/10/22/21528606/tom-holland-nathan-drake-first-photo-uncharted-movie-sony



New Spider-Man fun stuff:
https://www.playstation.com/en-us/games/marvels-spider-man-miles-morales/daily-bugle-now/#edition2

Little Nightmares 2 trailer:
https://www.youtube.com/watch?v=jVQn9jSgqAY

Rambo MK11 gameplay: 
https://twitter.com/noobde/status/1319262611968491521?s=20

Godfall stuff
https://youtu.be/9gf2etDH9aU

Metal Gear sneakers
https://twitter.com/GameSpot/status/1319647311224573952


2k ads
https://www.vg247.com/2020/10/21/nba-2k21-unskippable-in-game-ads/

Master Chief Series X update
https://www.tomsguide.com/news/classic-halo-games-are-getting-this-huge-boost-on-xbox-series-x

## Cyberpunk 2077: 10 Things You NEED TO KNOW
 - [https://www.youtube.com/watch?v=NNd8_DjVK2E](https://www.youtube.com/watch?v=NNd8_DjVK2E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-10-22 00:00:00+00:00

Cyberpunk 2077 (PC, PS4, Xbox One, PS5, Series X) is releasing soon, so here's all of the information to be caught up on the ambitious new RPG.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

