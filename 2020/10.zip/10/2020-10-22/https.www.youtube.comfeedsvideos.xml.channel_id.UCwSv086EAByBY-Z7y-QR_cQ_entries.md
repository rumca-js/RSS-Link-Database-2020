# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Nowy projekt Lewicy! Negowanie pandemii będzie karalne! Nowa normalność?
 - [https://www.youtube.com/watch?v=1jZsgvjp1Hg](https://www.youtube.com/watch?v=1jZsgvjp1Hg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2020-10-22 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
👀 Tatusiek: http://bit.ly/3aSCheE
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/2ETKSyN
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
---------------------------------------------------------------
✅źródła:
https://bit.ly/37wIqOp
https://bit.ly/3m5hv0m
https://bit.ly/3e10T7j
-------------------------------------------------------------
🖼Grafika - wykorzystano elementy ze strony: 
wikipedia.org / Adrian Grycuk
https://bit.ly/37AuEue
-------------------------------------------------------------
💡 Tagi: #lewica #covid19
--------------------------------------------------------------

