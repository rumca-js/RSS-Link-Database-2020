# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## Upgrading my ThinkPad with an MSATA Solid State Drive
 - [https://www.youtube.com/watch?v=JJI4ClLppHs](https://www.youtube.com/watch?v=JJI4ClLppHs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-10-23 00:00:00+00:00

I got an MSATA sold state drive to increase the storage space on my ThinkPad. I now have it and a terabyte SSD. Some MSATA drives can actually be as large as a TB, but this one was "only" 256 GB. I plan on moving my operating system over to it and perhaps my backup of the Monero blockchain.

The ThinkPad X220 was the first of the X series ThinkPads to have an MSATA slot. While I like the X200, I don't believe any of them came with it.

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE: https://lukesmith.xyz/donate 💰😎👌💯
OR affiliate links to things l use:
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://brave.com/luk005 Get the Brave browser.
https://lbry.tv/$/invite/@Luke View my videos on LBRY. Get a bonus for joining.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase. We both get $10 in Bitcoin when you buy or sell $100 in cryptocurrencies.

## Importance of Ego Management
 - [https://www.youtube.com/watch?v=A3OkXEMVk90](https://www.youtube.com/watch?v=A3OkXEMVk90)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-10-22 00:00:00+00:00

If you sperg out whenever someone insults your favorite video gayme or Linux distribution, you got something to deal with. We talk about managing your own and other people's egos lest you look like an arrogant brainlet.

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE: https://lukesmith.xyz/donate 💰😎👌💯
OR affiliate links to things l use:
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://brave.com/luk005 Get the Brave browser.
https://lbry.tv/$/invite/@Luke View my videos on LBRY. Get a bonus for joining.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase. We both get $10 in Bitcoin when you buy or sell $100 in cryptocurrencies.

