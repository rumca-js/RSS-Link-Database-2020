# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## India is Planning to Dominate Smartphone Manufacturing
 - [https://www.youtube.com/watch?v=IQSOkB-oaNI](https://www.youtube.com/watch?v=IQSOkB-oaNI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2020-10-23 00:00:00+00:00

The first 200 people to click my link https://brilliant.org/COLDFUSION/ will get 20% off their annual Premium subscription!

--- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. 

ColdFusion Merch:
INTERNATIONAL: https://store.coldfusioncollective.com/
AUSTRALIA: https://shop.coldfusioncollective.com/

If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- New Thinking Book written by Dagogo Altraide ---
This book was rated the 9th best technology history book by book authority.
In the book you’ll learn the stories of those who invented the things we use everyday and how it all fits together to form our modern world.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

--- ColdFusion Social Media ---
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusionTV

Sources:
 https://www.bloomberg.com/news/articles/2020-10-06/iphone-makers-win-nod-for-143-billion-india-manufacturing-plan

https://www.bloomberg.com/news/articles/2020-06-02/india-plans-6-6-billion-in-incentives-to-woo-smartphone-makers

https://edition.cnn.com/2020/10/07/tech/india-smartphone-apple-intl-hnk/index.html

https://marker.medium.com/will-apple-ever-choose-india-over-china-2ea5a4fad886

https://www.indiatoday.in/technology/news/story/iphone-12-will-be-made-in-india-as-apple-supplier-hires-10-000-local-employees-for-production-1712777-2020-08-19

https://9to5mac.com/2020/07/02/iphone-assembly-in-india/

https://www.statista.com/statistics/253649/iphone-revenue-as-share-of-apples-total-revenue/#:~:text=The%20iPhone's%20share%20of%20the,with%20new%20releases%20and%20updates.

https://www.ndtv.com/business/apple-iphone-makers-may-be-gainers-in-6-6-billion-india-plan-to-bring-manufacturing-to-india-report-2294920


» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide

