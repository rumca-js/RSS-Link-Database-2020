# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## SCIFI UNIVERSE TIER LIST
 - [https://www.youtube.com/watch?v=9RfXwCgkhUc](https://www.youtube.com/watch?v=9RfXwCgkhUc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-10-23 00:00:00+00:00

My tier list for a buncha sci-fi universes. What do you want from me? It's a list. its got universes. ENJOY!
The Tier List: https://tierlists.com/create/scifi-universes-bruh

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

## The Invisible Life Of Addie Larue - REVIEW
 - [https://www.youtube.com/watch?v=3R5qH5Z_RqE](https://www.youtube.com/watch?v=3R5qH5Z_RqE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-10-22 00:00:00+00:00

My review of Victoria Schwab's The Invisible Life of Addie Larue! 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

