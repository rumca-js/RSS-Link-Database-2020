## United Nations Secretary-General calls for individual action to combat misinformation | Africa Renewal
 - [https://www.un.org/africarenewal/news/united-nations-secretary-general-calls-individual-action-combat-misinformation](https://www.un.org/africarenewal/news/united-nations-secretary-general-calls-individual-action-combat-misinformation)
 - RSS feed: https://www.un.org
 - date published: 2020-10-22 06:30:50+00:00

United Nations Secretary-General calls for individual action to combat misinformation | Africa Renewal

