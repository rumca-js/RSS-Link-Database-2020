# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## The Most Mysterious Place On Earth? | Random Thursday
 - [https://www.youtube.com/watch?v=xJNEKSxeZ5E](https://www.youtube.com/watch?v=xJNEKSxeZ5E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2020-10-22 00:00:00+00:00

Get 3 months of ExpressVPN for free when you sign up at http://www.expressvpn.com/joescott
The Bermuda Triangle has held our collective attention for decades. This area of the ocean is blamed for countless missing ships and planes, spawning theories as wide-ranging as time/space vortexes, methane bubbles, the City of Atlantis, and, of course, aliens. 

But is there a rational explanation for all the weird phenomena reported in the Bermuda Triangle, or is it more of a pop culture phenomenon? Let's take a look.

Watch this video ad-free on Nebula: https://nebula.tv/videos/joe-scott-the-most-mysterious-place-on-earth


Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

Lemmino did a great video about the Bermuda Triangle:
Lemmino video: https://www.youtube.com/watch?v=AgMcqNnqatw

https://www.britannica.com/place/Bermuda-Triangle

https://www.history.com/topics/folklore/bermuda-triangle

https://www.britannica.com/story/what-is-known-and-not-known-about-the-bermuda-triangle

https://skeptoid.com/episodes/4699

https://www.history.com/news/bermuda-triangle-uss-cyclops-mystery-world-war-i

https://www.express.co.uk/news/weird/1144599/bermuda-triangle-uss-cyclops-case-solved-document-discovered-spt

https://www.nationalparks.org/connect/blog/legend-ghost-ship-carroll-deering

https://www.wearethemighty.com/lists/strange-military-disappearances-in-the-bermuda-triangle

https://www.csmonitor.com/Science/2013/0610/Bermuda-Triangle-doesn-t-make-the-cut-on-list-of-world-s-most-dangerous-oceans

https://www.marineinsight.com/maritime-history/5-famous-mysterious-stories-of-the-bermuda-triangle/

https://www.businessinsider.com/what-is-bermuda-triangle-myths-mysteries-disappearances-vanishes

