# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Huawei's last flagship :(
 - [https://www.youtube.com/watch?v=IPq0OX7ch48](https://www.youtube.com/watch?v=IPq0OX7ch48)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2020-10-23 00:00:00+00:00

Sponsored by Brilliant. The first 200 people to sign up get 20% off an annual plan at https://brilliant.org/techaltar

The Friday Checkout ep. 20

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► Quiz ◄◄◄ 

Weekly tech quiz: 
https://crrowd.com/quiz 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► TechAltar links ◄◄◄ 

Merch: 
https://enthusiast.store 

Crrowd Discord: 
https://discord.gg/npKQebe 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 

If you want to support TechAltar directly: 
https://flattr.com/@techaltar 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► Attributions ◄◄◄ 
Music by Edemski: 
https://soundcloud.com/edemski 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► Timestamps ◄◄◄ 

0:00 Intro 
0:34 Huawei's last flagship phone
2:50 Vivo comes to Europe
4:31 Goodbye Quibi

