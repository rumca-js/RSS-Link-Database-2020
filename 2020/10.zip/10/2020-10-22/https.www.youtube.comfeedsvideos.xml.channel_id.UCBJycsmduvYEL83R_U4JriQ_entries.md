# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Google Pixel 5 Review: Software Special!
 - [https://www.youtube.com/watch?v=NBLO6RpofIU](https://www.youtube.com/watch?v=NBLO6RpofIU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-10-23 00:00:00+00:00

Pixel 5 having a legendary camera is analogous to the entire rest of the phone!
Pixel 5 Grip case: https://dbrand.com/pixel-5-case
MKBHD Merch: http://shop.MKBHD.com

Pixel 5: https://store.google.com/us/product/pixel_5
Pixel 4A 5G: https://store.google.com/us/product/pixel_4a_5g

MrMobile Review video: https://youtu.be/-Se_HrAfFz8

Top 5 Android 11 Features: https://youtu.be/pLjtItOE88s

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Beyond by Overwerk
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by Google for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

## Huawei Mate 40 Pro Impressions: Technically Awesome!
 - [https://www.youtube.com/watch?v=j5zvFXmSGKY](https://www.youtube.com/watch?v=j5zvFXmSGKY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-10-22 00:00:00+00:00

Huawei's new smartphone is technically really good. But don't buy it. Again.

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Jordyn Edmonds http://smarturl.it/jordynedmonds
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by Huawei for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

