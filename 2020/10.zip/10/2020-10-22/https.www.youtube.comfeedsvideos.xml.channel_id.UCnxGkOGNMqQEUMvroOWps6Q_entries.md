# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Joe Discusses Wine Fraud Documentary "Sour Grapes" with Maynard James Keenan
 - [https://www.youtube.com/watch?v=m_ROYL1l2zg](https://www.youtube.com/watch?v=m_ROYL1l2zg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-10-23 00:00:00+00:00

#1553 w/Maynard James Keenan: https://open.spotify.com/episode/61zSjnaZ4Z6Bz98zTmFWtl?si=cmXsJQM3RF-vXybbnqK5gA

## Joe Rogan Praises Brian Ortega's Performance Against "Korean Zombie"
 - [https://www.youtube.com/watch?v=bgt5iurV9mE](https://www.youtube.com/watch?v=bgt5iurV9mE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-10-23 00:00:00+00:00

#1553 w/Maynard James Keenan: https://open.spotify.com/episode/61zSjnaZ4Z6Bz98zTmFWtl?si=cmXsJQM3RF-vXybbnqK5gA

## Rudy Giuliani's Borat Prank
 - [https://www.youtube.com/watch?v=T1-ITqczam0](https://www.youtube.com/watch?v=T1-ITqczam0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-10-23 00:00:00+00:00

#1553 w/Maynard James Keenan: https://open.spotify.com/episode/61zSjnaZ4Z6Bz98zTmFWtl?si=cmXsJQM3RF-vXybbnqK5gA

## Matthew McConaughey Discusses His Religious Beliefs
 - [https://www.youtube.com/watch?v=9uaw7OQ0vbo](https://www.youtube.com/watch?v=9uaw7OQ0vbo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-10-22 00:00:00+00:00

#1552 w/Matthew McConaughey:
https://open.spotify.com/episode/15eJWDILCbXFI3B2whkBTr

## Matthew McConaughey on Physically Transforming for Dallas Buyers Club
 - [https://www.youtube.com/watch?v=npJVN5-ZO2w](https://www.youtube.com/watch?v=npJVN5-ZO2w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-10-22 00:00:00+00:00

#1552 w/Matthew McConaughey: https://open.spotify.com/episode/15eJWDILCbXFI3B2whkBTr

## What Made Matthew McConaughey Realize He Wanted to Act
 - [https://www.youtube.com/watch?v=xXBOOlGr2EM](https://www.youtube.com/watch?v=xXBOOlGr2EM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-10-22 00:00:00+00:00

#1552 w/Matthew McConaughey: https://open.spotify.com/episode/15eJWDILCbXFI3B2whkBTr

