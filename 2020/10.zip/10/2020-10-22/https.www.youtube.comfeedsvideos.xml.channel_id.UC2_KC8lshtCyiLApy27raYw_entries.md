# Source:KnowledgeHusk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw, language:en-US

## Scooby Doo 2002: The Best Film Ever Made
 - [https://www.youtube.com/watch?v=5wa7QxegSFE](https://www.youtube.com/watch?v=5wa7QxegSFE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw
 - date published: 2020-10-22 00:00:00+00:00

“I awoke in a cold sweat. I had that dream again. The one with the van, the unrelenting dog. A twisted fiend, unholy in nature. He spoke to me, albeit muffled through the dense shrieks of his crew. I should have guessed their motive well before I entered that decrepit town of Coolsville.
The easiest way to solve a mystery is to incite it’s creation” - Scooby Doo, 2002

twitter:
https://twitter.com/KnowledgeHubTy

Soundcloud:
https://soundcloud.com/user-503704039

Patreon:
https://www.patreon.com/theknowledgehub

Second Channel:
https://www.youtube.com/channel/UC-KL04Ra6E1Du0pFawN4pWg

Spotify:
https://open.spotify.com/artist/3STpelEilrthF8UxsQTaaw?si=52TH_ZKTQhaKhfnK1Jomfg

My rss website:
www.borfed.com

Additional Clip Sources:
sboss

