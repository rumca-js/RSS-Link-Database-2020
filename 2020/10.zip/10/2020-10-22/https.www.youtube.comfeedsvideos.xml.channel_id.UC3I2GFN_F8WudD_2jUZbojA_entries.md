# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Fantastic Negrito - An Honest Man (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=HjDt3qJw-OA](https://www.youtube.com/watch?v=HjDt3qJw-OA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-23 00:00:00+00:00

http://KEXP.ORG presents Fantastic Negrito performing “An Honest Man” live at home, recorded exclusively for KEXP.

https://fantasticnegrito.com
http://kexp.org

## Fantastic Negrito - How Long? (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=t7EMLf5TB-A](https://www.youtube.com/watch?v=t7EMLf5TB-A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-23 00:00:00+00:00

http://KEXP.ORG presents Fantastic Negrito performing “How Long?” live at home, recorded exclusively for KEXP.

https://fantasticnegrito.com
http://kexp.org

## Fantastic Negrito - In The Pines (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=VpgBiii5FDc](https://www.youtube.com/watch?v=VpgBiii5FDc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-23 00:00:00+00:00

http://KEXP.ORG presents Fantastic Negrito performing “In The Pines” live at home, recorded exclusively for KEXP.

https://fantasticnegrito.com
http://kexp.org

## Fantastic Negrito - Night Has Turned To Day (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=stDPLT7_Nts](https://www.youtube.com/watch?v=stDPLT7_Nts)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-23 00:00:00+00:00

http://KEXP.ORG presents Fantastic Negrito performing “Night Has Turned To Day” live at home, recorded exclusively for KEXP.

https://fantasticnegrito.com
http://kexp.org

## Fantastic Negrito - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=tsNSexNDCjw](https://www.youtube.com/watch?v=tsNSexNDCjw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-23 00:00:00+00:00

http://KEXP.ORG presents Fantastic Negrito sharing a set of songs recorded live at home, exclusively for KEXP, and talking to Larry Mizell, Jr.. Recorded October 15, 2020.

Songs:
So Happy I Cry
Night Has Turned To Day
How Long?
In The Pines
An Honest Man

https://fantasticnegrito.com
http://kexp.org

## Fantastic Negrito - So Happy I Cry (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=vrbYYS42_pk](https://www.youtube.com/watch?v=vrbYYS42_pk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-23 00:00:00+00:00

http://KEXP.ORG presents Fantastic Negrito performing “So Happy I Cry” live at home, recorded exclusively for KEXP.

https://fantasticnegrito.com
http://kexp.org

## KEXP-VISION: A Two-Day Live on KEXP Special Event & Fundraiser (Day 1)
 - [https://www.youtube.com/watch?v=BPDy6hQ8W3Q](https://www.youtube.com/watch?v=BPDy6hQ8W3Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-23 00:00:00+00:00

http://KEXP.ORG presents KEXP-VISION, A Two-Day Live on KEXP Special Event & Fundraiser, on October 23 & 24, from 2-5PM PT. 

Featuring highlights from the past decade of Live on KEXP sessions, behind-the-scenes moments, special guests, brand-new exclusive performances, and much more. Hosted by DJ Morgan, Cheryl Waters, and Eva Walker, alongside more of your favorite KEXP DJs.

Watch Day 2 here: KEXP-VISION: A Two-Day Live on KEXP: https://youtu.be/Z-UiB4Dqb48

## Gabriel Garzón-Montano - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=Xss3plgOjfE](https://www.youtube.com/watch?v=Xss3plgOjfE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-10-22 00:00:00+00:00

http://KEXP.ORG presents Gabriel Garzón-Montano sharing a stripped-down performance recorded exclusively for KEXP.

Golden Wings
Fruit Flies
Everything is Everything
Strange Relationship (Prince Cover)
17 Days/Pleas (Prince and the Revolution/Moses Sumney Mashup)
Bloom
Agüita
Anacaona (Cheo Feliciano Cover)
Todo Tiene Su Final (Willie Colón & Héctor Lavoe Cover)
El Malo (Willie Colón & Héctor Lavoe Cover)
6 8
Someone
Lullaby
Muñeca

https://gabrielgarzonmontano.com
http://kexp.org

