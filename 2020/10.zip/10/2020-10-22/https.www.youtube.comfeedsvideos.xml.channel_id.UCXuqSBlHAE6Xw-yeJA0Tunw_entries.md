# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## This is a REALLY bad take  - WAN Show October 23 , 2020
 - [https://www.youtube.com/watch?v=Wln8fayc-3c](https://www.youtube.com/watch?v=Wln8fayc-3c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-10-23 00:00:00+00:00

Enter for your chance to win a RTX 3080 at https://BuildRedux.com

Edit PDF with #PDFelement: https://lmg.gg/PDFelement

Get $5 sent to your Venmo account at https://JoinHoney.com/Linus

Check out Carpool Critics, our new movie podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Podcast Download: https://dts.podtrac.com/redirect.mp3/traffic.libsyn.com/secure/linustechtips/This_is_a_REALLY_bad_take__-_WAN_Show_October_23__2020.mp3

Timestamps (Courtesy of Michael O'Brien):
00:00:00 - Stream Start!
00:00:08 - And welcome to the WAN Show ladies and gentlemen
00:00:21 - Topic #2: Danish retailer on RTX 3000 supply (Jump to 00:32:50)
00:00:47 - Topic #3: Alleged RX 6800 benchmarks (Jump to 00:49:01)
00:00:53 - Topic #1: Tweets on the streaming industry (Jump to 00:03:25)
00:01:11 - Topic #4: Intel sold NAND business unit (Jump to 00:51:41)
00:01:42 - [Tepid] Intro
00:02:12 - Unofficial Topic #1: People Giving Linus Crap
00:03:29 - Topic #1: [Alex Hutchinson] @BangBangClick's Twitter Comments
 00:04:07 - The meat of the topic
00:05:05 - Linus back with the meme moments...
 00:05:06 - Luke's take
 00:09:14 - Linus' take
 00:12:43 - Streaming isn't the complete context
 00:15:15 - How the Industry reacted
 00:17:09 - But the EULA...
 00:18:30 - Let's not forget about Fair Use w/ anecdote
 00:23:10 - It is not cut and dry
 00:25:50 - Summary of argument
 00:26:45 - And L&L's assessment of Alex Hutchinson's tweet?
00:28:53 - Sponsors!
 00:28:57 - Honey - joinhoney.com/linus
 00:30:22 - Wondershare PDFelement - 50% off, link in description
 00:31:57 - Redux - buildredux.com
00:32:50 - Topic #2: Proshop, Danish retailer fulfillment stats
 00:33:08 - RTX 3090 stats
 00:34:12 - RTX 3080 stats
 00:34:46 - RTX 3070 stats, despite embargo
 00:36:53 - Manufacturing bottleneck behind the delay
 00:38:17 - Linus' opinion on the topic
 00:39:59 - In all seriousness though...
 00:43:53 - NCIS Story Time! - Gather 'round the Pentium 4 space heater, kids
00:48:45 - Back to UT #1 :p
00:49:01 - Topic #3: Alleged RX 6800 benchmarks
 00:50:20 - Luke's hot take
00:51:41 - Topic #4: Intel sold NAND business unit
 00:51:41 - Details of sale & reasoning
00:53:27 - Unofficial Topic #2: Secret Shopper is BACK!
 00:54:03 - SI's are: iBuyPower, CyberPower, Dell, HP, Main Gear, and Origin PCs
00:58:10 - 2nd stealth giveaway details...
00:59:13 - New floatplane.com entries, Lon.TV & Craft Computing
 00:59:34 - Craft Computing shot out (someone else want to tell me what the other is?)
01:00:14 - Unofficial Topic #3: Loot Box Lawsuits
 01:00:31 - The thoughts on the topic
01:02:39 - Uofficial Topic #4: McBroken
01:04:35 - Superchats!
 01:04:58 - Linus can't adopt you
 01:05:31 - DMCA & Copyright Policy
01:11:10 - LMG is hiring - linusmediagroup.com/jobs-1
01:12:56 - Bye!
01:12:59 - Outtro!

## The ALL MSI Gaming PC!
 - [https://www.youtube.com/watch?v=OaPt-19C2No](https://www.youtube.com/watch?v=OaPt-19C2No)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-10-22 00:00:00+00:00

Thanks to MSI for sponsoring this video! 

We're giving the people what they want, with a fresh build featuring MSI's new RTX 3080 Gaming Trio X alongside a TON of MSI's gaming components.

Buy MSI Optix MPG341CQR Monitor
On Amazon (PAID LINK): https://geni.us/GAARoK3
On Newegg (PAID LINK): https://geni.us/GS3m7
On B&H (PAID LINK): https://geni.us/5jwR9

Buy MSI MPG SEKIRA 500X Case
On Amazon (PAID LINK): https://geni.us/U5Njvp
On Best Buy (PAID LINK): https://shop-links.co/1721650291622632505
On Newegg (PAID LINK): https://geni.us/Du7dB5

Buy MSI MEG Z490 ACE
On Amazon (PAID LINK): https://geni.us/RENbwwV
On Best Buy (PAID LINK): https://shop-links.co/1721650398578466765
On Newegg (PAID LINK): https://geni.us/SBxAjR
On B&H (PAID LINK): https://geni.us/uRHmwnP

Buy CORSAIR Vengeance 32GB RAM
On Amazon (PAID LINK): https://geni.us/bWx6c1E
On Best Buy (PAID LINK): https://shop-links.co/1721650427554141509
On Newegg (PAID LINK): https://geni.us/QUaHQT
On B&H (PAID LINK): https://geni.us/gHHwI

Buy Intel Core i9-10900K CPU
On Amazon (PAID LINK): https://geni.us/NgVk2w6
On Best Buy (PAID LINK): https://shop-links.co/1721650459219488397
On Newegg (PAID LINK): https://geni.us/rlj4A
On B&H (PAID LINK): https://geni.us/e29YmN

Buy Corsair HX1000 PSU
On Amazon (PAID LINK): https://geni.us/J8OkuNQ
On Newegg (PAID LINK): https://geni.us/SA9DLZ7
On B&H (PAID LINK): https://geni.us/9LhiiV

Buy MSI RTX 3080 GAMING TRIO X
On Amazon (PAID LINK): https://geni.us/ZtnoGo
On Newegg (PAID LINK): https://geni.us/D7uAcyA
On B&H (PAID LINK): https://geni.us/yfFi5B

Buy Corsair Force Series MP600 2TB Gen4 PCIe
On Amazon (PAID LINK): https://geni.us/dBiBI4
On Newegg (PAID LINK): https://geni.us/JKSUr1p

Buy MSI MAG CORELIQUID 360R AIO
On Amazon (PAID LINK): https://geni.us/JSJWv
On Newegg (PAID LINK): https://geni.us/6BeNzq
On B&H (PAID LINK): https://geni.us/wFOf

Buy MSI CLUTCH GM30 Mouse
On Amazon (PAID LINK): https://geni.us/TUZd
On Newegg (PAID LINK): https://geni.us/yWkPG1
On B&H (PAID LINK): https://geni.us/7xIKsbm

Buy MSI Vigor GK50 Elite LL Keyboard
On Amazon (PAID LINK): https://geni.us/wAJn0W
On Newegg (PAID LINK): https://geni.us/g4yu
On B&H (PAID LINK): https://geni.us/N19On2

Buy MSI IMMERSE GH50 Gaming Headset
On Amazon (PAID LINK): https://geni.us/2Bx7t
On Newegg (PAID LINK): https://geni.us/dML2
On B&H (PAID LINK): https://geni.us/3bQpjp

Buy MSI VIGOR WR01 Wrist Rest
On Amazon (PAID LINK): https://geni.us/cUp20H
On Newegg (PAID LINK): https://geni.us/GUm35n

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1260552-the-all-msi-pc/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Private Internet Access VPN: https://lmg.gg/pialinus2
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

