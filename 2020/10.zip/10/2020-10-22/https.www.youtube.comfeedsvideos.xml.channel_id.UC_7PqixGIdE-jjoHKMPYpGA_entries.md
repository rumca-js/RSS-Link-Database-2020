# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Czy maseczki działają?
 - [https://www.youtube.com/watch?v=2T41iw6Rzp8](https://www.youtube.com/watch?v=2T41iw6Rzp8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2020-10-23 00:00:00+00:00

👉 Patronite ► https://patronite.pl/NaukowyBelkot 
👕 Nasze koszulki ► https://naukowybelkot.shoplo.com/
📚 Moja książka ► https://altenberg.pl/geny/
👉 Film Tomka Rożka ► https://www.youtube.com/watch?v=dzs0NfM1jBs

Mix audio ► http://ratstudios.pl/

Nie będę się rozpisywał. Domyślacie się dlaczego ten film teraz powstał. Na pewno znacie kogoś, kto głośniej lub ciszej wątpi w skuteczność maseczek albo twierdzi, że jest to spisek i forma zniewolenia. Co więc na to nauka?

I przypominam, jeżeli już to czytasz, żeby regularnie zmieniać maseczki. Przypomnij proszę o tym innym w komentarzu, jeżeli zabraknie Ci pomysłu odnośnie tego, co napisać dla zasięgu.

👉 Film o sezonie grypowym ► https://www.youtube.com/watch?v=75qySnZ2in4 
===
Timestampy

0:00 Mój dowód anegdotyczny
3:14 Liczbowy kontekst
8:45 Jak i kiedy się zarażamy
12:05 Co robi maseczka
15:59 Maseczka maseczce nierówna
18:20 Skala mniejsza
20:35 Skala większa
24:31 Ale grypa...
26:26 Ostatnie pytanie

Subskrypcja ► https://youtube.com/c/UwagaNaukowyBelkot
Facebook ► https://facebook.com/UwagaNaukowyBelkot
Twitter ► https://twitter.com/NaukowyBelkot
Instagram ► https://www.instagram.com/NaukowyBelkot/

Wyłącznie Naukowy Bełkot ► https://goo.gl/Do7VCc
Grupa na facebooku ► https://goo.gl/HP8J83

===
Źródła (wybrane):

The Royal Society - Face masks and coverings for the general public: Behavioural knowledge, effectiveness of cloth coverings and public messaging
Y. Miyamae i in. - Duration of viral shedding in asymptomatic or mild cases of novel coronavirus disease 2019 (COVID-19) from a cruise ship: A single-hospital experience in Tokyo, Japan
D. K. Chu i in. - Physical distancing, face masks, and eye protection to prevent person-to-person transmission of SARS-CoV-2 and COVID-19: a systematic review and meta-analysis
P. Doung-ngern i in. - Case-Control Study of Use of Personal Protective Measures and Risk for SARS-CoV 2 Infection, Thailand
Y. J. Hou i in. - SARS-CoV-2 Reverse Genetics Reveals a Variable Infection Gradient in the Respiratory Tract
M. Gandhi i in. - Masks Do More Than Protect Others During COVID-19: Reducing the Inoculum of SARS-CoV-2 to Protect the Wearer
E. P. Fisher i in. - Low-cost measurement of face mask efficacy for filtering expelled droplets during speech
K. A. Prather i in. - Reducing transmission of SARS-CoV-2
T. T. Leffler i in. - Association of country-wide coronavirus mortality with demographics, testing, lockdowns, and public wearing of masks (Update August 4, 2020).
S. Bae i in. - Effectiveness of Surgical and Cotton Masks in Blocking SARS-CoV-2: A Controlled Comparison in 4 Patients
A. F. Melicor i in. - Is SARS-CoV-2 transmitted by asymptomatic and pre-symptomatic individuals?
Y. Sohn i in. - Assessing Viral Shedding and Infectivity of Asymptomatic or Mildly Symptomatic Patients with COVID-19 in a Later Phase
W. Yi i in. - Virus shedding dynamics in asymptomatic and mildly symptomatic patients infected with SARS-CoV-2
D. He i in. - The relative transmissibility of asymptomatic COVID-19 infections among close contacts
G. Morone i in. - Incidence and Persistence of Viral Shedding in COVID-19 Post-acute Patients With Negativized Pharyngeal Swab: A Systematic Review
P. K. Cheng i in. - Viral shedding patterns of coronavirus in patients with 
probable severe acute respiratory syndrome
https://www.iamexpat.nl/expat-info/dutch-expat-news/rivm-says-there-no-evidence-prove-effectiveness-face-masks?fbclid=IwAR3GfvXuPGkCHmb47kuxISi7XPe8f3xripxU6RtY5mmJ4ocVsw1DiSRfx2Y


https://www.cebm.net/study/clinical-course-and-viral-shedding-among-patients-with-sars-cov-2/
https://www.physiciansweekly.com/covid-19-asymptomatic-infection-delayed-symptoms-common-in-children/
https://www.vox.com/future-perfect/21299527/masks-coronavirus-covid-19-studies-research-evidence?__c=1
https://www.aamc.org/news-insights/science-and-psychology-behind-masking-prevent-spread-covid-19
https://rs-delve.github.io/addenda/2020/07/07/masks-update.html
https://theconversation.com/three-major-scientific-controversies-about-coronavirus-144021
https://discoveries.childrenshospital.org/covid-19-mask-science/
https://www.nature.com/articles/d41586-020-02801-8
https://www.ucsf.edu/news/2020/06/417906/still-confused-about-masks-heres-science-behind-how-face-masks-prevent
https://today.yougov.com/topics/international/articles-reports/2020/03/17/personal-measures-taken-avoid-covid-19
https://www.wsj.com/articles/face-masks-really-do-matter-the-scientific-evidence-is-growing-11595083298
https://www.rivm.nl/en/novel-coronavirus-covid-19/face-masks-and-gloves

