# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## The Fact Checkers
 - [https://www.youtube.com/watch?v=AmKPbYbAnKE](https://www.youtube.com/watch?v=AmKPbYbAnKE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-10-22 00:00:00+00:00

Get your Magnesium Breakthrough Here - https://MagnesiumBreakthrough.com/JP

Ever wonder who is doing all the censoring? Meet the fact checkers. The censorship of false information is important work in order to control how people think. Go behind the scenes and meet the fact checkers that determine what’s true and what’s false.

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

