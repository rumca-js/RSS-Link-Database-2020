# Source:Cercle, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ, language:en-US

## Christian Löffler - Ronda | Cercle Stories
 - [https://www.youtube.com/watch?v=9gx3Ik-l6kc](https://www.youtube.com/watch?v=9gx3Ik-l6kc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ
 - date published: 2020-10-22 00:00:00+00:00

Christian Löffler playing an ethereal live session in Ronda, Andalusia, Spain, a Cercle Stories. 
Cercle Stories is our new short video concept, it's a one track live session for our Cercle Records releases. 

☞ Cercle Records: 
Christian Löffler - Ronda: https://Cercle.lnk.to/ChristianLofflerRonda

The track is part of the limited edition vinyl compilation OUT NOW! 
More info here: https://Cercle.lnk.to/vinyls

☞ Support us and get access to exclusive videos & perks: https://Cercle.lnk.to/Patreon
☞ Listen to our playlists, tracks & sets: https://Cercle.lnk.to/Playlists
☞ Subscribe to our newsletter to know about our next shows: https://Cercle.lnk.to/Members
☞ Subscribe to our YouTube channel: Cercle.lnk.to/ytcercle

☞ Christian Löffler
https://www.instagram.com/christianloeffler/
https://www.facebook.com/christianloefflerofficial
https://open.spotify.com/artist/3tSvlEzeDnVbQJBTkIA6nO?si=wM7RBRBjQeeBumZyZfj0lQ
https://music.apple.com/fr/artist/christian-l%C3%B6ffler/334282801?l=en

Video credits:

Artist: Christian Löffler
Location: Ronda, Andalusia, Spain 
Producer: Derek Barbolla
Artistic director: Philippe Tuchmann
Director: Pol Souchier
DOP, Editing & Post-production: Mathieu Glissant (Saison Unique Production)
Cameramen: Mickaël Fidjili & Mathieu Glissant
Drone pilot: Alexis Olas
Sound and video assistant: Aurélien Moisan
Production team: Anaïs de Framond, Dan Aufseesser, Armand Prouhèze
Technical Manager: Aurélien Moisan
Communication: Anaëlle Rouquette
Stage design: Marvin Weymeersch & Cameron Heal
Technicians: Noah Azouagh & Isaac Martin

--
Special thanks to:
Miguel Guerrero from the tourism office of Ronda & Sergio Bote from the tourism office of Spain. 
Galerie Joseph. 


______

Follow us on http://www.cercle.io

