# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## "Get Rich Guru" Mocks Minimum Wage
 - [https://www.youtube.com/watch?v=PA07yqjDv5E](https://www.youtube.com/watch?v=PA07yqjDv5E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-10-22 00:00:00+00:00

Buying this course is like sticking a key into a Lamborghini, but trust me... It's not a get rich quick scheme. 

Oh and you'll make $100,000 by working 1 day a week. 

ROFL.

Six Figure Sunday terms of service
NOTE: Due to the tremendous value given throughout the course you will not be eligible for a refund if you purchased "The Six Figure Sunday" at a discount price
https://www.sixfiguresunday.com/terms-of-service25809226
this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.
#fakeguru #coffeezilla #sixfigures

