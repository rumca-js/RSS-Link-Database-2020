# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## Fixing Daylight Saving Time Is THIS Easy
 - [https://www.youtube.com/watch?v=bMrb56dDpic](https://www.youtube.com/watch?v=bMrb56dDpic)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2020-03-10 00:00:00+00:00

PBS Member Stations rely on viewers like you. To support your local station, go to: http://to.pbs.org/DonateOKAY
↓ More info and sources below ↓

We’re on PATREON now! Join the community ►► https://www.patreon.com/itsokaytobesmart
SUBSCRIBE so you don’t miss a video! ►► http://bit.ly/iotbs_sub 

Every year, hundreds of millions of people voluntarily turn their lives upside down by setting their clocks forward one hour in the spring and back one hour in the autumn on a particular date mandated by the government wherever they happen to live. Daylight saving time is a perfect example of how a few people with the best of intentions can end up annoying millions of the rest of us for the better part of a century. And it’s time we take an honest look at how we got to this place where half the world comes unstuck in time twice a year, and ask if the supposed advantages for springing forward and falling back still hold up! #daylightsavingtime #DST

References: https://sites.google.com/view/fixing-daylight-saving-time/home

My video about the invention of metric system: https://www.youtube.com/watch?v=e3eHHwcMVcA

Special thanks to our Brain Trust Patrons:
AlecZero
Brent M.
Diego Lombeida
Ernesto Silva
George Gladding
Marcus Tuepker
Ron Kakar
vincbis

-----------
Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/

