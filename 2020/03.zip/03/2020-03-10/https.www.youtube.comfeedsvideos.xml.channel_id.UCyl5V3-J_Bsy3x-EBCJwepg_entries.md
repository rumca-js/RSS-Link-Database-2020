# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Are You Smarter Than A Journalist?
 - [https://www.youtube.com/watch?v=sZgWu9Y8MbU](https://www.youtube.com/watch?v=sZgWu9Y8MbU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-03-11 00:00:00+00:00

This is the Babylon Bee weekly news podcast for the week of 3/11/2020.

 In this episode of The Babylon Bee podcast, editor-in-chief Kyle Mann and creative director Ethan Nicolle discuss the week’s big stories like all the democratic candidates joining their powers together into a giant mech to take down Bernie Sanders, Brian Williams’ math makes everything clear for us, and Elizabeth Warren heads back home. ‘Are You Smarter Than A Journalist?’ becomes a real game show and Kyle and Ethan talk about billionaires. 

 In the subscriber portion, Kyle and Ethan talk about how women have tricked men into cooking and also discuss a Chick-Fil-A miracle. Ethan also pontificates on whether or not flies have souls.

  Pre-order the new Babylon Bee Best-Of Coffee Table Book coming in 2020!

 Show Outline

 Introduction - Kyle and Ethan talk about how we’re not supposed to talk about cognitive decline and flubber-diddles. Ethan got to see comedian Norm MacDonald live. Coronavirus travel restrictions change some of Kyle’s family plans.

 Story 1 -  Dems Combine Into Giant Mech To Annihilate Bernie Sanders

   Right before Super Tuesday, Pete Buttigieg, Amy Klobuchar dropped out giving Biden a dominating election night.

   Biden got the Robert Francis O’Rourke to endorse him and promised Beto that he could head up his gun control efforts

   After a disappointed Super Tuesday, Bloomberg dropped out and endorsed Biden too.

   Kamala Harris endorsed Biden too.

   Story 2 -   Brian Williams To Host New Game Show 'Are You Smarter Than A Journalist?'

   How many people didn’t catch this before airing this segment? Producer, scriptwriter, graphics guy, Brian, guest, etc.

   “Brian Williams” hosts an exciting episode of ‘Are You Smarter Than A Journalist?’ 

   Story 3 -   Warren Returns To Tribe In Shame After Failing To Take Land Back From The Pale Faces

   It’s a sad story.

   Topic of the Week - Income inequality and the idea that billionaires are just sitting in a vault of hoarded cash and could solve everyone else’s problems if they gave away all their cash. Looking at income inequality from Christian worldview.

 Love Mail/Hate Mail/ Feedback -  A reverend complains about having to keep explaining to people that the Babylon Bee is “SPOOF!”

 Paid-subscriber portion (Starts at 00:56:05)

 Story 1 -  Miracle: Coronavirus Passes Over Houses With Chick-Fil-A Sauce Smeared On Door Posts

 Story 2 -  Historians: Women Invented Grilling To Trick Men Into Cooking

  Become a paid subscriber at https://babylonbee.com/plans

