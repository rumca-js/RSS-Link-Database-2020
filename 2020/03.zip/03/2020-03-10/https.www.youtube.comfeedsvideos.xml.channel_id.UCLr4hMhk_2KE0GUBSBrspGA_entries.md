# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## PowerEgg X Wizard - Wodoodporny dron i gimbal w jednym!
 - [https://www.youtube.com/watch?v=3jJ2rkYW5YM](https://www.youtube.com/watch?v=3jJ2rkYW5YM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-03-10 00:00:00+00:00

PowerEgg X, czyli dron jajo. Jego możliwości porównaliśmy do Mavica Pro, Mavica 2 Pro i Mavica 2 Zoom. Poddaliśmy go wielu wymagającym testom i oddaliśmy w ręce profesjonalistów, którym jesteśmy mega wdzięczni za pomoc.
Rafał z Warsaw By Dron: http://bit.ly/2TBRSZI
Zimowy Narodowy (dzięki bardzo za udostępnienie miejsca do nagrań!):
http://bit.ly/2vMbZLI
Instruktorki ze szkoły ICE & FUN Renaty Aleksander: http://bit.ly/2TWI6jN
Bracia Wielgosz ścigający się dronami: http://bit.ly/DronySportowe1
http://bit.ly/DronySportowe2
OSP URSUS (dzięki za super klimat i profesjonalizm!): http://bit.ly/2wLLmGy

Linki do dronów:
PowerEgg X Wizard: http://bit.ly/2wMslnq
PowerEgg X Explorer (bez opcji wodoodpornych): http://bit.ly/2wNmzlr
Mavic Pro: http://bit.ly/3cFoQ2G
Mavic 2 Pro: http://bit.ly/2TQQAsJ
Mavic 2 Zoom: http://bit.ly/2Q3XOby

