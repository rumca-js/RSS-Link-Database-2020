# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## THE DRAGONBONE CHAIR: MEMORY SORROW THORN - REVIEW
 - [https://www.youtube.com/watch?v=mXLKVTx4iPQ](https://www.youtube.com/watch?v=mXLKVTx4iPQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-03-11 00:00:00+00:00

My review of Memory Sorrow Thorn's The Dragonbone Chair, by Tad Williams. 
GET THE BOOK HERE: https://amzn.to/2wJZ5hq
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## First Law RELEASE DATE! Christpher Paolini's Scifi REVEAL! Altered Carbon Trailer - FANTASY NEWS
 - [https://www.youtube.com/watch?v=Hnd18RmU3zw](https://www.youtube.com/watch?v=Hnd18RmU3zw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-03-10 00:00:00+00:00

Everything from the MCU to Tor Covers updates! Let's jump into the FANTASY NEWS! 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

NEWS: 
The Trouble With Peace Release Date: https://twitter.com/lordgrimdark/status/1237083395685056513?s=12 https://twitter.com/LordGrimdark/status/1235985386142420994?s=09

Guardians of the Galaxy Thor Love & Thunder: https://twitter.com/lightscamerapod/status/1237091735899168768?s=12

Rise Of The Red Hand: https://www.tor.com/2020/03/09/erewhon-books-announces-rise-of-the-red-hand/

Harrow The Ninth Preview: https://twitter.com/tordotcompub/status/1237027497646198784?s=12

The Kraken’s Tooth: https://twitter.com/writer_anthony/status/1237065184272953345?s=12

Writing Toss A Coin To Your Witcher: https://www.tor.com/2020/03/09/the-witcher-team-shares-how-they-wrote-toss-a-coin-to-your-witcher/

Burning Voldemort Question: https://www.cinemablend.com/news/2491573/harry-potter-daniel-radcliffe-attempts-to-answer-a-voldemort-question-fans-have-asked-for-years

The Platform: https://www.tor.com/2020/03/06/netflixs-the-platform-looks-like-high-rise-meets-snowpiercer-but-set-in-a-prison/

Natalie Dormer Witcher: https://twitter.com/RedanianIntel/status/1236201475816206338

Wings Of Fire Adaptation: https://deadline.com/2020/03/ava-duvernay-wings-of-fire-books-adaptation-warner-bros-tui-t-sutherland-1202875630/

Christian Bale Thor 4: https://www.facebook.com/59685491632/posts/10157534163631633/?substory_index=0&sfnsn=mo

Lost In Space Lost: https://www.gamespot.com/articles/danger-will-robinson-netflixs-lost-in-space-is-com/1100-6474558/

New Mutants NO RESHOOTS: https://ew.com/movies/the-new-mutants-reshoots-josh-boone-maisie-williams/

To Sleep In A See Of Stars COVER: https://www.paolini.net/works/to-sleep-in-a-sea-of-stars/

