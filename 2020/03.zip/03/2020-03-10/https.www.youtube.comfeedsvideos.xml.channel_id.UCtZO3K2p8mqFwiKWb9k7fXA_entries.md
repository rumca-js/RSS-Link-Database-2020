# Source:Techaltar, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA, language:en-US

## Firefox OS is back... on KaiOS
 - [https://www.youtube.com/watch?v=_UPk3mpcDP4](https://www.youtube.com/watch?v=_UPk3mpcDP4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA
 - date published: 2020-03-11 00:00:00+00:00

Exclusive: Mozilla will officially start supporting KaiOS now and Firefox updates will start rolling out to KaiOS starting with ESR version 78. Is this essentially Firefox OS reborn? 



Twitter poll: https://twitter.com/TechAltar/status/1237727436604874754?s=20



[[[ TECHALTAR LINKS ]]]:

Merch: 
http://enthusiast.store 

Social media:
https://twitter.com/TechAltar
https://instagram.com/TechAltar
https://facebook.com/TechAltar

If you want to support TechAltar directly:
https://flattr.com/@techaltar

My video gear:
https://kit.co/TechAltar/video-gear

[[[ ATTRIBUTIONS ]]]:

Music by Edemski:
https://soundcloud.com/edemski
https://facebook.com/edemskimusic

