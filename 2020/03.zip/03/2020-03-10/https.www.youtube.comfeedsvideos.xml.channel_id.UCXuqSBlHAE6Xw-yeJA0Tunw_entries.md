# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## This Video Card Costs Over $5000
 - [https://www.youtube.com/watch?v=8EcMKg7awXg](https://www.youtube.com/watch?v=8EcMKg7awXg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-03-11 00:00:00+00:00

Get $25 off Vessifootwear with offer code LINUSTECHTIPS at https://www.vessifootwear.com/linustechtips

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire

Would you spend over $5,000 on a graphics card? If yes, should you do it?...

Buy Quadro RTX 
On Amazon (PAID LINK): https://geni.us/Lty9R
On Newegg (PAID LINK): https://geni.us/rqty

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1163969-this-video-card-costs-over-5000/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Get your ticket to LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

## We tried Android 11.
 - [https://www.youtube.com/watch?v=05X0RRmUtE0](https://www.youtube.com/watch?v=05X0RRmUtE0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-03-10 00:00:00+00:00

Sign up for Private Internet Access VPN at https://lmg.gg/pialinus2

Receive an additional $25 credit for Ting today when you sign up at https://linus.ting.com/

The first Developer Preview for Android 11 is here - so is it any good?

More Info: https://developer.android.com/preview

Buy Pixel 4
On Google Store : https://geni.us/ZmjSyv7
On Amazon (Paid Link): https://geni.us/fLjg
On Walmart (Paid Link): https://geni.us/Y9k9wTj
On NewEgg (Paid Link): https://geni.us/1fPONtA

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1163667-android-11-is-already-here/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Get your ticket to LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

