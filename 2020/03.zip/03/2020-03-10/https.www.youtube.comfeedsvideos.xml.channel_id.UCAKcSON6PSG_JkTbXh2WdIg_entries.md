# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Listen to Looch: ZZ Top documentary
 - [https://www.youtube.com/watch?v=mcFqBEJI8OE](https://www.youtube.com/watch?v=mcFqBEJI8OE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-03-11 00:00:00+00:00

Mary Lucia talks about a documentary on Netflix, 'ZZ Top: That Little Ol' Band From Texas.' The film covers the complete story of the band, from its origins in psychedelic rock to MTV superstars to inveterate rockers.
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

