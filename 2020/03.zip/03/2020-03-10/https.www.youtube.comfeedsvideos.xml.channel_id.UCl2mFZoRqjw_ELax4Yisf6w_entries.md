# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## The ONE person stopping Right To Repair in Minnesota
 - [https://www.youtube.com/watch?v=E1p0WOl25nQ](https://www.youtube.com/watch?v=E1p0WOl25nQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-03-11 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
https://www.senate.mn/members/member_bio.php?member_id=1174


🔵 Patreon https://www.patreon.com/rossmanngroup

## USPS, please stop losing our packages 😢
 - [https://www.youtube.com/watch?v=kHlbgSr1nmc](https://www.youtube.com/watch?v=kHlbgSr1nmc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-03-10 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
https://youtu.be/G4CCuMg6jXI

## the man in the thumbnail is a sadistic murderer
 - [https://www.youtube.com/watch?v=y_v7p3xEPDM](https://www.youtube.com/watch?v=y_v7p3xEPDM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-03-10 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
10:58 



https://www.youtube.com/watch?v=GWxGYewQmXA

