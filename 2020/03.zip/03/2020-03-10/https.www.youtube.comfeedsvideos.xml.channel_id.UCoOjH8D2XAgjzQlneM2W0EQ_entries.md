# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## How to Get Rich Bribing Politicians
 - [https://www.youtube.com/watch?v=AwM0REBUpag](https://www.youtube.com/watch?v=AwM0REBUpag)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2020-03-11 00:00:00+00:00

💵 Get 15% OFF Forbe's favorite Smart Wallet here with coupon code JAKETRAN-15: http://bit.ly/jt-ekster

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join 

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
📸 Follow me on IG:@jaketran // http://bit.ly/jt-ig
👨👦👦 Join the Tran Mafia Family here: https://bit.ly/patreon-jt
💬 Join the community Discord: http://discord.gg/BmK8EnQ

Stuff I use & recommend:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
🏠 The real estate investing course I love & recommend: https://jake.yt/RE
🌐 Most flexible, affordable website hosting: https://jake.yt/bhd
🖥️ Website platform I use & love: https://jake.yt/kd
💽 Editing software I've used for 7+ years: https://jake.yt/ccd
📒 Online bookkeeping software I use& love: https://jake.yt/benchd 
🧾 Best affordable bookkeeping software: https://jake.yt/fbd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd
📚 Get 3 free audiobooks for life: https://amzn.to/2v58PSu
🎥 My video gear, setup, tech, books: https://jake.yt/stored

✉️ Email me: jake@jaketran.io

Subscribe to the backup channel on LBRY, use reward code "jake-cast" for free coin: https://bit.ly/LBRY-jt

📰 Sources & visuals // http://bit.ly/32WFhDi

-----------------------
Back in the old days, if you were an entrepreneur that managed to make it big, and built yourself a nice giant successful business, you were on top of the world
But you’re ambitious - you want more - more money, more profits
But putting more money into R&D, into building a better product will only get you so far
You turn to selling your products for a loss, buying up your competitors, buying up other businesses in your product’s supply chain, and other monopolistic practices
With those pesky antitrust laws, that’s just not an option anymore, you might have to keep innovating to stay alive
Instead of working harder, providing a better service, and innovating to grow and stay afloat, we could have the government crush our competitors for us?
“Well gee, Jake. That sounds all good but how would anyone be okay with giving the government that much power to make the lives of big businesses easier?”
Instead of proclaiming to everyone our monopolistic intentions, we just say that it’s in the “public’s best interest”
We tell the world and congress that we need gov to protect consumers from greedy, unsafe businesses
We need to learn the game of crony capitalism

In 1998 Microsoft was the biggest company in the world, the most innovative companies in the world
Microsoft and Bill Gates thought that “business is going great, our customers love our products”
They spent zero dollars on lobbying or cronyism
When politicians kept seeing just how much money Microsoft was making Bill Gates is called into the Senate
And six months later, Microsoft got another knock on the door from the Justice Department
Microsoft was found guilty for giving away a product for free and spent the next nearly 10 years fighting that case, devoting time, resources, and lots of money to it
If you're making money and you don’t pander to the politicians, they'll come to your door, so why not profit from it too?

The other big tech companies have learned from Microsoft’s mistakes and now take a more offensive approach
Amazon was facing a lot of bad press about their low minimum wage, so Jeff Bezos raised the minimum wage to $15 for all Amazon workers and announced that he’ll be lobbying Congress to increase the minimum wage
AKA, he's gently bribing politicians to allow the  government to force his competitors expenses up 
-----------------------

🌅 Join my Facebook Group for going remote // http://bit.ly/remote-job

-----------------------

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2020 Jake Tran. All rights reserved.

Sound:


Music by Chillhop: http://chillhop.com/listen
Listen on Spotify: http://bit.ly/ChillhopSpotify

DISCLAIMER: These videos are for entertainment purposes only. This is not meant to be financial advice. Please always do your due diligence and never stop learning. Best of luck!

AFFILIATE DISCLOSURE: Some of the links in this video description are affiliate links, meaning, at no additional cost to you, I may earn a commission if you click through and make a purchase and/or subscribe. I only promote products that I 100% believe in.

