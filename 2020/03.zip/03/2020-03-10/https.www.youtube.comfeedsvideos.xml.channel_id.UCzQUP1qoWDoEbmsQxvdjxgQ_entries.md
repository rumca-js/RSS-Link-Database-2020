# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Joe Rogan Experience #1439 - Michael Osterholm
 - [https://www.youtube.com/watch?v=E3URhJx0NSw](https://www.youtube.com/watch?v=E3URhJx0NSw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2020-03-10 00:00:00+00:00

Michael Osterholm is an internationally recognized expert in infectious disease epidemiology. He is Regents Professor, McKnight Presidential Endowed Chair in Public Health, the director of the Center for Infectious Disease Research and Policy (CIDRAP), Distinguished Teaching Professor in the Division of Environmental Health Sciences, School of Public Health, a professor in the Technological Leadership Institute, College of Science and Engineering, and an adjunct professor in the Medical School, all at the University of Minnesota. Look for his book "Deadliest Enemy: Our War Against Deadly Germs" for more info. https://amzn.to/2IAzeLe
http://www.cidrap.umn.edu/

