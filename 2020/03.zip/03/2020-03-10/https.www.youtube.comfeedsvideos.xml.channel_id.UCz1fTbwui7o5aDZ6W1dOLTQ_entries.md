# Source:Literature Devil, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCz1fTbwui7o5aDZ6W1dOLTQ, language:en-US

## Why J. J. Abrams' Mystery Box is Terrible and How to Fix It
 - [https://www.youtube.com/watch?v=uXN3ZqN8kgs](https://www.youtube.com/watch?v=uXN3ZqN8kgs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCz1fTbwui7o5aDZ6W1dOLTQ
 - date published: 2020-03-10 00:00:00+00:00

J. J. Abrams' Mystery Box has become infamous for running stories astray. Let's check out how to fix it.

Dr. Alpha Miracle Child: https://www.indiegogo.com/projects/doctor-alpha-miracle-child-graphic-novel/x/22169562#/

SubscribeStar: https://www.subscribestar.com/literature-devil

Reylo Tears Mug (White): https://teespring.com/reylo-tears-mug-white?pid=658&cid=102908

Reylo Tears Mug (Black): https://teespring.com/reylo-tears-mug-black?pid=658&cid=102950

MLGA Mug: https://bit.ly/2wuhzlW

I'm Just Awesome Mug (White): https://teespring.com/i-m-just-awesome-mug-white?pid=658&cid=102908

I'm Just Awesome Mug (Black): https://teespring.com/i-m-just-awesome-mug-black?pid=658&cid=102950

MLGA Shirt (White): https://teespring.com/mlga-shirt-white?pid=2&cid=2122

MLGA Shirt (Black): https://teespring.com/mlga-shirt-black?pid=2&cid=2397

