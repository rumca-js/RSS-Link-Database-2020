# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Preservation Hall Jazz Band - Convergence (Live on KEXP)
 - [https://www.youtube.com/watch?v=5Eb23IS5Q8w](https://www.youtube.com/watch?v=5Eb23IS5Q8w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-03-11 00:00:00+00:00

http://KEXP.ORG presents Preservation Hall Jazz Band performing "Convergence" live in the KEXP studio. Recorded November 18, 2019.

Host: Troy Nelson
Audio Engineers: Kevin Suggs & Craig Walker
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://www.preservationhalljazzband.com

## Preservation Hall Jazz Band - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=qoPxTShCUCE](https://www.youtube.com/watch?v=qoPxTShCUCE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-03-11 00:00:00+00:00

http://KEXP.ORG presents Preservation Hall Jazz Band performing live in the KEXP studio. Recorded November 18, 2019.

Songs:
Convergence
Malecón
Keep Your Head Up
Sugar Plum

Host: Troy Nelson
Audio Engineers: Kevin Suggs & Craig Walker
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://www.preservationhalljazzband.com

## Preservation Hall Jazz Band - Keep Your Head Up (Live on KEXP)
 - [https://www.youtube.com/watch?v=YY6wJeMBRtQ](https://www.youtube.com/watch?v=YY6wJeMBRtQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-03-11 00:00:00+00:00

http://KEXP.ORG presents Preservation Hall Jazz Band performing "Keep Your Head Up" live in the KEXP studio. Recorded November 18, 2019.

Host: Troy Nelson
Audio Engineers: Kevin Suggs & Craig Walker
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://www.preservationhalljazzband.com

## Preservation Hall Jazz Band - Malecón (Live on KEXP)
 - [https://www.youtube.com/watch?v=WFMR3wa2bek](https://www.youtube.com/watch?v=WFMR3wa2bek)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-03-11 00:00:00+00:00

http://KEXP.ORG presents Preservation Hall Jazz Band performing "Malecón" live in the KEXP studio. Recorded November 18, 2019.

Host: Troy Nelson
Audio Engineers: Kevin Suggs & Craig Walker
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://www.preservationhalljazzband.com

## Preservation Hall Jazz Band - Sugar Plum (Live on KEXP)
 - [https://www.youtube.com/watch?v=6pVqHNfnHME](https://www.youtube.com/watch?v=6pVqHNfnHME)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-03-11 00:00:00+00:00

http://KEXP.ORG presents Preservation Hall Jazz Band performing "Sugar Plum" live in the KEXP studio. Recorded November 18, 2019.

Host: Troy Nelson
Audio Engineers: Kevin Suggs & Craig Walker
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://www.preservationhalljazzband.com

