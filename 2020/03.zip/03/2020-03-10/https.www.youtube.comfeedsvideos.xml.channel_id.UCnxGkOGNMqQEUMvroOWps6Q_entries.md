# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Before MMA Alexander Volkanovski Was a 214lb Rugby Player | Joe Rogan
 - [https://www.youtube.com/watch?v=EWVWmyEzw5I](https://www.youtube.com/watch?v=EWVWmyEzw5I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-11 00:00:00+00:00

Taken from MMA Show #93 w/Alexander Volkanovski:
https://youtu.be/jUiUUCt_TWg

## Joe Rogan Freaks Out About Australia's Cane Toad Problem
 - [https://www.youtube.com/watch?v=kWImFZqvxyQ](https://www.youtube.com/watch?v=kWImFZqvxyQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-11 00:00:00+00:00

Taken from MMA Show #93 w/Alexander Volkanovski:
https://youtu.be/jUiUUCt_TWg

## Joe Rogan Recaps Stylebender vs. Yoel Romero w/Alexander Volkanovski
 - [https://www.youtube.com/watch?v=qiW9mQ2YNyo](https://www.youtube.com/watch?v=qiW9mQ2YNyo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-11 00:00:00+00:00

Taken from MMA Show #93 w/Alexander Volkanovski:
https://youtu.be/jUiUUCt_TWg

## Can We Eliminate the Ticks That Carry Lyme Disease?
 - [https://www.youtube.com/watch?v=9xXrN-w4-JM](https://www.youtube.com/watch?v=9xXrN-w4-JM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-10 00:00:00+00:00

Taken from JRE #1439 w/Michael Osterholm: https://youtu.be/E3URhJx0NSw

## Hand Sanitizer & Face Masks, Will They Help Against the Coronavirus? w:Michael Osterholm | Joe
 - [https://www.youtube.com/watch?v=qbqQdwvjf7U](https://www.youtube.com/watch?v=qbqQdwvjf7U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-10 00:00:00+00:00

Taken from JRE #1439 w/Michael Osterholm:
https://youtu.be/E3URhJx0NSw

## How Serious is the Coronavirus? Infectious Disease Expert Michael Osterholm Explains | Joe Rogan
 - [https://www.youtube.com/watch?v=cZFhjMQrVts](https://www.youtube.com/watch?v=cZFhjMQrVts)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-10 00:00:00+00:00

Taken from JRE #1439 w/Michael Osterholm:
https://youtu.be/E3URhJx0NSw

## Is the Coronavirus a Bioweapon? w/Michael Osterholm | Joe Rogan
 - [https://www.youtube.com/watch?v=CfBhk-9OcrU](https://www.youtube.com/watch?v=CfBhk-9OcrU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-10 00:00:00+00:00

Taken from JRE #1439 w/Michael Osterholm:
https://youtu.be/E3URhJx0NSw

## Joe Rogan Speaks Out Against Anti-Vaxxers
 - [https://www.youtube.com/watch?v=ute7g2QxAO8](https://www.youtube.com/watch?v=ute7g2QxAO8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-10 00:00:00+00:00

Taken from JRE #1439 w/Michael Osterholm: https://youtu.be/E3URhJx0NSw

## Should You Take Probiotics After a Course of Antibiotics?
 - [https://www.youtube.com/watch?v=BxwFAL3jDmg](https://www.youtube.com/watch?v=BxwFAL3jDmg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-10 00:00:00+00:00

Taken from JRE #1439 w/Michael Osterholm: https://youtu.be/E3URhJx0NSw

## The Differences Between the Coronavirus and the Spanish Flu w:Michael Osterholm | Joe Rogan
 - [https://www.youtube.com/watch?v=B6IgMdsZHbM](https://www.youtube.com/watch?v=B6IgMdsZHbM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-10 00:00:00+00:00

Taken from JRE #1439 w/Michael Osterholm:
https://youtu.be/E3URhJx0NSw

## Why Wasn’t the US Better Prepared for Coronavirus?
 - [https://www.youtube.com/watch?v=Q4F2oSQ8CRI](https://www.youtube.com/watch?v=Q4F2oSQ8CRI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-10 00:00:00+00:00

Taken from JRE #1439 w/Michael Osterholm: https://youtu.be/E3URhJx0NSw

## Why We’re Years Out From a Coronavirus Vaccine
 - [https://www.youtube.com/watch?v=X8J0f18LLhE](https://www.youtube.com/watch?v=X8J0f18LLhE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-10 00:00:00+00:00

Taken from JRE #1439 w/Michael Osterholm: https://youtu.be/E3URhJx0NSw

## Why is China a Hotbed for Diseases Like Coronavirus?
 - [https://www.youtube.com/watch?v=_-DRhUDK738](https://www.youtube.com/watch?v=_-DRhUDK738)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-10 00:00:00+00:00

Taken from JRE #1439 w/Michael Osterholm: https://youtu.be/E3URhJx0NSw

