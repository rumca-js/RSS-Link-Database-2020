# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Co z wielbieniem w Bydgoszczy?:)
 - [https://www.youtube.com/watch?v=7QUaU_0h-bY](https://www.youtube.com/watch?v=7QUaU_0h-bY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-03-11 00:00:00+00:00

Z wszelkimi pytaniami odnośnie biletów prosimy się wstrzymać do czasu ogłoszenia nowego terminu wielbienia:)

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Jonasz z 2B [#03] Dzida
 - [https://www.youtube.com/watch?v=P5G4CeW23Hg](https://www.youtube.com/watch?v=P5G4CeW23Hg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-03-11 00:00:00+00:00

#Jonaszz2B #bondyra #wielkipost #challenge #szkoła #wuef #ewangelizacja #wspólnota @Langustanapalmie  @Dominikanieplportal  

Już dziś kolejny odcinek naszego langustowego serialu! Nasz bohater musi dziś stawić czoła swojemu Wuefiście i wytłumaczyć się z ostatniego wybryku... Ale czy “Dzida” jest zawsze “twardzielem”?... Zobaczcie jak Jonasz poradził sobie z kolejnym zadaniem!


Kolejne odcinki w środy.
________________________________________

Scenariusz: Angelika Olszewska
Reżyseria: Mateusz Olszewski
Zdjęcia: Marcin Lesisz
Montaż i czołówka: Agata Przygodzka
Mistrz Oświetlenia: Ireneusz Chojnacki
Kierownik produkcji: Angelika Olszewska
Kierownik planu: Magdalena Gonera
Korekta barwna: Przemysław Jurkiewicz
Fotosy: Halina Irena Jasińska
Grafiki: Jakub Dudek
Reżyseria dźwięku: Iga Kałduńska
Scenografia: Michał Pańczyk
Kostiumy: Justyna Jabłońska
Charakteryzacja: Beata Czerniszewska
Jonasz: Piotr Bondyra
Ewka: Angelika Olszewska
Ojciec: Piotr Cyrwus
Matka: Natasza Sierocka
I inni.

Serial jest wyprodukowany przez Stowarzyszenie Działań Twórczych Republika Warszawa dla Langusta na Palmie.

Śledź JONASZA na FB 
→ https://www.facebook.com/Jonasz-z-2b-101044304824327/ 
oraz na Instagramie: 
→ https://www.instagram.com/jonasz_z_2b/

Projekt można wesprzeć przez portal:
→  https://polakpotrafi.pl/projekt/postprodukcja-serialu-jonasz-z-2b
Dzięki.

Dziękujemy braciom Dominikanom z klasztoru na Warszawskim Służewie za udostępnienie miejsca do nagrania II http://www.sluzew.dominikanie.pl
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

## Wstawaki [#452] Zadowolenie
 - [https://www.youtube.com/watch?v=pJX3s19IMxw](https://www.youtube.com/watch?v=pJX3s19IMxw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-03-11 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

Poznaj szczegóły Wielkopostnej akcji Fundacji Malak: 
→ https://bit.ly/32Pt2s2
→ https://www.facebook.com/events/203007710768743/

Wesprzyj akcję:
Dane do przelewu tradycyjnego:
Numer konta:  42 2490 0005 0000 4600 1184 3564 
Tytuł przelewu: AFRYKA
Nasze dane: Fundacja Malak, ul. Plac Na Stawach 1/1, 30-107 Kraków

Dane do przelewu z zagranicy:
Kod SWIFT: ALBPPLPW
Numer IBAN: PL 42 2490 0005 0000 4600 1184 3564 

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Imiennik [#04] 7 demonów i uzdrowiciel
 - [https://www.youtube.com/watch?v=SXIItLbjoJU](https://www.youtube.com/watch?v=SXIItLbjoJU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-03-10 00:00:00+00:00

#Imiennik #coOznaczaTwojeImie #Magda #Damian

Co znaczy Twoje imię, zapraszamy na nową serię Languście.
Odkryj BŁOGOSŁAWIEŃSTWA i CHARYZMATY ukryte w Twoim imieniu. 

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#451] Towarzysz
 - [https://www.youtube.com/watch?v=Hux2iIy6rFo](https://www.youtube.com/watch?v=Hux2iIy6rFo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-03-10 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

Poznaj szczegóły Wielkopostnej akcji Fundacji Malak: 
→ https://bit.ly/32Pt2s2
→ https://www.facebook.com/events/203007710768743/

Wesprzyj akcję:
Dane do przelewu tradycyjnego:
Numer konta:  42 2490 0005 0000 4600 1184 3564 
Tytuł przelewu: AFRYKA
Nasze dane: Fundacja Malak, ul. Plac Na Stawach 1/1, 30-107 Kraków

Dane do przelewu z zagranicy:
Kod SWIFT: ALBPPLPW
Numer IBAN: PL 42 2490 0005 0000 4600 1184 3564 
Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

