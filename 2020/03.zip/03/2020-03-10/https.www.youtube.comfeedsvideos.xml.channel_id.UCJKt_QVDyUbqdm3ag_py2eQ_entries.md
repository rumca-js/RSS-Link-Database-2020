# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga Paula does XM: FBY - Last Ninja (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=SzKzLQbAExk](https://www.youtube.com/watch?v=SzKzLQbAExk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-03-11 00:00:00+00:00

"Last Ninja" by FBY (Fabio Barzagli). Untitled graphics by Fish/LSD (#3 at Digital Symposium 1993 graphics competition). This upload is intended for headphones.

DeliTracker 2.34 with 14Bit-NotePlayer 4.30. Normal mixing with actual mixing frequency of 44336 Hz. No panning, no 3D, no anti-click and DSP off. Auto boost enabled. 100% flawless playback not guaranteed. The track reports 20 channels, but that might not directly translate to 20 simultaneous sounds being played at once. Screenmode was Euro72 Productivity.

Made using real A1200 audio. A recapped Rev 1D.4 (AWK 364720-04) mobo with resistors R321 and R331 = 680 ohms. More info about these two resistors here (RetroGameModz):
https://www.youtube.com/watch?v=7sZ7vLcURK4&t=0s

Visit my channel for more Amiga music.

