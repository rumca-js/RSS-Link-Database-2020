# Source:Laowhy86, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw, language:en-US

## Coronavirus Now a Pandemic - My Predictions Were Correct
 - [https://www.youtube.com/watch?v=P12W0FPco90](https://www.youtube.com/watch?v=P12W0FPco90)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw
 - date published: 2020-03-11 00:00:00+00:00

Hey Laowinners!

Unfortunately, my predictions were correct about the Coronavirus - Covid-19 is now a global pandemic. Tune in and find out why.

◘ Support me on Patreon for early release, and much more! http://www.patreon.com/laowhy86

◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

◘ OR Become a Sponsor on YouTube:
https://www.youtube.com/channel/UChvithwOECK5g_19TjldMKw/sponsor

◘ My TV show: Conquering Northern China:
https://vimeo.com/ondemand/conqueringnorthernchina

◘ Conquering Southern China
https://vimeo.com/ondemand/conqueringsouthernchina

◘ Discount code for both shows: laowinning

◘ Join me every week for videos about China! Don't forget to subscribe!
http://www.youtube.com/laowhy86

Be a Laowinner!
Like comment subscribe!

◘ Facebook:
http://www.facebook.com/laowhy86

◘ Instagram: 
http://instagram.com/laowhy86

◘ Music used most of the time - New World Hip Hop
https://soundcloud.com/apollodrivenz
https://www.youtube.com/channel/UCgirAE5d8ufiotRXmBZZbBQ

