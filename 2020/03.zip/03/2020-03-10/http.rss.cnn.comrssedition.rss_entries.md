# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## 20 years of fashion memes
 - [https://www.cnn.com/style/article/fashion-memes/index.html](https://www.cnn.com/style/article/fashion-memes/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-03-10 14:03:11+00:00

The fashion industry -- with its close relationship to celebrity and pop culture -- finds itself at home in the world of online memes.

