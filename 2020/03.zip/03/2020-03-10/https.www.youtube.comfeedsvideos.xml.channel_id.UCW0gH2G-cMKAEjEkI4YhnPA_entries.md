# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Six Ideas for a Lord of the Rings Theme Park at Universal
 - [https://www.youtube.com/watch?v=5BvV08xLkdE](https://www.youtube.com/watch?v=5BvV08xLkdE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2020-03-10 00:00:00+00:00

A couple months ago the site Theme Park University reported Universal was quietly working on a Middle-earth theme park.  Today, I'm going to throw out some ideas for attractions that would be fun to see in a Lord of the Rings theme park!  Please let me know in the comments what ideas you have and what you think of mine!


Hit subscribe - and the bell - so you never miss a video from Nerd of the Rings!


--------------
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.

#tolkien #lordoftherings #themepark

