# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## The Truth About the Escobar Folding Phone!
 - [https://www.youtube.com/watch?v=O8FJSjy3bXA](https://www.youtube.com/watch?v=O8FJSjy3bXA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-03-10 00:00:00+00:00

The truth behind the $399 folding phone with the Escobar name... save your money.

The shirt! http://shop.MKBHD.com

The Escobar YouTube channel: https://www.youtube.com/channel/UC42zG9XD1TRNcz0TIvjpvDg

Samsung Galaxy Fold review: https://youtu.be/-5BsYYtyENw

MKBHD Merch: http://shop.MKBHD.com

Video Gear I use: http://kit.co/MKBHD/video-gear#recom...
Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro music: http://youtube.com/20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

