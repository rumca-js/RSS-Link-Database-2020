# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## How to protect your online privacy in 2020 | Tutorial
 - [https://www.youtube.com/watch?v=jxeeKKfjb5o](https://www.youtube.com/watch?v=jxeeKKfjb5o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2020-03-21 00:00:00+00:00

This the Hated One's latest privacy tutorial in 2020. Learn the mindset on how to protect your privacy online with an easy to follow guide.
Please support me through Patreon: https://www.patreon.com/thehatedone 
- or donate anonymously:

Monero: 84DYxU8rPzQ88SxQqBF6VBNfPU9c5sjDXfTC1wXkgzWJfVMQ9zjAULL6rd11ASRGpxD1w6jQrMtqAGkkqiid5ef7QDroTPp

Bitcoin: 1HkDxXAVDFhBHSyRjam5WW5uoY88sxn5qz

Sources
Google tracks you everywhere  https://www.forbes.com/sites/johnkoetsier/2020/03/11/google-is-tracking-you-on-86-of-the-top-50000-websites-on-the-planet/
Third party trackers in mobile apps https://arxiv.org/pdf/1804.03603.pdf 
Secret consumer score https://www.nytimes.com/2019/11/04/business/secret-consumer-score-access.html 

*Tools*

Search

DuckDuckGo https://www.duck.com
Qwant https://www.qwant.com
Searx  https://www.searx.me
Startpage  https://www.startpage.com

Browsing

Tor Browser  https://www.torproject.org
Firefox https://www.mozilla.org/en-US/firefox/new/
Brave  https://www.brave.com
Bromite  https://www.bromite.org

NoScript tutorial https://www.youtube.com/watch?v=AC4ALEKZRfg
Firefox privacy settings tutorial https://www.youtube.com/watch?v=tQhWdsFMc24

Chatting

Signal https://www.signal.org
Briar https://briarproject.org/

Email

ProtonMail https://www.protonmail.com
Tutanota https://www.tutanota.com
Mailfence https://www.mailfence.com

K-9 client https://k9mail.app/
Fair Email client https://email.faircode.eu/
Thunderbird client https://www.thunderbird.net/

Password managers

Bitwarden https://bitwarden.com/
KeepassXC https://keepassxc.org/

Application firewalls

Netguard (Android) https://www.netguard.me/
Lockdown (iOS) https://lockdownhq.com/

Others

Nextcloud https://www.nextcloud.com
Veracrypt https://www.veracrypt.fr
Cryptomator https://cryptomator.org/
OsmAnd https://osmand.net/
*F-Droid* https://www.fdroid.org
LineageOS https://lineageos.org/
GrapheneOS https://grapheneos.org/
Invidious https://www.invidio.us
NewPipe https://newpipe.schabi.org/


Credit: Music by CO.AG Music https://www.youtube.com/channel/UCcavSftXHgxLBWwLDm_bNvA

Follow me:
https://twitter.com/The_HatedOne_
https://www.bitchute.com/TheHatedOne/
https://www.reddit.com/r/thehatedone/
https://www.minds.com/The_HatedOne

The footage and images featured in the video were for critical analysis, commentary and parody, which are protected under the Fair Use laws of the United States Copyright act of 1976.

