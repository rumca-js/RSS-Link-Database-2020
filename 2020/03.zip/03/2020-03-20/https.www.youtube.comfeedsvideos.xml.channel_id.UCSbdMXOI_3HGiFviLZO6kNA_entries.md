# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## This is the most expensive Oculus Quest in the world
 - [https://www.youtube.com/watch?v=0B-uy3nwzpU](https://www.youtube.com/watch?v=0B-uy3nwzpU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-03-21 00:00:00+00:00

Welcome to: The Excess Quest
I took this standalone VR headset and threw on every single accessory I could find... just how expensive can I get this ridiculous beast?

Here are the links to everything I used, some are affiliate, some are not. Feel free to use them or not. 

Oculus Quest:
https://amzn.to/39fjvfP

Deluxe Audio Strap:
https://amzn.to/2QC5PVt

Deluxe Audio Strap Brackets:
https://etsy.me/2J4CAq7

Oculus Quest VR Cover Kit:
https://vrcover.com/product/oculus-quest-foam-and-interface-basic-set/?itm=322&campaign=Thrillseeker

Oculus Quest VR Cover Foam Pad:
https://vrcover.com/product/oculus-quest-foam-replacement-slim/?itm=322&campaign=Thrillseeker

Rebuff Reality VRPower:
https://rebuffreality.com/products/vr-power

Rebuff Reality VR Shell:
https://amzn.to/39aAYG7

Mamut Grips:
https://www.mamutvr.com/products/mamut-touch-grip

