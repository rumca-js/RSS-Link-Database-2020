# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Building the Ultimate CPU Cooler!
 - [https://www.youtube.com/watch?v=nwCtvpgwm5o](https://www.youtube.com/watch?v=nwCtvpgwm5o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-03-21 00:00:00+00:00

Check out the March Expo 2020 on Alibaba, and get the Ecovacs Deebot Ozmo at https://bit.ly/MarchExpo_Linus1

Our sub-zero chiller is pretty awesome for cooling CPUs... but pretty bad at being safe. Today that changes.

Learn more about welding (This Old Tony): https://youtu.be/Vfhz9anpaWE
Learn more about GFCI (ElectroBOOM): https://youtu.be/GlM6PE2kKVY

Buy Corsair RGB Fans 
On Amazon (PAID LINK): https://geni.us/LiapfP 
On Newegg: https://geni.us/SvSwP

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1167206-building-the-ultimate-cpu-cooler/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Get your ticket to LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

## More Xbox Series X Details - IT'S A PC! - WAN Show Mar 20, 2020
 - [https://www.youtube.com/watch?v=L15Ox1WN1yQ](https://www.youtube.com/watch?v=L15Ox1WN1yQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-03-20 00:00:00+00:00

Get $25 off Vessifootwear with offer code LINUSTECHTIPS at https://www.vessifootwear.com/linustechtips

Save 15% today with offer code LTT on Displate at https://lmg.gg/displatewan

Sign up for Private Internet Access VPN at https://lmg.gg/piawan

Buy LTX 2020 Presented by Intel Tickets: https://lmg.gg/ltx20tickets
Learn more about LTX 2020: https://www.ltxexpo.com/
LTX 2020 Activities: https://www.ltxexpo.com/attractions
LTX 2020 Special Guests: https://www.ltxexpo.com/guests

Buy an LTT shirt, hoodie, hat, and even our own water bottle at https://lmg.gg/wanlttstore

Check out Carpool Critics, our new movie podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Timestamps: (Courtesy of Lloyd Dunamis)

0:00:06 Linus's Best Day Ever
0:01:38 Ultimate Machine for Folding@Home & Quick&Easy F@H Startup Guide Video (Video Spoiler Alert)
0:06:15 WAN Show Topics review
0:06:52 INTRO
0:07:27 Where were we last week?
0:12:27 LMG: COVID-19 Concern and How We Stay Safe
0:17:51     Culture change: Work From Home (WFH)
0:21:09     "How do you stay fit?"
0:24:26     Linus's Medical Concern - Torn Meniscus
0:29:32 X-Box Series X Specs
0:31:34     4KU Blu-ray drive interest & General Blu-ray topics
0:39:48     Specs resume
0:42:20 LTX Store Stock Update (volume for backstage Nick)
0:45:22 Shameless Self-Promotion: Carpool Critics
    0:52:23 SPONSORS
    0:52:27 Vessi Footwear
    0:53:40 Displate
    0:55:13 PIA - Private Internet Access
    0:56:00     Submerged Vessi Footwear quick result
0:56:54 DirectX 12 ~Ultimate~
0:59:18     "Do away with bad console ports"
1:01:48 Gamestop, An Essential Service? Still Open Amidst Pandemic
1:03:50 SUPACHATS
1:04:09     Tech QoL Improvements for Family - Good WiFi
1:06:12     Bidets (aka. bum gun, butt hose, etc)
1:08:54     HowMuchToiletPaper.com
1:11:46     Half-Life Alyx interest
1:13:32     Linus looks physically tired - played 6hrs of Anna
1:14:25     Laundry experience
1:17:37     "Feathers or Nylon?" Racism in Badminton
1:23:23 OUTRO

Podcast Download: http://traffic.libsyn.com/linustechtips/More_Xbox_Series_X_Details_-_ITS_A_PC_-_WAN_Show_Mar_20_2020.mp3

