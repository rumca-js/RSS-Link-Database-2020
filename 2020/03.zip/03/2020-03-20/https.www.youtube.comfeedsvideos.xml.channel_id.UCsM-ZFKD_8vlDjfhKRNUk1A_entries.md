# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Rufus Wainwright - koncert (MUZO.FM)
 - [https://www.youtube.com/watch?v=GN0UPT3hDxY](https://www.youtube.com/watch?v=GN0UPT3hDxY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-03-20 00:00:00+00:00

Rufus Wainwright na żywo w MUZO.FM. Artysta wykonał live w naszym studiu utwory: Damsel In Distress, Going To A Town i Hallelujah. 


Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Rufus Wainwright: http://www.facebook.com/rufuswainwrightofficial
Instagram Rufus Wainwright: http://www.instagram.com/rufuswainwright
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm

