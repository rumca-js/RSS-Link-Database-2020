# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## The Coronavirus Vaccine Explained | COVID-19
 - [https://www.youtube.com/watch?v=SSuxVwMkcpA](https://www.youtube.com/watch?v=SSuxVwMkcpA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2020-03-21 00:00:00+00:00

The truth about the race to a coronavirus vaccine
Are Vaccines Causing Magnetism? https://youtu.be/bVi-GlOY9iM
JOIN OUR NEW EMAIL LIST: https://mailchi.mp/072240d817d6/asapscience
The Science of Self-Isolation: https://podcasts.apple.com/ca/podcast/sidenote/id1383086982?mt=2

Subscribe for more asapscience, and hit that bell :)
Created by: Mitchell Moffit and Gregory Brown

FOLLOW US!
Mitch
Instagram: https://instagram.com/mitchellmoffit
Twitter: https://twitter.com/mitchellmoffit 

Greg
Instagram: https://instagram.com/whalewatchmeplz 
Twitter: https://twitter.com/whalewatchmeplz 

AsapSCIENCE
Instagram: https://instagram.com/asapscience 
Facebook: https://facebook.com/asapscience 
Twitter: https://twitter.com/asapscience
Tumblr: https://asapscience.tumblr.com 

Send us stuff!
ASAPSCIENCE INC.
P.O. Box 93, Toronto P
Toronto, ON, M5S2S6

Resources:
https://www.ncbi.nlm.nih.gov/pubmed/32190290
https://www.ncbi.nlm.nih.gov/pubmed/32183941
https://www.ncbi.nlm.nih.gov/pubmed/32191728
https://www.nature.com/articles/s41422-020-0282-0
https://www.cdc.gov/vaccines/hcp/conversations/downloads/vacsafe-understand-color-office.pdf
https://sunnybrook.ca/research/media/item.asp?c=2&i=2069&f=covid-19-isolated-2020
https://time.com/5790545/first-covid-19-vaccine/
https://www.theguardian.com/world/2020/mar/20/when-will-a-coronavirus-vaccine-be-ready
BIOLOGY: The Core 3rd Edition

