# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## John Prine's wife, diagnosed with COVID-19, Bandcamp's Big Day (The Current Music News 3/20/20)
 - [https://www.youtube.com/watch?v=om-LLLaWCaY](https://www.youtube.com/watch?v=om-LLLaWCaY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-03-21 00:00:00+00:00

John Prine's wife Fiona has tested positive for COVID-19, and is urging fans to stay home to protect themselves. Meanwhile, artists are sharing new music on Bandcamp as the platform waives fees for a day; as more and more artists use livestreams to share songs and solidarity in the ongoing public health crisis.
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

