# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## Watching the World End from the Linux Command Line!
 - [https://www.youtube.com/watch?v=cQ03v4d3QEo](https://www.youtube.com/watch?v=cQ03v4d3QEo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-03-21 00:00:00+00:00

Sup guys, it's Luke. Just /comfy/ here in the unaboomer compound watching the world end via the internet. In this video, I'll make a little statusbar module for watching Corona-chan's advance across the world. That's right, epidemiology in the terminal!

In the time since I recorded this video, they've added ANSI color codes to the output of the curl command. Because of that, you now have to remove them to show up in some statusbards like dwmblocks, which can be done by piping it through this command: sed  's/\x1b\[[0-9;]*m//g' 

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE NOW: https://lukesmith.xyz/donate 💰😎👌💯

