# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## For Ants [Lockdown Live Looping Jam #2]
 - [https://www.youtube.com/watch?v=MMNY3XgTvyQ](https://www.youtube.com/watch?v=MMNY3XgTvyQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2020-03-20 00:00:00+00:00

Support my music on Patreon: https://www.patreon.com/yuriwong *Best heard on headphones or full-range speakers.
I'm getting a hang of this live jam thing. This time I tried something different. Details below.

Equipment used:
- Elektron Octatrack MkII
- Novation Circuit
- Korg Minilogue
- Korg Microkorg XL+
- Teenage Engineering OP-1
- iConnectAudio4+
- Fender Stratocaster w Vintage Noiseless pickups
- Fender Precision Bass
- myVolts mickXer

Music-nerd stuff:
This jam is DAWless. All the recording, playback and sequencing was done within the Octatrack.
The Octatrack is the master clock, which is sent via MIDI DIN to the iConnectAudio4+ (ica4+), which sends midi out via usb to the Circuit, OP-1, Microkorg. I somehow couldn't get the Minilogue clock to work properly with the usb clock - will figure it out later. Also, the Microkorg tends to drift, so after many bars, the clock sometimes goes out of sync with the Octatrack, which is a bummer. Need to figure out a more robust system, perhaps with MIDI DIN.
I didn't use the Octatrack Arranger mode this time - I just manually triggered the patterns when I felt like going to the next section. It's a bit more freeing than the previous track I did, but also requires more dancing about with the fingers, which takes me away from actually playing an instrument (esp guitar , which needs two hands) while transitioning. I did my best. Some minor stumbles but that's to be expected for a live jam. I hope you enjoyed this little explanation.

