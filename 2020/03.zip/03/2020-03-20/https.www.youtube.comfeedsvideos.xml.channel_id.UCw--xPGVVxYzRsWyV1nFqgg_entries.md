# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Why You Should Read Stephen King!
 - [https://www.youtube.com/watch?v=4cev1vlBexE](https://www.youtube.com/watch?v=4cev1vlBexE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-03-21 00:00:00+00:00

He's the modern master of horror. But is he worth you reading?... YES! Get check out IT, The Shinning, The Stand, Salem's Lot! ANY OF THEM! 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

How to start reading King: https://www.youtube.com/watch?v=rJWk_bq8Jn8&t=35s

## FANTASY WORLDS 🪐 - TIER LIST
 - [https://www.youtube.com/watch?v=sKv9v9pgSrU](https://www.youtube.com/watch?v=sKv9v9pgSrU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-03-20 00:00:00+00:00

We talk about and rank various fantasy worlds! From Middle Earth to Dresden :) 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

