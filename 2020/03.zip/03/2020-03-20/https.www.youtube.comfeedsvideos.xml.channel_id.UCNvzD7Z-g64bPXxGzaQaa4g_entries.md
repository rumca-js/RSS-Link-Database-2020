# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Animal Crossing: New Horizons - Before You Buy
 - [https://www.youtube.com/watch?v=V56uazDSYcA](https://www.youtube.com/watch?v=V56uazDSYcA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-03-21 00:00:00+00:00

Animal Crossing: New Horizons (Nintendo Switch) is here, and it's massive. With new features and surprises, how is it? Let's talk.
Subscribe for more: http://youtube.com/gameranxtv ▼▼


Buy Animal Crossing: https://amzn.to/2wqtRfa



Watch more 'Before You Buy': https://bit.ly/2kfdxI6

## Doom Eternal: 10 Things The Game DOESN'T TELL YOU
 - [https://www.youtube.com/watch?v=1eUfHQVC6rU](https://www.youtube.com/watch?v=1eUfHQVC6rU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-03-21 00:00:00+00:00

Doom Eternal (PC, PS4, Xbox One), is full of nuances and things to learn, despite it's brute-force appearance. Here are some things to get caught up on before playing.
Subscribe for more: http://youtube.com/gameranxtv

## GAME MAKERS EXPLAIN PS5'S SSD ADVANTAGE, SPIDER-MAN 2 LEAKED? & MORE
 - [https://www.youtube.com/watch?v=52EElKx_TAk](https://www.youtube.com/watch?v=52EElKx_TAk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-03-20 00:00:00+00:00

New spec details for PS5 and Xbox Series X, free games during the shut-in period, another Splinter Cell surprise, Control DLC, and more in a week full of gaming news!
Subscribe for more: http://youtube.com/gameranxtv 

*Jakes twitter: https://twitter.com/jakebaldino 
*Instagram: https://goo.gl/HH6mTW 

 discord.gg/gameranx 

 Weekly giveaway link: https://goo.gl/forms/a7zCtr1HuTkzWuOo2 



 ~~~~STORIES~~~~



Thumbnail: Insomniac concept art via:
https://www.artstation.com/artwork/8llgeq


PS5/Xbox specs revealed
Xbox: https://www.usgamer.net/articles/five-things-we-learned-from-the-xbox-series-x-specs-reveal
PS5: https://www.gamespot.com/articles/ps5-the-7-big-takeaways-from-sonys-specs-reveal/1100-6474936/

Our PS5 breakdown: https://youtu.be/0zN_oqhoCr0
Our Xbox Series X breakdown: https://youtu.be/o8oWzddltZ4
Austin Evans Xbox special look: https://youtu.be/7Fjn4GRw8qE

Devs explain PS5 SSD advantage:
https://pureplaystation.com/developers-explain-why-ps5-ssd-is-going-to-be-a-game-changer/2020/03/
On the xbox side:  https://i.redd.it/m01wrca6rpn41.png

Spiderman sequel rumor (take it with a grain of salt)
https://www.reddit.com/r/PS4/comments/flgkhv/rumor_insomniacs_spiderman_sequel_will_feature/


New Ghost Recon splinter cell content:
https://www.youtube.com/watch?v=zdMLMZ4O674

New Overwatch character:
https://youtu.be/ovvaNr4mUiE

Control DLC
https://www.youtube.com/watch?v=ZzlAX3Ljhu0

The Bioshock movie that never happened
https://birthmoviesdeath.com/2020/03/13/gore-verbinskis-bioshock-movie-would-have-ruled


GOG free games
https://www.pcworld.com/article/3533348/gog-is-offering-27-free-games-to-help-you-relax-at-home.html
Steam festival
https://www.theverge.com/2020/3/18/21184319/steam-game-festival-sale-gdc-2020-indie-developers


GDC returns:
https://www.polygon.com/2020/3/19/21187365/game-developers-conference-rescheduled-august-gdc-summer-dates-changes?utm_campaign=polygon&utm_content=chorus&utm_medium=social&utm_source=twitter

