# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Marvel's New Warriors Looks AMAZING!
 - [https://www.youtube.com/watch?v=3PzmQqq96bA](https://www.youtube.com/watch?v=3PzmQqq96bA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-03-20 00:00:00+00:00

Join me as I unpack the literary phenomenon that exemplifies why the comic book industry is doing as well as it's doing - Marvel's New Warriors.

