# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Andy Stumpf Gets Honest About Navy Seal Training | Joe Rogan
 - [https://www.youtube.com/watch?v=4S-6d99n2h4](https://www.youtube.com/watch?v=4S-6d99n2h4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-21 00:00:00+00:00

Taken from JRE #1445 w/Andy Stumpf:
https://youtu.be/OlFJm2wK7eo

## Andy Stumpf was Involved in the Rescue of Jessica Lynch | Joe Rogan
 - [https://www.youtube.com/watch?v=sNd9K5cBGtE](https://www.youtube.com/watch?v=sNd9K5cBGtE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-21 00:00:00+00:00

Taken from JRE #1445 w/Andy Stumpf:
https://youtu.be/OlFJm2wK7eo

## Controlling the Urge to Panic During Coronavirus Pandemic w/Andy Stumpf | Joe Rogan
 - [https://www.youtube.com/watch?v=7cF88GRf1ZU](https://www.youtube.com/watch?v=7cF88GRf1ZU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-21 00:00:00+00:00

Taken from JRE #1445 w/Andy Stumpf:
https://youtu.be/OlFJm2wK7eo

## Joe Rogan Reacts to LA Shutdown, Latest Coronavirus News
 - [https://www.youtube.com/watch?v=EeL2rc2uUOo](https://www.youtube.com/watch?v=EeL2rc2uUOo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-21 00:00:00+00:00

Taken from JRE #1445 w/Andy Stumpf:
https://youtu.be/OlFJm2wK7eo

## Joe Rogan on Civil Liberties in the Age of Coronavirus
 - [https://www.youtube.com/watch?v=8g7K4RZLWhk](https://www.youtube.com/watch?v=8g7K4RZLWhk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-21 00:00:00+00:00

Taken from JRE #1445 w/Andy Stumpf: https://youtu.be/OlFJm2wK7eo

## Joe Rogan on Why Jiu-jItsu Guys Should Know Judo
 - [https://www.youtube.com/watch?v=4b3d0rkl0yc](https://www.youtube.com/watch?v=4b3d0rkl0yc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-21 00:00:00+00:00

Taken from JRE #1445 w/Andy Stumpf: https://youtu.be/OlFJm2wK7eo

## Why Navy SEAL Andy Stumpf Got into Jiu-JItsu
 - [https://www.youtube.com/watch?v=iXgxvJKL1q8](https://www.youtube.com/watch?v=iXgxvJKL1q8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-21 00:00:00+00:00

Taken from JRE #1445 w/Andy Stumpf: https://youtu.be/OlFJm2wK7eo

## A Death Whistle Moment - JRE Toons
 - [https://www.youtube.com/watch?v=No4A0r2lgnA](https://www.youtube.com/watch?v=No4A0r2lgnA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-20 00:00:00+00:00

Another hilarious moment animated by PaulyToon from the Joe Rogan Experience - Fight Companion - January 9, 2020 - https://youtu.be/fM5IYSZeGCY

