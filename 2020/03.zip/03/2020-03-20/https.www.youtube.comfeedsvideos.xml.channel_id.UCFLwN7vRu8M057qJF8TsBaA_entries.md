# Source:UpIsNotJump, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFLwN7vRu8M057qJF8TsBaA, language:en-US

## Carpentry Is An Absolute Nightmare - This Is Why
 - [https://www.youtube.com/watch?v=DorUsZlYtfc](https://www.youtube.com/watch?v=DorUsZlYtfc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLwN7vRu8M057qJF8TsBaA
 - date published: 2020-03-20 00:00:00+00:00

Get the best deals while you’re stuck at home ▸ http://joinhoney.com/upisnotjump
Honey is FREE and finds coupons with the click of a button. Thanks Honey for sponsoring!

This week I take my changes at doing carpentry, and of course, it turns out to be an absolute nightmare. I’d just like to make it clear the video I am watching to make this bookcase is amazing, no shade to Eddie, I picked his video because I think it’s amazing.

All my music and sound is from here: https://www.epidemicsound.com/referral/8pficg
 
Patreon: https://www.patreon.com/UpIsNotJump

Has this ever happened to you, you want to build a bookshelf and gosh darn it you aren’t sure how? Well grab your tools and join me in a good carpentry session, just think how much you will learn!

Next video will be Half Life Alyx!

Video I parody: https://www.youtube.com/watch?v=AX_PIkKEjyc&t=48s
Merch: https://www.pixelempire.com/products/upisnotjump
Twittz: https://twitter.com/UpIsNotJump

Enjoy!

