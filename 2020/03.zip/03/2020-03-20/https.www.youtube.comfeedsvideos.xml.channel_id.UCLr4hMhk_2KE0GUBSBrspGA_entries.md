# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Elektryczna fiszka dla dużych: Evolve Stoke
 - [https://www.youtube.com/watch?v=Nbxm8vgRsp8](https://www.youtube.com/watch?v=Nbxm8vgRsp8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-03-20 00:00:00+00:00

Recenzja najmniejszej deski Evolve'a. Materiał z jazdy został nagrany GoPro Max i mam świadomość jak wygląda, ale musimy z tym żyć, bo #ZostańwDomu więc wyrwałem się tylko na chwilę.
Link do polskiego dystrybutora deski: https://bit.ly/2QAjAE7 (niestety nie wrzucił jeszcze Stoke'a na stronę, ale ma się pojawić lada chwila)
Oficjalna stronę Evolve Stoke: https://bit.ly/2UkWiDk
Moje:
Twitter: http://bit.ly/TTKlawitera, Insta: http://bit.ly/InstaKlawiatur i FB: http://bit.ly/FBKlawiatur

