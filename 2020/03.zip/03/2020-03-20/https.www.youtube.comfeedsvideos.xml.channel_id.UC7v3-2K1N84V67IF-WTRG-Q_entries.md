# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Mortal Kombat: Annihilation - Movie Review
 - [https://www.youtube.com/watch?v=LifnwV4b0sY](https://www.youtube.com/watch?v=LifnwV4b0sY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-03-20 00:00:00+00:00

Hailed as one of the worst video game movie adaptations of all time. It's high time I give my thoughts on MORTAL KOMBAT ANNIHILATION!

#MortalKombat #MortalKombatAnnihilation

