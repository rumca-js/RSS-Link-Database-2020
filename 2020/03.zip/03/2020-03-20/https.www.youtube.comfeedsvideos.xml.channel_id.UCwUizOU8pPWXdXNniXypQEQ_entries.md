# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Shifting from Panic to Purpose: Authentic JP
 - [https://www.youtube.com/watch?v=Q4bJz-MWKvg](https://www.youtube.com/watch?v=Q4bJz-MWKvg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-03-21 00:00:00+00:00

Click Here for the Course - https://bit.ly/JPSearsFeartoPeace

Purpose always trumps panic! If you are not dialed into your purpose, the path of least resistance will be panic. That doesn’t help and it feels like crap. Here’s a few thoughts on unapologetically rooting into your purpose right now! And if you want to dive deeper with me into a whole play book on how to thrive during this scary time, click here - https://bit.ly/JPSearsFeartoPeace

#AuthenticJP #SincereSaturday

Subscribe to my channel for MORE! New videos every week!: https://www.youtube.com/user/AwakenWithJP?sub_confirmation=1

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Click Here to join my PATREON - https://awakenwithjp.com/patron
---- Want to be the first to see my new videos with 24 hour early access? Just click this to receive the alerts! - https://m.me/awakenwithjp?ref=w6836464

Listen and Subscribe to my NEW Podcast here: 
https://podcasts.apple.com/ca/podcast/awaken-with-jp-sears-show/id1436938686
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

-Order my new book at: http://HowToBeUltraSpiritual.com/

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

## Live Stream Comedy Shows Announcement!
 - [https://www.youtube.com/watch?v=9-KWhGwci74](https://www.youtube.com/watch?v=9-KWhGwci74)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-03-20 00:00:00+00:00

Click Here to get on the List - https://store.awakenwithjp.com/comedy-night-updates-sign-up37284178

Every Friday night I’ll be doing a LIVE stream comedy show until the quarantine is over! It’ll be a night out while you’re stuck at home with laughs, levity, and you’re favorite red-headed conscious comedian, me! The show will have stand up comedy, sketch comedy, and topical comedy. It’ll be kinda like Saturday Night Live except way more woke! The show is called Friday Night Still Alive! 

It’s 45-60 minutes of laughing away your stress! Click the link in my bio if you are interested in joining me. I’m just working out the tech details now and we’ll be starting one week from today. Click the link and I’ll keep you in the loop so you can have a Friday night out from your own home with me!

