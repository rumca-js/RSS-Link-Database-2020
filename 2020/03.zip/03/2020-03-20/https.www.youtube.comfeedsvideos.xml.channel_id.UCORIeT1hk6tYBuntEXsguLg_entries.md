# Source:PostmodernJukebox, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg, language:en-US

## Shoop - Salt-N-Pepa (‘50s Little Richard Style Cover) ft. Tia Simone
 - [https://www.youtube.com/watch?v=gVKKtnKHPzw](https://www.youtube.com/watch?v=gVKKtnKHPzw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg
 - date published: 2020-03-20 00:00:00+00:00

GET TIX TO OUR GRAND REOPENING WORLD TOUR: http://www.pmjtour.com
Download & Stream "Shoop" Here:  https://pmjlive.com/the90s-volume1?IQid=yt
Shop PMJ Music/Merch:  https://smarturl.it/pmjshop?IQid=yt
Follow Us On Spotify: https://smarturl.it/pmjcomplete?IQid=yt

Follow The Musicians:
Tia Simone (Vocals):
Facebook: https://facebook.com/tiasimonedotcom
Instagram: http://instagram.com/tiasimonedotcom
Twitter: https://twitter.com/tiasimonedotcom

Mike Chisnall (Guitar):
Instagram: https://instagram.com/mikechisnallmusic/

Adam Kubota (Bass):
Instagram: https://instagram.com/adamkubota_bass

Randolph Miller-Taylor (Trombone):
Instagram: https://instagram.com/jazzbon27/?hl=en

Jacob Scesney (Sax)
https://instagram.com/antijacobclub?igshid=1sgyaaa160j3f

Griffin Goldsmith (Drums)

Shayla Navarro (Dancer)

Sunny Holiday  (Dancer)
Instagram: https://instagram.com/misssunnyholiday

Scott Bradlee (Piano):
YouTube: http://youtube.com/scottbradlee
Facebook: http://facebook.com/scottbradleemusic
Instagram: http://instagram.com/scottbradlee
Twitter: http://twitter.com/scottbradlee
Book: http://smarturl.it/outsidethejukebox

Arrangement by: Scott Bradlee
Engineered by: Thai Long Ly
Video by: Braverijah Sage
Choreography & Wardrobe: Sunny Holiday
____________________________________________

#SaltNPepa #Shoop #Cover

