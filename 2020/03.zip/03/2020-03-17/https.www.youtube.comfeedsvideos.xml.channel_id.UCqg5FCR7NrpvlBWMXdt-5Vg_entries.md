# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## DOOM Retrospective (Zero Punctuation)
 - [https://www.youtube.com/watch?v=-0ny2GhaSRg](https://www.youtube.com/watch?v=-0ny2GhaSRg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-03-18 00:00:00+00:00

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

This week on Zero Punctuation, Yahtzee prepares for DOOM Eternal by reviewing the original DOOM.

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►► https://sharkrobot.com/collections/zero-punctuation 

Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 

Like us on Facebook ►► http://www.facebook.com/EscapistMag

Follow us on Twitter ►► https://twitter.com/EscapistMag

#ZeroPunctuation

## State of Decay 2: Juggernaut Edition | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=9qIT9c9kmbc](https://www.youtube.com/watch?v=9qIT9c9kmbc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-03-18 00:00:00+00:00

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

KC Nwosu reviews State of Decay 2: Juggernaut Edition, developed by Undead Labs.

State of Decay 2 on Steam: https://store.steampowered.com/app/495420/State_of_Decay_2_Juggernaut_Edition/

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►► https://sharkrobot.com/collections/zero-punctuation 

Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 

Like us on Facebook ►► http://www.facebook.com/EscapistMag

Follow us on Twitter ►► https://twitter.com/EscapistMag

#StateofDecay2

## Bunker Bustin | Yahtzee's Dev Diary
 - [https://www.youtube.com/watch?v=AH2lQ5jsMUI](https://www.youtube.com/watch?v=AH2lQ5jsMUI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-03-17 00:00:00+00:00

DOWNLOAD THE MAGIC POO MACHINE: https://yzcroshaw.itch.io/the-magic-poo-machine

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Yahtzee begins work on the 12th and final Dev Diary game, Bunker Bustin.

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►► https://sharkrobot.com/collections/zero-punctuation 

Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 

Like us on Facebook ►► http://www.facebook.com/EscapistMag

Follow us on Twitter ►► https://twitter.com/EscapistMag

## Yahtzee's Dev Diary - Jack Builds a Magic Poo Machine
 - [https://www.youtube.com/watch?v=pL7wdTjF9Jk](https://www.youtube.com/watch?v=pL7wdTjF9Jk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-03-17 00:00:00+00:00

DOWNLOAD THE MAGIC POO MACHINE: https://yzcroshaw.itch.io/the-magic-poo-machine

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Yup, you read that title right. Jack's building a magic poo machine in today's let's play episode.

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►► https://sharkrobot.com/collections/zero-punctuation 

Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 

Like us on Facebook ►► http://www.facebook.com/EscapistMag

Follow us on Twitter ►► https://twitter.com/EscapistMag

