## Danheim - Skapanir (Full album 2020) Nordic Folk & Dark Viking Music
 - [https://www.youtube.com/watch?v=Va297erJjJ4](https://www.youtube.com/watch?v=Va297erJjJ4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLTQVYwu-M-MnfOJDKlFnOQ
 - date published: 2020-03-17 00:00:00+00:00

The Danheim album "Skapanir" touches on death, the creation of new things and beginnings in the dark period of the Viking age. 
Take a journey back to the pagan/heathen way of life, and experience the atmosphere,  ancestral gods, Norse mythology, and Scandinavian heritage portrayed in sound. 

Get the full album here:
https://linktr.ee/danheim

Song list:
00:00 # Intro
00:46 # Kala
04:29 # Blotjarl
09:11 # Danheim & Heldom - Aesir
13:24 # Forndagr
16:19 # Faldne
21:29 # Skapanir
24:57 # Vetrnátta Blot
27:55 # Ragnakamp
32:22 # Reida (Remastered)
35:53 # Danheim & Heldom - Blodfest (Remastered)
39:20 # Hefna (Remastered)


Danheim's Spotify Playlist:
https://open.spotify.com/playlist/5V8zOkOKntRtYNsc2paiyN?si=B7IQs0RPRgGrGQdJupjTLg

Follow me on Facebook:
https://www.facebook.com/DanheimMusic/

Follow me on Instagram:
https://www.instagram.com/danheim_music/

You can find some merchandise & clothing here:
https://danheimmusic.com/viking-shop-merch/

Music Licensing:
http://danheimmusic.com/license_music

