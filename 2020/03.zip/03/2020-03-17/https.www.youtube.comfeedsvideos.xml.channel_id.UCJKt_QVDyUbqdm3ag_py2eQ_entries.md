# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga Paula does XM: Roz - Angerkoski (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=I0FJj3iUTgY](https://www.youtube.com/watch?v=I0FJj3iUTgY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-03-17 00:00:00+00:00

"Angerkoski" (2020) by Roz/Fit, Byterapers (Jarkko Sakari Rotstén), 1st at Assembly Winter 2020 tracked music compo. Graphics "Goddamn Itch!" (2020) by Optic, 1st at Gerp 2020 Amiga graphics competition. This upload is intended for headphones only.

Roz at SoundCloud:
https://soundcloud.com/rotsten

Roz at BandCamp:
https://rotsten.bandcamp.com

DeliTracker 2.34 with 14Bit-NotePlayer 4.30. Normal mixing with actual mixing frequency of 44336 Hz. No panning, no 3D and DSP off. Auto boost and anti-click enabled. 100% flawless playback not guaranteed. The track reports 14 channels, but that might not directly translate to 14 simultaneous sounds being played at once. Screenmode was Euro72 Productivity.

Made using real A1200 audio. A recapped Rev 1D.4 (AWK 364720-04) mobo with resistors R321 and R331 = 680 ohms. More info about these two resistors here (RetroGameModz):
https://www.youtube.com/watch?v=7sZ7vLcURK4&t=0s

Visit my channel for more Amiga music.

## Amiga music: Matt Furniss - Manchester United Europe v2.1 (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=vZ6MIcEWS0I](https://www.youtube.com/watch?v=vZ6MIcEWS0I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-03-17 00:00:00+00:00

"Manchester United Europe" (1991) by Matt Furniss. Recorded from a running game (v2.1). At least two other variations exist of this tune, available here:
https://www.exotica.org.uk/wiki/Manchester_United_Europe
This upload is intended for headphones.

Made using real A1200 audio. A recapped Rev 1D.4 (AWK 364720-04) mobo with resistors R321 and R331 = 680 ohms. More info about these two resistors here (RetroGameModz):
https://www.youtube.com/watch?v=7sZ7vLcURK4&t=0s

Visit my channel for more Amiga music.

## Amiga music: Mygg & Virgill - Our Inner Conflict (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=4mqUMPa7Ta0](https://www.youtube.com/watch?v=4mqUMPa7Ta0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-03-17 00:00:00+00:00

"Our Inner Conflict" (2020) by Mygg & Virgill (Jonas Sarvik & Jochen Feldkötter), 3rd at Gerp 2020 4 channel music compo. Graphics "Elements Of Green" (2013) by Prowler, 1st at Datastorm 2013 graphics competition. This upload is intended for headphones only.

Made using real A1200 audio. A recapped Rev 1D.4 (AWK 364720-04) mobo with resistors R321 and R331 = 680 ohms. More info about these two resistors here (RetroGameModz):
https://www.youtube.com/watch?v=7sZ7vLcURK4&t=0s

Commodore 1084 monitor bezel image for WinUAE by Ralf Ostertag.

Visit my channel for more Amiga music.

## SID music: dLx - Food For Thought (U64E real 6581 dual mono bx_🎧)
 - [https://www.youtube.com/watch?v=nGNcpgHViIA](https://www.youtube.com/watch?v=nGNcpgHViIA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-03-17 00:00:00+00:00

"Food For Thought" (2019) by dLx/Insane (Joakim Falk). Graphics "Pretzcii Bar" (2020) by Mikael/Pretzel Logic. This upload works for both headphones and speakers.

Ultimate64 Elite real 6581 dual mono setup (identical audio data output for both chips, full channel separation):

Left channel: MOS 6581R3 0786/Philippines IH057833 HC-30
Right channel: MOS 6581 0784/Korea AH054105

Ultimate64 Elite:
https://ultimate64.com/Ultimate-64-Elite

