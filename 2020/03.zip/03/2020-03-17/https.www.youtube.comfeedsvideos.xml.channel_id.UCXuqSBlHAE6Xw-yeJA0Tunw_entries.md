# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Don't game with a generic mouse! - Mid-Range Gaming Round Up!
 - [https://www.youtube.com/watch?v=ar-HKYkWlvw](https://www.youtube.com/watch?v=ar-HKYkWlvw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-03-18 00:00:00+00:00

Get 50% off your first 3 months of FreshBooks when you sign up for a paid plan at https://www.freshbooks.com/techtips

Thanks to Thermal Grizzly for sponsoring today's episode! Buy Thermal Grizzly Conductonaut on Amazon (PAID LINK) at https://lmg.gg/conductonaut

This is our 2020 round up of gaming mice between $30-50. Which one should you buy? Is it one from the heavy hitters, Logitech’s G305 or G403? Or something from Razer like the Deathadder Elite or Basilisk? Is it Corsair’s M55 RGB Pro or HyperX’s entry the Pulsefire Surge

Buy Logitech G305
On Amazon (PAID LINK): https://shop-links.co/1721690289901073995
On Newegg (PAID LINK): https://geni.us/wjZhYiT

Buy Logitech G600
On Best Buy (PAID LINK): https://shop-links.co/1721690293288319127
On Amazon (PAID LINK): https://geni.us/XKNM
On Newegg (PAID LINK): https://geni.us/No2zbTT

Buy Razer Basilisk
On Amazon (PAID LINK): https://geni.us/VXgxkck
On Newegg (PAID LINK): https://geni.us/BcMLZ

Buy Razer Lancehead TE
On Amazon (PAID LINK): https://geni.us/5ylI
On Newegg (PAID LINK): https://geni.us/bASeM

Buy HyperX Pulsefire Surge
On Best Buy (PAID LINK): https://shop-links.co/1721690300703127105
On Amazon (PAID LINK): https://geni.us/HFHnd
On Newegg (PAID LINK): https://geni.us/n3Dk1Vt

Buy Razer Deathadder Elite
On Amazon (PAID LINK): https://geni.us/UOtjdL
On Newegg (PAID LINK): https://geni.us/EYpzS

Buy ReDragon M908 Impact RGB
LOL DON'T BUY IT

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1166076-dont-game-with-a-generic-mouse/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Get your ticket to LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

## The TINY 1TB SSD
 - [https://www.youtube.com/watch?v=IbYG7q9OO18](https://www.youtube.com/watch?v=IbYG7q9OO18)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-03-17 00:00:00+00:00

Visit https://www.squarespace.com/LTT and use offer code LTT for 10% off

Save 10% and Free Worldwide Shipping at Ridge Wallets by using offer code LINUS at https://www.ridge.com/LINUS

SSDs keep getting smaller and smaller...

Check out the Kioxia BG4 at https://lmg.gg/oOgLT

Buy Kioxia SSDs 
On Amazon (PAID LINK): https://geni.us/wNQy5cU
On Newegg (PAID LINK): https://geni.us/P06NA

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1165730-this-is-a-tiny-ssd/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Get your ticket to LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

