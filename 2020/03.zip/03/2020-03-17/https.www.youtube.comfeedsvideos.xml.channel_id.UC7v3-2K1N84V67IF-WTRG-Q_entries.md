# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Blasphemous - Game Review
 - [https://www.youtube.com/watch?v=uPoZoFrAlrc](https://www.youtube.com/watch?v=uPoZoFrAlrc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-03-18 00:00:00+00:00

A violent, punishing "Metroidvania" game involving a world of twisted religious lore. Here's my review of the game BLASPHEMOUS!

