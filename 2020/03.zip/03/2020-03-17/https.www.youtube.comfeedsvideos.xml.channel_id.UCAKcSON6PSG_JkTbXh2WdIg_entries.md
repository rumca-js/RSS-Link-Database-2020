# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Listen to Looch - "Miles Davis: Birth of the Cool"
 - [https://www.youtube.com/watch?v=bAnGAmfpPbE](https://www.youtube.com/watch?v=bAnGAmfpPbE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-03-18 00:00:00+00:00

Mary Lucia recommends a new documentary to you: "Miles Davis: Birth of the Cool," which was released by the PBS series, "American Masters." 
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

