# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## The Rollable Smartphone?
 - [https://www.youtube.com/watch?v=ASwVyfebu3E](https://www.youtube.com/watch?v=ASwVyfebu3E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-03-17 00:00:00+00:00

Are rollable displays a good idea?  What's coming with iPhone 12? Are you washing your hands?!
20syl: https://youtube.com/20syl
CDC: https://cdc.gov/coronavirus/2019-ncov/index.html

That shirt! https://shop.MKBHD.com

MKBHD Merch: http://shop.MKBHD.com

Video Gear I use: http://kit.co/MKBHD/video-gear#recom...
Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

