# Source:Kołem się toczy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw, language:pl-PL

## Na narty do CZARNOGÓRY! Zima piękna jak w Polsce! + pierwsza via ferrata w życiu 😬
 - [https://www.youtube.com/watch?v=OmF-g9JB3-A](https://www.youtube.com/watch?v=OmF-g9JB3-A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw
 - date published: 2020-03-18 00:00:00+00:00

Upamiętnijmy drona. Góra znajduje się tu 👉 https://goo.gl/maps/RsCsLM8CAHCqkS2w7
Zachęcam do subskrypcji 👉 http://bit.ly/2cmWbSO 

Chcesz wspomóc kanał? Kup moje książki lub kurs filmowo-montażowy 
Kurs ►► https://www.kursfilmowaniaimontazu.pl/
Zarabianie na podróżach ►► https://bit.ly/2BysGNg
Twoja Samodzielna Podróż ►► http://bitly.com/2bOhhZv


Wracamy do Czarnogóry po raz... już sam nie wiem który. Byliśmy w Czarnogórze latem, jesienią, wiosną, a teraz czas na zimę! Pytanie - czy spodziewaliście się kiedykolwiek, że w Czarnogórze można uprawiać sporty zimowe? Odwiedziliśmy Durmitor, gdzie pojeździliśmy na biegówkach, a także Kolasin 1450 i Kolasin 1600, gdzie do marca można bez problemu jeździć na nartach. To znaczy, zależy od szczęścia. Nam dopisało :D

muzyka : artlist i soundcloud.com/nevaxh
Zapraszam też na:
Facebook: http://bit.ly/2flU84f
Instagram: http://bit.ly/2eTrIMc
Blog: http://kolemsietoczy.pl/

Rozdziały:
0:00 Wstęp
1:33 Durmitor - najpiękniejszy region Czarnogóry
4:26 Co, gdzie i jak w Czarnogórze?
5:17 Narty w Czarnogórze - Kolasin 1600
9:32 Czy warto jechać do Czarnogóry na narty jako początkujący?
11:41 Via ferrata i wspinaczka górska w Czarnogórze zimą

