# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Westworld Season 3 Episode 1 - It's BAD
 - [https://www.youtube.com/watch?v=0PKCx4bMs6s](https://www.youtube.com/watch?v=0PKCx4bMs6s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-03-18 00:00:00+00:00

So now that Season 3 has started, I guess it's time to take a look at the first episode, "Parce Domine".

