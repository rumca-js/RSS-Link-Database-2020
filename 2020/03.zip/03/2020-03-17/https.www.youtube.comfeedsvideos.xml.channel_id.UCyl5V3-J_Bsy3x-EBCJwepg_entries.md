# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Quarantine: A Nerd's Utopia
 - [https://www.youtube.com/watch?v=yif-J3PPYys](https://www.youtube.com/watch?v=yif-J3PPYys)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-03-18 00:00:00+00:00

This is the Babylon Bee weekly news podcast for the week of 3/18/2020.

 In this episode of The Babylon Bee podcast, editor-in-chief Kyle Mann and creative director Ethan Nicolle discuss the week’s big stories like how our entire society has turned upside down and now the nerds rule, the rise of black markets in hand sanitizer, and how churches our delivering communion elements via drone. They then discuss how we shouldn’t be afraid of coronavirus and how the entire world is under God’s control.

 In the subscriber portion, Kyle and Ethan mull over rejected headlines from subscribers and some of the writers. It’s another exciting segment of ‘Almost A Headline!’.

  Pre-order the new Babylon Bee Best-Of Coffee Table Book coming in 2020!

 Show Outline

 Introduction - Kyle and Ethan talk about heroes as a recurring motif in rock songs, Ethan’s wife video chats Ethan from the furniture store, and the guys discuss how people seem to be doing home improvement projects during this coronavirus shutdown.

 Story 1 -  Nation's Nerds Wake Up In Utopia Where Everyone Stays Inside, Sports Are Canceled, Social Interaction Forbidden

    Italy Totally Fine Thanks To Universal Healthcare System

   (From Snopes) The article references a document drawn up by health officials in Turin, a city in Northern Italy hit hard by the virus, with guidelines for if and when “It becomes impossible to provide all patients with intensive care service.” In such a case, the document says, “It will be necessary to apply criteria for access to intensive treatment, which depends on the limited resources available.”

    ‘The criteria for access to intensive therapy in cases of emergency must include age of less than 80 or a score on the Charlson comorbidity Index [which indicates how many other medical conditions the patient has] of less than 5.'

     Story 2 -   Drug Cartels Switch To Producing Hand Sanitizer

  Ethan and Kyle act out an episode of 'Breaking Purell.'  Story 3 -  Churches Switch To Remote Drone Delivery For Communion

 Topic of the Week -  Latest Numbers On Coronavirus: 100% Of World Still Under God's Control

 Everything-- even church-- being shut down from Coronavirus. “Do not be afraid.”- Jesus

 Love Mail/Hate Mail/ Feedback - A dramatic slam poetry minute with Dave DeAndrea. You can not miss this beatnik slam poem sesh! 

 Paid-subscriber portion (Starts at 00:53:25)

 Kyle and Ethan laugh and mull over rejected headlines from subscribers and the writers.

  

 We love our subscribers! They make what we do at The Babylon Bee possible! Please consider becoming a subscriber!

 Become a paid subscriber at https://babylonbee.com/plans.

