# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## DOOM Eternal - Before You Buy
 - [https://www.youtube.com/watch?v=hf6hK_HJdnA](https://www.youtube.com/watch?v=hf6hK_HJdnA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-03-18 00:00:00+00:00

DOOM Eternal (PC, PS4, Xbox One) is finally here, and it's as awesome as you were hoping. Jake breaks it all down.
Subscribe for more: http://youtube.com/gameranxtv ▼▼


Buy DOOM Eternal: https://amzn.to/3921xx4



Watch more 'Before You Buy': https://bit.ly/2kfdxI6

## Call of Duty: Warzone - 10 Things Players HATE
 - [https://www.youtube.com/watch?v=mZEB7bgzOuY](https://www.youtube.com/watch?v=mZEB7bgzOuY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-03-17 00:00:00+00:00

Call of Duty Warzone (PC, PS4, Xbox One) is a fun game, but even the biggest fans have some minor complaints and grievances. Here are the biggest ones we've heard.
Subscribe for more: http://youtube.com/gameranxtv

