# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Animoji Lord of the Rings: The Fellowship of the Ring - Part One
 - [https://www.youtube.com/watch?v=dqmK0FeG4vk](https://www.youtube.com/watch?v=dqmK0FeG4vk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2020-03-17 00:00:00+00:00

Even the smallest person...can make use of social distancing time. Enjoy the first half of The Fellowship of the Ring in 4 min...with Animojis! 

If you enjoy this video, please SUBSCRIBE so you don't miss Part Two of The Lord of the Rings! 

Relive the magic of your first venture into Tolkien's cinematic world the way only Emojis can provide! 

--------------
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.
#lotr #animoji #lordoftherings

