# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Self Isolation & Mental Health | Russell Brand
 - [https://www.youtube.com/watch?v=4ntd_ojo7Eg](https://www.youtube.com/watch?v=4ntd_ojo7Eg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-03-18 00:00:00+00:00

What does self isolation mean? What effect is Coronavirus and Covid-19 going to have on our mental health, society and culture? How are YOU coping with the quarantine? Here's some advice and tips on what to do in self isolation.

Listen to my weekly Under The Skin podcast here: 
http://luminary.link/russell

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

