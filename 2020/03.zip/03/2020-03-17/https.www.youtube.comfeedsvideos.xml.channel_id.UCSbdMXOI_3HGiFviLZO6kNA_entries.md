# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## The Oculus Quest just got WAY BETTER with Open XR
 - [https://www.youtube.com/watch?v=Wq3eRhCKLdg](https://www.youtube.com/watch?v=Wq3eRhCKLdg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-03-17 00:00:00+00:00

Hello and Welcome to TUESDAY NEWSDAY! 
Your number one resource for the entire weeks worth of VR news.  

This week I will be covering:
Five Nights at freddys Help Wanted VR coming to Quest:
https://uploadvr.com/five-nights-at-freddys-quest-port/

Oculus Quest UI update:
https://www.pocket-lint.com/ar-vr/news/facebook/151454-oculus-quest-is-getting-a-major-ui-overhaul

Open XR prototype for Oculus Quest will actually change everything:
https://uploadvr.com/quest-openxr-prototype-support/

Meme break:
https://www.reddit.com/r/VR_memes/comments/fil42a/admit_it_its_true/

Facebook online conference:
https://www.roadtovr.com/facebook-game-developers-oculus-vr/

Apple has giant VR hardware patent:
https://www.techradar.com/news/apple-glasses-could-solve-one-of-vrs-biggest-issues-patent-suggests

Problems with VR arcades at the moment:
https://uploadvr.com/community-download-coronavirus-vr-arcades/

