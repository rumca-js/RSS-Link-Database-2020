# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Lewis Capaldi - koncert MUZO.FM
 - [https://www.youtube.com/watch?v=bA4v1BC0Cdk](https://www.youtube.com/watch?v=bA4v1BC0Cdk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-03-18 00:00:00+00:00

Lewis Capaldi - na żywo w MUZO.FM. Lewis Capaldi zagrał w naszaym studiu specjalny koncert. Artysta wykonał utwory: Someone You Loved, Grace i Bruises z debiutanckiej płyty - Lewis Capaldi Divinely Uninspired To A Hellish Extent. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Lewis Capaldi: http://www.facebook.com/lewiscapaldi
Instagram Lewis Capaldi: http://www.instagram.com/lewiscapaldi
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm

## Rufus Wainwright - Going To A Town - live MUZO.FM
 - [https://www.youtube.com/watch?v=o1u3-yXxnds](https://www.youtube.com/watch?v=o1u3-yXxnds)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-03-17 00:00:00+00:00

Rufus Wainwright - Going To A Town na żywo w MUZO.FM. Utwór Goint To A Town pochodzi z płyty Rufusa Wainwrighta Release The Stars. 


Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Rufus Wainwright: http://www.facebook.com/rufuswainwrightofficial
Instagram Rufus Wainwright: http://www.instagram.com/rufuswainwright
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm


Rufus Wainwright Going To A Town tekst

I'm going to a town that has already been burnt down
I'm going to a place that has already been disgraced
I'm gonna see some folks who have already been let down
I'm so tired of America
I'm gonna make it up for all of The Sunday Times
I'm gonna make it up for all of the nursery rhymes
They never really seem to want to tell the truth
I'm so tired of you, America
Making my own way home
Ain't gonna be alone
I've got a life to lead, America
I've got a life to lead
Tell me, do you really think you go to hell for having loved?
Tell me, enough of thinking everything that you've done is good
I really need to know, after soaking the body of Jesus Christ in blood
I'm so tired of America
I really need to know
I may just never see you again, or might as well
You took advantage of a world that loved you well
I'm going to a town that has already been burnt down
I'm so tired of you, America
Making my own way home
Ain't gonna be alone
I've got a life to lead, America
I've got a life to lead
I got a soul to feed
I got a dream to heed
And that's all I need
Making my own way home
Ain't gonna be alone
I'm going to a town
That has already been burnt down

