# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Auto Makers Tried Building Cars Out of Plexiglass and Stainless Steel
 - [https://www.youtube.com/watch?v=zORC2SAx1gc](https://www.youtube.com/watch?v=zORC2SAx1gc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-18 00:00:00+00:00

Taken from JRE #1443 w/Jonathan Ward: https://youtu.be/Xd1IF8_FKBo

## ICON’s Jonathan Ward on the Worst Car Ever Built
 - [https://www.youtube.com/watch?v=ZfrqlWn80kw](https://www.youtube.com/watch?v=ZfrqlWn80kw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-18 00:00:00+00:00

Taken from JRE #1443 w/Jonathan Ward: https://youtu.be/Xd1IF8_FKBo

## Jonathan Ward on California’s Horrible Business Environment
 - [https://www.youtube.com/watch?v=swzogcjasNY](https://www.youtube.com/watch?v=swzogcjasNY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-18 00:00:00+00:00

Taken from JRE #1443 w/Jonathan Ward: https://youtu.be/Xd1IF8_FKBo

## Jonathan Ward's Critique of Tesla | Joe Rogan
 - [https://www.youtube.com/watch?v=JfctbHsQYg8](https://www.youtube.com/watch?v=JfctbHsQYg8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-18 00:00:00+00:00

Taken from JRE #1443 w/Jonathan Ward:
https://youtu.be/Xd1IF8_FKBo

## The Mystery of Cars That Ran on Air, Water w/Jonathan Ward | Joe Rogan
 - [https://www.youtube.com/watch?v=9fkikPii7AU](https://www.youtube.com/watch?v=9fkikPii7AU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-18 00:00:00+00:00

Taken from JRE #1443 w/Jonathan Ward:
https://youtu.be/Xd1IF8_FKBo

## Why Jonathan Ward Started Building "Derelict" Cars | Joe Rogan
 - [https://www.youtube.com/watch?v=fCimXV4Iv1A](https://www.youtube.com/watch?v=fCimXV4Iv1A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-18 00:00:00+00:00

Taken from JRE #1443 w/Jonathan Ward:
https://youtu.be/Xd1IF8_FKBo

## 20,000 Native Children Died at America’s Indian Boarding Schools
 - [https://www.youtube.com/watch?v=ZReDKru1aOg](https://www.youtube.com/watch?v=ZReDKru1aOg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-17 00:00:00+00:00

Taken from JRE #1442 w/Shannon O'Loughlin:
https://youtu.be/UL3RvjhFu_s

## How Treaties Broken with Native Americans Resonate Even Today
 - [https://www.youtube.com/watch?v=C4thtYDf9S0](https://www.youtube.com/watch?v=C4thtYDf9S0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-17 00:00:00+00:00

Taken from JRE #1442 w/Shannon O'Loughlin:
https://youtu.be/UL3RvjhFu_s

## How the Chitimacha Tribe Saved Their Native Language
 - [https://www.youtube.com/watch?v=H3dp136PA04](https://www.youtube.com/watch?v=H3dp136PA04)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-17 00:00:00+00:00

Taken from JRE #1442 w/Shannon O'Laughlin: https://youtu.be/UL3RvjhFu_s

## Shannon O’Laughiln on the Path Forward for Native Americans
 - [https://www.youtube.com/watch?v=CLMu5YCR8_8](https://www.youtube.com/watch?v=CLMu5YCR8_8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-17 00:00:00+00:00

Taken from JRE #1442 w/Shannon O'Laughlin: https://youtu.be/UL3RvjhFu_s

## Shannon O’Laughlin Explains What Casinos Do for Tribes
 - [https://www.youtube.com/watch?v=EKoRAWTvn7Q](https://www.youtube.com/watch?v=EKoRAWTvn7Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-17 00:00:00+00:00

Taken from JRE #1442 w/Shannon O'Laughlin: https://youtu.be/UL3RvjhFu_s

## Shannon O’Laughlin and Joe Rogan on Native American Origin Stories
 - [https://www.youtube.com/watch?v=fyPMQ3Qwiqg](https://www.youtube.com/watch?v=fyPMQ3Qwiqg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-17 00:00:00+00:00

Taken from JRE #1442 w/Shannon O'Laughlin: https://youtu.be/UL3RvjhFu_s

## Shannon O’Laughlin on Spurring Economic Development in Indian Country
 - [https://www.youtube.com/watch?v=pPzaAks8-0E](https://www.youtube.com/watch?v=pPzaAks8-0E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-17 00:00:00+00:00

Taken from JRE #1442 w/Shannon O'Laughlin: https://youtu.be/UL3RvjhFu_s

## Shannon O’Laughlin on the Struggle to Reclaim Stolen Native Artifacts
 - [https://www.youtube.com/watch?v=RSKJmjkMhJM](https://www.youtube.com/watch?v=RSKJmjkMhJM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-17 00:00:00+00:00

Taken from JRE #1442 w/Shannon O'Loughlin:
https://youtu.be/UL3RvjhFu_s

## Shannon O’Laughlin: Let Native Americans Tell Their Own Stories!
 - [https://www.youtube.com/watch?v=D4QC-hZ5Xn8](https://www.youtube.com/watch?v=D4QC-hZ5Xn8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-17 00:00:00+00:00

Taken from JRE #1442 w/Shannon O'Laughlin: https://youtu.be/UL3RvjhFu_s

## The Origins of Indian Reservations w/Shannon O'Loughlin | Joe Rogan
 - [https://www.youtube.com/watch?v=OkoCZnDBNqQ](https://www.youtube.com/watch?v=OkoCZnDBNqQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-17 00:00:00+00:00

Taken from JRE #1442 w/Shannon O'Loughlin:
https://youtu.be/UL3RvjhFu_s

## The Problem with DNA Testing for Native American Heritage w/Shannon O'Loughlin | Joe Rogan
 - [https://www.youtube.com/watch?v=XyXF_LffAM0](https://www.youtube.com/watch?v=XyXF_LffAM0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-17 00:00:00+00:00

Taken from JRE #1442 w/Shannon O'Loughlin:
https://youtu.be/UL3RvjhFu_s

## They’re Blowing Up Native American Sacred Sites to Build the Wall
 - [https://www.youtube.com/watch?v=vLUgUimGJx4](https://www.youtube.com/watch?v=vLUgUimGJx4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-17 00:00:00+00:00

Taken from JRE #1442 w/Shannon O'Laughlin: https://youtu.be/UL3RvjhFu_s

## What Does the Next Century Hold for Native Americans?
 - [https://www.youtube.com/watch?v=FklWrF2pM1Y](https://www.youtube.com/watch?v=FklWrF2pM1Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-17 00:00:00+00:00

Taken from JRE #1442 w/Shannon O'Laughlin: https://youtu.be/UL3RvjhFu_s

## Why Are People Attacking the Indian Child Welfare Act?
 - [https://www.youtube.com/watch?v=18UewMPUIoc](https://www.youtube.com/watch?v=18UewMPUIoc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-17 00:00:00+00:00

Taken from JRE #1442 w/Shannon O'Laughlin: https://youtu.be/UL3RvjhFu_s

## Why Sports Teams with Native American Names are Controversial w/Shannon O'Loughlin | Joe Rogan
 - [https://www.youtube.com/watch?v=XOlI9OjQZHA](https://www.youtube.com/watch?v=XOlI9OjQZHA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-17 00:00:00+00:00

Taken from JRE #1442 w/Shannon O'Loughlin:
https://youtu.be/UL3RvjhFu_s

