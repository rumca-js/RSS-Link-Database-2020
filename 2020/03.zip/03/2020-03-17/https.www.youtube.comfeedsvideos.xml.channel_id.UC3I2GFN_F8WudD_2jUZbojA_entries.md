# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Vagabon - Cold Apartment (Live on KEXP)
 - [https://www.youtube.com/watch?v=YtFofuPAfyc](https://www.youtube.com/watch?v=YtFofuPAfyc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-03-18 00:00:00+00:00

http://KEXP.ORG presents Vagabon performing "Cold Apartment" live in the KEXP studio. Recorded December 12, 2019.

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Cameras: Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
https://vagabonvagabon.com

## Vagabon - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=W-yhbVRepM8](https://www.youtube.com/watch?v=W-yhbVRepM8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-03-18 00:00:00+00:00

http://KEXP.ORG presents Vagabon performing live in the KEXP studio. Recorded December 12, 2019.

Songs:
Secret Medicine
Water Me Down
In A Bind
Cold Apartment

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Cameras: Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
https://vagabonvagabon.com

## Vagabon - In A Bind (Live on KEXP)
 - [https://www.youtube.com/watch?v=YxszoVxaUwk](https://www.youtube.com/watch?v=YxszoVxaUwk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-03-18 00:00:00+00:00

http://KEXP.ORG presents Vagabon performing "In A Bind" live in the KEXP studio. Recorded December 12, 2019.

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Cameras: Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
https://vagabonvagabon.com

## Vagabon - Secret Medicine (Live on KEXP)
 - [https://www.youtube.com/watch?v=EcqEKG_9ybo](https://www.youtube.com/watch?v=EcqEKG_9ybo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-03-18 00:00:00+00:00

http://KEXP.ORG presents Vagabon performing "Secret Medicine" live in the KEXP studio. Recorded December 12, 2019.

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Cameras: Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
https://vagabonvagabon.com

## Vagabon - Water Me Down (Live on KEXP)
 - [https://www.youtube.com/watch?v=0uNXoHEUUrI](https://www.youtube.com/watch?v=0uNXoHEUUrI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-03-18 00:00:00+00:00

http://KEXP.ORG presents Vagabon performing "Water Me Down" live in the KEXP studio. Recorded December 12, 2019.

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Cameras: Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
https://vagabonvagabon.com

