# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## Roads should be abolished!
 - [https://www.youtube.com/watch?v=geBQNOid_7A](https://www.youtube.com/watch?v=geBQNOid_7A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-03-18 00:00:00+00:00

Roads are the indirect cause of most social misery in the world. Why? 👉 Let's find out!

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE NOW: https://lukesmith.xyz/donate 💰😎👌💯

## Let's Shell Script Together: Case statements, audio control and more
 - [https://www.youtube.com/watch?v=zrUW14L_uqE](https://www.youtube.com/watch?v=zrUW14L_uqE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-03-17 00:00:00+00:00

I want to write a shell script that can deal with either one of the two audio systems (ALSA and Pulseaudio) on Linux, so people who use my dotfiles don't need to revise all my dotfiles to edit some audio shortcuts in dwm or i3.

One additional optimization that I should've mentioned is that at the end, we can actually get rid of the case statement since our functions are coincidentally equal to the value of "$1". That would be okay in this case, but I didn't do it here because I'm thinking about adding more. Then again, we'll see how the script evolves.

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE NOW: https://lukesmith.xyz/donate 💰😎👌💯

