# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## I'm A Dude [Lockdown Live Looping Jam #1]
 - [https://www.youtube.com/watch?v=YHWJUh9jfnU](https://www.youtube.com/watch?v=YHWJUh9jfnU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2020-03-18 00:00:00+00:00

Support my music on Patreon: https://www.patreon.com/yuriwong *Best heard on headphones or full-range speakers.
My country (Malaysia) is now on partial lockdown due to the COVID-19 pandemic. I've a lot of time at home, so I decided to put together a jam session of 'I'm A Dude'.

Equipment used:
- Elektron Octatrack MkII
- Novation Circuit
- Korg Microkorg XL+
- Teenage Engineering OP-1
- Fender Stratocaster w Vintage Noiseless pickups
- Fender Precision Bass
- myVolts mickXer

Music-nerd stuff:
This jam is DAWless. All the recording, playback and sequencing was done within the Octatrack.
The Octatrack is master clock, sending MIDI clock out to the Microkorg. It's not clocked to the Circuit because I haven't yet got the Type B MIDI dongles it needs (I recently got it used and it didn't come with them). So I'm just setting the tempo manually and hitting Play at the right time. The OP-1 Microkorg, Bass & Guitar (thru a Zoom B1xon & G1xon on the floor) all go into the myVolts mickXer (it's a little unpowered stereo mixer) and connected with a 1/8" stereo to dual 1/4" mono cable (ghent audio makes awesome cables) into inputs A B of the Octatrack. The Circuit goes into inputs C D of the Octatrack. Output is just Main stereo outs into a Zoom H5 recorder - everything is mixed in the Octatrack. I would loved being able to have the multitracks, but there's no Overbridge on the Octatrack. Muchos sad. Metronome is being output on the headphones/cue of the Octatrack. I'm using the Arranger in the Octatrack and just jamming along; a lot of it is structured but the playing is mostly unplanned, hence some teeny weird bits.

