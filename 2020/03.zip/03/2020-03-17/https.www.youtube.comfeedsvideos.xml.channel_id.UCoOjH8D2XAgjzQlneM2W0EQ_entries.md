# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## How to Get Rich as a Corrupt Politician
 - [https://www.youtube.com/watch?v=_HSL6sAP9fg](https://www.youtube.com/watch?v=_HSL6sAP9fg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2020-03-18 00:00:00+00:00

💹 Claim your two FREE stocks valued up to $1400 when you open a Webull account and deposit ANY amount: http://bit.ly/webull-jt

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
📸 Follow me on IG:@jaketran // http://bit.ly/jt-ig
👨👦👦 Join the Tran Mafia Family here: https://bit.ly/patreon-jt
💬 Join the community Discord: http://discord.gg/BmK8EnQ

Stuff I use & recommend:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
🏠 The real estate investing course I love & recommend: https://jake.yt/RE
🌐 Most flexible, affordable website hosting: https://jake.yt/bhd
🖥️ Website platform I use & love: https://jake.yt/kd
💽 Editing software I've used for 7+ years: https://jake.yt/ccd
📒 Online bookkeeping software I use& love: https://jake.yt/benchd 
🧾 Best affordable bookkeeping software: https://jake.yt/fbd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd
📚 Get 3 free audiobooks for life: https://amzn.to/2v58PSu
🎥 My video gear, setup, tech, books: https://jake.yt/stored

✉️ Email me: jake@jaketran.io

Subscribe to the backup channel on LBRY, use reward code "jake-cast" for free coin: https://bit.ly/LBRY-jt
📰 Sources & visuals // http://bit.ly/39L6QlE

-----------------------
With the 2020 election coming up, it's a good time to learn how to make money as a politician
Back in the good ol days, if you were a politician, and you wanted to make extra money on the side thanks to the powerful position you’re in - it was pretty simple
You’d take bribes, and stuff the $90,000 into your freezer
You’d do some insider trading
You cut to the chase and make it easy for your customers, like Former Congressman Duke Cunningham did, with his innovative bribe menu
Want a $16m defense contract? That will be $140,000 and a luxury yacht

But today only around 17% of people actually trusting the government, directly taking bribes just don’t work anymore
Who cares about a few thousand dollars? You’re a selfless public servant. You deserve more.
We need a new way to take bribes, a new way to get insider deals, without alerting the public and directly breaking any laws

As a politician, you’re in the business of selling influence to those looking to buy political favors, exceptions, insider deals; and your customers whether that be a local company, or a foreign corporation or government, pays in the form of bribes
Once the public did catch on, they put together disclosure laws 
If the money you’re directly getting is legal, it’s probably best to avoid any suspicious transactions at all cost bc why draw attention to yourself
There’s a simple solution to this that does require more work, but it’s absolutely worth it bc we’re able to move hundreds of millions of dollars at a time, sometimes billions of dollars
We just need to borrow a simple concept from the business world called offshoring
As the economy becomes more global, companies use offshoring to maximize their profits
Some offshoring is legitimate, but some companies do it to obscure their transactions
So we offshore our corruption
Instead of us doing the questionable deal we move the deal and the people involved out of the country to places where there are far less disclosure laws or have our kids or close friends do the deal.


-----------------------

🌅 Join my Facebook Group for going remote // http://bit.ly/remote-job

-----------------------

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2020 Jake Tran. All rights reserved.

Sound:
Kupla - Nowhere Else https://chillhop.lnk.to/TaigaNativeID 
Blue Wednesday - Embers ft. Aso https://chillhop.ffm.to/greatescape.oyd 
Kupla - Barely Awake https://spoti.fi/2EespN4 
Kupla - Always Miss You
Kupla -  Kingdom In Blue https://open.spotify.com/album/4n4VJqnZTaPg41iDIakpmE?si=TSKD9o0TTHOFt7nKxLEq2Q 

Music by Chillhop: http://chillhop.com/listen
Listen on Spotify: http://bit.ly/ChillhopSpotify

DISCLAIMER: These videos are for entertainment purposes only. This is not meant to be financial advice. Please always do your due diligence and never stop learning. Best of luck!

AFFILIATE DISCLOSURE: Some of the links in this video description are affiliate links, meaning, at no additional cost to you, I may earn a commission if you click through and make a purchase and/or subscribe. I only promote products that I 100% believe in.

