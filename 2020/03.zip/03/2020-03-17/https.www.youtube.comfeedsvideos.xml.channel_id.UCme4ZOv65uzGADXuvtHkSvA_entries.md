# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Jonasz z 2B [#04] Babcia
 - [https://www.youtube.com/watch?v=Y1Kn1cg7m0g](https://www.youtube.com/watch?v=Y1Kn1cg7m0g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-03-18 00:00:00+00:00

​@Dominikanieplportal @Langustanapalmie 
#sushi #babcia #wielkipost #ewangelizacja #dominikanie #langustanapalmie #kamkaminska #bondyra

Już czwarty odcinek, w którym Jonasz zmaga się z “wielkopostnym challengem”! Dziś poznajemy Babcię Jonasza, która zabiera go na najlepszą “rybkę” w mieście. W jakiej “rybce” gustuje Babcia Jonasza i co ma “rybka” do ewangelizacji - o tym wszystkim w dzisiejszym odcinku!

Kolejne odcinki w środy.
________________________________________

Scenariusz: Angelika Olszewska
Reżyseria: Mateusz Olszewski
Zdjęcia: Marcin Lesisz
Montaż i czołówka: Agata Przygodzka
Mistrz Oświetlenia: Ireneusz Chojnacki
Kierownik produkcji: Angelika Olszewska
Kierownik planu: Magdalena Gonera
Korekta barwna: Przemysław Jurkiewicz
Fotosy: Halina Irena Jasińska
Grafiki: Jakub Dudek
Reżyseria dźwięku: Iga Kałduńska
Scenografia: Michał Pańczyk
Kostiumy: Justyna Jabłońska
Charakteryzacja: Beata Czerniszewska
Jonasz: Piotr Bondyra
Babcia: Tomira Kowalik
Magda: Julia Biesiada
Aśka: Kamila Kamińska
I inni.

Serial jest wyprodukowany przez Stowarzyszenie Działań Twórczych Republika Warszawa dla Langusta na Palmie.

Śledź JONASZA na FB 
→ https://www.facebook.com/Jonasz-z-2b-101044304824327/ 
oraz na Instagramie: 
→ https://www.instagram.com/jonasz_z_2b/
Projekt można wesprzeć przez portal:
→  https://polakpotrafi.pl/projekt/postprodukcja-serialu-jonasz-z-2b
Dzięki.

Dziękujemy braciom Dominikanom z klasztoru na Warszawskim Służewie za udostępnienie miejsca do nagrania II http://www.sluzew.dominikanie.pl
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

## Miłość w czasach zarazy [#03] Pragnienia Bożego serca
 - [https://www.youtube.com/watch?v=MzIgdwhOTxQ](https://www.youtube.com/watch?v=MzIgdwhOTxQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-03-18 00:00:00+00:00

@langustanapalmie @dominikanie.pl #miloscwczasachzarazy #zostanwdomu  ________________________________________
Trzeci odcinek rekolekcji na żywo w czasach zarazy. 

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#458] Poznać siebie
 - [https://www.youtube.com/watch?v=TEOGkElX8Cc](https://www.youtube.com/watch?v=TEOGkElX8Cc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-03-18 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

Poznaj szczegóły Wielkopostnej akcji Fundacji Malak: 
→ https://bit.ly/32Pt2s2
→ https://www.facebook.com/events/203007710768743/

Wesprzyj akcję:
Dane do przelewu tradycyjnego:
Numer konta:  42 2490 0005 0000 4600 1184 3564 
Tytuł przelewu: AFRYKA
Nasze dane: Fundacja Malak, ul. Plac Na Stawach 1/1, 30-107 Kraków

Dane do przelewu z zagranicy:
Kod SWIFT: ALBPPLPW
Numer IBAN: PL 42 2490 0005 0000 4600 1184 3564 
Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Miłość w czasach zarazy [#02] W piecu ognistym
 - [https://www.youtube.com/watch?v=eWmNtdjpxoc](https://www.youtube.com/watch?v=eWmNtdjpxoc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-03-17 00:00:00+00:00

@langustanapalmie @dominikanie.pl #miloscwczasachzarazy  #zostanwdomu
________________________________________
Drugi odcinek rekolekcji na żywo w czasach epidemii.

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#457] Narodziny
 - [https://www.youtube.com/watch?v=1HUgVYVRyxc](https://www.youtube.com/watch?v=1HUgVYVRyxc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-03-17 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

Poznaj szczegóły Wielkopostnej akcji Fundacji Malak: 
→ https://bit.ly/32Pt2s2
→ https://www.facebook.com/events/203007710768743/

Wesprzyj akcję:
Dane do przelewu tradycyjnego:
Numer konta:  42 2490 0005 0000 4600 1184 3564 
Tytuł przelewu: AFRYKA
Nasze dane: Fundacja Malak, ul. Plac Na Stawach 1/1, 30-107 Kraków

Dane do przelewu z zagranicy:
Kod SWIFT: ALBPPLPW
Numer IBAN: PL 42 2490 0005 0000 4600 1184 3564 
Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

