# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Channel Update Among Cancelled Movie Releases
 - [https://www.youtube.com/watch?v=SPZHYsXyKTk](https://www.youtube.com/watch?v=SPZHYsXyKTk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-03-16 00:00:00+00:00

Movie studios have delayed the release of upcoming movies in response to the current Coronavirus pandemic. Here's what that means for my channel, and the videos you can expect in the mean time.

