# Source:Vlog Casha, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg, language:pl-PL

## KORONAWIRUS W KOLUMBII
 - [https://www.youtube.com/watch?v=9jHDVEY8Rig](https://www.youtube.com/watch?v=9jHDVEY8Rig)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg
 - date published: 2020-03-16 00:00:00+00:00

🗺️ Świeża relacja z obecnej sytuacji w Kolumbii. 🇨🇴
❗ Twórz kanał razem ze mną, otrzymaj pocztówkę z podróży! 
https://patronite.pl/vlogcasha
✔️ SUBSKRYBUJ "Vlog Casha": https://bit.ly/1QnQgLR

💵 Zniżka 144 zł na nocleg z Airbnb: https://bit.ly/2U7dVqY

🌏 Vlogi z Azji Płd-Wsch: https://bit.ly/2wrM9t2
🇦🇺 Vlogi z Australii: https://bit.ly/2OJWYOy
🇺🇸 Vlogi z życia i podróży w USA: https://bit.ly/2ya73NV
🚙Vlogi z autostopu 2018: https://bit.ly/2NbHzos

▸ Instagram: https://www.instagram.com/vlogcasha
▸ Facebook: https://www.facebook.com/vlogcasha/
▸ "Grupa Casha" na FB: https://bit.ly/2N1a6wX


#PodróżeCasha #Kolumbia

