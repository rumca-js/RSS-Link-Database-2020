# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## This billion-euro nuclear reactor was never switched on
 - [https://www.youtube.com/watch?v=WUVZbBBHrI4](https://www.youtube.com/watch?v=WUVZbBBHrI4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2020-03-16 00:00:00+00:00

Zwentendorf Nuclear Power Plant, in Austria, was ready to go: it just needed starting up. But that never happened, and forty years later, it still sits mothballed. Here's why.
Thanks to all the EVN team: you can find information on tours (in German) here: http://www.zwentendorf.com/ - and about EVN here: https://www.evn.at/EVN-Group/Energie-Zukunft/EVN-Fuhrungsangebot/Zwentendorf.aspx

Camera by Matt Gray: https://youtube.com/mattgrayyes
Edited by Michelle Martin: https://twitter.com/mrsmmartin

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

