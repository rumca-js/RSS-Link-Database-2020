# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Wonder Woman 1984 - I've got a bad feeling about this
 - [https://www.youtube.com/watch?v=pHaHF6w1ZS4](https://www.youtube.com/watch?v=pHaHF6w1ZS4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-03-16 00:00:00+00:00

So I figured it was time to take a look at the trailer for Wonder Woman 1984. Will it live up to its predecessor, or will it prove to be an embarassing disappointment? Let's find out.

