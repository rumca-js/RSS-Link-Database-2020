# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## 5 Good Ideas That Went Horribly Wrong | Answers With Joe
 - [https://www.youtube.com/watch?v=9oDaRS_rUko](https://www.youtube.com/watch?v=9oDaRS_rUko)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2020-03-16 00:00:00+00:00

First 200 people to sign up at http://www.brilliant.org/answerswithjoe will get 20% off their subscription for life! Go get it!
You never know what life's gonna throw at you. Often our best efforts and most brilliant ideas turn into hellish nightmares. From the plant that ate the south to a pill that destroyed a generation, here are 5 times that's happened.

Want to support the channel? Here's how:
Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
Check out the store: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

Thalidomide:
https://americanpregnancy.org/pregnancy-health/morning-sickness-during-pregnancy/
http://broughttolife.sciencemuseum.org.uk/broughttolife/themes/controversies/thalidomide
https://www.dailymail.co.uk/health/article-6024765/Scientists-FINALLY-discover-thalidomide-caused-birth-defects.html

Kudzu:
https://science.howstuffworks.com/life/botany/kudzu.htm
https://www.smithsonianmag.com/science-nature/true-story-kudzu-vine-ate-south-180956325/
https://www.aces.edu/blog/topics/invasive-species/history-use-of-kudzu-in-southeastern-united-states/

MTBE:
https://archive.epa.gov/mtbe/web/html/faq.html
https://www.eesi.org/papers/view/fact-sheet-a-brief-history-of-octane
https://www.health.state.mn.us/communities/environment/risk/docs/guidance/gw/methbutylethinfo.pdf
https://www.eia.gov/todayinenergy/detail.php?id=36614

Cane Toads:
https://www.wptv.com/news/region-n-palm-beach-county/palm-beach-gardens/palm-beach-gardens-community-concerned-over-outbreak-of-toads
https://www.maitlandmercury.com.au/story/5968050/have-we-lost-the-battle-against-the-cane-toad/
https://www.smithsonianmag.com/smart-news/plague-invasive-cane-toads-overruns-florida-community-180971797/
https://www.nationalgeographic.com/animals/amphibians/c/cane-toad/

Asbestos:
https://www.epa.gov/asbestos/epa-actions-protect-public-exposure-asbestos
https://www.asbestos.com/asbestos/
https://www.mesotheliomadiagnosis.com/asbestos/
https://listverse.com/2014/07/06/10-popular-ideas-that-turned-out-to-be-really-dangerous/

