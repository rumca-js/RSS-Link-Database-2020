# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## The TINY 1TB SSD
 - [https://www.youtube.com/watch?v=IbYG7q9OO18](https://www.youtube.com/watch?v=IbYG7q9OO18)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-03-17 00:00:00+00:00

Visit https://www.squarespace.com/LTT and use offer code LTT for 10% off

Save 10% and Free Worldwide Shipping at Ridge Wallets by using offer code LINUS at https://www.ridge.com/LINUS

SSDs keep getting smaller and smaller...

Check out the Kioxia BG4 at https://lmg.gg/oOgLT

Buy Kioxia SSDs 
On Amazon (PAID LINK): https://geni.us/wNQy5cU
On Newegg (PAID LINK): https://geni.us/P06NA

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1165730-this-is-a-tiny-ssd/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Get your ticket to LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

## Blindfolded Gaming PC Build CHALLENGE!
 - [https://www.youtube.com/watch?v=zhaATaghK_4](https://www.youtube.com/watch?v=zhaATaghK_4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-03-16 00:00:00+00:00

Get 20% OFF + Free Shipping at Manscaped.com with code TECH -- https://mnscpd.com/2ML8ni3

Check out the Open Benchtable for your PC enthusiast needs at https://openbenchtable.com/ltt

Can you task someone with very limited PC building experience and guide them to build a test bench? We're going to give it a shot, and better yet, we're making it a race! How bad could it be? 

Buy DJI FPV Fly More Combo
On Amazon (PAID LINK): https://geni.us/YYeOe0
On Newegg (PAID LINK): https://geni.us/O9pj8
On Walmart (PAID LINK): https://geni.us/IDEU

Buy G.Skill Trident Z RAM:
On Amazon (PAID LINK): https://geni.us/vKOo
On Newegg (PAID LINK): https://geni.us/7jhUdq
On Walmart (PAID LINK): https://geni.us/6gPKIw

Buy Intel 8700K: https://geni.us/ti7dw
On Amazon (PAID LINK): https://geni.us/fyM06
On Newegg (PAID LINK): https://geni.us/7nOsF

Buy Corsair RM1000x: 
On Amazon (PAID LINK): https://geni.us/fyM06
On Newegg (PAID LINK): https://geni.us/VqvP75

Buy ASUS WS Z390 Pro: 
On Amazon (PAID LINK): https://geni.us/AYnCkJ
On Newegg (PAID LINK): https://geni.us/PBy6

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1165406-blind-pc-building-challenge/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Get your ticket to LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

