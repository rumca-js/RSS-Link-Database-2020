# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## My BIGGEST Flaw!
 - [https://www.youtube.com/watch?v=A5E1gld6qUE](https://www.youtube.com/watch?v=A5E1gld6qUE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-03-17 00:00:00+00:00

I see this criticism of the channel in a lot of places, and I can honestly say, YES! I AGREE! 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## THREE BODY PROBLEM - REVIEW / Scifi Talk
 - [https://www.youtube.com/watch?v=a9rbj0NW0oc](https://www.youtube.com/watch?v=a9rbj0NW0oc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-03-17 00:00:00+00:00

My thoughts on / review of The Three-Body Problem by Cixin Liu. 
GET THE BOOK HERE: https://amzn.to/33pKhjX

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## AVATAR VS. THE DRAGON PRINCE - Ft. Hello Future Me
 - [https://www.youtube.com/watch?v=5ysTQteQL30](https://www.youtube.com/watch?v=5ysTQteQL30)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-03-16 00:00:00+00:00

Does The Dragon Prince have the potential to overthrow Avatar The Last Airbender? Or no, it is doomed to be viewed as a poor copy. Hello Future Me and I give our thoughts on the topic. 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

