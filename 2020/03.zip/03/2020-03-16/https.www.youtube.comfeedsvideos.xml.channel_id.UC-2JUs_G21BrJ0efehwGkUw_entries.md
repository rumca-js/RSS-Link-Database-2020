# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Love on Top | Beyoncé | funk cover ft. Louis Cato
 - [https://www.youtube.com/watch?v=ZmUENUZx2w0](https://www.youtube.com/watch?v=ZmUENUZx2w0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2020-03-16 00:00:00+00:00

Patreon: http://modal.scarypocketsfunk.com/patreon
Store: https://www.scarypocketsfunk.com
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A cover of "Love on Top" by Scary Pockets.

CREDITS
Lead vocal: Louis Cato
Keys: Jack Conte
Guitar: Ryan Lerman
Organ: Larry Goldings
Drums: Tamir Barzilay
Bass: Joe Ayoub

Recording Engineer: David Boucher
Mixing/Mastering: Caleb Parker
Video Production/Editing: Ricky Chavez

Recorded Live at Valentine Studios in Los Angeles, CA. 

#ScaryPockets #Funk #LoveOnTop #Beyonce

