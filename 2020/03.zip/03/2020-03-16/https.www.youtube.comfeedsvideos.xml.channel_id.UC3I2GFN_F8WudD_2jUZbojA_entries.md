# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Stag - Dreamer (Live on KEXP)
 - [https://www.youtube.com/watch?v=Q_l8xfkLipA](https://www.youtube.com/watch?v=Q_l8xfkLipA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-03-16 00:00:00+00:00

http://KEXP.ORG presents Stag performing "Dreamer" live in the KEXP studio. Recorded December 16, 2019.

Host: John Richards
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
http://www.themightystag.com

## Stag - Electric Mistress (Live on KEXP)
 - [https://www.youtube.com/watch?v=NTnOBRHQdy0](https://www.youtube.com/watch?v=NTnOBRHQdy0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-03-16 00:00:00+00:00

http://KEXP.ORG presents Stag performing "Electric Mistress" live in the KEXP studio. Recorded December 16, 2019.

Host: John Richards
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
http://www.themightystag.com

## Stag - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=1BS5F1_EVSs](https://www.youtube.com/watch?v=1BS5F1_EVSs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-03-16 00:00:00+00:00

http://KEXP.ORG presents Stag performing live in the KEXP studio. Recorded December 16, 2019.

Songs:
Pied Piper Blues
Dreamer
Electric Mistress
Some Kinda Something

Host: John Richards
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
http://www.themightystag.com

## Stag - Pied Piper Blues (Live on KEXP)
 - [https://www.youtube.com/watch?v=eqkqYtK8mbw](https://www.youtube.com/watch?v=eqkqYtK8mbw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-03-16 00:00:00+00:00

http://KEXP.ORG presents Stag performing "Pied Piper Blues" live in the KEXP studio. Recorded December 16, 2019.

Host: John Richards
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
http://www.themightystag.com

## Stag - Some Kinda Something (Live on KEXP)
 - [https://www.youtube.com/watch?v=3yykUF4HKzA](https://www.youtube.com/watch?v=3yykUF4HKzA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-03-16 00:00:00+00:00

http://KEXP.ORG presents Stag performing "Some Kinda Something" live in the KEXP studio. Recorded December 16, 2019.

Host: John Richards
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
http://www.themightystag.com

