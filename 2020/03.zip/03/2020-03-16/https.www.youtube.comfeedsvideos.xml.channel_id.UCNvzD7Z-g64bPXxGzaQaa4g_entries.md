# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Call of Duty: Warzone - 10 Things Players HATE
 - [https://www.youtube.com/watch?v=mZEB7bgzOuY](https://www.youtube.com/watch?v=mZEB7bgzOuY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-03-17 00:00:00+00:00

Call of Duty Warzone (PC, PS4, Xbox One) is a fun game, but even the biggest fans have some minor complaints and grievances. Here are the biggest ones we've heard.
Subscribe for more: http://youtube.com/gameranxtv

## XBOX Series X: CPU, GPU, SSD Storage & RAM Specs Revealed
 - [https://www.youtube.com/watch?v=o8oWzddltZ4](https://www.youtube.com/watch?v=o8oWzddltZ4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-03-16 00:00:00+00:00

Microsoft/Xbox just dropped tons of new information about the upcoming Xbox Series X. From specs, to memory cards, to smaller hardware details, we've got you covered here.
Subscribe for more: http://youtube.com/gameranxtv

