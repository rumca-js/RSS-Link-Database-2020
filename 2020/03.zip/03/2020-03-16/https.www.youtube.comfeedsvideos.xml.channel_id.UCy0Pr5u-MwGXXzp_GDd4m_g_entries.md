# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## How to Look Cute in Quarantine
 - [https://www.youtube.com/watch?v=dxtbSmig_Os](https://www.youtube.com/watch?v=dxtbSmig_Os)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2020-03-16 00:00:00+00:00

In times like these it's important to laugh when you can.

