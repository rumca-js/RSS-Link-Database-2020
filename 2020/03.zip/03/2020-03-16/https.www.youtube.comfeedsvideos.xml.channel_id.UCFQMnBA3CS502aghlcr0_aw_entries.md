# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Viral COVID-19 Memes
 - [https://www.youtube.com/watch?v=EQk4zGoJFYI](https://www.youtube.com/watch?v=EQk4zGoJFYI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-03-16 00:00:00+00:00

laughing while we still can

actual health advice if you need it: 
CDC resources - https://www.cdc.gov/coronavirus/2019-ncov/index.html
Dr. Mike's video on COVID-19 - https://www.youtube.com/watch?v=LI90iqFqLXs
Wikipedia article on Coronavirus- https://en.wikipedia.org/wiki/2019%E2%80%9320_coronavirus_pandemic

