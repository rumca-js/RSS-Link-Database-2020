# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## FAQ koronawirus - 10 pytań o pandemię i SARS-CoV-2
 - [https://www.youtube.com/watch?v=xZPLUmvKUOM](https://www.youtube.com/watch?v=xZPLUmvKUOM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2020-03-16 00:00:00+00:00

📚 MOJA KSIĄŻKA! Wejdź na https://geny.altenberg.pl i zamów swój „Przepis na człowieka”! Do 7.04.2020 darmowa wysyłka na terenie Polski
#przepisnaczłowieka pomoże Ci zrozumieć, co tak naprawdę odkrywają naukowcy na całym świecie i jak te odkrycia przekładają się na Twoje życie. Po lekturze będziesz świadomy, że nasze geny nie wydały na nas wyroku i że to, czym jest człowiek, to efekt oddziaływania genów ze środowiskiem

===
Infolinia NFZ:
800 190 590

Szpitale zakaźne:
https://www.gov.pl/web/koronawirus/lista-szpitali

Porady rządowe:
https://www.gov.pl/web/koronawirus/porady
===
Patronite ► https://patronite.pl/NaukowyBelkot 
Mix audio ► http://ratstudios.pl/

===
Dla tych, którzy powinni być w szkole:
https://www.gov.pl/web/zdalnelekcje

i dla tych, którzy do nauczania zdalnego chcą coś dołożyć od siebie:
https://zdalnelekcje.webankieta.pl/

===
Film Tomka Rożka:
https://www.youtube.com/watch?v=Alt4F2w3SMM

i jeszcze gorący, świetny materiał Kasi Gandor:
https://www.youtube.com/watch?v=EeV_aDdRpTQ

===
Pierwszy film:
https://www.youtube.com/watch?v=zFvsYoKL5C8

===
Subskrypcja ► https://youtube.com/c/UwagaNaukowyBelkot
Facebook ► https://facebook.com/UwagaNaukowyBelkot
Twitter ► https://twitter.com/NaukowyBelkot
Instagram ► https://www.instagram.com/NaukowyBelkot/

Wyłącznie Naukowy Bełkot ► https://goo.gl/Do7VCc
Grupa na facebooku ► https://goo.gl/HP8J83

===
Źródła (wybrane):

COVID-19, a pandemic or not? - The Lancet Infectious Diseases
I. Ghinai i in. - First known person-to-person transmission of severe acute respiratory syndrome coronavirus 2 (SARS-CoV-2) in the USA
A. Remuzzi i in. - COVID-19 and Italy: what next?
M. S. Green - Did the hesitancy in declaring COVID-19 a pandemic reflect a need to redefine the term?
A. Casadevall i in. - The convalescent sera option for containing COVID-19
X. Tang i in. - On the origin and continuing evolution of SARS-CoV-2

https://coronavirus.jhu.edu/map.html
https://zdrowie.dziennik.pl/artykuly/6462501,koronawirus-szczepionka-kluczowy-enzym-polski-profesor.html
https://wiadomosci.onet.pl/swiat/koronawirus-szczepionka-przeciwko-koronawirusowi-nie-pojawi-sie-szybko/6bms022
https://news.sky.com/story/coronavirus-hundreds-of-scientists-accuse-government-of-risking-lives-over-covid-19-plan-11957715

