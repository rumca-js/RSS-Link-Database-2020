# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Alien Covenant - Why Does This Movie Exist?
 - [https://www.youtube.com/watch?v=YO0TUESAL5Y](https://www.youtube.com/watch?v=YO0TUESAL5Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-04-01 00:00:00+00:00

Well, since I've already covered Prometheus, I guess I might as well review its abominable sequel. Join me as I try to figure out why Alien Covenant exists.

