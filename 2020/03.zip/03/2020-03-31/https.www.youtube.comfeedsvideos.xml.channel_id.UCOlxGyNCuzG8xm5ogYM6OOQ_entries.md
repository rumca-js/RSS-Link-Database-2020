## Trampsta & Heavy Drop - Toxibombs (Video)
 - [https://www.youtube.com/watch?v=BSz1j_y35ro](https://www.youtube.com/watch?v=BSz1j_y35ro)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCOlxGyNCuzG8xm5ogYM6OOQ
 - date published: 2020-03-31 00:00:00+00:00

Listen to TOXIBOMBS on SPOTIFY: → https://spoti.fi/3bE1KbA
FREE DOWNLOAD .WAV: → https://bit.ly/2UQr0Eq
___________________________________________________

► Follow TRAMPSTA:

➥ Soundcloud: → https://bit.ly/39zcgQl
➥ Instagram: → https://bit.ly/2HkZLvr
➥ Fan Page: → https://bit.ly/39j6emg
➥ Youtube: → https://bit.ly/3bzVMt5
➥ Spotify: → https://spoti.fi/2SpK1hj
➥ Twitter: →  https://bit.ly/2WLs3Iq

► Trampsta Bookings:  +5521984929213
___________________________________________________

► FOLLOW HEAVY DROP:

➥ Spotify: → https://spoti.fi/3bwzqb6
➥ Instagram: → https://bit.ly/2UmEkRY
➥ Fan Page: → https://bit.ly/33UxEOk
➥ SoundCloud: → https://bit.ly/2UuYA44
__________________________________________________________________

Credits:

►Original Animation created by High5toons
➥ https://www.youtube.com/user/high5toons
Re edited and adapted by Trampsta

►Original songs by System Of A Down
Remixed by Trampsta and Heavy Drop

