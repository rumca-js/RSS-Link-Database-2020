# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 15 Video Game Disguises That Should NEVER Have Worked
 - [https://www.youtube.com/watch?v=RvqX9OQo8ZM](https://www.youtube.com/watch?v=RvqX9OQo8ZM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-04-01 00:00:00+00:00

Video game characters often attempt to hide from others with hilarious and stupid results. Here are some good examples of awful disguises in gaming.

Subscribe for more: http://youtube.com/gameranxtv

## Mount & Blade II: Bannerlord - Before You Buy
 - [https://www.youtube.com/watch?v=EjwJGkUyD4s](https://www.youtube.com/watch?v=EjwJGkUyD4s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-03-31 00:00:00+00:00

Mount & Blade II: Bannerlord (PC) is a medieval war/life sim. After a long development, it's finally released in early access. Is it worth the wait so far? Let's talk!
Subscribe for more: http://youtube.com/gameranxtv ▼▼



Watch more 'Before You Buy': https://bit.ly/2kfdxI6

