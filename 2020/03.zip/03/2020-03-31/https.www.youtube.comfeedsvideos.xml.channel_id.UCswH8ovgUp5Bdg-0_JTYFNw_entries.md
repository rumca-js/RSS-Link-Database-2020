# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Corona Survival Guide with Wim Hof & Russell Brand | Full Length Podcast
 - [https://www.youtube.com/watch?v=YfAgSusi6t0](https://www.youtube.com/watch?v=YfAgSusi6t0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-04-01 00:00:00+00:00

Under The Skin with Wim Hof aka The Iceman!
How relevant and valuable are Wim Hof's incredible breathing and meditative techniques during this pandemic and time of lockdowns and self isolation.
Have you tried his method?
Check it out here: https://www.wimhofmethod.com/

Listen to my Under The Skin podcast on Luminary here: 
http://luminary.link/russell

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

## Wim Hof's Corona Survival Guide! | Russell Brand
 - [https://www.youtube.com/watch?v=BaKirqZYfv4](https://www.youtube.com/watch?v=BaKirqZYfv4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-03-31 00:00:00+00:00

A clip from the upcoming Under The Skin podcast with the incredible and inspiring Iceman aka Wim Hof. His ability to control his body and how it reacts to the world seems limitless. In the past Wim has been deliberately injected with E-Coli to see if he could suppress the bacteria using breath alone...and he succeeded! Could Wim's techniques help us during the this pandemic? Podcast out tomorrow Wed 1st April brought to you by Luminary.
Make sure to check out Wim's app or try one of his online mini classes: https://www.wimhofmethod.com/

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

