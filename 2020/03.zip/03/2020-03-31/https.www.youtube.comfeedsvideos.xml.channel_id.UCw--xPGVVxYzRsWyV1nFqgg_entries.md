# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## CLASSIC VS MODERN FANTASY
 - [https://www.youtube.com/watch?v=lAHUXHxZMNA](https://www.youtube.com/watch?v=lAHUXHxZMNA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-04-01 00:00:00+00:00

What exactly are the lines between classic and modern fantasy? Let's talk about that.
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## DRAGON’S LAIR MOVIE 🐉 FURIOUSA PREQUEL 🤬 STORM OF SWORDS ILLUSTRATED EDITION ⚔️ - Fantasy News
 - [https://www.youtube.com/watch?v=LwufeeiOy-A](https://www.youtube.com/watch?v=LwufeeiOy-A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-03-31 00:00:00+00:00

All the fantasy news from A Song of Ice And Fire Illustrated Editions to Ryan stories. 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

NEWS:

R/Fantasy Relief effort: https://www.reddit.com/r/Fantasy/comments/frp5dw/its_time_62_authors_144_books_all_at_099099_with/

Nicholas Eames Interview: https://www.youtube.com/watch?v=ZCfJzg6yDGg&t=1s

Hugo Awards Moving Online: https://www.tor.com/2020/03/25/conzealand-and-the-hugo-awards-are-moving-online/

Solar Opposites Trailer: https://www.youtube.com/watch?v=tLjo8IQLa9o

Doom Eternal Sales: https://screenrant.com/doom-eternal-first-weekend-sales-2016-record/

Adult Animation Growing: https://www.cartoonbrew.com/business/adult-animation-is-now-the-fastest-growing-animation-category-report-188186.html

Book Sales Skyrocket: https://twitter.com/guardianbooks/status/1242852128395104258?s=12

US #ThePoppyWar cover: https://twitter.com/kuangrf/status/1243227332640415744?s=12

Mad Max Furiousa Prequel: https://www.cinemablend.com/news/2493465/looks-like-covid-19-cant-stop-wont-stop-mad-max-fury-road-spinoff-casting

Mandalorian Casting: https://deadline.com/2020/03/the-mandalorian-season-2-cast-michael-biehn-joins-bill-burr-returning-1202892470/

Baby Yoda Toy: https://io9.gizmodo.com/hot-toys-life-sized-baby-yoda-is-here-and-he-is-glorio-1842525596

Castlevania season 4: https://www.ign.com/articles/netflix-castlevania-season-4-confirmed-renewed

Dragon’s Lair Ryan Reynolds: https://deadline.com/2020/03/ryan-reynolds-dragons-lair-netflix-1202894660/

Project Hail Mary:https://variety.com/2020/film/news/ryan-gosling-astronaut-movie-hail-mary-1203547436/

Mario Games 2020: https://twitter.com/NinEverything/status/1244628043211005952

Storm of Swords Illustrated edition: https://winteriscoming.net/2020/03/24/george-r-r-martin-reveals-cover-artwork-storm-swords-illustrated-edition/

A song of ice and fire, storm of swords, storm of swords illustrated edition, furiousa prequel, mad max, dragon’s lair movie, Ryan Reynolds, the Mandalorian casting, Castlevania season 4, Castlevania Netflix, doom eternal, project hail may, Ryan gosling, the poppy war, baby Yoda, baby Yoda hot toys, solar opposites trailer, Daniel Greene, fantasy news,

