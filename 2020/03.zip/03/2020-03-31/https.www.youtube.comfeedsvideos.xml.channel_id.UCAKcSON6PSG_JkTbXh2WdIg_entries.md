# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Lissie - Live Virtual Session (The Current)
 - [https://www.youtube.com/watch?v=KhJkBnu469k](https://www.youtube.com/watch?v=KhJkBnu469k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-01 00:00:00+00:00

#Lissie, from Northern Virginia, joins The Current's Jill Riley via a #Zoom meeting for a virtual #live session.

07:58 - This Much I Know (unreleased song)
11:45 - When I'm Alone
15:48 - Dreams (Fleetwood Mac)
21:53 - Everywhere I Go

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Listen to Looch: the wisdom of Keith Richards
 - [https://www.youtube.com/watch?v=udCwCQqvz2o](https://www.youtube.com/watch?v=udCwCQqvz2o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-01 00:00:00+00:00

In these uncertain times, Mary Lucia shares a reading from the book of Life, by Keith Richards.
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Lizzo buys lunch for health care workers
 - [https://www.youtube.com/watch?v=3MU78eGKCuM](https://www.youtube.com/watch?v=3MU78eGKCuM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-01 00:00:00+00:00

April 1, 2020: Amidst the coronavirus crisis, musicians are helping workers who've been affected: Lizzo bought lunch for emergency room staff, and Taylor Swift is helping keep a Nashville record store afloat. While some artists are delaying their record releases, others are not - including Phish and, seemingly, Fiona Apple. Also today: DJ sets get old-school online, Flavor Flav is not fired after all, and Chance the Rapper hosts a new version of 'Punk'd.'
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## #LoveRecordStores campaign supports retailers during crisis
 - [https://www.youtube.com/watch?v=GlOem-b9G70](https://www.youtube.com/watch?v=GlOem-b9G70)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-03-31 00:00:00+00:00

March 31, 2020: The music industry is marshaling its resources to support retailers and artists during this unprecedented crisis. Adam Schlesinger (Fountains of Wayne) and John Prine are both in serious condition fighting COVID-19. Fans sheltering in place are using video to connect with music: a new mini-doc spotlights Bob Marley's female collaborators, and there's a doc spotlighting First Avenue in its 50th anniversary year. Plus, Jack Black is on TikTok now and it's awesome.
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Wolf Parade - #Microshow (6-song set for The Current)
 - [https://www.youtube.com/watch?v=EIosB85apB8](https://www.youtube.com/watch?v=EIosB85apB8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-03-31 00:00:00+00:00

Wolf Parade recorded what may have been the loudest #Microshow to date when they played a #live mini-set at the 300-seat capacity Icehouse venue in Minneapolis in mid-February.  

Setlist:
Julia Take Your Man Home
Against the Day
Fall Into the Future
Forest Green
Modern World
Dinner Bells

Microshows are produced in partnership with New Belgium Brewing

