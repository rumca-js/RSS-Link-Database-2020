# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## I'm selling a Fake Guru course. (here's why)
 - [https://www.youtube.com/watch?v=bASTsYxgJcM](https://www.youtube.com/watch?v=bASTsYxgJcM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-03-31 00:00:00+00:00

Want to make money online?🤑🤑🤑 Want to know if your favorite guru who acts like Kevin David, Dan Lok, Tai Lopez is legit or not? I created a fake guru spotter course just for you so you can save that money. 

JOIN HERE 👉👉👉 https://bit.ly/39up4qB

