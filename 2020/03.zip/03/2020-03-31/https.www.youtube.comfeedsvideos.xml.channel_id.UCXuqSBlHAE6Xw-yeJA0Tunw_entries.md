# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## The Truth about LinusTechTips - EXPOSED (April Fools 2020)
 - [https://www.youtube.com/watch?v=pYQtusd8deU](https://www.youtube.com/watch?v=pYQtusd8deU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-04-01 00:00:00+00:00

Get 50% off your first 3 months of FreshBooks when you sign up for a paid plan at https://www.freshbooks.com/techtips

Get iFixit's NEW Mahi Driver Kit today for only $34.99 USD at https://www.ifixit.com/linus

Linus is lying. And it's time you knew the truth.

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1171750-the-truth-about-linustechtips-exposed/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Get your ticket to LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

## Building the Xbox Series X Rip-off PC
 - [https://www.youtube.com/watch?v=Sv3Pqb2F_xc](https://www.youtube.com/watch?v=Sv3Pqb2F_xc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-03-31 00:00:00+00:00

Thanks to NZXT for sponsoring today's video! Check out their new H1 Case at https://nzxt.co/H1Linus or get a BLD H1 PC Build at https://nzxt.co/H1MiniPCLinus

Linus builds a gaming PC in a case that looks kind of similar to the forthcoming Xbox Series X, the NZXT H1. It’s got an Intel 9900K and an RTX2070 Super for good measure, though 😉

Buy ROG STRIX Z390-I Motherboard
On Amazon (PAID LINK): https://geni.us/msbe
On Newegg (PAID LINK): https://geni.us/HvSyfV

Buy i9 9900k Processor 
On Amazon (PAID LINK): https://geni.us/iqAcbJ
On Newegg (PAID LINK): https://geni.us/nlhAO

Buy Vengeance RGB Pro 
On Amazon (PAID LINK): https://geni.us/vuEKm
On Newegg (PAID LINK): https://geni.us/IUXR

Buy Sabrent Rocket NVMe PCIe M.2 SSD
On Walmart (PAID LINK): https://geni.us/A511iDm
On Newegg (PAID LINK): https://geni.us/Vo9d1j

Buy RTX 2070 Super
On Amazon (PAID LINK): https://geni.us/Qpmmn
On Newegg (PAID LINK): https://geni.us/hiR5Mia

Buy Gaming Monitor
On Amazon (Paid Link): https://geni.us/Ydz7
On Newegg (Paid Link): https://geni.us/Hj3YjIi

Buy Gaming Keyboard
On Amazon (Paid Link): https://geni.us/1Agyb
On Newegg (Paid Link): https://geni.us/5tv0xJ

Buy Gaming Mouse
On Amazon (Paid Link): https://geni.us/RAdqH0
On Newegg (Paid Link): https://geni.us/9FCkD1

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1171344-building-the-xbox-series-x-rip-off-pc/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Get your ticket to LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

