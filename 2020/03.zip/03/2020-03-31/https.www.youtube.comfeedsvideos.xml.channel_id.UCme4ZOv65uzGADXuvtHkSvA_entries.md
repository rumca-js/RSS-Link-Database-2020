# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Jonasz z 2B [#06] Jimmy
 - [https://www.youtube.com/watch?v=Ydi8_7NY9F0](https://www.youtube.com/watch?v=Ydi8_7NY9F0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-01 00:00:00+00:00

​@Dominikanieplportal @dominikanie.sluzew 
#friendshipforever #ewangelizacja #rekolekcje #szustak #langustanapalmie #dominikaniesłużew

Szósty odcinek, w którym występuje o.Adam Szustak oraz… niezliczona ilość Langustowiczów, którzy wzięli udział w naszym nagraniu 20.02! Dziś poznajemy również starego kumpla Jonasza - Jimmy’ego, z którym Jonasz spotyka się po latach...


Kolejny odcinek w niedzielę 05.04.2020.
________________________________________

Scenariusz: Angelika Olszewska
Reżyseria: Mateusz Olszewski
Zdjęcia: Marcin Lesisz
Montaż i czołówka: Agata Przygodzka
Mistrz Oświetlenia: Ireneusz Chojnacki
Kierownik produkcji: Angelika Olszewska
Kierownik planu: Magdalena Gonera
Korekta barwna: Przemysław Jurkiewicz
Fotosy: Halina Irena Jasińska
Grafiki: Jakub Dudek
Reżyseria dźwięku: Iga Kałduńska
Scenografia: Michał Pańczyk
Kostiumy: Justyna Jabłońska
Charakteryzacja: Beata Czerniszewska
Muzyka:  "Pójdę za Tobą" owca 
Jonasz: Piotr Bondyra
Rekolekcjonista: o. Adam Szustak
Jimmy: Paweł Dobek 
I Langustowicze ;)

Serial jest wyprodukowany przez Stowarzyszenie Działań Twórczych Republika Warszawa dla Langusta na Palmie.

Śledź JONASZA na FB 
→ https://www.facebook.com/Jonasz-z-2b-101044304824327/ 
oraz na Instagramie: 
→ https://www.instagram.com/jonasz_z_2b/

Dziękujemy braciom Dominikanom z klasztoru na Warszawskim Służewie za udostępnienie miejsca do nagrania II http://www.sluzew.dominikanie.pl
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

## Miłość w czasach zarazy [#15] Syn czy niewolnik?
 - [https://www.youtube.com/watch?v=5xfAANWtZI4](https://www.youtube.com/watch?v=5xfAANWtZI4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-01 00:00:00+00:00

@langustanapalmie @dominikanie.pl #miloscwczasachzarazy #zostanwdomu ________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#470] Ataki
 - [https://www.youtube.com/watch?v=iFe685ASE9k](https://www.youtube.com/watch?v=iFe685ASE9k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-01 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

Poznaj szczegóły Wielkopostnej akcji Fundacji Malak: 
→ https://bit.ly/32Pt2s2
→ https://www.facebook.com/events/203007710768743/

Wesprzyj akcję:
Dane do przelewu tradycyjnego:
Numer konta:  42 2490 0005 0000 4600 1184 3564 
Tytuł przelewu: AFRYKA
Nasze dane: Fundacja Malak, ul. Plac Na Stawach 1/1, 30-107 Kraków

Dane do przelewu z zagranicy:
Kod SWIFT: ALBPPLPW
Numer IBAN: PL 42 2490 0005 0000 4600 1184 3564 
Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Miłość w czasach zarazy [#14] Nie patrz pod nogi!
 - [https://www.youtube.com/watch?v=_o73-IbSqzU](https://www.youtube.com/watch?v=_o73-IbSqzU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-03-31 00:00:00+00:00

@langustanapalmie @dominikanie.pl #miloscwczasachzarazy #zostanwdomu ________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#469] Pokuta
 - [https://www.youtube.com/watch?v=g30r_Jil45Y](https://www.youtube.com/watch?v=g30r_Jil45Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-03-31 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

Poznaj szczegóły Wielkopostnej akcji Fundacji Malak: 
→ https://bit.ly/32Pt2s2
→ https://www.facebook.com/events/203007710768743/

Wesprzyj akcję:
Dane do przelewu tradycyjnego:
Numer konta:  42 2490 0005 0000 4600 1184 3564 
Tytuł przelewu: AFRYKA
Nasze dane: Fundacja Malak, ul. Plac Na Stawach 1/1, 30-107 Kraków

Dane do przelewu z zagranicy:
Kod SWIFT: ALBPPLPW
Numer IBAN: PL 42 2490 0005 0000 4600 1184 3564 
Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

