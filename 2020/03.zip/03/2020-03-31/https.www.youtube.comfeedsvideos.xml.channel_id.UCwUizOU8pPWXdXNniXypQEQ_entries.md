# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## How I’m Not Going Insane - a Fireside Livestream Chat With JP
 - [https://www.youtube.com/watch?v=l08Z6BXXU1Y](https://www.youtube.com/watch?v=l08Z6BXXU1Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-03-31 00:00:00+00:00

Join me today for a LIVE fireside chat, Q & A, and I'll also be sharing how I'm not going insane. Join me and comment in with your goofy or sincere questions!
Click Here to sign up for Friday Night, Still Alive - Comedy Livestream - http://awakenwithjp.com/live

Subscribe to my channel for MORE! New videos every week!: https://www.youtube.com/user/AwakenWithJP?sub_confirmation=1

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Click Here to join my PATREON - https://awakenwithjp.com/patron
---- Want to be the first to see my new videos with 24 hour early access? Just click this to receive the alerts! - https://m.me/awakenwithjp?ref=w6836464

Listen and Subscribe to my NEW Podcast here: 
https://podcasts.apple.com/ca/podcast/awaken-with-jp-sears-show/id1436938686
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

-Order my new book at: http://HowToBeUltraSpiritual.com/

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

## How to Destroy Your Relationship During the Quarantine
 - [https://www.youtube.com/watch?v=FQ2U870PVj8](https://www.youtube.com/watch?v=FQ2U870PVj8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-03-31 00:00:00+00:00

Click Here to sign up for Friday Night, Still Alive - Comedy Livestream - http://awakenwithjp.com/live

Here's how to destroy your relationship during the quarantine. It's a play by play to maximize the stress and tension that comes with having to spend 24 hours a day with your significant other during the quarantine. It's what's happening in every relationship, I just wanted to help you along with this helpful relationship advice during the coronavirus quarantine.

Subscribe to my channel for MORE! New videos every week!: https://www.youtube.com/user/AwakenWithJP?sub_confirmation=1

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Click Here to join my PATREON - https://awakenwithjp.com/patron
---- Want to be the first to see my new videos with 24 hour early access? Just click this to receive the alerts! - https://m.me/awakenwithjp?ref=w6836464

Listen and Subscribe to my NEW Podcast here: 
https://podcasts.apple.com/ca/podcast/awaken-with-jp-sears-show/id1436938686
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

-Order my new book at: http://HowToBeUltraSpiritual.com/

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

