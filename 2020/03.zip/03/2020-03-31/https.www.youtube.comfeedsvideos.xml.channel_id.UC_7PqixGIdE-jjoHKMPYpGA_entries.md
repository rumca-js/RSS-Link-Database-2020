# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Po co komu poczucie humoru?
 - [https://www.youtube.com/watch?v=wrbzl_QepEM](https://www.youtube.com/watch?v=wrbzl_QepEM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2020-04-01 00:00:00+00:00

📚 MOJA KSIĄŻKA! Wejdź na https://geny.altenberg.pl i zamów swój „Przepis na człowieka”!
Jeszcze tylko do 7.04.2020 DARMOWA WYSYŁKA na terenie Polski.
#przepisnaczłowieka pomoże Ci zrozumieć, co tak naprawdę odkrywają naukowcy na całym świecie i jak te odkrycia przekładają się na Twoje życie. Po lekturze będziesz świadomy, że nasze geny nie wydały na nas wyroku i że to, czym jest człowiek, to efekt oddziaływania genów ze środowiskiem.

Patronite ► https://patronite.pl/NaukowyBelkot 
Mix audio ► http://ratstudios.pl/

Zwykły film na niezwykłe czasy. Czyli w dzień robienia sobie żartów o tym, dlaczego nas śmieszą... częściowo... a częściowo też o innych rzeczach.

Subskrypcja ► https://youtube.com/c/UwagaNaukowyBelkot
Facebook ► https://facebook.com/UwagaNaukowyBelkot
Twitter ► https://twitter.com/NaukowyBelkot
Instagram ► https://www.instagram.com/NaukowyBelkot/

Wyłącznie Naukowy Bełkot ► https://goo.gl/Do7VCc
Grupa na facebooku ► https://goo.gl/HP8J83

===
Źródła (wybrane):

F. Caruna i in. - Smile and laughter elicited by electrical stimulation of the frontal operculum.
J. Meyers - Humor as a Double-Edged Sword: Four Functions of Humor in Communication 
P. Vernon i in. - Genetic and Environmental Contributions to Humor Styles: A Replication Study
https://www.businessinsider.com/snl-cast-describe-first-show-back-after-911-2013-9?IR=T
S. Weemes - Ha!: The Science of When We Laugh and Why

===
Zdjęcia:

By Jaffacity - Own work, CC BY-SA 4.0, https://commons.wikimedia.org/w/index.php?curid=88716718
By CT Cooper - Own work, Public Domain, https://commons.wikimedia.org/w/index.php?curid=15656851

#zostańwdomu #primaaprilis #przepisnaczłowieka

