# Source:Snazzy Labs, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w, language:en-US

## Pimp My $6,000 Mac Pro! 😎 I almost ruined it...
 - [https://www.youtube.com/watch?v=t4HPq-tEYWY](https://www.youtube.com/watch?v=t4HPq-tEYWY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w
 - date published: 2020-03-31 00:00:00+00:00

We modded Mac Pro. Wheels, RGB LEDs, a custom drive cage, oh, and we used a CIRCULAR SAW!
Get a 4 month FREE trial of Bitdefender - https://www.bitdefender.com/media/html/consumer/new/SL-get-4-months-total-security-2020?cid=inf%7Cc%7cSL%7C4myt

Download our wheels design for free! - https://www.thingiverse.com/thing:4251214
Download drive cage design for free! - https://www.thingiverse.com/thing:4067905
Subscribe to my podcast Flashback! - http://relay.fm/flashback
Follow me on Twitter - http://twitter.com/snazzyq
Follow me on Instagram - http://instagram.com/snazzyq

Apple's Mac Pro released to much fanfare. Finally, Apple users could return to a classic tower PC with PCIe expansion, easy CPU/GPU upgradability, and more. But at a starting price of $6,000, it definitely isn't perfect. In this video, we 3D print some DIY wheels that (a) don't cost $400, but, (b) have the ability to actually lock in place so your computer doesn't roll away. Rather than spend $400 on the Pegasus J2i, we built our own cage and soldered a custom cable since it can't be purchased separately. Then, we added RGB LED into our Mac making it the first PRO GAMER MAC ever and it increased our FPS by over 50%—now we get like 15FPS in most AAA titles. Lastly, we took a FREAKING CIRCULAR SAW to Mac Pro's chassis to fix our biggest annoyance and design frustration. This video is a fun one. Buckle up!

