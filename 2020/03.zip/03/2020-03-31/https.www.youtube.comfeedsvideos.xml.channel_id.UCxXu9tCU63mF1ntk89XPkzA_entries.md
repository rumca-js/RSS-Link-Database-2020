# Source:Worthkids, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCxXu9tCU63mF1ntk89XPkzA, language:en-US

## Xylophone
 - [https://www.youtube.com/watch?v=ou7GZDeOp3g](https://www.youtube.com/watch?v=ou7GZDeOp3g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCxXu9tCU63mF1ntk89XPkzA
 - date published: 2020-04-01 00:00:00+00:00

🦴🦴
Xylophone performed by Andrew Nittoli (abnmusic3 on Fiverr)

patreon: patreon.com/worthikids
twitter: twitter.com/worthikids

