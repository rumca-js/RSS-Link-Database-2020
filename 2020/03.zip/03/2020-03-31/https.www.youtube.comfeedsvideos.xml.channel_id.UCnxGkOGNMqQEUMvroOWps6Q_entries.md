# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Dr  Peter Hotez on Coronavirus: We’re Not Even At the Peak Yet
 - [https://www.youtube.com/watch?v=OoSYbWUaiMw](https://www.youtube.com/watch?v=OoSYbWUaiMw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-01 00:00:00+00:00

Taken from JRE #1451 w/Peter Hotez: https://youtu.be/Q9Q53KWZFMU

## Dr  Peter Hotez on How We Can Prevent Another Pandemic
 - [https://www.youtube.com/watch?v=B9JqgieRQ04](https://www.youtube.com/watch?v=B9JqgieRQ04)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-01 00:00:00+00:00

Taken from JRE #1451 w/Peter Hotez: https://youtu.be/Q9Q53KWZFMU

## Dr  Peter Hotez: Not Just the Old and Sick Are At Risk from Covid-19
 - [https://www.youtube.com/watch?v=WZr_9HjR4N4](https://www.youtube.com/watch?v=WZr_9HjR4N4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-01 00:00:00+00:00

Taken from JRE #1451 w/Peter Hotez: https://youtu.be/Q9Q53KWZFMU

## Dr. Peter Hotez: Will Coronavirus Be a Seasonal Virus?
 - [https://www.youtube.com/watch?v=MCucByGEg5Q](https://www.youtube.com/watch?v=MCucByGEg5Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-01 00:00:00+00:00

Taken from JRE #1451 w/Peter Hotez: https://youtu.be/Q9Q53KWZFMU

## Is Chloroquine an Effective Treatment for Coronavirus? w/Peter Hotez | Joe Rogan
 - [https://www.youtube.com/watch?v=uy3cDf_nrwI](https://www.youtube.com/watch?v=uy3cDf_nrwI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-01 00:00:00+00:00

Taken from JRE #1451 w/Peter Hotez:
https://youtu.be/Q9Q53KWZFMU

## Is Coronavirus Lung and Heart Damage Permanent?
 - [https://www.youtube.com/watch?v=GBzWJlkC9h0](https://www.youtube.com/watch?v=GBzWJlkC9h0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-01 00:00:00+00:00

Taken from JRE #1451 w/Peter Hotez: https://youtu.be/Q9Q53KWZFMU

## Many More People Will Die from Covid 19 Than the Flu
 - [https://www.youtube.com/watch?v=m1K7rPlY5_Q](https://www.youtube.com/watch?v=m1K7rPlY5_Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-01 00:00:00+00:00

Taken from JRE #1451 w/Peter Hotez: https://youtu.be/Q9Q53KWZFMU

## Partisanship Might Prevent Us From Preparing for the Next Pandemic
 - [https://www.youtube.com/watch?v=Pm94XII5rHc](https://www.youtube.com/watch?v=Pm94XII5rHc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-01 00:00:00+00:00

Taken from JRE #1451 w/Peter Hotez: https://youtu.be/Q9Q53KWZFMU

## Scientist Peter Hotez Explains Asymptomatic Cases, Effects on Coronavirus by Age | Joe Rogan
 - [https://www.youtube.com/watch?v=hYYMsCWo1Y0](https://www.youtube.com/watch?v=hYYMsCWo1Y0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-01 00:00:00+00:00

Taken from JRE #1451 w/Peter Hotez:
https://youtu.be/Q9Q53KWZFMU

## Scientist Peter Hotez On Germany's Low Coronavirus Death Rate, Smoking, Vaping | Joe Rogan
 - [https://www.youtube.com/watch?v=8oV2DWr28Og](https://www.youtube.com/watch?v=8oV2DWr28Og)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-01 00:00:00+00:00

Taken from JRE #1451 w/Peter Hotez:
https://youtu.be/Q9Q53KWZFMU

## Hatred of Trump is Getting in the Way of Some People's Accurate Reporting | Joe Rogan
 - [https://www.youtube.com/watch?v=KRh4MtyeCF0](https://www.youtube.com/watch?v=KRh4MtyeCF0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-31 00:00:00+00:00

Taken from JRE #1450 w/Brian Redban:
https://youtu.be/iS3te7kM6DY

## Joe Rogan Ponders Long Term Effects of Coronavirus Lockdown
 - [https://www.youtube.com/watch?v=9UqEQag-Dr8](https://www.youtube.com/watch?v=9UqEQag-Dr8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-31 00:00:00+00:00

Taken from JRE #1450 w/Brian Redban:
https://youtu.be/iS3te7kM6DY

## Joe Rogan Reviews Numbers of H1N1, Other Pandemics
 - [https://www.youtube.com/watch?v=FXKpBeeUNMk](https://www.youtube.com/watch?v=FXKpBeeUNMk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-31 00:00:00+00:00

Taken from JRE #1450 w/Brian Redban:
https://youtu.be/iS3te7kM6DY

## Joe Rogan and Brian Redban Have a Probing Conversation About Bidets
 - [https://www.youtube.com/watch?v=tgi6hvtgT2Y](https://www.youtube.com/watch?v=tgi6hvtgT2Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-31 00:00:00+00:00

Taken from JRE #1450 w/Brian Redban: https://youtu.be/iS3te7kM6DY

## Joe Rogan on Mainers Who Forcibly Quarantined Out of Towners
 - [https://www.youtube.com/watch?v=i9IRNQuxafk](https://www.youtube.com/watch?v=i9IRNQuxafk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-31 00:00:00+00:00

Taken from JRE #1450 w/Brian Redban: https://youtu.be/iS3te7kM6DY

