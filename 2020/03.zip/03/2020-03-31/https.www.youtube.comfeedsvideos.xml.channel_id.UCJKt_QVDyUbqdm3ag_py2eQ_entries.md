# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Atari (YM2149) music: !Cube - Bullet Sequence (bx_🎧)
 - [https://www.youtube.com/watch?v=sb0q3c_2SVQ](https://www.youtube.com/watch?v=sb0q3c_2SVQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-04-01 00:00:00+00:00

"Bullet Sequence" (2014) by !Cube. Winner of Sillyventure 2014.

Emulated with Micro ST beta 10:
http://bulba.untergrund.net/ayplayer_e.htm

SNDH Atari ST YM2149 collection:
http://sndh.atari.org/about.php

## SID music: Jason Page - Turrican - Rise Of The Machine (FPGASID 8580 custom stereo bx_🎧)
 - [https://www.youtube.com/watch?v=-nVSf2_a7jg](https://www.youtube.com/watch?v=-nVSf2_a7jg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-04-01 00:00:00+00:00

"Turrican - Rise Of The Machine" C64 version (2020) by Jason Page. Original Amiga TFMX by Chris Huelsbeck.

Rise Of The Machine at Huelsbeck's Bandcamp:
https://chrishuelsbeck.bandcamp.com/album/turrican-rise-of-the-machine

Made using FPGASID fw 0A running in C64 Reloaded MK2.

FPGASID:
http://www.fpgasid.de/

