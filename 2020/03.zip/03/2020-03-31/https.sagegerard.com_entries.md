## Are You a Slave to your Software Knowledge?
 - [https://sagegerard.com/stop-learning-so-much.html](https://sagegerard.com/stop-learning-so-much.html)
 - RSS feed: https://sagegerard.com
 - date published: 2020-03-31 09:10:22+00:00

Are You a Slave to your Software Knowledge?

