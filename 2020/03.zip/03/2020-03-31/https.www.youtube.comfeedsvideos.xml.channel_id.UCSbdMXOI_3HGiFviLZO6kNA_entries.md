# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## HOME MADE VR Headset made with a Raspberry Pi
 - [https://www.youtube.com/watch?v=fcDgA6b7dgk](https://www.youtube.com/watch?v=fcDgA6b7dgk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-03-31 00:00:00+00:00

Hello and welcome to TUESDAY NEWSDAY! Your number one resource for the entire weeks worth of VR news. 

Reddit post from Dan on how to build your headset:
https://www.reddit.com/r/cyberpunkdiy/comments/fmpszx/diy_vrar_headset_pi_goggles/

Things I cover today:

Half Life alyx gets updates:
https://www.roadtovr.com/half-life-alyx-continuous-turning-smooth-crash-fix/

Half Life alyx and other VR games in the top 10 PC games for all of 2020:
https://www.roadtovr.com/half-life-alyx-best-rated-pc-game-2020-steam-vr-game-all-time/

Dan Build his own VR headset with a Raspberry Pi:
https://www.reddit.com/r/cyberpunkdiy/comments/fmpszx/diy_vrar_headset_pi_goggles/

MEME BREAK:
https://www.reddit.com/r/VR_memes/comments/fowmvm/haptic_motors_go_brrrr/

Oculus Signs deal with AR display manufacturer:
https://www.roadtovr.com/facebook-exclusivity-deal-ar-display-plessey/

Apple AR glasses Rumors and Leaks:
https://vrscout.com/news/apple-hybrid-vr-ar-headset-bowling-game-leak/

Sansar is sold:
https://www.roadtovr.com/sansar-spin-off-linden-lab-refocus-second-life/

The Room VR Game

Lies Beneath VR Game

New Music Pack for Beat Saber

