# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Batman & Robin Is A MASTERPIECE!
 - [https://www.youtube.com/watch?v=r-AvP6nkmwA](https://www.youtube.com/watch?v=r-AvP6nkmwA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-04-01 00:00:00+00:00

Happy April 1st!

