# Source:BezPlanu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g, language:pl-PL

## Ostatni dzień wolności (oraz to, co nastąpiło później) - Filipiny
 - [https://www.youtube.com/watch?v=kucZ-GZM_68](https://www.youtube.com/watch?v=kucZ-GZM_68)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g
 - date published: 2020-04-01 00:00:00+00:00

Wszystkie odcinki chronologicznie: http://bit.ly/2MqAO7Q
(można też klikać w kartę "Następny odcinek" pojawiającą się pod koniec każdego filmu po prawej stronie u góry)
Aktualny odcinek z pełnego wydarzeń marca 2020r.

Mieszkania u Larry'ego na Airbnb: https://bit.ly/2USpulk

Ula:
https://www.youtube.com/channel/UCAyR1hEsjVl0p7jDPFIVH_g/videos
https://www.instagram.com/poprostulala/?hl=en

Podróż z Ulą po Azji Płd-Wsch (2017) - odcinki 1-36:
https://www.youtube.com/playlist?list=PLxvi52O0l5Y0CpLoXg48g6P8FlvX6hr3v

Skala bólu Schmidta:
https://en.wikipedia.org/wiki/Schmidt_sting_pain_index
https://pl.wikipedia.org/wiki/Skala_bólu_Schmidta
https://businessinsider.com.pl/lifestyle/najgorsze-uzadlenia-na-swiecie-skala-bolu-wg-schmidta/rycwj60

Jak Tarantula Hawk łapie swoje ofiary:
https://www.youtube.com/watch?v=1pfdRBahCG8

Coyote Peterson daje się użądlić Tarantula Hawk:
https://www.youtube.com/watch?v=MnExgQ81fhU

Coyote Peterson daje się użądlić mrówce Bullet Ant:
https://www.youtube.com/watch?v=tXjHb5QmDV0

Czas akcji: marzec 2020r.

Wsparcie na Patronite: http://bit.ly/2KsFTZk 
Instagram: http://instagram.com/bezplanu_czukesky 
Facebook: https://www.facebook.com/BezPlanu.tv 

Tłumaczenie na angielski: Michał Stadryniak
https://www.linkedin.com/in/micha%C5%82-stadryniak-82b8491a6/

