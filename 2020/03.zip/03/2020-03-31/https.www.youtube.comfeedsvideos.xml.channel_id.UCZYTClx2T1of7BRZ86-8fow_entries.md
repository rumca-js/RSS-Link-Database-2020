# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## This Tree Oozes Metal Sap
 - [https://www.youtube.com/watch?v=4z-kG9DCzUI](https://www.youtube.com/watch?v=4z-kG9DCzUI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2020-03-31 00:00:00+00:00

In the South Pacific, there is a rare tree so rich in metal that its sap runs blue.

Hosted by: Olivia Gordon

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Kevin Bealer, Jacob, KatieMarie Magnone, D.A. Noe, Charles Southerland, Christopher R Boucher, Alex Hackman, Matt Curls, Adam Brainard, Scott Satovsky Jr, Sam Buck, Avi Yashchin, Ron Kakar, Chris Peters, Kevin Carpentier, Patrick D. Ashmore, Piya Shedden, Sam Lutfi, charles george, Greg
----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://www.chemguide.co.uk/inorganic/complexions/colour.html
https://mitchalbala.com/nickel-titanate-the-coolest-yellow/
https://www.ncbi.nlm.nih.gov/pubmed/9433812
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6359332/
https://www.nature.com/articles/srep41861
https://link.springer.com/article/10.1007/s11104-017-3523-3
https://link.springer.com/article/10.1007/s11104-016-2910-5
https://www.mdpi.com/2304-6740/7/7/89/htm
https://www.purdue.edu/uns/html4ever/2004/040901.Salt.antioxidant.html
https://link.springer.com/article/10.1007/s00425-013-1983-0
https://bsapubs.onlinelibrary.wiley.com/doi/full/10.3732/ajb.89.6.998
https://journals.co.za/content/sajsci/97/11-12/EJC97252 
https://www.ncbi.nlm.nih.gov/pubmed/17244045 
https://nph.onlinelibrary.wiley.com/doi/full/10.1111/nph.15105 
----------
Images:
https://commons.wikimedia.org/wiki/File:Pycnandra_acuminata_05_-BH-_aspect_g%C3%A9n%C3%A9ral.jpg
https://commons.wikimedia.org/wiki/File:Pycnandra_acuminata_01_-BH-_Feuilles.jpg
https://commons.wikimedia.org/wiki/File:Pycnandra_acuminata_03_-BH-_S%C3%A8ve_bleue.jpg

