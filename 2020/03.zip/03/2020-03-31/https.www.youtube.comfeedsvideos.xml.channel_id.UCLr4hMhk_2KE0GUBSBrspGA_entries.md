# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Kwarantanna Show z nagrodami #1
 - [https://www.youtube.com/watch?v=bW0Ka8_tr_s](https://www.youtube.com/watch?v=bW0Ka8_tr_s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-04-01 00:00:00+00:00

Pierwszy odcinek programu, którego sponsorem jest dziura pod schodami!
Linki do produktów, gdybyście nabrali ochoty na zakupy:
Polaroll - https://bit.ly/2UO9QYh
Konsola Retro Arcade: https://bit.ly/2wTANBI
Xiaomi głośnik - https://bit.ly/2WUZdFB
Jamstick: https://bit.ly/3dKpe0k

Moje sociale: insta: http://bit.ly/InstaKlawiatur twitter: http://bit.ly/TTKlawitera i FB: http://bit.ly/FBKlawiatur.

Zasady teleturnieju:
1. Opowiedz na instastories o tym, dlaczego to Ciebie powinniśmy wybrać do wzięcia udziału w konkursie
2. Oznacz nas: @klawitermedia

Bierzemy pod uwagę tylko te filmy, które zostaną nagrane w dniach: niedziela (od 20.00) do poniedziałek (do godz. 10.30).

