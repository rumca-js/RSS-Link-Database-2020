# Source:Laowhy86, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw, language:en-US

## I Found The Source of the Coronavirus
 - [https://www.youtube.com/watch?v=bpQFCcSI0pU](https://www.youtube.com/watch?v=bpQFCcSI0pU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw
 - date published: 2020-04-01 00:00:00+00:00

Hey Laowinners,

After 2 weeks of painstaking searching, I refute the claim that the Coronavirus started outside of China. 

◘ Support me on Patreon for early release, and much more! http://www.patreon.com/laowhy86

◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

◘ OR Become a Sponsor on YouTube:
https://www.youtube.com/channel/UChvithwOECK5g_19TjldMKw/sponsor

Thanks to Snarky Guy for the footage - Check his China channel here - https://www.youtube.com/channel/UCaUlyGQGo6RFBVk_z8hqT2g

◘ My TV show: Conquering Northern China:
https://vimeo.com/ondemand/conqueringnorthernchina

◘ Conquering Southern China
https://vimeo.com/ondemand/conqueringsouthernchina

◘ Discount code for both shows: laowinning

◘ Join me every week for videos about China! Don't forget to subscribe!
http://www.youtube.com/laowhy86

Be a Laowinner!
Like comment subscribe!

◘ Facebook:
http://www.facebook.com/laowhy86

◘ Instagram: 
http://instagram.com/laowhy86

Music in this video - The Muse Maker
https://soundcloud.com/themusemaker

◘ Music used most of the time - New World Hip Hop
https://soundcloud.com/apollodrivenz
https://www.youtube.com/channel/UCgirAE5d8ufiotRXmBZZbBQ

Links for proof:  
http://www.whiov.cas.cn/105341/
http://www.whiov.cas.cn/105341/201911/t20191118_5438006.html
http://www.whiov.cas.cn/105341/201912/t20191224_5471634.html
http://159.226.126.127:8082/web/17190/20
http://159.226.126.127:8082/web/17190/46
http://gd.whiov.cas.cn/zxpy/yjsswgg/201409/t20140923_258008.html
http://rfi.my/5OFG
http://rfi.my/5OSZ
http://gd.whiov.cas.cn/tzgg/201111/t20111104_151377.html
http://www.whiov.ac.cn/tzgg_105342/202002/t20200216_5500201.html
http://blog.creaders.net/u/3027/202002/366239.html
https://www.backchina.com/blog/261460/article-314718.html
http://www.bjnews.com.cn/news/2020/02/26/695325.html
https://bbs.pku.edu.cn/v2/post-read.php?bid=1465&threadid=17542777&page=5

