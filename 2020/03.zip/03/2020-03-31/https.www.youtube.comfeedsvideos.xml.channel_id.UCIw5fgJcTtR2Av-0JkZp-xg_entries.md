# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## The Brains & The Brawn [Lockdown Live Looping Jam #5]
 - [https://www.youtube.com/watch?v=SoaPWwlibkE](https://www.youtube.com/watch?v=SoaPWwlibkE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2020-03-31 00:00:00+00:00

Support my music on Patreon: https://www.patreon.com/yuriwong *Best heard on headphones or full-range speakers.
Here's a live looping jam of my track, featuring the voice of Professor Hulk, sampled from Avengers Endgame.

Equipment used:
- Elektron Octatrack MkII
- Novation Circuit
- Korg Microkorg XL+
- iConnectAudio4+
- Fender Stratocaster w Vintage Noiseless pickups
- Fender Precision Bass
- myVolts mickXer

Music-nerd stuff:
This jam is DAWless. All the recording, playback and sequencing was done within the Octatrack.
The Octatrack is the master clock, which is sent via MIDI DIN to the iConnectAudio4+ (ica4+), which sends midi out via usb to the Circuit, OP-1, Microkorg. MIDI start/play message goes to the Circuit only, and starts the drum kit, but since it's tied to a Thru machine Track 1 on the Octatrack that only trigs at a later section, you hear it come in later.
This jam did not use the Octatrack arranger; I just simply jumped from one Pattern to another by hitting (Pattern) then (Number) manually, which was a little bit awkward, since I was playing guitar and bass which both required two hands. You'll notice some moments when I'm kind of figuring out when to stop playing and hit the pattern change buttons. Moving forward, I'll likely turn this into an Arrangement, but that takes away the spontaneous fun of hitting whichever pattern I feel like, as in this case.

