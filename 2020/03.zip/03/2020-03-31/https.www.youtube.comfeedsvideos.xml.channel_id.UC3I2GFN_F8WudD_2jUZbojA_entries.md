# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Kikagaku Moyo - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=PpnQlnra_to](https://www.youtube.com/watch?v=PpnQlnra_to)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-04-01 00:00:00+00:00

http://KEXP.ORG presents Kikagaku Moyo performing live at The Triple Door as part of KEXP's VIP Club Concert series. Recorded November 29, 2019.

Songs:
Old Snow, White Sun
Cardigan Song
Green Sugar
Nazo Nazo
Kodama
Gatherings

Host: Morgan
Audio Engineers: Eric Lemke & Julian Martlew
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpianen & Luke Knecht
Editor: Jim Beckmann

http://kexp.org
https://www.kikagakumoyo.com

