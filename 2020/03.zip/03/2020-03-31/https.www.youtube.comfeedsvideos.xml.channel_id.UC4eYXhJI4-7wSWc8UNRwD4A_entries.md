# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## Michael McDonald: Tiny Desk (Home) Concert
 - [https://www.youtube.com/watch?v=B_TOY8gQ2NY](https://www.youtube.com/watch?v=B_TOY8gQ2NY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2020-04-01 00:00:00+00:00

The Tiny Desk is working from home for the foreseeable future. Introducing NPR Music's Tiny Desk (Home) Concerts, bringing you performances from across the country and the world. It's the same spirit — stripped-down sets, an intimate setting — just a different space.

April 1, 2020 | Bobby Carter --  After five-time Grammy winner Michael McDonald finished "Matters Of The Heart," the opening song in his Tiny Desk (home) concert, there was a brief pause. The bewilderment on his face was unmistakable. It's a look I believe we all can relate to in this moment of uncertainty. He sat in his home studio, complete with an illustration of the Tiny Desk drawn by Mr. McDonald himself. That pause, usually reserved for the anticipated applause, was replaced by complete silence.

The 2020 Rock and Roll Hall of Fame inductee then proceeded to play two 1978 Doobie Brothers classics that showcase his still-golden voice: "Minute By Minute" and "What A Fool Believes." "If you know the words, sing along with me at home," he said. "I won't know if you're singing well or not because I can't hear you here."

I sang along, and so will you.

SET LIST
"Matters Of The Heart"
"Minute By Minute"
"What A Fool Believes"

