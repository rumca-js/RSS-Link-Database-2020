# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## ZOOM is becoming popular, but don't fall for the memes!
 - [https://www.youtube.com/watch?v=oEeBs8wC0JQ](https://www.youtube.com/watch?v=oEeBs8wC0JQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-04-01 00:00:00+00:00

Zoom is a botnet video conferencing service that normies are herding to using due to coronachan, but it is both closed-source and unencrypted. While at best, it will be not better than Skype and Discord, which have extending records of spyware of and manipulation, there are many much better video conferencing services that are free and open source software and peer-to-peer encrypted.

Try one of these:
Tox (qtox): https://tox.chat
Jitsi: https://jitsi.org/
Ekiga: http://www.ekiga.org/

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE NOW: https://lukesmith.xyz/donate 💰😎👌💯

## Colored Characters and Emoji in dmenu and dwm
 - [https://www.youtube.com/watch?v=0QkByBugq_4](https://www.youtube.com/watch?v=0QkByBugq_4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-03-31 00:00:00+00:00

Due to a fix I've mentioned before on my channel, you can now get colored emoji and other characters in your suckless software, just install libxft-bgra (or wait until the upstream fix) and you can see them in st without crashes. In dwm and dmenu, however, there was previously added a little block of code that disallows color emojis in any case, so in order to properly see them after the fix (rather than boxes) you have to make this little change to the source code.

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE NOW: https://lukesmith.xyz/donate 💰😎👌💯

