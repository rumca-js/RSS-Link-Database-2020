# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## Starlink: Elon Musk’s Third World Internet Scheme
 - [https://www.youtube.com/watch?v=LPTeIWU12J0](https://www.youtube.com/watch?v=LPTeIWU12J0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2020-04-01 00:00:00+00:00

🌌 The first 500 people who click the link will get 2 free months of Skillshare Premium: https://skl.sh/jaketran3

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join 

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
📸 Follow me on IG:@jaketran // http://bit.ly/jt-ig
👨👦👦 Join the Tran Mafia Family here: https://bit.ly/patreon-jt
💬 Join the community Discord: http://discord.gg/BmK8EnQ

Stuff I use & recommend:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
🏠 The real estate investing course I love & recommend: https://jake.yt/RE
🌐 Most flexible, affordable website hosting: https://jake.yt/bhd
🖥️ Website platform I use & love: https://jake.yt/kd
💽 Editing software I've used for 7+ years: https://jake.yt/ccd
📒 Online bookkeeping software I use& love: https://jake.yt/benchd 
🧾 Best affordable bookkeeping software: https://jake.yt/fbd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd
📚 Get 3 free audiobooks for life: https://amzn.to/2v58PSu
🎥 My video gear, setup, tech, books: https://jake.yt/stored

✉️ Email me: jake@jaketran.io

Subscribe to the backup channel on LBRY, use reward code "jake-cast" for free coin: https://bit.ly/LBRY-jt

📰 Sources & visuals // https://bit.ly/2QRcJ9r

-----------------------
The business of Elon Musk's SpaceX has always been to make humanity an interplanetary species
Although SpaceX has made more progress than practically all government space agencies, combined unless Elon figures out a way to speed up the rate of innovation he’s gonna be dead by the time we land on Mars.

The biggest thing standing in the way of SpaceX right now is money
Their entire business model is centered around launching payloads into space, according to Elon, taps out at around $3b per year
Far from Elon’s estimated $100b to $10t that’s needed to build a city on Mars

So Elon needs some kind of cash cow, some kind of side business that will provide the kind of money needed to fund their main goal - third world internet and Starlink
An untapped industry and business idea that Elon estimates could bring in roughly $30-50 billion dollars in revenue per year.

The internet is the most impactful inventions of all time. But by 2018, half of the humanity’s population, around 3.4 billion people at the time, still have not experienced the golden age of information

That’s where Starlink comes in. And with this system alone, Starlink could single handily bring half of the world into the modern economy

People that live away from major metropolitan areas can afford fast internet, but they’re the hardest for telecom companies to reach. Before Starlink is able to serve the ones that need internet most, it has to not go bankrupt

By 1997, owning a computer went from a far off luxury to a necessity and the Age of Information was born with plenty of money to follow.
If Starlink is successful, wnot only will Elon be able to get to Mars faster, but he will have inadvertently created a similar boom
3.75b more people with money to spend online
Double the people to serve ads to
Double the people that will want an online education
Double the people on YouTube
-----------------------

🌅 Join my Facebook Group for going remote // http://bit.ly/remote-job

-----------------------

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2020 Jake Tran. All rights reserved.

Sound:
Toonorth - Chrysalism https://soundcloud.com/countbazzy-2 
Blue Wednesday, Himalayan Beach Ensemble, Dillan Witherow - Sleeping in 
Blue Wednesday » https://soundcloud.com/bluewednesday 
Himalayan Beach Ensemble » https://soundcloud.com/himalayanbeachensemble 
Dillan Witherow » https://soundcloud.com/witherowandgibson 
Ruck P - Soul Food https://www.soundcloud.com/ruckp 

Music by Chillhop: http://chillhop.com/listen
Listen on Spotify: http://bit.ly/ChillhopSpotify

DISCLAIMER: These videos are for entertainment purposes only. This is not meant to be financial advice. Please always do your due diligence and never stop learning. Best of luck!

AFFILIATE DISCLOSURE: Some of the links in this video description are affiliate links, meaning, at no additional cost to you, I may earn a commission if you click through and make a purchase and/or subscribe. I only promote products that I 100% believe in.

