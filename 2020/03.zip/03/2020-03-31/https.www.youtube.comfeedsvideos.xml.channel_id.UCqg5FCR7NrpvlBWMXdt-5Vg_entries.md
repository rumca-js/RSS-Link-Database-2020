# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Ori and the Will of the Wisps (Zero Punctuation)
 - [https://www.youtube.com/watch?v=70gY_ToZHmI](https://www.youtube.com/watch?v=70gY_ToZHmI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-04-01 00:00:00+00:00

Watch this week's episode on DOOM Eternal early: https://www.escapistmagazine.com/v2/doom-eternal-zero-punctuation/

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

This week on Zero Punctuation, Yahtzee reviews Ori and the Will of the Wisps.

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►► https://sharkrobot.com/collections/zero-punctuation 

Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 

Like us on Facebook ►► http://www.facebook.com/EscapistMag

Follow us on Twitter ►► https://twitter.com/EscapistMag

#ZeroPunctuation #OriandtheWilloftheWisps

## Yahtzee and Jack Play Doom Eternal | Post-ZP Stream
 - [https://www.youtube.com/watch?v=36T8rBA1K6Y](https://www.youtube.com/watch?v=36T8rBA1K6Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-04-01 00:00:00+00:00

We play some lame game about Samus Aran roid raging or something.

Want in on the chat? Come join us on Twitch: https://www.twitch.tv/escapistmagazine

## Over The Alps | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=YLEFAZJdbsI](https://www.youtube.com/watch?v=YLEFAZJdbsI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-03-31 00:00:00+00:00

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Amy Campbell reviews Over The Alps, developed by Stave Studios.

Over The Alps on Steam: https://store.steampowered.com/app/1227400/Over_the_Alps/

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►► https://sharkrobot.com/collections/zero-punctuation 

Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 

Like us on Facebook ►► http://www.facebook.com/EscapistMag

Follow us on Twitter ►► https://twitter.com/EscapistMag

## Pacing and Punchlines | Yahtzee's Dev Diary
 - [https://www.youtube.com/watch?v=K48PChHcPss](https://www.youtube.com/watch?v=K48PChHcPss)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-03-31 00:00:00+00:00

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Yahtzee continues work on Bunker Buster in this episode of Dev Diary. 

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►► https://sharkrobot.com/collections/zero-punctuation 

Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 

Like us on Facebook ►► http://www.facebook.com/EscapistMag

Follow us on Twitter ►► https://twitter.com/EscapistMag

