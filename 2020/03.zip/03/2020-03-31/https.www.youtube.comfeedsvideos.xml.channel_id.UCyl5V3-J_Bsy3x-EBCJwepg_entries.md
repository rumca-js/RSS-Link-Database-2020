# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## China: 'We've Completely Cured Coronavirus And Everything Is Fine And No One Is Allowed In To Check'
 - [https://www.youtube.com/watch?v=Bz1S0Ww3HWw](https://www.youtube.com/watch?v=Bz1S0Ww3HWw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-04-01 00:00:00+00:00

BEIJING—President of the People’s Republic of China Xi Jinping made a surprise announcement to a few invited members of the press. “Everything is great here!” he said. “In fact... um... we’ve completely eradicated Coronavirus here -- cured it even. Yep, cured it. We found a cure. But it... um... only works on the Chinese so we can’t give it to you. Yeah, that’s the ticket. China-only cure; can’t share it. But, uh, everything's perfectly all right now. We're fine. We're all fine here, now, thank you. How are you?"

https://babylonbee.com/news/china-announces-that-theyve-completely-cured-coronavirus-and-everything-is-fine-there-and-no-one-is-allowed-in-to-check

## The Essential Business Of Keeping Perspective
 - [https://www.youtube.com/watch?v=VCzk68IXbvc](https://www.youtube.com/watch?v=VCzk68IXbvc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-04-01 00:00:00+00:00

This is the Babylon Bee weekly news podcast for the week of 4/1/2020.

 In this episode of The Babylon Bee podcast, editor-in-chief Kyle Mann and creative director Ethan Nicolle are joined by the editor-in-chief of Ricochet, Jon Gabriel, as they discuss the week’s big stories like using worthless dollar bills as toilet paper, China being so awesome and great at everything, and the government accidentally banning itself when it bans all non-essential business. They also discuss reading really old books by dead guys to gain perspective during hard times.

 You can hear more Jon Gabriel on his podcast: The Conservatarians.

 In the subscriber portion, Kyle, Ethan, and Jon Gabriel talk about our awesome subscriber portion intros that you’re missing out on if you are not a subscriber, pacing while talking on phone calls, ten questions on life for Jon, and also analyzing some list of the top 100 20th century novels.

  Pre-order the new Babylon Bee Best-Of Coffee Table Book coming in 2020!

 Show Outline

 Introduction - Kyle and Ethan welcome Jon Gabriel to the podcast. 

 Stuff That’s Good - 

 Ethan- Rise of Jordan Peterson documentary

 Kyle- Tuttle Twins Books

 Jon -  A Confederacy of Dunces

 Story 1 -  Toilet Paper Crisis Solved As Government Prints Trillions Of Fresh, Soft Dollar Bills

   According to Thomas Massie this isn’t a $2.2 Trillion stimulus; it is a $6 trillion stimulus when you factor in all the unaccountable actions by the Federal Reserve and US Treasury

   The Federal Reserve lowered interest rates to 0% and set reserve requirements at banks to zero.

   When Americans get a $1200 check, but the bill is $2 trillion, each American’s tax burden to pay it off will be $13,333. 

   Inflation is the increase of the money supply, not the immediate increase in consumer prices. Effects won’t be felt immediately and equally dispersed throughout the economy’s industries.  Austrian economics teaches that this is how bubbles form in certain industries and systematic malinvestments of resources take place in the first place. The higher forms of production get bid up first, they have the first crack at the “free money”. They go crazy building factories and end products that there are no real savings to buy at the end of the road. Boom and then bust.

   Story 2 -  China: 'We've Completely Cured Coronavirus And Everything Is Fine Here And No One Is Allowed In To Check'

   Their numbers are pretty low. They told World Health Org coronavirus wasn’t spreading from person to person and the WHO tweeted that out January 14!

   Why does WHO defend China as in this  CNBC article?

    China stopped their lockdown protocols but then suddenly  closed movie theaters again?

   Orders for  urns much greater than reported deaths?

   Story 3 -  Government Accidentally Shuts Itself Down With Ban On Non-Essential Businesses

   I really miss Adam Ford.  Now it’s just the libertarian bee.

   How are we deciding what is essential or not

   Is it dangerous to cede the idea that church is “non-essential”

   Topic of the Week - Talking to Jon Gabriel about reading old books to gain a sense of perspective.

 Love Mail/Hate Mail/ Feedback -  Ethan almost doxxes Joe “Flowerbed”

 Paid-subscriber portion (Starts at 01:02:47)

  Ten questions for Jon Gabriel  Time’s Top Novels   Become a paid subscriber at https://babylonbee.com/plans

