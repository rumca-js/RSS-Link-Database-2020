# Source:FoldingIdeas, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyNtlmLB73-7gtlBz00XOQQ, language:en-US

## I Can't Stop Watching Contagion | Folding Ideas
 - [https://www.youtube.com/watch?v=ZsSzrVhdVuw](https://www.youtube.com/watch?v=ZsSzrVhdVuw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyNtlmLB73-7gtlBz00XOQQ
 - date published: 2020-03-31 19:42:48+00:00

Clickbait Title: Spreading Misinformation During A Crisis Makes You A Bad Person

The one thing that I'm expecting someone in the comments is going to latch onto is the exact timeline of the abolition of serfdom in Europe because it was very much not a uniform thing and the process took a couple hundred years to encompass the entire continent. It's a super big and complex subject because it encompasses both the fallout of the Black Death and various technological developments. But some of those developments were, themselves, responses to the plague, built to solve problems it created. Ultimately I chose a super simplified, ultra-compressed version of history because the story of history is ultimately the story of the present. We can come out of this crisis better than we went in.

Written and performed by Dan Olson

Crowdfunding: https://www.patreon.com/foldablehuman
Twitter: https://twitter.com/FoldableHuman

