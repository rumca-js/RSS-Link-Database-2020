# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## The Truth [Lockdown Live Looping Jam #3]
 - [https://www.youtube.com/watch?v=tkX2d_xr7Kk](https://www.youtube.com/watch?v=tkX2d_xr7Kk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2020-03-22 00:00:00+00:00

Support my music on Patreon: https://www.patreon.com/yuriwong *Best heard on headphones or full-range speakers*
Wanted to try out looping acoustic percussion, so here it is.

Equipment used:
- Elektron Octatrack MkII
- Novation Circuit
- Korg Microkorg XL+
- iConnectAudio4+
- Fender Stratocaster w Vintage Noiseless pickups
- Fender Precision Bass
- myVolts mickXer
- Tambourine, Hand Jingle, Woodblock thing from Bali.

Music-nerd stuff:
This jam is DAWless. All the recording, playback and sequencing was done within the Octatrack.
The Octatrack is the master clock, which is sent via MIDI DIN to the iConnectAudio4+, which sends midi out via usb to the Circuit and Microkorg. This time I didn't use the OP-1 or the Minilogue for the jam - kept it simple.
I used the Octatrack Arranger for this one, manually moving the arrangement to the next step from the percussion looping part, as I didn't know how long I wanted to be looping those instruments. The rest were Arranger sequenced, and the final part was an infinite looping that I faded out.

