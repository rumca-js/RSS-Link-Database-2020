# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Top 13 NEW Horror Games of 2020
 - [https://www.youtube.com/watch?v=hMTHjG-BJPY](https://www.youtube.com/watch?v=hMTHjG-BJPY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-03-23 00:00:00+00:00

Looking forward to horror games in 2020? Here are some to keep an eye on for PC, PS4, Xbox One, Switch, and beyond.
Subscribe for more: http://youtube.com/gameranxtv

#13 Someday You'll Return

Platform: PC PS4 XBOX ONE

Release date: April 14, 2020



#12 Unholy

Platform: PC

Release date: TBA 2020



#11 Paranormal HK

Platform: PC

Release date: Jan 6, 2020



#10 Sons of the Forest

Platform: PC

Release date: TBA 2020



#9 Once Upon A Time In Roswell

Platform: PC PS4 XBOX ONE

Release date: Q4 2020



#8 The Outlast Trials

Platform: PC PS4 XBOX ONE

Release date: TBA 2020



#7 Paranoid

Platform: PC

Release date: TBA 2020



#6 WORLD OF HORROR

Platform: PC PS4 Switch

Release date: FEBRUARY 20, 2020



#5 Little Nightmares 2

Platform: PC PS4 XBOX ONE SWITCH

Release date: 2020



#4 Remothered: Broken Porcelain

Platform: PC PS4 XBOX ONE SWITCH

Release date: Q3 2020



#3 The Last of Us Part 2

Platform: PS4

Release date: May 29, 2020



#2 Amnesia: Rebirth

Platform: PC PS4

Release date: TBA 2020



#1 Resident Evil 3

Platform: PC PS4 XBOX ONE

Release date: April 3, 2020



BONUS

The Dark Pictures Anthology: Little Hope

Platform: Xbox One, PC, PS4

Release date: Q3 2020



Scorn

Platform: PC

Release date: TBA 2020



Those Who Remain

Platform: Xbox One, PC, PS4, Nintendo Switch

Release date: June 2020

## DOOM ETERNAL: Top 10 Secrets & Easter Eggs
 - [https://www.youtube.com/watch?v=EhAm5nH0G48](https://www.youtube.com/watch?v=EhAm5nH0G48)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-03-22 00:00:00+00:00

Doom Eternal (PC, PS4, Xbox One) is littered with tons of secrets, Easter eggs, and references. Here are our favorites.
Subscribe for more: http://youtube.com/gameranxtv

