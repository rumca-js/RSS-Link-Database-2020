# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## TOP 6 WEB BROWSERS! (5 out of 6 are Blue!)
 - [https://www.youtube.com/watch?v=KHHGmtCiW0o](https://www.youtube.com/watch?v=KHHGmtCiW0o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-03-23 00:00:00+00:00

Most browsers are botnets and trash. Here are six that are pretty sensible. I've used them all at some point, and while I've been using Brave pretty consistently for a while now, all the others are worth either a look or at least some awareness.

ungoogled-chromium: https://ungoogled-software.github.io/ungoogled-chromium-binaries/
Brave: https://brave.com/luk005
Icecat: https://www.gnu.org/software/gnuzilla/
Waterfox: https://www.waterfox.net/
Pale Meme: https://www.palemoon.org/
qutebrowser: https://www.qutebrowser.org/

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE NOW: https://lukesmith.xyz/donate 💰😎👌💯

## The Simple Terminal: st from Suckless, and how I extend it
 - [https://www.youtube.com/watch?v=uqLcvKYl-Ms](https://www.youtube.com/watch?v=uqLcvKYl-Ms)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-03-22 00:00:00+00:00

https://github.com/lukesmithxyz/st

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE NOW: https://lukesmith.xyz/donate 💰😎👌💯

