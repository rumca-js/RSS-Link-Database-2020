# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Street Fighter: The Movie - Movie Review
 - [https://www.youtube.com/watch?v=Nb_HMDXYXNI](https://www.youtube.com/watch?v=Nb_HMDXYXNI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-03-23 00:00:00+00:00

It's infamous, it's cheesy, it's 90's, yet Raul Julia is epic. Here's my review of my personal "guilty pleasure favorite" STREET FIGHTER: THE MOVIE!

