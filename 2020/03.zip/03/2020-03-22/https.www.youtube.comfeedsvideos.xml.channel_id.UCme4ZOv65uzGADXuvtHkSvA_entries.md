# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Miłość w czasach zarazy [#07] Bóg w Ciebie wierzy!
 - [https://www.youtube.com/watch?v=jAmZS6Dkprc](https://www.youtube.com/watch?v=jAmZS6Dkprc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-03-23 00:00:00+00:00

@langustanapalmie @dominikanie.pl #miloscwczasachzarazy @zostanwdomu
________________________________________
Codzienne wieczorne spotkania LIVE.

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#462] Po co to wszystko
 - [https://www.youtube.com/watch?v=R0lCcPKloAg](https://www.youtube.com/watch?v=R0lCcPKloAg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-03-23 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

Poznaj szczegóły Wielkopostnej akcji Fundacji Malak: 
→ https://bit.ly/32Pt2s2
→ https://www.facebook.com/events/203007710768743/

Wesprzyj akcję:
Dane do przelewu tradycyjnego:
Numer konta:  42 2490 0005 0000 4600 1184 3564 
Tytuł przelewu: AFRYKA
Nasze dane: Fundacja Malak, ul. Plac Na Stawach 1/1, 30-107 Kraków

Dane do przelewu z zagranicy:
Kod SWIFT: ALBPPLPW
Numer IBAN: PL 42 2490 0005 0000 4600 1184 3564 
Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#173] Jak się wyspowiadać bez księdza?
 - [https://www.youtube.com/watch?v=bkAx-qQrPp4](https://www.youtube.com/watch?v=bkAx-qQrPp4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-03-22 00:00:00+00:00

​ @Langustanapalmie    @Dominikanieplportal    #msza #zostanwdomu 

IV Niedziela wielkiego Postu, Rok A

1. czytanie (1 Sm 16, 1b. 6-7. 10-13)

Pan rzekł do Samuela: «Napełnij oliwą twój róg i idź: Posyłam cię do Jessego Betlejemity, gdyż między jego synami upatrzyłem sobie króla».
Kiedy przybył, spostrzegł Eliaba i powiedział: «Z pewnością przed Panem jest jego pomazaniec». Pan jednak rzekł do Samuela: «Nie zważaj ani na jego wygląd, ani na wysoki wzrost, gdyż odsunąłem go, nie tak bowiem, jak człowiek widzi, widzi Bóg, bo człowiek widzi to, co dostępne dla oczu, a Pan widzi serce». I Jesse przedstawił Samuelowi siedmiu swoich synów, lecz Samuel oświadczył Jessemu: «Nie ich wybrał Pan».

Samuel więc zapytał Jessego: «Czy to już wszyscy młodzieńcy? » Odrzekł: «Pozostał jeszcze najmniejszy, lecz on pasie owce». Samuel powiedział do Jessego: «Poślij po niego i sprowadź tutaj, gdyż nie rozpoczniemy uczty, dopóki on nie przyjdzie».

Posłał więc i przyprowadzono go: był on rudy, miał piękne oczy i pociągający wygląd. Pan rzekł: «Wstań i namaść go, to ten». Wziął więc Samuel róg z oliwą i namaścił go pośrodku jego braci. Od tego dnia duch Pański opanował Dawida.

2. czytanie (Ef 5, 8-14)
Bracia:

Niegdyś byliście ciemnością, lecz teraz jesteście światłością w Panu: postępujcie jak dzieci światłości. Owocem bowiem światłości jest wszelka prawość i sprawiedliwość, i prawda. Badajcie, co jest miłe Panu. I nie miejcie udziału w bezowocnych uczynkach ciemności, a raczej piętnując je, nawracajcie tamtych. O tym bowiem, co się u nich dzieje

po kryjomu, wstyd nawet mówić. Natomiast wszystkie te rzeczy, gdy są piętnowane, stają się jawne dzięki światłu, bo wszystko, co staje się jawne, jest światłem.

Dlatego się mówi: «Zbudź się, o śpiący, i powstań z martwych, a zajaśnieje ci Chrystus».

Ewangelia (J 9, 1. 6-9. 13-17. 34-38)

Jezus, przechodząc, ujrzał pewnego człowieka, niewidomego od urodzenia. Splunął na ziemię, uczynił błoto ze śliny i nałożył je na oczy niewidomego, i rzekł do niego: «Idź, obmyj się w sadzawce Siloam» – co się tłumaczy: Posłany. On więc odszedł, obmył się i wrócił, widząc.

A sąsiedzi i ci, którzy przedtem widywali go jako żebraka, mówili: «Czyż to nie jest ten, który siedzi i żebrze?» Jedni twierdzili: «Tak, to jest ten», a inni przeczyli: «Nie, jest tylko do tamtego podobny». On zaś mówił: «To ja jestem».

Zaprowadzili więc tego człowieka, niedawno jeszcze niewidomego, do faryzeuszów. A tego dnia, w którym Jezus uczynił błoto i otworzył mu oczy, był szabat. I znów faryzeusze pytali go o to, w jaki sposób przejrzał. Powiedział do nich: «Położył mi błoto na oczy, obmyłem się i widzę».

Niektórzy więc spośród faryzeuszów rzekli: «Człowiek ten nie jest od Boga, bo nie zachowuje szabatu». Inni powiedzieli: «Ale w jaki sposób człowiek grzeszny może czynić takie znaki?» I powstał wśród nich rozłam. Ponownie więc zwrócili się do niewidomego: «A ty, co o Nim mówisz, jako że ci otworzył oczy?» Odpowiedział: «To prorok».

Rzekli mu w odpowiedzi: «Cały urodziłeś się w grzechach, a nas pouczasz?» I wyrzucili go precz.

Jezus usłyszał, że wyrzucili go precz, i spotkawszy go, rzekł do niego: «Czy ty wierzysz w Syna Człowieczego?» On odpowiedział: «A któż to jest, Panie, abym w Niego uwierzył?» Rzekł do niego Jezus: «Jest nim Ten, którego widzisz i który mówi do ciebie». On zaś odpowiedział: «Wierzę, Panie!» i oddał Mu pokłon.

________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Msza w czasach zarazy
 - [https://www.youtube.com/watch?v=DqsZbN1T4ew](https://www.youtube.com/watch?v=DqsZbN1T4ew)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-03-22 00:00:00+00:00

​@Langustanapalmie  @Dominikanieplportal  #msza #zostanwdomu 

IV Niedziela wielkiego Postu, Rok A

1. czytanie (1 Sm 16, 1b. 6-7. 10-13)

Pan rzekł do Samuela: «Napełnij oliwą twój róg i idź: Posyłam cię do Jessego Betlejemity, gdyż między jego synami upatrzyłem sobie króla».
Kiedy przybył, spostrzegł Eliaba i powiedział: «Z pewnością przed Panem jest jego pomazaniec». Pan jednak rzekł do Samuela: «Nie zważaj ani na jego wygląd, ani na wysoki wzrost, gdyż odsunąłem go, nie tak bowiem, jak człowiek widzi, widzi Bóg, bo człowiek widzi to, co dostępne dla oczu, a Pan widzi serce». I Jesse przedstawił Samuelowi siedmiu swoich synów, lecz Samuel oświadczył Jessemu: «Nie ich wybrał Pan».

Samuel więc zapytał Jessego: «Czy to już wszyscy młodzieńcy? » Odrzekł: «Pozostał jeszcze najmniejszy, lecz on pasie owce». Samuel powiedział do Jessego: «Poślij po niego i sprowadź tutaj, gdyż nie rozpoczniemy uczty, dopóki on nie przyjdzie».

Posłał więc i przyprowadzono go: był on rudy, miał piękne oczy i pociągający wygląd. Pan rzekł: «Wstań i namaść go, to ten». Wziął więc Samuel róg z oliwą i namaścił go pośrodku jego braci. Od tego dnia duch Pański opanował Dawida.

2. czytanie (Ef 5, 8-14)
Bracia:

Niegdyś byliście ciemnością, lecz teraz jesteście światłością w Panu: postępujcie jak dzieci światłości. Owocem bowiem światłości jest wszelka prawość i sprawiedliwość, i prawda. Badajcie, co jest miłe Panu. I nie miejcie udziału w bezowocnych uczynkach ciemności, a raczej piętnując je, nawracajcie tamtych. O tym bowiem, co się u nich dzieje

po kryjomu, wstyd nawet mówić. Natomiast wszystkie te rzeczy, gdy są piętnowane, stają się jawne dzięki światłu, bo wszystko, co staje się jawne, jest światłem.

Dlatego się mówi: «Zbudź się, o śpiący, i powstań z martwych, a zajaśnieje ci Chrystus».

Ewangelia (J 9, 1. 6-9. 13-17. 34-38)

Jezus, przechodząc, ujrzał pewnego człowieka, niewidomego od urodzenia. Splunął na ziemię, uczynił błoto ze śliny i nałożył je na oczy niewidomego, i rzekł do niego: «Idź, obmyj się w sadzawce Siloam» – co się tłumaczy: Posłany. On więc odszedł, obmył się i wrócił, widząc.

A sąsiedzi i ci, którzy przedtem widywali go jako żebraka, mówili: «Czyż to nie jest ten, który siedzi i żebrze?» Jedni twierdzili: «Tak, to jest ten», a inni przeczyli: «Nie, jest tylko do tamtego podobny». On zaś mówił: «To ja jestem».

Zaprowadzili więc tego człowieka, niedawno jeszcze niewidomego, do faryzeuszów. A tego dnia, w którym Jezus uczynił błoto i otworzył mu oczy, był szabat. I znów faryzeusze pytali go o to, w jaki sposób przejrzał. Powiedział do nich: «Położył mi błoto na oczy, obmyłem się i widzę».

Niektórzy więc spośród faryzeuszów rzekli: «Człowiek ten nie jest od Boga, bo nie zachowuje szabatu». Inni powiedzieli: «Ale w jaki sposób człowiek grzeszny może czynić takie znaki?» I powstał wśród nich rozłam. Ponownie więc zwrócili się do niewidomego: «A ty, co o Nim mówisz, jako że ci otworzył oczy?» Odpowiedział: «To prorok».

Rzekli mu w odpowiedzi: «Cały urodziłeś się w grzechach, a nas pouczasz?» I wyrzucili go precz.

Jezus usłyszał, że wyrzucili go precz, i spotkawszy go, rzekł do niego: «Czy ty wierzysz w Syna Człowieczego?» On odpowiedział: «A któż to jest, Panie, abym w Niego uwierzył?» Rzekł do niego Jezus: «Jest nim Ten, którego widzisz i który mówi do ciebie». On zaś odpowiedział: «Wierzę, Panie!» i oddał Mu pokłon.

________________________________________

Msza św. online odprawiana przez o. Adama w niedzielę, 22 kwietnia, o godz. 12.00. 

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## NV [#369] Jak znaleźć Boga?
 - [https://www.youtube.com/watch?v=2UIN7urHgnE](https://www.youtube.com/watch?v=2UIN7urHgnE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-03-22 00:00:00+00:00

#langustanapalmie #niecodziennyvlog #nocnyvlog

Poznaj szczegóły Wielkopostnej akcji Fundacji Malak: 
→ https://bit.ly/32Pt2s2
→ https://www.facebook.com/events/203007710768743/

Wesprzyj akcję:
Dane do przelewu tradycyjnego:
Numer konta:  42 2490 0005 0000 4600 1184 3564 
Tytuł przelewu: AFRYKA
Nasze dane: Fundacja Malak, ul. Plac Na Stawach 1/1, 30-107 Kraków

Dane do przelewu z zagranicy:
Kod SWIFT: ALBPPLPW
Numer IBAN: PL 42 2490 0005 0000 4600 1184 3564 
Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zdjęcia i montaż: Adam Szustak OP
Muzyka: https://soundcloud.com/findinghopemusic

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

