# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## The First Two Hours of Half-Life: Alyx | Today We Try
 - [https://www.youtube.com/watch?v=A1luJ6-Kq9c](https://www.youtube.com/watch?v=A1luJ6-Kq9c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-03-23 00:00:00+00:00

Nick and Jack showcase the first two hours of Half-Life: Alyx.

Want in on the chat? Come join us on Twitch: https://www.twitch.tv/escapistmagazine

