# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## GOODBYE TO THE 💣
 - [https://www.youtube.com/watch?v=Dhg5Ud_ejfI](https://www.youtube.com/watch?v=Dhg5Ud_ejfI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-03-23 00:00:00+00:00

We are putting this on hold... FOR NOW!
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

Lily Creations: facebook.com/jaylilycreations

## AHSOKA IN THE MANDALORIAN! Stormlight Archive Update | Iron Man BS - FANTASY NEWS
 - [https://www.youtube.com/watch?v=GOc28_M4byw](https://www.youtube.com/watch?v=GOc28_M4byw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-03-22 00:00:00+00:00

Lets jump into the FANTASY NEWS! 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

Scribd No Credit Card Link: https://www.scribd.com/readfree?utm_source=readfree

#DoomEternal Price: https://www.polygon.com/ps4/2020/3/21/21188758/best-gaming-deals-doom-eternal-ps4-xbox-one-sega-genesis-mini-best-buy-amazon

What We Do In The Shadows Season 2: https://www.youtube.com/watch?v=bWEowLhqgkY

Harley Quinn Trailer: https://www.youtube.com/watch?v=TBjgTmkJDyQ

Onward Streaming: https://twitter.com/polygon/status/1240994718902878208?s=12

Wonder Woman False Rumor: https://twitter.com/lightscamerapod/status/1241052360258052097?s=12

WB Denial: https://www.indiewire.com/2020/03/wonder-woman-1984-theaters-streaming-coronavirus-1202219383/

#Ahsoka Mandalorian Casting: https://www.slashfilm.com/rosario-dawson-ahsoka-mandalorian/

Poppy War Burning God - Book 4 Announcement: https://twitter.com/kuangrf/status/1240718292114903040?s=12

Hold Up the Sky: https://www.tor.com/2020/03/19/cover-reveals-cixin-liu-to-hold-up-the-sky/

Stormlight Update: https://www.reddit.com/r/Stormlight_Archive/comments/fmovga/stormlight_book_four_update_8/

Jake Johnson is awesome: https://deadline.com/2020/03/spider-man-spider-verse-actor-free-voice-messages-peter-parker-quarantined-kids-1202888400/

