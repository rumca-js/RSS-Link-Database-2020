# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week #8: Walcząc z gołębiami
 - [https://www.youtube.com/watch?v=XSAgEV8fb3o](https://www.youtube.com/watch?v=XSAgEV8fb3o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-03-22 00:00:00+00:00

Oraz innymi efektami ubocznymi kwarantanny.
Link do zakupów online z promocjami od OleOle: https://bit.ly/3bgeG73, kod rabatowy: ZOSTAJEWDOMU 

Mój kumpel, co gra w konie, robi też fajne filmy. Nie tylko dla koniarzy: https://bit.ly/33C99oZ

Moje sociale: insta: http://bit.ly/InstaKlawiatur Tu Twitter: http://bit.ly/TTKlawitera i FB: http://bit.ly/FBKlawiatur.

Źródła:
Na jak długo wystarczy mi papieru: https://bit.ly/2J3J9tf
Prezentacja nowych smartfonów Nokii: https://bit.ly/2xdDyxI
Sprzedaż smartfonów spada: https://bit.ly/33CbgZS
Piosenkarze koncertują na insta: https://bit.ly/2Uz1Om6
I na Twitchu: https://bit.ly/2xcw91D
Ten szalony typ w szlafroku: https://bit.ly/3doieWI
Kimmel i inni na YT: https://bit.ly/2U8ye7U
Nowy iPad Pro: https://apple.co/33AIzwu
Nowy MacBook Air: https://apple.co/3bmzcmN
Prezentacja PS5: https://bit.ly/3dorGt8
Porównanie PS5 i Xbox X: https://bit.ly/3bfVUNg
Chiny wdzięczne Polakom za pomoc: https://bit.ly/2xXYOb3

