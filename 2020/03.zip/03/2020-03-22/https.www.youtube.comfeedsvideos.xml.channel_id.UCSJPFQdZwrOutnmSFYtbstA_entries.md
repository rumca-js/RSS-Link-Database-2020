# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## The Drinker's Unhappy Hour (feat. Doomcock)
 - [https://www.youtube.com/watch?v=bijmYNQsEho](https://www.youtube.com/watch?v=bijmYNQsEho)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-03-22 00:00:00+00:00

Join future ruler of Earth, Diktor von Doomcock and myself as we discuss the state of modern entertainment, plan for the end of the world and pop open a few beers in the process. Expect lots of swearing and incoherent opinions. 

Link to Doomcock's channel: https://www.youtube.com/channel/UCeCJB88u93eq91U0rlJsW-A

