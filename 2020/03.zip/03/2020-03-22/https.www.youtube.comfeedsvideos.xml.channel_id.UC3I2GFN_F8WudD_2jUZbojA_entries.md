# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Hatari - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=Cbhlay8RI4k](https://www.youtube.com/watch?v=Cbhlay8RI4k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-03-23 00:00:00+00:00

http://KEXP.ORG presents Hatari performing live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 10, 2019.

Songs:
Spillingardans
Klámstrákur
Biðröð Mistaka
Klefi / Samed (feat. Bashar Murad)

Audio: Friðfinnur Oculus Sigurðsson
Cameras: Alaia D'Alessandro, Scott Holpainen, Matt Ogaz, Kendall Rock & Baldvin Vernharðsson
Editor: Scott Holpainen

Matthías Tryggvi Haraldsson - Vocalist 
Klemens Nikulásson Hannigan - Vocalist 
Einar Hrafn Stefánsson - Drummer 

Sólbjört Sigurðardóttir - Dancer 
Ástrós Guðjónsdóttir - Dancer 
Andrean Sigurgeirsson - Dancer 
Alfreð Jónsson - Extra 
Jónína Svensdóttir - Extra
Fríða Kolbrúnar Þorkelsdóttir - Extra

Gabríel Bjarkason - Light Designer 
Salóme Ósk Jónsdóttir - Makeup
Karen Briem - Costume Designer 
Harpa Einarsdóttir - Costume Designer 
Baldvin Vernharðsson - Co-director 
Ingi Kristján Sigurmarsson - Production assistant 

http://kexp.org
https://www.hatari.is

