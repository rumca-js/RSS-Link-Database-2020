# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## COVID-19 Is Just The Beginning. Here's Why. | Answers With Joe
 - [https://www.youtube.com/watch?v=AbKMNpYBCTc](https://www.youtube.com/watch?v=AbKMNpYBCTc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2020-03-23 00:00:00+00:00

Get 30 days of CuriosityStream for free when you sign up at http://www.curiositystream.com/joescott
The novel coronavirus pandemic has officially destabilized our economy, our workplaces, and our homes. That's the bad news. The worse news? It won't be the last.

In today's video I speak with bestselling author David Quammen about zoonotic viruses - viruses that jump from animals to humans. Why they're so dangerous, why we've been seeing more of them in recent years, and why COVID-19 will not be the last one we'll be dealing with.

You can find David's book, Spillover: Animal Infections And The Next Human Pandemic here:
https://amzn.to/2UvmWcy


Want to support the channel? Here are some ways:

Patreon: http://www.patreon.com/answerswithjoe

Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join

Cool shirts and merchandise: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

============

LINKS LINKS LINKS:

https://www.cdc.gov/coronavirus/2019-ncov/cases-in-us.html

https://www.cdc.gov/coronavirus/2019-ncov/summary.html  

https://www.who.int/emergencies/diseases/novel-coronavirus-2019/situation-reports

Super informative video from Draw Curiosity:
https://www.youtube.com/watch?v=oA8XYSftmtQ

Dr. John Campbell has done an excellent job covering the virus:
https://www.youtube.com/user/Campbellteaching

Alanna Shaikh's excellent TED talk:
https://www.youtube.com/watch?v=Fqw-9yMV0sI

Be safe out there everyone.

