# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## DIY Switch for Filthy Pirates
 - [https://www.youtube.com/watch?v=u_vSMtmz9TA](https://www.youtube.com/watch?v=u_vSMtmz9TA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-03-23 00:00:00+00:00

Buy the CORSAIR ONE PRO i200 Gaming PC at
CORSAIR: https://geni.us/ywY7S0L
On Amazon (Paid Link): https://geni.us/I5Cl0

Sign up for Private Internet Access VPN at https://lmg.gg/pialinus1

If you want to play retro games on the go, the Creoqode Lyra looks like a good option. But does it hold up to the Kickstarters claims?

Check out the Lyra: https://www.creoqode.com/lyra

Buy a cheap emulator 
On Amazon (PAID LINK): https://geni.us/yJrsYJ1 
On Newegg (PAID LINK): https://geni.us/fBsod

Buy Rasberry Pi
On Amazon (PAID LINK): https://geni.us/DJztM
On Walmart (PAID LINK): https://geni.us/NR3Vob
On Newegg (PAID LINK): https://geni.us/SAtzwS


Purchases made through some store links may provide some compensation to Linus Media Group.
Discuss on the forum: https://linustechtips.com/main/topic/1167940-diy-switch-for-filthy-pirates/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Get your ticket to LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

## Here's How YOU Can Help Find a Cure for COVID-19!
 - [https://www.youtube.com/watch?v=KU4qOebhkfs](https://www.youtube.com/watch?v=KU4qOebhkfs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-03-22 00:00:00+00:00

Go to https://privacy.com/linus ​to get $5 off your first purchase!

Save 10% and Free Worldwide Shipping at Ridge Wallets by using offer code LINUS at https://www.ridge.com/LINUS

We show you how you can setup Folding@Home, a distributed computation project that allows you to donate your computer's processing power to help model protein dynamics to combat diseases like Parkinsons, Cancer, Huntingtons, and most importantly, COVID-19.

Download Folding@Home: https://foldingathome.org/start-folding/
LTT Folding Team Number: 223518
Get a Folding@Home Passkey: https://apps.foldingathome.org/getpasskey
Get Help Folding on the LTT Discord server (#folding-and-boinc) : https://discord.gg/LTT

LTT Folding Team's Event Info: https://linustechtips.com/main/topic/1164541-ltt-folding-teams-emergency-response-to-covid-19/

Discuss on the forum: https://linustechtips.com/main/topic/1167571-heres-how-you-can-help-find-a-cure-for-covid-19/

Buy EKWB Watercooling Parts:
On Their Site: https://lmg.gg/A8mop
On Amazon: https://lmg.gg/K9Sgg
On Newegg: https://lmg.gg/6wLZt

Buy an EVGA 1600W T2 Power Supply:
On Amazon: https://lmg.gg/YaaW0
On Newegg: https://lmg.gg/DiBTO

Buy an Intel Xeon 8180 Processor:
On Amazon: https://lmg.gg/mFun8
On Newegg: https://lmg.gg/wFcGl

Buy an ASUS WS C621E Sage Motherboard:
On Amazon: https://lmg.gg/xXJ9m
On Newegg: https://lmg.gg/62Cvg

Buy Kingston ECC DDR4 Memory:
On Amazon: https://lmg.gg/8z2Hr
On Newegg: https://lmg.gg/vpjDJ

Buy NVIDIA TITAN V Graphics Cards:
On Amazon: https://lmg.gg/9a0SV
On Newegg: https://lmg.gg/aFVff

Buy Swiftech Watercooling Parts
On Amazon: https://lmg.gg/x1uFw
On Newegg: https://lmg.gg/A1d86

Buy Intel NVMe SSDs:
On Amazon: https://lmg.gg/XjoMb
On Newegg: https://lmg.gg/btdco

Purchases made through some store links may provide some compensation to Linus Media Group.

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Get your ticket to LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

