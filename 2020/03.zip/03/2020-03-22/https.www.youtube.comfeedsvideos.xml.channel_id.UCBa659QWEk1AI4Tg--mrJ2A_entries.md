# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## YouTube's Copyright System Isn't Broken. The World's Is.
 - [https://www.youtube.com/watch?v=1Jwo5qc78QU](https://www.youtube.com/watch?v=1Jwo5qc78QU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2020-03-23 00:00:00+00:00

No copyright infringement intended. | Watch Money, my new Nebula Original series, when you join CuriosityStream for only $2.99/month: https://curiositystream.com/tomscott

WRITTEN BY: Tom Scott
SCRIPT ASSISTANT: Andrea Marks
CAMERA: Jamie Drew
CAMERA: Joe Stone
AUDIO MIX: Graham Haerther
EDITOR: Isla McTear
CAPTIONS: Caption+

WITH THANKS TO:
1901 Arts Club
The Camera Museum, Soho
Evan Edinger
The Lexi Cinema, Kensal Green
Mandy Celine
Abigail Thorn
Tim Bunn

LEGAL CAMEOS:
Leonard French https://www.youtube.com/user/ljfrench009
Devin Stone https://www.youtube.com/legaleagle

QUASI-LEGAL CAMEO:
Jay Foreman https://www.youtube.com/jayforeman

MINECRAFT SEQUENCE:
Joel "Smallishbeans" https://www.youtube.com/SmallishBeans

MUSIC
Epidemic Sound
Canon in D solo piano recording courtesy of ProstoRecords and Envato Market
Canon in D rock recording courtesy of Kora3000 and Envato Market

STOCK PHOTOGRAPHY
Images used under license from shutterstock.com

PRODUCER
Reb Day

© Pad 26 Limited MMXX

Chapters
0:00 Introduction
1:09 Chapter 1: The Mess We're In
10:08 Chapter 2: No Copyright Infringement Intended
22:18 Chapter 3: Content ID
28:21 Chapter 4: Where Do We Go From Here
39:00 Trailer and Sponsorship
40:07 Credits and Outtakes

https://tomscott.com
https://twitter.com/tomscott
https://instagram.com/tomscottgo

