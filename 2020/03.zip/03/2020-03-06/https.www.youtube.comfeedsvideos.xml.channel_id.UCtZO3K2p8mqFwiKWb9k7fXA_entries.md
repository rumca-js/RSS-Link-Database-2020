# Source:Techaltar, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA, language:en-US

## Why Windows 10X is a big deal
 - [https://www.youtube.com/watch?v=MjyVpfw3RT0](https://www.youtube.com/watch?v=MjyVpfw3RT0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA
 - date published: 2020-03-06 00:00:00+00:00

Sponsored by Brilliant. The first 200 get 20% off their subscriptions at http://brilliant.org/TechAltar 

Microsoft has recently announced Windows 10x, it's new operating system for dual-screen devices. Underneath all that shiny UX though, there are much bigger changes that aim to fundamentally change how Windows works for everyone. 

The Story Behind - Ep. 63

[[[ TECHALTAR LINKS ]]]:

Merch: 
http://enthusiast.store 

Social media:
https://twitter.com/TechAltar
https://instagram.com/TechAltar
https://facebook.com/TechAltar

If you want to support TechAltar directly:
https://flattr.com/@techaltar

My video gear:
https://kit.co/TechAltar/video-gear

[[[ ATTRIBUTIONS ]]]:

Music by Edemski:
https://soundcloud.com/edemski
https://facebook.com/edemskimusic

