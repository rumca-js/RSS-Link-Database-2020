# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Murder by Numbers | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=WyD9GCosRfs](https://www.youtube.com/watch?v=WyD9GCosRfs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-03-07 00:00:00+00:00

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Jesse Galena reviews Murder by Numbers developed by Mediatonic.

Murder by Numbers on Steam: https://store.steampowered.com/app/1140290/Murder_by_Numbers/

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►► https://sharkrobot.com/collections/zero-punctuation 

Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 

Like us on Facebook ►► http://www.facebook.com/EscapistMag

Follow us on Twitter ►► https://twitter.com/EscapistMag

#MurderbyNumbers

## Yes, Your Grace | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=ApnwNxa-jcM](https://www.youtube.com/watch?v=ApnwNxa-jcM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-03-06 00:00:00+00:00

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

KC Nwosu reviews Yes, Your Grace, developed by Brave At Night.

Yes, Your Grace on Steam: https://store.steampowered.com/app/1115690/Yes_Your_Grace/

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►► https://sharkrobot.com/collections/zero-punctuation 

Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 

Like us on Facebook ►► http://www.facebook.com/EscapistMag

Follow us on Twitter ►► https://twitter.com/EscapistMag

#YesYourGrace

