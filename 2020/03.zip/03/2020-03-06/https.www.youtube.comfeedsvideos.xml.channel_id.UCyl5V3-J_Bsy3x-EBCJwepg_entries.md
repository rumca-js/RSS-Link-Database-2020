# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## The Mysterious Science Of Turning Christian: The Mike Nelson Interview
 - [https://www.youtube.com/watch?v=nVmlZ3HivQ8](https://www.youtube.com/watch?v=nVmlZ3HivQ8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-03-06 00:00:00+00:00

Editor-in-chief Kyle Mann and creative director Ethan Nicolle welcome Mike Nelson, former star of Mystery Science Theater 3000, RiffTrax dude, and host of some podcasts. Mike talks to Kyle and Ethan about his story of becoming a Christian, working in an industry that’s not really down with that,  making comedy for all, and how he and Ethan helped ruin VeggieTales. 

 You can hear more from Mike Nelson on his podcasts: Like Trees Walking (about Basic Christian Apologetics), 372 Pages We’ll Never Get Back (about bad books) and he semi-regularly joins in with Doug TenNapel and Ethan Nicolle on Audio Mullet! 

 Check out the  RiffTrax Live 2020 Kickstarter!

  Pre-order the new Babylon Bee Best-Of Coffee Table Book coming in 2020! Get a Sneak Peak!

 Topics Discussed

   The guys plan out Mike’s tombstone listing his accomplishments

   Mike Nelson’s story and his work on MST3K

   How Ready Player One is terrible

   Coming to faith in Hollywood

   Facing doubts, finding ammunition in C.S. Lewis’ God in the Dock

   Working with people who disagree with you

   RiffTrax events and other podcasts

   Mike Nelson worked on the infamous Netflix run of Veggietales with Ethan

   Hollywood name-dropping and funny things that happened to Mike’s wife

   Seat-fillers at award shows 

   Mentioned in this episode: MST3K: Merlin's Shop of Mystical Wonders (This episode may be a good gateway into MST3K according to Mike Nelson)

 Subscriber Portion (Begins at 00:42:09)

 The entire interview is available for Babylon Bee subscribers only…

 Become a paid subscriber at https://babylonbee.com/plans

