# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## 6 People Who Predicted the Future With Stunning Accuracy
 - [https://www.youtube.com/watch?v=oNnlmq05hGc](https://www.youtube.com/watch?v=oNnlmq05hGc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2020-03-06 00:00:00+00:00

With the current acceleration of innovation making what was unthinkable just a few years ago possible, it's a little easier to imagine what the future may hold than ever before. But in the past this was a great deal harder. Today we look at the visionaries that saw our modern life.

--- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. 

If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- New Thinking Book written by Dagogo Altraide ---
Learn the stories of those who invented the things we all use everyday.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

--- ColdFusion Social Media ---
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusionTV

--- ColdFusion Podcast links ---
Google Podcasts - http://bit.ly/2xo8doR
Apple Podcasts - https://apple.co/2WI2IeU
Spotify - https://spoti.fi/2KT1taB
Stitcher - http://bit.ly/2WI4f4E

Sources:

https://listverse.com/2013/03/15/10-ridiculously-specific-predictions-that-came-true/

1999A.D. https://youtu.be/6XxKORHKcjg

https://www.sciencealert.com/these-15-wild-sci-fi-predictions-about-future-tech-actually-came-true

Apple Video: https://www.youtube.com/watch?v=HGYFEI6uLy0

https://bigthink.com/technology-innovation/isaac-asimov-future-predictions-from-1983?rebelltitem=3#rebelltitem3

//Soundtrack//

Tom Demac & Real Lies - White Flowers

no spirit - leaves covered by snow

Module Module - An Interlude

Winter Flags - Winter Flags

Wezi Mkandawire - Someday

Dan Farley - Arkose

Valotihkuu - Sleeping In Wildflower Meadow

Mosaik - Icarus (Need a Name Remix)

Nils Frahm - You

Kevin MacInnis - Miss the Feeling of Being Missed

Yasper - Move Together

Gem Club - First Weeks

Burn Water (I Haven't finished this track yet)

» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide

Why are you still reading?

