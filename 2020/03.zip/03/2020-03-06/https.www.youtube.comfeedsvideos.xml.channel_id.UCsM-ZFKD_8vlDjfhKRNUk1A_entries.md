# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## The Score - Stronger - live MUZO.FM
 - [https://www.youtube.com/watch?v=wLqmqspdLPc](https://www.youtube.com/watch?v=wLqmqspdLPc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-03-06 00:00:00+00:00

The Score Stronger na żywo w MUZO.FM. Utwór The Score Stronger pochodzi z EP The Score Pressure.


Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook The Score: http://www.facebook.com/TheScoreOfficial
Instagram The Score: http://www.instagram.com/thescoremusic
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm


The Score Stronger tekst

I don't do this for the riches
I'm infected, my condition is I'm always in my head
These words are my religion,
I'm obsessed it's by decision
I'ma do this til I'm dead

Set me on fire, set me on, set me on fire
Whoa whoa
I'm still alive, I'm still a, I'm still alive
Whoa, whoa-bet you didn't think that I'd come back to life

Higher, faster, ever lasting
Harder, faster, ever never crashing

Stronger, bet you didn't think that I'd come back to life

I do this with conviction
I write truths and never fiction
My disease is what you fed
I can't stop with my ambition
Like a missile on a mission
I'm a force that you will dread

Stronger, stronger, ever lasting
Higher, faster, never crashing

