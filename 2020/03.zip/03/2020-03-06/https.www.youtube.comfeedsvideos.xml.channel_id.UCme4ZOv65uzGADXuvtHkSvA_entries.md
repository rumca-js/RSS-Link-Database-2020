# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## CNN [#171] Co zrobić, żeby Bóg mi błogosławił?
 - [https://www.youtube.com/watch?v=HSnYRDvbWWM](https://www.youtube.com/watch?v=HSnYRDvbWWM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-03-07 00:00:00+00:00

#cnn #dobrewiadomości #kazankodookienka

Kazanie na niedzielę, w każdą niedzielę, czyli Słowo Na Niedzielę. 
II Niedzielę Wielkiego Postu, Rok A

1. czytanie (Rdz 12, 1-4a)

Pan Bóg rzekł do Abrama: «Wyjdź z twojej ziemi rodzinnej i z domu twego ojca do kraju, który ci ukażę. Uczynię bowiem z ciebie wielki naród, będę ci błogosławił i twoje imię rozsławię: staniesz się błogosławieństwem. Będę błogosławił tym, którzy tobie błogosławić będą, a tym, którzy tobie będą złorzeczyli, i Ja będę złorzeczył. Przez ciebie będą otrzymywały błogosławieństwo ludy całej ziemi».

Abram udał się w drogę, jak mu Pan rozkazał.


2. czytanie (2 Tm 1, 8b-10)

Najdroższy: Weź udział w trudach i przeciwnościach znoszonych dla Ewangelii mocą Bożą! On nas wybawił i wezwał świętym powołaniem nie na podstawie naszych czynów, lecz stosownie do własnego postanowienia i łaski, która nam dana została w Chrystusie Jezusie przed wiecznymi czasami. Ukazana zaś została ona teraz przez pojawienie się naszego Zbawiciela, Chrystusa Jezusa, który zniweczył śmierć, a na życie i nieśmiertelność rzucił światło przez Ewangelię.

Ewangelia (Mt 17, 1-9)

Jezus wziął z sobą Piotra, Jakuba oraz brata jego, Jana, i zaprowadził ich na górę wysoką, osobno. Tam przemienił się wobec nich: twarz Jego zajaśniała jak słońce, odzienie zaś stało się białe jak światło. A oto ukazali się im Mojżesz i Eliasz, rozmawiający z Nim.

Wtedy Piotr rzekł do Jezusa: «Panie, dobrze, że tu jesteśmy; jeśli chcesz, postawię tu trzy namioty: jeden dla Ciebie, jeden dla Mojżesza i jeden dla Eliasza».

Gdy on jeszcze mówił, oto obłok świetlany osłonił ich, a z obłoku odezwał się głos: «To jest mój Syn umiłowany, w którym mam upodobanie, Jego słuchajcie!» Uczniowie, słysząc to, upadli na twarz i bardzo się zlękli.

A Jezus zbliżył się do nich, dotknął ich i rzekł: «Wstańcie, nie lękajcie się!» Gdy podnieśli oczy, nikogo nie widzieli, tylko samego Jezusa.

A gdy schodzili z góry, Jezus przykazał im, mówiąc: «Nie opowiadajcie nikomu o tym widzeniu, aż Syn Człowieczy zmartwychwstanie».
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Przyjaciele Afryki || Akcja Wielkopostna
 - [https://www.youtube.com/watch?v=YgR1iE5kAwc](https://www.youtube.com/watch?v=YgR1iE5kAwc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-03-07 00:00:00+00:00

#PrzyjacieleAfryki #AkcjaWielkopostna #FundacjaMalak #LangustanaPalmie

Poznaj szczegóły Wielkopostnej akcji Fundacji Malak: 
→ https://bit.ly/32Pt2s2
→ https://www.facebook.com/events/203007710768743/

Wesprzyj akcję:
Dane do przelewu tradycyjnego:
Numer konta:  42 2490 0005 0000 4600 1184 3564 
Tytuł przelewu: AFRYKA
Nasze dane: Fundacja Malak, ul. Plac Na Stawach 1/1, 30-107 Kraków

Dane do przelewu z zagranicy:
Kod SWIFT: ALBPPLPW
Numer IBAN: PL 42 2490 0005 0000 4600 1184 3564 
Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#449] Teraz
 - [https://www.youtube.com/watch?v=3xQX1ze2Ohk](https://www.youtube.com/watch?v=3xQX1ze2Ohk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-03-07 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#448] Owoce?
 - [https://www.youtube.com/watch?v=gJhSHK1QWEU](https://www.youtube.com/watch?v=gJhSHK1QWEU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-03-06 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

