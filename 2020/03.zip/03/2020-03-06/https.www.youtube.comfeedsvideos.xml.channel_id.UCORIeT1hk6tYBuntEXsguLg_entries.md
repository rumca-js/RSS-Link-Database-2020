# Source:PostmodernJukebox, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg, language:en-US

## Wannabe - Spice Girls (Vintage "Andrews Sisters" Style Cover) by Postmodern Jukebox
 - [https://www.youtube.com/watch?v=u9jGGiqjwf4](https://www.youtube.com/watch?v=u9jGGiqjwf4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg
 - date published: 2020-03-06 00:00:00+00:00

GET TIX TO OUR GRAND REOPENING WORLD TOUR: http://www.pmjtour.com
Download & Stream "Wannabe" Here: https://pmjlive.com/the90s-volume1
Shop PMJ Music/Merch:  https://smarturl.it/pmjshop?IQid=youtube
Follow Us On Spotify: https://smarturl.it/pmjcomplete?IQid=youtube

To celebrate our new '90s compilation, Sara, Olivia and Therese joined us for our version of the '90s biggest girl group hit - "Wannabe" by the Spice Girls - done in the style of one of the original "girl groups": The Andrews Sisters.  

____________________________________________

Follow The Musicians:
Olivia Kuper Harris (Vocals):
Facebook: https://facebook.com/olivia.kuper.harris
Instagram: https://instagram.com/olivia.kuper.harris
Twitter: https://twitter.com/olivia_k_harris

Sara Niemietz (Vocals):
Facebook: https://facebook.com/SaraNiemietzMusic/
Instagram: http://instagram.com/sarapalooza 
Twitter: http://twitter.com/saraniemietz

Therese Curatolo (Vocals):
Facebook: https://facebook.com/therese.curatolo
Instagram: https://instagram.com/reesetea/
Twitter: https://twitter.com/reesetea

Mike Chisnall (Guitar):
Facebook: https://facebook.com/mikechisnallmusic/
Instagram: https://instagram.com/mikechisnallmusic/

Cooper Appelt (Bass):
Facebook: https://facebook.com/cooper.appelt
Instagram: https://instagram.com/cooperappelt
Twitter: https://twitter.com/cooperappelt

Martin Diller (Drums):
Facebook: https://facebook.com/martindillermusic/
Instagram:https://instagram.com/drummer510
Twitter: https://twitter.com/MartinDiller

Scott Bradlee (Piano):
YouTube: http://youtube.com/scottbradlee
Facebook: http://facebook.com/scottbradleemusic
Instagram: http://instagram.com/scottbradlee
Twitter: http://twitter.com/scottbradlee

Arrangement by: Scott Bradlee
Engineered by: Thai Long Ly
Cinematography by: Guy Livneh
Wardrobe: Sunny Holiday
____________________________________________
#SpiceGirls #WannaBe #Cover #PMJ

