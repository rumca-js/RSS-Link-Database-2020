# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Life of Aragorn before The Lord of the Rings | Tolkien Explained
 - [https://www.youtube.com/watch?v=5aPrSyKE3oE](https://www.youtube.com/watch?v=5aPrSyKE3oE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2020-03-06 00:00:00+00:00

What was Aragorn doing before The Lord of the Rings?  After his father, Arathorn is killed, Aragorn is taken to Rivendell to be raised by Elrond. He grows into a great warrior and his experiences will mold him into the man who would reclaim the throne of Gondor and Arnor, and usher in the fourth age of Middle-earth!

Hit subscribe - and the bell - so you never miss a video from Nerd of the Rings!


--------------
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.

Arwen and Aragorn the Youth by Samo
Denethor Son of Ecthelion II by 1oshuart
Strider by ckgoksoy
At the Sign of the Prancing Pony - Ted Nasmith

#lordoftherings #aragorn #lotr

