# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Why I'm Angry. | Russell Brand
 - [https://www.youtube.com/watch?v=SmW37YPnfyc](https://www.youtube.com/watch?v=SmW37YPnfyc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-03-06 00:00:00+00:00

A member of the audience asked why I became vegan...this is my answer...
#RecoveryLive Tour 2020 - a few tickets still available for #Auckland, #Christchurch & #Wellington shows!
https://www.russellbrand.com/tour/

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

