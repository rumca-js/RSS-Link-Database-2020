# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## These are the pioneering women of photojournalism
 - [https://www.cnn.com/2020/03/06/world/gallery/trailblazers-of-light-women-photojournalists/index.html](https://www.cnn.com/2020/03/06/world/gallery/trailblazers-of-light-women-photojournalists/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-03-06 23:58:57+00:00

Photojournalism has traditionally been a male-dominated field.

