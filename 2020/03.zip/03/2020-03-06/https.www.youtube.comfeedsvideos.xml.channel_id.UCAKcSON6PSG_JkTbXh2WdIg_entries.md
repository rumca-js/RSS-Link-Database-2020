# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## X-Ray Spex (Teenage Kicks from The Current)
 - [https://www.youtube.com/watch?v=yUvZM96EyC0](https://www.youtube.com/watch?v=yUvZM96EyC0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-03-07 00:00:00+00:00

Jim McGuinn talks about one of his favorite singers of the punk and post-punk era: Poly Styrene from the band X-Ray Spex, who released a song that addressed consumerism, entitled, "Oh Bondage! Up Yours!"
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

