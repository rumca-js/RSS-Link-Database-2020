# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## MY BIGGEST MISTAKES 😱
 - [https://www.youtube.com/watch?v=91tY0amGY7g](https://www.youtube.com/watch?v=91tY0amGY7g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-03-07 00:00:00+00:00

From A Song of Ice and Fire to Berserk, I have made mistakes here on the channel. Let's talk about that! 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## Last Of US HBO Show! LotR LEAD ACTOR Cast. Natalie Dormer Witcher Rumors - FANTASY NEWS
 - [https://www.youtube.com/watch?v=dp-HIfLDo74](https://www.youtube.com/watch?v=dp-HIfLDo74)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-03-06 00:00:00+00:00

Lets jump into the Fantasy News! 
The first 500 people who click the link will get 2 free months of Skillshare Premium: https://skl.sh/danielgreene3

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

This video was sponsored by Skillshare

NEWS:

The Magicians’ Ending: https://www.tor.com/2020/03/03/the-magicians-fifth-season-will-be-its-last/

JJ Abrams #Pinkerton: https://variety.com/2020/film/news/j-j-abrams-warner-bros-thriller-the-pinkerton-1203522909/

Captain Kirk “Played Out”:https://deadline.com/2020/03/william-shatner-captain-kirk-star-trek-picard-1202872876/

#TheWheelOfTime Composer: https://winteriscoming.net/2020/03/02/amazons-wheel-time-show-gets-composer/amp/
Composer Website: http://davidbuckleymusic.com/

#LordOfTheRings Lead Actor: https://deadline.com/2020/03/the-lord-of-the-rings-maxim-baldry-set-lead-amazon-series-1202873677/maz/

DC Cancels March Comic Con: https://www.hollywoodreporter.com/heat-vision/dc-cancels-march-comic-con-appearances-coronavirus-concerns-1282436

Beyond Solaris: https://www.tor.com/2020/03/03/stanislaw-lem-mit-press-reissue-polish-science-fiction-translation/

Jerusalem’s Lot Casting: https://www.tor.com/2020/03/04/epix-adaptation-of-stephen-kings-jerusalems-lot-to-feature-emily-hampshire-and-adrien-brody-as-leads/

Star Wars game: https://twitter.com/polygon/status/1235218265254834176?s=12

New Mutants: https://twitter.com/ERCboxoffice/status/1235008909850501121

Sandman trailer: https://www.youtube.com/watch?v=zn8WDXY6hRM&feature=youtu.be

Natalie Dormer #Witcher season 2: https://redanianintelligence.com/2020/03/05/rumor-game-of-thrones-star-natalie-dormer-cast-in-the-witcher-season-2/amp/?__twitter_impression=true

Tolkien unfinished tales: https://www.tor.com/2020/03/04/jrr-tolkien-unfinished-tales-middle-earth-illustrated-edition-alan-lee/

Charlie and the Chocolate Factory: https://variety.com/2020/tv/news/taika-waititi-netflix-charlie-and-the-chocolate-factory-animated-series-willy-wonka-oompa-loompa-1203524577/amp/

HBO #TheLastOfUs: https://www.hollywoodreporter.com/heat-vision/last-us-series-works-at-hbo-chernobyl-creator-1282707

The Night Sun: https://twitter.com/tordotcom/status/1235629867665960960?s=12

