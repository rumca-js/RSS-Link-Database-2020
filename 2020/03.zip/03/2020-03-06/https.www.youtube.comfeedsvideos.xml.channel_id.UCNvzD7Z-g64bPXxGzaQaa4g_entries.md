# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Top 15 NEW War Games of 2020
 - [https://www.youtube.com/watch?v=xGkesCqv8Dg](https://www.youtube.com/watch?v=xGkesCqv8Dg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-03-07 00:00:00+00:00

Looking for some war action in your video games? Here are some war games to keep an eye on throughout 2020 for PC, PS4, Xbox One, and more.
Subscribe for more: http://youtube.com/gameranxtv

#15 Days of War: Definitive Edition
PC
Jan 30, 2020

#14 Broken Lines
PC
25 Feb, 2020

#13 Blunt Force
PC[VR]
TBA 2020

#12 Comanche
PC
TBA 2020

#11 Panzer Corps 2
PC
MARCH 19, 2020

#10 Starship Troopers - Terran Command
PC
TBA 2020

#9 Medal of Honor: Above and Beyond
OCULUS VR
2020

#8 Land Of War The Beginning
PC 
2020

#7 Project Wingman
PC
2020

#6 Wasteland 3
PC, PS4, XBOX ONE
19 May 2020

#5 Call of Duty: Black Ops 5
PC, PS4, XBOX ONE
2020

#4 CrossfireX
XBOX ONE
2020

#3 Tom Clancy's Rainbow Six Quarantine
PC, PS4, XBOX ONE, PS5, XBOX SERIES X
2020

#2 Outriders
PC, PS4, XBOX ONE, PS5, XBOX SERIES X
2020

#1 Halo Infinite
PC, XBOX ONE, XBOX SERIES X
2020

BONUS

Death Stranding
PC
JUNE 2, 2020

## WHY GOOGLE STADIA HAS ALMOST NO GAMES, AMNESIA RETURNS, & MORE
 - [https://www.youtube.com/watch?v=lPZdxtZMZgg](https://www.youtube.com/watch?v=lPZdxtZMZgg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-03-06 00:00:00+00:00

Thanks to Puma and Finish Line for sponsoring this video. Check out some kicks here: http://www.finishline.com/puma?icid=app_pumapaxeast


New details explain why Stadia has limited games, the horror heavyweight Amnesia makes a comeback, The Last of Us is getting a TV show, and more stuff happening in the world of gaming news.
Subscribe for more: http://youtube.com/gameranxtv 

*Jakes twitter: https://twitter.com/jakebaldino 
*Instagram: https://goo.gl/HH6mTW 

 discord.gg/gameranx 

 Weekly giveaway link: https://goo.gl/forms/a7zCtr1HuTkzWuOo2 



 ~~~~STORIES~~~~



Why Google Stadia might be struggling
https://www.businessinsider.com/why-are-so-few-games-on-google-stadia-2020-2

The Last of Us on TV
https://variety.com/2020/tv/news/the-last-of-us-series-hbo-craig-mazin-neil-druckmann-1203524989/

Amnesia returns
https://twitter.com/frictionalgames/status/1235913505812946945?s=20


Ghost of Tsushima (June 26)
https://youtu.be/24jDIftu97s


Amazing God of War camera hack
https://www.vg247.com/2020/03/05/god-of-war-baldur-flips-off/



New Grounded gameplay
https://youtu.be/vTSBLqAjMSA

Black Mesa digital foundry
https://youtu.be/EDquIZPXxWA

Valorant gameplay
https://youtu.be/g8amyzDHOKw



More Half Life?
https://www.ign.com/articles/half-life-3-half-life-alyx-sequel

Star Wars game leaked
https://twitter.com/psnrelease/status/1235166862591352832

