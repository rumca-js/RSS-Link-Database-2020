# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## 320 TERABYTES in a normal case!! - The DIY 4k editing NAS
 - [https://www.youtube.com/watch?v=FAy9N1vX76o](https://www.youtube.com/watch?v=FAy9N1vX76o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-03-07 00:00:00+00:00

Get 50% off your first 3 months of FreshBooks when you sign up for a paid plan at https://www.freshbooks.com/techtips

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire

Fractal's new Define 7 XL has an enormous capacity for hard drives, so it only makes sense to build and deploy a 4K editing NAS to compliment our recently built 4K editing workstation.  For about $1000(not including the drives) you can build up this system and add up to 20 drives, like Segate's Iron Wolf Pro line. Using Unraid or ProxMox you'll be able to manage your data effectively.

Buy Define 7XL
On Amazon (PAID LINK): https://geni.us/ZW6CMlG
On Newegg (PAID LINK): https://geni.us/OlDwOs

Buy Ryzen 2600 
On Amazon (PAID LINK): https://geni.us/u0va6y1
On Newegg (PAID LINK): https://geni.us/K9Q2zfV

Buy Corsair Vengeance LPX 16GB
On Amazon (PAID LINK): https://geni.us/c4TbFdq
On Newegg (PAID LINK): https://geni.us/GjeD

Buy Asus ROG STRIX B450-F
On Amazon (PAID LINK): https://geni.us/cNGeUBX
On Newegg (PAID LINK): https://geni.us/8ptR

Buy Corsair HX750 
On Amazon (PAID LINK): https://geni.us/vXmUAO
On Newegg (PAID LINK): https://geni.us/BY6404

Buy Adata SU655
On Amazon (PAID LINK): https://geni.us/nBJHqE
On Newegg (PAID LINK): https://geni.us/qtXBCMa

Buy Intel X540-T1 10G NIC 
On Amazon (PAID LINK): https://geni.us/n9AG
On Newegg (PAID LINK): https://geni.us/Gd03

Buy Lsi Logic 9201-16i 16port 6gb/S 
On Ebay: https://lmg.gg/KlY3B
On Amazon (PAID LINK): https://geni.us/VnBQ
On Newegg (PAID LINK): https://geni.us/B0VTIE

Buy SFF-8087 to 4x SATA
On Amazon (PAID LINK): https://geni.us/dzQC
On Newegg (PAID LINK): https://geni.us/SDKW

Buy Seagate IronWolf Pro 16TB
On Amazon (PAID LINK): https://geni.us/9fQM
On Newegg (PAID LINK): https://geni.us/QdRuZk

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://lmg.gg/qkG5g

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Get your ticket to LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

## UNFIXABLE Intel CPU Flaw - WAN Show Mar 6, 2020
 - [https://www.youtube.com/watch?v=0Ml6T6F5Dec](https://www.youtube.com/watch?v=0Ml6T6F5Dec)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-03-06 00:00:00+00:00

Visit https://www.squarespace.com/WAN to try it free for 14 days free and use offer code WAN for 10% off

Save 15% today with offer code LTT on Displate at https://lmg.gg/displatewan

Sign up for Private Internet Access VPN at https://lmg.gg/piawan

Buy LTX 2020 Presented by Intel Tickets: https://lmg.gg/ltx20tickets
Learn more about LTX 2020: https://www.ltxexpo.com/
LTX 2020 Activities: https://www.ltxexpo.com/attractions
LTX 2020 Special Guests: https://www.ltxexpo.com/guests

Buy an LTT shirt, hoodie, hat, and even our own water bottle at https://lmg.gg/wanlttstore

Check out Carpool Critics, our new movie podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Timestamps: http://traffic.libsyn.com/linustechtips/UNFIXABLE_Intel_CPU_Flaw_-_WAN_Show_Mar_6_2020.mp3

Podcast Download: (Courtesy of Lloyd Dunamis)

01:14 INTRO
01:56 Intel Chip - "Completely Unpatchable" Security Flaw
05:07     "Requires physical interaction; Not a cause for concern"
08:14     Comparison to other security flaws
08:54 E-Commerce Firms Could Start to be Responsible for Counterfeits
09:42     Linus's eBay Consumer Protection experience
11:43     Wish experience - Engineering put on fake cards
14:36     Superchat assistance on Wish refunds experience
16:06 Kickstarter Backing Check - Luke's Backing: Colebar Hammer
19:34     Luke's other backs
21:59     Linus's backs (through work)
25:14     Terada's Star Citizen Video Montages  https://www.youtube.com/channel/UCalnBKLnFmYjrnHWQKR2s1A
27:44     More about Colebar Hammer
30:01 Back to topic: (E-Commerce Firms) Being responsible for counterfeits
30:59     Fake Goods Market
33:13 LTTStore.com Lower Shipping Rates + Sticker Sheets
35:00     Sticker Sheets showing (volume up for sticker details being told by Nick away from the mic)
36:30     Team FPS Talk: TF2 and Overwatch
    41:50 SPONSORS
    41:53 Squarespace
    42:48 Displate
    43:54 PIA - Private Internet Access
45:19 Canadian Gov't Threatens The Big 3 Telecoms to Cut Cellular Prices by 25%
48:46     To piggyback competitor telecoms...
50:43 Google Education Software Spies on Children via Free Chromebooks
51:54 LTX - Regarding COVID-19/Novel Coronavirus Outbreak
54:27 AMD Roadmap Through 2022
55:44 SUPACHATS
55:59     Special Physical Superchat from Yosef
57:36     Letter reading
1:01:58     Softlaunch LTT Network Minecraft server
1:03:22     "Geodude (Luke's PC) is amazing"
1:06:30     RealFakeTshirts(.)com redirect
1:07:50 END, no outro
= BONUS / EXTRA =  
07:40 "Platform"
13:58 Luke pounding drums (for Secret Shopper)
43:57 Pirate Internet Access

