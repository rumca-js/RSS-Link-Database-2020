# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## I felt the rain hit my body in VR with this haptic suit
 - [https://www.youtube.com/watch?v=j1xnWx3N5o0](https://www.youtube.com/watch?v=j1xnWx3N5o0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-03-06 00:00:00+00:00

Welcome to VIRTUALLY ODD!
Today I'm talking a look at a Haptics kit from Bhaptics that allows me to FEEL the game. This led to one of the most incredible feelings I have ever had in a VR game or... game in general for that matter. I try out a bunch of games but Skyrim VR and VRChat really left me with some real impressions. 

Join my discord for good times
https://discord.gg/thrill
MY STREAM: 
https://www.twitch.tv/thrilluwu
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill

Kit:
https://www.bhaptics.com/

VRchat tools:
https://www.pixiv.net/fanbox/creator/5179544/post/371411

