# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## The Way Back - Movie Review
 - [https://www.youtube.com/watch?v=66-WwcRtcDU](https://www.youtube.com/watch?v=66-WwcRtcDU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-03-07 00:00:00+00:00

Ben Affleck stars in the story of a man who might just find his path while coaching a high school basketball team. Here's my review for THE WAY BACK!

