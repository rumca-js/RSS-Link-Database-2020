# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Andrew Santino: Bert Kreischer Looks Like Florida If it Was a Person
 - [https://www.youtube.com/watch?v=L7lIU0vh70o](https://www.youtube.com/watch?v=L7lIU0vh70o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-06 00:00:00+00:00

Taken from JRE #1438 w/Andrew Santino: https://youtu.be/eDzGRT06er0

## Does Running Really Ruin Your Knees?
 - [https://www.youtube.com/watch?v=HxPzll6J7YU](https://www.youtube.com/watch?v=HxPzll6J7YU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-06 00:00:00+00:00

Taken from JRE #1438 w/Andrew Santino: https://youtu.be/eDzGRT06er0

## How Andrew Santino Got Busted for Public Exposure
 - [https://www.youtube.com/watch?v=GcJjQF5NE0o](https://www.youtube.com/watch?v=GcJjQF5NE0o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-06 00:00:00+00:00

Taken from JRE #1438 w/Andrew Santino: https://youtu.be/eDzGRT06er0

## How Did a Photo of Tennis Shoes “Denigrate” Ferrari’s Brand?
 - [https://www.youtube.com/watch?v=mTUyilFkDQk](https://www.youtube.com/watch?v=mTUyilFkDQk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-06 00:00:00+00:00

Taken from JRE #1438 w/Andrew Santino: https://youtu.be/eDzGRT06er0

## Joe Rogan Details His Martial Arts Background
 - [https://www.youtube.com/watch?v=lrarNr3JWRg](https://www.youtube.com/watch?v=lrarNr3JWRg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-06 00:00:00+00:00

Taken from JRE #1438 w/Andrew Santino:
https://youtu.be/eDzGRT06er0

## Joe Rogan Imagines Anti-Aging Medicine Gone Wrong
 - [https://www.youtube.com/watch?v=1Zt4agbW5D0](https://www.youtube.com/watch?v=1Zt4agbW5D0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-06 00:00:00+00:00

Taken from JRE #1438 w/Andrew Santino: https://youtu.be/eDzGRT06er0

## Joe Rogan Reacts to Ankalaev vs. Cutelaba Stoppage
 - [https://www.youtube.com/watch?v=YQlhm9xsG3k](https://www.youtube.com/watch?v=YQlhm9xsG3k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-06 00:00:00+00:00

Taken from JRE #1438 w/Andrew Santino: https://youtu.be/eDzGRT06er0

## Joe Rogan Reacts to Joe Biden Gaffes w/Andrew Santino
 - [https://www.youtube.com/watch?v=mhhXF6EOtoM](https://www.youtube.com/watch?v=mhhXF6EOtoM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-06 00:00:00+00:00

Taken from JRE #1438 w/Andrew Santino:
https://youtu.be/eDzGRT06er0

## Joe Rogan and Andrew Santino Watch Oprah Falling Video
 - [https://www.youtube.com/watch?v=EAdETHrrli4](https://www.youtube.com/watch?v=EAdETHrrli4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-03-06 00:00:00+00:00

Taken from JRE #1438 w/Andrew Santino: https://youtu.be/eDzGRT06er0

