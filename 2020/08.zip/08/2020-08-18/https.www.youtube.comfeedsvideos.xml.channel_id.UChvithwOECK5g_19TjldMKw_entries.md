# Source:Laowhy86, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw, language:en-US

## Is China Scared of the Belarus Revolution?
 - [https://www.youtube.com/watch?v=6kS8SoVy9Uo](https://www.youtube.com/watch?v=6kS8SoVy9Uo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw
 - date published: 2020-08-19 00:00:00+00:00

The Cha Bu Duo and Wu Mao shirts are back! - Get them for a limited time only - https://everpress.com/laowhy86-black
https://everpress.com/wu-mao

China finally reported on the Belarus situation. The Chinese government ended up supporting Lukashenko. Here's why.

◘ Support me on Patreon for early release, and much more! http://www.patreon.com/laowhy86
◘ Or, if you prefer, Subscribestar - https://www.subscribestar.com/laowhy86

Car channel - https://www.youtube.com/worthlesswhips
ADVChina - https://www.youtube.com/advchina
SerpentZA - https://www.youtube.com/serpentza
ADVPodcasts - https://www.youtube.com/advpodcasts

Some of the footage used -
Graz and Beyond - https://www.youtube.com/channel/UCo6Q2-oVQCOj3oPCQ4cGVSw
byg channel - https://www.youtube.com/channel/UCiH29d5F4_8Ildue4kkcK8g
Belarus in 4k - https://www.youtube.com/channel/UCM8aeWt7m8uB857tNpo3AVA

◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

◘ OR Become a Sponsor on YouTube:
https://www.youtube.com/channel/UChvithwOECK5g_19TjldMKw/sponsor

◘ My TV show: Conquering Northern China:
https://vimeo.com/ondemand/conqueringnorthernchina

◘ Conquering Southern China
https://vimeo.com/ondemand/conqueringsouthernchina

◘ Discount code for both shows: laowinning

◘ Join me every week for videos about China! Don't forget to subscribe!
http://www.youtube.com/laowhy86

Be a Laowinner!
Like comment subscribe!

◘ Facebook:
http://www.facebook.com/laowhy86

◘ Instagram: 
http://instagram.com/laowhy86

◘ Music used most of the time - New World Hip Hop
https://soundcloud.com/apollodrivenz
https://www.youtube.com/channel/UCgirAE5d8ufiotRXmBZZbBQ

