# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## serpentwithfeet (live on kexp at home)
 - [https://www.youtube.com/watch?v=6KmDC2nWVdw](https://www.youtube.com/watch?v=6KmDC2nWVdw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-08-18 00:00:00+00:00

serpentwithfeet shares an exclusive set of songs from the Apparition EP, performed with co-producer Wynne Bennett, and joins Larry Mizell Jr. live from home on KEXP on Tuesday, August 18, at 12pm PT.

