# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Phil Johnson From John MacArthur’s Church Defends Gathering In Defiance Of CA Government
 - [https://www.youtube.com/watch?v=Rl9fcuVfoXk](https://www.youtube.com/watch?v=Rl9fcuVfoXk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-08-19 00:00:00+00:00

Phil Johnson of Grace To You guests on this week’s episode of the Babylon Bee and he gives us the run down of why Grace Community Church has decided to defy California Governor Newsom and the County of Los Angeles by opening their church for worship.

FULL ▶️  https://youtu.be/oEkOSFM0gUU

## Phil Johnson Talks Grace Community Church's 'Peaceful Protest'/Wokeness/John MacArthur's Emoji Game
 - [https://www.youtube.com/watch?v=oEkOSFM0gUU](https://www.youtube.com/watch?v=oEkOSFM0gUU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-08-18 00:00:00+00:00

In this episode, Kyle and Ethan talk to Phil Johnson who is the executive director of Grace to You. He has been closely associated with John MacArthur since 1981 and edits most of Pastor MacArthur’s major books. Phil also founded several popular websites, including The Spurgeon Archive, The Hall of Church History, and the Pyromaniacs blog. He is an ordained elder and pastor at Grace Community Church, which is in the news recently for its decision to meet on the Lord’s Day for worship in defiance of California orders to socially distance. 

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Gain Access to the Exclusive Content and Writing Forum: https://babylonbee.com/plans

The Official Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

