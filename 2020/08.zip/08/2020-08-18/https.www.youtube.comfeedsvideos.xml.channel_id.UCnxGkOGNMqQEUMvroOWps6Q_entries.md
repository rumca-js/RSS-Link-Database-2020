# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## David Blaine Freaks Joe Rogan Out With Crazy Ice Pick Trick
 - [https://www.youtube.com/watch?v=fZpt0lBq9co](https://www.youtube.com/watch?v=fZpt0lBq9co)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-08-18 00:00:00+00:00

Taken from JRE #1527 w/David Blaine: https://youtu.be/NY3Zg37nIHo

## David Blaine Regurgitates a Live Frog on the Joe Rogan Experience
 - [https://www.youtube.com/watch?v=wyLhUHJZYvo](https://www.youtube.com/watch?v=wyLhUHJZYvo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-08-18 00:00:00+00:00

Taken from JRE #1527 w/David Blaine: https://youtu.be/NY3Zg37nIHo

## David Blaine Started Hallucinating During His "Frozen in Time" Stunt
 - [https://www.youtube.com/watch?v=C4LraPdm5YI](https://www.youtube.com/watch?v=C4LraPdm5YI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-08-18 00:00:00+00:00

Taken from JRE #1527 w/David Blaine:
https://youtu.be/NY3Zg37nIHo

## David Blaine is Lucky with Dice
 - [https://www.youtube.com/watch?v=UhV3uDea0aE](https://www.youtube.com/watch?v=UhV3uDea0aE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-08-18 00:00:00+00:00

Taken from JRE #1527 w/David Blaine:
https://youtu.be/NY3Zg37nIHo

## Why David Blaine Learned to Hold His Breath for 17 Minutes
 - [https://www.youtube.com/watch?v=GjB0Dqoqbb8](https://www.youtube.com/watch?v=GjB0Dqoqbb8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-08-18 00:00:00+00:00

Taken from JRE #1527 w/David Blaine:
https://youtu.be/NY3Zg37nIHo

