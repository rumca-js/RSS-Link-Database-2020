# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Louis teaches a lesson on the universality of law & order.
 - [https://www.youtube.com/watch?v=p3v31w0xqSg](https://www.youtube.com/watch?v=p3v31w0xqSg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-08-18 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
Region 7 - Lenexa, Kansas EPA’s website:
        If you think you’ve witnessed an environmental crime in Iowa, Kansas, Missouri or Nebraska: Call 913-551-7999 or send an email to r7cidtips@epa.gov to report it to the EPA Region 7 Criminal Investigation Division.
    Attn:     Lisa Hanlon, Compliance Officer
U.S. EPA Region 7
11201 Renner Boulevard
Lenexa, Kansas 66219
      c. EPA Region 7 Phone number: 1 (800) 223-0425
👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

