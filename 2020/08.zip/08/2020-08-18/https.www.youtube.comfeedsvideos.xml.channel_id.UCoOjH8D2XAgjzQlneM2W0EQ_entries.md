# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## How the Rich & Powerful Hide Their Money
 - [https://www.youtube.com/watch?v=ZGfZ7pWF0lE](https://www.youtube.com/watch?v=ZGfZ7pWF0lE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2020-08-19 00:00:00+00:00

📈 Join the Trends Community today. Get your first two weeks for just ONE dollar. Go to https://trends.co/jake to get started.

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join 

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
📸 Follow me on IG:@jaketran // http://bit.ly/jt-ig
👨👦👦 Join the Tran Mafia Family here: https://bit.ly/patreon-jt
💬 Join the community Discord: http://discord.gg/BmK8EnQ

Stuff I use & recommend:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
🏠 The real estate investing course I love & recommend: https://jake.yt/RE
🌐 Most flexible, affordable website hosting: https://jake.yt/bhd
🖥️ Website platform I use & love: https://jake.yt/kd
💽 Editing software I've used for 7+ years: https://jake.yt/ccd
📒 Online bookkeeping software I use& love: https://jake.yt/benchd 
🧾 Best affordable bookkeeping software: https://jake.yt/fbd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd
📚 Get 3 free audiobooks for life: https://amzn.to/2v58PSu
🎥 My video gear, setup, tech, books: https://jake.yt/stored

✉️ Email me: jake@jaketran.io

Subscribe to the backup channel on LBRY, use reward code "jake-cast" for free coin: https://bit.ly/LBRY-jt

📰 Sources & visuals: 

-----------------------
You’ve done pretty well for yourself and your family. But ironically, the world you enriched thinks that you should be punished the most! That you should pay your “fair share” with their greedy “progressive” tax system.

Not paying taxes is a puzzle. When you operate a business that is registered in the majority of modern countries like the US, you’re legally required to have your name on the business in one way or another. The key is getting your name off of the business, off of any paperwork, and to make sure that even if the US really wanted to with a warrant, they can never find out who actually owns the business. 

Shell companies are official companies that you can open and control, but it can’t be traced back to you. This way, you can open up a shell company, move your money through it, and since your name isn’t attached to the shell company, tax collectors won’t be able to charge you. The problem is that there is no way in hell the countries like the US would allow full-blown shell companies to be created.

Tax Havens are usually small countries that don’t really have much going for them, so they offer an extremely enticing business environment to attract foreign businesses to work with them and collect fees. There are four main qualifiers that a country is a tax haven 1. The country has little or no taxes. 2. They have very convenient financial products and incentives 3. The financial activities of the country lack transparency And lastly, the country doesn’t cooperate with other countries to give away their clients' identities. Once you have a tax haven in mind, it’s time to start your shell company.

You’re gonna choose a company in that tax haven that offers these financial services for sale. You can either buy a brand new shell company, or they’ll have existing ones that have a history of transactions already to make it look more legitimate. Once you purchase a shell, you're gonna have to determine Who’s gonna be the shareholder of the company, choose the directors and open up a bank account under your new anonymous shell company. Now it’s time to put your tax haven to work.

Our goal is to not pay taxes and move the money offshore into our Shell, so it can’t be taxed. Then, you have to eventually get the money back home. If authorities smell any potential wrongdoing, these are the things they’re gonna investigate: how you entered the offshore world, how you got your money offshore, and how you got it back to shore.

-----------------------

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2020 Jake Tran. All rights reserved.

DISCLAIMER: These videos are for entertainment purposes only. This is not meant to be financial advice. Please always do your due diligence and never stop learning.

AFFILIATE DISCLOSURE: Some of the links in this video description are affiliate links, meaning, at no additional cost to you, I may earn a commission if you click through and make a purchase and/or opt-in. I only promote products that I 100% believe in.

