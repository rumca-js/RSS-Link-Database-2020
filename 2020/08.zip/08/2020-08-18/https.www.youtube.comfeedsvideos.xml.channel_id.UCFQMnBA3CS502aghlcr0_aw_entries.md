# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## The HIDDEN Agenda Behind Plandemic Indoctorination
 - [https://www.youtube.com/watch?v=H91Asd5t0zs](https://www.youtube.com/watch?v=H91Asd5t0zs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-08-19 00:00:00+00:00

So Brian Rose has gone even further down the rabbit hole, now pushing Plandemic.

London Real is a company that allegedly wants to build a TRIBE: "Join a community of high-achievers on a mission to transform themselves and the world!"
But what are they after really? Since Brian Rose loves "tracing the money", what is Plandemic2 actually doing? Where are they getting their funding, and their money? 
A quick look at the sale at the end of the video might tell us, Brian Rose offers many ways to buy his courses...
London Real Academy: BUSINESS ACCELERATOR: LIFE ACCELERATOR: BROADCAST YOURSELF: SPEAK TO INSPIRE:
#londonreal #coffeezilla #plandemic2

## The Worst Lawyer in the World
 - [https://www.youtube.com/watch?v=WH8WtrIef78](https://www.youtube.com/watch?v=WH8WtrIef78)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-08-18 00:00:00+00:00

ADA Abuse is real but it's also hard to talk about without dealing with some weird issues. I discuss my challenges with two people, Jocelyn, a disabled person from Canada who thinks deeply about disability issues and Phil Stillman, the lawyer representing small businesses being sued by Peter Strojnik. 

Also, go check out Jocelyn's channel!
https://www.youtube.com/channel/UC9y3S192IixJQr0aPBxy5_w

