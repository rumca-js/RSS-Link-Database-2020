# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Galaxy Note 20 Ultra Review: It Better Be Good!
 - [https://www.youtube.com/watch?v=R94ntpWVelw](https://www.youtube.com/watch?v=R94ntpWVelw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-08-18 00:00:00+00:00

Note 20 Ultra starts at $1299. Key word Ultra.
Galaxy Note 20 Ultra (Mystic Bronze): https://amzn.to/34eW1bB
dbrand Grip for Note 20 Ultra: https://dbrand.com/ultra

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Jordyn Edmonds http://smarturl.it/jordynedmonds
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by Samsung for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

