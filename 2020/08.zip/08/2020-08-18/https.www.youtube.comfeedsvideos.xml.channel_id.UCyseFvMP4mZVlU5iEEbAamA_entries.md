# Source:Salvatore Ganacci, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyseFvMP4mZVlU5iEEbAamA, language:en-US

## Salvatore & Ganacci
 - [https://www.youtube.com/watch?v=scqKIsRLILo](https://www.youtube.com/watch?v=scqKIsRLILo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyseFvMP4mZVlU5iEEbAamA
 - date published: 2020-08-19 00:00:00+00:00

Follow Salvatore:
https://www.instagram.com/salvatoreganacci

Directed by Vedran Rupic, Produced by Business Club Royale

Credits
Director: Vedran Rupic
Producer: Christian Kuosmanen & Sia Masoodian
Creative producer: Gustav Sundström
DOP: Lionel Cabrera

Starring: 
Miodrag Stojanovic
Victor von  Schirach
Marianne Skoglund

#salvatoreganacci

