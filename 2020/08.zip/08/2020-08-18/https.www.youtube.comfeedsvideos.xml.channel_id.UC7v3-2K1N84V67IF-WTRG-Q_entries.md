# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Spider-Man - Movie Review
 - [https://www.youtube.com/watch?v=Ru8ZahJ9BUE](https://www.youtube.com/watch?v=Ru8ZahJ9BUE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-08-18 00:00:00+00:00

In 2002, Sam Raimi's SPIDER-MAN hit theaters with a bang! Does it hold up today? Here's my review!

Watch the teaser trailer here: https://youtu.be/Ozz8uxW733Q

#SpiderMan

