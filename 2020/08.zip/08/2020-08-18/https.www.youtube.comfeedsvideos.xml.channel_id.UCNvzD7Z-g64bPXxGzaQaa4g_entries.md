# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 13 PRO Gamers Who Were Caught Cheating
 - [https://www.youtube.com/watch?v=uJFrKAie1oM](https://www.youtube.com/watch?v=uJFrKAie1oM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-08-19 00:00:00+00:00

Sometimes even the pros get caught cheating. Here are some examples of cheating in the competitive gaming scenes.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Sources:

https://nypost.com/2019/01/11/dozen-of-professional-gamers-caught-cheating-in-a-bid-to-win-2m-prize/

https://www.espn.in/esports/story/_/id/29505007/aspiring-valorant-pro-phox-banned-cheating

https://kotaku.com/top-counter-strike-players-caught-in-big-cheating-scand-1662810816

https://www.dexerto.com/apex-legends/apex-legends-pro-player-dropped-after-getting-caught-cheating-stream-402975

https://kotaku.com/fortnite-winner-caught-cheating-stripped-of-prize-mone-1843689493

https://www.polygon.com/2018/10/21/18006358/counter-strike-esports-cheating-shanghai-video

https://gamerant.com/overwatch-streamer-banned-live/

https://www.bbc.com/news/technology-36131238

https://www.invenglobal.com/articles/6395/chinese-taipei-disqualified-from-hearthstone-global-games-for-cheating

https://www.sk-gaming.com/content/57027-azubu-frost-fined-30-000-for-cheating

https://www.vg247.com/2020/05/26/formula-e-driver-fired-hiring-pro-gamer-race-for-him/

https://www.pcgamer.com/csgo-player-flex-banned-during-esea-league-livestream/

https://www.polygon.com/2019/4/16/18410888/fortnite-pro-cheats-team-kaliber

## Microsoft Flight Simulator - Before You Buy
 - [https://www.youtube.com/watch?v=O_sK_sc5GYs](https://www.youtube.com/watch?v=O_sK_sc5GYs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-08-18 00:00:00+00:00

Microsoft Flight Simulator (Windows, Steam) marks the return of the famous historic aircraft simulation game. Does it truly feel like the next generation? Let's talk.
Subscribe for more: http://youtube.com/gameranxtv ▼▼


Buy Flight Simulator: https://amzn.to/3aJdla4



Watch more 'Before You Buy': https://bit.ly/2kfdxI6

