# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Can they win me back?? - LG Gram 2020 Lineup Showcase
 - [https://www.youtube.com/watch?v=bhq3AzEXLm0](https://www.youtube.com/watch?v=bhq3AzEXLm0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-08-19 00:00:00+00:00

Thanks to LG for sponsoring today's video! Check out the LG Grams at https://bit.ly/3ggixU5
17”: https://bit.ly/31XEO3K
15”: https://bit.ly/3axSZAs
14”: https://bit.ly/3iSHVAG
2in1: https://bit.ly/2EaT1Cj

LG Grams are known for their lightness, but I didn't pick it when I was deciding on my last laptop since it didn't have Thunderbolt 3. The 2020 line-up does so let's take a look at which one I would be interested in checking out. 

Buy Dell XPS 13 2-in-1
On Amazon (PAID LINK): https://geni.us/thFEX
On Newegg (PAID LINK): https://geni.us/Bsgtv    
On B&H (PAID LINK): https://geni.us/sURuMN 
On Best Buy (PAID LINK): https://geni.us/wrzjLIq

Buy Razer 4K Stealth
On Amazon (PAID LINK): https://geni.us/b7Fz
On Newegg (PAID LINK): https://geni.us/4XBWrA    
On B&H (PAID LINK): https://geni.us/59VKztB  
On Best Buy (PAID LINK): https://geni.us/BoM0

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1236337-can-they-win-me-back-sponsored/

GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Mech Keyboard: https://geni.us/RecNBTI
Nerd or Die Stream Overlays & Templates: https://geni.us/s8hBAgR
NEEDforSEAT Gaming Chairs: https://geni.us/needforseat
Get a Displate Metal Print at https://lmg.gg/displateltt
Use code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Gear on Amazon: https://www.amazon.com/shop/linustechtips
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0 https://lmg.gg/fxHYK 
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://lmg.gg/Q9yyQ 
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://lmg.gg/8upii

## This $10,000 laptop ISN'T overpriced...
 - [https://www.youtube.com/watch?v=-TWj-biXpLo](https://www.youtube.com/watch?v=-TWj-biXpLo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-08-18 00:00:00+00:00

*Free 32GB Flash Drive & 32GB Micro SD Card: https://rebrand.ly/gy7m39z
Get the best prices and best selection at Micro Center: https://rebrand.ly/twi95lc
Join the Micro Center Community: https://rebrand.ly/rw1lcli
Micro Center Custom PC Builder: https://rebrand.ly/uw4g7lf

*Limited Time Offer, Valid In-store only, Limit 1 Coupon Per Customer

Get iFixit's Marlin Screwdriver set today at https://www.ifixit.com/linus

What do you get when you flip convention on it’s head? Well, you get the Asus Studiobook One - one of the most powerful laptops we’ve reviewed EVER.

Buy: ASUS ProArt StudioBook One
On B&H (PAID LINK): https://geni.us/BPXvB

Buy Dell XPS 17
On Amazon (PAID LINK): https://geni.us/fa4BYI3
On Newegg (PAID LINK): https://geni.us/nVM1A

Buy Alienware A51M
On Amazon (PAID LINK): https://geni.us/dPxv5

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1235883-this-10000-laptop-isnt-overpriced-asus-studiobook-one/


GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Mech Keyboard: https://geni.us/RecNBTI
Nerd or Die Stream Overlays & Templates: https://geni.us/s8hBAgR
NEEDforSEAT Gaming Chairs: https://geni.us/needforseat
Get a Displate Metal Print at https://lmg.gg/displateltt
Use code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Gear on Amazon: https://www.amazon.com/shop/linustechtips
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0 https://lmg.gg/fxHYK 
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://lmg.gg/Q9yyQ 
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://lmg.gg/8upii

