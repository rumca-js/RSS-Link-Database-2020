# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## NEW Sony VR headset may bring the competition we all need
 - [https://www.youtube.com/watch?v=PnozVxhHV7M](https://www.youtube.com/watch?v=PnozVxhHV7M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-08-18 00:00:00+00:00

Hello and Welcome to, TUESDAY NEWSDAY! Your number one resource for the entire weeks worth of VR news. Today I will talk about Sony's new VR headset that they have confirmed they are currently working on. This is more than likely NOT a playstation VR headset and is likely a headset to compete closely with something like the Oculus Quest. I have certain hopes and dreams for what it is though. I also talk about some Pokemon VR, new hilarious apple VR patents, and more. Hope you enjoy!

My links-
Twitch Stream TODAY!
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL

TIMESTAMPS:
00:00 intro
00:43 Official POKEMON VR Event
01:44 New Sony Headset background
05:10 What I think this means/ What I want
06:32 This makes me so sad
07:00 Hilarious Apple VR patents
09:28 Apple VR Car
10:32 Facebook Horizons news
11:40 Question of the Week
13:00 TWITCH STREAM TODAY!

Sources today-

POKEMON VR- https://pokemon2020.cluster.mu/


https://appleinsider.com/articles/20/08/13/apple-car-may-control-how-doors-move-offer-motion-sickness-free-vr
https://appleinsider.com/articles/20/08/17/epic-games-appears-to-out-apple-vr-development-in-fortnite-dispute
https://appleinsider.com/articles/20/08/13/apple-developing-system-to-keep-vr-users-from-bumping-into-real-world-objects

https://uploadvr.com/sony-next-generation-vr-headset/
https://uploadvr.com/apple-vr-boundary-system/
https://www.tomsguide.com/news/psvr-2-for-ps5-sony-is-working-on-a-new-vr-headset

https://uploadvr.com/oculus-venues-revamp/
https://pokemon2020.cluster.mu/
https://uploadvr.com/pokemon-virtual-fest-vr/

