# Source:Roosevelt, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqqY6fzyLY3OmdjYRe2eJAg, language:en-US

## Roosevelt - Echoes (Official Audio)
 - [https://www.youtube.com/watch?v=KdqlenFrH58](https://www.youtube.com/watch?v=KdqlenFrH58)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqqY6fzyLY3OmdjYRe2eJAg
 - date published: 2020-08-18 00:00:00+00:00

'POLYDANS' - my new album - out now! Stream / Purchase here: https://roosevelt.lnk.to/Polydans

FOLLOW Roosevelt on Facebook, Instagram and more https://roosevelt.lnk.to/follow
Website : https://roosevelt.lnk.to/website 

This is the Official Youtube Channel for Roosevelt. 
SUBSCRIBE NOW to be kept up to date with the latest music, videos, tour dates, behind the scenes footage and more https://roosevelt.lnk.to/subscribe

MUSIC CREDITS
Written, Performed, Recorded and Produced by Marius Lauber 
Mastered by Heba Kadry 


LYRICS

i'm running away
with you on my mind
yeah i need to get out of this
out of your sight

you're beginning to play
your tricks on my mind
can we find a way out of this 
got to win the fight

oohh aahh
when time has no meaning
lost in a feeling
where do we go from here

oohh aahh
where's your devotion
strangest emotion
you made it reappear

i still hear the echoes
feels like we're slipping away
but maybe tonight we can
leave the past behind

i still hear the echoes
feels like we're slipping away
yeah maybe tonight we can
leave it all behind

i remember a time
with you by my side
bringing back all the memory
start to fall apart

committed a crime
as dark as the night
you know you were the remedy
to my broken heart

oohh aahh
when time has no meaning
lost in a feeling
where do we go from here

oohh aahh
where's your devotion
strangest emotion
you made it reappear

i still hear the echoes
feels like we're slipping away
but maybe tonight we can
leave the past behind

i still hear the echoes
feels like we're slipping away
yeah maybe tonight we can
leave it all behind

in the haze of the sun
don't fall behind
let's make this right
back to where it begun
cause in these golden lights
we'll come alive (x2)

℗ & © Greco-Roman / City Slang             

#Roosevelt #Echoes #OfficialAudio

