# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Czy bezpiecznie jest pić wodę z kranu?
 - [https://www.youtube.com/watch?v=b1uMurqcc3Q](https://www.youtube.com/watch?v=b1uMurqcc3Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2020-08-19 00:00:00+00:00

Podziękowania dla ► https://www.warszawskakranowka.pl 
Patronite ► https://patronite.pl/NaukowyBelkot 
Moja książka ► https://geny.altenberg.pl
Mix audio ► http://ratstudios.pl/

Są pytania mało ważne, umiarkowanie ważne, ważne, bardzo ważne i takie, które do końca nie wiemy jak ważne są. Jednym z nich jest pytanie o to, czy powinniśmy pić wodę z kranu, która (co prawda) jest 2-3 tysiące razy tańsza od tej butelkowanej... ale przecież pochodzi z sieci wodociągowej... a ona jest w ziemi i tam są rury... i pobiera się ją z rzek... no musi być coś z nią nie tak... prawda? Odpowiedź w filmie.

Subskrypcja ► https://youtube.com/c/UwagaNaukowyBelkot
Facebook ► https://facebook.com/UwagaNaukowyBelkot
Twitter ► https://twitter.com/NaukowyBelkot
Instagram ► https://www.instagram.com/NaukowyBelkot/

===
Timestamp:
0:00 Dylemat spragnionego
2:27 Na początek - odpowiedź
5:05 Walka z koloidami
9:40 Filtr, ozon, filtr i filtr
15:15 To co? Chlor?

Wyłącznie Naukowy Bełkot ► https://goo.gl/Do7VCc
Grupa na facebooku ► https://goo.gl/HP8J83

===
Źródła (wybrane):

Odcinek powstał we współpracy z ekspertami warszawskich Filtrów oraz w oparciu o 12 lat spędzonych na studiowaniu chemii na lubelskim UMCS - wskazanie konkretnych prac jest więc trudne...

https://clark.com/deals-money-saving-advice/pepsi-aquafina-tap-water-best-bottled-waters/

