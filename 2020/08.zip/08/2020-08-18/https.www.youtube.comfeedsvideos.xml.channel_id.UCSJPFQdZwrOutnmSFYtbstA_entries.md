# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Demolition Man - Life Simulator 2020 Edition
 - [https://www.youtube.com/watch?v=FiG99WmpX7c](https://www.youtube.com/watch?v=FiG99WmpX7c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-08-18 00:00:00+00:00

Greetings and salutations, citizen. Spread joy-joy feelings by watching this review of the 1993 sci-fi action classic, Demolition Man. And don't forget to obey the Verbal Morality Statute.

Want to help support this channel? 

Become a Patron: https://www.patreon.com/TheCriticalDrinker
Subscribe on Subscribestar: https://www.subscribestar.com/the-critical-drinker

