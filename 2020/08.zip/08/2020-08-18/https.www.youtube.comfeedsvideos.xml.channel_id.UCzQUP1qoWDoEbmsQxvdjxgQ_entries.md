# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Joe Rogan Experience #1527 - David Blaine
 - [https://www.youtube.com/watch?v=NY3Zg37nIHo](https://www.youtube.com/watch?v=NY3Zg37nIHo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2020-08-18 00:00:00+00:00

David Blaine is an illusionist, endurance artist, and extreme performer. He is best known for his high-profile feats of endurance and has set and broken several world records. His new special "Ascension" premieres on YouTube live on August 31. @DavidBlaine https://www.youtube.com/watch?v=QwzvNAAqH3g

