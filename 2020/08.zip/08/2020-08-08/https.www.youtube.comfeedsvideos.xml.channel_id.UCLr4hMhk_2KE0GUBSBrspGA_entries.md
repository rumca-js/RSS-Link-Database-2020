# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week w 8K? A także: Canon R5, Canon R6, Pixel 4A vs Note 20, OnePlus Buds, Google Nearby Share
 - [https://www.youtube.com/watch?v=9z_obl4TafQ](https://www.youtube.com/watch?v=9z_obl4TafQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-08-09 00:00:00+00:00

Dzisiejszy odcinek został nagrany w sumie trzema aparatami. Dawno nie było tak bogato.

Moje sociale:
Insta: http://bit.ly/InstaKlawiatur 
Twitter: http://bit.ly/TTKlawitera
FB: http://bit.ly/FBKlawiatur

Muza z filmów: https://spoti.fi/3fgBNRu

Spis treści:
00:00 Przywitanko
00:30 Nowe produkty Samsunga
01:28 OnePlus Nord
01:40 Canon R5
02:05 Pixel 4A
02:36 Pixel 4A vs Note 20
03:46 Pozostałe Pixele
04:23 Słuchawki OnePlus Bus
05:46 Trump banuje TikToka
06:36 Trump banuje WeChata
07:25 Reelsy w 50 krajach na świecie
08:25 Jak będzie w Polsce z TikTokiem?
11:11 Nowe słuchawki Sony
11:26 Canon R6
12:24 Google Nearby Share
13:14 10 lat Xiaomi
13:55 Centrum Testów
14:18 Pożegnanie

Źródła:
Nowe Pixele: https://bit.ly/31z4QKp
Trump banuje TikToka: https://cnet.co/3achQtb
TikTokowi milionerzy: https://bit.ly/33IVvCo
Nowa grupa pop z TikToka: https://bbc.in/33JjYaY
Instagramowe Reelsy: https://bit.ly/33H1E20
Zdjęcie projektu, nad którym nikt nie pracuje: https://bit.ly/3ktbxGv
Ministerstwo dementuje: https://bit.ly/3gVjbYh
Wywiad z Edwardem Snowdenem: https://bit.ly/30GhOql
Nowe słuchawki Sony: https://bit.ly/2XIR3j8
Android Nearby Share: https://bit.ly/3aece1U
10-lecie Xiaomi: https://bit.ly/3iilFQu

