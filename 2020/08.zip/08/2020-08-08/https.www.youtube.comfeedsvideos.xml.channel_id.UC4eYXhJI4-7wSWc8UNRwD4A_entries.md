# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## Lawrence Arabia: NPR Music Tiny Desk Concert From The Archives
 - [https://www.youtube.com/watch?v=yyVW_j0VjeA](https://www.youtube.com/watch?v=yyVW_j0VjeA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2020-08-09 00:00:00+00:00

We've been filming Tiny Desk concerts for more than 10 years. While revisiting our archives, we discovered that some of our earliest concerts never made it to YouTube! 
Watch Lawrence Arabia’s Tiny Desk concert from 2010: https://www.npr.org/2010/08/23/129358909/lawrence-arabia-tiny-desk-concert

Bob Boilen | August 23, 2010
If you look carefully over the shoulder of Lawrence Arabia's guitarist, you'll see the cover art to The Beatles' Abbey Road etched onto a coaster. And, though the coaster placement was random, it turned out to be apropos. After all, Lawrence Arabia, led by singer James Milne, crafts harmony parts that would have felt right at home in 1969.

Milne is from New Zealand, and his second album with Lawrence Arabia is titled Chant Darling. That record was recorded in three different countries: Milne started in Sweden by laying down drums and basic tracks at a friend's studio, and then more work was recorded in bedrooms and living rooms in London before the band returned to New Zealand for finishing touches from friends.

Lawrence Arabia's witty songs are good for more than just singing along: They provide a few chuckles, too. That comes through in the four tracks from Chant Darling that turn up in this Tiny Desk Concert at the NPR Music offices.

Set List:
"I've Smoked Too Much"
"The Beautiful Young Crew"
"Apple Pie Bed"
"Like A Fool"

