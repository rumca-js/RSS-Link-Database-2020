# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Historie potłuczone [#06] O Marysi, co ją szatan straszył
 - [https://www.youtube.com/watch?v=MM6atPd4AKw](https://www.youtube.com/watch?v=MM6atPd4AKw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-08-09 00:00:00+00:00

@Langustanapalmie   #historiepotłuczone #podcast
________________________________________
Historie potłuczone to opowieści o córkach i synach Boga, pięknych i brzydkich, świętych i grzesznych, szczęśliwych i na skraju rozpaczy. To opowieści o drodze, którą idzie się do nieba i o zakrętach i chaszczach, które spychają do piekła. To opowieści o ludziach po prostu. Czyli o nas.

Muzyka: Kai Engel: Brand New World, http://freemusicarchive.org/music/Kai_Engel/
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

♫ Słuchaj jako PODCAST Langusty: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
iTunes → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWHx

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Mocno Stronniczy [#06] Jak to się stało, że jesteśmy w zakonie?
 - [https://www.youtube.com/watch?v=8QIDu4cPcz8](https://www.youtube.com/watch?v=8QIDu4cPcz8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-08-09 00:00:00+00:00

@STREFAWODZA @Langustanapalmie 

Takich dwóch, jak Ci to nie ma :) Zapraszamy co niedzielę o godz: 10:oo na premierę zupełnie niesłychanej serii ojców Tomasza Nowaka OP i Adama Szustaka OP.
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

♫ Słuchaj jako PODCAST Langusty: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/histori...
Spotify → https://spoti.fi/2NVIRHb
iTunes → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWHx

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#193] Dlaczego Bóg nie spełnia naszych oczekiwań?
 - [https://www.youtube.com/watch?v=YpEOesWkP14](https://www.youtube.com/watch?v=YpEOesWkP14)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-08-08 00:00:00+00:00

#cnn #kazaniedookienka  @Langusta na palmie  

Kazanie XIX Niedzielę zwykłą, Rok A

1. czytanie (1 Krl 19, 9a. 11-13a)

Gdy Eliasz przyszedł do Bożej góry Horeb, wszedł do pewnej groty, gdzie przenocował. Wtedy Bóg rzekł: «Wyjdź, aby stanąć na górze wobec Pana!»

A oto Pan przechodził. Gwałtowna wichura rozwalająca góry i druzgocąca skały szła przed Panem; ale Pana nie było w wichurze. A po wichurze – trzęsienie ziemi: Pana nie było w trzęsieniu ziemi. Po trzęsieniu ziemi powstał ogień: Pana nie było w ogniu. A po tym ogniu – szmer łagodnego powiewu. Kiedy tylko Eliasz go usłyszał, zasłoniwszy twarz płaszczem, wyszedł i stanął przy wejściu do groty.

2. czytanie (Rz 9, 1-5)

Bracia: Prawdę mówię w Chrystusie, nie kłamię, potwierdza mi to moje sumienie w Duchu Świętym, że w sercu swoim odczuwam wielki smutek i nieustanny ból.

Wolałbym bowiem sam być pod klątwą, odłączonym od Chrystusa dla zbawienia braci moich, którzy według ciała są moimi rodakami. Są to Izraelici, do których należą przybrane synostwo i chwała, przymierza i nadanie Prawa, pełnienie służby Bożej i obietnice. Do nich należą praojcowie, z nich również jest Chrystus według ciała, Ten, który jest ponad wszystkim, Bóg błogosławiony na wieki. Amen.

Ewangelia (Mt 14, 22-33)

Gdy tłum został nasycony, zaraz Jezus przynaglił uczniów, żeby wsiedli do łodzi i wyprzedzili Go na drugi brzeg, zanim odprawi tłumy. Gdy to uczynił, wyszedł sam jeden na górę, aby się modlić. Wieczór zapadł, a On sam tam przebywał. Łódź zaś była już o wiele stadiów oddalona od brzegu, miotana falami, bo wiatr był przeciwny. Lecz o czwartej straży nocnej przyszedł do nich, krocząc po jeziorze. Uczniowie, zobaczywszy Go kroczącego po jeziorze, zlękli się, myśląc, że to zjawa, i ze strachu krzyknęli. Jezus zaraz przemówił do nich: «Odwagi! To Ja jestem, nie bójcie się!» Na to odezwał się Piotr: «Panie, jeśli to Ty jesteś, każ mi przyjść do siebie po wodzie!»
A On rzekł: «Przyjdź!» Piotr wyszedł z łodzi i krocząc po wodzie, podszedł do Jezusa. Lecz na widok silnego wiatru uląkł się i gdy zaczął tonąć, krzyknął: «Panie, ratuj mnie!»
Jezus natychmiast wyciągnął rękę i chwycił go, mówiąc: «Czemu zwątpiłeś, człowiecze małej wiary?» Gdy wsiedli do łodzi, wiatr się uciszył. Ci zaś, którzy byli w łodzi, upadli przed Nim, mówiąc: «Prawdziwie jesteś Synem Bożym».
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

♫ Słuchaj jako PODCAST Langusty: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
iTunes → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWHx

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#578] Dominik
 - [https://www.youtube.com/watch?v=8a6IC9SX8Xk](https://www.youtube.com/watch?v=8a6IC9SX8Xk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-08-08 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP
"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał  
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

♫ Słuchaj jako PODCAST Langusty: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
iTunes → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWHx

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

