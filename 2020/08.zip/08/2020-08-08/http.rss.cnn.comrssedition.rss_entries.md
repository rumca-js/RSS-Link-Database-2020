# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Michelle Obama and Bernie Sanders expected to speak on first night of Democratic convention
 - [https://www.cnn.com/2020/08/08/politics/michelle-obama-bernie-sanders-john-kasich-dnc/index.html](https://www.cnn.com/2020/08/08/politics/michelle-obama-bernie-sanders-john-kasich-dnc/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 23:48:22+00:00

The first night of the Democratic National Convention is currently expected to bring a message of unity featuring Vermont Sen. Bernie Sanders, former first lady Michelle Obama and former Republican Ohio Gov. John Kasich, according to a source who has seen current convention plans.

## Remains recovered from New Orleans hotel, almost 10 months after collapse
 - [https://www.cnn.com/2020/08/08/us/remains-recovered-new-orleans-hard-rock-hotel/index.html](https://www.cnn.com/2020/08/08/us/remains-recovered-new-orleans-hard-rock-hotel/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 22:52:32+00:00

The remains of a construction worker have been recovered from the collapsed Hard Rock hotel in New Orleans, Mayor LaToya Cantrell said Saturday, 10 months after the disaster.

## Brazil passes 100,000 Covid-19 deaths, as cases top 3 million
 - [https://www.cnn.com/2020/08/08/world/brazil-covid-19-deaths-intl/index.html](https://www.cnn.com/2020/08/08/world/brazil-covid-19-deaths-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 22:49:57+00:00

Brazil surpassed 100,000 deaths from Covid-19 on Saturday as cases exceeded 3 million, according to the latest numbers by the country's Health Ministry.

## Champions League: Inspired Lionel Messi lifts Barcelona into quarterfinals
 - [https://www.cnn.com/2020/08/08/football/football-champions-league-barcelona-messi-bayern-munich/index.html](https://www.cnn.com/2020/08/08/football/football-champions-league-barcelona-messi-bayern-munich/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 22:18:33+00:00

Lionel Messi scored a spellbinding goal as Barcelona beat Napoli 3-1 (4-2 on aggregate) in the Camp Nou on Saturday night to advance to the quarterfinals of the Champions League.

## Trump's battle with TikTok is so remarkable because it's happening in the 'land of the free'
 - [https://www.cnn.com/collections/intl-tiktok-0807/](https://www.cnn.com/collections/intl-tiktok-0807/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 20:38:13+00:00



## Juventus replaces sacked Maurizio Sarri with former star Andrea Pirlo
 - [https://www.cnn.com/2020/08/08/football/football-juventus-sack-sarri-ronaldo-spt-intl/index.html](https://www.cnn.com/2020/08/08/football/football-juventus-sack-sarri-ronaldo-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 20:15:20+00:00

Juventus coach Maurizio Sarri was sacked on Saturday following the Serie A club's Champions League last 16 exit to Lyon.

## Lebanon protesters storm ministries as violent protests grip Beirut
 - [https://www.cnn.com/2020/08/08/middleeast/beirut-judgment-day-protests-intl/index.html](https://www.cnn.com/2020/08/08/middleeast/beirut-judgment-day-protests-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 20:12:10+00:00

Lebanon's Prime Minister Hassan Diab has vowed to hold early elections as his beleaguered government faces calls to resign.

## Trump nonsensically accuses Democrats of election 'cheating'
 - [https://www.cnn.com/2020/08/07/politics/donald-trump-press-briefing-democrats-cheating-election-fact-check/index.html](https://www.cnn.com/2020/08/07/politics/donald-trump-press-briefing-democrats-cheating-election-fact-check/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 19:53:59+00:00



## Why Michelle Obama opening up about depression is a big deal for Black women
 - [https://www.cnn.com/2020/08/08/us/michelle-obama-depression-black-women-wellness-trnd/index.html](https://www.cnn.com/2020/08/08/us/michelle-obama-depression-black-women-wellness-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 19:43:59+00:00

Michelle Obama recently revealed that because of the pandemic and racial injustice in the US, she has been experiencing low-grade depression.

## A police dog found a missing mom and her baby during his first shift on the force
 - [https://www.cnn.com/2020/08/08/uk/police-dog-mom-baby-trnd/index.html](https://www.cnn.com/2020/08/08/uk/police-dog-mom-baby-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 18:04:01+00:00

A missing mother and her 1-year-old baby were found after a very good boy named Max discovered them on the edge of a ravine.

## Buffett's Berkshire Hathaway earnings jumped 87% as it recovers from the pandemic
 - [https://www.cnn.com/2020/08/08/business/berkshire-hathaway-warren-buffett-earnings/index.html](https://www.cnn.com/2020/08/08/business/berkshire-hathaway-warren-buffett-earnings/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 17:34:02+00:00

Berkshire Hathaway is recovering from a rough start to a year in which it was hard hit by the coronavirus. Its second quarter earnings, released Saturday morning, were up almost 87% from last year, and a big turnaround from its huge first quarter loss.

## NASA drops racially insensitive nicknames of celestial bodies
 - [https://www.cnn.com/2020/08/08/us/nasa-nicknames-eskimo-siamese-trnd/index.html](https://www.cnn.com/2020/08/08/us/nasa-nicknames-eskimo-siamese-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 16:21:44+00:00

Grocery store items, pro sports teams, and country music bands have all removed racially insensitive names.

## History professor who has accurately predicted every US presidential election since 1984 reveals 2020 pick
 - [https://www.cnn.com/2020/08/07/us/allan-lichtman-trump-biden-2020-trnd/index.html](https://www.cnn.com/2020/08/07/us/allan-lichtman-trump-biden-2020-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 15:48:11+00:00

History professor Allan Lichtman is used to being right.

## 'I don't know. Who knows?': Chinese golfer baffled by question about Trump
 - [https://www.cnn.com/2020/08/08/golf/golf-pga-haotong-trump-koepka-woods-spt-intl/index.html](https://www.cnn.com/2020/08/08/golf/golf-pga-haotong-trump-koepka-woods-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 15:31:47+00:00

Chinese golfer Haotong Li hopes to write his own unique piece of history this weekend in San Francisco.  But he's also finding it's the letters on his cap that are prompting questions about US President Donald Trump.

## Can the common cold help protect against coronavirus?
 - [https://www.cnn.com/videos/health/2020/08/08/coronavirus-cold-virus-resistance-smerconish-sot.cnn](https://www.cnn.com/videos/health/2020/08/08/coronavirus-cold-virus-resistance-smerconish-sot.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 15:22:57+00:00

Preventive medicine specialist Dr. David Katz discusses an article in the journal Nature Reviews Immunology that suggests some immune systems are resistant to COVID-19.

## Joe Arpaio loses Republican primary for sheriff to his former chief deputy
 - [https://www.cnn.com/2020/08/08/politics/joe-arpaio-loses-primary-sheriff/index.html](https://www.cnn.com/2020/08/08/politics/joe-arpaio-loses-primary-sheriff/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 14:41:23+00:00

Joe Arpaio, the former Arizona sheriff known for his controversial hardline tactics against undocumented immigrants, lost his bid to win back his former position in Maricopa County.

## The 'Lebanese Tiger' on Beirut blast: What you see on TV is nothing compared to reality
 - [https://www.cnn.com/videos/sports/2020/08/07/fadi-el-khatib-basketball-hero-lebanon-beirut-explosion-charity-spt-intl-lon-orig.cnn](https://www.cnn.com/videos/sports/2020/08/07/fadi-el-khatib-basketball-hero-lebanon-beirut-explosion-charity-spt-intl-lon-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 13:53:22+00:00

Widely regarded as the greatest ever Asian basketball player, Fadi El Khatib is weeping for Lebanon. The former pro basketball player faces ruin after the port explosion in Beirut on August 4. The father of four has lost his home and business, both shattered and damaged due to the incident.

## Dr. Sanjay Gupta answers kids' Covid-19 questions
 - [https://www.cnn.com/videos/us/2020/08/07/gupta-kids-coronavirus-questions-wellness-social-orig.cnn](https://www.cnn.com/videos/us/2020/08/07/gupta-kids-coronavirus-questions-wellness-social-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 12:59:36+00:00

CNN Chief Medical Correspondent Dr. Sanjay Gupta answers children's coronavirus questions sent from around the country.

## High-speed Cincinnati police chase kills 2 bystanders, hurts 2 more in Kentucky
 - [https://www.cnn.com/2020/08/08/us/cincinnati-police-chase-fatal-bystanders/index.html](https://www.cnn.com/2020/08/08/us/cincinnati-police-chase-fatal-bystanders/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 12:49:14+00:00

Two bystanders were killed Friday and two more injured by a suspect vehicle in a high-speed police chase, Cincinnati Police Chief Eliot Isaac said.

## Why does the US even have a vice president?
 - [https://www.cnn.com/2020/08/08/politics/what-matters-august-7/index.html](https://www.cnn.com/2020/08/08/politics/what-matters-august-7/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 12:14:24+00:00

Barack Obama had Joe Biden. Donald Trump has Mike Pence. Joe Biden will have ... somebody!

## Inside the federal prison where three out of every four inmates has coronavirus
 - [https://www.cnn.com/2020/08/08/us/federal-prison-coronavirus-outbreak-invs/index.html](https://www.cnn.com/2020/08/08/us/federal-prison-coronavirus-outbreak-invs/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 12:07:48+00:00

When James Giannetta first called his brother Russ in late June to tell him that the coronavirus was beginning to spread in his Texas federal prison, Russ could hear the fear in his voice. "This place is exploding," James warned.

## 4 children identified among Air India Express plane crash casualties
 - [https://www.cnn.com/2020/08/08/asia/air-india-express-plane-crash-kerala-intl/index.html](https://www.cnn.com/2020/08/08/asia/air-india-express-plane-crash-kerala-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 12:03:45+00:00

• Plane overshoots runway and crashes

## New video shows another Black man in custody pleading, 'I can't breathe,' before his death
 - [https://www.cnn.com/2020/08/07/us/north-carolina-detention-death-video-released-trnd/index.html](https://www.cnn.com/2020/08/07/us/north-carolina-detention-death-video-released-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 11:50:01+00:00

Video that shows a Black man in apparent medical distress repeatedly telling officers, "I can't breathe," days before he died in a hospital was released this week following a North Carolina judge's order.

## Mauritius declares a state of environmental emergency over catastrophic oil spill
 - [https://www.cnn.com/2020/08/08/world/mauritius-oil-spill-scli-intl/index.html](https://www.cnn.com/2020/08/08/world/mauritius-oil-spill-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 11:23:23+00:00



## He's been stung 1,000 times --  for science
 - [https://www.cnn.com/2020/08/08/us/king-of-sting-great-big-story-scn-trnd/index.html](https://www.cnn.com/2020/08/08/us/king-of-sting-great-big-story-scn-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 07:58:47+00:00

Justin Schmidt is in the business of pain.

## Tutankhamun's last legacy emerges near the pyramids
 - [https://www.cnn.com/travel/article/tutankhamun-grand-egyptian-museum/index.html](https://www.cnn.com/travel/article/tutankhamun-grand-egyptian-museum/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 07:47:14+00:00

For almost a century, King Tutankhamun has been the poster boy for Ancient Egypt. His death mask was sublimely, breathtakingly crafted over 3,300 years ago from 24 pounds of beaten gold, with eyeliner of lapis lazuli and eyes of quartz and obsidian.

## Trump sets a dangerous precedent for democracy
 - [https://www.cnn.com/2020/08/08/business/trump-tiktok-democracy-intl/index.html](https://www.cnn.com/2020/08/08/business/trump-tiktok-democracy-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 07:15:13+00:00

President Donald Trump's ongoing battle with TikTok is becoming one of the most curious chapters in America's emerging cold war with China. Earlier this week, Trump issued an executive order which gave the Chinese social media giant until the middle of September to find an American buyer or be banned in the country. He also issued a similar executive order for the Chinese messaging service WeChat.

## A house fire that killed two children and three adults was deliberately set, police say
 - [https://www.cnn.com/2020/08/08/us/denver-arson-fire-kills-five-relatives-trnd/index.html](https://www.cnn.com/2020/08/08/us/denver-arson-fire-kills-five-relatives-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 06:41:04+00:00

A house fire that killed three adults and two children in Denver was deliberately set by someone who fled the area, authorities said.

## Plane breaks in two in deadly Air India crash
 - [https://www.cnn.com/2020/08/07/asia/plane-crash-calicut-india-intl/index.html](https://www.cnn.com/2020/08/07/asia/plane-crash-calicut-india-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 06:28:27+00:00

An Air India Express flight has skidded off the runway while landing at Calicut International Airport, in the South Indian state of Kerala, CNN News 18 reports.

## US sanctions Hong Kong chief executive Carrie Lam
 - [https://www.cnn.com/2020/08/07/politics/us-sanctions-carrie-lam/index.html](https://www.cnn.com/2020/08/07/politics/us-sanctions-carrie-lam/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 06:25:51+00:00

The US sanctioned Hong Kong Chief Executive Carrie Lam Friday for her role in crackdowns on political freedom in the region.

## A man who was sentenced to life in prison for selling $30 of marijuana will be freed
 - [https://www.cnn.com/2020/08/08/us/man-freed-life-sentence-marijuana-trnd/index.html](https://www.cnn.com/2020/08/08/us/man-freed-life-sentence-marijuana-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 04:51:24+00:00

A military veteran serving a life sentence for selling less than $30 worth of marijuana will soon be released from prison, his attorney said.

## Jerry Falwell Jr. will take leave of absence from Liberty University
 - [https://www.cnn.com/2020/08/07/us/jerry-falwell-jr-liberty-university-leave/index.html](https://www.cnn.com/2020/08/07/us/jerry-falwell-jr-liberty-university-leave/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 04:13:31+00:00

Jerry Falwell Jr., the president of Liberty University, has agreed to take an "indefinite leave of absence," according to a statement Friday from the evangelical Christian university.

## Japan's coronavirus fatigue is fueling defiance in Tokyo
 - [https://www.cnn.com/2020/08/07/asia/tokyo-coronavirus-fatigue-intl-hnk/index.html](https://www.cnn.com/2020/08/07/asia/tokyo-coronavirus-fatigue-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 03:49:36+00:00

Ayumi Sato is trying to be careful. But she's had enough. Lockdown fatigue is setting in for Sato, a 34-year-old stock trader who lives in Tokyo, and she's not alone.

## Louis Vuitton heralds the return of the physical fashion show -- in China
 - [https://www.cnn.com/style/article/louis-vuitton-ss21-shanghai/index.html](https://www.cnn.com/style/article/louis-vuitton-ss21-shanghai/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 02:03:04+00:00

On Thursday, Louis Vuitton revealed its new menswear collection in spectacular fashion on the banks of the Huangpu River.

## Suspension dropped for teen who took photo of crowd at school
 - [https://www.cnn.com/videos/us/2020/08/08/georgia-teen-school-suspension-overturned-tuchman-pkg-ac360-vpx.cnn](https://www.cnn.com/videos/us/2020/08/08/georgia-teen-school-suspension-overturned-tuchman-pkg-ac360-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 01:48:55+00:00

The mother of a student who was suspended after posting a photo on Twitter that showed her high school's crowded hallways this week tells CNN that her daughter's suspension has been reversed.

## How to fact-check Donald Trump in realtime
 - [https://www.cnn.com/videos/politics/2020/08/08/donald-trump-realtime-fact-checking-facts-first-orig-vf.cnn](https://www.cnn.com/videos/politics/2020/08/08/donald-trump-realtime-fact-checking-facts-first-orig-vf.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 01:14:43+00:00

Two recent interviews with President Donald Trump, one on Axios on HBO and another on Fox News Sunday, provide a lesson on how to fact-check the President in realtime. CNN's Daniel Dale breaks it down.

## China 'prefers' Trump lose election as Russia works to denigrate Biden, US intel assessment says
 - [https://www.cnn.com/2020/08/07/politics/2020-election-russia-china-iran/index.html](https://www.cnn.com/2020/08/07/politics/2020-election-russia-china-iran/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 00:41:53+00:00

The US intelligence community's top election security official said in a statement Friday that China "prefers" an outcome where President Donald Trump is not reelected in November and Russia is working to denigrate former Vice President Joe Biden's White House bid.

## Anderson Cooper and Leslie Jordan look at actor's baby photos
 - [https://www.cnn.com/videos/us/2020/08/08/leslie-jordan-baby-pictures-cooper-acfc-sot-vpx.cnn](https://www.cnn.com/videos/us/2020/08/08/leslie-jordan-baby-pictures-cooper-acfc-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 00:29:09+00:00

CNN's Anderson Cooper asks actor Leslie Jordan about his baby photos that he's been posting online during quarantine. Watch Full Circle every Monday, Tuesday, and Friday at 6pm ET.

## The killers of an Indian royal have just been jailed, 35 years after the crime
 - [https://www.cnn.com/2020/08/07/asia/india-maharaja-police-sentence-intl-dst-hnk/index.html](https://www.cnn.com/2020/08/07/asia/india-maharaja-police-sentence-intl-dst-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-08 00:20:19+00:00

On a winter's day in 1985, a one-time Indian prince was killed by police in a bustling Rajasthan market.

