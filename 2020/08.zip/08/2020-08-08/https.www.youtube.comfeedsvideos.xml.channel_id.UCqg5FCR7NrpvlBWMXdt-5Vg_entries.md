# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Fall Guys (Yahtzee Is Here Too!) | Game Night
 - [https://www.youtube.com/watch?v=2PSGILB7H6Y](https://www.youtube.com/watch?v=2PSGILB7H6Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-08-09 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Tonight for Game Night we're playing Fall Guys. Yahtzee  decided to join us for some fun as well! 


Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## No, Games Shouldn’t Return to Just Black-and-White Morality | The Escapist Show
 - [https://www.youtube.com/watch?v=9Xnfe7xl_Gg](https://www.youtube.com/watch?v=9Xnfe7xl_Gg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-08-09 00:00:00+00:00

Listen to the extended cut of our conversation via the podcast on Soundcloud, iTunes, Spotify or Stitcher. https://soundcloud.com/nick-calandra-612440979/no-games-shouldnt-return-to-just-black-and-white-morality

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

This week on The Escapist Show we discuss the games we've been playing, and provide our "hot take" on the Polygon article about morality in games. https://www.polygon.com/2020/8/3/21352437/games-morality-last-of-of-us-bioshock-good-bad

0:00 - 15:22 - The games we've been playing
15:23 - 29:37 - Discussing the Polygon article about morality in games

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Ask the Creators Episode 2 | The Escapist
 - [https://www.youtube.com/watch?v=BkbMgY6qM94](https://www.youtube.com/watch?v=BkbMgY6qM94)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-08-08 00:00:00+00:00

The Ask the Creators series is a collection of videos funded by our YouTube Membership and The Escapist + members. Each month they get to submit questions for anyone on our team to answer in a new video.

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

