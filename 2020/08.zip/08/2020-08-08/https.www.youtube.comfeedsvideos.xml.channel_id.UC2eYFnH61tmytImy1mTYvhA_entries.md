# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## Fix your Terrible Hipster Distro when it Breaks (Arch/Artix)
 - [https://www.youtube.com/watch?v=-1K5vi-q9bo](https://www.youtube.com/watch?v=-1K5vi-q9bo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-08-08 00:00:00+00:00

I can't wait to tell my internet friends on R*ddit and 4gag how hard it is to use Arch Linux and how all serious people use Ubuntu because our time is just too valuable to be able to troubleshoot basic problems.

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE: https://lukesmith.xyz/donate 💰😎👌💯
OR affiliate links to things l use:
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://brave.com/luk005 Get the Brave browser.
https://lbry.tv/$/invite/@Luke View my videos on LBRY.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase.

