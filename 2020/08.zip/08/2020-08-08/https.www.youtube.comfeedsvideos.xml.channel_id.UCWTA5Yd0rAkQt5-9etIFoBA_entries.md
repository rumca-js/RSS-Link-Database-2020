# Source:SciFun, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCWTA5Yd0rAkQt5-9etIFoBA, language:pl-PL

## WIEŻA HANOI JEST ABSURDALNA
 - [https://www.youtube.com/watch?v=iG4lHkfuu8I](https://www.youtube.com/watch?v=iG4lHkfuu8I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCWTA5Yd0rAkQt5-9etIFoBA
 - date published: 2020-08-09 00:00:00+00:00

2 tygodnie riserczowania zabawki, oto co robię z życiem.

