# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I've Never Seen Anything Like This - Asetek Rad Card
 - [https://www.youtube.com/watch?v=iN-0rTwiFBQ](https://www.youtube.com/watch?v=iN-0rTwiFBQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-08-09 00:00:00+00:00

In the new Alienware Aurora R11 is a GPU cooler like we've never seen before....


Check out the Rad Card: https://www.asetek.com/gamingenthusiasts/technology-for-gamingdiy/gpu-cooling/rad-card

Check out the Alienware Aurora R11 - https://geni.us/4fdRrK2

Buy the Alienware Aurora R11
On Amazon (PAID LINK): https://geni.us/Ed3l
On Newegg (PAID LINK): https://geni.us/74sO

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1232436-ive-never-seen-anything-like-this-asetek-rad-card/

GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Mech Keyboard: https://geni.us/RecNBTI
Nerd or Die Stream Overlays & Templates: https://geni.us/s8hBAgR
NEEDforSEAT Gaming Chairs: https://geni.us/needforseat
Get a Displate Metal Print at https://lmg.gg/displateltt
Use code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Gear on Amazon: https://geni.us/lmgamazon
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0 https://lmg.gg/fxHYK 
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://lmg.gg/Q9yyQ 
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://lmg.gg/8upii

## ULTIMATE PC Tech Support Challenge - Jayztwocents vs Gamers Nexus
 - [https://www.youtube.com/watch?v=LOU9Ea60Zzc](https://www.youtube.com/watch?v=LOU9Ea60Zzc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-08-08 00:00:00+00:00

Thanks to Intel for sponsoring this Challenge! Enter our giveaway for a chance to win these PC's at https://geni.us/gcZ7
Learn more about Intel Gamer Days 2020: https://twitter.com/inteltech
Learn more about Intel® Core™ i9-10900K processors: https://geni.us/dQ4KA

Anyone can build a PC - But CAN THEY FIX ONE??? Who will come out on top in today's tech support battle between Jayztwocents and Steve from Gamers Nexus?

Shout-out to everyone who participated:
Co-Host: Austin @ https://www.youtube.com/channel/UC1IQIspOkCeV3WnYm32SBFQ
Contestant: Steve @ https://www.youtube.com/user/GamersNexus
Contestant: Jay @ https://www.youtube.com/user/Jayztwocents

Gamers Nexus Overclocking our System: https://www.youtube.com/watch?v=ZvDLt-9Q8bs

https://www.lttstore.com/ 

Buy Intel Core i7-10700K - CPU
On Amazon (PAID LINK): https://geni.us/wWu0IwW
On Newegg (PAID LINK): https://geni.us/XhxU

Buy ASUS Z490 Maximus XII Hero - Mobo
On Amazon (PAID LINK): https://geni.us/ckYb7w
On Newegg (PAID LINK): https://geni.us/caIRm

Sabrent 1TB M.2 - SSD
On Amazon (PAID LINK): https://geni.us/l10t
On Newegg (PAID LINK): https://geni.us/Y2i6PdA

EVGA RTX 2070 - GPU
On Amazon (PAID LINK): https://geni.us/PYVuB
On Newegg (PAID LINK): https://geni.us/wrB4NB

G.SKILL 16GB Trident Z RGB DDR4 - RAM
On Amazon (PAID LINK): https://geni.us/noUhQ
On Newegg (PAID LINK): https://geni.us/qVkwb

In-Win 805 - Case
On Amazon (PAID LINK): https://geni.us/CKvYi9
On Newegg (PAID LINK): https://geni.us/eW779

Seasonic Prime TX 1000 - PSU
On Amazon (PAID LINK): https://geni.us/iGPqZIB
On Newegg (PAID LINK): https://geni.us/wxnt9r9

ViewSonic XG270QG Gaming - Monitor
On Amazon (PAID LINK): https://geni.us/cX9t
On Newegg (PAID LINK): https://geni.us/yjK8

CORSAIR K95 - Keyboard
On Amazon (PAID LINK): https://geni.us/bwqDNQ
On Newegg (PAID LINK): https://geni.us/YM8XaI

CORSAIR Dark Core Pro - Mouse
On Amazon (PAID LINK): https://geni.us/Dwfp
On Newegg (PAID LINK): https://geni.us/PPxZE

CORSAIR VOID RGB ELITE - Headset
On Amazon (PAID LINK): https://geni.us/7B2Km
On Newegg (PAID LINK): https://geni.us/sjm2u

