# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Best of the Week - August 2, 2020
 - [https://www.youtube.com/watch?v=5J3ilR3jP0U](https://www.youtube.com/watch?v=5J3ilR3jP0U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-08-09 00:00:00+00:00

#1519 w/Mike Baker:
https://www.youtube.com/watch?v=yR-GXnXw2wU

#1520 w/Dr. Debra Soh:
https://www.youtube.com/watch?v=j9NeQTkJjIs

#1521 w/Josh Dubin & Jason Flom:
https://www.youtube.com/watch?v=Trh7YWo2Bmo

#1522 w/Rob Lowe:
https://www.youtube.com/watch?v=pw8dkF-jotk

## Rob Lowe Recounts Bombing at the 1989 Oscars
 - [https://www.youtube.com/watch?v=-_edyRObneQ](https://www.youtube.com/watch?v=-_edyRObneQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-08-08 00:00:00+00:00

Taken from JRE #1522 w/Rob Lowe: https://youtu.be/pw8dkF-jotk

