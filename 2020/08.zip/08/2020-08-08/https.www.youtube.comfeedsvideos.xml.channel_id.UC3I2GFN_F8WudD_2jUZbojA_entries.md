# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Ben Zaidi (Live at Refill)
 - [https://www.youtube.com/watch?v=Vm2tn92vZJk](https://www.youtube.com/watch?v=Vm2tn92vZJk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-08-09 00:00:00+00:00

Refill (http://www.refill.live) is a community-driven, live-streamed benefit concert to help raise $25,000 for the Seattle Artist Relief Fund (SARF), a Black-led community response to help provide direct financial support to artists who have been affected by COVID-19.
  
With the global pandemic extending further into the future, artists from Seattle recognized a need for renewed focus and funding to support Seattle artists through SARF. In partnership with SARF, LANGSTON, and KEXP, we present this session with Northwest artist Ben Zaidi. 

Donate through this video where 100% of your donations go directly to artists in need.
 
https://www.facebook.com/benzaidimusic
https://www.langstonseattle.org/sarf
https://www.kexp.org
http://www.refill.live

## Chicano Batman (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=adWjEdqzhbc](https://www.youtube.com/watch?v=adWjEdqzhbc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-08-08 00:00:00+00:00

LA's Chicano Batman share a set of songs recorded exclusively for KEXP and join Morgan to talk live on Thursday, August 6, at 3pm PT.

Songs:
I know It
Polymetrophonic Harmony
Moment of Joy
The Way
Color My Life

