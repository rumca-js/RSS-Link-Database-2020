# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Louis comes across a building for sale with one 3 and a half foot high catch...
 - [https://www.youtube.com/watch?v=6QGmSOzXV1s](https://www.youtube.com/watch?v=6QGmSOzXV1s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-08-09 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545

## Nebraska farmers are tired of being dicked around
 - [https://www.youtube.com/watch?v=FPgSG41Jk7M](https://www.youtube.com/watch?v=FPgSG41Jk7M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-08-08 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
To: Steve Halloran shalloran@leg.ne.gov,  Pete Ricketts pete.ricketts@nebraska.gov
Cc: "tbrandt@leg.ne.gov" tbrandt@leg.ne.gov, 
 Carol Blood cblood@leg.ne.gov, 
 "bhansen@leg.ne.gov" bhansen@leg.ne.gov, 
 "slathrop@leg.ne.gov" slathrop@leg.ne.gov, 
 "mmoser@leg.ne.gov" mmoser@leg.ne.gov, 
 "jslama@leg.ne.gov" jslama@leg.ne.gov, 
 "jalbrecht@leg.ne.gov" jalbrecht@leg.ne.gov, 
 "kbolz@leg.ne.gov" kbolz@leg.ne.gov, 
 "bbostelman@leg.ne.gov" bbostelman@leg.ne.gov, 
 "tbrewer@leg.ne.gov" tbrewer@leg.ne.gov, 
 "tbriese@leg.ne.gov" tbriese@leg.ne.gov, 
 "rclements@leg.ne.gov" rclements@leg.ne.gov, 
 "scrawford@leg.ne.gov" scrawford@leg.ne.gov, 
 "wdeboer@leg.ne.gov" wdeboer@leg.ne.gov, 
 "mdorn@leg.ne.gov" mdorn@leg.ne.gov, 
 Steve Erdman serdman@leg.ne.gov, 
 "cfriesen@leg.ne.gov" cfriesen@leg.ne.gov, 
 "sgeist@leg.ne.gov" sgeist@leg.ne.gov, 
 "tgragert@leg.ne.gov" tgragert@leg.ne.gov, 
 "mgroene@leg.ne.gov" mgroene@leg.ne.gov, 
 "mhansen@leg.ne.gov" mhansen@leg.ne.gov, 
 Mike Hilgers mhilgers@leg.ne.gov, 
 "dhughes@leg.ne.gov" dhughes@leg.ne.gov, 
 "mkolterman@leg.ne.gov" mkolterman@leg.ne.gov, 
 John Lowe jlowe@leg.ne.gov, Dave Murman dmurman@leg.ne.gov, 
 "ppansingbrooks@leg.ne.gov" ppansingbrooks@leg.ne.gov, 
 "jscheer@leg.ne.gov" jscheer@leg.ne.gov, 
 "jstinner@leg.ne.gov" jstinner@leg.ne.gov, 
 "lwalz@leg.ne.gov" lwalz@leg.ne.gov, 

 "mwilliams@leg.ne.gov" mwilliams@leg.ne.gov, 




Dear Senator Halloran-Ag Committee Chairman

cc:  Unicameral Senators / Ag Lobby
bcc: Hundreds of Nebraska Farmers, Ranchers, NEFB Members, NEFU Members & Farm Mechanics

It comes as no surprise that the medical establishment is upset that they can't even fix their COVID-19 Ventilators due to unbridled 'Corporate Greed'.  Hero Senators just announced the bill titled, "The Critical Medical Infrastructure Right-to-Repair Act of 2020".(1) To date, no relief for Nebraska Farmers in their legislative quest via the Unicameral to obtain repair software for their farm tractors.  

Today, ONLY approved Ag Dealerships get access to repair & diagnostic software for Tractors...

The Farmers & Ranchers spoke via their Nebraska Farm Bureau Delegates in 2016 (100%) & 2019 (176-1) "In Favor" of Right-to-Repair.(2)  The Nebraska Farmers Union is also 100% on board. They want help from their State Senators to fix their tractors...that's a fact.  

Hats off to the talented Lobbyists (AEM & EDA) who obviously do a great job winning vs this overwhelming majority of your constituent-Farmers & Ranchers who are left holding a worsening farm-lot filling up of ag equipment vulnerable to more expensive fixes each year.  

This Monopoly on Ag Repair has got to stop.  Please forward the bill, "Farm Equipment Repair Act" to the drafting Committee as an Ag Committee Priority Bill.(3)   

(1)    https://www.wyden.senate.gov/imo/media/doc/Critical%20Medical%20Infrastructure%20Right%20to%20Repair%20Act%20of%202020%20Bill%20Text.pdf

(2)    https://uspirg.org/blogs/blog/usp/nebraska-farmers-vote-overwhelmingly-right-repair

(3)    ref attached pdf


Lastly, a 'Compromise Agreement'(MOU) between the NEFB/NFU & the Ag Equipment Industry is flat out worthless without access to 'Payload Files'...or software patches.  We need exactly the same Deal as the Dealers get.  Any compromise here will result in a continued 100% Monopoly on Repair & Independent Farm Mechanics will be left out.  

All we want is what the Automobile Industry already has....repair software....

