# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Production Hell - Apocalypse Now
 - [https://www.youtube.com/watch?v=TXC-b4O_H_M](https://www.youtube.com/watch?v=TXC-b4O_H_M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-08-09 00:00:00+00:00

When it comes to movies that have had a nightmarish production, few films compare to Francis Ford Coppola's Vietnam epic, Apocalypse Now. Join me as I take you through the history of one of the most difficult movies ever made.

