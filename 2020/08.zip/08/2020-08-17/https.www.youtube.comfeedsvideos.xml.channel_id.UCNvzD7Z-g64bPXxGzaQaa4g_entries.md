# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Microsoft Flight Simulator - Before You Buy
 - [https://www.youtube.com/watch?v=O_sK_sc5GYs](https://www.youtube.com/watch?v=O_sK_sc5GYs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-08-18 00:00:00+00:00

Microsoft Flight Simulator (Windows, Steam) marks the return of the famous historic aircraft simulation game. Does it truly feel like the next generation? Let's talk.
Subscribe for more: http://youtube.com/gameranxtv ▼▼


Buy Flight Simulator: https://amzn.to/3aJdla4



Watch more 'Before You Buy': https://bit.ly/2kfdxI6

## 13 Best Ninja Games & Samurai Games of All Time
 - [https://www.youtube.com/watch?v=krP9uh_EeDA](https://www.youtube.com/watch?v=krP9uh_EeDA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-08-17 00:00:00+00:00

Ninja Games | Samurai Games | Video games are always better when there's a katana involved. Here are some of our favorite samurai & ninja games.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

#13 Samurai Warriors 4
Platform: PS3 PS4 PS Vita

#12 Aragami
Platform: PC PS4 XBOX ONE SWITCH Linux

#11 Mark Of The Ninja
Platform: PC PS4 XBOX ONE SWITCH LINUX XBOX 360

#10 Naruto To Boruto: Shinobi Striker
Platform: PC PS4 XBOX ONE

#9 Tenchu
Platform: PS PS2 XBOX XBOX 360 PS Portable Nintendo DS Wii 

#8 Shadow Tactics: Blades Of The Shogun
Platform: PC PS4 XBOX ONE Linux

#7 Bushido Blade
Platform: PS

#6 Ninja Gaiden Series

#5 Nioh + Nioh 2 [PS4 ONLY]
Platform: PC PS4

#4 Onimusha
Platform: PC PS2 PS3 XBOX PS4 XBOX ONE Switch 

#3 Way Of The Samurai
Platform: PS2 PS Portable

#2 Sekiro: Shadows Die Twice
Platform: PC PS4 XBOX ONE STADIA

#1 Ghost Of Tsushima
Platform: PS4 

Bonus
The Mystical Ninja
SNES GBA

Genji: Dawn Of The Samurai 
PS2

For HonorPC 
PS4 XBOX ONE

Metal Gear Rising Revengeance
Platform: XBOX 360 PC PS3

