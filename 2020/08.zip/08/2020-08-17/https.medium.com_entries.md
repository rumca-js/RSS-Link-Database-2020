## Write Code as If You Had to Support It for the Rest of Your Life
 - [https://medium.com/oreillymedia/write-code-as-if-you-had-to-support-it-for-the-rest-of-your-life-a707d3442f1a](https://medium.com/oreillymedia/write-code-as-if-you-had-to-support-it-for-the-rest-of-your-life-a707d3442f1a)
 - RSS feed: https://medium.com
 - date published: 2020-08-17 09:59:59+00:00

Write Code as If You Had to Support It for the Rest of Your Life

