# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## The Worst Lawyer in the World
 - [https://www.youtube.com/watch?v=WH8WtrIef78](https://www.youtube.com/watch?v=WH8WtrIef78)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-08-18 00:00:00+00:00

ADA Abuse is real but it's also hard to talk about without dealing with some weird issues. I discuss my challenges with two people, Jocelyn, a disabled person from Canada who thinks deeply about disability issues and Phil Stillman, the lawyer representing small businesses being sued by Peter Strojnik. 

Also, go check out Jocelyn's channel!
https://www.youtube.com/channel/UC9y3S192IixJQr0aPBxy5_w

