# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## serpentwithfeet (live on kexp at home)
 - [https://www.youtube.com/watch?v=6KmDC2nWVdw](https://www.youtube.com/watch?v=6KmDC2nWVdw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-08-18 00:00:00+00:00

serpentwithfeet shares an exclusive set of songs from the Apparition EP, performed with co-producer Wynne Bennett, and joins Larry Mizell Jr. live from home on KEXP on Tuesday, August 18, at 12pm PT.

## Antibalas - Amenawon (Live on KEXP)
 - [https://www.youtube.com/watch?v=fkntZE-FYNw](https://www.youtube.com/watch?v=fkntZE-FYNw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-08-17 00:00:00+00:00

http://KEXP.ORG presents Antibalas performing “Amenawon” live in the KEXP studio. Recorded February 20, 2020.

Host: Darek Mazzone
Audio Engineer: Kevin Suggs
Cameras: Alaia D’Alessandro, Scott Holpainen, Luke Knecht & Kendall Rock
Editor: Justin Wilmore

http://kexp.org
https://antibalas.com

## Antibalas - Fight Am Finish (Live on KEXP)
 - [https://www.youtube.com/watch?v=oN5nRWXfLDU](https://www.youtube.com/watch?v=oN5nRWXfLDU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-08-17 00:00:00+00:00

http://KEXP.ORG presents Antibalas performing “Fight Am Finish” live in the KEXP studio. Recorded February 20, 2020.

Host: Darek Mazzone
Audio Engineer: Kevin Suggs
Cameras: Alaia D’Alessandro, Scott Holpainen, Luke Knecht & Kendall Rock
Editor: Justin Wilmore

http://kexp.org
https://antibalas.com

## Antibalas - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=FwwpHDxl3oc](https://www.youtube.com/watch?v=FwwpHDxl3oc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-08-17 00:00:00+00:00

http://KEXP.ORG presents Antibalas performing live in the KEXP studio. Recorded February 20, 2020.

Songs:
Fight Am Finish
MTTT Pt. 1 & 2
Amenawon

Host: Darek Mazzone
Audio Engineer: Kevin Suggs
Cameras: Alaia D’Alessandro, Scott Holpainen, Luke Knecht & Kendall Rock
Editor: Justin Wilmore

http://kexp.org
https://antibalas.com

## Antibalas - MTTT, Pt. 1 & 2 (Live on KEXP)
 - [https://www.youtube.com/watch?v=_e3gdSDkXjk](https://www.youtube.com/watch?v=_e3gdSDkXjk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-08-17 00:00:00+00:00

http://KEXP.ORG presents Antibalas performing “MTTT, Pt. 1 & 2” live in the KEXP studio. Recorded February 20, 2020.

Host: Darek Mazzone
Audio Engineer: Kevin Suggs
Cameras: Alaia D’Alessandro, Scott Holpainen, Luke Knecht & Kendall Rock
Editor: Justin Wilmore

http://kexp.org
https://antibalas.com

## Left At London (Live at Refill)
 - [https://www.youtube.com/watch?v=HAI9ZQf3VAo](https://www.youtube.com/watch?v=HAI9ZQf3VAo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-08-17 00:00:00+00:00

Refill (http://www.refill.live) is a community-driven, live-streamed benefit concert to help raise $25,000 for the Seattle Artist Relief Fund (SARF), a Black-led community response to help provide direct financial support to artists who have been affected by COVID-19.
  
With the global pandemic extending further into the future, artists from Seattle recognized a need for renewed focus and funding to support Seattle artists through SARF. In partnership with SARF, LANGSTON, and KEXP, we present this session with Northwest Left at London. 

Donate through this video where 100% of your donations go directly to artists in need.
 
http://leftatlondon.com
https://www.langstonseattle.org/sarf
https://www.kexp.org
http://www.refill.live

