# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## How Couples Were in January vs August 2020
 - [https://www.youtube.com/watch?v=28LPTFCeLY4](https://www.youtube.com/watch?v=28LPTFCeLY4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-08-18 00:00:00+00:00

Get your Cacao Bliss Here - https://earthechofoods.com/jpsears

How were couples in January vs August of 2020? Pre-pandemic couples had lots to look forward to in their relationships, including love. Since the lockdown hit, things have changed. Examine the various nuances that have changed in relationships!

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

## How People Cancel Each Other
 - [https://www.youtube.com/watch?v=D5-z-P4Agik](https://www.youtube.com/watch?v=D5-z-P4Agik)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-08-17 00:00:00+00:00

This video is written and directed by my canceled co-star Brent Pella. Please subscribe to his channel and cancel him more: https://www.youtube.com/c/brentpella/

Canceling everyone who doesn’t think like you is the goal. All parts of culture that aren’t cancel culture should be canceled. If you’re a social justice warrior who has your degree in being woke, this video will teach you how to ascend to the highest peak of cancel culture!

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

