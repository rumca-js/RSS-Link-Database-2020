# Source:BehindtheCurtain, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3osNjJeuDdvyALIEP-nh0g, language:en-US

## Screenwriting Lessons from Comedy Writer Simon Rich
 - [https://www.youtube.com/watch?v=Yml_FFnIhts](https://www.youtube.com/watch?v=Yml_FFnIhts)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3osNjJeuDdvyALIEP-nh0g
 - date published: 2020-08-17 14:00:17+00:00

Join our Discord server and tell me what your favorite film is: https://discord.gg/xxTqXXd


Simon Rich (SNL, Miracle Workers, An American Pickle) talks with Jake Williams about how he generates premises for his stories. Find out how he never runs out of ideas to explore and apply it to your own writing process!

Join the public Behind the Curtain discord: https://discord.gg/xxTqXXd

Follow Jake:
https://www.youtube.com/channel/UCzLj6mTdCCTwbugGY2AJtjA

Follow Me:
Twitter: https://twitter.com/ntjrdn
Instagram: https://www.instagram.com/ntjrdn/

About Simon Rich:
Simon Rich is an American humorist, novelist, and screenwriter. He has published two novels and three collections of humor pieces, several of which appeared in The New Yorker. Rich was one of the youngest writers ever hired on Saturday Night Live, and served as a staff writer for Pixar. An American Pickle is a 2020 American comedy-drama film directed by Brandon Trost (in his solo directorial debut) and written by Simon Rich, based on his 2013 short story "Sell Out". The film stars Seth Rogen as a Jewish immigrant who gets preserved in a vat of pickles and wakes up in modern-day New York City, attempting to fit in with the assistance of his last remaining descendant (also played by Rogen).

ABOUT BEHIND THE CURTAIN
Learn from real screenwriters. Learn the most without wasting time listening to long interviews with only 3 minutes of useful information. We take the best pieces of advice and insight from professional screenwriters and deliver them to you in an easily watchable format.

Generating 100 Story Premises with Simon Rich
https://youtu.be/Yml_FFnIhts

#screenwriting #anamericanpickle #HBOMax

