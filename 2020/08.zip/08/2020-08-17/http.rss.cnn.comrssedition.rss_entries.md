# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Trump deploys dark message to counter Dems' convention
 - [https://www.cnn.com/2020/08/17/politics/donald-trump-campaign-swing/index.html](https://www.cnn.com/2020/08/17/politics/donald-trump-campaign-swing/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 23:33:26+00:00

• Trump retweets known Russian propaganda about Biden
• Opinion: If Trump loses and won't leave, it could get ugly

## Trump deploys dark message of conspiracy and fear to counter Biden's convention week
 - [https://www.cnn.com/collections/intl-politics-postal-service-08172020/](https://www.cnn.com/collections/intl-politics-postal-service-08172020/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 23:08:12+00:00



## Wolf Blitzer presses Kushner: 1,000 deaths a day isn't success, right?
 - [https://www.cnn.com/videos/politics/2020/08/17/jared-kushner-coronavirus-deaths-wolf-blitzer-vpx.cnn](https://www.cnn.com/videos/politics/2020/08/17/jared-kushner-coronavirus-deaths-wolf-blitzer-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 21:45:23+00:00

CNN's Wolf Blitzer talks to President Trump's senior adviser and son-in-law Jared Kushner.

## The moments that transformed US political conventions
 - [https://www.cnn.com/videos/politics/2020/08/14/us-political-conventions-democrats-republicans-vf-orig.cnn](https://www.cnn.com/videos/politics/2020/08/14/us-political-conventions-democrats-republicans-vf-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 21:07:30+00:00

US political conventions used to be filled with raucous antics. But reforms over decades have dramatically changed the role of delegates and this year many won't even show up in person. So what actually happens at conventions?

## CNN Poll of Polls: Biden's lead is back in single digits
 - [https://www.cnn.com/collections/2020-election-intl-081720/](https://www.cnn.com/collections/2020-election-intl-081720/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 19:19:19+00:00



## Covid-19 is now the No. 3 cause of death in the US
 - [https://www.cnn.com/collections/intl-health-0817/](https://www.cnn.com/collections/intl-health-0817/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 18:59:06+00:00



## 'The Office' star shares messages from racist trolls
 - [https://www.cnn.com/videos/entertainment/2020/08/17/the-office-spinoff-racist-trolls-leslie-david-baker-mxp-vpx.hln](https://www.cnn.com/videos/entertainment/2020/08/17/the-office-spinoff-racist-trolls-leslie-david-baker-mxp-vpx.hln)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 16:18:45+00:00

'The Office" actor Leslie David Baker has received racist hateful attacks for trying to produce a spinoff of the series starring his character Stanley Hudson. HLN's Melissa Knowles reports.

## What to watch on the first night of the Democratic convention
 - [https://www.cnn.com/2020/08/17/politics/dnc-schedule-speakers-monday/index.html](https://www.cnn.com/2020/08/17/politics/dnc-schedule-speakers-monday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 15:53:33+00:00

The Democratic National Convention kicks off Monday with a two-hour virtual event built on a theme of unity.

## Trump administration announces plans to drill in Arctic National Wildlife Refuge
 - [https://www.cnn.com/2020/08/17/politics/trump-arctic-wildlife-drilling/index.html](https://www.cnn.com/2020/08/17/politics/trump-arctic-wildlife-drilling/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 15:52:34+00:00

Interior Secretary David Bernhardt on Monday announced plans for an oil and gas leasing program in the Arctic National Wildlife Refuge, clearing the way for drilling in the remote Alaskan area.

## Sharon Stone shares sister's Covid-19 diagnosis: 'One of you Non-Mask wearers did this'
 - [https://www.cnn.com/2020/08/17/entertainment/sharon-stone-sister-coronavirus-diagnosis-trnd/index.html](https://www.cnn.com/2020/08/17/entertainment/sharon-stone-sister-coronavirus-diagnosis-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 15:45:09+00:00

Actress Sharon Stone shared her sister's experience with Covid-19 on Instagram, and she said people who don't wear masks are to blame.

## Rebel Wilson shows off major weight loss
 - [https://www.cnn.com/2020/08/17/entertainment/rebel-wilson-weight-loss/index.html](https://www.cnn.com/2020/08/17/entertainment/rebel-wilson-weight-loss/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 15:35:15+00:00

If you picked up some weight while quarantining, you can look to Rebel Wilson for inspiration.

## Thailand's monarchy was long considered God-like. But protesters say it's time for change
 - [https://www.cnn.com/2020/08/17/asia/thailand-democracy-protests-monarchy-intl-hnk/index.html](https://www.cnn.com/2020/08/17/asia/thailand-democracy-protests-monarchy-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 15:30:50+00:00

It was an act unthinkable in Thailand mere months ago -- an estimated 10,000 anti-government protesters packing Bangkok's Democracy Monument on Sunday, with some calling for reform of the country's monarchy.

## Protesters in Thailand demand monarchy reform
 - [https://www.cnn.com/videos/world/2020/08/17/thailand-reform-monarchy-protest-lon-orig-mrg.cnn](https://www.cnn.com/videos/world/2020/08/17/thailand-reform-monarchy-protest-lon-orig-mrg.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 15:27:50+00:00

An estimated 10,000 anti-government protesters rallied in Bangkok on Sunday, with some calling for reform of the country's monarchy.

## It's long past time for Biden to take media questions
 - [https://www.cnn.com/2020/08/17/politics/joe-biden-media/index.html](https://www.cnn.com/2020/08/17/politics/joe-biden-media/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 15:27:04+00:00

Joe Biden held two public events last week introducing California Sen. Kamala Harris as his vice presidential pick. He took zero questions from the press.

## Green recovery or 'nightmare' for trade? Europe wants to tax emissions from ships
 - [https://www.cnn.com/collections/intl-biz-0817/](https://www.cnn.com/collections/intl-biz-0817/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 15:03:29+00:00



## RB Leipzig's US sensation Tyler Adams driven on by the 'sacrifices' of his family
 - [https://www.cnn.com/2020/08/17/football/tyler-adams-american-champions-league-spt-intl/index.html](https://www.cnn.com/2020/08/17/football/tyler-adams-american-champions-league-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 14:57:25+00:00

'Where do you see yourself in five years?' is a popular question you might find asked at a job interview, or a hopeful parent might inquire of their teenager. But, in this current climate, you would be forgiven if the query was truncated a bit -- more of a five-day plan than a five-year one.

## CNN Poll of Polls: Biden's lead is narrowing
 - [https://www.cnn.com/2020/08/17/politics/biden-trump-poll-of-polls-august-election/index.html](https://www.cnn.com/2020/08/17/politics/biden-trump-poll-of-polls-august-election/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 14:40:20+00:00

Former Vice President Joe Biden leads President Donald Trump by a nine-point margin nationally, according to a CNN Poll of Polls on the general election matchup released Monday.

## Nudes, prudes and swingers. Hedonism II adapts to the pandemic era
 - [https://www.cnn.com/travel/article/hedonism-ii-lifestyle-resort-reopens-pandemic-jamaica/index.html](https://www.cnn.com/travel/article/hedonism-ii-lifestyle-resort-reopens-pandemic-jamaica/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 14:17:22+00:00

During the time I spent living with my husband next door to Hedonism II resort in Jamaica, I often suspected the neighbors were having more fun than we were.

## Cardi B interviewed Joe Biden and she had some requests
 - [https://www.cnn.com/2020/08/17/entertainment/cardi-b-joe-biden-elle/index.html](https://www.cnn.com/2020/08/17/entertainment/cardi-b-joe-biden-elle/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 14:17:12+00:00

Cardi B has a list of things she wants for the country and she has shared them with Joe Biden.

## If Trump loses and won't leave, it could get ugly
 - [https://www.cnn.com/2020/08/17/opinions/if-trump-loses-and-refuses-to-leave-callan/index.html](https://www.cnn.com/2020/08/17/opinions/if-trump-loses-and-refuses-to-leave-callan/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 13:28:22+00:00

President Donald Trump talks a lot about staying in office longer than the two-term, eight-year limit allowed by the Constitution. People may assume he's joking -- just needling his enemies. He couldn't possibly be serious, could he?

## Golf faces 'confusion' over players hitting huge drives
 - [https://www.cnn.com/2020/08/17/golf/golf-course-length-designers-driving-bryson-dechambeau-cmd-spt-intl/index.html](https://www.cnn.com/2020/08/17/golf/golf-course-length-designers-driving-bryson-dechambeau-cmd-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 13:08:15+00:00

When Bryson DeChambeau, who had put on 40 pounds during lockdown as the PGA Tour suspended play from mid-March to mid-June, stepped onto the first tee at Muirfield Village last month at the Memorial Tournament, everyone was anticipating fireworks.

## Police pick up penguin found waddling along rural English road
 - [https://www.cnn.com/2020/08/17/uk/penguin-nottinghamshire-police-scli-intl-gbr/index.html](https://www.cnn.com/2020/08/17/uk/penguin-nottinghamshire-police-scli-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 12:42:37+00:00

Police in central England were surprised to find a penguin waddling along a village street on Sunday morning.

## In search of the perfect swimming pools
 - [https://www.cnn.com/travel/article/brad-walls-aerial-photos-swimming-pools/index.html](https://www.cnn.com/travel/article/brad-walls-aerial-photos-swimming-pools/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 12:37:19+00:00

Glistening turquoise water rippling in the sunlight, a pop of color from a coral-colored parasol, a figure lounging on a sunbed.

## At least 18 arrested in Seattle after a protest is declared a riot
 - [https://www.cnn.com/2020/08/17/us/seattle-riot-protesters-arrested/index.html](https://www.cnn.com/2020/08/17/us/seattle-riot-protesters-arrested/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 12:07:10+00:00

At least 18 people were arrested in Seattle Sunday night when a riot was declared during an anti-police demonstration in the SODO neighborhood, just south of downtown, according to the Seattle Police Department. Police did not say what charges the arrestees face.

## Angry workers heckle Belarus' Lukashenko as challenges to his decades-long rule grow
 - [https://www.cnn.com/collections/intl-belaurs-08172020/](https://www.cnn.com/collections/intl-belaurs-08172020/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 12:01:30+00:00



## US intelligence: Iran paid bounties to Taliban to target US troops
 - [https://www.cnn.com/videos/politics/2020/08/17/iran-taliban-bounties-us-intelligence-marquardt-new-day-ldn-vpx.cnn](https://www.cnn.com/videos/politics/2020/08/17/iran-taliban-bounties-us-intelligence-marquardt-new-day-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 11:38:49+00:00

US intelligence agencies assessed that Iran offered bounties to Taliban fighters for targeting American and coalition troops in Afghanistan, CNN has learned. CNN's Alexander Marquardt reports.

## For sale: the demo album Ed Sheeran really doesn't want us to hear
 - [https://www.cnn.com/2020/08/17/entertainment/ed-sheeran-rare-demo-auction-intl-scli-gbr/index.html](https://www.cnn.com/2020/08/17/entertainment/ed-sheeran-rare-demo-auction-intl-scli-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 11:35:24+00:00

A rare copy of Ed Sheeran's first demo album is being auctioned -- and somewhere out there, he is dying of embarrassment.

## Democrats launch emergency effort to thwart President's apparent attempt to squeeze USPS to suppress voting
 - [https://www.cnn.com/2020/08/17/politics/donald-trump-election-2020-democrats-postal-service/index.html](https://www.cnn.com/2020/08/17/politics/donald-trump-election-2020-democrats-postal-service/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 11:07:11+00:00

Democrats are launching an emergency effort to thwart what they warn is President Donald Trump's attempt to squeeze the US Postal Service -- one of the country's most beloved institutions -- to suppress the vote in November's election.

## Washington's Alex Smith back after horrific injury
 - [https://www.cnn.com/2020/08/17/sport/alex-smith-washington-nfl-spt-intl/index.html](https://www.cnn.com/2020/08/17/sport/alex-smith-washington-nfl-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 10:47:00+00:00

Washington quarterback Alex Smith has returned to practice having been side-lined for 21 months with a gruesome leg injury.

## See the precautions a Scottish school is taking as children return to class
 - [https://www.cnn.com/videos/world/2020/08/17/scotland-school-reopening-coronavirus-covid-19-pandemic-foster-pkg-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2020/08/17/scotland-school-reopening-coronavirus-covid-19-pandemic-foster-pkg-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 10:29:20+00:00

CNN's Max Foster shows us how one school in Scotland has prepared to reopen and what safety measures they have put in place.

## Elizabeth Debicki will play Princess Diana in final two seasons of 'The Crown'
 - [https://www.cnn.com/2020/08/17/entertainment/elizabeth-debicki-princess-diana-the-crown-intl-scli-gbr/index.html](https://www.cnn.com/2020/08/17/entertainment/elizabeth-debicki-princess-diana-the-crown-intl-scli-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 10:03:03+00:00

Elizabeth Debicki is set to play Diana, Princess of Wales in the final seasons of "The Crown," makers of the hit Netflix series announced on Sunday.

## Restaurant apologizes for weighing diners to determine how much they should eat
 - [https://www.cnn.com/travel/article/china-restaurant-weighing-customers-intl-hnk-scli/index.html](https://www.cnn.com/travel/article/china-restaurant-weighing-customers-intl-hnk-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 08:20:51+00:00

A restaurant chain in southern China has issued a public apology for weighing diners before they entered the premises as part of a national campaign to reduce food waste.

## WHO reports record global Covid-19 increase over 24 hours
 - [https://www.cnn.com/videos/world/2020/08/17/global-coronavirus-covid-19-wrap-brunhuber-pkg-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2020/08/17/global-coronavirus-covid-19-wrap-brunhuber-pkg-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 08:20:28+00:00

As the World Health Organization reported a global record of new Covid-19 cases within a 24-hour period over the weekend, CNN's Kim Brunhuber reports on how the pandemic is spreading across the world.

## Officials apologize and drop charges against Black reporter covering rally
 - [https://www.cnn.com/2020/08/17/us/kalamazoo-proud-boys-black-reporter-arrest/index.html](https://www.cnn.com/2020/08/17/us/kalamazoo-proud-boys-black-reporter-arrest/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 08:08:17+00:00

Officials in Kalamazoo have apologized for the arrest of a Black reporter who was covering a Proud Boys rally and counterprotests on Saturday, according to affiliate reports.

## VR lets you experience racism in the workplace
 - [https://www.cnn.com/2020/08/17/business/virtual-reality-diversity-workplace-spc-intl/index.html](https://www.cnn.com/2020/08/17/business/virtual-reality-diversity-workplace-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 07:46:47+00:00

If you were at work and one of your colleagues made a racist remark, would you challenge it or let it pass?

## New Zealand Prime Minister Jacinda Ardern delays election over Covid-19
 - [https://www.cnn.com/2020/08/16/asia/new-zealand-ardern-election-delay-coronavirus/index.html](https://www.cnn.com/2020/08/16/asia/new-zealand-ardern-election-delay-coronavirus/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 07:45:59+00:00

New Zealand Prime Minister Jacinda Ardern says she is delaying the country's parliamentary election by four weeks to October 17 after the reemergence of Covid-19 in the country last week.

## New saliva-based Covid-19 test could be a fast and cheap 'game changer'
 - [https://www.cnn.com/2020/08/16/health/us-coronavirus-sunday/index.html](https://www.cnn.com/2020/08/16/health/us-coronavirus-sunday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 03:55:26+00:00

After months of frustration over testing shortages and delays, a new saliva test could give Americans a fast and inexpensive option to learn if they have Covid-19.

## Violent crime rises during pandemic as confidence in police takes a hit
 - [https://www.cnn.com/2020/08/16/us/violent-crime-soars-confidence-in-police-takes-hit/index.html](https://www.cnn.com/2020/08/16/us/violent-crime-soars-confidence-in-police-takes-hit/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 02:06:13+00:00

As the body counts rise, American cities remain ground zero for a deadly new reality.

## See video from controversial party near Georgia college
 - [https://www.cnn.com/videos/us/2020/08/16/georgia-students-party-dahlonega-coronavirus-chen-tsr-vpx.cnn](https://www.cnn.com/videos/us/2020/08/16/georgia-students-party-dahlonega-coronavirus-chen-tsr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 00:59:06+00:00

CNN's Natasha Chen reports that a private party near a North Georgia college drew large groups of students, without apparent Covid-19 precautions being exercised.

## This is what Tijuana's red light district looks like during pandemic
 - [https://www.cnn.com/videos/world/2020/08/16/tijuana-mexico-red-light-district-coronavirus-rivers-pkg-tsr-vpx.cnn](https://www.cnn.com/videos/world/2020/08/16/tijuana-mexico-red-light-district-coronavirus-rivers-pkg-tsr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 00:18:17+00:00

Despite the coronavirus pandemic, the red light district in Tijuana, Mexico, is still bustling with tourists. CNN's Matt Rivers reports.

## How Trump could lose the popular vote by 5 million and still win the election
 - [https://www.cnn.com/videos/politics/2020/08/14/donald-trump-joe-biden-electoral-college-math-enten-analysis-vpx.cnn](https://www.cnn.com/videos/politics/2020/08/14/donald-trump-joe-biden-electoral-college-math-enten-analysis-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 00:14:07+00:00

CNN's Harry Enten breaks down the Electoral College math that could see President Trump lose the general election by more than 5 million votes and still win the general election.

## Asia's prisons are filling up with women. Many are victims of the war on drugs
 - [https://www.cnn.com/2020/08/16/asia/women-drug-trafficking-mules-hnk-intl-dst-as-equals/index.html](https://www.cnn.com/2020/08/16/asia/women-drug-trafficking-mules-hnk-intl-dst-as-equals/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-17 00:02:41+00:00



