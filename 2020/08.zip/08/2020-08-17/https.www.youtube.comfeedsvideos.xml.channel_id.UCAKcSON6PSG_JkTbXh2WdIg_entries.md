# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Mitski - two songs at The Current (2018)
 - [https://www.youtube.com/watch?v=PhDNQmnzJmE](https://www.youtube.com/watch?v=PhDNQmnzJmE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-08-18 00:00:00+00:00

Two years ago, on Aug. 17, 2018, Mitski released her album, "Be The Cowboy." A couple months after that release, Mitski visited our studio to perform tracks from the album, including the song, "Nobody," which ended up landing at No. 18 in our Top 89 Songs of 2018, as voted by The Current's audience. Here are two performances from Mitski's studio session.

SONGS PERFORMED
0:00 "Nobody"
3:08 "Washing Machine Heart" 

PERSONNEL
Mitski – vocals
Patrick Hyland – guitar
Marie Kim - keyboards
Bruno Luis – drums
Jeni Magana – bass

CREDITS
Video & Photo: Nate Ryan; Helen Teague
Audio: Michael DeMark
Production: Derrick Stevens

FIND MORE:
2018 studio session: https://www.thecurrent.org/feature/2018/10/29/mitski-performs-in-the-current-studio-nobody-be-the-cowboy

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Sylvan Esso - Virtual Session
 - [https://www.youtube.com/watch?v=LLHHwR74Au8](https://www.youtube.com/watch?v=LLHHwR74Au8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-08-18 00:00:00+00:00

Amelia Meath and Nick Sanborn of Sylvan Esso join Jade of The Current for a Virtual Session.

SONGS PERFORMED:
5:42 "Ferris Wheel"
18:23 "Coffee"
22:55 "Radio"

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

