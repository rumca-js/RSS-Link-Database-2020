# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Rhythm of War Cover REVEAL🥁 Ghibli Meets D&D🎲 Erikson’s RANT😍-FANTASY NEWS
 - [https://www.youtube.com/watch?v=EN42bL_MVLU](https://www.youtube.com/watch?v=EN42bL_MVLU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-08-18 00:00:00+00:00

Erikson got something off his chest and Sanderson reveals the new books look! 
Podcast: https://afictionalconversation.podbean.com/
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

NEWS: 

—
00:23 - Rhythm Of War Cover: https://www.reddit.com/r/Stormlight_Archive/comments/ibdvrs/rhythm_of_war_cover_its_gorgeous/

01:48 - Brandon Writing Progress: https://twitter.com/BrandSanderson/status/1293822442998099968?s=19

02:26 - George R R Martin Post: https://georgerrmartin.com/notablog/2020/08/15/back-in-westeros/

03:13 - DESCENDANTS OF THE FIRST COVER: https://twitter.com/renikamayo/status/1294573568232230912?s=12

03:55 - #JadeCity ( Jade City) Adaptation: https://deadline.com/2020/08/jade-city-series-books-peacock-dave-kalstein-breck-eisner-dean-georgaris-1203011700/

06:29 - Avatar Rumor: https://fandomwire.com/exclusive-why-avatar-the-last-airbenders-creators-really-left-netflix/

09:29 - Barney Harris Insta/Twitter: https://www.instagram.com/p/CD2MukkHk8x/?igshid=19yuovgmunevz

09:54 - Folio Society #Farseer: https://www.instagram.com/p/CD_O6akoCRK/?igshid=oli2udq0v3o7

Erikson Rant: https://www.facebook.com/steveneriksonofficial/posts/1646644495487844

13:00 - Ghibli Meets DUNGEONS & DRAGONS: https://nerdist.com/article/studio-ghibli-dungeons-dragons-adventure-anthology/?amp&__twitter_impression=true

14:32 - Enola Holmes: https://twitter.com/DiscussingFilm/status/1295345115138084864

16:10 - Lovecraft Country Reviews: https://www.imdb.com/title/tt6905686/?ref_=ttep_ep_tt

16:37 -  Star Wars Holiday Special: https://www.starwars.com/news/the-lego-star-wars-holiday-special-disney-plus-announce

—

## The Life Of King's Editor
 - [https://www.youtube.com/watch?v=4hkCyXIKFEA](https://www.youtube.com/watch?v=4hkCyXIKFEA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-08-17 00:00:00+00:00

It be like that for King's editor. 
Podcast: https://afictionalconversation.podbean.com/
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

