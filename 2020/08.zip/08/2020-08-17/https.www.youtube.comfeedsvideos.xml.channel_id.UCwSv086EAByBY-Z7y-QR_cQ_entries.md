# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Analiza projektu ustawy o transparentności finansowana NGO
 - [https://www.youtube.com/watch?v=gGLz9B-dcsI](https://www.youtube.com/watch?v=gGLz9B-dcsI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2020-08-18 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Mroczne Podcasty: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
👀 Tatusiek: http://bit.ly/3aSCheE
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
🔒 Dołącz do Spółdzielni
https://discord.gg/RSEUaR3
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/2ETKSyN
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
---------------------------------------------------------------
🖼Grafika - wykorzystano elementy ze stron: 
gov.pl / http://bit.ly/2lVWjQr
---------------------------------------------------------------
✅źródła:
https://bit.ly/2CGYjoE
https://bit.ly/3kWJSOE
https://bit.ly/3hc7Hjc
https://bit.ly/315KZDu
-------------------------------------------------------------
💡 Tagi: #Ziobro #NGO
--------------------------------------------------------------

## Agenci CBA mogą zostać zdemaskowani!
 - [https://www.youtube.com/watch?v=yjO5U9FDcmY](https://www.youtube.com/watch?v=yjO5U9FDcmY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2020-08-17 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Mroczne Podcasty: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
👀 Tatusiek: http://bit.ly/3aSCheE
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
🔒 Dołącz do Spółdzielni
https://discord.gg/RSEUaR3
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/2ETKSyN
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
---------------------------------------------------------------
🖼Grafika - wykorzystano elementy ze strony: 
Stanisław Kowalczyk / East News
http://bit.ly/2T1Bgrz
---------------------------------------------------------------
✅źródła:
http://bit.ly/2Y7HKf0
https://bit.ly/3h2ZAFf
https://bit.ly/2Q1veXO
https://bit.ly/3g1Z35s
https://bit.ly/31WN83H
https://bit.ly/2PUdTAi
-------------------------------------------------------------
💡 Tagi: #CBA #służby
--------------------------------------------------------------

