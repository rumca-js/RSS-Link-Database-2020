# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## The Oculus Store Is The Least Consumer-Friendly Digital Storefront | The Escapist Show
 - [https://www.youtube.com/watch?v=DNmkQGzH3Ls](https://www.youtube.com/watch?v=DNmkQGzH3Ls)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-08-24 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

This week on The Escapist Show we take a look at a bunch of different games we've been playing, our thoughts on Sony dipping their toes back in multiplayer, the Facebook / Oculus controversy and our thoughts on all the delays currently happening around next-gen consoles.

Timestamps
The games we've been playing - 0:00 - 11:33
Ghost of Tsushima Legends - 11:34 - 14:40
The Facebook / Oculus Controversy - 14:41 - 19:57
Will the PS5 and Xbox Series X be delayed? - 19:58 - 25:45

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Who Had the Best First Console, Yahtzee or Jack? | Slightly Civil War
 - [https://www.youtube.com/watch?v=IdcPtOnRe8g](https://www.youtube.com/watch?v=IdcPtOnRe8g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-08-24 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

This week on Slightly Civil War, Yahtzee and Jack debate which one of them had the best first console: the Magnavox Odyssey 2 or Super Nintendo.

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

