# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Gotham Knights: 10 Things You NEED TO KNOW
 - [https://www.youtube.com/watch?v=7JBqFf3idV0](https://www.youtube.com/watch?v=7JBqFf3idV0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-08-24 00:00:00+00:00

Gotham Knights (2021) is the latest Batman-themed Warner Brothers game and it has a co-op twist. What exactly is this game? Where's Batman himself? Let's talk.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## ATOMIC HEART: The Most UNIQUE Open World Game?
 - [https://www.youtube.com/watch?v=3zn1-H_qPDw](https://www.youtube.com/watch?v=3zn1-H_qPDw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-08-23 00:00:00+00:00

Atomic Heart has been on our radar for some time now. Here's why we're excited for this strange Russian inspired BioShock hybrid game.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## Top 10 NEW Survival Games of 2020
 - [https://www.youtube.com/watch?v=tCqUIBCj_FY](https://www.youtube.com/watch?v=tCqUIBCj_FY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-08-23 00:00:00+00:00

Looking for survival games to play and/or anticipate in 2020? We've got you covered with survival games for PC, PS4, Xbox One, and beyond.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Windbound

Platform:  PC PS4 XBOX ONE Switch, Stadia

Release Date:  August 28, 2020



The Riftbreaker

Platform: PC PS4 XBOX ONE

Release Date: TBA 2020



Occupy Mars: The Game

Platform: PC 

Release Date:  TBA 2020



The Eternal Cylinder

Platform: PC PS4 XBOX ONE

Release Date:  TBA 2020



Wild

Platform: PS4

Release Date: TBA 2020



The Survivalists

Platform: PC PS4 XBOX ONE Switch

Release Date:  Q4 2020



Grounded

Platform: PC XBOX ONE

Release Date: July 28, 2020



Survivalist: Invisible Strain

Platform: PC

Release Date:  June 1, 2020



Away: the survival series

Platform: PC PS4

Release Date:  TBA 2020



DEADSIDE

Platform: PC

Release Date:  April 14, 2020

