## System of a Down - Aerials - Medieval Style - Bardcore
 - [https://www.youtube.com/watch?v=tAVkuRKwuDI](https://www.youtube.com/watch?v=tAVkuRKwuDI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCrwIwCT7vXtJIm3nZiwD7cQ
 - date published: 2020-08-23 00:00:00+00:00

Song composed by Serj Tankian and Daron Malakian.

Spotify: https://open.spotify.com/artist/6AU6DQHPVlHvPh175WIXHa
iTunes: https://music.apple.com/us/artist/algal/1529528125
Google Play: https://play.google.com/store/music/artist?id=A27ex3kykbb65ri4gcb5wja5qom
Facebook: http://www.facebook.com/alvarogalanmusic
Twitter: http://twitter.com/Alvariu
Instagram: https://www.instagram.com/alvariu360 
Instruments: Viola da gamba, irish bouzouki, xaphoon and lute-guitar.

