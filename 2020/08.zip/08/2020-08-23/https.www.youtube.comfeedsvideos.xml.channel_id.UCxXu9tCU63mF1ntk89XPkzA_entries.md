# Source:Worthkids, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCxXu9tCU63mF1ntk89XPkzA, language:en-US

## BIGTOP BURGER: SEASON ONE
 - [https://www.youtube.com/watch?v=GyCagepF_T4](https://www.youtube.com/watch?v=GyCagepF_T4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCxXu9tCU63mF1ntk89XPkzA
 - date published: 2020-08-23 14:41:01+00:00

FEATURING THE VOICE TALENTS OF:
Lindsay Small-Butera ...... Penny
Olivia Craighead ...............Billie
Tim Batt ............................Tim
Guy Montgomery ..............Customer
Tom Willett.........................Customer#2
Chris Fleming.....................Cesare
SungWon Cho....................Doctor
Ayo Edebiri.........................Frances
Alex Small-Butera..............Conrad

English Captions provided by:
FunOBot, connithan, grungebob, David Baral, Annoyed Grunt

Patreon: https://www.patreon.com/worthikids
Twitter: https://www.twitter.com/worthikids
Instagram: https://www.instagram.com/worthikids/

