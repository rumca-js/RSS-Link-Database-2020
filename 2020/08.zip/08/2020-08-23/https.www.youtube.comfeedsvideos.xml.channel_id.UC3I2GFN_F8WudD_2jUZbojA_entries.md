# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Andy Shauf - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=qqNTVbargwc](https://www.youtube.com/watch?v=qqNTVbargwc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-08-24 00:00:00+00:00

http://KEXP.ORG presents Andy Shauf performing live in the KEXP studio. Recorded February 25, 2020.

Songs:
Neon Skyline
Thirteen Hours
Try Again
Things I Do

Host: Cheryl Waters
KEXP Audio Engineer: Kevin Suggs
Guest Audio Engineer: Justin Nace
Cameras: Alaia D’Alessandro, Scott Holpainen, Kendall Rock & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
https://andyshauf.com

## Andy Shauf - Neon Skyline (Live on KEXP)
 - [https://www.youtube.com/watch?v=wNKTwckPG-A](https://www.youtube.com/watch?v=wNKTwckPG-A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-08-24 00:00:00+00:00

http://KEXP.ORG presents Andy Shauf performing “Neon Skyline” live in the KEXP studio. Recorded February 25, 2020.

Host: Cheryl Waters
KEXP Audio Engineer: Kevin Suggs
Guest Audio Engineer: Justin Nace
Cameras: Alaia D’Alessandro, Scott Holpainen, Kendall Rock & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
https://andyshauf.com

## Andy Shauf - Things I Do (Live on KEXP)
 - [https://www.youtube.com/watch?v=y-zKG8LLWR0](https://www.youtube.com/watch?v=y-zKG8LLWR0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-08-24 00:00:00+00:00

http://KEXP.ORG presents Andy Shauf performing “Things I Do” live in the KEXP studio. Recorded February 25, 2020.

Host: Cheryl Waters
KEXP Audio Engineer: Kevin Suggs
Guest Audio Engineer: Justin Nace
Cameras: Alaia D’Alessandro, Scott Holpainen, Kendall Rock & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
https://andyshauf.com

## Andy Shauf - Thirteen Hours (Live on KEXP)
 - [https://www.youtube.com/watch?v=82JnY6ejA_o](https://www.youtube.com/watch?v=82JnY6ejA_o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-08-24 00:00:00+00:00

http://KEXP.ORG presents Andy Shauf performing “Thirteen Hours” live in the KEXP studio. Recorded February 25, 2020.

Host: Cheryl Waters
KEXP Audio Engineer: Kevin Suggs
Guest Audio Engineer: Justin Nace
Cameras: Alaia D’Alessandro, Scott Holpainen, Kendall Rock & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
https://andyshauf.com

## Andy Shauf - Try Again (Live on KEXP)
 - [https://www.youtube.com/watch?v=XTKjqimjhc8](https://www.youtube.com/watch?v=XTKjqimjhc8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-08-24 00:00:00+00:00

http://KEXP.ORG presents Andy Shauf performing “Try Again” live in the KEXP studio. Recorded February 25, 2020.

Host: Cheryl Waters
KEXP Audio Engineer: Kevin Suggs
Guest Audio Engineer: Justin Nace
Cameras: Alaia D’Alessandro, Scott Holpainen, Kendall Rock & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
https://andyshauf.com

## Dave B (Live at Refill)
 - [https://www.youtube.com/watch?v=ORvN7jxA-EM](https://www.youtube.com/watch?v=ORvN7jxA-EM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-08-23 00:00:00+00:00

Refill (http://www.refill.live) is a community-driven, live-streamed benefit concert to help raise $25,000 for the Seattle Artist Relief Fund (SARF), a Black-led community response to help provide direct financial support to artists who have been affected by COVID-19.
  
With the global pandemic extending further into the future, artists from Seattle recognized a need for renewed focus and funding to support Seattle artists through SARF. In partnership with SARF, LANGSTON, and KEXP, we present this session with Northwest artist Dave B. 

Donate through this video where 100% of your donations go directly to artists in need.
 
http://davebmusic.com
https://www.langstonseattle.org/sarf
https://www.kexp.org
http://www.refill.live

