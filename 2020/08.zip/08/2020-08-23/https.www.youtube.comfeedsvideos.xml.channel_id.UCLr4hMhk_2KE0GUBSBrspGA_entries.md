# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week: Dlaczego koty włażą do kartonów? A także PS5, iPhone 12, OnePlus Buds
 - [https://www.youtube.com/watch?v=_0wun4pCzZo](https://www.youtube.com/watch?v=_0wun4pCzZo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-08-23 00:00:00+00:00

Dzisiaj głównie o kotach. Małych i dużych. Ale miejsce na technologię też się znalazło ;)
Centrum Testów Zrzutka: https://zrzutka.pl/z/ct
Strona Centrum Testów: https://centrumtestow.pl

Moje sociale:
Insta: http://bit.ly/InstaKlawiatur 
Twitter: http://bit.ly/TTKlawitera
FB: http://bit.ly/FBKlawiatur

Proshop - dzięki za słuchawki OnePlus Buds - https://bit.ly/32jTkTG
Muza z filmów: https://spoti.fi/3fgBNRu

Źródła:
Reklama PS5: https://bit.ly/2YoUNac
Malowanie oczu na krowich tyłkach: https://bit.ly/31n0Ygw
Apple jest warte 2 miliardy dolarów: https://bit.ly/2EndAeJ
Bateria w iPhonie 12 będzie mniejsza i tańsza: https://bit.ly/31lG7uh
Data eventu Apple'a: https://bit.ly/3ldAhTq
Sposób na przegrzewającego się Canona R5: https://bit.ly/2Qj2OZC
Smartwatche uprzedzą nas o Covidzie: https://bit.ly/3hi9qmW
Dlaczego koty włażą do kartonów: https://bit.ly/3ht9QqU

Spis treści:
00:00 Wstęp
00:16 Co się wydarzyło w tym tygodniu
00:52 Krowy z oczami na dupach
02:19 Apple warte 2 miliardy dolarów
02:57 iPhone 12 będzie miał marną baterię
03:22 Data premiery iPhone'a 12
05:02 OnePlus Buds
05:17 Centrum Testów
05:46 Słuchawki Sony vs Apple
06:55 Canon R5 sposób na przegrzewanie
08:34 Czarny rynek smartfonów z Fortnite
08:51 Smartwatche ostrzegą przed Covidem
09:29 Dlaczego koty włażą do kartonów?
10:46 Pożegnanko

