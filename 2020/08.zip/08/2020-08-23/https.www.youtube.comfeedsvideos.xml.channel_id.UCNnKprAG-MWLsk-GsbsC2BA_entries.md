# Source:FlashGitz, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA, language:en-US

## Paper Mario creates a Monster
 - [https://www.youtube.com/watch?v=Tvl1If4sMbA](https://www.youtube.com/watch?v=Tvl1If4sMbA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA
 - date published: 2020-08-24 00:00:00+00:00

Install Raid for Free ✅ IOS: https://clcr.me/7zlWEv ✅ ANDROID: https://clcr.me/X1qCw6 ✅ PC: https://clcr.me/8nh0dn and get a special starter pack 💥Available only for the next 30 days

Flashgitz presents "Paper Mario creates a Monster" a Paper Mario parody featuring Paper Mario.

Patreon ►
https://www.patreon.com/flashgitz

Special thanks to our Patron Producers, really going the extra mile to make this possible:

Albert Hutchins
David Murphy
Andrew Palmer
Adam Knopow
Connor Hill
Zack Buckland
Jonathon Geach
Sam Husmann

Thank you gents, seriously.

VO ► 
Mario - Meatcanyon
Peach - Hayley Nelson
Broken Peach - Don
Luigi, Koopa Troopas - Tom

Sound ►
Justin Greger

8-Bit Music ►
Tom Ryan 

Additional Animation ► 
Meatcanyon

Backgrounds ► 
CG Geek https://www.youtube.com/CGGeek

Additional Background Work ► 
PotatomanNG 

Thumbnail ►
Josh Floyd 

Instagram ►
https://www.instagram.com/flashgitz/


Twitter ►
https://www.twitter.com/flashgitzanims
https://www.twitter.com/flashgitztom
https://www.twitter.com/flashgitzdon


Discord ►
https://discord.gg/b5ekXbK

