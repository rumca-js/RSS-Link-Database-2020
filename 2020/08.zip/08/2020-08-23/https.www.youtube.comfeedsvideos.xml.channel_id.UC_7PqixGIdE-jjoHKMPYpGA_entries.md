# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Skąd wiemy gdzie są atomy (w krysztale)?
 - [https://www.youtube.com/watch?v=rbEo2tSS3XU](https://www.youtube.com/watch?v=rbEo2tSS3XU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2020-08-24 00:00:00+00:00

Kup koszulkę ► https://naukowybelkot.shoplo.com/ 
Patronite ► https://patronite.pl/NaukowyBelkot 
Mix audio ► http://ratstudios.pl/
Moja książka ► https://geny.altenberg.pl

Nieprzerwanie zachwyca mnie w nauce wiele rzeczy. W chemii, z którą mam już kilkunastoletni i poświadczony papierami związek - również. Ale nie to, co z czym reaguje... przynajmniej nie najbardziej. Na szczycie mojej listy są cząsteczki i atomy. Konkretnie to, że znamy ich kształt i położenie. Oczywiście szczyt listy okupują razem z technikami, które umożliwiają rozwikłanie tych zagadek kształtu. Dziś film o jednej z nich.

Subskrypcja ► https://youtube.com/c/UwagaNaukowyBelkot
Facebook ► https://facebook.com/UwagaNaukowyBelkot
Twitter ► https://twitter.com/NaukowyBelkot
Instagram ► https://www.instagram.com/NaukowyBelkot/

Wyłącznie Naukowy Bełkot ► https://goo.gl/Do7VCc
Grupa na facebooku ► https://goo.gl/HP8J83
===
Timestamp:

0:00 Dwie historie
2:35 Podróż do wnętrza kryształu
5:20 Definicje
9:08 Serce dziedziny
15:13 Jak to się robi z kryształami?
19:00 Zdjęcie i co dalej?
21:27 Porządek pośród symetrii
29:32 Ogłoszenie

===
Źródła (wybrane):
Z. Bojarski i in. - Krystalografia
Dieter Schwarzenbach - The success story of crystallography

