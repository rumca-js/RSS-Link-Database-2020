# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Jennifer Garner wows in dance duet with ballerina
 - [https://www.cnn.com/videos/entertainment/2020/08/23/jennifer-garner-tiler-peck-grease-dance-ballet-eg-orig.cnn](https://www.cnn.com/videos/entertainment/2020/08/23/jennifer-garner-tiler-peck-grease-dance-ballet-eg-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-23 23:01:50+00:00

Actress Jennifer Garner debuted a special dance routine to "We Go Together" from the film "Grease" with her friend Tiler Peck, who is a principal dancer for the New York City Ballet.

## Zakaria to Jared Kushner: Didn't Netanyahu outsmart you?
 - [https://www.cnn.com/videos/politics/2020/08/23/fareed-zakaria-kushner-israel-uae-gps-vpx.cnn](https://www.cnn.com/videos/politics/2020/08/23/fareed-zakaria-kushner-israel-uae-gps-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-23 20:11:06+00:00

CNN's Fareed Zakaria speaks to White House adviser and President Trump's son-in-law Jared Kushner about the diplomatic agreement between Israel and the United Arab Emirates, and the push to sell US fighter jets to the UAE.

## Gulf Coast may be hit by two storms
 - [https://www.cnn.com/2020/08/23/weather/marco-laura-gulf-coast-weather-forecast-sunday/index.html](https://www.cnn.com/2020/08/23/weather/marco-laura-gulf-coast-weather-forecast-sunday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-23 19:27:04+00:00

The Gulf Coast will get pummeled by a pair of hurricanes this week, bringing torrential rain, fierce winds and ferocious storm surges.

## 'The Batman' debuts its first trailer with Robert Pattinson as a gritty Dark Knight
 - [https://www.cnn.com/2020/08/23/media/batman-trailer-trnd/index.html](https://www.cnn.com/2020/08/23/media/batman-trailer-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-23 19:26:46+00:00

"I'm vengeance."

## Belarus opposition protests begin amid heavy police presence
 - [https://www.cnn.com/2020/08/23/europe/belarus-protest-sunday-intl/index.html](https://www.cnn.com/2020/08/23/europe/belarus-protest-sunday-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-23 18:33:25+00:00

Belarus's embattled government vowed to take control of national monuments to protect them from protesters, as opposition demonstrators gathered in Minsk on Sunday.

## Inside Belarus' protests: If we are not free tomorrow, we will never be free
 - [https://www.cnn.com/videos/world/2020/08/23/belarus-protest-election-lukashenko-minsk-pleitgen-pkg.cnn](https://www.cnn.com/videos/world/2020/08/23/belarus-protest-election-lukashenko-minsk-pleitgen-pkg.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-23 18:30:04+00:00

Protesters in Belarus say they won't give up until there is a new election, insisting the recent vote that re-elected Alexander Lukashenko was rigged. CNN's Fred Pleitgen is in Minsk.

## 304th-ranked Sophia Popov clinches British Open to win her first major
 - [https://www.cnn.com/2020/08/23/golf/sophia-popov-womens-open-golf-spt-intl/index.html](https://www.cnn.com/2020/08/23/golf/sophia-popov-womens-open-golf-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-23 18:29:44+00:00

Sophia Popov clinched a surprise victory at the British Open on Sunday, winning her first major by two shots.

## Apple apologizes after another controversy over its app store
 - [https://www.cnn.com/2020/08/23/tech/wordpress-apple-app-store/index.html](https://www.cnn.com/2020/08/23/tech/wordpress-apple-app-store/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-23 18:25:32+00:00

Apple is apologizing after it found itself in yet another controversy this weekend over its app store.

## The UAE-Israel announcement proves the folly of warming to Iran
 - [https://www.cnn.com/2020/08/23/opinions/uae-israel-announcement-iran-opinion-oren/index.html](https://www.cnn.com/2020/08/23/opinions/uae-israel-announcement-iran-opinion-oren/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-23 18:22:49+00:00

The impending peace agreement between the United Arab Emirates and Israel is a game-changer for the entire Middle East.

## Stelter: We can expect a 'grievance convention' at RNC
 - [https://www.cnn.com/videos/media/2020/08/23/asymmetric-lying-political-leaders-rnc-dnc-stelter-commentary-rs-vpx.cnn](https://www.cnn.com/videos/media/2020/08/23/asymmetric-lying-political-leaders-rnc-dnc-stelter-commentary-rs-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-23 17:22:15+00:00

CNN's Brian Stelter tells us what we can expect from the upcoming Republican convention and makes his case for "asymmetric lying."

## President Trump has used this word over 250 times this year
 - [https://www.cnn.com/videos/media/2020/08/23/trump-word-hoax-weapon-stelter-rs-vpx.cnn](https://www.cnn.com/videos/media/2020/08/23/trump-word-hoax-weapon-stelter-rs-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-23 17:10:37+00:00

CNN's Brian Stelter and author Peter Pomerantsev examine the corrosive effects of President Trump's repeated use of the word "hoax" to describe any criticism of the President.

## President Donald Trump's sister criticizes him in secret audio
 - [https://www.cnn.com/2020/08/22/politics/maryanne-trump-barry-donald-trump-mary-trump/index.html](https://www.cnn.com/2020/08/22/politics/maryanne-trump-barry-donald-trump-mary-trump/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-23 16:35:52+00:00

Maryanne Trump Barry called her brother President Donald Trump "cruel" and appeared to confirm her niece Mary Trump's previous allegations that he had a friend take his SATs to get into college, according to transcripts and audio excerpts obtained exclusively by the Washington Post.

## Airline pilots are worried about their jobs. So some are learning to fly drones
 - [https://www.cnn.com/2020/08/23/business/drone-pilots-gig-economy/index.html](https://www.cnn.com/2020/08/23/business/drone-pilots-gig-economy/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-23 14:11:46+00:00

With mass layoffs at US air carriers expected this fall, airline pilots like Michelle Bishop are anticipating the unwelcome reality that pilots like herself may soon be left without stable work.

## 'It's not even war. It's pathetic. We are traumatized.'
 - [https://www.cnn.com/2020/08/23/opinions/loving-lebanon-ward-opinion/index.html](https://www.cnn.com/2020/08/23/opinions/loving-lebanon-ward-opinion/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-23 14:04:36+00:00

"This time, it's different," my Lebanese friend said.

## As world tops 23 million cases, US is still the worst affected
 - [https://www.cnn.com/world/live-news/coronavirus-pandemic-08-23-20-intl/index.html](https://www.cnn.com/world/live-news/coronavirus-pandemic-08-23-20-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-23 14:01:05+00:00



## At least 13 dead in club stampede breaking Covid-19 restrictions
 - [https://www.cnn.com/2020/08/23/americas/peru-nighclub-covid-stampede-intl-scli/index.html](https://www.cnn.com/2020/08/23/americas/peru-nighclub-covid-stampede-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-23 13:00:29+00:00

At least 13 people have been killed and three others injured in a stampede at a nightclub in Lima, Peru, as partygoers attempted to escape a police raid on the venue, according to Orlando Velasco Mujica, general of the Peruvian National Police.

## TikTok will sue the Trump administration over its plan to ban the app
 - [https://www.cnn.com/2020/08/22/tech/tiktok-trump-court-challenge/index.html](https://www.cnn.com/2020/08/22/tech/tiktok-trump-court-challenge/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-23 09:30:25+00:00



## London's Tower Bridge gets stuck open, causing traffic chaos
 - [https://www.cnn.com/travel/article/tower-bridge-stuck-intl-scli-gbr/index.html](https://www.cnn.com/travel/article/tower-bridge-stuck-intl-scli-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-23 09:15:45+00:00

Tower Bridge, one of London's most famous landmarks, was stuck open Saturday afternoon due to "mechanical failure," causing traffic chaos in the city.

## Nearly 1 million acres are burning due to wildfires across California, official says
 - [https://www.cnn.com/2020/08/23/us/california-wildfires-sunday/index.html](https://www.cnn.com/2020/08/23/us/california-wildfires-sunday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-23 08:06:51+00:00

Wildfires in California have burned through nearly 1 million acres -- and there's no end in sight as thousands of firefighters struggle to contain the blazes and more emerge.

## Algorithms can drive inequality. Just look at Britain's school exam chaos
 - [https://www.cnn.com/2020/08/23/tech/algorithms-bias-inequality-intl-gbr/index.html](https://www.cnn.com/2020/08/23/tech/algorithms-bias-inequality-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-23 04:01:23+00:00

Philip blames an algorithm for potentially losing his place to study law at university.

## Trump shares emotional post after his brother's death
 - [https://www.cnn.com/videos/politics/2020/08/16/trump-brother-robert-dies-vpx.cnn](https://www.cnn.com/videos/politics/2020/08/16/trump-brother-robert-dies-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-23 03:16:00+00:00

Robert Trump, 71, the younger brother of President Donald Trump, died Saturday at a New York hospital, Donald Trump announced in a statement. Details of Robert Trump's illness have not been released, but he had been sick for several months, a person familiar with knowledge of the matter told CNN.

## Trump's niece: He is a psychologically deeply damaged man
 - [https://www.cnn.com/videos/politics/2020/07/18/mary-donald-trump-psychologically-damaged-sot-vpx-cpt.cnn](https://www.cnn.com/videos/politics/2020/07/18/mary-donald-trump-psychologically-damaged-sot-vpx-cpt.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-23 03:15:01+00:00

In an interview with CNN's Chris Cuomo, Mary Trump, President Donald Trump's niece, describes the President as a "psychologically damaged man" based on his upbringing and habits.

## Video shows Kanye campaign moments before missing deadline
 - [https://www.cnn.com/videos/politics/2020/08/22/kanye-west-campaign-wisconsin-ballot-deadline-smerconish-vpx.cnn](https://www.cnn.com/videos/politics/2020/08/22/kanye-west-campaign-wisconsin-ballot-deadline-smerconish-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-23 00:16:32+00:00

The Wisconsin Elections Commission voted to keep Kanye West off the general election presidential ballot after determining the hip hop star had filed late, a move that keeps him from potentially competing in a key battleground state in November.

## China's Communist Party is a threat to the world, says former elite insider
 - [https://www.cnn.com/2020/08/22/asia/chinas-communist-party-threat-world-intl-hnk/index.html](https://www.cnn.com/2020/08/22/asia/chinas-communist-party-threat-world-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-23 00:07:41+00:00



