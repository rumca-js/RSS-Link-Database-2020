# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## The Truth About "Trading Gurus" From a Hedge Fund Manager
 - [https://www.youtube.com/watch?v=JfP4rVsmL_Q](https://www.youtube.com/watch?v=JfP4rVsmL_Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-08-24 00:00:00+00:00

Patrick Boyle is a hedge fund manager at Palomar Fund, author, university professor and former investment banker with over a decade of experience. 

In this video we talk trading gurus, fake gurus, reasonable returns, the 2% delusion, Tim Sykes, Day Traders, Jeff Bishop and Jason Bond...Is making money online with day trading reasonable in 2020? 

PATRICK’S YOUTUBE CHANNEL
https://www.youtube.com/c/PatrickBoyleOnFinance

Reading List:

Victor Niederhoffer, Education of a Speculator (1998) https://amzn.to/3ddWAEG

Jack Schwager, Market Wizards Series https://amzn.to/3a89diH

Jack Schwager, Market Sense And Nonsense (2013) https://amzn.to/2wpaHXb

Nassim Nicholas Taleb, Fooled By Randomness (2007) https://amzn.to/2x9yI4G

Victor Niederhoffer, Practical Speculation (2004) https://amzn.to/33BZChr

 Edward Thorp, A Man for All Markets (2017) https://amzn.to/2QhTKUJ

Gregory Zuckerman, The Man Who Solved the Market (2019) https://amzn.to/3de8ej3

Dimson, E., Marsh, P., and M. Staunton, Triumph of the Optimists: 101 Years of Global Investment Returns (2002) https://amzn.to/3djC6dR

Roger Lowenstein, When Genius Failed (2001) https://amzn.to/3dgQWS5

Howard Marks, The Most Important Thing  (2011) https://amzn.to/2IZPIge

Frank Partnoy, F.I.A.S.C.O. (1999) https://amzn.to/2x9zpLk

Michael Lewis, Liars Poker (1989)   -  The Big Short (2010) https://amzn.to/2xd6hmp

Burton Malkiel, A Random Walk Down Wall Street (2007) https://amzn.to/33xVlvL

Roger Lowenstein, Buffett: The Making of an American Capitalist (2008) https://amzn.to/2UpUSr3

Phil Knight, Shoe Dog (2018) https://amzn.to/2QnIvdw

Ray Dalio, Principles (2017)  https://amzn.to/2YqY9cA

Patricks' Books: 
Statistics for Traders: https://amzn.to/3eerLA0

Financial Derivatives: https://amzn.to/3fq8Bao

Corporate Finance: https://amzn.to/3fn3rvC

