# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Justice League: The Snyder Cut - Official Trailer (My Thoughts)
 - [https://www.youtube.com/watch?v=drEzDIiESZg](https://www.youtube.com/watch?v=drEzDIiESZg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-08-23 00:00:00+00:00

We have our first second trailer for Zack Snyder's JUSTICE LEAGUE! Let's talk about it!

Watch the trailer here: https://www.youtube.com/watch?v=u77M-oANRtQ&t=34s

#TheSnyderCut #Fandome

## The Batman - Official Trailer (My Thoughts)
 - [https://www.youtube.com/watch?v=MGthLOcmZH0](https://www.youtube.com/watch?v=MGthLOcmZH0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-08-23 00:00:00+00:00

Another trailer for an anticipated DC movie. Here are my thoughts on the 1st trailer for THE BATMAN!

Watch the trailer here: https://www.youtube.com/watch?v=8fxbzD_CSD8

#Batman #TheBatman

