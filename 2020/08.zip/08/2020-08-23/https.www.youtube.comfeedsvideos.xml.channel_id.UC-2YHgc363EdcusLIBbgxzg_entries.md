# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## Rise Of The Living Robots | Answers With Joe
 - [https://www.youtube.com/watch?v=DeR43H-lAf8](https://www.youtube.com/watch?v=DeR43H-lAf8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2020-08-24 00:00:00+00:00

Hey! Get 3 months of ExpressVPN for free when you sign up at http://www.expressvpn.com/joescott
Our traditional view of robots as metal machines with computer brains is pretty hard-wired (pun intended) into the human psyche. But there are reasons to believe that living robots - robots made of soft or living tissue - might be the better option. Here's why.

Check out Emmett Short's video on molecular machines to go along with this video here: 
https://youtu.be/Nec82dkWfVo

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe


#protectthetubes

