# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Best of the Week - August 16, 2020 - Joe Rogan Experience
 - [https://www.youtube.com/watch?v=-rRVA7PmBqo](https://www.youtube.com/watch?v=-rRVA7PmBqo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-08-23 00:00:00+00:00

#1527 w/David Blaine:
https://www.youtube.com/watch?v=NY3Zg37nIHo

#1528 w/Nikki Glaser:
https://www.youtube.com/watch?v=KUCkrZKslr4

#1529 w/ Whitney Cummings & Annie Lederman
https://www.youtube.com/watch?v=5UXpbbX9-Wo

