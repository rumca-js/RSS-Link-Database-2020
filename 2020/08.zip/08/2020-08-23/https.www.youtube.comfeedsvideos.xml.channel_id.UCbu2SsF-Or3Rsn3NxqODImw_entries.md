# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Hyper Scape Early Game Strats from a Dev and Pro | The Pod
 - [https://www.youtube.com/watch?v=rArYVUWiHWk](https://www.youtube.com/watch?v=rArYVUWiHWk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-08-24 00:00:00+00:00

(Presented by Hyper Scape) The opening moments of any Battle Royale game are pivotal for victory, so let a developer of the game and pro player TannerSlays give you the tips you need to set yourself up for a win!

## The Sims' Darkest Mystery: The Fate Of Its Most Famous Sim | Lorescape
 - [https://www.youtube.com/watch?v=haD3RFUu9gg](https://www.youtube.com/watch?v=haD3RFUu9gg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-08-24 00:00:00+00:00

On this episode of Lorescape, we take a closer look at the mystery behind one of the most famous Sims of all time, Bella Goth.

While The Sims games are known for their character customization and house decoration, the stranger lore beneath the surface reveals quite a few bizarre mysteries and relationships. From aliens and vampires to supervillains, the world of SimNation and the lore behind it runs much deeper than you know.

## 7 Wildest Moments From The Black Ops Series
 - [https://www.youtube.com/watch?v=-um8jVqzkxM](https://www.youtube.com/watch?v=-um8jVqzkxM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-08-23 00:00:00+00:00

Call Of Duty: Black Ops has gone to some wild places, here are a few of the most memorable.

00:00 - Intro
00:13 - Number 1 Mind Control
00:48 - Number 2: Mason Kills JFK?
01:20- Number 3: Woods Shoots Mason
02:25 - Number 4: Avenged Sevenfold's "Carry On" Music Video
03:03 Number 5: The Ending Of Black Ops III (Like...All of it)
04:04: Number 6: That Time You Killed Castro...For A Second
04:32: Number 7 Activision Gets Sued

The Call Of Duty: Black Ops series, developed by Treyarch and published by Activision, has taken players on covert missions around the globe with themes focusing on conspiracy theories, paranoia, and alternate history. With the new Call Of Duty game coming in 2020 reportedly focusing on the Cold War era, we take you through some of the wildest things that have happened in and around the series so far.

## Suicide Squad: Kill the Justice League - Official Cinematic Reveal Trailer
 - [https://www.youtube.com/watch?v=70pnfnH3Afo](https://www.youtube.com/watch?v=70pnfnH3Afo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-08-23 00:00:00+00:00

The creators of the Batman: Arkham series are back with a brand new action-adventure shooter. The
most dangerous villains in the DC Universe have been forced to team up and take on a new mission: Kill the Justice League. Create Chaos in Metropolis. You are the Suicide Squad.
Coming in 2022 to PS5, Xbox Series X, and PC.

