# Source:Chris Ray Gun, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCctjGdm2NlMNzIlxz02IsXA, language:en-US

## HALO 3 CUSTOM GAMES w/ NakobJakob, Edward Burbank, and Friends
 - [https://www.youtube.com/watch?v=jPCZsGLOJlY](https://www.youtube.com/watch?v=jPCZsGLOJlY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCctjGdm2NlMNzIlxz02IsXA
 - date published: 2020-08-24 00:00:00+00:00

Go to https://buyraycon.com/raygun for 15% off your order! Brought to you by Raycon.

Are you stressed out by the sheer unpredictability of the cold unfeeling world that stares at you through your filthy windows? Well, why not relax and take a load off with me and some other YouTube friends as we delve into some classic Halo 3 Custom Games.

Come over to twitch.tv/chrisraygun to see this shit live!

Thanks to NakeyJakey, Eddy Burback, ModestCube, CrankGameplays, and Bruce Greene for stopping by and having a gay old time. It was fun. 

Noodle as Paul - https://www.youtube.com/c/LegitimateNoodle

SHIRTS ► https://teespring.com/stores/chris-ray-gun
TWITTER ► https://twitter.com/ChrisRGun
FACEBOOK ► http://on.fb.me/15OyE7z
TWITCH ► http://www.twitch.tv/chrisraygun
PATREON ► https://www.patreon.com/ChrisRay
SUBREDDIT ► https://www.reddit.com/r/ChrisRayGun/
SACRED SYMBOLS  ► https://apple.co/2Rqmklc
SECOND CHANNEL ► https://www.youtube.com/channel/UCiNediqB-JC_TjbsB4hJuHA

