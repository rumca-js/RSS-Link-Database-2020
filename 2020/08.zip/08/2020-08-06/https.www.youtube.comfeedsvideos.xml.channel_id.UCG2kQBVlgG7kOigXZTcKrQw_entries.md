# Source:Kołem się toczy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw, language:pl-PL

## TOP 10 spływów kajakowych w Polsce! (gość: Aleksander Doba i przyjaciele) 🛶
 - [https://www.youtube.com/watch?v=Edaqi0rLJ2E](https://www.youtube.com/watch?v=Edaqi0rLJ2E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw
 - date published: 2020-08-06 00:00:00+00:00

Pływacie kajakami? Gdzie było najlepiej? Zapraszam na 10 świetnych rzek na spływ kajakowy :)

Dziękuję wszystkim gościom za podzielenie się swoimi typami najciekawszych spływów kajakowych w Polsce. Mam nadzieję, że dzięki temu filmowi będziecie mieli gdzie jeździć na spływy co najmniej przez kilka sezonów.

Podziękowania kolejno:
Zdzich Rabenda https://tyswidziol.pl/
Aleksandrowi Dobie https://aleksanderdoba.pl/
Wędrowne Motyle @Wędrowne Motyle 
Gdzie Bądzie @GDZIE BĄDŹ 
Bartek Szaro https://paragonzpodrozy.pl/17420/san-splyw-dlaczego-warto/

Jeśli chodzi o wspomniane w filmie wpisy blogowe dotyczące konkretnych spływów kajakowych, to lecimy z tematem. Wspomniany wpis o Sanie Bartka macie powyżej. Następnie podrzucam wpis o spływie rzeką Pilicą.
https://kolemsietoczy.pl/pilica-kajak-splyw-porady-informacje/

Kolejny wpis jest o spływaniu kajakiem po Brdzie.
https://kolemsietoczy.pl/brda-kajaki-porady-informacje-splyw-kajakowy-rzeka/

Natomiast o kajakach / canoe po Odrze przeczytacie tutaj:
https://kolemsietoczy.pl/kajaki-canoe-wycieczki-plywanie-dolina-dolnej-odry-ciekawe-miejsca-obok-szczecina/

Dajcie znać, która rzeka jest Waszym zdaniem najciekawsza? Gdzie byście się wybrali na kajak? Nad Wdę, Dunajec, Nidę? Albo bardziej przemawia do Was majestatyczna rzeka Bug lub zielona Czarna Hańcza? 

Zapraszam do innych filmów!

►►Zachęcam do subskrypcji: http://bit.ly/2cmWbSO 

Zapraszam też na:
Facebook: http://bit.ly/2flU84f
Instagram: http://bit.ly/2eTrIMc
Blog: http://kolemsietoczy.pl/

Spis treści:
00:00 - 00:46 Najlepsze rzeki na spływ kajakiem w Polsce?
00:47 - 01:40 Rzeka Brda - spływy kajakiem
01:41 - 03:47 Spływ Bugiem
03:47 - 04:08 Spływy kajakiem Nida i 
04:08 - 05:49 Pilica kajakami i biwak na dziko przy rzece
05:50 - 06:25 Olek Doba poleca - rzeka Drawa kajakiem
06:51 - 07:58 Rzeka Wda kajakiem
07:59 - 09:01 Suwalszczyzna i Czarna Hańcza kajakami
09:02 - 10:12 Spływ Odrą
10:13 - 11:36 Rzeka San kajakiem

