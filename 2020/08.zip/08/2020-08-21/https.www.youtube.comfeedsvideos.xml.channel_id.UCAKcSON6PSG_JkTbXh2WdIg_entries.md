# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Dessa - three concert performances at The Current (2011, 2013, 2018)
 - [https://www.youtube.com/watch?v=u10jsrB9Oyo](https://www.youtube.com/watch?v=u10jsrB9Oyo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-08-22 00:00:00+00:00

This week's Friday Night Concerts pick is Dessa's 2013 "Parts of Speech" album-release show recorded live at the Fitzgerald Theater in St. Paul. We've enjoyed many great performances by Dessa at The Current over the years, so in anticipation of this week's Friday Night Concerts, we're sharing three live performances by Dessa, recorded in 2011, 2013 and 2018.

SONGS PERFORMED
0:00 "551" (Fitzgerald Theater, 2011)
4:06 "The Man I Knew" (Fitzgerald Theater, 2013)
7:43 "Good Grief" (MPR Forum, 2018)

CREDITS
Video & Photo: Nate Ryan; Chris Hadland; Chris Worlow; Once Light Collective; Steel Brooks; Peter Ecklund; Erik Stromstad
Audio: Michael DeMark
Production: Derrick Stevens

FIND MORE:
2011 Fitzgerald Theater concert: https://www.thecurrent.org/feature/2011/11/08/dessa-live-fitz
2013 Fitzgerald Theater concert: https://www.thecurrent.org/feature/2013/07/10/dessa-fitzgerald-theater-performance-broadcast
2018 MPR Forum session:
https://www.thecurrent.org/feature/2018/02/21/dessa-the-making-of-chime

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Dirty Projectors - Virtual Session
 - [https://www.youtube.com/watch?v=efWzoMugdJ0](https://www.youtube.com/watch?v=efWzoMugdJ0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-08-21 00:00:00+00:00

Dirty Projectors join The Current's Mac Wilson for a virtual session featuring tracks from this year's 5EPs series.

Songs Played:
09:01 Lose Your Love
11:54 Overlord
14:41 On The Breeze

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Why did it take 18 years to file charges in the murder of Jam Master Jay? (The Current Music News)
 - [https://www.youtube.com/watch?v=FXdYWZTwsQs](https://www.youtube.com/watch?v=FXdYWZTwsQs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-08-21 00:00:00+00:00

August 20, 2020: News broke this week that criminal charges have been filed in the 2002 killing of Run-DMC's Jam Master Jay. Why has this crime taken two decades to crack?
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

