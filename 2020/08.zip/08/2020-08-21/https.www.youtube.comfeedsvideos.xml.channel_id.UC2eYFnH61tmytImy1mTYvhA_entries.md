# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## Logically, Linux can't exist. CHECKMATE GNUTARDS!
 - [https://www.youtube.com/watch?v=jLKFLFErtk8](https://www.youtube.com/watch?v=jLKFLFErtk8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-08-21 00:00:00+00:00

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE: https://lukesmith.xyz/donate 💰😎👌💯
OR affiliate links to things l use:
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://brave.com/luk005 Get the Brave browser.
https://lbry.tv/$/invite/@Luke View my videos on LBRY. Get a bonus for joining.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase. We both get $10 in Bitcoin when you buy or sell $100 in cryptocurrencies.

## The Boomer Economy is Over!
 - [https://www.youtube.com/watch?v=WapemYM5QQs](https://www.youtube.com/watch?v=WapemYM5QQs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-08-21 00:00:00+00:00

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE: https://lukesmith.xyz/donate 💰😎👌💯
OR affiliate links to things l use:
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://brave.com/luk005 Get the Brave browser.
https://lbry.tv/$/invite/@Luke View my videos on LBRY. Get a bonus for joining.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase. We both get $10 in Bitcoin when you buy or sell $100 in cryptocurrencies.

