# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Unhinged - Movie Review
 - [https://www.youtube.com/watch?v=UYMCtr5HybI](https://www.youtube.com/watch?v=UYMCtr5HybI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-08-22 00:00:00+00:00

A movie...IN A THEATER!!!!!! Anyhow, here's my review of Russell Crowe going nuts in UNHINGED!

#Unhinged

