# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## How TikTok investors are trolling Microsoft
 - [https://www.youtube.com/watch?v=fnatuVGwono](https://www.youtube.com/watch?v=fnatuVGwono)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2020-08-21 00:00:00+00:00

Sponsored by CuriosityStream. Sign up here and get access to Nebula for free with your subscription: https://curiositystream.com/tfc 

You can check out Nebula at http://watchnebula.com but the bundle means you get both services for the same price, and because CuriosityStream is our sponsor it’s a better way to support us. 

[[[ QUIZ ]]]: 

Weekly tech quiz: 
https://crrowd.com/quiz 

[[[ TECHALTAR LINKS ]]]: 

Merch: 
http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 

If you want to support TechAltar directly: 
https://flattr.com/@techaltar 

[[[ ATTRIBUTIONS ]]]: 

Music by Edemski: https://soundcloud.com/edemski


[[[ TIMESTAMPS ]]]: 

0:00 Intro 
0:38 Oracle wants TikTok?
4:17 """BlackBerry""" returns
6:17 Huawei loses MediaTek

