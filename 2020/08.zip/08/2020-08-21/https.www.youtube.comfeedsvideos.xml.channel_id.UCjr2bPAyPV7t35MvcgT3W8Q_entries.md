# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## Signal - the most secure messenger for everyone
 - [https://www.youtube.com/watch?v=3eC4Hp4MNBA](https://www.youtube.com/watch?v=3eC4Hp4MNBA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2020-08-22 00:00:00+00:00

Signal Private Messenger is the most secure messaging app you can install on your phone. 
Support me through Patreon: https://www.patreon.com/thehatedone 
Join my channel and become a member to enjoy perks https://www.youtube.com/channel/UCjr2bPAyPV7t35MvcgT3W8Q/join

- or donate anonymously:

Monero:
84DYxU8rPzQ88SxQqBF6VBNfPU9c5sjDXfTC1wXkgzWJfVMQ9zjAULL6rd11ASRGpxD1w6jQrMtqAGkkqiid5ef7QDroTPp

Bitcoin: 
1FuKzwa5LWR2xn49HqEPzS4PhTMxiRq689

Ethereum:
0x6aD936198f8758279C2C153f84C379a35865FE0F

Some good resources for further understanding of Signal:
Signal Tutorials by Infosec Bytes: https://www.youtube.com/watch?v=46ozjP-R2-E
- on Android: https://www.youtube.com/watch?v=XQzhWbnop8c
- on iOS: https://www.youtube.com/watch?v=kiX8lGJK3Ww
Introduction to Signal: https://freedom.press/news/signal-beginners/  
Signal PINs: https://support.signal.org/hc/en-us/articles/360007059792-Signal-PINs 
PIN-related feature: https://signal.org/blog/secure-value-recovery/
Moxie on Signal's future (unfortunately, not decentralized): https://signal.org/blog/looking-back-as-the-world-moves-forward/ 
Some news coverage on the PIN feature:
https://www.zdnet.com/article/signal-to-move-away-from-phone-numbers-as-user-ids/
https://www.vice.com/en_us/article/pkyzek/signal-new-pin-feature-worries-cybersecurity-experts 
https://www.forbes.com/sites/kateoflahertyuk/2020/05/21/is-this-new-signal-feature-enough-to-make-you-ditch-whatsapp/ 
Moxie's take on the critical reception of the PIN feature: https://mobile.twitter.com/moxie/status/1281353114063257600 

Credits
Music by: CO.AG Music https://www.youtube.com/channel/UCcavSftXHgxLBWwLDm_bNvA
Follow me:
https://twitter.com/The_HatedOne_
https://www.bitchute.com/TheHatedOne/
https://www.reddit.com/r/thehatedone/
https://www.minds.com/The_HatedOne

The footage and images featured in the video were for critical analysis, commentary and parody, which are protected under the Fair Use laws of the United States Copyright act of 1976.

