# Source:Hugh Jeffreys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA, language:en-US

## New Sealed In-box iPhone Scam - WATCH OUT!
 - [https://www.youtube.com/watch?v=97sT52Kof1M](https://www.youtube.com/watch?v=97sT52Kof1M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA
 - date published: 2020-08-22 00:00:00+00:00

Some cunning scammers have been selling low quality refurbished phones as "new" and "sealed" on online sites like eBay. They go to great lengths to reapply the plastic wrap and create fake boxes to trick people into believing their phone is new when in fact its far from. We are going to be taking a look at this one I was given after the previous owner upgraded to a newer model. While of cause assessing and dissecting the phone to see whats going on inside.
--------------------------------------Socials-------------------------------------
Website: https://www.hughjeffreys.com 
Twitter: https://twitter.com/hughjeffreys
Instagram: http://instagram.com/hughjeffreys
---------------------------------------Links---------------------------------------
Get parts, tools, and thousands of free repair guides from iFixit at: 
    https://iFixit.com/hughjeffreys
Australia Store: https://ifix.gd/2FPxhKy
(DISCLAIMER: This description contains affiliate links, which means that if you click on one of the product links, l will receive a small commission.)

