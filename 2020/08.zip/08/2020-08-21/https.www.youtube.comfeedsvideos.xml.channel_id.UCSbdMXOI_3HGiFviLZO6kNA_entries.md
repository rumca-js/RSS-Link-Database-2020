# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## This is BAD for VR
 - [https://www.youtube.com/watch?v=LSMCTarhvjY](https://www.youtube.com/watch?v=LSMCTarhvjY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-08-21 00:00:00+00:00

Facebook makes the decision that all Oculus accounts are forced to become Facebook accounts. Should you be worried? Should you be angry? Does it even matter? Here's everything on it. 

my links-
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill

Links I used-
https://www.oculus.com/blog/a-single-way-to-log-into-oculus-and-unlock-social-features/

https://www.eff.org/deeplinks/2014/09/facebooks-real-name-policy-can-cause-real-world-harm-lgbtq-community

https://www.roadtovr.com/oculus-guarantee-promise-facebook-log-in/

https://twitter.com/oculus/status/1295769244894785538

