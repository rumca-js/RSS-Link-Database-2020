# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Authenticity & Creativity with Russell Brand & Bill Burr
 - [https://www.youtube.com/watch?v=_JIKMJYJWno](https://www.youtube.com/watch?v=_JIKMJYJWno)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-08-21 00:00:00+00:00

From my #UnderTheSkin podcast with #Bill Burr!
You can listen to the entire podcast over on Luminary: http://luminary.link/russell

Bill can currently be seen in Judd Apatow and Pete Davidson’s heartfelt comedy, The King of Staten Island. The movie is available to own on Digital now and will released on Blu-ray & DVD – featuring over two hours of bonus content and alternate endings - on August 25th in the US and September 14th in the UK.

https://uni.pictures/TheKingOfStatenIsland

@BillBurr on Twitter, @WilfredBurr on Instagram

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

