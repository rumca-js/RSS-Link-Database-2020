# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Pro-Life Arguments That Reach The Hopelessly Woke
 - [https://www.youtube.com/watch?v=PholZa77K_o](https://www.youtube.com/watch?v=PholZa77K_o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-08-22 00:00:00+00:00

Kyle and Ethan talk with Students For Life President, Kristan Hawkins about violence against the preborn and human rights.

FULL ▶️  https://youtu.be/36_IRU4Y4Mk

## Twitter-Gate/Trump Stamps/Students For Life News Show 8.21.2020
 - [https://www.youtube.com/watch?v=36_IRU4Y4Mk](https://www.youtube.com/watch?v=36_IRU4Y4Mk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-08-21 00:00:00+00:00

In this episode of The Babylon Bee podcast, Kyle and Ethan talk about the week’s biggest stories like Twitter “accidentally” suspending the Babylon Bee for the web’s darkest 90 minutes, the humble Postal Service being the focus of all the nation’s fire and fury, and how students got arrested for the peaceful protest with sidewalk chalk outside a Planned Parenthood. Kristan Hawkins, President for Students For Life, talks to The Babylon Bee and silliness ensues.  

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Gain Access to the Exclusive Content and Writing Forum: https://babylonbee.com/plans

The Official Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

Follow Students for Life of America & Kristan Hawkins:
Twitter: http://twitter.com/studentsforlife
Twitter: http://twitter.com/sflaction
Twitter: http://twitter.com/kristanhawkins

Facebook: http://facebook.com/studentsforlife
Facebook: http://facebook.com/studentsforlifeaction
Facebook: http://facebook.com/HawkinsKristan

Instagram: https://www.instagram.com/studentsforlifeaction/
Instagram: https://www.instagram.com/studentsforlife/
Instagram: https://www.instagram.com/kristanmercerhawkins

