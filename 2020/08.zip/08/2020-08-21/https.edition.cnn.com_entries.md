## US coronavirus deaths could top 6,000 a day by December in worst-case scenario, expert predicts
 - [https://edition.cnn.com/world/live-news/coronavirus-pandemic-08-21-20-intl#h_e869402891201d42d0937c0fe789a1df](https://edition.cnn.com/world/live-news/coronavirus-pandemic-08-21-20-intl#h_e869402891201d42d0937c0fe789a1df)
 - RSS feed: https://edition.cnn.com
 - date published: 2020-08-21 11:39:16+00:00

US coronavirus deaths could top 6,000 a day by December in worst-case scenario, expert predicts

