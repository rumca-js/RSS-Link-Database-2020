# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## The BEST Monitors of 2020 - LG 27GN950 Review
 - [https://www.youtube.com/watch?v=-1xu0IP35FI](https://www.youtube.com/watch?v=-1xu0IP35FI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-08-22 00:00:00+00:00

Pre-Order the DROP THX Panda Wireless headphones today at https://dro.ps/ltt-aug20-panda

Sign up for Private Internet Access VPN at https://lmg.gg/pialinus1

The LG 27GN950 is a gaming monitor that has it all: 4K, 144Hz, DisplayHDR 600, adaptive sync, and of course, RGB. But is it a better buy than the 240Hz Samsung Odyssey G7? Depends…

Check out the 27GN950(LG.com): https://bit.ly/31bfYwN
Buy LG 27GN950 on Amazon (PAID LINK): https://geni.us/yUUgBq

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1237450-what%E2%80%99s-the-best-monitor-in-2020/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Private Internet Access VPN: https://lmg.gg/pialinus2
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Our Gear on Amazon: https://geni.us/OhmF
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0 https://lmg.gg/fxHYK 
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://lmg.gg/Q9yyQ 
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://lmg.gg/8upii

## Flight Sim 2020 will CRUSH Your Gaming Rig- WAN Show August 21, 2020
 - [https://www.youtube.com/watch?v=u_dLt3-ycwo](https://www.youtube.com/watch?v=u_dLt3-ycwo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-08-21 00:00:00+00:00

Sign up for Private Internet Access VPN at https://lmg.gg/piawan

Learn more about Pulseway's Patch Management Software at: https://patch.pulseway.com/?rfid=linus_patch

Get the KernelCare & Extended Lifecycle Support* for CentOS® 6 Bundle today at https://lp.kernelcare.com/bundle-wan

Check out Carpool Critics, our new movie podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Podcast Download: https://dts.podtrac.com/redirect.mp3/traffic.libsyn.com/secure/linustechtips/Flight_Sim_2020_will_CRUSH_Your_Gaming_Rig-_WAN_Show_August_21_2020.mp3

Timestamps: (Credit to Lime12387)
00:00:32 Welcome to the WAN SHOW!
00:00:45 TOPICS     
00:02:50 ROLL THE INTRO
00:03:30 *Microsoft Flight Simulator 2020 - HEADLINE TOPIC*
00:17:50 *Facebook'en'ing of OCULUS - TOPIC*
00:24:55 *SPONSORS*
00:28:28 Back to the show!
00:28:41 *Back to Facebook*
00:35:40 *Apple supplying parts to independent repair shops (not as cut and dried as you might think) - TOPIC*
00:54:46  *XBOX Series X architecture deep dive - TOPIC*
01:04:11 *BREAKING NEWS... The RTX 3090 has been pictured - TOPIC*
01:09:38 ***UNSUBSCRIBE FROM LTT, you heard it here first.***
01:10:47 ***SUPERCHATS***
01:19:02 OUTRO 
01:19:09 Leafy (YouTuber) gets account terminated!
01:21:24 WifeySauce gets her own YouTube channel and raid ensues

