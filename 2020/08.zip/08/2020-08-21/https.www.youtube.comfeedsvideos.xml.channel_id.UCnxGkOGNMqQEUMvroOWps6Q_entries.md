# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Joe Rogan Reacts to Bryce Hall’s Sway House Shutdown
 - [https://www.youtube.com/watch?v=tNPWiBM-QAQ](https://www.youtube.com/watch?v=tNPWiBM-QAQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-08-21 00:00:00+00:00

Taken from JRE #1529 w/Whitney Cummings and Annie Lederman: https://youtu.be/5UXpbbX9-Wo

## Joe Rogan: Twitter is Going to Be Like Blockbuster Video
 - [https://www.youtube.com/watch?v=PRLaU2-TTW8](https://www.youtube.com/watch?v=PRLaU2-TTW8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-08-21 00:00:00+00:00

Taken from JRE #1529 w/Whitney Cummings and Annie Lederman: https://youtu.be/5UXpbbX9-Wo

## Joe on the David Blaine Podcast "He's a Master"
 - [https://www.youtube.com/watch?v=jZS2wt09snw](https://www.youtube.com/watch?v=jZS2wt09snw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-08-21 00:00:00+00:00

Taken from JRE #1529 w/David Blaine & Annie Lederman:
https://youtu.be/5UXpbbX9-Wo

