## US tells Kenya to publicly support Israel or forget free trade deal
 - [https://www.theeastafrican.co.ke/tea/news/east-africa/us-tells-kenya-to-support-israel-or-forget-free-trade-deal-2304192](https://www.theeastafrican.co.ke/tea/news/east-africa/us-tells-kenya-to-support-israel-or-forget-free-trade-deal-2304192)
 - RSS feed: www.theeastafrican.co.ke
 - date published: 2020-08-21 12:51:44+00:00



