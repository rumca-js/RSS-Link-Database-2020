# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## CNN [#195] Któremu księdzu można ufać?
 - [https://www.youtube.com/watch?v=7SJvyHbHzmM](https://www.youtube.com/watch?v=7SJvyHbHzmM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-08-22 00:00:00+00:00

#cnn #kazaniedookienka  @Langustanapalmie 

Kazanie XXI Niedzielę zwykłą, Rok A

1. czytanie (Iz 22, 19-23)

Tak mówi Pan do Szebny, zarządcy pałacu:
«Gdy strącę cię z twego urzędu i przepędzę cię z twojej posady, tego dnia powołam sługę mego, Eliakima, syna Chilkiasza. Oblokę go w twoją tunikę, przepaszę go twoim pasem, twoją władzę oddam w jego ręce; on będzie ojcem dla mieszkańców Jeruzalem oraz dla domu Judy. Położę klucz domu Dawidowego na jego ramieniu; gdy on otworzy, nikt nie zamknie, gdy on zamknie, nikt nie otworzy. Wbiję go jak kołek na miejscu pewnym; i stanie się on tronem chwały dla domu swego ojca».

2. czytanie (Rz 11, 33-36)

O głębokości bogactw, mądrości i wiedzy Boga! Jakże niezbadane są Jego wyroki i nie do wyśledzenia Jego drogi! Kto bowiem poznał myśl Pana albo kto był Jego doradcą? Lub kto Go pierwszy obdarował, aby nawzajem otrzymać odpłatę? Albowiem z Niego i przez Niego, i dla Niego jest wszystko. Jemu chwała na wieki! Amen.

Ewangelia (Mt 16, 13-20)

Gdy Jezus przyszedł w okolice Cezarei Filipowej, pytał swych uczniów: «Za kogo ludzie uważają Syna Człowieczego?» A oni odpowiedzieli: «Jedni za Jana Chrzciciela, inni za Eliasza, jeszcze inni za Jeremiasza albo za jednego z proroków». Jezus zapytał ich: «A wy za kogo Mnie uważacie?» Odpowiedział Szymon Piotr: «Ty jesteś Mesjasz, Syn Boga żywego». Na to Jezus mu rzekł: «Błogosławiony jesteś, Szymonie, synu Jony. Albowiem nie objawiły ci tego ciało i krew, lecz Ojciec mój, który jest w niebie. Otóż i Ja tobie powiadam: Ty jesteś Piotr, czyli Opoka, i na tej opoce zbuduję Kościół mój, a bramy piekielne go nie przemogą. I tobie dam klucze królestwa niebieskiego; cokolwiek zwiążesz na ziemi, będzie związane w niebie, a co rozwiążesz na ziemi, będzie rozwiązane w niebie».
Wtedy surowo zabronił uczniom, aby nikomu nie mówili, że On jest Mesjaszem.

________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

♫ Słuchaj jako PODCAST Langusty: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
iTunes → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWHx

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#590] Pomimo
 - [https://www.youtube.com/watch?v=9Q4THBZ-Zn4](https://www.youtube.com/watch?v=9Q4THBZ-Zn4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-08-22 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP
"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał  
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie


♫ Słuchaj jako PODCAST Langusty: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
iTunes → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWHx

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#589] Rozsądek
 - [https://www.youtube.com/watch?v=XOOllbtOF3Q](https://www.youtube.com/watch?v=XOOllbtOF3Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-08-21 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP
"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał  
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie


♫ Słuchaj jako PODCAST Langusty: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
iTunes → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWHx

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

