# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## LET’S DEBATE: AuthorTube Is BAD😡 Books should be RATED!🚶‍♂️
 - [https://www.youtube.com/watch?v=-gMIejTt-pI](https://www.youtube.com/watch?v=-gMIejTt-pI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-08-22 00:00:00+00:00

You drop spicey takes on the fantasy genre, I SMACK them down with the force of like 1 or two suns.
Art Provided By: https://www.instagram.com/yoichi.art/
Podcast: https://afictionalconversation.podbean.com/
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## MAJOR Stranger Things Update👹 WoT Casting Min/Siuan🎬 Olivia Wilde Spider-Woman🕷️ -FANTASY NEWS
 - [https://www.youtube.com/watch?v=_BQXodt-b5s](https://www.youtube.com/watch?v=_BQXodt-b5s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-08-21 00:00:00+00:00

Everything from Wheel of Time Amazon casting to Batman promos. We got the Fantasy news coming in hot. 
Podcast: https://afictionalconversation.podbean.com/
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

NEWS: 

--
00:00 - #WheelOfTime Casting: https://twitter.com/WOTonPrime/status/1296129825694875649
03:00 - Doors Of Eden Released: https://twitter.com/aptshadow/status/1296392057787908096
03:52 - More #Twilight: https://people.com/books/stephenie-meyer-new-twilight-book/
04:47 - Combat Wheelchair: https://twitter.com/nerdist/status/1296149057832984576?s=19
05:34 - Prince Of Persia rumor: https://www.siliconera.com/rumor-prince-of-persia-remake-product-listings-appear/
06:54 - Black Myth: https://www.youtube.com/watch?v=O2nNljv0MOw
07:44 - #StrangerThings Update: https://www.buzzfeed.com/marissamuller/stranger-things-season-four-update
09:36 - #Exorcist Reboot: https://screenrant.com/exorcist-movie-reboot-2021-release-date/
10:37 - Olivia Wild #Spider-Woman Movie: https://deadline.com/2020/08/olivia-wilde-spider-woman-director-secret-marvel-movie-sony-1203017798/
11:33- Fantastic Beasts: https://twitter.com/DiscussingFilm/status/1296170465791217667
11:47 - #LovecraftCountry Episode 1: https://www.youtube.com/watch?v=lvVmlDyJ6BA 
12:05 - Pinocchio: https://www.hollywoodreporter.com/heat-vision/guillermo-del-toro-signs-netflix-deal-casts-tilda-swinton-finn-wolfhard-in-pinocchio-exclusive
12:46 - #Batman Logohttps://twitter.com/mattreevesLA/status/1296477749654233089/photo/1
13:09 - Narnia Church Statues: https://www.theguardian.com/uk-news/2020/aug/19/yorkshire-church-adorned-chronicles-of-narnia-carvings-st-marys-beverley
--

