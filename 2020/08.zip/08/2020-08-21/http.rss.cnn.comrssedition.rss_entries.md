# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Singer's hilarious pandemic video racks up millions of views
 - [https://www.cnn.com/videos/us/2020/08/21/kd-french-at-the-fridge-again-gospel-singer-wellness-orig-llr.cnn](https://www.cnn.com/videos/us/2020/08/21/kd-french-at-the-fridge-again-gospel-singer-wellness-orig-llr.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 23:12:45+00:00

Singer KD French sang lead AND backup for a song she wrote about how hard it is to keep off the pandemic pounds. The video now has millions of views.

## Sevilla continues Europa League love affair with final victory over Inter Milan
 - [https://www.cnn.com/2020/08/21/football/europa-league-final-sevilla-inter-milan-spt-intl/index.html](https://www.cnn.com/2020/08/21/football/europa-league-final-sevilla-inter-milan-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 23:02:55+00:00

Sevilla's love affair with the Europa League continues as the Spanish club beat Inter Milan 3-2 Friday in a thrilling final to win a record-extending sixth title and its fourth in the last seven years.

## GOP candidate behind controversial BLM ad speaks out
 - [https://www.cnn.com/videos/politics/2020/08/21/kim-klacik-campaign-ad-black-lives-matter-orig-jm.cnn](https://www.cnn.com/videos/politics/2020/08/21/kim-klacik-campaign-ad-black-lives-matter-orig-jm.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 21:45:47+00:00

This trending ad from GOP candidate Kim Klacik claims Democrats don't care about Black lives. She's not a likely win at the polls, but her message has sparked a lot of chatter, even from President Trump.

## The New York Mets have 4 games postponed as players quarantine in New York and Miami
 - [https://www.cnn.com/2020/08/21/us/new-york-mets-game-postponements-spt-trnd/index.html](https://www.cnn.com/2020/08/21/us/new-york-mets-game-postponements-spt-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 21:42:57+00:00

Members of the New York Mets are quarantining in two different cities after the team reported two Covid-19 cases this week.

## California wildfires kill at least 4 people as some evacuees weigh coronavirus risks at shelters
 - [https://www.cnn.com/2020/08/21/us/california-wildfires/index.html](https://www.cnn.com/2020/08/21/us/california-wildfires/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 18:35:56+00:00

Even for a state prone to natural disasters, California's had a catastrophic week.

## Golden State Killer sentenced to life in prison
 - [https://www.cnn.com/2020/08/21/us/golden-state-killer-sentencing/index.html](https://www.cnn.com/2020/08/21/us/golden-state-killer-sentencing/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 18:35:32+00:00

A former California police officer who became known as the notorious Golden State Killer said he was "truly sorry" before he was sentenced to life without the possibility of parole on Friday.

## Trump files emergency request to prevent subpoena of his tax records after judge denies motion
 - [https://www.cnn.com/2020/08/21/politics/trump-motion-tax-records/index.html](https://www.cnn.com/2020/08/21/politics/trump-motion-tax-records/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 18:23:16+00:00

Lawyers for President Donald Trump filed an emergency request Friday for a federal appeals court to put a subpoena for his financial documents and tax returns on hold until the higher court can weigh in on the matter.

## GOP strategist gets emotional over DNC moment
 - [https://www.cnn.com/videos/politics/2020/08/21/jennings-brayden-harrington-reference-2020-dnc-vpx.cnn](https://www.cnn.com/videos/politics/2020/08/21/jennings-brayden-harrington-reference-2020-dnc-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 17:04:05+00:00

CNN Republican strategist Scott Jennings says the highlight of the fourth night of the DNC was the story of a 13-year-old boy overcoming the insecurity of his stutter.

## 'Look into the camera': Senator grills USPS chief
 - [https://www.cnn.com/videos/politics/2020/08/21/senator-rosen-louis-dejoy-usps-hearing-sot-nr-vpx.cnn](https://www.cnn.com/videos/politics/2020/08/21/senator-rosen-louis-dejoy-usps-hearing-sot-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 17:02:01+00:00

Sen. Jacky Rosen (D-NV) grills Postmaster General Louis DeJoy about changes he's made at the United States Postal Service right ahead of the 2020 election, asking him if he's done analysis on the impacts of his policies.

## Brawl erupts on airplane over masks
 - [https://www.cnn.com/videos/us/2020/08/21/airplane-mask-fight-moos-pkg-vpx.cnn](https://www.cnn.com/videos/us/2020/08/21/airplane-mask-fight-moos-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 17:00:31+00:00

Airline passengers brawl over seats and masks. CNN's Jeanne Moos has the blow-by-blow account.

## Russian dissident Navalny to be transported to Germany "within a day," doctor tells state media
 - [https://www.cnn.com/2020/08/21/europe/alexey-navalny-russia-travel-intl/index.html](https://www.cnn.com/2020/08/21/europe/alexey-navalny-russia-travel-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 17:00:22+00:00

The Siberian hospital treating Russian opposition leader Alexey Navalny said it cannot authorize him to be transported due to "worry" over his clinical state, amid claims by his team that the delay is to mask the presence of a "deadly substance."

## Stephen Curry laughs at daughter's presidential nominee guess
 - [https://www.cnn.com/videos/politics/2020/08/21/stephen-curry-ayesha-curry-dnc-2020-kids-joe-biden-vote-sot-vpx.cnn](https://www.cnn.com/videos/politics/2020/08/21/stephen-curry-ayesha-curry-dnc-2020-kids-joe-biden-vote-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 16:59:33+00:00

During the Democratic National Convention, Stephen and Ayesha Curry have a candid conversation with their daughters Ryan and Riley about the importance of voting ahead of the 2020 presidential election.

## Valentino Rossi calls for track change after miraculously escaping MotoGP horror crash
 - [https://www.cnn.com/2020/08/21/motorsport/moto-gp-crash-valentino-rossi-spt-intl/index.html](https://www.cnn.com/2020/08/21/motorsport/moto-gp-crash-valentino-rossi-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 16:43:42+00:00

Valentino Rossi said he believes changes are needed to the Red Bull Ring in order to avoid a repeat of the dramatic crash in Sunday's Austrian MotoGP.

## Meghan on voting in 2020: If you aren't voting, 'then you're complicit'
 - [https://www.cnn.com/2020/08/21/politics/meghan-duchess-of-sussex-voting-2020/index.html](https://www.cnn.com/2020/08/21/politics/meghan-duchess-of-sussex-voting-2020/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 16:26:21+00:00

Meghan, Duchess of Sussex, spoke on the importance of voting during an event with Michelle Obama's voter registration organization Thursday, saying that if you don't vote, "then you're complicit."

## Scientists have 'digitally unwrapped' some Egyptian animal mummies, including a kitten and cobra
 - [https://www.cnn.com/2020/08/21/world/mummies-digitally-unwrapped-scli-intl-gbr-scn/index.html](https://www.cnn.com/2020/08/21/world/mummies-digitally-unwrapped-scli-intl-gbr-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 16:05:35+00:00

Researchers at a UK university have "digitally unwrapped" three mummified animals from ancient Egypt using high-resolution 3D scans.

## Election mail is No. 1 priority, says US postal chief
 - [https://www.cnn.com/2020/08/21/politics/louis-dejoy-senate-hearing/index.html](https://www.cnn.com/2020/08/21/politics/louis-dejoy-senate-hearing/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 16:04:50+00:00

Embattled Postmaster General Louis DeJoy argued during a high-profile Senate hearing Friday that the Postal Service is up to the task of handling election mail delivery, a reassurance that comes as Democrats raise the alarm over Postal Service operations in the run-up to the presidential election.

## Manchester United captain Harry Maguire 'fully co-operating' with police after incident
 - [https://www.cnn.com/2020/08/21/football/harry-maguire-manchester-united-incident-spt-intl/index.html](https://www.cnn.com/2020/08/21/football/harry-maguire-manchester-united-incident-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 15:45:01+00:00

Manchester United captain Harry Maguire is "fully co-operating" with Greek police, the English Premier League club said Friday, after three Britons allegedly threatened police officers and attacked one of them.

## UK-EU trade talks are going backward and time is running out
 - [https://www.cnn.com/collections/intl-biz-0821/](https://www.cnn.com/collections/intl-biz-0821/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 15:32:44+00:00



## Ardern wants to eliminate coronavirus. Is she setting herself up to fail?
 - [https://www.cnn.com/collections/intl-coronavirus-worldwide-0821/](https://www.cnn.com/collections/intl-coronavirus-worldwide-0821/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 15:31:58+00:00



## Steve Bannon calls arrest and fraud charges a 'political hit job'
 - [https://www.cnn.com/2020/08/21/politics/bannon-responds-to-fraud-charges/index.html](https://www.cnn.com/2020/08/21/politics/bannon-responds-to-fraud-charges/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 15:30:36+00:00

President Donald Trump's former adviser Steve Bannon on Friday called his arrest yesterday a "political hit job" and vowed to fight the charges against him of fraud tied to a fundraising campaign purportedly aimed at supporting Trump's border wall.

## Joe Biden takes on Trump-era traumas in career-defining speech
 - [https://www.cnn.com/collections/intl-biden-speech/](https://www.cnn.com/collections/intl-biden-speech/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 15:29:23+00:00



## Magnus Carlsen wins richest and most-watched online chess event ever
 - [https://www.cnn.com/2020/08/21/sport/magnus-carlsen-chess-finale-victory-hikaru-nakamura-spt-intl/index.html](https://www.cnn.com/2020/08/21/sport/magnus-carlsen-chess-finale-victory-hikaru-nakamura-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 14:34:51+00:00

There's just no stopping Magnus Carlsen.

## Officials caught off guard by ban on witnessing ballots
 - [https://www.cnn.com/2020/08/21/politics/postal-workers-absentee-ballot-witnesses/index.html](https://www.cnn.com/2020/08/21/politics/postal-workers-absentee-ballot-witnesses/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 14:32:22+00:00

Absentee voters in Alaska's state primary this week got an unexpected answer when they asked postal workers to witness their ballots: No.

## The US Postal Service controversy, explained
 - [https://www.cnn.com/collections/intl-usps-0821/](https://www.cnn.com/collections/intl-usps-0821/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 14:30:40+00:00



## Paralyzed artist who paints with her eyes is an international sensation
 - [https://www.cnn.com/collections/intl-sponsored-tech-0821/](https://www.cnn.com/collections/intl-sponsored-tech-0821/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 14:02:46+00:00



## The Postal Service controversy, explained
 - [https://www.cnn.com/2020/08/21/politics/usps-funding-controversy-explained/index.html](https://www.cnn.com/2020/08/21/politics/usps-funding-controversy-explained/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 13:55:45+00:00

Postmaster General Louis DeJoy is set to testify in front of the Republican-led Senate Homeland Security and Governmental Affairs Committee on Friday.

## Taylor Swift has donated $30,000 to help a Black London teenager study math
 - [https://www.cnn.com/2020/08/21/entertainment/taylor-swift-fan-donation-scli-intl-gbr/index.html](https://www.cnn.com/2020/08/21/entertainment/taylor-swift-fan-donation-scli-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 13:54:42+00:00

Musician Taylor Swift has donated $30,000 to help an 18-year-old student realize her dream of becoming a mathematician.

## Kelly Osbourne reveals how she lost 85 lbs
 - [https://www.cnn.com/2020/08/21/entertainment/kelly-osbourne-weight-loss/index.html](https://www.cnn.com/2020/08/21/entertainment/kelly-osbourne-weight-loss/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 13:42:00+00:00

Kelly Osbourne is not one of those celebrities who is unwilling to share how she shed weight.

## CNN anchor to Pence: How can you not know about QAnon?
 - [https://www.cnn.com/videos/politics/2020/08/21/mike-pence-qanon-conspiracy-theory-trump-berman-intv-newday-vpx.cnn](https://www.cnn.com/videos/politics/2020/08/21/mike-pence-qanon-conspiracy-theory-trump-berman-intv-newday-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 13:15:17+00:00

CNN's John Berman presses Vice President Mike Pence on the QAnon conspiracy theory after President Donald Trump seemed to embrace the fringe group.

## BTS's first English language song is 'Dynamite'
 - [https://www.cnn.com/2020/08/21/entertainment/bts-dynamite-trnd/index.html](https://www.cnn.com/2020/08/21/entertainment/bts-dynamite-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 12:53:52+00:00

It took less than eight hours for BTS to rack up more than 45 million views for its first English language single on YouTube.

## Spectacular new step-bridge 'floats' over Norwegian waterfall
 - [https://www.cnn.com/travel/article/norway-waterfall-bridge/index.html](https://www.cnn.com/travel/article/norway-waterfall-bridge/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 12:08:46+00:00

Rushing water cascades below an elevated footbridge that looks like it's floating on air, with panoramic views of hazy mountains and a plunging, deep valley underneath.

## Paris Saint-Germain looks to upset European football's established order with victory over Bayern Munich
 - [https://www.cnn.com/2020/08/21/football/champions-league-final-psg-bayern-munich-spt-intl/index.html](https://www.cnn.com/2020/08/21/football/champions-league-final-psg-bayern-munich-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 11:37:25+00:00

Few people will have bigger headaches going into this weekend than Bayern Munich and Paris Saint-Germain's defenders.

## Pharrell Williams: 'We must trust in a Black vision of the future'
 - [https://www.cnn.com/2020/08/21/entertainment/pharrell-williams-racism-essay-time/index.html](https://www.cnn.com/2020/08/21/entertainment/pharrell-williams-racism-essay-time/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 11:28:59+00:00

Pharrell Williams has penned a powerful essay for Time in which he says the protests sweeping the nation have made him finally feel like an American.

## Toronto Raptors president says he was shoved by police officer because he is Black
 - [https://www.cnn.com/2020/08/21/sport/masai-ujiri-toronto-raptors-push-police-officer-follow-up-spt-intl/index.html](https://www.cnn.com/2020/08/21/sport/masai-ujiri-toronto-raptors-push-police-officer-follow-up-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 11:08:07+00:00

Toronto Raptors President Masai Ujiri says that the reason he was pushed by a law enforcement officer last year as he tried to join his NBA champions in celebration is because he is Black.

## Teens are having unprotected sex, driving drunk and vaping among other risky behaviors, CDC says
 - [https://www.cnn.com/collections/cnn-health-0821/](https://www.cnn.com/collections/cnn-health-0821/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 11:02:31+00:00



## Europe's travel windows are slamming shut
 - [https://www.cnn.com/travel/article/europe-travel-windows-closing/index.html](https://www.cnn.com/travel/article/europe-travel-windows-closing/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 10:56:33+00:00

The vacation lights are going out all over Europe.

## Multiple star explosions may have contributed to a mass extinction on Earth
 - [https://www.cnn.com/2020/08/21/world/supernova-mass-extinction-scn-trnd/index.html](https://www.cnn.com/2020/08/21/world/supernova-mass-extinction-scn-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 10:45:07+00:00

Simultaneous explosions of stars, called supernovae, may have led to one of Earth's mass extinctions 359 million years ago, according to new research.

## Defying Bolsonaro, Brazilian congress orders mandatory mask wearing
 - [https://www.cnn.com/videos/world/2020/08/21/brazil-coronavirus-covid-19-pandemic-congress-jair-bolsonaro-masks-romo-lkl-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2020/08/21/brazil-coronavirus-covid-19-pandemic-congress-jair-bolsonaro-masks-romo-lkl-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 10:32:39+00:00

Brazil's congress voted for mandatory mask wearing in closed spaces such as commercial establishments, offices, schools and places of worship, overturning President Jair Bolsonaro's previous veto. CNN's Rafael Romo reports.

## Grand Canyon cliff collapse reveals 313 million-year-old fossil footprints
 - [https://www.cnn.com/travel/article/grand-canyon-cliff-collapse-fossil-footprints-scn-trnd/index.html](https://www.cnn.com/travel/article/grand-canyon-cliff-collapse-fossil-footprints-scn-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 10:26:53+00:00

Finding fossil footprints at the Grand Canyon isn't particularly unusual. The expansive stretch of red rock is home to an array of formations containing preserved remains of the past.

## Hot oil helps fuel Tiger Woods at The Northern Trust
 - [https://www.cnn.com/2020/08/21/golf/tiger-woods-the-northern-trust-golf-spt-intl/index.html](https://www.cnn.com/2020/08/21/golf/tiger-woods-the-northern-trust-golf-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 09:24:18+00:00

Tiger Woods looked to be in a spot of bother ahead of the first round of The Northern Trust in Massachusetts Thursday, but it was nothing a cold bottle of water couldn't fix.

## Lifelong Republican and NRA member says he will vote for Biden
 - [https://www.cnn.com/videos/politics/2020/08/21/edward-good-veteran-dnc-2020-speech-full-video-vpx.cnn](https://www.cnn.com/videos/politics/2020/08/21/edward-good-veteran-dnc-2020-speech-full-video-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 08:17:55+00:00

Edward Good, a 95-year-old war veteran and lifelong Republican denounced Donald Trump in his speech during the Democratic National Convention and called on the country to vote for Democratic presidential nominee Joe Biden.

## Stealthy thieves broke into a Japanese ninja museum and stole a million yen
 - [https://www.cnn.com/2020/08/21/asia/thieves-ninja-museum-japan-intl-hnk-scli/index.html](https://www.cnn.com/2020/08/21/asia/thieves-ninja-museum-japan-intl-hnk-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 08:07:25+00:00

A ninja museum in central Japan had some stealthy visitors this week -- thieves who broke in and stole more than a million yen ($9,470) in the middle of the night.

## Watch late-night hosts reactions to Obama and Biden DNC speeches
 - [https://www.cnn.com/videos/media/2020/08/21/dnc-day-four-late-night-laughs-orig.cnn](https://www.cnn.com/videos/media/2020/08/21/dnc-day-four-late-night-laughs-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 08:03:52+00:00

Jimmy Fallon, Trevor Noah and Stephen Colbert react to former President Obama and Democratic presidential nominee Joe Biden's speeches from the Democratic National Convention.

## Hear from couple who lost only child in the Beirut blast
 - [https://www.cnn.com/videos/world/2020/08/21/lebanon-beirut-blast-couple-lost-only-child-alexandra-wedemen-pkg-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2020/08/21/lebanon-beirut-blast-couple-lost-only-child-alexandra-wedemen-pkg-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 07:23:01+00:00

A young couple lost their only child, three-year-old Alexandra, in the Beirut blast. Like so many Lebanese who survived the explosion but lost so much, the couple tells CNN's Ben Wedeman they are close to giving up on a country that is falling apart.

## Satellite photos appear to show Chinese submarine using underground base
 - [https://www.cnn.com/2020/08/21/asia/china-submarine-underground-base-satellite-photo-intl-hnk-scli/index.html](https://www.cnn.com/2020/08/21/asia/china-submarine-underground-base-satellite-photo-intl-hnk-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 06:39:50+00:00



## Julia Louis-Dreyfus' DNC satire: Awkward or funny?
 - [https://www.cnn.com/videos/politics/2020/08/21/julia-louis-dreyfus-dnc-vf-orig.cnn](https://www.cnn.com/videos/politics/2020/08/21/julia-louis-dreyfus-dnc-vf-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 05:00:59+00:00

"Veep" and "Seinfeld" star Julia Louis-Dreyfus emceed the final night of the Democratic National Convention in the lead up to Joe Biden officially accepting the Democratic presidential nomination.

## USPS email tells managers not to reconnect sorting machines
 - [https://www.cnn.com/2020/08/20/politics/usps-reconnect-sorting-machines/index.html](https://www.cnn.com/2020/08/20/politics/usps-reconnect-sorting-machines/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-21 03:08:36+00:00

While Postmaster General Louis DeJoy may be suspending changes to postal service operations, it doesn't necessarily mean machines that had been removed will be put back in use, according to an email obtained by CNN.

