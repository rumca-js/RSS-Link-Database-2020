# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 7 SURPRISES You Got For 100% Completing The Game
 - [https://www.youtube.com/watch?v=q0wmBYwNsHI](https://www.youtube.com/watch?v=q0wmBYwNsHI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-08-22 00:00:00+00:00

Working hard to completely finish a video game is often rewarding...in good ways and bad ways. Here are some surprising examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## NEW CHINESE AAA GAME LOOKS INSANE, PRINCE OF PERSIA REMAKE? & MORE
 - [https://www.youtube.com/watch?v=NjWobPcKrXA](https://www.youtube.com/watch?v=NjWobPcKrXA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-08-21 00:00:00+00:00

Thanks to ExpressVPN for sponsoring this video. Go to https://expressvpn.com/gameranx to take back your Internet privacy TODAY and find out how you can get 3 months free.

More Batman game teases before DC Fandome, Ghost of Tsushima is getting a surprise free add-on, Call of Duty Cold War is revealed, and more in a week full of gaming news.
Subscribe for more: http://youtube.com/gameranxtv 

*Jakes twitter: https://twitter.com/jakebaldino 
*Instagram: https://goo.gl/HH6mTW 


 discord.gg/gameranx 




 ~~~~STORIES~~~~



Black Myth Wu Kong- https://youtu.be/oRLhCxC886o

Batman tease - https://twitter.com/ArkhamVideos/status/1296825566256144385

Prince of Persia- https://www.gamesradar.com/prince-of-persia-remake-reportedly-in-the-works-for-2020-release/

Deathloop delayed - https://www.ign.com/articles/deathloop-delayed-to-2021
Also Baldur’s gate: https://www.ign.com/articles/baldurs-gate-3-early-access-launch-date-revealed

Supreme Mortal Kombat - https://www.pcmag.com/news/what-you-need-to-know-supreme-mortal-kombat-arcade-cabinet



Before You Buy:Fall Guys: https://youtu.be/iL-KcNqn5AQ
Flight Simulator: https://youtu.be/O_sK_sc5GYs

Deep dive on Diablo: https://youtu.be/huPF3Gid7DE

Hitman 3 location: https://youtu.be/tDKhgJDIsig


Call of Duty Cold War box art: https://www.forbes.com/sites/erikkain/2020/08/21/what-the-call-of-duty-black-ops-cold-war-key-art-tells-us-about-the-game/#40ccfece2e38


Tsushima co op!
https://www.theverge.com/2020/8/17/21371957/ghost-of-tsushima-legends-co-op-mode-free

