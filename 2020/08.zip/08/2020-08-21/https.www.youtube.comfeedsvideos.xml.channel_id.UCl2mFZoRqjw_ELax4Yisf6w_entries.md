# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## A1466 Macbook Air starts with no backlight now has no image logic board repair
 - [https://www.youtube.com/watch?v=b39IQa_pffk](https://www.youtube.com/watch?v=b39IQa_pffk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-08-22 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
🔵 We fix Macbooks & offer free estimates. https://rossmanngroup.com
🔵 Send us your Macbook for repair! http://bit.ly/sendmacbook
🔵 We'll send you a box with a pre-paid shipping label for your repair! http://bit.ly/sendyourmacbook
🔵 We offer iPhone data recovery: http://bit.ly/2BDBX4G
🔵 We offer lab hard drive data recovery: http://bit.ly/labdatarecovery

👉 LEARN HOW TO DO THIS:
› In-person classes: https://bit.ly/classrg
› Beginner's guide: http://bit.ly/2k6uz84
› Support forum: $29/mo http://bit.ly/boardrepairforum

👉 Donate & post a message: http://bit.ly/postamessage 

👉 Below we list tools & recording gear we use, repair guides to help you learn, online chip sources, & donation links:

👉 BlackBerry, Oreo, & Clinton the cat's wish list: https://www.amazon.com/hz/wishlist/ls/2YC1L66N7T5BC?&sort=default

👉 CHIPS & COMPONENTS:
› http://bit.ly/2jaAOXM

👉 Discord: https://tinyurl.com/rossmatrix

👉 TOOLS USED:

✓ Soldering Irons:
› Louis' Hakko station(no tweezers): http://amzn.to/2cKkMyO 
› Paul's Hakko station(works with tweezers): http://amzn.to/2yMvWNy
› Micro Soldering Pencil: http://amzn.to/2d5MWUP
› Hot tweezers: http://amzn.to/2yMvZsZ
› Atten ST-862D hot air station: http://bit.ly/atten862

✓ CHEAP HAKKO ALTERNATIVES:
› TS100 soldering iron: https://amzn.to/2Gy1Fqz
› Recommended tips: TS-C4: https://amzn.to/33s3jpW TS-KU https://amzn.to/2QsKT36

✓ Preferred Soldering Tips
› Fine: http://amzn.to/2d5MgPn 
› Flat: https://amzn.to/2JnsDBT 
› GPU wicking: http://amzn.to/2w8chtB
› Micro soldering tip: http://amzn.to/2qUSFDh

✓ Microscopes:
› Microscope: http://amzn.to/2iLrE16 
› Barlow lens: http://amzn.to/2yMKdKf
› LED light: http://amzn.to/2nzfPT2
› CHEAP alternative microscope: http://amzn.to/2rTlHbj

✓ Soldering/Repair Supplies:
› Solder: http://amzn.to/2cKkxUp
› Desoldering braid: http://bit.ly/2otflOX
› Flux: http://bit.ly/amtechflux
› Solder paste: http://bit.ly/amtechsolderpaste
› THICK insulated jumper wire: https://amzn.to/2rvtD0A
› THIN insulated jumper wire: https://amzn.to/2I47DQY
› Kapton tape: http://amzn.to/2yN0xuq
› Tweezers: http://amzn.to/2d5NBpi
› Blades: http://amzn.to/2ByWnvF
› Freeze Spray: http://amzn.to/2BySozw
› Conformal coating: http://bit.ly/greencoate
› Conformal coating curing pen: http://bit.ly/uvpen

✓ Diagnostic tools:
› USB amp meter: http://bit.ly/2B2Lu5W
› USB-C amp meter: http://bit.ly/usbcamp
› On-Screen multimeter: http://amzn.to/2jtgY9K 
› Multimeter Probes: http://bit.ly/fineprobes
› CHEAP multimeter: http://amzn.to/2zjkg8U
› Bench PSU: CSI3005P http://bit.ly/benchsupply
› Phoneboard: https://phoneboard.co
› Boardview software: https://pldaniels.com/flexbv/

✓ Ultrasonic Cleaning:
› ALL MACBOOKS & CELLPHONES: Crest P1200H-45: https://amzn.to/2ITSQdw
› PRE-TOUCHBAR MACBOOKS & CELLPHONES: Crest P500H-45: https://amzn.to/2Qrnhf8
› CELLPHONES ONLY: Crest P230H-45: https://amzn.to/2QsckKG
› Branson EC cleaning fluid: http://amzn.to/2cKlBrp

✓ Desk supplies:
› Desk: http://amzn.to/2yMShdZ
› Chair: https://amzn.to/2LB8bUB
› Fume Extractor: http://amzn.to/2d5MGoD
› Work mat: http://amzn.to/2yMtlTR
› Outlets: http://amzn.to/2yNsZwo
› Gloves: http://amzn.to/2iUfumS
› Durable lightning cable: http://amzn.to/2yNHzUt
› Fine tipped snippers: http://amzn.to/2HGt4XB

✓ Screwdrivers: 
› iPhone bottom screw: http://amzn.to/2yNwX8p
› Macbook bottom screw: http://amzn.to/2AKMdVb
› Torx T3: http://amzn.to/2zjtxxH
› Torx T5 http://amzn.to/2BLNDn4
› Torx T6 http://amzn.to/2B0XIfA
› Torx T8 http://amzn.to/2CpWp68
› Phillips #0: http://amzn.to/2AJaHhM
› Phillips #000: http://amzn.to/2yNqsCl



✓ RECORDING EQUIPMENT:
› Work cam: https://amzn.to/2QjHnt0
› Overhead cam: http://amzn.to/2eAH0oT
› Work mic: https://amzn.to/2WGIhzw
› Home mic: https://amzn.to/2xfampC
› Microscope camera: http://amzn.to/2icVQoG - mine is DISCONTINUED, closest one I can find. 
› HDMI capture: http://amzn.to/2iyGcle

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com

👉 Leave a tip for us via cryptocurrency if we've helped you out:
› Credit card: http://bit.ly/postamessage
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

## NYC real estate prices are RISING!!
 - [https://www.youtube.com/watch?v=Yavgfk0IjdM](https://www.youtube.com/watch?v=Yavgfk0IjdM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-08-22 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
https://www.loopnet.com/Listing/300-Eighth-Ave-New-York-NY/10847798/ 

https://www.loopnet.com/Listing/1265-Broadway-New-York-NY/3939819/ 

https://nymag.com/news/features/foreigners-hiding-money-new-york-real-estate-2014-6/

## A boring commute to work, testing DJI Action 4k60 camera
 - [https://www.youtube.com/watch?v=etvQKe4-pVM](https://www.youtube.com/watch?v=etvQKe4-pVM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-08-21 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
This is the new camera I am using: DJI Action 4K: https://amzn.to/3aI5dqa

🔵 DPA 4066: https://amzn.to/3dCbZhJ (my favorite mic)
🔵 Zoom H1n: https://amzn.to/2Y44HwF (this works amazingly well)

## GoPro Hero 7 vs DJI Action 4k at night - low light recording
 - [https://www.youtube.com/watch?v=gDHBKukRoRM](https://www.youtube.com/watch?v=gDHBKukRoRM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-08-21 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
🔵 DJI Action 4K: https://amzn.to/3aI5dqa
🔵 GoPro 7: https://amzn.to/30muenV
I am a moron. I judged the DJI vs. GoPro low light from... the screens of the devices.
I was going to reupload this without the audio, but in the interest of transparency, it's worthwhile that 1.23 million people realize I am an idiot. A total moron. LAY IT ON ME. :( I deserve it, I judged the quality of these two cameras from... their effing internal screens. It makes sense if the DJI has TWO screens for $80 less than the gopro's ONE screen that the screen they put on the DJI is going to be way worse in quality than the gopro's screen.
When you actually have them next to each other on the same screen, they're more similar. I think the gopro has way more natural white balance when set to auto(which is how most will use action cams). The DJI really has no idea what color anything is at night, but it is not the drastic difference I thought it was while recording the video. 
I will likely end up keeping the DJI since it doesn't crash all the time a-la-gopro. I recorded 3 videos with it so far - zero crashing. It's beautiful. :)

## New York City businesses: they're all leaving
 - [https://www.youtube.com/watch?v=G9hfbQShmvI](https://www.youtube.com/watch?v=G9hfbQShmvI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-08-21 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
🔵 DJI Action 4K: https://amzn.to/3aI5dqa
🔵 DPA 4066: https://amzn.to/3dCbZhJ (my favorite mic)
🔵 Zoom H1n: https://amzn.to/2Y44HwF (this works amazingly well)

