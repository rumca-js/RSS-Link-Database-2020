# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Brian Kolfage's Wife Has Criminal Evidence In Her TikTok Videos - We Build the Wall SCAM
 - [https://www.youtube.com/watch?v=L_M_wCyTGEw](https://www.youtube.com/watch?v=L_M_wCyTGEw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-08-21 00:00:00+00:00

This WE BUILD THE WALL drama is insane and goes deep. 
SUBSCRIBE TO THE DRIP!
https://www.youtube.com/channel/UCMMCy1le81jHY8rwcaqQrtA?

Brian Kolfage and TikTok and Instagram model Ashley Kolfage have really messed up, they not only allegedly embezzled money from their org: We Build the Wall Inc. but this was after Brian Kolfage repeatedly denounced this idea that he would ever "take a penny"

Absolutely insane, read the full docket here: https://www.justice.gov/usao-sdny/press-release/file/1306611/download

