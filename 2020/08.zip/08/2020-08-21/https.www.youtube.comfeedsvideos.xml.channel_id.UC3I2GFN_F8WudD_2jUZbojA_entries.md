# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## TeZATalks - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=oDC9ibvRS2s](https://www.youtube.com/watch?v=oDC9ibvRS2s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-08-21 00:00:00+00:00

http://KEXP.ORG presents TeZATalks performing live in the KEXP studio. Recorded February 17, 2020.

Songs:
Golden
Parachute
Kinko
The World

Host: Eva Walker
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen & Kendall Rock
Editor: Jim Beckmann

http://kexp.org
https://linktr.ee/tezatalks

## TeZATalks - Golden (Live on KEXP)
 - [https://www.youtube.com/watch?v=3gEun99iXWA](https://www.youtube.com/watch?v=3gEun99iXWA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-08-21 00:00:00+00:00

http://KEXP.ORG presents TeZATalks performing “Golden” live in the KEXP studio. Recorded February 17, 2020.

Host: Eva Walker
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen & Kendall Rock
Editor: Jim Beckmann

http://kexp.org
https://www.facebook.com/TeZaTalks

## TeZATalks - Kinko (Live on KEXP)
 - [https://www.youtube.com/watch?v=UaIkbOvpBaA](https://www.youtube.com/watch?v=UaIkbOvpBaA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-08-21 00:00:00+00:00

http://KEXP.ORG presents TeZATalks performing “Kinko” live in the KEXP studio. Recorded February 17, 2020.

Host: Eva Walker
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen & Kendall Rock
Editor: Jim Beckmann

http://kexp.org
https://www.facebook.com/TeZaTalks

## TeZATalks - Parachute (Live on KEXP)
 - [https://www.youtube.com/watch?v=KItMEeySIGg](https://www.youtube.com/watch?v=KItMEeySIGg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-08-21 00:00:00+00:00

http://KEXP.ORG presents TeZATalks performing “Parachute” live in the KEXP studio. Recorded February 17, 2020.

Host: Eva Walker
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen & Kendall Rock
Editor: Jim Beckmann

http://kexp.org
https://www.facebook.com/TeZaTalks

## TeZATalks - The World (Live on KEXP)
 - [https://www.youtube.com/watch?v=XnuRwFAlO2A](https://www.youtube.com/watch?v=XnuRwFAlO2A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-08-21 00:00:00+00:00

http://KEXP.ORG presents TeZATalks performing “The World” live in the KEXP studio. Recorded February 17, 2020.

Host: Eva Walker
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen & Kendall Rock
Editor: Jim Beckmann

http://kexp.org
https://www.facebook.com/TeZaTalks

