# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week: Fortnite vs Apple vs Google i zabierzcie hulajnogi z chodników! Mi 10 Ultra, Surface Duo
 - [https://www.youtube.com/watch?v=xLDfWvMXrKA](https://www.youtube.com/watch?v=xLDfWvMXrKA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-08-16 00:00:00+00:00

Moje sociale:
Insta: http://bit.ly/InstaKlawiatur 
Twitter: http://bit.ly/TTKlawitera
FB: http://bit.ly/FBKlawiatur

Muza z filmów: https://spoti.fi/3fgBNRu

Źródła:
Epic vs Apple vs Google: https://bit.ly/2EcRTOf
Film Fortnite vs Apple: https://youtu.be/euiSHuaw6Q4
Reklama Apple z 1984: https://youtu.be/2zfqw8nhUwA
Huawei nie będzie mógł produkować Kirinów: https://bit.ly/2CwTGxn
Nowe przepisy dotyczące hulajnóg: https://bit.ly/30YKkUp
Osobny pas dla samochodów autonomicznych: https://cnet.co/3h0DYJK
Microsoft Surface Duo: https://bit.ly/2PTtZtY
Jabłko pozywa gruszkę: https://bit.ly/3iMV0vC
Xiaomi Mi 10 Ultra: https://bit.ly/3arLlaP
TikTok będzie płacił twórcom: https://bit.ly/3iYoAyn
Picie zwiększa ryzyko złapania COVIDu: https://cnet.co/31RzIGc
Vaping zwiększa ryzyko złapania COVIDu: https://bit.ly/3iJE5tI
Nowy Watch Os z informacją o myciu rąk: https://bit.ly/32178lX

