# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Does your PC Need This?? - Capture Cards Explained
 - [https://www.youtube.com/watch?v=-pBPb15ykCI](https://www.youtube.com/watch?v=-pBPb15ykCI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-08-17 00:00:00+00:00

Thanks to CORSAIR for sponsoring this video!! Check out the CORSAIR Vengeance a4100 Series Streaming PC at https://geni.us/260zQn2
Buy Elgato 4K60 PRO Capture Cards: https://geni.us/RPcRM
On Amazon (PAID LINK): https://geni.us/AJV5
On Newegg (PAID LINK): https://geni.us/BNHZs

Buy AMD Ryzen 3000 CPUs
On Amazon (PAID LINK): https://geni.us/z9qNX
On Newegg (PAID LINK): https://geni.us/Ynlc0
On B&H (PAID LINK): https://geni.us/kW9gt

Do you really need a capture card for content creation in 2020? Watch to find out!

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1235502-does-your-pc-need-this/


GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Mech Keyboard: https://geni.us/RecNBTI
Nerd or Die Stream Overlays & Templates: https://geni.us/s8hBAgR
NEEDforSEAT Gaming Chairs: https://geni.us/needforseat
Get a Displate Metal Print at https://lmg.gg/displateltt
Use code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Gear on Amazon: https://www.amazon.com/shop/linustechtips
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0 https://lmg.gg/fxHYK 
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://lmg.gg/Q9yyQ 
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://lmg.gg/8upii

## A Chinese Intel competitor?
 - [https://www.youtube.com/watch?v=BEqSHwk93lE](https://www.youtube.com/watch?v=BEqSHwk93lE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-08-16 00:00:00+00:00

Receive an additional $50 credit for Ting today when you sign up at https://linus.ting.com/

China's chip-making prowess has been getting increasingly sophisticated in recent years, and Zhaoxin has been at the forefront for years with its x86 cores. Let's take a look and see what they're like, shall we?

Buy G.SKILL Trident Z RGB memory
On Amazon (PAID LINK): https://geni.us/omlB
On Newegg (PAID LINK): https://geni.us/EErBoI

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1235158-a-chinese-intel-competitor/


GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Mech Keyboard: https://geni.us/RecNBTI
Nerd or Die Stream Overlays & Templates: https://geni.us/s8hBAgR
NEEDforSEAT Gaming Chairs: https://geni.us/needforseat
Get a Displate Metal Print at https://lmg.gg/displateltt
Use code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Gear on Amazon: https://www.amazon.com/shop/linustechtips
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0 https://lmg.gg/fxHYK 
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://lmg.gg/Q9yyQ 
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://lmg.gg/8upii

