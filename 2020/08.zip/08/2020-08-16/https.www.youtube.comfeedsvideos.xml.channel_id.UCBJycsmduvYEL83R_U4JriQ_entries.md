# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Dope Tech: The iPad Pro Killer?!
 - [https://www.youtube.com/watch?v=5NNO5Kb-PZo](https://www.youtube.com/watch?v=5NNO5Kb-PZo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-08-17 00:00:00+00:00

Have you ever seen a self-aligning wireless charger?
That shirt! http://shop.MKBHD.com

Xiaomi Smart Wireless Charger: ¯\_(ツ)_/¯

Hachi Infinite M1: https://amzn.to/30GKAam
$49.95 off Coupon Code: FKR96IZC (for Amazon)
Homepage: https://bit.ly/3ktT8t9

Galaxy Tab S7+: https://samsung.com/us/mobile/tablets/tab-s7/

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Great Moment by The Quiet
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

