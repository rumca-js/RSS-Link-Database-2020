# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## 'They haven't found anyone else out there like me'
 - [https://www.bbc.co.uk/news/uk-england-cornwall-53276271](https://www.bbc.co.uk/news/uk-england-cornwall-53276271)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-08-16 23:11:05+00:00

Charlotte Evans suffers from an undiagnosed condition that causes parts of her body to swell.

## The two students who took on Coke and Pepsi
 - [https://www.bbc.co.uk/news/business-53593138](https://www.bbc.co.uk/news/business-53593138)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-08-16 23:00:27+00:00

German friends Mirco Wiegert and Lorenz Hampl launched best-selling Fritz-Kola in 2003.

## Penguin waddling in Broxtowe picked up by police
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-53798757](https://www.bbc.co.uk/news/uk-england-nottinghamshire-53798757)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-08-16 16:52:12+00:00

The officers were surprised to see the aquatic bird in landlocked Nottinghamshire.

