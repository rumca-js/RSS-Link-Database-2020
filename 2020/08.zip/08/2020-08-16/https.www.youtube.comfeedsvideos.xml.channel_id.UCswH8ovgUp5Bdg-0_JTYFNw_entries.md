# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## If You Fall In Love Fast - Watch This... | Russell Brand
 - [https://www.youtube.com/watch?v=GfSushzin2k](https://www.youtube.com/watch?v=GfSushzin2k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-08-17 00:00:00+00:00

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

## One Of My Favourite Meditation Techniques! | Russell Brand
 - [https://www.youtube.com/watch?v=vILbhfaJDyw](https://www.youtube.com/watch?v=vILbhfaJDyw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-08-16 00:00:00+00:00

One of my favourite meditations to do are Mooji's - which you can find on YouTube. He was a guest on my Under The Skin podcast this week and here are some of the lessons I learned from him.

The full podcast will be out on YouTube next week but you can listen to it now on Luminary: http://luminary.link/mooji

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

