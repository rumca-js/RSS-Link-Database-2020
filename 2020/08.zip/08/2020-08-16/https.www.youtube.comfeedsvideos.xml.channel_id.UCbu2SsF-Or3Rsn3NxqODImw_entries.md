# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Apex Legends Season 6 - Everything You Need To Know In Under 5 Minutes
 - [https://www.youtube.com/watch?v=RgNYK3J_5xs](https://www.youtube.com/watch?v=RgNYK3J_5xs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-08-17 00:00:00+00:00

We breakdown everything that you need to know about Apex Legends newest update with the new Worlds Edge, Rampart, and some minor details you might have missed.

## Fortnite Drama Heats Up: Epic To Lose Apple Dev Accounts | Save State
 - [https://www.youtube.com/watch?v=apFrjIajYfY](https://www.youtube.com/watch?v=apFrjIajYfY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-08-17 00:00:00+00:00

Epic Games has filed for a temporary restraining order against Apple, after Apple announced it would be cutting off Epic's developer accounts for iOS and Mac, including those it uses to work on the Unreal Engine. WB Montreal is teasing a new Batman game, and a free co-op mode is coming to Ghost of Tsushima later this year.

00:00 - Intro
00:20 - Apple Is Cutting Off Epic Games
01:46 - Looks Like The Batman: Gotham Knights Reveal Is Tomorrow
2:42 - Ghost Of Tsushima Is Getting A Co-op Mode
3:40 - Outro

In today's gaming news, the lawsuit between Apple and Epic Games heats up. Epic Games has filed for a temporary restraining order against Apple, after Apple announced it would be cutting off Epic's developer accounts for iOS and Mac, including those it uses to work on the Unreal Engine.

Batman: Arkham Origins developer WB Montreal are teasing a new game, could it be the rumored Court Of Owls-inspired Gotham Knight?

Ghost of Tsushima is getting a co-op mode later this year. Legends will introduce new story missions, wave-based missions, as well as a raid. Don't forget to check out store.gamespot.com to get some awesome Play For All merch. All proceeds will be donated to Black Lives Matter and COVID-19 relief efforts.

## Ghost of Tsushima  Legends - Official 4K Announcement Trailer
 - [https://www.youtube.com/watch?v=jkdW3tgqqG4](https://www.youtube.com/watch?v=jkdW3tgqqG4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-08-17 00:00:00+00:00

Legends is a brand-new co-op multiplayer experience coming to Ghost of Tsushima, free for owners of the game on PlayStation 4. Coming this Fall.

## Halo Almost Wasn't An Xbox Game | Remember When
 - [https://www.youtube.com/watch?v=noE49iZ9Reg](https://www.youtube.com/watch?v=noE49iZ9Reg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-08-17 00:00:00+00:00

Halo is Microsoft’s crowning franchise, a series that changed console shooters forever, and the face of the Xbox brand. Except, it actually almost didn’t happen that way at all.

 In this episode of Remember When, Kurt Indovina looks back on how Halo was nearly a Mac exclusive, dissects exactly how it almost happened, and dares to question what a world would have been like if it actually did happen.Aiding Kurt on his journey is Halo co-creator Marcus Lehto, who gives some insight into what it was like to be a Mac developer in the 90s, early iterations of Halo, and the possibilities of what Halo would have been like if it was released only on Mac.

## Mortal Shell Review
 - [https://www.youtube.com/watch?v=Fqxk8Oq97HI](https://www.youtube.com/watch?v=Fqxk8Oq97HI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-08-17 00:00:00+00:00

Developer Cold Symmetry's budget action-RPG is a love letter to From Software's work, but Mortal Shell's take on similar ideas feels aimed at those who struggle to get through Soulsborne games.

## Sam Fisher In Rainbow Six Siege: Everything You Need To Know
 - [https://www.youtube.com/watch?v=Q4DDd7B5BWY](https://www.youtube.com/watch?v=Q4DDd7B5BWY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-08-16 00:00:00+00:00

Splinter Cell's Sam Fisher, aka Zero, is coming to Rainbow Six Siege, and he brings a camera that can peek through walls and fire lasers.

We might not be getting a new Splinter Cell game anytime soon, but Sam Fisher is stepping out of the shadows to join Rainbow Six Siege. Fisher, aka Zero, is a new Operator joining the roster for the new season, Operation Shadow Legacy. Tony goes over the new Attacker's abilities and gadgets in the video above.

There's more than a new season to check out in Rainbow Six Siege. The MUTE Protocol event was recently reinstated after a game-breaking invisibility bug caused Ubisoft to pull it. The event will run until 7 AM PT / 10 AM ET on August 24.

