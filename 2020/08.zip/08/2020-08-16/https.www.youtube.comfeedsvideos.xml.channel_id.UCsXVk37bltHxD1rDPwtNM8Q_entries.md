# Source:Kurzgesagt – In a Nutshell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsXVk37bltHxD1rDPwtNM8Q, language:en-US

## Unlimited Resources From Space – Asteroid Mining
 - [https://www.youtube.com/watch?v=y8XvQNt26KI](https://www.youtube.com/watch?v=y8XvQNt26KI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsXVk37bltHxD1rDPwtNM8Q
 - date published: 2020-08-16 00:00:00+00:00

Get Merch designed with ❤ from https://kgs.link/shop-127  
Join the Patreon Bird Army 🐧 https://kgs.link/patreon  
▼▼ More infos and links are just a click away ▼▼

Sources & further reading: 
https://sites.google.com/view/sources-asteroidmining/
 
Getting rare materials from the ground into your phone is ugly. The mining industry is responsible for air and water pollution and the destruction of entire landscapes. But what if we could replace the mining industry on Earth with a clean process that can’t harm anyone? Well, we can. All we need to do is look up.


OUR CHANNELS
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
German Channel: https://kgs.link/youtubeDE
Spanish Channel: https://kgs.link/youtubeES


HOW CAN YOU SUPPORT US?
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
This is how we make our living and it would be a pleasure if you support us!

Get Merch designed with ❤ from https://kgs.link/shop-127  
Join the Patreon Bird Army 🐧 https://kgs.link/patreon  


DISCUSSIONS & SOCIAL MEDIA
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
Reddit:            https://kgs.link/reddit
Instagram:     https://kgs.link/instagram
Twitter:           https://kgs.link/twitter
Facebook:      https://kgs.link/facebook
Discord:          https://kgs.link/discord
Newsletter:    https://kgs.link/newsletter


OUR VOICE
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
The Kurzgesagt voice is from 
Steve Taylor:  https://kgs.link/youtube-voice


OUR MUSIC ♬♪
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
700+ minutes of Kurzgesagt Soundtracks by Epic Mountain:

Spotify:            https://kgs.link/music-spotify
Soundcloud:   https://kgs.link/music-soundcloud
Bandcamp:     https://kgs.link/music-bandcamp
Youtube:          https://kgs.link/music-youtube
Facebook:       https://kgs.link/music-facebook

The Soundtrack of this video:

Soundcloud:   https://bit.ly/3gQMb2Z
Bandcamp:     https://bit.ly/2FjrAGX 

🐦🐧🐤 PATREON BIRD ARMY 🐤🐧🐦
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
Many Thanks to our wonderful Patreons from http://kgs.link/patreon who support us every month and made this video possible:

Orlando Lizarraga, Nessa, Felipe Di Gregorio, Traysea, Berta López Salamanca, Leon Kullig, Pranav Garg, Chonn Berdosh, Ernesto Silva, Francisco Salamanca Montero, Hrithik Shukla, Karen Brzostowski, Jokum Ziener, Sujana, Benji Rajaskas, Lanita Henne, Paul Linthicum, Kelly Ashman, Andrew Edwards, Eduard Nicodei, Nicola Occhipinti, Cheese Bungen, Crystal Parker, Owen Santos, Celine, Jeffrey Chua, Niclas38, Shashanka S Kundu, LeTibbers, Mohamad Hanano, May Palace, Ahmad Salim Al-Sibahi, Kian Saeidnia, Hunter Manhart, Ethan Alguire, Javier Siacca, Ramsey Elbasheer, Leela V, Logan A., Adam Ruggiero, Swaathikka Karthikeyan, Gary Arriaga, Leo Gili, Winslow Strong, Eitan Glinert, Sami Ergin, Liora Schwartz, Joan Bowman, Varun Boughram, Harrison Sherwin, Tobias, Patrick Höner, Menno van Wijk, alain reseau, Daniel Turner, Joselino Doumolin, Isaac Suttell, Gary Plumbridge, Pablo Moncada, Arsen Tufankjian, Harish Kumar, Daniel Hedtmann, Ameerah Allie, Michel H, Nathan Ducasse, Federico Tomasi, Lars Müller, Alex Simpson, Moritz Pongratz, Juan Vergara, Juan Pablo Acosta, Patrick Sullivan, Milo Corkey, Dadelfush, Konstanze Haubner, Saul Antonio Martinez Class, James Pizzurro, Ivan Teece, Matej Silný, Robert Woodward, Butterbean, Patrick Suchor, Chris Kirman, Dormitory Fedora, Tom Novelle, Johannes, Noe Ortiz, Rishi Rawat, Steph Craig, Eric Lamont, Gerasimos Chourdakis, Mike Bermingham, Julián Perdomo, kisame, Brandon Gibbons, Krisada Dabpetch, Traysea, Berta López Salamanca, Leon Kullig, Pranav Garg, Chonn Berdosh, Ernesto Silva, Francisco Salamanca Montero, Hrithik Shukla, Karen Brzostowski, Jokum Ziener, Sujana, Benji Rajaskas, Lanita Henne, Paul Linthicum, Kelly Ashman, Andrew Edwards, Eduard Nicodei, Nicola Occhipinti, Cheese Bungen, Crystal Parker, Owen Santos, Celine, Jeffrey Chua, Niclas38, Shashanka S Kundu, LeTibbers, Mohamad Hanano, May Palace, Ahmad Salim Al-Sibahi, Kian Saeidnia, Hunter Manhart, Ethan Alguire, Javier Siacca, Leela V, Logan A., Adam Ruggiero, Swaathikka Karthikeyan, Gary Arriaga, Leo Gili, Winslow Strong, Eitan Glinert, Sami Ergin, Liora Schwartz, Joan Bowman, Varun Boughram, Harrison Sherwin, Tobias, Patrick Höner, Menno van Wijk, alain reseau, Daniel Turner, Joselino Doumolin, Isaac Suttell, Gary Plumbridge, Pablo Moncada, Arsen Tufankjian, Harish Kumar, Daniel Hedtmann, Ameerah Allie, Michel H, Nathan Ducasse, Federico Tomasi, Lars Müller, Alex Simpson, Moritz Pongratz, Juan Vergara, Juan Pablo Acosta, Patrick Sullivan, Milo Corkey, Dadelfush, Konstanze Haubner, Saul Antonio Martinez Class, James Pizzurro, Ivan Teece, Matej Silný, Robert Woodward, Butterbean, Patrick Suchor, Chris Kirman, Dormitory Fedora, Felipe Di Gregorio, Tom Novelle, Johannes, Noe Ortiz, Rishi Rawat, Steph Craig, Eric Lamont, Gerasimos Chourdakis, Mike Bermingham, Julián Perdomo, kisame, Brandon Gibbons, Krisada Dabpetch, Orlando Lizarraga, Nessa, Ramsey Elbasheer, Camila Issa Svelti, Vincent Mak

