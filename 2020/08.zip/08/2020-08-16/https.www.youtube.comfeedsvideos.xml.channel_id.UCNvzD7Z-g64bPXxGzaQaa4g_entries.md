# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 13 Best Ninja Games & Samurai Games of All Time
 - [https://www.youtube.com/watch?v=krP9uh_EeDA](https://www.youtube.com/watch?v=krP9uh_EeDA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-08-17 00:00:00+00:00

Ninja Games | Samurai Games | Video games are always better when there's a katana involved. Here are some of our favorite samurai & ninja games.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

#13 Samurai Warriors 4
Platform: PS3 PS4 PS Vita

#12 Aragami
Platform: PC PS4 XBOX ONE SWITCH Linux

#11 Mark Of The Ninja
Platform: PC PS4 XBOX ONE SWITCH LINUX XBOX 360

#10 Naruto To Boruto: Shinobi Striker
Platform: PC PS4 XBOX ONE

#9 Tenchu
Platform: PS PS2 XBOX XBOX 360 PS Portable Nintendo DS Wii 

#8 Shadow Tactics: Blades Of The Shogun
Platform: PC PS4 XBOX ONE Linux

#7 Bushido Blade
Platform: PS

#6 Ninja Gaiden Series

#5 Nioh + Nioh 2 [PS4 ONLY]
Platform: PC PS4

#4 Onimusha
Platform: PC PS2 PS3 XBOX PS4 XBOX ONE Switch 

#3 Way Of The Samurai
Platform: PS2 PS Portable

#2 Sekiro: Shadows Die Twice
Platform: PC PS4 XBOX ONE STADIA

#1 Ghost Of Tsushima
Platform: PS4 

Bonus
The Mystical Ninja
SNES GBA

Genji: Dawn Of The Samurai 
PS2

For HonorPC 
PS4 XBOX ONE

Metal Gear Rising Revengeance
Platform: XBOX 360 PC PS3

## 10 CRAZY Things BRITISH Gamers Have Done
 - [https://www.youtube.com/watch?v=u9IPRw2-qvM](https://www.youtube.com/watch?v=u9IPRw2-qvM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-08-16 00:00:00+00:00

The United Kingdom is filled with gamers and some of them have taken their enthusiasm to the next level. Here are some crazy gaming news stories from the UK.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## Top 10 NEW CO-OP Games of 2020
 - [https://www.youtube.com/watch?v=UUVvuFX_LEE](https://www.youtube.com/watch?v=UUVvuFX_LEE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-08-16 00:00:00+00:00

Looking for a good co op game to play in 2020? We've got you covered with these games for PC, PS5, Series X, PS4, XB1, and Switch.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

#10 Hellpoint

Platform: PC PS4 XBOX ONE LINUX SWITCH

Release Date: July 30, 2020



#9 Minecraft Dungeons

Platform:   PC PS4 XBOX ONE SWITCH

Release Date:  May 26, 2020



#8 Battletoads

Platform: PC XBOX ONE

Release Date: August 20, 2020



#7 SpongeBob Battle for Bikini Bottom Rehydrated

Platform:  PC PS4 XBOX ONE SWITCH

Release Date: June 23, 2020



#6 Watch Dogs Legion

Platform:  PC PS4 PS5 XBOX ONE STADIA Xbox Series X

Release Date: 29 October 2020


#5 Baldur's Gate 3

Platform: PC 

Release Date: Q4 2020



#4 Outriders

Platform: PC PS4 PS5 XBOX ONE STADIA Xbox Series X

Release Date: Q4 2020



#3 Star Wars: Squadrons

Platform:  PC PS4 XBOX ONE

Release Date: October 3, 2020



#2 Marvel’s Avengers

Platform:  PC PS4 XBOX ONE STADIA September 4, 2020

Release Date: PS5 Xbox Series X Q4 2020



#1 Grounded

Platform: PC XBOX ONE

Release Date: July 28, 2020



BONUS

Gunfire Reborn

Platform:  PC

Release Date: 23 May, 2020



Godfall

Platform: PC PS5

Release Date: Late 2020

