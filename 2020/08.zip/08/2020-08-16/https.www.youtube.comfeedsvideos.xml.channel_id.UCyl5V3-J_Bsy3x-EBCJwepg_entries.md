# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## The Babylon Bee Goes Atheist, Owns Self
 - [https://www.youtube.com/watch?v=e--PLRQhHVM](https://www.youtube.com/watch?v=e--PLRQhHVM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-08-16 00:00:00+00:00

Kyle and Ethan transform into Atheists and absolutely destroy Christianity with 10 of the most brain-melting, and faith-shattering arguments ever.

Full ▶️  https://youtu.be/vahDLVR9jmo

