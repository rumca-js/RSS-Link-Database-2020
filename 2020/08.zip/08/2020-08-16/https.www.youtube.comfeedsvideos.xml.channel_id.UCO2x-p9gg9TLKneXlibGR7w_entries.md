# Source:Snazzy Labs, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w, language:en-US

## HDR is a SCAM! feat. LG OLED GX 77
 - [https://www.youtube.com/watch?v=fx-pfuszquk](https://www.youtube.com/watch?v=fx-pfuszquk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w
 - date published: 2020-08-16 00:00:00+00:00

HDR. We've all heard about it. But what does it *really* mean and is it *really* worth it? It's convoluted...

LG OLED77GX - Hit ‘where to buy’ for retail price! https://lgoled.co/SnazzyLabs (not sponsored)

Editors Correction: A TV stand is NOT included but a wall mount bracket comes with the purchase. The GX was made to be flush wall mounted: no gap, no shadow, nothing in the way.

Subscribe to my podcast Flashback! - http://relay.fm/flashback
Follow me on Twitter - http://twitter.com/snazzyq
Follow me on Instagram - http://instagram.com/snazzyq

HDR has now been marketed to consumers for a few years now but things are becoming increasingly complex and transparency from television manufacturers has become even more clouded. Let's talk about what high dynamic range is, what it will do for you, what HDR standards are supported by what TVs and if it really matters...

#LGOLED #SELFLITOLED #HDR

