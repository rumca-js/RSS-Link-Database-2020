# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Andrea Swensson interviews Jake Luppen
 - [https://www.youtube.com/watch?v=te1MyjjNbng](https://www.youtube.com/watch?v=te1MyjjNbng)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-08-16 00:00:00+00:00

Jake Luppen talks with Andrea Swensson about what he's been up to, not only with his primary band Hippo Campus, but also with his new side project Lupin, as well as the production work he's been doing for a host of other artists.
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## David Huckfelt - Three Songs for The Current
 - [https://www.youtube.com/watch?v=hYi5rjFw2dE](https://www.youtube.com/watch?v=hYi5rjFw2dE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-08-16 00:00:00+00:00

David Huckfelt and his band, the Unarmed Forces, share two songs from Huckfelt's forthcoming album, "Room Enough, Time Enough," plus a folksong to boot, in this video made for The Current.
SONGS PERFORMED
0:00 "Better To See The Face Than To Hear The Name"
5:03 "Book of Life"
9:15 "Roving Gambler"

