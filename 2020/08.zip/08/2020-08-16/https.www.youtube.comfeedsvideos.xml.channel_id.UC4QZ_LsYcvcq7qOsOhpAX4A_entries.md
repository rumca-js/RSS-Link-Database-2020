# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## The Strange Origins of Wi-Fi – An Australian Invention?
 - [https://www.youtube.com/watch?v=McbsxihcQS0](https://www.youtube.com/watch?v=McbsxihcQS0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2020-08-17 00:00:00+00:00

The strange story about the invention of Wi-Fi technology

--- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. 

If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- New Thinking Book written by Dagogo Altraide ---
This book was rated the 9th best technology history book by book authority.
In the book you’ll learn the stories of those who invented the things we use everyday and how it all fits together to form our modern world.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

--- ColdFusion Social Media ---
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusionTV

--- ColdFusion Podcast links ---
Google Podcasts - http://bit.ly/2xo8doR
Apple Podcasts - https://apple.co/2WI2IeU
Spotify - https://spoti.fi/2KT1taB
Stitcher - http://bit.ly/2WI4f4E

Sources:

https://hanwell.com/news/radio-vs-wifi/

https://www.physicsclassroom.com/mmedia/waves/em.cfm

https://www.khanacademy.org/science/physics/light-waves/introduction-to-light-waves/v/electromagnetic-waves-and-the-electromagnetic-spectrum

https://www.thoughtco.com/who-invented-wifi-1992663

https://www.autodesk.com/products/eagle/blog/electromagnetic-wireless-electronic-basics/

https://ethw.org/Vic_Hayes

https://www.autodesk.com/products/eagle/blog/wifi-vs-bluetooth-wireless-electronics-basics/

https://en.wikipedia.org/wiki/IEEE_802.11

https://en.wikipedia.org/wiki/Wi-Fi

https://patents.google.com/patent/US5487069

https://worldwide.espacenet.com/patent/search/family/003776560/publication/EP0599632A2?q=pn%3DEP0599632

https://en.wikipedia.org/wiki/John_O%27Sullivan_(engineer)

https://www.createdigital.org.au/australian-engineers-solved-wireless-networkings-biggest-problems-make-wifi/

https://www.smh.com.au/technology/how-australias-top-scientist-earned-millions-from-wifi-20091207-kep4.html

https://www.vice.com/en_au/article/9an9m7/heres-what-wi-fi-would-look-like-if-we-could-see-it

https://www.thoughtco.com/who-invented-wifi-1992663

https://en.wikipedia.org/wiki/ALOHAnet#ALOHA_protocol

//Soundtrack//

Burn Water - Nostalgia Dreams

A Zed And Two L's - Fila Brazillia

WMD - Sentimental

Seb Wildblood - -~^

LUCA - Your Name is Jim

Burn Water - Burning Love

» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide

