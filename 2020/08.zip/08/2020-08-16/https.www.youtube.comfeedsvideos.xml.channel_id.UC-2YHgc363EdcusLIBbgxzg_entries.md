# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## How The COVID-19 Pandemic Will End | Answers With Joe
 - [https://www.youtube.com/watch?v=XmjsLyTW5EY](https://www.youtube.com/watch?v=XmjsLyTW5EY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2020-08-17 00:00:00+00:00

Get a free subscription to Nebula when you sign up to CuriosityStream at http://www.curiositystream.com/joescott
We're all pretty much over the COVID-19 pandemic at this point, but how close are we to containing the disease, and how will it end?

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

https://www.theatlantic.com/health/archive/2020/08/coronavirus-will-never-go-away/614860/

https://www.sciencemag.org/news/2020/03/why-do-dozens-diseases-wax-and-wane-seasons-and-will-covid-19

https://www.npr.org/sections/health-shots/2020/07/24/894148860/without-a-vaccine-researchers-say-herd-immunity-may-never-be-achieved

https://www.historyofvaccines.org/content/articles/vaccine-development-testing-and-regulation

https://apnews.com/dacdc8bc428dd4df6511bfa259cfec44

https://www.infectioncontroltoday.com/view/viewpoint-have-you-heard-about-herd-its-covid-19-fallacy

https://www.the-scientist.com/features/why-r0-is-problematic-for-predicting-covid-19-spread-67690

https://www.thestreet.com/mishtalk/economics/swedens-covid-experiment-is-now-a-certified-failure

https://www.nejm.org/doi/full/10.1056/NEJMc2025179

https://www.nytimes.com/interactive/2020/science/coronavirus-vaccine-tracker.html

https://www.reuters.com/article/us-health-coronavirus-vaccines/astrazeneca-agrees-to-supply-europe-with-400-million-doses-of-covid-19-vaccine-idUSKBN23K0HW

https://www.newscientist.com/article/2250176-which-covid-19-treatments-work-and-how-close-are-we-to-getting-more/

https://www.healthline.com/health-news/want-to-sign-up-for-a-covid-19-vaccine-trial-heres-what-to-know

