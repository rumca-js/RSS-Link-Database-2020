# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Schiff: This is a shocking betrayal of our democracy
 - [https://www.cnn.com/videos/politics/2020/08/16/adam-schiff-donald-trump-usps-tsr-sot-vpx.cnn](https://www.cnn.com/videos/politics/2020/08/16/adam-schiff-donald-trump-usps-tsr-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-16 22:48:29+00:00

Rep. Adam Schiff (D-CA) says the emergency needs of the US Postal Service must be addressed, and accuses President Donald Trump of not wanting to improve the function of the USPS in an attempt to disenfranchise voters.

## Voters receive absentee ballot forms with Trump's face on them
 - [https://www.cnn.com/2020/08/16/politics/postal-service-trump-absentee-ballot-request-mail-usps/index.html](https://www.cnn.com/2020/08/16/politics/postal-service-trump-absentee-ballot-request-mail-usps/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-16 20:32:46+00:00

Given the crisis facing the United States Postal Service before a presidential election, the last thing John Herter expected to receive in the mail Saturday was an absentee ballot request form with President Donald Trump's face on it.

## Kamala Harris responds to Trump's birther attacks
 - [https://www.cnn.com/2020/08/16/politics/harris-trump-birther-attacks/index.html](https://www.cnn.com/2020/08/16/politics/harris-trump-birther-attacks/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-16 18:14:07+00:00

• Don Lemon: Guess how many GOP colleagues stood up for Kamala Harris?
• Meadows says Harris is eligible to be VP
• Analysis: Harris pick is a hit with voters

## Bernstein: This will be the GOP's shame for generations
 - [https://www.cnn.com/videos/media/2020/08/16/carl-bernstein-trump-mail-in-voting-usps-stelter-rs-vpx.cnn](https://www.cnn.com/videos/media/2020/08/16/carl-bernstein-trump-mail-in-voting-usps-stelter-rs-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-16 18:08:22+00:00

Legendary Watergate journalist Carl Bernstein speaks with CNN's Brian Stelter about what President Trump's attacks on mail-in voting mean for our democracy.

## How can you tell if a giant panda is pregnant?
 - [https://www.cnn.com/videos/travel/2020/08/16/national-zoo-panda-pregnancy-ultrasound-kj-orig.cnn](https://www.cnn.com/videos/travel/2020/08/16/national-zoo-panda-pregnancy-ultrasound-kj-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-16 17:57:05+00:00

Vets detected fetal tissue after giving Mei Xiang, a giant panda at the Smithsonian's National Zoo in DC, an ultrasound. She could give birth within days.

## Lewis Hamilton dominates to win Spanish GP and extend lead atop F1 standings
 - [https://www.cnn.com/2020/08/16/motorsport/spanish-gp-lewis-hamilton-formula-1-spt-intl/index.html](https://www.cnn.com/2020/08/16/motorsport/spanish-gp-lewis-hamilton-formula-1-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-16 16:01:25+00:00

Lewis Hamilton produced a dominant display to win the Spanish Grand Prix and extend his lead at the top of the Formula One standings.

## A cargo ship leaking tons of oil off an island coast has split in two
 - [https://www.cnn.com/2020/08/15/world/mauritius-oil-spill-ship-splits/index.html](https://www.cnn.com/2020/08/15/world/mauritius-oil-spill-ship-splits/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-16 13:02:22+00:00

A ship that has leaked tons of oil off the coast of Mauritius has split apart, authorities said on Saturday.

## A big sign Trump is a weak candidate
 - [https://www.cnn.com/2020/08/15/politics/trump-house-analysis/index.html](https://www.cnn.com/2020/08/15/politics/trump-house-analysis/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-16 12:10:49+00:00

It's often been said that President Donald Trump is "underperforming the fundamentals". Some believe Trump's doing worse than the average Republican president would be doing in the polls under similar circumstances. It's difficult to prove that, however.

## Lebanese President says it's 'impossible' for him to resign following Beirut's deadly blast
 - [https://www.cnn.com/2020/08/16/middleeast/lebanese-president-beirut-blast-intl/index.html](https://www.cnn.com/2020/08/16/middleeast/lebanese-president-beirut-blast-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-16 11:53:02+00:00

Lebanese President Michel Aoun has said it would be "impossible" for him to resign following calls for him to leave office over the deadly explosion in Beirut.

## The US President sought to reframe the fall election and shift blame for US Postal Service funding problems to Democrats
 - [https://www.cnn.com/2020/08/16/politics/trump-election-2020-usps-post-office/index.html](https://www.cnn.com/2020/08/16/politics/trump-election-2020-usps-post-office/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-16 11:42:37+00:00

President Donald Trump sought to reframe the fall election two days before the Democratic National Convention, arguing on Saturday that key economic and pandemic indicators were moving in his favor, while attempting to shift blame for US Postal Service funding problems to Democrats and refusing to acknowledge his administration's efforts to undermine the agency three months before Election Day.

## Biden heads into the conventions in a historically strong position
 - [https://www.cnn.com/2020/08/16/politics/biden-conventions-analysis/index.html](https://www.cnn.com/2020/08/16/politics/biden-conventions-analysis/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-16 11:11:54+00:00

First things first: The theme song of the week is The Nanny.

## Robert Trump, the younger brother of President Donald Trump, dead at age 72
 - [https://www.cnn.com/2020/08/15/politics/robert-trump-dead/index.html](https://www.cnn.com/2020/08/15/politics/robert-trump-dead/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-16 10:59:11+00:00

Robert Trump, 72, the younger brother of President Donald Trump, died Saturday at a New York hospital, Donald Trump announced in a statement.

## Depression stalks Canada's indigenous youth under lockdown
 - [https://www.cnn.com/2020/08/16/americas/canada-indigenous-youth-mental-health-intl/index.html](https://www.cnn.com/2020/08/16/americas/canada-indigenous-youth-mental-health-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-16 09:54:05+00:00

For Farrah Dixon, the words come slowly and reluctantly, a measure of both how she's been feeling during this pandemic, and how she'd prefer to never talk about it again.

## Men on death row for murder of British backpackers in Thailand get sentence commuted
 - [https://www.cnn.com/2020/08/16/asia/thai-backpackers-murder-pardon-intl-hnk/index.html](https://www.cnn.com/2020/08/16/asia/thai-backpackers-murder-pardon-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-16 05:18:50+00:00

Two men on death row for killing pair of British backpackers on a Thai island in 2014 have had their death sentences commuted to life imprisonment by the country's king.

## The wild tigers that terrorized Hong Kong
 - [https://www.cnn.com/2020/08/15/asia/tiger-hong-kong-hnk-dst-intl/index.html](https://www.cnn.com/2020/08/15/asia/tiger-hong-kong-hnk-dst-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-16 04:59:39+00:00

In 1929, two Chinese farmers were stopped by a British police officer while ambling down a road in a rugged part of Hong Kong's then-expansive rural hinterland.

## Boris Johnson may be taught a cruel lesson by Covid-19 in bid to reopen schools
 - [https://www.cnn.com/2020/08/16/uk/schools-pubs-uk-reopening-analysis-intl-gbr/index.html](https://www.cnn.com/2020/08/16/uk/schools-pubs-uk-reopening-analysis-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-16 04:05:49+00:00

Schools or pubs? That's the choice some believe UK Prime Minister Boris Johnson will face when English students return to their classrooms next month. The country has only recently been able to open establishments like pubs and restaurants, which suffered badly during lockdown.

## An Australian surfer punched a great white shark to save a woman being attacked
 - [https://www.cnn.com/2020/08/15/australia/australia-man-punches-shark-intl-hnk-scli/index.html](https://www.cnn.com/2020/08/15/australia/australia-man-punches-shark-intl-hnk-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-16 03:46:06+00:00

An Australian surfer repeatedly punched a great white shark to save his female companion who was being attacked by the animal in New South Wales state on Saturday.

## Democrats consider bringing House back into session next week over USPS issues
 - [https://www.cnn.com/2020/08/15/politics/democrats-house-postal-service/index.html](https://www.cnn.com/2020/08/15/politics/democrats-house-postal-service/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-16 02:04:34+00:00

Democrats are seriously considering whether to bring the House of Representatives back as early as next week to discuss some of the issues facing the United States Postal Service, one source familiar with the matter told CNN.

## Georgia State Patrol trooper charged with murder after shooting a Black man
 - [https://www.cnn.com/2020/08/15/us/georgia-state-patrol-trooper-murder-black-man-trnd/index.html](https://www.cnn.com/2020/08/15/us/georgia-state-patrol-trooper-murder-black-man-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-16 01:56:49+00:00

A Georgia State Patrol trooper has been arrested and charged with felony murder after fatally shooting a Black man during an attempted traffic stop.

## What Kamala Harris means to Indian Americans
 - [https://www.cnn.com/2020/08/15/opinions/what-kamala-harris-means-to-indian-americans-singh/index.html](https://www.cnn.com/2020/08/15/opinions/what-kamala-harris-means-to-indian-americans-singh/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-08-16 00:24:11+00:00

Kamala Harris, the daughter of Indian and Jamaican immigrants, became the first Black and South Asian American woman to run on a major political party's presidential ticket after presumptive nominee Joe Biden announced her as his VP pick on Tuesday.

