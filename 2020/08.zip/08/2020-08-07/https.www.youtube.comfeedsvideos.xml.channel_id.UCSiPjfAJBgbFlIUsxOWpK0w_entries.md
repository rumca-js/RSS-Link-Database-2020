# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## We tried lucid dreaming for a month. It was... hard
 - [https://www.youtube.com/watch?v=Yti4yYZqtMo](https://www.youtube.com/watch?v=Yti4yYZqtMo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2020-08-07 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 The Lucid Dreaming Soundtrack is on Spotify: https://open.spotify.com/album/3JPLnLbQ7K29GK3wuAikBY?si=bbH5VdP3QKC9OziH38NrWQ
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

Lucid Dreamers/Music By: Nataly Dawn & Jack Conte
Video Editor: Jeremiah Williams
Drawings: Lucia Catellani

