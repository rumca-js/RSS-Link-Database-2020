# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## The Anointed - Magic System Explained (My Book)
 - [https://www.youtube.com/watch?v=aPksk6bPnrI](https://www.youtube.com/watch?v=aPksk6bPnrI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-08-08 00:00:00+00:00

Here is the second magic system within my book. Inspired largely by Greek mythology, I plan to use this system as a counter to the rigid Grohalind.
Sign Up For Campfire Here: https://www.campfiretechnology.com/pro?utm_source=youtube&utm_medium=influencer&utm_campaign=Greene7.9-20 

Podcast: https://afictionalconversation.podbean.com/
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## DARK - Series Review
 - [https://www.youtube.com/watch?v=WGd0V7CiIG4](https://www.youtube.com/watch?v=WGd0V7CiIG4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-08-07 00:00:00+00:00

My review of Netflix's hit series DARK. A grim scifi story taking place in a small German town. 
Podcast: https://afictionalconversation.podbean.com/
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

