# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Taken - Movie Review
 - [https://www.youtube.com/watch?v=gEhbHr_YCzc](https://www.youtube.com/watch?v=gEhbHr_YCzc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-08-07 00:00:00+00:00

Part revenge spree, part missing person flick, all Liam Neeson! Here's my review for TAKEN!

