# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Amanda Shires - four songs at The Current
 - [https://www.youtube.com/watch?v=u7Ni-BHbN_E](https://www.youtube.com/watch?v=u7Ni-BHbN_E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-08-07 00:00:00+00:00

Two years ago this week, Amanda Shires' "To The Sunset" was our Album of the Week. What's more, about one year ago this week, Shires and her band visited our studio to play songs from "To The Sunset." Here are the songs from that 2019 performance.

SONGS PERFORMED
0:00 "Parking Lot Pirouette"
3:40 "Swimmer"
6:31 "Break Out The Champagne"
9:27 "White Feather"

PERSONNEL
Amanda Shires – vocals, fiddle, ukulele
Peter Levin – piano
Seth Plemmons – guitar

CREDITS
Video & Photo: Nate Ryan; Mary Mathis
Audio: Michael DeMark
Production: Derrick Stevens

FIND MORE:
2019 studio session: https://www.thecurrent.org/feature/2019/08/18/amanda-shires-performs-in-the-current-studio-to-the-sunset
2018 album review of "To The Sunset" by Mac Wilson: https://www.thecurrent.org/feature/2018/08/03/album-of-the-week-amanda-shires-to-the-sunset

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Taylor Goldsmith of Dawes - Live Virtual Session from The Current
 - [https://www.youtube.com/watch?v=OaxsuQCcTbA](https://www.youtube.com/watch?v=OaxsuQCcTbA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-08-07 00:00:00+00:00

Taylor Goldsmith of Dawes joins The Current's Mac Wilson for live virtual session to discuss the band's upcoming record 'Good Luck With Whatever'. 

01:05 "Who Do You Think You're Talking To"
10:03 "Saint Augustine at Night"
23:58 "Crack The Case"

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

