# Source:The Linux Experiment, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw, language:en-US

## The Best Apps for elementary OS (and other distros)
 - [https://www.youtube.com/watch?v=MWP5tNugYhk](https://www.youtube.com/watch?v=MWP5tNugYhk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw
 - date published: 2020-08-08 00:00:00+00:00

The first 1000 people who click the link will get 2 free months of Skillshare Premium: https://skl.sh/thelinuxexperiment0820 

elementary OS has managed to build a small, but robust ecosystem of apps that do one thing, but do it very well. These are one of the main draws to that specific distro, but most of them are also available outside of the elementary OS AppCenter, so let's take a look at some great applications for elementary OS, and if you can run them elsewhere.


Support the channel on Patreon: 
https://www.patreon.com/thelinuxexperiment

Follow me on Twitter : http://twitter.com/thelinuxEXP

My Gaming on Linux Channel: https://www.youtube.com/channel/UCaw_Lz7oifDb-PZCAcZ07kw

Follow me on LBRY: https://lbry.tv/@TheLinuxExperiment:e

The Linux Experiment merch: get your goodies there! https://teespring.com/en-GB/stores/the-linux-experiment


The first one is Ciano. It's a converter for any kind of format you'd like. It allows you to take any video, picture, or music file, and turn it into another format in a pinch. It's super fast, looks good and simple, and while it's not the best solution if you want to tweak a lot of settings before converting, it generally does an awesome job, and I use it all the time. Ciano allows multiple file conversions at the same time, and lets you pick the destination folder, or use the origin folder for the converted files. It's available on the AppCenter or on Flathub.

Next is Image optimizer. If you run a blog or a website, you'll need to make sure your images are compressed enough to not use too much space and guarantee speedy page loads. Image otpimizer is designed to do just that. It actually integrates into the file manager right click menu, so you can just select an image, right click on it, and optimize it immediately. I use it to reduce the file sizes on my website, thelinuxexp.com. The app is available on the AppCenter, or on Flathub.

TO complete this tour, there's Resizer. This is the useful counterpart to image optimizer, as it allows you to resize images in a pinch, from your right click menu in your file manager. You select a max height, or width, and the image will resize to ensure you don't lose the aspect ratio. It's extremely handy for my blog as well, and I recommend you grab it from the AppCenter. If youre using another distro, you can compile it from source, it's a pretty small one :)

## Productivity tools

Let's get to work! First is Planner. Most of you know I love this application, and it really deserves another highlight. Planner is a project management application that lets you create folders, projects, and tasks in that order, with a bunch of bells and whistles. It syncs with a todoist account, or you can sync the database using any other sync tool you use, and it supports tags, due dates, reminders, subtasks, notes and priorities.

Next is Outliner. A relatively new entry in the AppCenter, it allows you to quickly outline a plan for a presentation, a memo, or any long form document. 

Minder is next, and it's a terrific mind map application. It allows you to quickly jot down ideas and link them together, and offers a ton of ways to present your map, with color themes and various trees.

We move on to VGrive, a Google Drive syncing client. It's a fairly simple app: you log into it using your Google account, copy the key Google gives you, and select the folder where you want to sync all files, and the client will just do the rest, monitoring for changes one way or the other, and sync your files to and from your Google Drive.

Next we have Pebbles, a fantastically complete calculator application. It will let you do scientific calculations, statistics, date calculations, and even convert from any scientific unit to any other. 

To conclude, let us take a look at Color Picker. It's an extremely simple application, but it lets you grab any color on the screen, and copy its value, in any format you like: hexadecimal, RGB, or RGBA. 


First is Vocal, an awesome Podcast client. It will look up for podcasts from the iTUnes library, but you can also add your own through an RSS feed. It supports downloading or streaming episodes, lets you choose from which region you want to see results from the iTUnes store, it has a dark theme, and it can handle a queue of episodes. You can get it from the AppCenter, or Flathub.

Next is Byte. It's a small music player, which will let you play your local music collection, or web radios if you prefer. It has a fantastic, minimalistic interface which you can theme a bit, and lets you create playlists. 

If you prefer just listening to web radios, however, Tuner is a fantastic choice. It lets you browse any web radio, by genre.

Let's move on to Fondo, a small app to find new wallpapers. It searches through unsplash for  beautiful pictures you can use as your wallpaper, you just have to browse, or enter a search term, and click on the image to apply it as a wallpaper.

