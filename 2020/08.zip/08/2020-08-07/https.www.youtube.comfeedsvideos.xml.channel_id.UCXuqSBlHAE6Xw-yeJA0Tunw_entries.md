# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## ULTIMATE PC Tech Support Challenge - Jayztwocents vs Gamers Nexus
 - [https://www.youtube.com/watch?v=LOU9Ea60Zzc](https://www.youtube.com/watch?v=LOU9Ea60Zzc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-08-08 00:00:00+00:00

Thanks to Intel for sponsoring this Challenge! Enter our giveaway for a chance to win these PC's at https://geni.us/gcZ7
Learn more about Intel Gamer Days 2020: https://twitter.com/inteltech
Learn more about Intel® Core™ i9-10900K processors: https://geni.us/dQ4KA

Anyone can build a PC - But CAN THEY FIX ONE??? Who will come out on top in today's tech support battle between Jayztwocents and Steve from Gamers Nexus?

Shout-out to everyone who participated:
Co-Host: Austin @ https://www.youtube.com/channel/UC1IQIspOkCeV3WnYm32SBFQ
Contestant: Steve @ https://www.youtube.com/user/GamersNexus
Contestant: Jay @ https://www.youtube.com/user/Jayztwocents

Gamers Nexus Overclocking our System: https://www.youtube.com/watch?v=ZvDLt-9Q8bs

https://www.lttstore.com/ 

Buy Intel Core i7-10700K - CPU
On Amazon (PAID LINK): https://geni.us/wWu0IwW
On Newegg (PAID LINK): https://geni.us/XhxU

Buy ASUS Z490 Maximus XII Hero - Mobo
On Amazon (PAID LINK): https://geni.us/ckYb7w
On Newegg (PAID LINK): https://geni.us/caIRm

Sabrent 1TB M.2 - SSD
On Amazon (PAID LINK): https://geni.us/l10t
On Newegg (PAID LINK): https://geni.us/Y2i6PdA

EVGA RTX 2070 - GPU
On Amazon (PAID LINK): https://geni.us/PYVuB
On Newegg (PAID LINK): https://geni.us/wrB4NB

G.SKILL 16GB Trident Z RGB DDR4 - RAM
On Amazon (PAID LINK): https://geni.us/noUhQ
On Newegg (PAID LINK): https://geni.us/qVkwb

In-Win 805 - Case
On Amazon (PAID LINK): https://geni.us/CKvYi9
On Newegg (PAID LINK): https://geni.us/eW779

Seasonic Prime TX 1000 - PSU
On Amazon (PAID LINK): https://geni.us/iGPqZIB
On Newegg (PAID LINK): https://geni.us/wxnt9r9

ViewSonic XG270QG Gaming - Monitor
On Amazon (PAID LINK): https://geni.us/cX9t
On Newegg (PAID LINK): https://geni.us/yjK8

CORSAIR K95 - Keyboard
On Amazon (PAID LINK): https://geni.us/bwqDNQ
On Newegg (PAID LINK): https://geni.us/YM8XaI

CORSAIR Dark Core Pro - Mouse
On Amazon (PAID LINK): https://geni.us/Dwfp
On Newegg (PAID LINK): https://geni.us/PPxZE

CORSAIR VOID RGB ELITE - Headset
On Amazon (PAID LINK): https://geni.us/7B2Km
On Newegg (PAID LINK): https://geni.us/sjm2u

## Intel's Giant Leak... - WAN Show August 7, 2020
 - [https://www.youtube.com/watch?v=Rs4hTm6B9QQ](https://www.youtube.com/watch?v=Rs4hTm6B9QQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-08-07 00:00:00+00:00

** Video starts at 5:16. There doesn't seem to be any way to edit the first few minutes out of this due to some changes YouTube made to the live streaming system... Also can't enable monetization. Weird - LS **

Get the KernelCare & Extended Lifecycle Support* for CentOS® 6 Bundle today at https://lp.kernelcare.com/bundle-wan

Honey automatically applies the best coupon codes to save you money at 
different online checkouts, try it now at https://www.joinhoney.com/linus

Visit https://www.squarespace.com/WAN and use offer code WAN for 10% off

Check out Carpool Critics, our new movie podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Podcast Download: https://dts.podtrac.com/redirect.mp3/traffic.libsyn.com/secure/linustechtips/Intels_Giant_Leak..._-_WAN_Show_August_7_2020.mp3

Timestamps: (courtesy of Michael O'Brien)

00:00:00 - Stream Start!
00:00:04 - WOOOOOOO BOY! WELCOME!
 00:00:12 - Topic #1: Floatplane v App Store (Jump to 00:02:06)
 00:00:35 - Topic #2: Intel Leak (Jump to 00:13:06)
 00:01:10 - Topic #3: TikTok & WeChat (Jump to 00:37:05)
 00:01:18 - Topic #4: Get Unpacked (Jump to 00:50:27)
00:01:37 - Roll the Intro
00:02:06 - Topic #1: Floatplane on iOS
 00:02:40 - Relevancy of topic
 00:04:12 - "Great User Experience"
 00:06:08 - How Floatplane is impacted
 00:08:16 - Additional restrictions from Apple
 00:10:28 - Apple's hypocrisy
00:13:06 - Topic #2.1: Intel's 20GB of IP (not of the v4 or v6 variety)
 00:14:27 - Backdoor in firmware?
 00:14:37 - Password practices are the best!
 00:15:09 - How it was found & where it was
 00:17:01 - Initial meta overview of why it was offsite
 00:18:53 - TRAINING VIDEOS!
00:18:57 - Meme opportunity #1
00:19:38 - Topic #2.2: Nintendo tie-in
 00:20:46 - Weird Yoshi
 00:22:23 - Overview of the Nintendo leak
 00:23:35 - LTT Confessions
 0:26:33 - And this is when Luke gets hatemail
00:27:04 - Sponsors!
 00:27:14 - SquareSpace - 10% Off - squarespace.com/wan
 00:28:04 - Honey - joinhoney.com/linus
00:28:44 - Technical problems!
 00:29:08 - Cloudlinux - ELS for CentOS 6 30% off, 15% discount on KernelCare lp.kernelcare.com/bundle-wan
00:30:31 - Happy Linus! Sebastian, not Torvalds
00:31:57 - Dr DisRespect Streams!
 00:32:15 - Linus is famous
 00:32:48 - "Too Mad PC" Colab Details
00:34:37 - To PC or not to PC?
00:35:47 - lttstore.com
00:37:05 - Topic #3: US Banning TikTok & WeChat in 45 days
 00:38:03 - "Poorly worded, ill prepared"
 00:39:46 - Getting past The Great Firewall
 00:42:09 - Trillian nostalgia et al.
00:44:44 - Tangent #1: Current state of notifications on Windows & Android
 00:46:15 - Google, Listen up!
 00:47:32 - Luke's trials & tribulations
 00:49:41 - [Microsoft] Teams' woes
00:50:27 - Topic #4: "Get Unpacked" the Samsung event
 00:51:06 - Note 20 hot take
 00:52:05 - Note 20 Ultra hot take
 00:52:51 - Math!
 00:53:39 - Galaxy Watch 3 hot take
 00:54:20 - Galaxy Z Fold 2 hot take
00:55:55 - Tangent #2: Buy a car or a phone?
00:57:16 - Tangent #3: Buying a Tesla
 00:58:38 - Tesla's delivery process
 01:00:14 - Fanboys!
 01:01:43 - "Fix the roof" analogy
 01:02:29 - Luke's self-proclaimed Nintendo fanboy
 01:03:51 - Today's Guest on The View, Linus Sebastian
 01:06:33 - No apology videos!
01:07:25 - PC Tech Support Challenge Sponsored by Intel Stream on August 8th
 01:08:15 - #Lienus
 01:09:25 - 3 [fixed] computer systems given away
 01:09:57 - Stream is at 12:00 pm PDT, August 8th
 01:10:14 - The will to prove that the other is not as good...
01:10:50 - Meme opportunity #2
01:11:34 - Linus' Bounty - $2500 (Watch for details)
01:14:50 - SUPERCHATS!
 01:16:14 - Tangent #4: Honesty
01:17:55 - Inexperience vs Maliciousness
01:19:13 - Linus will do anything for money
 01:19:24 - Luke schools Linus' on technique
01:20:07 - Loving the Gestapo
01:22:35 - Luke's missing "Bye"

