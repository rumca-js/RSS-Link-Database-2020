# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Rob Lowe Recounts Bombing at the 1989 Oscars
 - [https://www.youtube.com/watch?v=-_edyRObneQ](https://www.youtube.com/watch?v=-_edyRObneQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-08-08 00:00:00+00:00

Taken from JRE #1522 w/Rob Lowe: https://youtu.be/pw8dkF-jotk

## Innocence Project Ambassador's Detail How Wrongful Convictions Happen
 - [https://www.youtube.com/watch?v=ROU7G0d4iyE](https://www.youtube.com/watch?v=ROU7G0d4iyE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-08-07 00:00:00+00:00

Taken from JRE #1521 w/Josh Dubin and Jason Flom:
https://youtu.be/Trh7YWo2Bmo

## James Cameron Was Visiting the Titanic on One of the Worst Days in US History
 - [https://www.youtube.com/watch?v=KvSl7kF7c_E](https://www.youtube.com/watch?v=KvSl7kF7c_E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-08-07 00:00:00+00:00

Taken from JRE #1522 w/Rob Lowe: https://youtu.be/pw8dkF-jotk

## Rob Lowe Remembers Working with “Intense” Patrick Swayze
 - [https://www.youtube.com/watch?v=I_H_RXZoG6s](https://www.youtube.com/watch?v=I_H_RXZoG6s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-08-07 00:00:00+00:00

Taken from JRE #1522 w/Rob Lowe: https://youtu.be/pw8dkF-jotk

## Rob Lowe Talks Tommy Boy, Chris Farley
 - [https://www.youtube.com/watch?v=71tVLlJFQMI](https://www.youtube.com/watch?v=71tVLlJFQMI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-08-07 00:00:00+00:00

Taken from JRE #1522 w/Rob Lowe: https://youtu.be/pw8dkF-jotk

## Rob Lowe Tells Phil Hartman, SNL Stories
 - [https://www.youtube.com/watch?v=a_sjDH2Vu2M](https://www.youtube.com/watch?v=a_sjDH2Vu2M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-08-07 00:00:00+00:00

Taken from JRE #1522 w/Rob Lowe: https://youtu.be/pw8dkF-jotk

## Rob Lowe and His Sons Went Hunting for Bigfoot
 - [https://www.youtube.com/watch?v=s80qJn1RdZI](https://www.youtube.com/watch?v=s80qJn1RdZI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-08-07 00:00:00+00:00

Taken from JRE #1522 w/Rob Lowe: https://youtu.be/pw8dkF-jotk

## Rob Lowe and Joe Rogan Discuss Psychedelic Experiences
 - [https://www.youtube.com/watch?v=51QnLc9Bb2k](https://www.youtube.com/watch?v=51QnLc9Bb2k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-08-07 00:00:00+00:00

Taken from JRE #1522 w/Rob Lowe: https://youtu.be/pw8dkF-jotk

## Rob Lowe on Fame "What's the Point of Being Famous Today?"
 - [https://www.youtube.com/watch?v=zAClRJZclHg](https://www.youtube.com/watch?v=zAClRJZclHg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-08-07 00:00:00+00:00

Taken from JRE #1522 w/Rob Lowe: https://youtu.be/pw8dkF-jotk

