# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Top 25 NEW Single Player Games of 2020
 - [https://www.youtube.com/watch?v=8gyd3bSNE8Q](https://www.youtube.com/watch?v=8gyd3bSNE8Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-08-08 00:00:00+00:00

2020 is filled with great single player games. Here's everything for PS4, PS5, Xbox One, Series X, Nintendo Switch, and beyond.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Disclaimer: Elder RIng, Vampire: The Masquerade – Bloodlines, Dying light 2 likely not coming out this year.


#25 Yakuza: Like a Dragon 

Platform: PC PS4 XBOX ONE PS5 Xbox Series X

 November TBA 2020





#24 Mafia: Definitive Edition

Platform: PC PS4 XBOX ONE

Release date: September 25, 2020





#23 The Medium

Platform: PC Xbox Series X

Release date: Q4 2020



#22 Crash Bandicoot 4: It's About Time. 

Platform: PS4, XBOX ONE

Release date: October 2, 2020





#21 Nioh 2

Platform: PS4

Release date: March 13, 2020





#20 Crusader Kings III 

Platform: PC Linux

Release date: September 1, 2020





#19 Stoneshard

Platform: PC

Release date: Feb 6, 2020



#18 Carrion

Platform: PC, Xbox One, Nintendo Switch, PS4

Release date: July 23, 2020





#17 Desperados III

Platform: PC PS4 XBOX ONE

Release date: 16 June 2020



#16 Half-Life: Alyx

Platform: PC Linux

Release date:  March 23, 2020



#15 Final Fantasy VII Remake

Platform: PS4

Release date: April 10, 2020



#14 RESIDENT EVIL 3

Platform: PC PS4 XBOX ONE

Release date: April 3, 2020



#13 PERSONA 5 ROYAL

Platform: PS4

Release date: March 31, 2020



#12 Assassin's Creed Valhalla 

Platform: PC, PS4, XBOX ONE, Stadia

Release date: November 17



#11 Destroy All Humans! Remake

Platform: PC PS4 XBOX ONE STADIA

Release date: July 28, 2020



#10 ORI AND THE WILL OF THE WISPS

Platform: PC XBOX ONE

Release date: March 11, 2020



#9 The Last of Us Part II

Platform: PS4

Release date:  June 19, 2020



#8 Halo Infinite

Platform: PC XBOX ONE Xbox Series X

Release date: Q4 2020



#7 Watch Dogs Legion 

Platform: PC, PS4, XBO, Stadia

Release date: October 29 



#6 Spider-Man: Miles Morales PS 5

Platform: PS5

Release date: Q4 2020



#5 Marvel's Avengers

Platform: PC PS4 XBOX ONE STADIA 4 September 2020

Release date: PS5 Xbox Series X Q4 2020



#4 Animal Crossing: New Horizons 

Platform: Nintendo Switch

Release date: March 20, 2020



#3 Ghost of Tsushima

Platform: PS4

Release date: July 17, 2020



#2 Doom Eternal 

Platform: PC PS4 XBOX ONE STADIA

Release date: March 20, 2020



#1 Cyberpunk 2077

Platform: PC, PS4, XBO, Stadia

Release date: November 19



BONUS

Horizon Zero Dawn Complete Edition

Platform: PC

Release date: 7 August 2020



Tony Hawk’s Pro Skater 1 and 2

Platform:  PC PS4 XBOX ONE

Release date: September 4, 2020



Kingdoms of Amalur: Re-Reckoning

Platform: PC PS4 XBOX ONE

Release date: September 8, 2020



Maneater

Platform: PC PS4 XBOX ONE

Release date: May 22, 2020



Gears tactics

Platform: PC

Release date: April 28, 2020



Serious Sam 4

Platform: PC Stadia

Release date: 24 September 2020

## 5 Things That Could Go Extinct With PS5 & Xbox Series X
 - [https://www.youtube.com/watch?v=tXqoAoHdEhg](https://www.youtube.com/watch?v=tXqoAoHdEhg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-08-07 00:00:00+00:00

The future of gaming technology is exciting. We're optimistically speculating on things that could change with the next-generation consoles: PS5 and Xbox Series X.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## Horizon Zero Dawn PC: Before You Buy [4K 60FPS]
 - [https://www.youtube.com/watch?v=fPiOW3dDj9k](https://www.youtube.com/watch?v=fPiOW3dDj9k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-08-07 00:00:00+00:00

Horizon: Zero Dawn finally arrives on PC. Available on both Steam and Epic, we've got a quick look at the graphics and what you can expect.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## TAKE-TWO CLARIFIES $70 NEXT GEN GAME PRICE,  ROCKSTEADY'S NEXT GAME REVEALED, & MORE
 - [https://www.youtube.com/watch?v=DG61eZNKjxs](https://www.youtube.com/watch?v=DG61eZNKjxs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-08-07 00:00:00+00:00

Thanks Omaze for sponsoring! For your chance to win your dream PC along with exclusive gear for Razor and support a great cause, go to https://bit.ly/You-Win-Gaming-Rig

Sony shows off some new games for PS4 and PS5, Rocksteady gears up to announce a new superhero game, Horizon Zero Dawn launches on PC, and more in a week FULL of gaming news.

*Jakes twitter: https://twitter.com/jakebaldino 
*Instagram: https://goo.gl/HH6mTW 


Jake's other channel: https://youtu.be/HthcS8kcEtk



 ~~~~STORIES~~~~


Suicide Squad Kills The Justice League: 
https://twitter.com/suicidesquadRS/status/1291720914485223424

2K changes their tune on pricing: https://arstechnica.com/gaming/2020/08/take-two-says-70-game-prices-arent-necessarily-a-new-next-gen-standard/

Sony State of Play: https://youtu.be/t6VUOmNFnG4
Hitman VR: https://youtu.be/uwjdl6vpxGU
Crash 4: https://youtu.be/bdRZGc1mQkU


Spider-Man Avengers
https://www.pcgamer.com/avengers-dev-explains-why-spider-man-is-a-playstation-exclusive/


Tomb Raider https://t.co/MLIY9MnxSR?amp=1

Flight Simulator development explained: https://youtu.be/ng-mGNqLe6M

Pikmin 3 on Switch: 
https://youtu.be/aSSQ0Z6eDhU

FF game: https://youtu.be/lHLFu0RMw0E

Halo n64 (twitch raid them lol)
https://youtu.be/qZpQoeHobFQ

Next Call of Duty teased?
https://charlieintel.com/mysterious-crate-arrives-from-activision-ahead-of-cod-2020-reveal/61687/

