# Source:Mandalore Gaming, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw, language:en-US

## Call of Cthulhu Review
 - [https://www.youtube.com/watch?v=WmC-Fb0Wuy8](https://www.youtube.com/watch?v=WmC-Fb0Wuy8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw
 - date published: 2020-08-07 00:00:00+00:00

Déjà vu? This review isn't about Dark Corners of the Earth, it's about the 2018 version. Call of Cthulhu the Official Video Game. What a subtitle. 
Support the channel at: https://www.patreon.com/mandaloregaming or https://www.paypal.me/MandaloreGaming
I take video suggestions at mandaloremovies@gmail.com
Twitter: https://twitter.com/Lord_Mandalore
#CallofCthulhu #CallofCthulhuGame #CallofCthulhuReview #CallofCthulhuPCGame #Cthulhu

00:00 - Intro
00:45 - Game Premise
1:56 - Visuals
5:18 - Music & Sound Design
7:15 - Gameplay Mechanics
14:12 - Story
14:56 - Story (SPOILERS)
22:07 - Conclusions
22:54 - Credits
23:55 - Brian?

