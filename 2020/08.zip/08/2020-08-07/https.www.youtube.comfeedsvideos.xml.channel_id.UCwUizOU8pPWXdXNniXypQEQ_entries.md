# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## The Insanity of Picking a Side - Authentic JP
 - [https://www.youtube.com/watch?v=SXM6RMissmI](https://www.youtube.com/watch?v=SXM6RMissmI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-08-08 00:00:00+00:00

Grab your Awakened Shirt here - https://awakenwithjp.com/shop

With politics, the idea of picking a side and then being against the other side, while believing that will somehow help the world has become normal. The problem is this practice has insanity, greed, power, and divisiveness at its roots. Gearing up for the election the “pick a side” mantra is being pressed into our brains more than ever. Maybe instead of picking a side, you can pick something else...

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

