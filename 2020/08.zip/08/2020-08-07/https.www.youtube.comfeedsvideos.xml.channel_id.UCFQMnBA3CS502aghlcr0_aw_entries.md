# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## PAID DATING APPS ARE FOR SIMPS (according to math & science)
 - [https://www.youtube.com/watch?v=GMqv6SHwJkE](https://www.youtube.com/watch?v=GMqv6SHwJkE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-08-08 00:00:00+00:00

This episode is proudly sponsored by Pacific Shaving Company
https://www.pacificshaving.com/
https://www.instagram.com/pacificshaving/

the truth will set you free. Paid dating apps are for simps according math and science. Match Group Inc owns Tinder, Plenty of Fish, Match.com, Hinge and more

