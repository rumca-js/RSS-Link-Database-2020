# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Apple just banned xCloud
 - [https://www.youtube.com/watch?v=dMS1NSqJVes](https://www.youtube.com/watch?v=dMS1NSqJVes)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2020-08-07 00:00:00+00:00

0:00 Intro
0:20 Apple bans xCloud
3:28 Mediatek rescues Huawei
5:39 Should have been the Note 20e


Tech quiz: https://crrowd.com/quiz

Join our Discord: https://discord.gg/npKQebe


[[[ TECHALTAR LINKS ]]]:


Merch:

http://enthusiast.store


Social media:
https://twitter.com/TechAltar
https://instagram.com/TechAltar

https://facebook.com/TechAltar


If you want to support TechAltar directly:

https://flattr.com/@techaltar


My video gear:
https://kit.co/TechAltar/video-gear

