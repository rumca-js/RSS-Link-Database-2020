# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Nebraska farmers are tired of being dicked around
 - [https://www.youtube.com/watch?v=FPgSG41Jk7M](https://www.youtube.com/watch?v=FPgSG41Jk7M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-08-08 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
To: Steve Halloran shalloran@leg.ne.gov,  Pete Ricketts pete.ricketts@nebraska.gov
Cc: "tbrandt@leg.ne.gov" tbrandt@leg.ne.gov, 
 Carol Blood cblood@leg.ne.gov, 
 "bhansen@leg.ne.gov" bhansen@leg.ne.gov, 
 "slathrop@leg.ne.gov" slathrop@leg.ne.gov, 
 "mmoser@leg.ne.gov" mmoser@leg.ne.gov, 
 "jslama@leg.ne.gov" jslama@leg.ne.gov, 
 "jalbrecht@leg.ne.gov" jalbrecht@leg.ne.gov, 
 "kbolz@leg.ne.gov" kbolz@leg.ne.gov, 
 "bbostelman@leg.ne.gov" bbostelman@leg.ne.gov, 
 "tbrewer@leg.ne.gov" tbrewer@leg.ne.gov, 
 "tbriese@leg.ne.gov" tbriese@leg.ne.gov, 
 "rclements@leg.ne.gov" rclements@leg.ne.gov, 
 "scrawford@leg.ne.gov" scrawford@leg.ne.gov, 
 "wdeboer@leg.ne.gov" wdeboer@leg.ne.gov, 
 "mdorn@leg.ne.gov" mdorn@leg.ne.gov, 
 Steve Erdman serdman@leg.ne.gov, 
 "cfriesen@leg.ne.gov" cfriesen@leg.ne.gov, 
 "sgeist@leg.ne.gov" sgeist@leg.ne.gov, 
 "tgragert@leg.ne.gov" tgragert@leg.ne.gov, 
 "mgroene@leg.ne.gov" mgroene@leg.ne.gov, 
 "mhansen@leg.ne.gov" mhansen@leg.ne.gov, 
 Mike Hilgers mhilgers@leg.ne.gov, 
 "dhughes@leg.ne.gov" dhughes@leg.ne.gov, 
 "mkolterman@leg.ne.gov" mkolterman@leg.ne.gov, 
 John Lowe jlowe@leg.ne.gov, Dave Murman dmurman@leg.ne.gov, 
 "ppansingbrooks@leg.ne.gov" ppansingbrooks@leg.ne.gov, 
 "jscheer@leg.ne.gov" jscheer@leg.ne.gov, 
 "jstinner@leg.ne.gov" jstinner@leg.ne.gov, 
 "lwalz@leg.ne.gov" lwalz@leg.ne.gov, 

 "mwilliams@leg.ne.gov" mwilliams@leg.ne.gov, 




Dear Senator Halloran-Ag Committee Chairman

cc:  Unicameral Senators / Ag Lobby
bcc: Hundreds of Nebraska Farmers, Ranchers, NEFB Members, NEFU Members & Farm Mechanics

It comes as no surprise that the medical establishment is upset that they can't even fix their COVID-19 Ventilators due to unbridled 'Corporate Greed'.  Hero Senators just announced the bill titled, "The Critical Medical Infrastructure Right-to-Repair Act of 2020".(1) To date, no relief for Nebraska Farmers in their legislative quest via the Unicameral to obtain repair software for their farm tractors.  

Today, ONLY approved Ag Dealerships get access to repair & diagnostic software for Tractors...

The Farmers & Ranchers spoke via their Nebraska Farm Bureau Delegates in 2016 (100%) & 2019 (176-1) "In Favor" of Right-to-Repair.(2)  The Nebraska Farmers Union is also 100% on board. They want help from their State Senators to fix their tractors...that's a fact.  

Hats off to the talented Lobbyists (AEM & EDA) who obviously do a great job winning vs this overwhelming majority of your constituent-Farmers & Ranchers who are left holding a worsening farm-lot filling up of ag equipment vulnerable to more expensive fixes each year.  

This Monopoly on Ag Repair has got to stop.  Please forward the bill, "Farm Equipment Repair Act" to the drafting Committee as an Ag Committee Priority Bill.(3)   

(1)    https://www.wyden.senate.gov/imo/media/doc/Critical%20Medical%20Infrastructure%20Right%20to%20Repair%20Act%20of%202020%20Bill%20Text.pdf

(2)    https://uspirg.org/blogs/blog/usp/nebraska-farmers-vote-overwhelmingly-right-repair

(3)    ref attached pdf


Lastly, a 'Compromise Agreement'(MOU) between the NEFB/NFU & the Ag Equipment Industry is flat out worthless without access to 'Payload Files'...or software patches.  We need exactly the same Deal as the Dealers get.  Any compromise here will result in a continued 100% Monopoly on Repair & Independent Farm Mechanics will be left out.  

All we want is what the Automobile Industry already has....repair software....

## Board repair featuring discussion of a new trade association
 - [https://www.youtube.com/watch?v=-snMxmZXcgg](https://www.youtube.com/watch?v=-snMxmZXcgg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-08-07 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
🔵 We fix Macbooks & offer free estimates. https://rossmanngroup.com
🔵 Send us your Macbook for repair! http://bit.ly/sendmacbook
🔵 We'll send you a box with a pre-paid shipping label for your repair! http://bit.ly/sendyourmacbook
🔵 We offer iPhone data recovery: http://bit.ly/2BDBX4G
🔵 We offer lab hard drive data recovery: http://bit.ly/labdatarecovery

👉 LEARN HOW TO DO THIS:
› In-person classes: https://bit.ly/classrg
› Beginner's guide: http://bit.ly/2k6uz84
› Support forum: $29/mo http://bit.ly/boardrepairforum

👉 Donate & post a message: http://bit.ly/postamessage 

👉 Below we list tools & recording gear we use, repair guides to help you learn, online chip sources, & donation links:

👉 BlackBerry, Oreo, & Clinton the cat's wish list: https://www.amazon.com/hz/wishlist/ls/2YC1L66N7T5BC?&sort=default

👉 CHIPS & COMPONENTS:
› http://bit.ly/2jaAOXM

👉 Discord: https://tinyurl.com/rossmatrix

👉 TOOLS USED:

✓ Soldering Irons:
› Louis' Hakko station(no tweezers): http://amzn.to/2cKkMyO 
› Paul's Hakko station(works with tweezers): http://amzn.to/2yMvWNy
› Micro Soldering Pencil: http://amzn.to/2d5MWUP
› Hot tweezers: http://amzn.to/2yMvZsZ
› Atten ST-862D hot air station: http://bit.ly/atten862

✓ CHEAP HAKKO ALTERNATIVES:
› TS100 soldering iron: https://amzn.to/2Gy1Fqz
› Recommended tips: TS-C4: https://amzn.to/33s3jpW TS-KU https://amzn.to/2QsKT36

✓ Preferred Soldering Tips
› Fine: http://amzn.to/2d5MgPn 
› Flat: https://amzn.to/2JnsDBT 
› GPU wicking: http://amzn.to/2w8chtB
› Micro soldering tip: http://amzn.to/2qUSFDh

✓ Microscopes:
› Microscope: http://amzn.to/2iLrE16 
› Barlow lens: http://amzn.to/2yMKdKf
› LED light: http://amzn.to/2nzfPT2
› CHEAP alternative microscope: http://amzn.to/2rTlHbj

✓ Soldering/Repair Supplies:
› Solder: http://amzn.to/2cKkxUp
› Desoldering braid: http://bit.ly/2otflOX
› Flux: http://bit.ly/amtechflux
› Solder paste: http://bit.ly/amtechsolderpaste
› THICK insulated jumper wire: https://amzn.to/2rvtD0A
› THIN insulated jumper wire: https://amzn.to/2I47DQY
› Kapton tape: http://amzn.to/2yN0xuq
› Tweezers: http://amzn.to/2d5NBpi
› Blades: http://amzn.to/2ByWnvF
› Freeze Spray: http://amzn.to/2BySozw
› Conformal coating: http://bit.ly/greencoate
› Conformal coating curing pen: http://bit.ly/uvpen

✓ Diagnostic tools:
› USB amp meter: http://bit.ly/2B2Lu5W
› USB-C amp meter: http://bit.ly/usbcamp
› On-Screen multimeter: http://amzn.to/2jtgY9K 
› Multimeter Probes: http://bit.ly/fineprobes
› CHEAP multimeter: http://amzn.to/2zjkg8U
› Bench PSU: CSI3005P http://bit.ly/benchsupply
› Phoneboard: https://phoneboard.co
› Boardview software: https://pldaniels.com/flexbv/

✓ Ultrasonic Cleaning:
› ALL MACBOOKS & CELLPHONES: Crest P1200H-45: https://amzn.to/2ITSQdw
› PRE-TOUCHBAR MACBOOKS & CELLPHONES: Crest P500H-45: https://amzn.to/2Qrnhf8
› CELLPHONES ONLY: Crest P230H-45: https://amzn.to/2QsckKG
› Branson EC cleaning fluid: http://amzn.to/2cKlBrp

✓ Desk supplies:
› Desk: http://amzn.to/2yMShdZ
› Chair: https://amzn.to/2LB8bUB
› Fume Extractor: http://amzn.to/2d5MGoD
› Work mat: http://amzn.to/2yMtlTR
› Outlets: http://amzn.to/2yNsZwo
› Gloves: http://amzn.to/2iUfumS
› Durable lightning cable: http://amzn.to/2yNHzUt
› Fine tipped snippers: http://amzn.to/2HGt4XB

✓ Screwdrivers: 
› iPhone bottom screw: http://amzn.to/2yNwX8p
› Macbook bottom screw: http://amzn.to/2AKMdVb
› Torx T3: http://amzn.to/2zjtxxH
› Torx T5 http://amzn.to/2BLNDn4
› Torx T6 http://amzn.to/2B0XIfA
› Torx T8 http://amzn.to/2CpWp68
› Phillips #0: http://amzn.to/2AJaHhM
› Phillips #000: http://amzn.to/2yNqsCl



✓ RECORDING EQUIPMENT:
› Work cam: https://amzn.to/2QjHnt0
› Overhead cam: http://amzn.to/2eAH0oT
› Work mic: https://amzn.to/2WGIhzw
› Home mic: https://amzn.to/2xfampC
› Microscope camera: http://amzn.to/2icVQoG - mine is DISCONTINUED, closest one I can find. 
› HDMI capture: http://amzn.to/2iyGcle

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com

👉 Leave a tip for us via cryptocurrency if we've helped you out:
› Credit card: http://bit.ly/postamessage
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

## Deblasio and Cuomo spar over rich residents
 - [https://www.youtube.com/watch?v=sAxaCD6BMh4](https://www.youtube.com/watch?v=sAxaCD6BMh4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-08-07 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
https://www.unitedvanlines.com/newsroom/movers-study-2018?utm_source=dynamic&utm_medium=press&utm_campaign=National-Movers-Study&utm_content=2018-interactive-map

Over 41% of the people who left make $150k & up. People who make under $50,000 made up only 8.4% of those leaving. 

https://gothamist.com/news/census-report-new-york-losing-new-yorkers

New York is losing more people than any other area of the country.
👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

## Google antitrust problem explained in 59 seconds
 - [https://www.youtube.com/watch?v=5LfiY4HIr5E](https://www.youtube.com/watch?v=5LfiY4HIr5E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-08-07 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
https://www.blog.google/products/ads/restricting-ads-third-party-tech-support-services/
https://www.ifixit.com/News/31131/an-open-letter-to-the-ftc-on-googles-banning-of-repair-business-ads

https://9to5google.com/2018/03/14/samsung-galaxy-repairs-ubreakifix/

## How to recover data from a dead Western Digital hard drive when not powering on
 - [https://www.youtube.com/watch?v=03Laq4z4trU](https://www.youtube.com/watch?v=03Laq4z4trU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-08-07 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
🔵 We fix Macbooks & offer free estimates. https://rossmanngroup.com
🔵 Send us your Macbook for repair! http://bit.ly/sendmacbook
🔵 We'll send you a box with a pre-paid shipping label for your repair! http://bit.ly/sendyourmacbook
🔵 We offer iPhone data recovery: http://bit.ly/2BDBX4G
🔵 We offer lab hard drive data recovery: http://bit.ly/labdatarecovery

👉 LEARN HOW TO DO THIS:
› In-person classes: https://bit.ly/classrg
› Beginner's guide: http://bit.ly/2k6uz84
› Support forum: $29/mo http://bit.ly/boardrepairforum

👉 Donate & post a message: http://bit.ly/postamessage 

👉 Below we list tools & recording gear we use, repair guides to help you learn, online chip sources, & donation links:

👉 BlackBerry, Oreo, & Clinton the cat's wish list: https://www.amazon.com/hz/wishlist/ls/2YC1L66N7T5BC?&sort=default

👉 CHIPS & COMPONENTS:
› http://bit.ly/2jaAOXM

👉 Discord: https://discord.gg/uz9Jt76

👉 TOOLS USED:

✓ Soldering Irons:
› Louis' Hakko station(no tweezers): http://amzn.to/2cKkMyO 
› Paul's Hakko station(works with tweezers): http://amzn.to/2yMvWNy
› Micro Soldering Pencil: http://amzn.to/2d5MWUP
› Hot tweezers: http://amzn.to/2yMvZsZ
› Atten ST-862D hot air station: http://bit.ly/atten862

✓ CHEAP HAKKO ALTERNATIVES:
› TS100 soldering iron: https://amzn.to/2Gy1Fqz
› Recommended tips: TS-C4: https://amzn.to/33s3jpW TS-KU https://amzn.to/2QsKT36

✓ Preferred Soldering Tips
› Fine: http://amzn.to/2d5MgPn 
› Flat: https://amzn.to/2JnsDBT 
› GPU wicking: http://amzn.to/2w8chtB
› Micro soldering tip: http://amzn.to/2qUSFDh

✓ Microscopes:
› Microscope: http://amzn.to/2iLrE16 
› Barlow lens: http://amzn.to/2yMKdKf
› LED light: http://amzn.to/2nzfPT2
› CHEAP alternative microscope: http://amzn.to/2rTlHbj

✓ Soldering/Repair Supplies:
› Solder: http://amzn.to/2cKkxUp
› Desoldering braid: http://bit.ly/2otflOX
› Flux: http://bit.ly/amtechflux
› Solder paste: http://bit.ly/amtechsolderpaste
› THICK insulated jumper wire: https://amzn.to/2rvtD0A
› THIN insulated jumper wire: https://amzn.to/2I47DQY
› Kapton tape: http://amzn.to/2yN0xuq
› Tweezers: http://amzn.to/2d5NBpi
› Blades: http://amzn.to/2ByWnvF
› Freeze Spray: http://amzn.to/2BySozw
› Conformal coating: http://bit.ly/greencoate
› Conformal coating curing pen: http://bit.ly/uvpen

✓ Diagnostic tools:
› USB amp meter: http://bit.ly/2B2Lu5W
› USB-C amp meter: http://bit.ly/usbcamp
› On-Screen multimeter: http://amzn.to/2jtgY9K 
› Multimeter Probes: http://bit.ly/fineprobes
› CHEAP multimeter: http://amzn.to/2zjkg8U
› Bench PSU: CSI3005P http://bit.ly/benchsupply
› Phoneboard: https://phoneboard.co
› Boardview software: https://pldaniels.com/flexbv/

✓ Ultrasonic Cleaning:
› ALL MACBOOKS & CELLPHONES: Crest P1200H-45: https://amzn.to/2ITSQdw
› PRE-TOUCHBAR MACBOOKS & CELLPHONES: Crest P500H-45: https://amzn.to/2Qrnhf8
› CELLPHONES ONLY: Crest P230H-45: https://amzn.to/2QsckKG
› Branson EC cleaning fluid: http://amzn.to/2cKlBrp

✓ Desk supplies:
› Desk: http://amzn.to/2yMShdZ
› Chair: https://amzn.to/2LB8bUB
› Fume Extractor: http://amzn.to/2d5MGoD
› Work mat: http://amzn.to/2yMtlTR
› Outlets: http://amzn.to/2yNsZwo
› Gloves: http://amzn.to/2iUfumS
› Durable lightning cable: http://amzn.to/2yNHzUt
› Fine tipped snippers: http://amzn.to/2HGt4XB

✓ Screwdrivers: 
› iPhone bottom screw: http://amzn.to/2yNwX8p
› Macbook bottom screw: http://amzn.to/2AKMdVb
› Torx T3: http://amzn.to/2zjtxxH
› Torx T5 http://amzn.to/2BLNDn4
› Torx T6 http://amzn.to/2B0XIfA
› Torx T8 http://amzn.to/2CpWp68
› Phillips #0: http://amzn.to/2AJaHhM
› Phillips #000: http://amzn.to/2yNqsCl



✓ RECORDING EQUIPMENT:
› Work cam: https://amzn.to/2QjHnt0
› Overhead cam: http://amzn.to/2eAH0oT
› Work mic: https://amzn.to/2WGIhzw
› Home mic: https://amzn.to/2xfampC
› Microscope camera: http://amzn.to/2icVQoG - mine is DISCONTINUED, closest one I can find. 
› HDMI capture: http://amzn.to/2iyGcle

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com

👉 Leave a tip for us via cryptocurrency if we've helped you out:
› Credit card: http://bit.ly/postamessage
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

