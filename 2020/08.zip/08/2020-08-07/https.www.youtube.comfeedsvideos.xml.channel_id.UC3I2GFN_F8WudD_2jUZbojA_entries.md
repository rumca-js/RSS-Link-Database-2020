# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Chicano Batman (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=adWjEdqzhbc](https://www.youtube.com/watch?v=adWjEdqzhbc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-08-08 00:00:00+00:00

LA's Chicano Batman share a set of songs recorded exclusively for KEXP and join Morgan to talk live on Thursday, August 6, at 3pm PT.

Songs:
I know It
Polymetrophonic Harmony
Moment of Joy
The Way
Color My Life

## Metronomy - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=rvQQFVSTVps](https://www.youtube.com/watch?v=rvQQFVSTVps)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-08-07 00:00:00+00:00

http://KEXP.ORG presents Metronomy performing live in the KEXP studio. Recorded February 17, 2020.
Songs:
Lately
The Light
Wedding Bells
Salted Caramel Ice Cream

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Kendall Rock
Editor: Justin Wilmore

http://kexp.org
http://www.metronomy.co.uk

## Metronomy - Lately (Live on KEXP)
 - [https://www.youtube.com/watch?v=FfdzM1fN-AA](https://www.youtube.com/watch?v=FfdzM1fN-AA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-08-07 00:00:00+00:00

http://KEXP.ORG presents Metronomy performing “Lately” live in the KEXP studio. Recorded February 17, 2020.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Kendall Rock
Editor: Justin Wilmore

http://kexp.org
http://www.metronomy.co.uk

## Metronomy - Salted Caramel Ice Cream (Live on KEXP)
 - [https://www.youtube.com/watch?v=8j9EE1oKuf8](https://www.youtube.com/watch?v=8j9EE1oKuf8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-08-07 00:00:00+00:00

http://KEXP.ORG presents Metronomy performing “Salted Caramel Ice Cream” live in the KEXP studio. Recorded February 17, 2020.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Kendall Rock
Editor: Justin Wilmore

http://kexp.org
http://www.metronomy.co.uk

## Metronomy - The Light (Live on KEXP)
 - [https://www.youtube.com/watch?v=k24A55piyMY](https://www.youtube.com/watch?v=k24A55piyMY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-08-07 00:00:00+00:00

http://KEXP.ORG presents Metronomy performing “The Light” live in the KEXP studio. Recorded February 17, 2020.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Kendall Rock
Editor: Justin Wilmore

http://kexp.org
http://www.metronomy.co.uk

## Metronomy - Wedding Bells (Live on KEXP)
 - [https://www.youtube.com/watch?v=aEnSGTU1pxM](https://www.youtube.com/watch?v=aEnSGTU1pxM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-08-07 00:00:00+00:00

http://KEXP.ORG presents Metronomy performing “Wedding Bells” live in the KEXP studio. Recorded February 17, 2020.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Kendall Rock
Editor: Justin Wilmore

http://kexp.org
http://www.metronomy.co.uk

