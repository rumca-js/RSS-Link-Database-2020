# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## COVID-19 [Lockdown Live Jam #7]
 - [https://www.youtube.com/watch?v=VOGLML98uhU](https://www.youtube.com/watch?v=VOGLML98uhU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2020-05-03 00:00:00+00:00

Support my music on Patreon: https://www.patreon.com/yuriwong Download the mp3: https://gum.co/covid19live
*Best heard on headphones or full-range speakers*
Here's a live looping jam of COVID-19 with *that* guy's voice. (I tried to keep it low)

Equipment used:
- Elektron Octatrack MkII
- Moog SUB37
- Novation Circuit
- Korg Microkorg XL+
- iConnectAudio4+
- Fender Stratocaster w Vintage Noiseless pickups
- Teenage Engineering OP-1
- myVolts mickXer

Music-nerd stuff:
This jam is DAWless. All the recording, playback and sequencing was done within the Octatrack.
The Octatrack is the master clock, which is sent via MIDI DIN to the iConnectAudio4+ (ica4+), which sends midi out via usb to the Circuit, Microkorg, OP-1 and SUB37. I had an issue with noise coming in from USB on the Circuit so disconnected it (which meant I had no MIDI synced start-stop) and I manually pressed play together to sync the Octa and Circuit. It's probably slightly off, but ok. Also, I experimented with MIDI sequencing from the Octa for the first time, so I didn't really play the keys, more sound shaping and stuff. Still figuring out MIDI live recording, which I would've preferred to do, at least on the Microkorg for the chords.

