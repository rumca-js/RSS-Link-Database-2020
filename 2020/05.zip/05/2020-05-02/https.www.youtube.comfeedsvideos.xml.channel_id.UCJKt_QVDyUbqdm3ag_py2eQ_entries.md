# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga Paula does XM: Tangerine - Toy Summer (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=iHAoDl-RFO0](https://www.youtube.com/watch?v=iHAoDl-RFO0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-05-03 00:00:00+00:00

"Toy Summer" (1998) by Tangerine (Philip Barsky), 6th at Bytefall 1999. Art "Got Nuts?" by Prowler/Nectarine^nicepixel.se, 1st at Revision 2017. This upload is intended for headphones only.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Normal mixing with 48587 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click disabled
- Module reports 20 channels
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.

## Amiga music: Slide - The Prey OST (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=EHA1ke6kU9E](https://www.youtube.com/watch?v=EHA1ke6kU9E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-05-03 00:00:00+00:00

Soundtrack from "The Prey" AGA demo (Polka Brothers, 1994) by Slide (Henrik Juhl). Art by Pixie and Devilstar. This upload is intended for headphones only.

Jumplist:
00:00 intro ("Eat Dust & Hof!")
00:53 main part ("Ultimate Seduction 3")

Made using real A1200 Rev. 1D.4 audio.

Visit my channel for more Amiga music.

