# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Fantasy Themes - A Reader's Perspective!
 - [https://www.youtube.com/watch?v=eRu5GqNrDQQ](https://www.youtube.com/watch?v=eRu5GqNrDQQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-05-03 00:00:00+00:00

A midnight rant/ramble on the writing of themes within the fantasy genre.
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## Fullmetal Alchemist: Brotherhood - REVIEW
 - [https://www.youtube.com/watch?v=H1B1drKq1wI](https://www.youtube.com/watch?v=H1B1drKq1wI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-05-02 00:00:00+00:00

My review of Fullmetal Alchemist: Brotherhood!
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

