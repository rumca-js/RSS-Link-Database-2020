# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## This is a GAMING PC!?!?!
 - [https://www.youtube.com/watch?v=56MgVgnRBSs](https://www.youtube.com/watch?v=56MgVgnRBSs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-05-03 00:00:00+00:00

The first 100 people to go to https://blinkist.com/linustechtips are going to get unlimited access for 1 week to try it out. You’ll also get 25% off if you want the full membership.

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire
 
You are on a super tight budget and you  just got a 7 year old Dell Optiplex 9010. With a mix of new and used hardware upgrades, we are gonna show you how much game really is in that old computer. 

Intro by Mbarek Abdelwassaa -  https://www.instagram.com/mbarek_abdel/


Buy NVIDIA GTX 1650 Low-Profile
On Amazon (PAID LINK): https://geni.us/AcfMvI
On Newegg (PAID LINK): https://geni.us/athULc

Buy NVIDIA GTX 1650 SUPER
On Amazon (PAID LINK): https://geni.us/VnBm
On Newegg (PAID LINK): https://geni.us/GGzxkX

Buy NVIDIA GTX 1660 TI
On Amazon (PAID LINK): https://geni.us/vHS6fX
On Newegg (PAID LINK): https://geni.us/hCD2

Buy DDR3 RAM
On Amazon (PAID LINK): https://geni.us/dgZ23G
On Newegg (PAID LINK): https://geni.us/X7vMfB

Buy SATA SSD
On Amazon (PAID LINK): https://geni.us/7TC7OIC
On Newegg (PAID LINK): https://geni.us/uHfYU

Buy SATA to 6-pin Adapter 
On Amazon (PAID LINK): https://geni.us/PFZmi
On Newegg (PAID LINK): https://geni.us/5XYn

Buy SATA to 8-pin Adapter
On Amazon (PAID LINK): https://geni.us/jeZ3
On Newegg (PAID LINK): https://geni.us/hOOz 

Purchases made through some store links may provide some compensation to Linus Media Group.

Used Dell 9010 Ebay search: https://lmg.gg/9aXe1
Used GTX 960 Ebay search: https://lmg.gg/LKhCL
Discuss on the forum: https://lmg.gg/2NtRP


GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Support a Creator code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Test Benches on Amazon: https://lmg.gg/HOx0z
Our Production Gear: https://lmg.gg/4oPzt
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0 https://lmg.gg/fxHYK 
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://lmg.gg/Q9yyQ 
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://lmg.gg/8upii

## WHY do I pay Adobe $10K a YEAR!?
 - [https://www.youtube.com/watch?v=L9VysWRHPdI](https://www.youtube.com/watch?v=L9VysWRHPdI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-05-02 00:00:00+00:00

Buy CORSAIR Dark Core RGB Pro
On CORSAIR: https://geni.us/BwIcB
On Amazon: https://geni.us/rAGj8
On Newegg: https://geni.us/gQTZB

Check out ORIGIN PC’s new EVO16-S Ready-To-Ship Streamer Bundle today at https://bit.ly/3ahu3LX

Intro by Mbarek Abdelwassaa -  https://www.instagram.com/mbarek_abdel/

It's ridiculous. Can we make our videos without touching a SINGLE Adobe Product?

Apps we used:
Kyno: https://lesspain.software/kyno/
Davinci Resolve / Fusion / Fairlight: https://www.blackmagicdesign.com/products/davinciresolve/
Affinity Photo: https://affinity.serif.com/en-gb/photo/

Buy an Editing Workstation
On Amazon (PAID LINK): https://geni.us/5qwv7e
On B&H (PAID LINK): https://geni.us/195VL9

Buy an AMD Threadripper CPU
On Amazon (PAID LINK): https://geni.us/AeAzI5
On B&H (PAID LINK): https://geni.us/tr9khe

Buy an NVIDIA GPU
On Amazon (PAID LINK): https://geni.us/BgrzU
On B&H (PAID LINK): https://geni.us/WMe5

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1187903-why-do-i-pay-adobe-10k-a-year/


GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Support a Creator code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Test Benches on Amazon: https://lmg.gg/HOx0z
Our Production Gear: https://lmg.gg/4oPzt
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0 https://lmg.gg/fxHYK 
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://lmg.gg/Q9yyQ 
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://lmg.gg/8upii

