# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 BIG Video Game Items That Were Absolutely USELESS
 - [https://www.youtube.com/watch?v=T75B4TaCmlU](https://www.youtube.com/watch?v=T75B4TaCmlU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-05-03 00:00:00+00:00

Video game items and pick-ups are important - but these specific items are hilariously useless.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 10 Best FREE iOS & Android Games of April 2020
 - [https://www.youtube.com/watch?v=TUHIcu1L4vI](https://www.youtube.com/watch?v=TUHIcu1L4vI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-05-02 00:00:00+00:00

Looking for something to play while you're stuck at home? Here's a list of the best free mobile games of April 2020.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

#10 Disorder
Platform: Android, iOS
Price: Free
https://play.google.com/store/apps/details?id=com.netease.disorder&hl=en_IN

#9 Naruto Slugfest
Platform: Android iOS [SOON]
PRICE: FREE
https://apps.apple.com/us/app/naruto-slugfest/id1474940970
https://play.google.com/store/apps/details?id=com.narutoslugfest.cubinet.android&hl=en_IN

#8 Dirt Bike Unchained
Platform: iOS Android
PRICE: FREE
https://apps.apple.com/us/app/dirt-bike-unchained/id1451177077
https://play.google.com/store/apps/details?id=com.redbull.moto

#7 Aura Kingdom 2
Platform: iOS Android
PRICE: FREE
https://apps.apple.com/us/app/aura-kingdom-2/id1492679270
https://play.google.com/store/apps/details?id=com.xlegend.aurakingdom2.global

#6 Legends of Runeterra
Platform: Android, iOS
Price: Free
https://play.google.com/store/apps/details?id=com.riotgames.legendsofruneterra
https://apps.apple.com/us/app/legends-of-runeterra/id1480617557

#5 BLADE XLORD
Platform: iOS, Android
PRICE: FREE
https://apps.apple.com/us/app/blade-xlord/id1496760638
https://play.google.com/store/apps/details?id=jp.co.applibot.us.bladexlord&hl=en_IN


#4 Dino Squad: Online Action
Platform: iOS android
Price: Free
https://apps.apple.com/us/app/dino-squad-online-action/id1499971430
https://play.google.com/store/apps/details?id=com.pixonic.dino&hl=en_IN

#3 Gameloft Classics: 20 Years
Platform: Android
Price: Free
https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftGLCL&hl=en_IN

#2 Game of Thrones Beyond the Wall
Platform: iOS Android
Price: Free
https://apps.apple.com/us/app/game-of-thrones-beyond/id1492828790
https://play.google.com/store/apps/details?id=com.bhvr.beyondthewall&hl=en


#1 Dead by Daylight Mobile
Platform: iOS android
Price: Free
https://apps.apple.com/no/app/dead-by-daylight-mobile/id1452289752
https://play.google.com/store/apps/details?id=com.bhvr.deadbydaylight&hl=en_IN

BONUS

GRIS
Platform: iOS Android
Price: $4.99
https://apps.apple.com/us/app/gris/id1445379072
https://play.google.com/store/apps/details?id=com.devolver.grispaid&hl=en_US

## 10 WEIRD Gaming Stories of April 2020
 - [https://www.youtube.com/watch?v=qz0jdyYvbBI](https://www.youtube.com/watch?v=qz0jdyYvbBI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-05-02 00:00:00+00:00

Despite the state of the world, April was still a weird and crazy month for video game news. Here are some interesting highlights.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1
Bad Robo: https://www.youtube.com/channel/UCtv_wDOg5_71C94AlXvkoGQ

