# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## YĪN YĪN - Chông ky (Live on KEXP)
 - [https://www.youtube.com/watch?v=xKnbV8PsD08](https://www.youtube.com/watch?v=xKnbV8PsD08)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-03 00:00:00+00:00

http://KEXP.ORG presents YĪN YĪN performing “Chông ky” live at the La Chapelle by Le Studio in Rennes, France, during Trans Musicales 2019. Recorded December 7, 2019.

Audio Engineer: Matt Ogaz
Audio Mixer: Simon Van Boxtel
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

Additional support by 
Jean Baptiste Le Clec’h
Jean-Marc Meleard
Jeremy Meleard

Festival Artwork by Brendan Monroe

Special thanks to Gwenola Le Bris at Trans Musicales, Valérian Mercier at La Chapelle by le Studio, and Destination Renne

http://kexp.org
https://www.lestrans.com
https://www.tourisme-rennes.com
https://www.lachapellebylestudio.com
https://yinyin.bandcamp.com

## YĪN YĪN - pingpxng (Live on KEXP)
 - [https://www.youtube.com/watch?v=hfTTbR7oNfQ](https://www.youtube.com/watch?v=hfTTbR7oNfQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-03 00:00:00+00:00

http://KEXP.ORG presents YĪN YĪN performing “pingpxng” live at the La Chapelle by Le Studio in Rennes, France, during Trans Musicales 2019. Recorded December 7, 2019.

Audio Engineer: Matt Ogaz
Audio Mixer: Simon Van Boxtel
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

Additional support by 
Jean Baptiste Le Clec’h
Jean-Marc Meleard
Jeremy Meleard

Festival Artwork by Brendan Monroe

Special thanks to Gwenola Le Bris at Trans Musicales, Valérian Mercier at La Chapelle by le Studio, and Destination Renne

http://kexp.org
https://www.lestrans.com
https://www.tourisme-rennes.com
https://www.lachapellebylestudio.com
https://yinyin.bandcamp.com

