# Source:BezPlanu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g, language:pl-PL

## Ugandyjskie busy, impreza nad Nilem
 - [https://www.youtube.com/watch?v=7s_St-wwFIY](https://www.youtube.com/watch?v=7s_St-wwFIY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g
 - date published: 2020-05-03 00:00:00+00:00

Wszystkie odcinki chronologicznie: http://bit.ly/2MqAO7Q
(można też klikać w kartę "Następny odcinek" pojawiającą się pod koniec każdego filmu po prawej stronie u góry) 

Ruszamy nad Jezioro Wiktorii do miejscowości Jinja położonej u źródła Nilu. Odcinek przedstawia podróż ugandyjskim "Taxi", czyli niewielkim busem oraz hotel i imprezę

Ania Markowska:
https://instagram.com/annmarelo

Pierwszy odcinek BezPlanu z Anią (miejsce: Bogota, Kolumbia):
http://bit.ly/31ZCE3l

Wsparcie na Patronite: http://bit.ly/2KsFTZk 
Instagram: http://instagram.com/bezplanu_czukesky 
Facebook: https://www.facebook.com/BezPlanu.tv 

Czas akcji: wrzesień 2019r.

Tłumaczenie na angielski: Michał Stadryniak
www.linkedin.com/in/michał-stadryniak-82b8491a6

