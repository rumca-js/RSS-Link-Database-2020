# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## How Many Species are in Your Backyard?
 - [https://www.youtube.com/watch?v=1-LjzKx-u9g](https://www.youtube.com/watch?v=1-LjzKx-u9g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2020-05-19 00:00:00+00:00

PBS Member Stations rely on viewers like you. To support your local station, go to: http://to.pbs.org/DonateOKAY
↓ More info and sources below ↓

We’re on PATREON! Join the community ►► https://www.patreon.com/itsokaytobesmart
SUBSCRIBE so you don’t miss a video! ►► http://bit.ly/iotbs_sub 

Download iNaturalist to join the It’s Okay to be Smart global survey project and submit your observations! https://www.inaturalist.org/projects/it-s-okay-to-be-smart-global-survey

Learn more about iNaturalist and citizen science: https://www.inaturalist.org/

Special thanks to our Brain Trust Patrons:
AlecZero
Diego Lombeida
Dustin
Ernesto Silva
George Gladding
Marcus Tuepker
Megan K Bradshaw
Ron Kakar
Vincbis

Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/

