# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## CNN [#181] Co nie zrobisz, to jest źle?
 - [https://www.youtube.com/watch?v=TlUtPIjFLyU](https://www.youtube.com/watch?v=TlUtPIjFLyU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-05-19 00:00:00+00:00

#cnn #kazaniedookienka  @Langusta na palmie  @STREFA WODZA @Dominikanie.pl 
________________________________________

V Niedziela Wielkanocna, ROK A

1. czytanie (Dz 8, 5-8. 14-17)

Filip przybył do miasta Samarii i głosił im Chrystusa. Tłumy słuchały z uwagą i skupieniem słów Filipa, ponieważ widziały znaki, które czynił. Z wielu bowiem opętanych wychodziły z donośnym krzykiem duchy nieczyste, wielu też sparaliżowanych i chromych zostało uzdrowionych. Wielka zaś radość zapanowała w tym mieście.

Kiedy apostołowie w Jerozolimie dowiedzieli się, że Samaria przyjęła słowo Boże, wysłali do niej Piotra i Jana, którzy przyszli i modlili się za nich, aby mogli otrzymać Ducha Świętego. Bo na żadnego z nich jeszcze nie zstąpił. Byli jedynie ochrzczeni w imię Pana Jezusa. Wtedy więc nakładali apostołowie na nich ręce, a oni otrzymywali Ducha Świętego.


2. czytanie (1 P 3, 15-18)

Najdrożsi: Pana Chrystusa uznajcie w sercach waszych za Świętego i bądźcie zawsze gotowi do obrony wobec każdego, kto domaga się od was uzasadnienia tej nadziei, która w was jest.

A z łagodnością i bojaźnią Bożą zachowujcie czyste sumienie, ażeby ci, którzy oczerniają wasze dobre postępowanie w Chrystusie, doznali zawstydzenia właśnie przez to, co wam oszczerczo zarzucają. Lepiej bowiem – jeżeli taka wola Boża – cierpieć, czyniąc dobrze, aniżeli źle czyniąc.

Chrystus bowiem również raz jeden umarł za grzechy, sprawiedliwy za niesprawiedliwych, aby was do Boga przyprowadzić; zabity wprawdzie na ciele, ale powołany do życia przez Ducha.

Ewangelia (J 14, 15-21)

Jezus powiedział do swoich uczniów: «Jeżeli Mnie miłujecie, będziecie zachowywać moje przykazania. Ja zaś będę prosił Ojca, a innego Parakleta da wam, aby z wami był na zawsze – Ducha Prawdy, którego świat przyjąć nie może, ponieważ Go nie widzi ani nie zna. Ale wy Go znacie, ponieważ u was przebywa i w was będzie.

Nie zostawię was sierotami. Przyjdę do was. Jeszcze chwila, a świat nie będzie już Mnie widział. Ale wy Mnie widzicie; ponieważ Ja żyję, i wy żyć będziecie. W owym dniu poznacie, że Ja jestem w Ojcu moim, a wy we Mnie i Ja w was.

Kto ma przykazania moje i je zachowuje, ten Mnie miłuje. Kto zaś Mnie miłuje, ten będzie umiłowany przez Ojca mego, a również Ja będę go miłował i objawię mu siebie».

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Nabożeństwo Majowe - 19 maja 2020
 - [https://www.youtube.com/watch?v=QTkGpyS_3go](https://www.youtube.com/watch?v=QTkGpyS_3go)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-05-19 00:00:00+00:00

@Langusta na palmie #majowe #langustanapalmie

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#508] Poganie
 - [https://www.youtube.com/watch?v=1re40vx49v8](https://www.youtube.com/watch?v=1re40vx49v8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-05-19 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał  

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Ksiądz gra w grę: Uncharted 4 [#16] Pozwól się wyprzedzić!
 - [https://www.youtube.com/watch?v=AhJuV9GI7-g](https://www.youtube.com/watch?v=AhJuV9GI7-g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-05-18 00:00:00+00:00

@Langustanapalmie #ksiądzgrawgrę #bedegrałwgre 
________________________________________
Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Miniaturkę stworzył dla nas: Sebastian Gwóźdź

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Nabożeństwo majowe  - 18 maja 2020
 - [https://www.youtube.com/watch?v=eQWezVnQh6Y](https://www.youtube.com/watch?v=eQWezVnQh6Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-05-18 00:00:00+00:00

@Langustanapalmie #majówka #langustanapalmie
------------------------------------------------------------

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#507] Inne życie
 - [https://www.youtube.com/watch?v=8vH_cgnAuos](https://www.youtube.com/watch?v=8vH_cgnAuos)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-05-18 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

Szczegóły krakowskiej akcji Obiady w czasie zarazy:
→ https://www.facebook.com/groups/600190943909356

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał  

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

