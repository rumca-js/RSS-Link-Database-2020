# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## This new VR Headset could change the entire VR market
 - [https://www.youtube.com/watch?v=k7pZOLdnLLA](https://www.youtube.com/watch?v=k7pZOLdnLLA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-05-19 00:00:00+00:00

Hello and welcome to TUESDAY NEWSDAY! Your number one resource for the entire weeks worth of VR news. 

Here are my links:
Patreon link:Join
https://www.patreon.com/Thrillseeker
My Stream:
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill


Today I will cover:
Meme break clip: https://twitter.com/DBLTAPesports/status/1261766400470855680?s=20

video clips used: https://www.youtube.com/watch?v=C7YycpxoKSw

Oculus Quest and Rift S one year anniversary 
Oculus Quest Hand Tracking receives large update
Oculus store sale
Beat saber receives 40 new beatmaps
https://www.oculus.com/blog/celebrating-the-one-year-anniversary-of-oculus-quest-and-rift-s/

This new chinese headset:
https://www.jd.com/pinpai/12349-253559.html
https://item.jd.com/100011903114.html#none

Oculus link updates:
https://uploadvr.com/oculus-link-usb-2-update/

Apple buys out NExtVR:
https://www.theverge.com/2020/5/14/21211254/apple-confirms-nextvr-acquisition-purchase-vr-virtual-reality-company

Google takes down fake Oculus Ads:
https://www.bbc.com/news/technology-52668164

