# Source:Jeff Gerling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg, language:en-US

## Drupal 7 to 8 LIVE Migration - Ep 16 - TODAY IS THE DAY!
 - [https://www.youtube.com/watch?v=4ehIIFGtMRg](https://www.youtube.com/watch?v=4ehIIFGtMRg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg
 - date published: 2020-05-19 00:00:00+00:00

In this sixteenth and final livestream, we'll run the Drupal 7 to Drupal 8 migration, LIVE! In the last livestream, Jeff accidentally took down his live server. What damage will he do *this* week? Tune in to find out whether the migration is a success or a total disaster!

Support me on Patreon: https://www.patreon.com/geerlingguy

Sponsor me on GitHub: https://github.com/sponsors/geerlingguy



See more: https://www.jeffgeerling.com/blog/2020/migrating-jeffgeerlingcom-drupal-7-drupal-8-how-video-series

