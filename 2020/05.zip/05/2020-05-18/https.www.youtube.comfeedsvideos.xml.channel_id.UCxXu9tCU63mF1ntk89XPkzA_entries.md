# Source:Worthkids, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCxXu9tCU63mF1ntk89XPkzA, language:en-US

## Jason & Friends
 - [https://www.youtube.com/watch?v=0pdF1a7Qi9c](https://www.youtube.com/watch?v=0pdF1a7Qi9c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCxXu9tCU63mF1ntk89XPkzA
 - date published: 2020-05-18 00:00:00+00:00

FOUND IT!!!

special thanks to my roommate for helping with voices and inbetweens!

Patreon: https://www.patreon.com/worthikids
Twitter: https://twitter.com/Worthikids

