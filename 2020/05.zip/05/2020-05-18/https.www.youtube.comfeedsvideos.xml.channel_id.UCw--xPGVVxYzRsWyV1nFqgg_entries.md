# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## AVATAR THE LAST AIRBENDER ( movie ) - RANT REVIEW
 - [https://www.youtube.com/watch?v=9wNz330eiGc](https://www.youtube.com/watch?v=9wNz330eiGc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-05-19 00:00:00+00:00

My review of the Avatar The Last Airbender movie directed by m. night shyamalan. An extreme insult to the ATLA fanbase.
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## How I'll Review The Wheel Of Time Show! - 2 reviews EVERY episode!
 - [https://www.youtube.com/watch?v=PNI544Icjgw](https://www.youtube.com/watch?v=PNI544Icjgw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-05-18 00:00:00+00:00

I realized in one video I could not properly review the Wheel of time show right. So, I will review each episode twice. Let's talk about that! 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

