# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## How to choose the most secure messaging app | Private messenger tutorial
 - [https://www.youtube.com/watch?v=Qz3VBGo9jJU](https://www.youtube.com/watch?v=Qz3VBGo9jJU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2020-05-19 00:00:00+00:00

Encrypted messaging is becoming mainstream. How do you decide which messenger is the most secure and private for your needs?

Support me through Patreon: https://www.patreon.com/thehatedone 

- or donate anonymously:

Monero: 84DYxU8rPzQ88SxQqBF6VBNfPU9c5sjDXfTC1wXkgzWJfVMQ9zjAULL6rd11ASRGpxD1w6jQrMtqAGkkqiid5ef7QDroTPp

Bitcoin: 1HkDxXAVDFhBHSyRjam5WW5uoY88sxn5qz 

Securing your digital communications should be your highest
priority when going online. There are just way too many threats to
trust any company with your private data. Companies care more about
their bottom line then about fixing bugs in their software or poorly
undersecured data centers. And they definitely don’t care if they
expose your digital life to harassment, scammers, fraud and data
mining advertisers. 

Can you actually find a secure messaging app you can trust? And
how can you make sure an app that promises encryption won’t turn
evil? 

Well, ever since the Snowden leaks on N.S.A. mass surveillance, we
now have more options then ever before. You can thank the broad
community of security researchers and developers on the front lines
in the war against data mining and surveillance. 

Questions:

Are all messages end-to-end encryption? 
Is the app fully open source or free software? 
How is the app making money?
Does it have a good jurisdiction?
What is the app’s metadata policy?
Can you create an account anonymously?
Can you do contact verification?
Does your app provide disappearing messages?
Is the encryption strengthened with forward secrecy? 
Is your app in a centralized ecosystem or on a decentralized platform? 

Some sources
EFF guide to choosing a secure messenger https://www.eff.org/deeplinks/2018/03/thinking-about-what-you-need-secure-messenger


Ultimate recommendation guide 

https://securechatguide.org/effguide.html



 iPhone exploitation
https://techcrunch.com/2019/08/29/google-iphone-secretly-hacked/
https://googleprojectzero.blogspot.com/2019/08/a-very-deep-dive-into-ios-exploit.html

Snake oil encrypted phone
https://arstechnica.com/information-technology/2013/09/worlds-most-secure-smartphone-looks-like-snake-oil-experts-say/

iMessage bug
https://threatpost.com/apple-imessage-remote-attackersread-iphone-messages/146789/

 Credits
Music by: CO.AG Music https://www.youtube.com/channel/UCcavSftXHgxLBWwLDm_bNvA 

  Follow me:
https://twitter.com/The_HatedOne_
https://www.bitchute.com/TheHatedOne/
https://www.reddit.com/r/thehatedone/
https://www.minds.com/The_HatedOne

The footage and images featured in the video were for critical analysis, commentary and parody, which are protected under the Fair Use laws of the United States Copyright act of 1976.

