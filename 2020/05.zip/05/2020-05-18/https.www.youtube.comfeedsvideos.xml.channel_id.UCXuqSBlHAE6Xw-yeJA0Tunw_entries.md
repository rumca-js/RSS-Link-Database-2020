# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Why I Still Love Intel...
 - [https://www.youtube.com/watch?v=Cp3xW4uncbk](https://www.youtube.com/watch?v=Cp3xW4uncbk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-05-19 00:00:00+00:00

MAINGEAR Element (Amazon): https://rebrand.ly/5afjqs3
MAINGEAR Element: https://rebrand.ly/kpr68sh
Browse Micro Center’s work and learn from home products: https://rebrand.ly/i5o8b9e

Save 10% and Free Worldwide Shipping at Ridge Wallets by using offer code LINUS at https://www.ridge.com/LINUS

Buy a processor specifically for gaming: (link to Intel CPU)
Buy a processor for almost literally anything else: (links to Ryzen 5 3600, Ryzen 7 3700X, Ryzen 7 3800X, 3900X, 3950X)

As AMD grows in power, there's a few things I hope Intel continues to be great at...

Buy Intel CPUs on Amazon (PAID LINK): https://geni.us/2u0jN
Purchases made through some store links may provide some compensation to Linus Media Group.

Buy an AMD CPU on Amazon:
Ryzen 5 3600: https://geni.us/Cfxr
Ryzen 7 3700X: https://geni.us/XuoSBk1
Ryzen 7 3800X: https://geni.us/6M3LTE
Ryzen 7 3900X: https://geni.us/jye2
Ryzen 9 3950X: https://geni.us/dYFW

Discuss on the forum: https://linustechtips.com/main/topic/1196919-why-i-still-love-intel/

GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Mech Keyboard: https://geni.us/RecNBTI
Get a Displate Metal Print at https://lmg.gg/displateltt
Use code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Gear on Amazon: https://geni.us/lmgamazon
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0 https://lmg.gg/fxHYK 
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://lmg.gg/Q9yyQ 
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://lmg.gg/8upii

## The Future of TVs is NOT What You Think!
 - [https://www.youtube.com/watch?v=RTTiQeXXrhI](https://www.youtube.com/watch?v=RTTiQeXXrhI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-05-18 00:00:00+00:00

Sign up for Private Internet Access VPN at https://lmg.gg/pialinus2
Check out ORIGIN PC gaming laptops and desktops today at https://bit.ly/2Wn7RvV

Everyone thinks MicrOLED is going to be the next big display technology, but with investment from Samsung and LG, OLED still has a lot of fight left in it, especially with the help of Quantum Dots from NanoSys.

Buy Quantom Dot Display
On Amazon (PAID LINK): https://geni.us/fDlsNBr
On Newegg (PAID LINK): https://geni.us/BThL2a

Buy HDR Monitor
On Amazon (PAID LINK): https://geni.us/ZK7dkC
On Newegg (PAID LINK): https://geni.us/6TSP

Purchases made through some store links may provide some compensation to Linus Media Group.

Learn more about NanoSys: https://www.nanosysinc.com/

Discuss on the forum: https://linustechtips.com/main/topic/1196391-the-future-of-tvs-is-not-what-you-think/

GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Mech Keyboard: https://geni.us/RecNBTI
Get a Displate Metal Print at https://lmg.gg/displateltt
Use code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Gear on Amazon: https://geni.us/lmgamazon
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0 https://lmg.gg/fxHYK 
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://lmg.gg/Q9yyQ 
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://lmg.gg/8upii

