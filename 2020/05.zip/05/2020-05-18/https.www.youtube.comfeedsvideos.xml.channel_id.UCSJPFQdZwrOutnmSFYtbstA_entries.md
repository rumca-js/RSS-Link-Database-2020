# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Avatar - The Most Successful Failure Ever
 - [https://www.youtube.com/watch?v=xNeEGBDTnig](https://www.youtube.com/watch?v=xNeEGBDTnig)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-05-18 00:00:00+00:00

Since Avatar 2 is rumbling ever closer, I wanted to take a cast my critical eye back on the 2009 original that everyone went nuts over, and try to figure out what exactly they saw in it.

