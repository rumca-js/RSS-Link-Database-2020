# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## The Raid 2 - Movie Review
 - [https://www.youtube.com/watch?v=MngcC4lfs94](https://www.youtube.com/watch?v=MngcC4lfs94)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-05-18 00:00:00+00:00

Click here http://harrys.com/jeremyjahns to get your Starter Set from Harry’s for just $3!

Well, THE RAID blew my mind, so let's dive into the sequel. Here's my review for THE RAID 2!

Thank you Harry's for sponsoring this video!

#TheRaid2

