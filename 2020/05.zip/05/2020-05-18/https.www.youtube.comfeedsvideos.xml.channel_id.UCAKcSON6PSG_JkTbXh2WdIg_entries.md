# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Acoustic music surges during listener lockdown (The Current Music News)
 - [https://www.youtube.com/watch?v=-WZOfcdmgbA](https://www.youtube.com/watch?v=-WZOfcdmgbA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-19 00:00:00+00:00

May 19, 2020: Acoustic music is surging - not just in livestream performances, but in classic recordings as well. Plus, Billie Eilish launches a Takashi Murakami collaboration, VJ Matt Pinfield enters recovery, and Snoop Dogg vibes with Idina Menzel.
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## CHVRCHES  - Full performance (Live at The Current, 2015)
 - [https://www.youtube.com/watch?v=xAVdxqQflZg](https://www.youtube.com/watch?v=xAVdxqQflZg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-19 00:00:00+00:00

@CHVRCHES  perform "Leave a Trace," "Afterglow," and "The Mother We Share" in The Current studio in 2015.

The first two songs are off CHVRCHES' 2015 release, Every Open Eye, available on Glassnote Records; "The Mother We Share" comes from CHVRCHES' 2013 debut, The Bones of What You Believe, out on Glassnote Records.

PERSONNEL
Lauren Mayberry
Iain Cook
Martin Doherty

CREDITS
Video: Leah Garaas, Helen Teague
Audio: Michael DeMark
Production: Derrick Stevens

MORE FROM THIS SESSION
Leave a Trace https://youtu.be/hMQSdpWb1ok
Afterglow https://youtu.be/KqR_O_0_5A4
The Mother We Share https://youtu.be/kbqFUfgKZOw

#Synthpop #chvrches #Indiepop

## CHVRCHES - Afterglow (Live at The Current, 2015)
 - [https://www.youtube.com/watch?v=KqR_O_0_5A4](https://www.youtube.com/watch?v=KqR_O_0_5A4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-19 00:00:00+00:00

CHVRCHES perform "Afterglow" live at The Current. "Afterglow" is from CHVRCHES' 2015 release, Every Open Eye, available on Glassnote Records.

PERSONNEL
Lauren Mayberry
Iain Cook
Martin Doherty

CREDITS
Video: Leah Garaas, Helen Teague
Audio: Michael DeMark
Production: Derrick Stevens

MORE FROM THIS SESSION
Leave a Trace https://youtu.be/hMQSdpWb1ok
The Mother We Share https://youtu.be/kbqFUfgKZOw
Full session https://youtu.be/xAVdxqQflZg

#Synthpop #chvrches #Indiepop

## CHVRCHES - The Mother We Share (Live at The Current, 2015)
 - [https://www.youtube.com/watch?v=kbqFUfgKZOw](https://www.youtube.com/watch?v=kbqFUfgKZOw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-19 00:00:00+00:00

CHVRCHES perform "The Mother We Share" live at The Current. "The Mother We Share" is from CHVRCHES' 2013 debut "The Bones of What You Believe," available on Glassnote Records.


PERSONNEL
Lauren Mayberry
Iain Cook
Martin Doherty

CREDITS
Video: Leah Garaas, Helen Teague
Audio: Michael DeMark
Production: Derrick Stevens


MORE FROM THIS SESSION
Leave a Trace https://youtu.be/hMQSdpWb1ok
Afterglow https://youtu.be/KqR_O_0_5A4
Full session https://youtu.be/xAVdxqQflZg

#Synthpop #chvrches #Indiepop

## Kiss the Tiger - Live Virtual Session at Sounds Like Home
 - [https://www.youtube.com/watch?v=EUcAlSkn2Zw](https://www.youtube.com/watch?v=EUcAlSkn2Zw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-19 00:00:00+00:00

Kiss the Tiger play a live virtual session as part of The Current's Sounds Like Home festival.

Song performed:
4:50 "Grown Ass Woman"

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Reina del Cid - full session for Sounds Like Home festival for The Current
 - [https://www.youtube.com/watch?v=4HcehL4vtsw](https://www.youtube.com/watch?v=4HcehL4vtsw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-19 00:00:00+00:00

Reina del Cid perform a set of songs as part of The Current's virtual Sounds Like Home Festival.
Songs performed:
03:47 "Won't You Please Forget"
07:00 "Million Girls"
11:26 "Bernadette"
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Beatles photographer Astrid Kirchherr dies at 81 (The Current Music News)
 - [https://www.youtube.com/watch?v=nc7QsgrHxbo](https://www.youtube.com/watch?v=nc7QsgrHxbo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-18 00:00:00+00:00

May 18, 2020: Astrid Kirchherr, a photographer whose early images of the Beatles helped shape their image, has died at 81. Also: hackers have leaked Lady Gaga's legal documents, Nils Lofgren is crusading for nursing home safety, a debate over the best American rock band, and a middle school marching band covers Lizzo.
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Gully Boys - Live Virtual Session at Sounds Like Home
 - [https://www.youtube.com/watch?v=4ZnusOTM9rM](https://www.youtube.com/watch?v=4ZnusOTM9rM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-18 00:00:00+00:00

Gully Boys play a live virtual session as part of The Current's Sounds Like Home festival.

Songs performed:
1:51 "New Song No. 2"
7:01 "Favorite Son"
12:41 "Like Me Now"

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

