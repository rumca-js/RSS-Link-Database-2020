# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Celebrity Scams - Real Estate Seminars
 - [https://www.youtube.com/watch?v=LOTqjIBs9ZY](https://www.youtube.com/watch?v=LOTqjIBs9ZY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-05-19 00:00:00+00:00

here we go again. 

today we're talking about the FTC shutting down Zurixx LLC, a Utah based company that ran seminars based on celebrity-endorsements, including Robert Herjavec and "Flip or Flop" Stars Tarek & Christina  El Moussa. It gets really nasty. 
zurixx.com
https://www.ftc.gov/news-events/press-releases/2019/10/ftc-acts-against-company-using-celebrity-endorsements-bogus

