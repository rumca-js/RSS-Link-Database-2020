# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 IN-GAME PROBLEMS That Are Now Extinct
 - [https://www.youtube.com/watch?v=IhtLOnZkgi8](https://www.youtube.com/watch?v=IhtLOnZkgi8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-05-19 00:00:00+00:00

There are some problems in video games that just don't exist anymore thanks to modern technology and innovation. Here's another trip down memory lane.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 10 Most POWERFUL ARMORED Suits In Video Games
 - [https://www.youtube.com/watch?v=unV1Vc7TuzY](https://www.youtube.com/watch?v=unV1Vc7TuzY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-05-18 00:00:00+00:00

Video games are often power fantasies, and the best games give you high-powered technologically advanced suits to help you live out that dream. Here are our favorites.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

