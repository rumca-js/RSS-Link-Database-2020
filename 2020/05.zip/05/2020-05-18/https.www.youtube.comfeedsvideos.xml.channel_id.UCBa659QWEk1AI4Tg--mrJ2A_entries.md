# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## Why some "remastered" music videos look awful
 - [https://www.youtube.com/watch?v=CkysCJBdGtw](https://www.youtube.com/watch?v=CkysCJBdGtw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2020-05-18 00:00:00+00:00

This isn't "the way they were meant to be seen". • Join CuriosityStream, including access to Nebula and my original series, for only $2.99/month here: https://curiositystream.com/tomscott

When YouTube allowed music labels to "remaster" their original uploads, different videos had very different approaches. Some are in crystal-clear 4K; others are very definitely not. Here's why some of them look terrible.

Animation by William Marler: https://wmad.co.uk
Sound mix by Graham Haerther: https://haerther.net

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

