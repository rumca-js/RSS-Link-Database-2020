# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## beabadoobee (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=db6aWZMKXwI](https://www.youtube.com/watch?v=db6aWZMKXwI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-19 00:00:00+00:00

beabadoobee performs at home and joins Morgan live on KEXP on Tuesday, May 19, at 12pm PT.

## Shawn Parker - Change (Live on KEXP)
 - [https://www.youtube.com/watch?v=HQF8PkQIP4k](https://www.youtube.com/watch?v=HQF8PkQIP4k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-18 00:00:00+00:00

http://KEXP.ORG presents Shawn Parker performing "Change" live in the KEXP studio. Recorded January 15, 2020.

Host: Stas THEE Boss
Audio Engineer: Kevin Suggs
Cameras: Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Alaia D'Alessandro

http://kexp.org
https://www.facebook.com/ShawnParkerPCA

## Shawn Parker - Fallin' (Live on KEXP)
 - [https://www.youtube.com/watch?v=2VHjw5pDc4k](https://www.youtube.com/watch?v=2VHjw5pDc4k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-18 00:00:00+00:00

http://KEXP.ORG presents Shawn Parker performing "Fallin'" live in the KEXP studio. Recorded January 15, 2020.

Host: Stas THEE Boss
Audio Engineer: Kevin Suggs
Cameras: Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Alaia D'Alessandro

http://kexp.org
https://www.facebook.com/ShawnParkerPCA

## Shawn Parker - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=MRBqhLtisaw](https://www.youtube.com/watch?v=MRBqhLtisaw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-18 00:00:00+00:00

http://KEXP.ORG presents Shawn Parker performing live in the KEXP studio. Recorded January 15, 2020.

Songs:
Fallin'
Change
Zoom
OTW

Host: Stas THEE Boss
Audio Engineer: Kevin Suggs
Cameras: Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Alaia D'Alessandro

http://kexp.org
https://fanlink.to/FallinxShawnParker

## Shawn Parker - OTW (Live on KEXP)
 - [https://www.youtube.com/watch?v=VPhIzS6r_wM](https://www.youtube.com/watch?v=VPhIzS6r_wM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-18 00:00:00+00:00

http://KEXP.ORG presents Shawn Parker performing "OTW" live in the KEXP studio. Recorded January 15, 2020.

Host: Stas THEE Boss
Audio Engineer: Kevin Suggs
Cameras: Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Alaia D'Alessandro

http://kexp.org
https://www.facebook.com/ShawnParkerPCA

## Shawn Parker - Zoom (Live on KEXP)
 - [https://www.youtube.com/watch?v=Yks9JJLiBAc](https://www.youtube.com/watch?v=Yks9JJLiBAc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-18 00:00:00+00:00

http://KEXP.ORG presents Shawn Parker performing "Zoom" live in the KEXP studio. Recorded January 15, 2020.

Host: Stas THEE Boss
Audio Engineer: Kevin Suggs
Cameras: Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Alaia D'Alessandro

http://kexp.org
https://www.facebook.com/ShawnParkerPCA

