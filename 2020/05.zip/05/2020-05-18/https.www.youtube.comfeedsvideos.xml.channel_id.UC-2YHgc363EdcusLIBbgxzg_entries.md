# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## Untangling String Theory | Answers With Joe
 - [https://www.youtube.com/watch?v=NtG0nv8TNE8](https://www.youtube.com/watch?v=NtG0nv8TNE8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2020-05-18 00:00:00+00:00

Get 30 days of CuriosityStream for free and 40% off after that when you go to http://www.curiositystream.com/joescott
String theory is a very complex mathematical concept involving 11 dimensions that will melt your mind if you think too hard about it. Let's try to break it up and make sense of what some people believe is the theory of everything.

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS

http://hyperphysics.phy-astr.gsu.edu/hbase/Forces/unify.html

Sagan's Flatland Analogy:
https://www.youtube.com/watch?v=N0WjV6MmCyM

Kaluza-Klein theory:
https://www.nature.com/articles/118516a0.pdf

https://blogs.scientificamerican.com/cross-check/physics-titan-still-thinks-string-theory-is-on-the-right-track/

https://www.forbes.com/sites/startswithabang/2019/02/12/why-supersymmetry-may-be-the-greatest-failed-prediction-in-particle-physics-history/#c03262269e6d

https://www.nasa.gov/mission_pages/chandra/images/chandra-data-tests-theory-of-everything.html

Kurzgesagt:
https://www.youtube.com/watch?v=Da-2h2B4faU

Michio Kaku:
https://www.youtube.com/watch?v=kYAdwS5MFjQ

Brian Greene TED talk:
https://www.youtube.com/watch?v=kF4ju6j6aLE

