# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## JRE is Moving to Spotify
 - [https://www.youtube.com/watch?v=X8bVqI2j8o4](https://www.youtube.com/watch?v=X8bVqI2j8o4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-19 00:00:00+00:00

https://spoti.fi/JoeRogan

## Patton Oswalt Defends Wrestling Being "Fake" | Joe Rogan
 - [https://www.youtube.com/watch?v=gBR-ucvxMSA](https://www.youtube.com/watch?v=gBR-ucvxMSA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-19 00:00:00+00:00

Taken from #1476 w/Patton Oswalt:
https://youtu.be/KluBn073YjY

## Patton Oswalt Goes Off On An Epic Rant About The Matrix
 - [https://www.youtube.com/watch?v=4CNcKivLICY](https://www.youtube.com/watch?v=4CNcKivLICY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-19 00:00:00+00:00

Taken from JRE #1476 w/Patton Oswalt: https://youtu.be/KluBn073YjYhttps://youtu.be/KluBn073YjY

## Patton Oswalt on Marvel Movies and Martin Scorcese
 - [https://www.youtube.com/watch?v=luavkF7wfS4](https://www.youtube.com/watch?v=luavkF7wfS4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-19 00:00:00+00:00

Taken from JRE #1476 w/Patton Oswalt: https://youtu.be/KluBn073YjYhttps://youtu.be/KluBn073YjY

## Patton Oswalt on What He Learned Taking LSD
 - [https://www.youtube.com/watch?v=bqG8VYsXaoU](https://www.youtube.com/watch?v=bqG8VYsXaoU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-19 00:00:00+00:00

Taken from JRE #1476 w/Patton Oswalt: https://youtu.be/KluBn073YjYhttps://youtu.be/KluBn073YjY

## Patton Oswalt: Hatred is a Luxury of Youth
 - [https://www.youtube.com/watch?v=l82O_cQiivk](https://www.youtube.com/watch?v=l82O_cQiivk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-19 00:00:00+00:00

Taken from JRE #1476 w/Patton Oswalt: https://youtu.be/KluBn073YjYhttps://youtu.be/KluBn073YjY

