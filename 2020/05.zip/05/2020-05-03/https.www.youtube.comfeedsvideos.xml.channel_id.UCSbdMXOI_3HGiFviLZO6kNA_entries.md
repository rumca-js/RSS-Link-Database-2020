# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## A completely new way to walk in VR: CyberShoes
 - [https://www.youtube.com/watch?v=Egv9iBRsaFA](https://www.youtube.com/watch?v=Egv9iBRsaFA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-05-04 00:00:00+00:00

Welcome to Virtually Odd! Where I take a look at some of the weirdest Virtual Reality devices over the course of history. Today we'll be focusing on the Cybershoes, a mobile, home sized alternative to something like an omni-directional treadmill. Buckle up though, this is about to get odd. 

Here are my links:

My Stream:
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill

