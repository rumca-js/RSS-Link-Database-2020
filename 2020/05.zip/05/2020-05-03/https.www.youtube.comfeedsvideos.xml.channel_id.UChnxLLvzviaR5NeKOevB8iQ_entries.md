# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Sleep Sleep (Ambient Performance)
 - [https://www.youtube.com/watch?v=yfHzqrIVMQ8](https://www.youtube.com/watch?v=yfHzqrIVMQ8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2020-05-04 00:00:00+00:00

Happy Sunday. First time "performing" with the new modular stuff. Randomly decided to throw it up here on YouTube. Keystep Pro, 0-Coast, Pico System 3, ZOIA, Microfreak, Vocals through the Perform VE.

My current modular rig: 
Squarp Hermod: https://reverb.grsm.io/hermod
Empress Effects ZOIA: https://reverb.grsm.io/zoia3787
Make Noise 0-Coast: https://reverb.grsm.io/0coast
Erica Synths Pico System 3: https://reverb.grsm.io/picosystemiii
Arturia Rackbrute: https://reverb.grsm.io/rackbrute
Arturia Keystep Pro: https://reverb.grsm.io/keysteppro
Arturia Microfreak: https://reverb.grsm.io/microfreak
Make Noise Maths: https://reverb.grsm.io/maths
Mutable Instruments Plaits, Streams: https://reverb.grsm.io/plaits
Intellijel Quad VCA: https://reverb.grsm.io/intquadvca
IME Piston Honda MKIII: https://reverb.grsm.io/pistonhonda
After Later Monsoon: https://reverb.grsm.io/almonsoon
QD Quad Drum Module: https://reverb.grsm.io/vpmeqd
Busy Circuits Pam's New Workout: https://reverb.grsm.io/pams
Erica Synths Pico Drum2, Pico Voice: https://reverb.grsm.io/espico
Quart: https://reverb.grsm.io/quart
------------------------------------
Patreon: http://bit.ly/rmrpatreon
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe
T-Shirts: http://bit.ly/rmrshirts
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

