# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Ayron Jones - Boys From The Puget Sound (Live on KEXP)
 - [https://www.youtube.com/watch?v=OHp5Rse5ass](https://www.youtube.com/watch?v=OHp5Rse5ass)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-04 00:00:00+00:00

http://KEXP.ORG presents Ayron Jones performing "Boys From The Puget Sound" live in the KEXP studio. Recorded January 9, 2020.

Host: Eva Walker
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Alaia D'Alessandro

http://kexp.org
https://www.ayronjonesmusic.com

## Ayron Jones - Emily (Live on KEXP)
 - [https://www.youtube.com/watch?v=BQxQEo6navs](https://www.youtube.com/watch?v=BQxQEo6navs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-04 00:00:00+00:00

http://KEXP.ORG presents Ayron Jones performing "Emily" live in the KEXP studio. Recorded January 9, 2020.

Host: Eva Walker
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Alaia D'Alessandro

http://kexp.org
https://www.ayronjonesmusic.com

## Ayron Jones - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=kWYzdhluQpY](https://www.youtube.com/watch?v=kWYzdhluQpY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-04 00:00:00+00:00

http://KEXP.ORG presents Ayron Jones performing live in the KEXP studio. Recorded January 9, 2020.

Songs:
Boys From The Puget Sound
Emily
My Love Remains
Take Me Away

Host: Eva Walker
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Alaia D'Alessandro

http://kexp.org
https://www.ayronjonesmusic.com

## Ayron Jones - My Love Remains (Live on KEXP)
 - [https://www.youtube.com/watch?v=2HUMmmPE8io](https://www.youtube.com/watch?v=2HUMmmPE8io)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-04 00:00:00+00:00

http://KEXP.ORG presents Ayron Jones performing "My Love Remains" live in the KEXP studio. Recorded January 9, 2020.

Host: Eva Walker
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Alaia D'Alessandro

http://kexp.org
https://www.ayronjonesmusic.com

## Ayron Jones - Take Me Away (Live on KEXP)
 - [https://www.youtube.com/watch?v=vzsvCt6WDe0](https://www.youtube.com/watch?v=vzsvCt6WDe0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-04 00:00:00+00:00

http://KEXP.ORG presents Ayron Jones performing "Take Me Away" live in the KEXP studio. Recorded January 9, 2020.

Host: Eva Walker
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Alaia D'Alessandro

http://kexp.org
https://www.ayronjonesmusic.com

## YĪN YĪN - Chông ky (Live on KEXP)
 - [https://www.youtube.com/watch?v=xKnbV8PsD08](https://www.youtube.com/watch?v=xKnbV8PsD08)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-03 00:00:00+00:00

http://KEXP.ORG presents YĪN YĪN performing “Chông ky” live at the La Chapelle by Le Studio in Rennes, France, during Trans Musicales 2019. Recorded December 7, 2019.

Audio Engineer: Matt Ogaz
Audio Mixer: Simon Van Boxtel
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

Additional support by 
Jean Baptiste Le Clec’h
Jean-Marc Meleard
Jeremy Meleard

Festival Artwork by Brendan Monroe

Special thanks to Gwenola Le Bris at Trans Musicales, Valérian Mercier at La Chapelle by le Studio, and Destination Renne

http://kexp.org
https://www.lestrans.com
https://www.tourisme-rennes.com
https://www.lachapellebylestudio.com
https://yinyin.bandcamp.com

## YĪN YĪN - pingpxng (Live on KEXP)
 - [https://www.youtube.com/watch?v=hfTTbR7oNfQ](https://www.youtube.com/watch?v=hfTTbR7oNfQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-03 00:00:00+00:00

http://KEXP.ORG presents YĪN YĪN performing “pingpxng” live at the La Chapelle by Le Studio in Rennes, France, during Trans Musicales 2019. Recorded December 7, 2019.

Audio Engineer: Matt Ogaz
Audio Mixer: Simon Van Boxtel
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

Additional support by 
Jean Baptiste Le Clec’h
Jean-Marc Meleard
Jeremy Meleard

Festival Artwork by Brendan Monroe

Special thanks to Gwenola Le Bris at Trans Musicales, Valérian Mercier at La Chapelle by le Studio, and Destination Renne

http://kexp.org
https://www.lestrans.com
https://www.tourisme-rennes.com
https://www.lachapellebylestudio.com
https://yinyin.bandcamp.com

