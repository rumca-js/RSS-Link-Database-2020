# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## The Fastest Phone of 2020!
 - [https://www.youtube.com/watch?v=wUhf0sWhtKw](https://www.youtube.com/watch?v=wUhf0sWhtKw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-05-13 00:00:00+00:00

The first 144Hz smartphone display: A closer look!

MKBHD Merch: http://shop.MKBHD.com

Nubia RedMagic 5G: http://redmagic.gg

Video Gear I use: http://kit.co/MKBHD/video-gear#recom...
Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: http://youtube.com/20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

