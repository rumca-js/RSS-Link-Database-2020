# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I’ve been water cooling wrong for YEARS - $H!T Manufacturers Say
 - [https://www.youtube.com/watch?v=GDR4QByVdCc](https://www.youtube.com/watch?v=GDR4QByVdCc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-05-13 00:00:00+00:00

Get 10% Off XSplit VCam with offer code LINUSTECHTIPS at https://xspl.it/lttvcam

Apparently stacking radiators is bad -- According to the brains over at Corsair, so we built a water cooled gaming rig to test their theory.

Buy Intel 9900KS
On Amazon (PAID LINK): https://geni.us/RyZyZQ5

Buy Corsair Vengeance RGB RAM
On Amazon (PAID LINK): https://geni.us/uxWIG
On Newegg (PAID LINK): https://geni.us/3HfM0Ii

Buy EK Reservoirs
On Amazon (PAID LINK): https://geni.us/YubShVJ
On Newegg (PAID LINK): https://geni.us/kPLy

Buy EK Coolstream SE 240mm
On Amazon (PAID LINK): https://geni.us/bZQBl
On Newegg (PAID LINK): https://geni.us/VUjAIu

Buy EK Vector RTX 2080Ti
On Amazon (PAID LINK): https://geni.us/aeSlS
On Newegg (PAID LINK): https://geni.us/axcLVv2

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1193911-i%E2%80%99ve-been-water-cooling-wrong-for-years-ht-manufacturers-say/

GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Mech Keyboard: https://geni.us/RecNBTI
Get a Displate Metal Print at https://lmg.gg/displateltt
Use code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Gear on Amazon: https://geni.us/lmgamazon
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0 https://lmg.gg/fxHYK 
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://lmg.gg/Q9yyQ 
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://lmg.gg/8upii

## The Most Powerful Laptop EVER!!! - XMG Apex 15
 - [https://www.youtube.com/watch?v=KFTMBTDGTx8](https://www.youtube.com/watch?v=KFTMBTDGTx8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-05-12 00:00:00+00:00

Go to https://privacy.com/linus ​to get $5 off your first purchase!

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire

An AMD Ryzen 9 3950X in a laptop? Sign me up, the XMG Apex 15 sounds wicked.

Click here for more information on XMG APEX 15: https://bit.ly/35XQFQI

Click here to freely configure the XMG APEX 15: https://bit.ly/2yV6Bap

Buy AMD Ryzen 9 3950X
On Amazon (PAID LINK): https://geni.us/Tz93yk
On Newegg (PAID LINK): https://geni.us/J3Jqt
On B&H (PAID LINK): https://geni.us/bJTi9l

Buy Intel Core i9-9900K
On Amazon (PAID LINK): https://geni.us/bmS5x
On Newegg (PAID LINK): https://geni.us/uBVwQ
On B&H (PAID LINK): https://geni.us/IgY5U

Buy NVIDIA RTX 2070
On Amazon (PAID LINK): https://geni.us/1bMtf
On Newegg (PAID LINK): https://geni.us/C3eNzkB

Buy 16GB G.SKILL Trident Z Royal
On Amazon (PAID LINK): https://geni.us/cfoUS
On Newegg (PAID LINK): https://geni.us/9vxWQE

Buy Samsung 970 Evo
On Amazon (PAID LINK): https://geni.us/iMnpOOE
On Newegg (PAID LINK): https://geni.us/LW0ThQQ

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1193385-the-most-powerful-laptop-ever/

GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Mech Keyboard: https://geni.us/RecNBTI
Get a Displate Metal Print at https://lmg.gg/displateltt
Use code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Gear on Amazon: https://geni.us/lmgamazon
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0 https://lmg.gg/fxHYK 
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://lmg.gg/Q9yyQ 
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://lmg.gg/8upii

