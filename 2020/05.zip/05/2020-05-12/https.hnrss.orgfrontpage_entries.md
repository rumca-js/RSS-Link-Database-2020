# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## A one-to-one call with his majesty (1999)
 - [https://www.theguardian.com/theguardian/1999/feb/11/features11.g22](https://www.theguardian.com/theguardian/1999/feb/11/features11.g22)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2020-05-12 23:53:33+00:00

<p>Article URL: <a href="https://www.theguardian.com/theguardian/1999/feb/11/features11.g22">https://www.theguardian.com/theguardian/1999/feb/11/features11.g22</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=23161607">https://news.ycombinator.com/item?id=23161607</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

