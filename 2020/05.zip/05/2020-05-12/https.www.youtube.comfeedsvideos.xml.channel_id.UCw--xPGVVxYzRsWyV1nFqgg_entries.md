# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## MY REVIEW STYLE
 - [https://www.youtube.com/watch?v=HnI_7TNjjGo](https://www.youtube.com/watch?v=HnI_7TNjjGo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-05-13 00:00:00+00:00

lets talk about how I review books. 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## FIRST LAW SPECIAL EDITION!📖 Lan Actor Discusses Role⚔️ Boba Fett RETURNS! - FANTASY NEWS
 - [https://www.youtube.com/watch?v=W0RAR_AJLrE](https://www.youtube.com/watch?v=W0RAR_AJLrE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-05-12 00:00:00+00:00

I agrogate the news worth knowing. You watch! Or don't. Though that makes my heart sad. FANTASY NEWS! 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

Tolkien Symposium: https://tolkienlecture.org/2020/05/09/tolkien-symposium-2020/

Looney Tunes: https://www.youtube.com/watch?v=i6AM7BJ_IpQ

Boba Felt Returns: https://www.hollywoodreporter.com/heat-vision/mandalorian-finds-boba-fett-temuera-morrison-1293675?utm_source=Sailthru&utm_medium=email&utm_campaign=THR%27s%20Heat%20Vision_now_2020-05-08%2013:19:16_acouch&utm_term=hollywoodreporter_heat_vision

BMO Trailer: https://youtu.be/XTuUoeNNrB8

Back to the Future Reunion: https://metro.co.uk/2020/05/07/back-future-reunion-confirmed-christoper-lloyd-teases-special-talk-josh-gad-12670067/amp/

40th Anniversary Flash Gordon: https://www.slashfilm.com/flash-gordon-4k-blu-ray-re-release/

Live Action Hercules: https://collider.com/hercules-remake-changes-russo-brothers-disney/

National Treasure Series: https://ew.com/tv/national-treasure-tv-series-disney-plus/?utm_term=BD60E188-90A5-11EA-B484-E0E94744363C&utm_source=twitter.com&utm_content=link&utm_medium=social&utm_campaign=entertainmentweekly_ew

Crunchyroll HBO Max: https://comicbook.com/anime/news/hbo-max-launch-anime-crunchyroll/

Art of the Cosmere interview: https://www.tor.com/2020/05/07/the-art-of-the-cosmere-an-interview-with-isaac-stewart/

Witcher’s Bestiary: https://www.youtube.com/watch?v=9u9OVRvj1fo

Signed Edition A Little Hatred: https://subterraneanpress.com/little-hatred

Daniel Henney lan: https://www.tor.com/2020/05/11/the-wheel-of-times-daniel-henney-talks-playing-lan-in-an-instagram-qa/

