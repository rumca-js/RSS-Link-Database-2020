# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## A 70th birthday celebration of Stevie Wonder (The Current Music News)
 - [https://www.youtube.com/watch?v=V5QKjTfNOzA](https://www.youtube.com/watch?v=V5QKjTfNOzA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-13 00:00:00+00:00

May 13, 2020: Stevie Wonder was there for Motown's early days, who had towering artistic successes with sprawling '70s albums, was a consistent hitmaker in the '80s, and remains active as an artist to this day.
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Alison Mosshart - interview with The Current's Jill Riley.
 - [https://www.youtube.com/watch?v=HOzFnmPmYZI](https://www.youtube.com/watch?v=HOzFnmPmYZI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-13 00:00:00+00:00

Singer-songwriter Alison Mosshart joins The Current's Jill Riley for a conversation about music, creativity and awesome cars.
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Car Seat Headrest - Full Session (Live at The Current, 2016)
 - [https://www.youtube.com/watch?v=P9xAjPKgcmQ](https://www.youtube.com/watch?v=P9xAjPKgcmQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-12 00:00:00+00:00

With a new Car Seat Headrest album in the news, we're digging into our archive to share the full 2016 session from Will Toledo and company. 

00:00 Stop Smoking
01:52 Fill In The Blank
06:46 Unforgiving Girl

The first song comes from Car Seat Headrest's 2011 album, Twin Fantasy, and the following two songs are from Car Seat Headrest's 2016 album, Teens of Denial, available on Matador Records.

PERSONNEL
Will Toledo, guitar, vocals
Ethan Ives, guitar
Andrew Katz, drums
Seth Dalby, bass

CREDITS
Produced by Derrick Stevens
Engineered by Michael DeMark and Andrew Broussard
Visuals by Nate Ryan
Edit by Helen Teague

## Car Seat Headrest - Stop Smoking (Live at The Current, 2016)
 - [https://www.youtube.com/watch?v=QfoIde5CBVM](https://www.youtube.com/watch?v=QfoIde5CBVM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-12 00:00:00+00:00

Watch Car Seat Headrest perform "Stop Smoking" from a studio session in 2016 at The Current. The song originally appears on Car Seat Headrest's 2011 album, Twin Fantasy.

PERSONNEL
Will Toledo, guitar, vocals
Ethan Ives, guitar
Andrew Katz, drums
Seth Dalby, bass

CREDITS
Produced by Derrick Stevens
Engineered by Michael DeMark and Andrew Broussard
Visuals by Nate Ryan
Edit by Helen Teague

## Car Seat Headrest - Unforgiving Girl (She's Not An) (Live at The Current, 2016)
 - [https://www.youtube.com/watch?v=baRzbTUiEII](https://www.youtube.com/watch?v=baRzbTUiEII)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-12 00:00:00+00:00

Watch Car Seat Headrest perform "Unforgiving Girl (She's Not An)" from a studio session in 2016 at The Current. The song originally appears on Car Seat Headrest's 2016 album, Teens of Denial, available on Matador Records.

PERSONNEL
Will Toledo, guitar, vocals
Ethan Ives, guitar
Andrew Katz, drums
Seth Dalby, bass

CREDITS
Produced by Derrick Stevens
Engineered by Michael DeMark and Andrew Broussard
Visuals by Nate Ryan
Edit by Helen Teague

## Dave Grohl on why concerts will return: 'We need each other' (The Current Music News)
 - [https://www.youtube.com/watch?v=S05-xmRW2lQ](https://www.youtube.com/watch?v=S05-xmRW2lQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-12 00:00:00+00:00

May 12, 2020: It's going to take a lot for live music to come back amidst a pandemic, but in a passionate essay, Dave Grohl says that eventually, it must. Also today: Doja Cat tops the Hot 100 and brings Nicki Minaj along for her first chart-topper; how older musicians are coping with the pandemic; and Billy Joel calls on New York to rise up together.
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

