# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## War Propaganda: How to Get a Country to Go to War
 - [https://www.youtube.com/watch?v=88Ev1gM0nt8](https://www.youtube.com/watch?v=88Ev1gM0nt8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2020-05-13 00:00:00+00:00

💻 Get 70% off a 3-year plan + 1 month free of NordVPN with code “jaketran” here: https://nordvpn.org/jaketran 

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join 

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
📸 Follow me on IG:@jaketran // http://bit.ly/jt-ig
👨👦👦 Join the Tran Mafia Family here: https://bit.ly/patreon-jt
💬 Join the community Discord: http://discord.gg/BmK8EnQ

Stuff I use & recommend:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
🏠 The real estate investing course I love & recommend: https://jake.yt/RE
🌐 Most flexible, affordable website hosting: https://jake.yt/bhd
🖥️ Website platform I use & love: https://jake.yt/kd
💽 Editing software I've used for 7+ years: https://jake.yt/ccd
📒 Online bookkeeping software I use& love: https://jake.yt/benchd 
🧾 Best affordable bookkeeping software: https://jake.yt/fbd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd
📚 Get 3 free audiobooks for life: https://amzn.to/2v58PSu
🎥 My video gear, setup, tech, books: https://jake.yt/stored

✉️ Email me: jake@jaketran.io

Subscribe to the backup channel on LBRY, use reward code "jake-cast" for free coin: https://bit.ly/LBRY-jt

📰 Sources & visuals: https://bit.ly/3clRANB

-----------------------
So you’re the heads of the US. You’ve grown comfortable being the world leader for so long now that you view the US as untouchable, that unlike every other empire in the past, the US empire will never fall. But then comes along China. 

No country in history has ever risen so far, so fast, on so many dimensions of power. that it’s starting to make us feel rather insecure - they’re outshining the master! Worst yet, you’re well aware of what’s called Thucydides Trap. Now, besides the people who profit off of war, no one really wants to go to war - it’s such a hassle. War is our nature. So in times like this, in the name of preparedness, Murphy’s law, just as a thought experiment, let’s say we did need to go to war with China - what would that process look like?

The concept of good fighting evil is so ingrained in us, it’s so primal to us, that if you can activate in people, they’ll go to the ends of the Earth, they’ll do whatever they can to defeat evil. This is the first step in our War Propaganda Machine. They have to believe that they’re the mythological “good guys,” and their fighting to put an end to those evil, barbarian bad guys.

If people believe that war is immoral, and that by going war, they’re immoral, they won’t be able to look at themselves in the mirror and will never support it, so you gotta change this perception by making war look like the most moral, altruistic thing we can do in this situation. But most importantly, you have to frame war as the path to peace - that we need to fight to spread democracy and freedom to these poor people enslaved by the Chinese government.

We need the media to promote our agenda and propaganda while not reporting what we don’t want the public to know about. Sure you’ll have politicians and smaller media outlets here and there that will question the official story, but no one takes them as seriously as a CNN or a New York Times anyways - they’ll be the unpatriotic outsiders. By invoking a sense of good vs evil, by making people feel that they’re on the moral high ground and that the pursuit of peace and democracy justifies war, and by gradually getting that drum beat of battle rising with your pals in the media until that one catalyst event .
-----------------------

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2020 Jake Tran. All rights reserved.

Sound:
Idealism - neon lights
Idealism - gone
Idealism - cold door handles
Idealism - crowds
https://open.spotify.com/album/3aHZpDjLZLWpGD9qJyFPAW?si=QbJ5yOX9QmWyhdOJ3uA0mg 

Music by Chillhop: http://chillhop.com/listen
Listen on Spotify: http://bit.ly/ChillhopSpotify

DISCLAIMER: These videos are for entertainment purposes only. This is not meant to be financial advice. Please always do your due diligence and never stop learning.

AFFILIATE DISCLOSURE: Some of the links in this video description are affiliate links, meaning, at no additional cost to you, I may earn a commission if you click through and make a purchase and/or opt-in. I only promote products that I 100% believe in.

