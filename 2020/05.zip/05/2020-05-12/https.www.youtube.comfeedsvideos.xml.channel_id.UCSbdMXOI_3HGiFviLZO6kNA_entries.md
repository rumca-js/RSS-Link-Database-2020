# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## This Oculus Quest hand tracking app is ACTUALLY GOOD
 - [https://www.youtube.com/watch?v=2ftCEwfPyMs](https://www.youtube.com/watch?v=2ftCEwfPyMs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-05-12 00:00:00+00:00

Hello and Welcome to TUESDAY NEWSDAY! Your number one resource for the entire weeks worth of VR news. 

Here are my links:

Today I will cover: (links coming soon)
Physics hand lab for Oculus Quest hand tracking is awesome


Sidequest hits 1 million downloads
https://uploadvr.com/sidequest-downloads-1-million/

PSVR patents including full body tracking
https://www.thegamepost.com/2020/05/08/next-gen-playstation-vr-patents/
https://www.roadtovr.com/researchers-head-mounted-haptics-combat-vr-discomfort-walkingvibe/

Meme break
https://www.reddit.com/r/VR_memes/comments/ghsxbz/those_bastards_lied_to_me/

Awesome kickstarter for VR exosuit module number one has opened
https://www.kickstarter.com/projects/mechatech/agilevr-immersive-locomotion-controller-for-virtual-reality

Medical industry to take VR profits to the next level
https://www.globenewswire.com/news-release/2020/05/11/2031228/0/en/Virtual-Reality-VR-in-Healthcare-Market-to-Reach-2-4-Billion-by-2026-AMR.html

Medal of Honor VR news


Walking Dead VR saints and Sinners sequel

