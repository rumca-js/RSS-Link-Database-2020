# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## What Does Carbonated Water Do to Your Body?
 - [https://www.youtube.com/watch?v=vdpKeaVmOy4](https://www.youtube.com/watch?v=vdpKeaVmOy4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2020-05-12 00:00:00+00:00

We love carbonated drinks, but they also get a bad rap. What does bubbly water do to our body? Is it really bad for us?

Go to http://Brilliant.org/SciShow to try out Brilliant’s Daily Challenges. The first 200 subscribers get 20% off an annual Premium subscription.

Hosted by: Hank Green

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Kevin Bealer, Jacob, Katie Marie Magnone, D.A. Noe, Charles Southerland, Eric Jensen, Christopher R Boucher, Alex Hackman, Matt Curls, Adam Brainard, Scott Satovsky Jr, Sam Buck, Ron Kakar, Chris Peters, Kevin Carpentier, Patrick D. Ashmore, Piya Shedden, Sam Lutfi, Charles George, Christoph Schwanke, Greg

----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://www.sciencedirect.com/topics/earth-and-planetary-sciences/carbonic-acid
https://www.ada.org/en/~/media/ADA/Public%20Programs/Files/JADA_The%20pH%20of%20beverages%20in%20the%20United%20States
https://www.sciencedirect.com/topics/agricultural-and-biological-sciences/carbonation
https://www.healthline.com/health/food-nutrition/is-phosphoric-acid-bad-for-me#1
https://ods.od.nih.gov/factsheets/Phosphorus-HealthProfessional/#en1
https://www.hindawi.com/journals/ijn/2018/3162806/
https://www.kidney.org/atoz/content/phosphorus
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3433753/
https://annals.org/aim/fullarticle/1920506/dietary-pharmacologic-management-prevent-recurrent-nephrolithiasis-adults-clinical-practice-guideline
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3433753/#R13
https://www.ncbi.nlm.nih.gov/pubmed/10092157/
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5771309/
https://www.ncbi.nlm.nih.gov/pubmed/11556958

Image Sources:
https://www.videoblocks.com/video/carbonated-water-is-poured-into-the-glass-v_dxemoheiljv6xop
https://upload.wikimedia.org/wikipedia/commons/0/08/Phosphoric-acid-3D-vdW.png
https://www.istockphoto.com/vector/abstract-vertical-tech-light-background-gm1163285802-319366797
https://www.istockphoto.com/photo/ice-coffee-in-a-tall-glass-with-cream-poured-over-and-coffee-beans-cold-summer-drink-gm936008054-256057953
https://www.istockphoto.com/photo/assortment-of-healthy-protein-source-and-body-building-food-gm655275624-127466867
https://upload.wikimedia.org/wikipedia/commons/b/b9/Calcium_oxalate_resonance.png

