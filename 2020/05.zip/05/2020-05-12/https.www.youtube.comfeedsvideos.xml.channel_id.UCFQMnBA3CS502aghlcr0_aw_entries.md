# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Exposing the Cameo Hustle ft. Wesley "Billion Dollar" Virgin
 - [https://www.youtube.com/watch?v=p2BCT01STn8](https://www.youtube.com/watch?v=p2BCT01STn8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-05-13 00:00:00+00:00

a closer look at the king of cameo clout, Wesley "Billion Dollar" Virgin and his elaborate hustle involving paying celebrities to shout him out for a nominal fee and then pretending like these are spontaneous shout-outs.
follow me here:
https://twitter.com/coffeebreak_YT

## Interviewing a Trump University Graduate
 - [https://www.youtube.com/watch?v=HOdE_TgzCI4](https://www.youtube.com/watch?v=HOdE_TgzCI4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-05-12 00:00:00+00:00

TRUMP UNIVERSITY IS MAKING COURSES GREAT AGAIN. 

A hilarious conversation with Amish Patel, a comedian who was enrolled into Trump University. The conversation covers everything about Trump University and quickly derails into everything from scams, pyramid schemes, the military industrial complex, and I had a blast. Let me know what you think and be sure to follow Amish Patel @fadetobrown
https://www.instagram.com/fadetobrown/

