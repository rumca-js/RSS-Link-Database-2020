# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Capone - Movie Review
 - [https://www.youtube.com/watch?v=R6Xt9-r1Y28](https://www.youtube.com/watch?v=R6Xt9-r1Y28)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-05-13 00:00:00+00:00

A biopic about the last year of Al Capone's life and his declining mental state. Here's my review for CAPONE!

#Capone

