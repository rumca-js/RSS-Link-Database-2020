# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## sanah - Królowa dram - wywiad MUZO.FM
 - [https://www.youtube.com/watch?v=oFMgHkt73gI](https://www.youtube.com/watch?v=oFMgHkt73gI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-05-12 00:00:00+00:00

sanah - wywiad w MUZO.FM. Artystka opowiada o debiutanckiej płycie - Królowa dram, sukcesie kawałka Szampan i o nieśmiałych początkach kariery. 


Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook sanah: http://www.facebook.com/sanahmusic
Instagram sanah: http://www.instagram.com/sanahmusic
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm 

#popolsku

