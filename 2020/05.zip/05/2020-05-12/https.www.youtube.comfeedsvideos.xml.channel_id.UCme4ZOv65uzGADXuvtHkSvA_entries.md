# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Ksiądz gra w grę: Uncharted 4 [#13] Potrzebujesz dystansu!
 - [https://www.youtube.com/watch?v=nmKZopUmwk4](https://www.youtube.com/watch?v=nmKZopUmwk4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-05-13 00:00:00+00:00

@Langustanapalmie #ksiądzgrawgrę #bedegrałwgre 
________________________________________
Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Miniaturkę stworzył dla nas: Sebastian Gwóźdź

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Nabożeństwo Majowe - 13 maja 2020
 - [https://www.youtube.com/watch?v=z6VbfF_-BSo](https://www.youtube.com/watch?v=z6VbfF_-BSo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-05-13 00:00:00+00:00

@langustanapalmie #majówka #langustanapalmie
------------------------------------------------------------

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#503] Toniesz?
 - [https://www.youtube.com/watch?v=pEexgi27X4w](https://www.youtube.com/watch?v=pEexgi27X4w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-05-13 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał  

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## BookSzpan [#03] Książkowe podjaranie
 - [https://www.youtube.com/watch?v=ClnphdnlF7o](https://www.youtube.com/watch?v=ClnphdnlF7o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-05-12 00:00:00+00:00

​@Langusta na palmie  #książki #bookszpan
________________________________________
Trzeci odcinek serii o książkach BookSzpan.

Spis książek z tego odcinka:

Prawda jest spotkaniem - Papież Franciszek
Po co światu mnich - Michał Zioło, Katarzyna Kolska, Roman Bielecki
Siedmiopiętrowa góra - Thomas Merton
Rok 1984 - George Orwell 
Madame - Antoni Libera
Floryda - Lauren Groff 
Normalni ludzie - Sally Rooney 
Droga - Cormac Mccarthy 
Dziki Ojciec - Szymon Grzelak
Siła nawyku - Charles Duhigg 
Z wielką odwagą - Brene Brown 
Zimny ogień - Dean Koontz
Wzlot i upadek D.O.D.O. - Neal Stephenson, Nicole Galland

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Nabożeństwo Majowe - 12 maja 2020
 - [https://www.youtube.com/watch?v=O5WFIh0buoA](https://www.youtube.com/watch?v=O5WFIh0buoA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-05-12 00:00:00+00:00

@langustanapalmie #majówka #langustanapalmie
------------------------------------------------------------

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#502] Miłość
 - [https://www.youtube.com/watch?v=3S8_IG0AOGs](https://www.youtube.com/watch?v=3S8_IG0AOGs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-05-12 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał  

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

