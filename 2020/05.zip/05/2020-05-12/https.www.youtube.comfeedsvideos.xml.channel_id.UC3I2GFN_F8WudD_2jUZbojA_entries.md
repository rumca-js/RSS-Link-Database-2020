# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Cheikh Lô - Bourama (Live on KEXP)
 - [https://www.youtube.com/watch?v=y4jipgkYvZM](https://www.youtube.com/watch?v=y4jipgkYvZM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-13 00:00:00+00:00

http://KEXP.ORG presents Cheikh Lô performing "Bourama" live in the KEXP studio. Recorded January 20, 2020.

Host: Darek Mazzone
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
http://cheikhlomusic.com

## Cheikh Lô - Degg Gui (Live on KEXP)
 - [https://www.youtube.com/watch?v=2WyNsvX2MZw](https://www.youtube.com/watch?v=2WyNsvX2MZw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-13 00:00:00+00:00

http://KEXP.ORG presents Cheikh Lô performing "Degg Gui" live in the KEXP studio. Recorded January 20, 2020.

Host: Darek Mazzone
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
http://cheikhlomusic.com

## Cheikh Lô - Doxandeme (Live on KEXP)
 - [https://www.youtube.com/watch?v=HWiOEMWlGzE](https://www.youtube.com/watch?v=HWiOEMWlGzE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-13 00:00:00+00:00

http://KEXP.ORG presents Cheikh Lô performing "Doxandeme" live in the KEXP studio. Recorded January 20, 2020.

Host: Darek Mazzone
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
http://cheikhlomusic.com

## Cheikh Lô - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=uoSY-b3sn4E](https://www.youtube.com/watch?v=uoSY-b3sn4E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-13 00:00:00+00:00

http://KEXP.ORG presents Cheikh Lô performing live in the KEXP studio. Recorded January 20, 2020.

Songs:
Guiss Guiss
Degg Gui
Bourama
Doxandeme

Host: Darek Mazzone
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
http://cheikhlomusic.com

## Cheikh Lô - Guiss Guiss (Live on KEXP)
 - [https://www.youtube.com/watch?v=ZHFhcPifams](https://www.youtube.com/watch?v=ZHFhcPifams)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-13 00:00:00+00:00

http://KEXP.ORG presents Cheikh Lô performing "Guiss Guiss" live in the KEXP studio. Recorded January 20, 2020.

Host: Darek Mazzone
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
http://cheikhlomusic.com

## Hamilton Leithauser (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=iAFomFQkJxw](https://www.youtube.com/watch?v=iAFomFQkJxw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-12 00:00:00+00:00

Hamilton Leithauser performs from his home and joins Morgan, live on KEXP, on Tuesday, May 12, at 12pm PT.

