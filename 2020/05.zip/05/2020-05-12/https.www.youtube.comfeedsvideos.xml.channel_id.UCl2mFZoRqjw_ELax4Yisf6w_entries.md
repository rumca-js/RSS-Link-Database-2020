# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Samsung 970 Evo NVMe failed again 😥 two in less than a year
 - [https://www.youtube.com/watch?v=ywwtQ6kFFIc](https://www.youtube.com/watch?v=ywwtQ6kFFIc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-05-13 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545

## A1706 stuck at 5v with PP3V3_G3H present &working CD3215 - what could it be??
 - [https://www.youtube.com/watch?v=vXAK2l1oMZM](https://www.youtube.com/watch?v=vXAK2l1oMZM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-05-12 00:00:00+00:00

Let's get Right to Repair passed! https://gofund.me/1cba2545
👉 If our videos have added revenue to your business, consider becoming a patron
🔵 Patreon https://www.patreon.com/rossmanngroup

🔵 We fix Macbooks & offer free estimates. https://rossmanngroup.com
🔵 Send us your Macbook for repair! http://bit.ly/sendmacbook
🔵 We'll send you a box with a pre-paid shipping label for your repair! http://bit.ly/sendyourmacbook
🔵 We offer iPhone data recovery: http://bit.ly/2BDBX4G
🔵 We offer lab hard drive data recovery: http://bit.ly/labdatarecovery

👉 LEARN HOW TO DO THIS:
› In-person classes: https://bit.ly/classrg
› Beginner's guide: http://bit.ly/2k6uz84
› Support forum: $29/mo http://bit.ly/boardrepairforum

👉 Donate & post a message: http://bit.ly/postamessage 

👉 Below we list tools & recording gear we use, repair guides to help you learn, online chip sources, & donation links:

👉 BlackBerry, Oreo, & Clinton the cat's wish list: https://www.amazon.com/hz/wishlist/ls/2YC1L66N7T5BC?&sort=default

👉 CHIPS & COMPONENTS:
› http://bit.ly/2jaAOXM

👉 Discord: https://tinyurl.com/rossmatrix

👉 TOOLS USED:

✓ Soldering Irons:
› Louis' Hakko station(no tweezers): http://amzn.to/2cKkMyO 
› Paul's Hakko station(works with tweezers): http://amzn.to/2yMvWNy
› Micro Soldering Pencil: http://amzn.to/2d5MWUP
› Hot tweezers: http://amzn.to/2yMvZsZ
› Atten ST-862D hot air station: http://bit.ly/atten862

✓ CHEAP HAKKO ALTERNATIVES:
› TS100 soldering iron: https://amzn.to/2Gy1Fqz
› Recommended tips: TS-C4: https://amzn.to/33s3jpW TS-KU https://amzn.to/2QsKT36

✓ Preferred Soldering Tips
› Fine: http://amzn.to/2d5MgPn 
› Flat: https://amzn.to/2JnsDBT 
› GPU wicking: http://amzn.to/2w8chtB
› Micro soldering tip: http://amzn.to/2qUSFDh

✓ Microscopes:
› Microscope: http://amzn.to/2iLrE16 
› Barlow lens: http://amzn.to/2yMKdKf
› LED light: http://amzn.to/2nzfPT2
› CHEAP alternative microscope: http://amzn.to/2rTlHbj

✓ Soldering/Repair Supplies:
› Solder: http://amzn.to/2cKkxUp
› Desoldering braid: http://bit.ly/2otflOX
› Flux: http://bit.ly/amtechflux
› Solder paste: http://bit.ly/amtechsolderpaste
› THICK insulated jumper wire: https://amzn.to/2rvtD0A
› THIN insulated jumper wire: https://amzn.to/2I47DQY
› Kapton tape: http://amzn.to/2yN0xuq
› Tweezers: http://amzn.to/2d5NBpi
› Blades: http://amzn.to/2ByWnvF
› Freeze Spray: http://amzn.to/2BySozw
› Conformal coating: http://bit.ly/greencoate
› Conformal coating curing pen: http://bit.ly/uvpen

✓ Diagnostic tools:
› USB amp meter: http://bit.ly/2B2Lu5W
› USB-C amp meter: http://bit.ly/usbcamp
› On-Screen multimeter: http://amzn.to/2jtgY9K 
› Multimeter Probes: http://bit.ly/fineprobes
› CHEAP multimeter: http://amzn.to/2zjkg8U
› Bench PSU: CSI3005P http://bit.ly/benchsupply
› Phoneboard: https://phoneboard.co
› Boardview software: https://pldaniels.com/flexbv/

✓ Ultrasonic Cleaning:
› ALL MACBOOKS & CELLPHONES: Crest P1200H-45: https://amzn.to/2ITSQdw
› PRE-TOUCHBAR MACBOOKS & CELLPHONES: Crest P500H-45: https://amzn.to/2Qrnhf8
› CELLPHONES ONLY: Crest P230H-45: https://amzn.to/2QsckKG
› Branson EC cleaning fluid: http://amzn.to/2cKlBrp

✓ Desk supplies:
› Desk: http://amzn.to/2yMShdZ
› Chair: https://amzn.to/2LB8bUB
› Fume Extractor: http://amzn.to/2d5MGoD
› Work mat: http://amzn.to/2yMtlTR
› Outlets: http://amzn.to/2yNsZwo
› Gloves: http://amzn.to/2iUfumS
› Durable lightning cable: http://amzn.to/2yNHzUt
› Fine tipped snippers: http://amzn.to/2HGt4XB

✓ Screwdrivers: 
› iPhone bottom screw: http://amzn.to/2yNwX8p
› Macbook bottom screw: http://amzn.to/2AKMdVb
› Torx T3: http://amzn.to/2zjtxxH
› Torx T5 http://amzn.to/2BLNDn4
› Torx T6 http://amzn.to/2B0XIfA
› Torx T8 http://amzn.to/2CpWp68
› Phillips #0: http://amzn.to/2AJaHhM
› Phillips #000: http://amzn.to/2yNqsCl



✓ RECORDING EQUIPMENT:
› Work cam: https://amzn.to/2QjHnt0
› Overhead cam: http://amzn.to/2eAH0oT
› Work mic: https://amzn.to/2WGIhzw
› Home mic: https://amzn.to/2xfampC
› Microscope camera: http://amzn.to/2icVQoG - mine is DISCONTINUED, closest one I can find. 
› HDMI capture: http://amzn.to/2iyGcle

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com

👉 Leave a tip for us via cryptocurrency if we've helped you out:
› Credit card: http://bit.ly/postamessage
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

## Wearing a mask during coronavirus, my opinion as a business owner
 - [https://www.youtube.com/watch?v=3PGwnm_pNnM](https://www.youtube.com/watch?v=3PGwnm_pNnM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-05-12 00:00:00+00:00

https://tinyurl.com/rossmatrix
🔵  https://aip.scitation.org/doi/pdf/10.1063/5.0016018
🔵  https://www.healthaffairs.org/doi/10.1377/hlthaff.2020.00818
🔵  https://www.medrxiv.org/content/10.1101/2020.05.22.20109231v3
🔵  https://www.pnas.org/content/117/26/14857
🔵  https://royalsocietypublishing.org/doi/10.1098/rspa.2020.0376
🔵  https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(20)31142-9/fulltext
🔵  https://onlinelibrary.wiley.com/doi/full/10.1111/jep.13415
🔵  https://arxiv.org/pdf/2005.12446.pdf
🔵  https://www.acpjournals.org/doi/10.7326/M20-2567
🔵  https://www.medrxiv.org/content/10.1101/2020.04.17.20069567v4.full.pdf
🔵  https://gh.bmj.com/content/bmjgh/5/5/e002794.full.pdf
🔵  https://www.cambridge.org/core/services/aop-cambridge-core/content/view/476E32549012B3620D2452F30F2567F1/S0022112020003304a.pdf/flow_physics_of_covid19.pdf
🔵  https://pubs.acs.org/doi/10.1021/acsnano.0c03252
🔵  https://www.medrxiv.org/content/10.1101/2020.04.20.20064899v1
🔵  https://www.sciencedirect.com/science/article/pii/S0020748920301139
🔵  https://arxiv.org/pdf/2004.13553.pdf
🔵  https://www.medrxiv.org/content/10.1101/2020.04.17.20069567v2.full.pdf
🔵  https://www.nejm.org/doi/full/10.1056/NEJMc2007800
🔵  https://www.cdc.gov/mmwr/volumes/69/wr/mm6915e5.htm?s_cid=mm6915e5_w
🔵  https://www.preprints.org/manuscript/202004.0203/v2
🔵  https://www.bmj.com/content/369/bmj.m1435
🔵  https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3567438
🔵  https://www.medrxiv.org/content/10.1101/2020.04.01.20049528v1.full.pdf
🔵  https://www.medrxiv.org/content/10.1101/2020.03.30.20047217v2.full.pdf
🔵  https://www.medrxiv.org/content/10.1101/2020.03.31.20048652v1
🔵  https://www.medrxiv.org/content/10.1101/2020.04.02.20051177v1.full.pdf
🔵  https://www.nature.com/articles/s41591-020-0843-2
🔵  https://onlinelibrary.wiley.com/doi/full/10.1002/jmv.25805
🔵  https://arxiv.org/ftp/arxiv/papers/2003/2003.07353.pdf
🔵  https://pubmed.ncbi.nlm.nih.gov/32167245/
🔵  https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7134426/?report=classic
🔵  https://bmcpulmmed.biomedcentral.com/track/pdf/10.1186/s12890-019-0940-5
🔵  https://jamanetwork.com/journals/jama/fullarticle/2749214
🔵  https://onlinelibrary.wiley.com/doi/full/10.1111/risa.13181
🔵  https://wwwnc.cdc.gov/eid/article/22/11/16-0920_article
🔵  https://www.clinicalmicrobiologyandinfection.com/article/S1198-743X(16)30241-5/fulltext
🔵  https://www.cmaj.ca/content/cmaj/188/8/567.full.pdf
🔵  https://www.clinicalmicrobiologyandinfection.com/article/S1198-743X(15)00837-X/fulltext
🔵  https://pubmed.ncbi.nlm.nih.gov/25336079/
🔵  https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3810906/
🔵  https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7108646/
🔵  https://www.sciencedirect.com/science/article/abs/pii/S0195670113000698
🔵  https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3591312/
🔵  https://pubmed.ncbi.nlm.nih.gov/22476275/
🔵  https://pubmed.ncbi.nlm.nih.gov/22280120/
🔵  https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0029744
🔵  https://onlinelibrary.wiley.com/doi/full/10.1111/j.1750-2659.2011.00318.x
🔵  https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6993921/
🔵  https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2821845/
🔵  https://academic.oup.com/jid/article/201/4/491/861190
🔵  https://onlinelibrary.wiley.com/doi/full/10.1111/j.1365-3156.2009.02255.x
🔵  https://www.acpjournals.org/doi/full/10.7326/0003-4819-151-7-200910060-00142?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200pubmed
🔵  https://pubmed.ncbi.nlm.nih.gov/19522650/
🔵  https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2662657/
🔵  https://www.ijidonline.com/article/S1201-9712(08)01008-4/fulltext
🔵  https://pubmed.ncbi.nlm.nih.gov/18806349/
🔵  https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2440799/
🔵  https://bmcpublichealth.biomedcentral.com/articles/10.1186/1471-2458-6-207
🔵  https://pubmed.ncbi.nlm.nih.gov/16778970/
🔵  https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3373043/?report=classic
🔵  http://www.ajtmh.org/content/journals/10.4269/ajtmh.2005.73.17
🔵  https://wwwnc.cdc.gov/eid/article/11/7/04-1165_article
🔵  https://www.cambridge.org/core/services/aop-cambridge-core/content/view/55025CCAFE6E5F3B30C31ECB6E73A3D4/S0950268804002766a.pdf/factors_associated_with_transmission_of_severe_acute_respiratory_syndrome_among_healthcare_workers_in_singapore.pdf
🔵  https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3323085/
🔵  https://academic.oup.com/jid/article/189/4/642/839039
🔵  https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3322931/
🔵  https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3322898/
🔵  https://pubmed.ncbi.nlm.nih.gov/15061941/
🔵  https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3033076/
🔵  https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(03)13168-6/fulltext

## 😢 A sad look at Steve's hard drive data recovery queue
 - [https://www.youtube.com/watch?v=-9jaya61t5M](https://www.youtube.com/watch?v=-9jaya61t5M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-05-12 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
🔵 We fix Macbooks & offer free estimates. https://rossmanngroup.com
🔵 Send us your Macbook for repair! http://bit.ly/sendmacbook
🔵 We'll send you a box with a pre-paid shipping label for your repair! http://bit.ly/sendyourmacbook
🔵 We offer iPhone data recovery: http://bit.ly/2BDBX4G
🔵 We offer lab hard drive data recovery: http://bit.ly/labdatarecovery

👉 LEARN HOW TO DO THIS:
› In-person classes: https://bit.ly/classrg
› Beginner's guide: http://bit.ly/2k6uz84
› Support forum: $29/mo http://bit.ly/boardrepairforum

👉 Donate & post a message: http://bit.ly/postamessage 

👉 Below we list tools & recording gear we use, repair guides to help you learn, online chip sources, & donation links:

👉 BlackBerry, Oreo, & Clinton the cat's wish list: https://www.amazon.com/hz/wishlist/ls/2YC1L66N7T5BC?&sort=default

👉 CHIPS & COMPONENTS:
› http://bit.ly/2jaAOXM

👉 Discord: https://discord.gg/uz9Jt76

👉 TOOLS USED:

✓ Soldering Irons:
› Louis' Hakko station(no tweezers): http://amzn.to/2cKkMyO 
› Paul's Hakko station(works with tweezers): http://amzn.to/2yMvWNy
› Micro Soldering Pencil: http://amzn.to/2d5MWUP
› Hot tweezers: http://amzn.to/2yMvZsZ
› Atten ST-862D hot air station: http://bit.ly/atten862

✓ CHEAP HAKKO ALTERNATIVES:
› TS100 soldering iron: https://amzn.to/2Gy1Fqz
› Recommended tips: TS-C4: https://amzn.to/33s3jpW TS-KU https://amzn.to/2QsKT36

✓ Preferred Soldering Tips
› Fine: http://amzn.to/2d5MgPn 
› Flat: https://amzn.to/2JnsDBT 
› GPU wicking: http://amzn.to/2w8chtB
› Micro soldering tip: http://amzn.to/2qUSFDh

✓ Microscopes:
› Microscope: http://amzn.to/2iLrE16 
› Barlow lens: http://amzn.to/2yMKdKf
› LED light: http://amzn.to/2nzfPT2
› CHEAP alternative microscope: http://amzn.to/2rTlHbj

✓ Soldering/Repair Supplies:
› Solder: http://amzn.to/2cKkxUp
› Desoldering braid: http://bit.ly/2otflOX
› Flux: http://bit.ly/amtechflux
› Solder paste: http://bit.ly/amtechsolderpaste
› THICK insulated jumper wire: https://amzn.to/2rvtD0A
› THIN insulated jumper wire: https://amzn.to/2I47DQY
› Kapton tape: http://amzn.to/2yN0xuq
› Tweezers: http://amzn.to/2d5NBpi
› Blades: http://amzn.to/2ByWnvF
› Freeze Spray: http://amzn.to/2BySozw
› Conformal coating: http://bit.ly/greencoate
› Conformal coating curing pen: http://bit.ly/uvpen

✓ Diagnostic tools:
› USB amp meter: http://bit.ly/2B2Lu5W
› USB-C amp meter: http://bit.ly/usbcamp
› On-Screen multimeter: http://amzn.to/2jtgY9K 
› Multimeter Probes: http://bit.ly/fineprobes
› CHEAP multimeter: http://amzn.to/2zjkg8U
› Bench PSU: CSI3005P http://bit.ly/benchsupply
› Phoneboard: https://phoneboard.co
› Boardview software: https://pldaniels.com/flexbv/

✓ Ultrasonic Cleaning:
› ALL MACBOOKS & CELLPHONES: Crest P1200H-45: https://amzn.to/2ITSQdw
› PRE-TOUCHBAR MACBOOKS & CELLPHONES: Crest P500H-45: https://amzn.to/2Qrnhf8
› CELLPHONES ONLY: Crest P230H-45: https://amzn.to/2QsckKG
› Branson EC cleaning fluid: http://amzn.to/2cKlBrp

✓ Desk supplies:
› Desk: http://amzn.to/2yMShdZ
› Chair: https://amzn.to/2LB8bUB
› Fume Extractor: http://amzn.to/2d5MGoD
› Work mat: http://amzn.to/2yMtlTR
› Outlets: http://amzn.to/2yNsZwo
› Gloves: http://amzn.to/2iUfumS
› Durable lightning cable: http://amzn.to/2yNHzUt
› Fine tipped snippers: http://amzn.to/2HGt4XB

✓ Screwdrivers: 
› iPhone bottom screw: http://amzn.to/2yNwX8p
› Macbook bottom screw: http://amzn.to/2AKMdVb
› Torx T3: http://amzn.to/2zjtxxH
› Torx T5 http://amzn.to/2BLNDn4
› Torx T6 http://amzn.to/2B0XIfA
› Torx T8 http://amzn.to/2CpWp68
› Phillips #0: http://amzn.to/2AJaHhM
› Phillips #000: http://amzn.to/2yNqsCl



✓ RECORDING EQUIPMENT:
› Work cam: https://amzn.to/2QjHnt0
› Overhead cam: http://amzn.to/2eAH0oT
› Work mic: https://amzn.to/2WGIhzw
› Home mic: https://amzn.to/2xfampC
› Microscope camera: http://amzn.to/2icVQoG - mine is DISCONTINUED, closest one I can find. 
› HDMI capture: http://amzn.to/2iyGcle

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com

👉 Leave a tip for us via cryptocurrency if we've helped you out:
› Credit card: http://bit.ly/postamessage
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

