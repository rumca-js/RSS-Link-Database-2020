# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## Amid Pandemic, Renewables Now Supply More Energy than Coal in the U.S.
 - [https://www.youtube.com/watch?v=7lkwnJsioL4](https://www.youtube.com/watch?v=7lkwnJsioL4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2020-05-13 00:00:00+00:00

The first 1000 who click the link wiIl get 2 months of Skillshare Premium for FREE  https://skl.sh/coldfusion4

Thorium video: https://youtu.be/U1lIfFcxVuY

--- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. 

If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- New Thinking Book written by Dagogo Altraide ---
This book is rated the 9th best technology history book by book authority.
In the book you’ll learn the stories of those who invented the things we use everyday and how it all fits together to form our modern world.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

--- ColdFusion Social Media ---
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusionTV

--- ColdFusion Podcast links ---
Google Podcasts - http://bit.ly/2xo8doR
Apple Podcasts - https://apple.co/2WI2IeU
Spotify - https://spoti.fi/2KT1taB
Stitcher - http://bit.ly/2WI4f4E

Sources:

https://www.ibisworld.com/united-states/market-research-reports/hydroelectric-power-industry/

https://reneweconomy.com.au/scientists-set-new-solar-power-efficiency-record-at-almost-50-per-cent-71555/

https://ieefa.org/wp-content/uploads/2020/03/US-Coal-Outlook-2020_March-2020.pdf

https://www.wired.com/story/next-gen-nuclear/

https://leaderpost.com/opinion/columnists/mandryk-perhaps-the-time-has-come-to-revisit-nuclear-options/

https://www.usenergyjobs.org/

https://static1.squarespace.com/static/5a98cf80ec4eb7c5cd928c61/t/5e78b3c756e8367abbd47ab0/1584968660321/USEER+2020+0323.pdf

https://static1.squarespace.com/static/5a98cf80ec4eb7c5cd928c61/t/5e78b363087a892473ac6cdf/1584968554743/2020+USEER+EXEC+0323.pdf

https://ieefa.org/category/subject/reports/

https://ieefa.org/ieefa-report-market-trends-are-pushing-u-s-coal-closer-to-a-reckoning/


//Soundtrack//

Ephemerals - You'll Never See Me Cry (Ambassadeurs Remix)

Hiatus - As Close To Me As You Are Now

Balmorhea - [SEQUENCED]14

Sleepy Fish - Forgot It Was Monday

Julianna Barwick - Look Into Your Own Mind

Burn Water - Burning Love

» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide

