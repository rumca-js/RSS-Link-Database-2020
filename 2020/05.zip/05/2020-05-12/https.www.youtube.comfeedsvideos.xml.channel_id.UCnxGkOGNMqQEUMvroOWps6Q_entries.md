# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Joe Rogan Ponders Move to Texas, Calls Bryan Callen
 - [https://www.youtube.com/watch?v=9OUz6I5UORg](https://www.youtube.com/watch?v=9OUz6I5UORg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-13 00:00:00+00:00

Taken from JRE #1473 w/Tom Papa:
https://youtu.be/EToUmoEYGuU

## Joe Rogan Reacts to 3 month Extension of LA Shelter in Place Order
 - [https://www.youtube.com/watch?v=h6ADS1Oy-4A](https://www.youtube.com/watch?v=h6ADS1Oy-4A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-13 00:00:00+00:00

Taken from JRE #1473 w/Tom Papa:
https://youtu.be/EToUmoEYGuU

## Joe Rogan Reacts to Mike Tyson’s Return to Boxing
 - [https://www.youtube.com/watch?v=XolBNaavdAQ](https://www.youtube.com/watch?v=XolBNaavdAQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-13 00:00:00+00:00

Taken from JRE #1473 w/Tom Papa: https://youtu.be/EToUmoEYGuU

## Joe Rogan Weighs In On Trump’s Clash with Asian-American Reporter
 - [https://www.youtube.com/watch?v=jmwYl0aqx3Q](https://www.youtube.com/watch?v=jmwYl0aqx3Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-13 00:00:00+00:00

Taken from JRE #1473 w/Tom Papa: https://youtu.be/EToUmoEYGuU

## Joe Rogan's Thoughts on Slap Fighting, "Jeff Goldblum" Street Fight, Praying Mantises
 - [https://www.youtube.com/watch?v=jshXRSwpVx0](https://www.youtube.com/watch?v=jshXRSwpVx0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-13 00:00:00+00:00

Taken from JRE #1473 w/Tom Papa:
https://youtu.be/EToUmoEYGuU

## How a Parasitic Disease Created the “Lazy Southerner” Stereotype
 - [https://www.youtube.com/watch?v=O4W-YI-NmR0](https://www.youtube.com/watch?v=O4W-YI-NmR0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-12 00:00:00+00:00

Taken from JRE #1472 w/Michael Yo: https://youtu.be/KdDPhoyypcg

## Joe Rogan Comments on Armed Michigan Lockdown Protesters
 - [https://www.youtube.com/watch?v=_CC5iaaCf8g](https://www.youtube.com/watch?v=_CC5iaaCf8g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-12 00:00:00+00:00

Taken from JRE #1472 w/Michael Yo: https://youtu.be/KdDPhoyypcg

## Joe Rogan Reacts to the Government’s Release of UFO Videos
 - [https://www.youtube.com/watch?v=Z2ZTGupYCRo](https://www.youtube.com/watch?v=Z2ZTGupYCRo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-12 00:00:00+00:00

Taken from JRE #1472 w/Michael Yo: https://youtu.be/KdDPhoyypcg

## Joe Rogan on Doing Commentary for UFC #249 with Coronavirus Guidelines
 - [https://www.youtube.com/watch?v=AKn0usottIY](https://www.youtube.com/watch?v=AKn0usottIY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-12 00:00:00+00:00

Taken from JRE #1472 w/Michael Yo:
https://youtu.be/KdDPhoyypcg

## Joe Rogan's Post Fight Thoughts on Tony Ferguson vs. Justin Gaethje
 - [https://www.youtube.com/watch?v=3wxX6rzkyoI](https://www.youtube.com/watch?v=3wxX6rzkyoI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-12 00:00:00+00:00

Taken from JRE #1472 w/Michael Yo:
https://youtu.be/KdDPhoyypcg

## Joe Rogan: Ahmaud Arbery Killing Was Vigilanteism
 - [https://www.youtube.com/watch?v=pFk9mDK3PuI](https://www.youtube.com/watch?v=pFk9mDK3PuI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-12 00:00:00+00:00

Taken from JRE #1472 w/Michael Yo: https://youtu.be/KdDPhoyypcg

## Michael Yo Details His Harrowing Coronavirus Experience | Joe Rogan
 - [https://www.youtube.com/watch?v=IgEUsIIhl0A](https://www.youtube.com/watch?v=IgEUsIIhl0A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-12 00:00:00+00:00

Taken from #1472 w/Michael Yo:
https://youtu.be/KdDPhoyypcg

## Michael Yo Talks About Growing Up Mixed-Race in Texas
 - [https://www.youtube.com/watch?v=J2EgkC1uop8](https://www.youtube.com/watch?v=J2EgkC1uop8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-12 00:00:00+00:00

Taken from JRE #1472 w/Michael Yo: https://youtu.be/KdDPhoyypcg

## People Shunned Michael Yo After He Recovered from Coronavirus
 - [https://www.youtube.com/watch?v=DtSB0Q7iKmE](https://www.youtube.com/watch?v=DtSB0Q7iKmE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-12 00:00:00+00:00

Taken from JRE #1472 w/Michael Yo: https://youtu.be/KdDPhoyypcg

## Striking Garbage Workers Were Replaced by Prisoners in New Orleans
 - [https://www.youtube.com/watch?v=QfEGj0hORhI](https://www.youtube.com/watch?v=QfEGj0hORhI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-12 00:00:00+00:00

Taken from JRE #1472 w/Michael Yo: https://youtu.be/KdDPhoyypcg

