## Ministerstwo zdrowia kupiło maseczki od znajomego ministra Szumowskiego. Teraz żąda zwrotu pieniędzy - Money.pl
 - [https://www.money.pl/gospodarka/ministerstwo-zdrowia-kupilo-maseczki-od-znajomego-ministra-szumowskiego-teraz-zada-zwrotu-pieniedzy-6509608986204289a.html](https://www.money.pl/gospodarka/ministerstwo-zdrowia-kupilo-maseczki-od-znajomego-ministra-szumowskiego-teraz-zada-zwrotu-pieniedzy-6509608986204289a.html)
 - RSS feed: https://www.money.pl
 - date published: 2020-05-12 20:29:09+00:00

Ministerstwo zdrowia kupiło maseczki od znajomego ministra Szumowskiego. Teraz żąda zwrotu pieniędzy - Money.pl

