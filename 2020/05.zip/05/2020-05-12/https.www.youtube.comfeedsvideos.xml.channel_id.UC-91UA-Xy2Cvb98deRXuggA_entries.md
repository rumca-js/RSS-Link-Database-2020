# Source:Joshua Fluke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-91UA-Xy2Cvb98deRXuggA, language:en-US

## Studying for my Pilot's License! (Q&A) | #grindreel #studywithme
 - [https://www.youtube.com/watch?v=12E2urk1TPc](https://www.youtube.com/watch?v=12E2urk1TPc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-91UA-Xy2Cvb98deRXuggA
 - date published: 2020-05-13 00:00:00+00:00

❤️ Support me because corporate sponsors rarely do! 
 https://www.patreon.com/joshuafluke

🔥 Need a resume/cover letter? Check out my templates!  
https://grindreel.com/

👊 Join the community! 
https://discord.gg/Joshuafluke

My Other Socials🤳
https://www.tiktok.com/@joshua_fluke
https://www.instagram.com/joshuafluke/  📸
https://twitter.com/joshuafluke  🐦

📧 Email me directly!: grindreel@gmail.com
📧 Business inquiries: Joshuafluke@thoughtleaders.io  

My Gear ⚙️:  https://kit.co/JoshuaFluke

## CORPORATE CRINGE - GARY VAYNERCHUK | #grindreel
 - [https://www.youtube.com/watch?v=mJHDjNfn1vM](https://www.youtube.com/watch?v=mJHDjNfn1vM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-91UA-Xy2Cvb98deRXuggA
 - date published: 2020-05-12 00:00:00+00:00

❤️ Support me because corporate sponsors rarely do! 
 https://www.patreon.com/joshuafluke

🔥 Need a resume/cover letter? Check out my templates!  
https://grindreel.com/

👊 Join the community! 
https://discord.gg/Joshuafluke

My Other Socials🤳
https://www.tiktok.com/@joshua_fluke
https://www.instagram.com/joshuafluke/  📸
https://twitter.com/joshuafluke  🐦

📧 Email me directly!: grindreel@gmail.com
📧 Business inquiries: Joshuafluke@thoughtleaders.io  

My Gear ⚙️:  https://kit.co/JoshuaFluke

