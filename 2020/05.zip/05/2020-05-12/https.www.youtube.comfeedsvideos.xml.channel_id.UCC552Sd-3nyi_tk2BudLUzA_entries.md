# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## The Truth About 5G ft. MKBHD
 - [https://www.youtube.com/watch?v=cw0A9FUTEKE](https://www.youtube.com/watch?v=cw0A9FUTEKE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2020-05-13 00:00:00+00:00

Is 5G Dangerous? Marques Brownlee helps us explain what is 5G, the health impacts on your body, whether it can make you sick, and some other claims being made!
Conspiracy Theories (5G, Coronavirus, Plandemic) https://youtu.be/u2NeoJHP6F0
JOIN OUR NEW EMAIL LIST: https://mailchi.mp/072240d817d6/asapscience

Check out MKBHD's Channel: https://www.youtube.com/user/marquesbrownlee

Why Conspiracy Theories Work: https://youtu.be/tfVgHRPC7Ao

ICNIRP 2020 Guidelines: https://www.icnirp.org/cms/upload/publications/ICNIRPrfgdl2020.pdf

Subscribe for more asapscience, and hit that bell :)
Created by: Mitchell Moffit and Gregory Brown

FOLLOW US!
Mitch
Instagram: https://instagram.com/mitchellmoffit
Twitter: https://twitter.com/mitchellmoffit 

Greg
Instagram: https://instagram.com/whalewatchmeplz 
Twitter: https://twitter.com/whalewatchmeplz 

AsapSCIENCE
Instagram: https://instagram.com/asapscience 
Facebook: https://facebook.com/asapscience 
Twitter: https://twitter.com/asapscience
TikTok: @AsapSCIENCE 



MORE INFO/SOURCES:
https://www.icnirp.org/en/applications/mobile-phones/index.html
https://ec.europa.eu/health/scientific_committees/opinions_layman/en/electromagnetic-fields/l-2/7-power-lines-elf.htm
https://www.icnirp.org/cms/upload/publications/ICNIRPSCIreview2011.pdf
https://ec.europa.eu/health/scientific_committees/opinions_layman/en/electromagnetic-fields/l-2/7-power-lines-elf.htm
https://allianceforscience.cornell.edu/blog/2020/04/5g-whats-behind-the-latest-covid-conspiracy-theory/
https://www.cancer.org/cancer/cancer-causes/radiation-exposure/radiofrequency-radiation.html
http://www.columbia.edu/~vjd1/electromag_spectrum.htm
https://imagine.gsfc.nasa.gov/science/toolbox/emspectrum1.html
https://www.miniphysics.com/electromagnetic-spectrum_25.html
https://slate.com/technology/2020/04/coronavirus-covid19-5g-conspiracy-theory.html
https://www.nature.com/articles/nature13290
https://www.icnirp.org/en/applications/power-lines/power-lines.html
https://www.theguardian.com/technology/2020/mar/12/5g-safe-radiation-watchdog-health
https://blogs.scientificamerican.com/observations/we-have-no-reason-to-believe-5g-is-safe/
https://blogs.scientificamerican.com/observations/dont-fall-prey-to-scaremongering-about-5g/
https://www.cancer.org/cancer/cancer-causes/radiation-exposure/radiofrequency-radiation.html
https://www.bbc.com/news/uk-england-52164358
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6765906/
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6820018/
https://www.ncbi.nlm.nih.gov/pubmed/29402696

