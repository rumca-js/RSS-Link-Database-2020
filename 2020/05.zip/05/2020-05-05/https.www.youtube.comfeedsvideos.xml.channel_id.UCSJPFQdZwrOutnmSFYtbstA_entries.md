# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Justice League - Anatomy of a Disaster (Part 2)
 - [https://www.youtube.com/watch?v=wPN5ZJD-YuQ](https://www.youtube.com/watch?v=wPN5ZJD-YuQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-05-06 00:00:00+00:00

Join me for Part 2 of my journey into the failure of Justice League, the biggest mistake in the DCEU so far.

