# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Chef Adam Perry Lang on the State of the Restaurant Industry During Coronavirus | Joe Rogan
 - [https://www.youtube.com/watch?v=QigoMlxhqMk](https://www.youtube.com/watch?v=QigoMlxhqMk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-05 00:00:00+00:00

Taken from JRE #1469 w/Adam Perry Lang:
https://youtu.be/EATOIfG2ISk

## Joe Rogan: We Can’t Sustain a Nation-Wide Quarantine
 - [https://www.youtube.com/watch?v=hSw8yszRtjg](https://www.youtube.com/watch?v=hSw8yszRtjg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-05 00:00:00+00:00

Taken from JRE #1469 w/Adam Perry Lange: https://youtu.be/EATOIfG2ISk

