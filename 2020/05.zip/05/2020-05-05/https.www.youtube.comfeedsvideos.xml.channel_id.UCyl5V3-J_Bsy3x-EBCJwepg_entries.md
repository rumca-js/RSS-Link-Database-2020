# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Real Moms Of The Babylon Bee
 - [https://www.youtube.com/watch?v=WXcf-1RpdoQ](https://www.youtube.com/watch?v=WXcf-1RpdoQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-05-06 00:00:00+00:00

Kyle and Ethan are joined by their moms on this special mother's day episode and The Babylon Bee videocast debut.

