# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## The Reason COVID-19 Is Our Perfect Enemy (and Why We’ll Beat It)
 - [https://www.youtube.com/watch?v=elWnURZpWCA](https://www.youtube.com/watch?v=elWnURZpWCA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2020-05-06 00:00:00+00:00

PBS Member Stations rely on viewers like you. To support your local station, go to: http://to.pbs.org/DonateOKAY
↓ More info and sources below ↓

We’re on PATREON! Join the community ►► https://www.patreon.com/itsokaytobesmart
SUBSCRIBE so you don’t miss a video! ►► http://bit.ly/iotbs_sub 

SARS-CoV-2 and COVID-19 are nasty enemies. Invisible, mysterious, and deadly, they have spread around the world and caused much of humanity to hide away. Germs like these only succeed and spread because of our social evolution, and our social nature is why social and physical distancing is so deeply painful for us. But evolution has also given us the gifts we need to survive this difficult time. 

Special thanks to our Brain Trust Patrons:
AlecZero
Diego Lombeida
Dustin
Ernesto Silva
George Gladding
Marcus Tuepker
Megan K Bradshaw
Peter Ehrnstrom
Ron Kakar
Vincbis

Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/

