# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## The surprising origin of Dippin' Dots
 - [https://www.cnn.com/videos/us/2020/05/04/great-big-story-dippin-dots-gbs.great-big-story](https://www.cnn.com/videos/us/2020/05/04/great-big-story-dippin-dots-gbs.great-big-story)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-05 23:56:31+00:00

Dippin' Dots—they're an amusement park, zoo, aquarium and overall summertime staple. The mini balls of ice cream that melt in your mouth are also a childhood favorite. But where did the "ice cream of the future" come from?

