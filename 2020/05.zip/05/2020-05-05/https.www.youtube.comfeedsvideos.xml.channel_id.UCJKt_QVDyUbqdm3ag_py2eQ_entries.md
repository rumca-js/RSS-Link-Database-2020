# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga Paula does XM: Awesome - Dreams of Hope (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=cKeRTvgOLqM](https://www.youtube.com/watch?v=cKeRTvgOLqM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-05-06 00:00:00+00:00

"Dreams of Hope" (1997) by Awesome/Wild Bits^Exelweiss^Inside (Victor Vergara Luján). Art "Heaven" by Fairfax/Pure Metal Coders, 6th at The Gathering 1992. This upload is intended for headphones only.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Normal mixing with 32244 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click disabled
- Module reports 32 channels
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.

## Amiga Paula does XM: Big Bear - Longing (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=N0G9zg6KO3Q](https://www.youtube.com/watch?v=N0G9zg6KO3Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-05-06 00:00:00+00:00

"Longing" (1998) by Big Bear/Level D^Fake That (Matthias Scheidegger). Art "Love Deluxe" (1995?) by Made/Scoopex^Bomb. This upload is intended for headphones only.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Normal mixing with 36192 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click disabled
- Module reports 32 channels
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.

## Amiga Paula does XM: Xhale - Small Red Grapes (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=UznkqUAp-E8](https://www.youtube.com/watch?v=UznkqUAp-E8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-05-06 00:00:00+00:00

"Small Red Grapes" (1999) by Xhale/Dual Crew & Shining^Theralite^Phrenetik^Nocturnal^KMY (Erik K. Skodvin). Art "Stopping Time" by Spiv/Infect^Unsure, 5th at Assembly 1993. This upload is intended for headphones only.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Normal mixing with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click disabled
- Module reports 24 channels
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.

## Amiga Paula does XM: Yehar - The East Wing Study (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=tmuvvwVrlFg](https://www.youtube.com/watch?v=tmuvvwVrlFg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-05-06 00:00:00+00:00

"The East Wing Study" by Yehar (Olli Niemitalo). Art "A statement about fire, flowers and technology" by Frost/Tulou, 3rd at Datastorm 2011. This upload is intended for headphones only.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Normal mixing with 48587 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- Module reports 14 channels
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.

