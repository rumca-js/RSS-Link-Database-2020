# Source:FRONTLINE PBS | Official, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ, language:en-US

## Pregnant in Prison – Tutwiler (full documentary) | FRONTLINE + The Marshall Project
 - [https://www.youtube.com/watch?v=rWv66yLetI4](https://www.youtube.com/watch?v=rWv66yLetI4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ
 - date published: 2020-05-06 00:00:00+00:00

What happens to women who are pregnant in prison, and to the babies born to them? A rare and intimate look at pregnancy and motherhood behind bars.

FRONTLINE and The Marshall Project go inside Alabama’s Julia Tutwiler Prison for Women in “Tutwiler” — an unforgettable window into the lives of pregnant women in prison, and what happens to their newborns. A documentary short from Academy Award-nominated filmmaker Elaine McMillion Sheldon.

U.S. television premiere on America ReFramed on WORLD Channel, 5/19/2020. 

Subscribe on YouTube: http://bit.ly/1BycsJW
 
#Tutwiler #PregnantInPrison #BabiesBornBehindBars
 
Instagram: https://www.instagram.com/frontlinepbs
Twitter: https://twitter.com/frontlinepbs
Facebook: https://www.facebook.com/frontline
 
FRONTLINE is streaming more than 200 documentaries online, for free, here: http://to.pbs.org/hxRvQP   
 
Funding for FRONTLINE is provided through the support of PBS viewers and by the Corporation for Public Broadcasting. Major funding for FRONTLINE is provided by the John D. and Catherine T. MacArthur Foundation and the Ford Foundation. Additional funding is provided by the Abrams Foundation, the Park Foundation, The John and Helen Glessner Family Trust, and the FRONTLINE Journalism Fund with major support from Jon and Jo Ann Hagler on behalf of the Jon L. Hagler Foundation.

