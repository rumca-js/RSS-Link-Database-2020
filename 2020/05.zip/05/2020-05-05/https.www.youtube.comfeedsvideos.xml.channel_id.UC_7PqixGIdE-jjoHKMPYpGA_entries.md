# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Ty i Twój mózg w izolacji
 - [https://www.youtube.com/watch?v=Ndq-NpCR_Rk](https://www.youtube.com/watch?v=Ndq-NpCR_Rk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2020-05-05 00:00:00+00:00

📚 MOJA KSIĄŻKA! Wejdź na https://geny.altenberg.pl i zamów swój „Przepis na człowieka”!

Patronite ► https://patronite.pl/NaukowyBelkot 
Mix audio ► http://ratstudios.pl/

Nie da się ukryć, że żyjemy w czasach, które są niezwykłe. Wymagają od nas niezwykłych rzeczy. I te niezwykłe rzeczy nie pozostają obojętne dla naszych ciał i umysłów. Coś tak, wydawałoby się, prozaicznego jak izolacja - także odciska na nas piętno. Potencjalnie duże.

Subskrypcja ► https://youtube.com/c/UwagaNaukowyBelkot
Facebook ► https://facebook.com/UwagaNaukowyBelkot
Twitter ► https://twitter.com/NaukowyBelkot
Instagram ► https://www.instagram.com/NaukowyBelkot/

Wyłącznie Naukowy Bełkot ► https://goo.gl/Do7VCc
Grupa na facebooku ► https://goo.gl/HP8J83

===
Źródła (wybrane):

M. Bianchi i in. - Isolation rearing induces recognition memory deficits accompanied by cytoskeletal alterations in rat hippocampus.

D. Dierendonck i in. - Flotation restricted environmental stimulation therapy (REST) as a stress-management tool: A meta-analysis.

L. M. Jaremka i in. - Loneliness Predicts Pain, Depression, and Fatigue: Understanding the Role of Immune Dysregulation

S. Santarossa i in. - Exploring the Role of In-Person Components for Online Health Behavior Change Interventions: Can a Digital Person-to-Person Component Suffice?

A. Stahn i in. - Brain Changes in Response to Long Antarctic Expeditions

E. Snow - Intimacy and Face-to-Face versus Computer Interaction

R. Hari i in. - Centrality of Social Interaction in Human Brain Function

O. Suillebhain i in. - Loneliness, Living Alone, and All-Cause Mortality: The Role of Emotional and Social Loneliness in the Elderly During 19 Years of Follow-Up

https://www.youtube.com/watch?v=n3Xv_g3g-mA

===
#zostańwdomu #izolacja #Ty

https://www.ageuk.org.uk/our-impact/policy-research/loneliness-research-and-resources/loneliness-depression-and-anxiety-exploring-the-connection-to-mental-health/

http://www.sciencedaily.com/releases/2009/02/090215151800.htm

https://www.smithsonianmag.com/science-nature/science-solitary-confinement-180949793/
https://newatlas.com/science/neuroscience-social-isolation-loneliness-antarctica-brain/

===
Timestamp:

0:00 Wstęp
2:10 Samotność a izolacja
3:26 Mózg sam
7:50 Psychika sama
9:25 Ciało samo
12:27 Wersja po bandzie
15:05 Substytuty?

