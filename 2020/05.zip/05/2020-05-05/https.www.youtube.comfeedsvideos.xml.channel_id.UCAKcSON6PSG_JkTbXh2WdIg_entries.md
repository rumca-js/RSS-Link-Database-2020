# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Beat the final boss for an encore? Look for more concerts in video games (The Current Music News)
 - [https://www.youtube.com/watch?v=8XHhmYS9gW8](https://www.youtube.com/watch?v=8XHhmYS9gW8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-06 00:00:00+00:00

May 6, 2020: After the wild success of Travis Scott's Fortnite concert, get ready for more stars to play virtual shows in multi-player video games. Meanwhile, Arkansas is preparing to host a socially distanced concert IRL, while fans staying in quarantine will be able to watch documentaries about Wilco and the Beastie Boys. Plus, Mick Jagger shows off his shelter-in-place recreation for charity.
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Drive-By Truckers - Live Virtual Session for The Current
 - [https://www.youtube.com/watch?v=pZogRtYjp_w](https://www.youtube.com/watch?v=pZogRtYjp_w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-06 00:00:00+00:00

Mike Cooley and Patterson Hood of Drive-By Truckers connect with The Current's Bill DeVille to swap tunes and share stories.
Songs Performed:
05:58 “21st Century USA”  (Hood)
10:09 “Grievance Merchants” (Cooley)
22:46 “Quarantine Together” (Hood)
25:33 “Eyes Like Glue” (Cooley)

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/
https://www.facebook.com/RadioHeartlandMPR/
https://twitter.com/RadioHeartland

## Kraftwerk co-founder Florian Schneider dies at 73 (The Current Music News)
 - [https://www.youtube.com/watch?v=gu2Jk7Rehq4](https://www.youtube.com/watch?v=gu2Jk7Rehq4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-06 00:00:00+00:00

May 6, 2020: Florian Schneider was a co-founder of Kraftwerk, the seminal electronic German rock band that helped infuse a sleek electronic sound into music of the '70s and '80s, performing live up through recent years in groundbreaking immersive audiovisual spectaculars that blended men and machine.
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Stranglers keyboardist Dave Greenfield dies of COVID-19 (The Current Music News)
 - [https://www.youtube.com/watch?v=EdgZ7X4jHF4](https://www.youtube.com/watch?v=EdgZ7X4jHF4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-05 00:00:00+00:00

May 5, 2020: Dave Greenfield, keyboardist in the Stranglers, has died of coronavirus at age 71. Also, catalog albums by artists like Fleetwood Mac and Mariah Carey are bumping back up the chart; a new baby for Grimes; a Prince guitar and other rock memorabilia go up for auction; and a little kid in pajamas may have written the song of the summer.
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

