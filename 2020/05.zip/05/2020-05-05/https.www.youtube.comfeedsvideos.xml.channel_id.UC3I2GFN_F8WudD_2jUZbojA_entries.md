# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Kelly Lee Owens - 8 (Live on KEXP)
 - [https://www.youtube.com/watch?v=CICb936US84](https://www.youtube.com/watch?v=CICb936US84)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-06 00:00:00+00:00

http://KEXP.ORG presents Kelly Lee Owens performing "8" live in the KEXP studio. Recorded July 20, 2018.

Host: Cheryl Waters
Audio Engineers: Peter Smith & Kevin Suggs
Audio Mixer: Peter Smith
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
https://www.kellyleeowens.com

## Kelly Lee Owens - Anxi. (feat. Jenny Hval) (Live on KEXP)
 - [https://www.youtube.com/watch?v=peyXmk6_D04](https://www.youtube.com/watch?v=peyXmk6_D04)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-06 00:00:00+00:00

http://KEXP.ORG presents Kelly Lee Owens performing "Anxi. (feat. Jenny Hval)" live in the KEXP studio. Recorded July 20, 2018.

Host: Cheryl Waters
Audio Engineers: Peter Smith & Kevin Suggs
Audio Mixer: Peter Smith
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
https://www.kellyleeowens.com

## Kelly Lee Owens - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=Oskqru6HKUo](https://www.youtube.com/watch?v=Oskqru6HKUo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-06 00:00:00+00:00

http://KEXP.ORG presents Kelly Lee Owens performing live in the KEXP studio. Recorded July 20, 2018.

Songs:
8
S.O.
Lucid
Anxi. (feat. Jenny Hval)

Host: Cheryl Waters
Audio Engineers: Peter Smith & Kevin Suggs
Audio Mixer: Peter Smith
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
https://www.kellyleeowens.com

## Kelly Lee Owens - Lucid (Live on KEXP)
 - [https://www.youtube.com/watch?v=x7H6TpwbrrU](https://www.youtube.com/watch?v=x7H6TpwbrrU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-06 00:00:00+00:00

http://KEXP.ORG presents Kelly Lee Owens performing "Lucid" live in the KEXP studio. Recorded July 20, 2018.

Host: Cheryl Waters
Audio Engineers: Peter Smith & Kevin Suggs
Audio Mixer: Peter Smith
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
https://www.kellyleeowens.com

## Kelly Lee Owens - S.O. (Live on KEXP)
 - [https://www.youtube.com/watch?v=Ssgx48IGI2U](https://www.youtube.com/watch?v=Ssgx48IGI2U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-06 00:00:00+00:00

http://KEXP.ORG presents Kelly Lee Owens performing "S.O." live in the KEXP studio. Recorded July 20, 2018.

Host: Cheryl Waters
Audio Engineers: Peter Smith & Kevin Suggs
Audio Mixer: Peter Smith
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
https://www.kellyleeowens.com

## Christine & The Queens (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=3bavZe47um4](https://www.youtube.com/watch?v=3bavZe47um4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-05 00:00:00+00:00

Chris, aka Christine & The Queens, performs an exclusive set from home and joins Morgan, live on KEXP on Tuesday, May 5, at 12pm PT.

