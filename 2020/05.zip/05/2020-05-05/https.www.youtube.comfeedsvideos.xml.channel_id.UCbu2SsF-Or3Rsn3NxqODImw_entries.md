# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Apex Legends Season 5 Loba Launch Trailer, Explained
 - [https://www.youtube.com/watch?v=I0hCY0Pyj6I](https://www.youtube.com/watch?v=I0hCY0Pyj6I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-06 00:00:00+00:00

Apex Legends Season 5: Fortune's Favor starts May 12, but the latest trailer told us a lot about what Loba has been up to and what's to come. 

Apex Legends' Season 5 trailer is out now, and it's full of details about the new legend, Loba. While her abilities are still unconfirmed at this point, we can see her thieving skills in action in the trailer as she hunts down Revenant. Tony breaks down what this means for the battle royale in the video above.

Season 5: Fortune's Favor will launch on PS4, Xbox One, and PC on May 12. Like the previous season, it will split ranked mode into two series, starting with Kings Canyon before moving to World's Edge. A new Quests mode will also be added.

#ApexLegends #Loba #GameSpot

## Cyberpunk 2077 Event Announced, Halo 2 Anniversary PC Release Date | Save State
 - [https://www.youtube.com/watch?v=fhjVY_SD_Sc](https://www.youtube.com/watch?v=fhjVY_SD_Sc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-06 00:00:00+00:00

CD Projekt Red teased a Cyberpunk 2077 event called Night City Wire, Halo 2 Anniversary is coming to the PC Master Chief Collection, and The Last of Us Part 2 is getting a new trailer this week.

Chastity brings you all the biggest gaming stories for your May 5 Save State. CD Projekt Red teased that an event for Cyberpunk 2077 called Night City Wire is happening in June. Microsoft has a new series called Xbox 20/20 which will air monthly, and it sounds like each episode will be in the style of Nintendo Directs. The first Xbox 20/20 stream is on May 7, where we'll get our first look at Assassin's Creed Valhalla gameplay. 

Speaking of Xbox, the Series X boot screen and sound may have been revealed. In Halo news, Halo 2: Anniversary is coming to the PC version of the Master Chief Collection this month. And finally, The Last of Us Part 2 is getting a new trailer on Wednesday. For all the latest gaming news stories, be sure to get your Save State every Monday through Thursday on GameSpot.

Watch Chastity host our TV & Movies Podcast, You Should Be Watching: https://www.youtube.com/playlist?list=PL3nb0Cg7lKSDtZQt-T2mX-5sAnqcE1pUV

#SaveState #GameSpot

## Mortal Kombat 11 - Official Aftermath Story And Character DLC Trailer
 - [https://www.youtube.com/watch?v=qRaPzRqW5tg](https://www.youtube.com/watch?v=qRaPzRqW5tg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-06 00:00:00+00:00

Mortal Kombat 11 is getting a ton of new content very soon! New stages, characters, friendships and even stage fatalities accompany a brand new story chapter! Check it all out in this new trailer!

Mortal Kombat11: Aftermath expands the critically acclaimed story campaign with an all-new, cinematic narrative centered around trust and deceit, while also adding new playable characters, Fujin, Sheeva, and guys character, RoboCop, who is making his series debut.

#MK11 #MortalKombat11 #Aftermath

## Mortal Kombat 11 Aftermath DLC: Everything You Need To Know In Under 3 Minutes
 - [https://www.youtube.com/watch?v=gk_QsRYN-yY](https://www.youtube.com/watch?v=gk_QsRYN-yY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-06 00:00:00+00:00

For the first time in the series' history, Mortal Kombat 11 is getting a story expansion. Aftermath adds new story content, playable characters, and more.

Aftermath picks up where Mortal Kombat 11 ends, with Liu Kang as the new keeper of time. He aims to create a new timeline, leading him on a quest that will bring back some familiar faces. Wind god Fujin and four-armed half-dragon Sheeva are joining the roster, and they're accompanied by a surprising fresh face: Robocop. 

Aftermath comes to PS4, Xbox One, PC, Nintendo Switch, and Google Stadia on May 26. The same day, a new update for all Mortal Kombat 11 players will add new stages, stage fatalities, and Friendships. The video above details these additions and more.

#MK11 #MortalKombat11 #Aftermath

## Mortal Kombat 11: Aftermath - Official Cinematic Teaser
 - [https://www.youtube.com/watch?v=wpO0USmFv5g](https://www.youtube.com/watch?v=wpO0USmFv5g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-06 00:00:00+00:00

Mortal Kombat11: Aftermath expands the critically acclaimed story campaign with an all-new, cinematic narrative centered around trust and deceit, while also adding new playable characters, Fujin, Sheeva, and guys character, RoboCop, who is making his series debut. Check out a sneak peek of one of Aftermath's cutscenes...

Mortal Kombat 11: Aftermath releases May 26, 2020!
#MK11 #MortalKombat11 #Aftermath

## The Last of Us Part 2 - Official Story Trailer
 - [https://www.youtube.com/watch?v=Ig0mNpvBz28](https://www.youtube.com/watch?v=Ig0mNpvBz28)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-06 00:00:00+00:00

Watch the all-new story trailer for The Last of Us Part II launching on 19th June 2020. After a vicious and violent event disrupts the relative peace that Ellie has found in Jackson, she sets out to bring justice to those responsible. As she hunts them down one by one, she is confronted with the devastating physical and emotional repercussions of her actions.

#TheLastOfUs2 #TLOU2

## Apex Legends: Season 5 – Official Fortune's Favor Launch Trailer
 - [https://www.youtube.com/watch?v=tvKhX-73c4Y](https://www.youtube.com/watch?v=tvKhX-73c4Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-05 00:00:00+00:00

When she was nine years old, Loba Andrade witnessed her parents’ murders at the hands of the simulacrum Revenant. Orphaned and tossed into the system, Loba fought tooth and nail to overcome the adversity of her childhood. She grew up to become a famous high society socialite by day, and the Outlands’ most infamous thief by night. Now, her parents’ seemingly immortal killer has re-emerged, and she’s tracked him to the Apex Games. She’s looking for answers, treasure, and a way to take the one thing that’s always been out of her reach: revenge. 
 
Apex Legends™ is a free-to-play battle royale game where legendary characters battle for glory, fame, and fortune on the fringes of the Frontier. Play for free now on Xbox One, PS4, and Origin for PC.

## Doom Eternal Drama, No Halo Infinite Gameplay At Inside Xbox | Save State
 - [https://www.youtube.com/watch?v=K9BSEJBIQ5c](https://www.youtube.com/watch?v=K9BSEJBIQ5c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-05 00:00:00+00:00

Id Software's Marty Stratton weighs in on the Doom Eternal soundtrack drama, there'll be no Halo Infinite gameplay on this week's Inside Xbox, and EA announced its 2020 EA Play dates.

#SaveState #GameSpot

## Mortal Kombat 11 - The Epic Saga Continues Teaser Trailer
 - [https://www.youtube.com/watch?v=oGY7GyiTP40](https://www.youtube.com/watch?v=oGY7GyiTP40)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-05 00:00:00+00:00

The epic saga continues. Full reveal coming May 6.

