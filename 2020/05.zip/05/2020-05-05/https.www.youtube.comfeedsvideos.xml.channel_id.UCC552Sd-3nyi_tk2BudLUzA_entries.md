# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## The Teeth Song (Learn in 3 minutes!) | SCIENCE SONGS
 - [https://www.youtube.com/watch?v=PI3hne8C8rU](https://www.youtube.com/watch?v=PI3hne8C8rU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2020-05-06 00:00:00+00:00

A brush your teeth song with science to help you memorize every tooth!
The END OF THE UNIVERSE Song: https://youtu.be/o6UPfdhOHIY
This video is sponsored by Sensodyne. Take control of tooth sensitivity and improve gum health with Sensodyne Sensitivity & Gum https://www.sensodyne.com/en-us/

MORE AsapSCIENCE Songs: https://www.youtube.com/watch?v=LTXTeAt2mpg&list=PLvFsG9gYFxY9zTBhcFmMcYa3zYfQz7P7F

Created by: Mitchell Moffit and Gregory Brown

FOLLOW US! 
AsapINSTAGRAM: https://instagram.com/asapscience/
Facebook: http://facebook.com/AsapSCIENCE
Twitter: http://twitter.com/AsapSCIENCE
TikTok @asapsciguys 

Sensodyne:
Youtube: https://www.youtube.com/user/SensodyneUS  
Twitter: https://twitter.com/Sensodyne_US  
 Facebook: https://www.facebook.com/SensodyneUS/

LYRICS----

CHORUS
Teeth! They’re neat
Calcified tools to eat
Crown and root
In sections they are grouped
Incisors, chop and then cut for you
Canines stab and rip too,
Bicuspids crush the food,
Molars grind 

Upper maxilla
The lower mandible
A full set counts to 32


VERSE
Enamel, the hardest substance in your body
Making up the crown
Dentin underneath, supporting structure
Further down
Cementum now
Connecting ligaments and covering the root for more stability
The pulp is here
Blood vessels cheer
Periodontium tissue
Gingiva or gum act like glue
All combined for you to masticate

As omnivores our diet is mixed
Eat organisms, get our fix
It’s what makes us heterotrophs
So our teeth are made multipurpose

CHORUS REPEATS

VERSE 2
Brushing teeth, prevents cavities 
Breaking plaque formation
Fluoride helps to build enamel
Through the process of remineralization

Mammals are diphyodont
Two sets of teeth are designed
From primary or baby
To permanent for your life
So brush your teeth (Keep them clean)
Floss regularly (In between)
And they’ll stay healthy now if you just keep
A regular routine

ALT CHORUS
Teeth, are great
To empty up your plate
But unchecked
Things can become a mess

BRIDGE
If you do not clean your teeth
Bacteria will increase
Creating plaque and acid
Tooth decay can be rapid
Demineralization
And some painful sensations
Exposing nerves in dentin
While toxins start infecting
Inflaming up gum disease
And tooth sensitivity 

Without good oral hygiene
Bacteria reigns supreme
This is why we brush our teeth twice a day
To keep gingivitis and diseases all at bay
For our

CHORUS
Teeth! They’re neat
Calcified tools to eat
Crown and root
Let’s name those groups!

FINALE
First, we have central and lateral incisors
The canines are the longest to consider
Transitional first and second premolars
Also called bicuspids by the scholars
The first and second molars at the back grind
And if you’re clever you will find a third kind
Wisdom teeth

