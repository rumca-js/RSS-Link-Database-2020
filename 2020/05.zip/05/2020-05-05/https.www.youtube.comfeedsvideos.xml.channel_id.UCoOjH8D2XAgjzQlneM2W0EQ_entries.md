# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## The Diamond Cartel: History's Greatest Monopoly
 - [https://www.youtube.com/watch?v=V5rQlXibKgg](https://www.youtube.com/watch?v=V5rQlXibKgg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2020-05-06 00:00:00+00:00

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join 

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
📸 Follow me on IG:@jaketran // http://bit.ly/jt-ig
👨👦👦 Join the Tran Mafia Family here: https://bit.ly/patreon-jt
💬 Join the community Discord: http://discord.gg/BmK8EnQ

Stuff I use & recommend:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
🏠 The real estate investing course I love & recommend: https://jake.yt/RE
🌐 Most flexible, affordable website hosting: https://jake.yt/bhd
🖥️ Website platform I use & love: https://jake.yt/kd
💽 Editing software I've used for 7+ years: https://jake.yt/ccd
📒 Online bookkeeping software I use& love: https://jake.yt/benchd 
🧾 Best affordable bookkeeping software: https://jake.yt/fbd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd
📚 Get 3 free audiobooks for life: https://amzn.to/2v58PSu
🎥 My video gear, setup, tech, books: https://jake.yt/stored

✉️ Email me: jake@jaketran.io

Subscribe to the backup channel on LBRY, use reward code "jake-cast" for free coin: https://bit.ly/LBRY-jt

📰 Sources & visuals: https://bit.ly/3b3JdVj

-----------------------
The truth about diamonds
You’re Ernest Oppenhiemer in the jewelry business, and you have a monopoly over all the diamond mines in South Africa, the biggest diamond producer
De Beers was on top of the world
Diamonds make for great jewelry that the world is willing to top dollar for, they have industrial uses that no other materials can really replace, and you control the main area in the world where 90% diamonds are coming from
Everyone thought that diamonds are pretty rare, making them very valuable much like how gold is valuable
It’s becoming more apparent that diamonds aren’t really as rare as we thought
The economics of diamonds are looking pretty bleak, but you’re a very clever businessman so you’re not willing to quit
Shift your business from digging as many diamonds out of the ground as possible, to doing everything in your power to control how many diamonds come out of the ground
Turn your modest diamond operation into the most successful monopoly cartel the world has ever seen in the blood diamond trade

A cartel is a group of companies coming together to fix the price of a product so that the all cartel members get their fair share of the profits
Like how major oil countries come together as the cartel OPEC, to fix the price of crude oil, except with a diamond cartel
Once these locals catch on to how profitable the diamond trade is, they’ll started trading diamonds and smuggling it - do whatever is necessary to crush them

Now that you have the start of the supply chain under your grip, it’s time for  the merchants
Since you control 90% of the world’s diamond output, merchants who want to buy raw diamonds can really only go to you
You can’t legally operate in the US, so set up shop in London where you’ll distribute raw diamonds to merchants
It’s the 1930’s, you’re making more money than ever but the people in you’re biggest market, the US, don’t really care about diamonds and your sales were pretty small
But jewelery is just that, a “nice-to-have,” a luxury that only people with extra money can afford
You need diamonds to symbolize something so evergreen that no matter how the economy was doing, no matter how rich or poor a person was, people would always need diamonds

-----------------------

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2020 Jake Tran. All rights reserved.

Sound:
dné - End Credits https://soundcloud.com/dnednedne 
idealism - falling asleep at 3:37 am (ft. Alex Szotak) https://soundcloud.com/idealismus/
Kupla - Always Miss You https://open.spotify.com/album/765gc1DpB9bZU1yjrIaO5T?si=IVCnVwlvRdWdr0GB7ZGwtw 

Music by Chillhop: http://chillhop.com/listen
Listen on Spotify: http://bit.ly/ChillhopSpotify

DISCLAIMER: These videos are for entertainment purposes only. This is not meant to be financial advice. Please always do your due diligence and never stop learning.

AFFILIATE DISCLOSURE: Some of the links in this video description are affiliate links, meaning, at no additional cost to you, I may earn a commission if you click through and make a purchase and/or opt-in. I only promote products that I 100% believe in.

