# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## HTC Phones - From Biggest Smartphone Maker to Nothing!
 - [https://www.youtube.com/watch?v=5md3d2hDKdM](https://www.youtube.com/watch?v=5md3d2hDKdM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2020-05-05 00:00:00+00:00

HTC was an absoloutly influenial smartphone brand, but over the years, they've gone from number one to zero. What exactly happened? In this video we explore the story.
 --- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. 

iPhone Creation Video: https://youtu.be/24O00Jz8R04

Blackberry Video: https://youtu.be/iYTos-1FfnM

iOS/ Android History: https://youtu.be/0YApLJWmRDM

If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- New Thinking Book written by Dagogo Altraide ---
Learn the stories of those who invented the things we use everyday.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

--- ColdFusion Social Media ---
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusionTV

--- ColdFusion Podcast links ---
Google Podcasts - http://bit.ly/2xo8doR
Apple Podcasts - https://apple.co/2WI2IeU
Spotify - https://spoti.fi/2KT1taB
Stitcher - http://bit.ly/2WI4f4E

Sources:

https://www.theunwired.net/?item=videoview-htc-touchflo-3d-user-interface-for-windows-mobile-professional

https://www.digitaltrends.com/mobile/the-decline-and-fall-of-htc/

https://www.fastcompany.com/3017928/31htc

https://www.bbc.com/news/business-34172323

https://en.wikipedia.org/wiki/HTC

https://www.htc.com/us/about/

https://www.theverge.com/2015/3/20/8262339/htc-ceo-cher-wang-change

https://www.theverge.com/2016/6/22/11999806/former-htc-ceo-peter-chou-has-left-the-company

https://www.theunwired.net/?item=videoview-htc-touchflo-3d-user-interface-for-windows-mobile-professional

https://www.phoneyear.com/htc-rise-and-fall-of-a-titan/

https://en.wikipedia.org/wiki/Cher_Wang

https://en.wikipedia.org/wiki/First_International_Computer


//Soundtrack//

Sublab - So in Love

Sergey Alekseev - Sunet on Sea

Croquet Club – Only You Can Tell (Original Mix)

Blue States - Vision Trail

Personal Best (Keith Sweaty Remix)

DJ Seinfeld - U

Montell Fish - Jam Session 

Nova Nova - Tones

Japanese Wallpaper - Arrival

Burn Water - Does it Get Easier?

» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide

