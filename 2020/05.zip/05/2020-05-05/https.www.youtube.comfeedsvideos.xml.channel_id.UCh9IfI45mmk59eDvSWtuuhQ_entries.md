# Source:Ryan George, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ, language:en-US

## We Live In The Dumbest Timeline
 - [https://www.youtube.com/watch?v=9nfbeK5LAl0](https://www.youtube.com/watch?v=9nfbeK5LAl0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ
 - date published: 2020-05-06 00:00:00+00:00

Subscribe for more videos!
Twitter/Instagram: @TheRyanGeorge

Maybe it's the darkest timeline? Maybe it's the dumbest? Who knows! One thing is for sure though-- we should all avoid speaking moistly.

To be clear-- there's obviously a lot more to this situation than everybody just staying home, and I'm clearly poking fun at those who are out protesting with "me wanty haircut" signs and crowding beaches.

Also some people seem to think that I had someone else cough on me at 2:58. Don't worry-- that's also me, but with glasses and some video editing.

I've made a donation to Food Banks Canada and if you're fortunate enough to be in a position to donate as well, it's very fun to do. These sites have super neat buttons to click on:
Food Banks Canada: https://www.foodbankscanada.ca/Make-A-Donation.aspx
Feeding America: https://www.feedingamerica.org/find-your-local-foodbank
Global Foodbanking Network: https://www.foodbanking.org/take-action/donate/

Special shout-out to my girlfriend for learning to cut my hair for this video!

