# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## The 3 Types Of Meditation Explained! | Russell Brand Podcast
 - [https://www.youtube.com/watch?v=WBrmjWS98Gs](https://www.youtube.com/watch?v=WBrmjWS98Gs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-05-06 00:00:00+00:00

A clip from #UnderTheSkin with CEO of The David Lynch Foundation Bob Roth! You can listen to this entire podcast from Sat 9th May on Luminary: http://luminary.link/russell 
#Meditation

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

