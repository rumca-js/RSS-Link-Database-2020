# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Broken Arrow - Movie Review
 - [https://www.youtube.com/watch?v=1SmqEbn4-Ak](https://www.youtube.com/watch?v=1SmqEbn4-Ak)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-05-02 00:00:00+00:00

Another 90's action movie where the villain steals the show. Let's talk about BROKEN ARROW!

