# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Fullmetal Alchemist: Brotherhood - REVIEW
 - [https://www.youtube.com/watch?v=H1B1drKq1wI](https://www.youtube.com/watch?v=H1B1drKq1wI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-05-02 00:00:00+00:00

My review of Fullmetal Alchemist: Brotherhood!
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## Butcher Talks w/ Rothfuss💬 Elder Scrolls Leaks?🛡️ Sword Of Kaigen Wins!🏆 - FANTASY NEWS
 - [https://www.youtube.com/watch?v=Ktg0CfiOohQ](https://www.youtube.com/watch?v=Ktg0CfiOohQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-05-01 00:00:00+00:00

It is news that is fantasy-related. What more could you want?? 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

NEWS: 

#Rothfuss Butcher Talk: https://www.instagram.com/p/B_nVwZODRul/?igshid=1oqdxiv1am9fb

#SPUMC: https://twitter.com/culturecrave/status/1256023300477612033?s=12

New Dr. Who: https://io9.gizmodo.com/tom-baker-and-louise-jameson-recorded-a-brand-new-docto-1843160940?utm_campaign=io9&utm_content=1588194402&utm_medium=SocialMarketing&utm_source=facebook

Sword of Kaigen #SPFBO: https://twitter.com/PetrikReads/status/1255790259360563201

Live Action Hercules: https://thedisinsider.com/2020/04/29/exclusive-disney-developing-live-action-hercules-film-with-some-possible-big-name-directors-in-the-mix/

George R. R. Martin Edited Book: https://www.wildcardsworld.com/book/wild-cards-xxvii-texas-holdum/

Dual: https://deadline.com/2020/04/karen-gillan-aaron-paul-jesse-eisenberg-riley-stearns-dual-1202919941/

Absolutely Faithful Adaptation of Terry Pratchett: https://www.theguardian.com/books/2020/apr/28/terry-pratchett-novels-faithful-tv-adaptation-discworld

#RiseOfSkywalker on Disney Plus: https://variety.com/2020/digital/news/star-wars-rise-of-skywalker-streaming-disney-plus-1234590532/

Elder Scrolls Leaks: https://www.youtube.com/watch?v=kM7B_xsOpzE&feature=youtu.be

Dr. Who Time Lord Victorious: https://www.doctorwho.tv/news/?article=time-lord-victorious#_

Dresden Files Card Game: https://www.youtube.com/watch?v=N1vnkrVIgwo

Anime Auction: https://screenrant.com/dragon-ball-studio-ghibli-pokemon-art-auction/

SheRa Trailer: https://ew.com/tv/she-ra-netflix-final-season-trailer/?utm_term=F42E2432-8AFB-11EA-B24A-FC0E933C408C&utm_campaign=entertainmentweekly_ew&utm_content=link&utm_source=twitter.com&utm_medium=social&__twitter_impression=true&__twitter_impression=true

Avatar 2 Photo: https://www.slashfilm.com/avatar-2-set-photo-sigourney-weaver/

