# Source:KnowledgeHusk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw, language:en-US

## Roblox: A Video About Roblox
 - [https://www.youtube.com/watch?v=B18vu43ndZw](https://www.youtube.com/watch?v=B18vu43ndZw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw
 - date published: 2020-05-01 00:00:00+00:00

Sometimes media is a bastion of light, a pool of knowledge that can be tapped at will. For who heeds the call to action? Ney but a few can suffice, as the tired grow weary, the weary grow spiteful, and the bodies of the fallen transform into blocks.

Creation of art, destruction of worlds. Pain, suffering, what does it mean?

Maybe we don’t have all the answers, but that’s just because we haven’t looked closely enough.

Roblox isn’t just a game. It’s a lifestyle.

Twitter: https://twitter.com/KnowledgeHubTy
Soundcloud: https://soundcloud.com/user-503704039
Patreon: https://www.patreon.com/theknowledgehub
Second Channel: https://www.youtube.com/channel/UC-KL04Ra6E1Du0pFawN4pWg
Spotify: https://open.spotify.com/artist/3STpelEilrthF8UxsQTaaw?si=52TH_ZKTQhaKhfnK1Jomfg


Some Footage Credits:
calculatorti
Valientlink
DeletedTubev 
Treegaming
Andrew Louis
Andrew Louis
Vilnis Tukums
dosdaysareover

