# Source:Mandalore Gaming, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw, language:en-US

## Total War Warhammer 2 Review
 - [https://www.youtube.com/watch?v=WA_iXKhoujA](https://www.youtube.com/watch?v=WA_iXKhoujA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw
 - date published: 2020-05-02 00:00:00+00:00

Total War Warhammer 2 is a game I've played far too much of in my free time. Now with nothing but free time, it's time to be productive about it.
Support the channel at: https://www.patreon.com/mandaloregaming or https://www.paypal.me/MandaloreGaming
I take video suggestions at mandaloremovies@gmail.com
Twitter: https://twitter.com/Lord_Mandalore
#TotalWar #TotalWarWarhammer #TotalWarWarhammerReview #TotalWarWarhammer2 #Warhammer

0:00 - Intro
00:46 - Warhammer Fantasy Overview
5:31 - Visuals
10:55 - Music & Sound Design
17:10 - The Empire and the Basics
21:42 - The DLC Policy
25:51 - Empire Continued
26:20 - Vampire Counts 
32:08 - Warhammer Diplomacy 
33:35 - Vampire Counts Continued 
34:05 - Dwarfs 
36:14 - The Siege Problem 
41:33 - Dwarfs Continued
42:50 - Greenskins 
45:28 - Bretonnia 
48:35 - Chaos 
53:14 - Beastmen
53:18 - Wood Elves 
53:22 - Fine, Beastmen 
54:58 - Back to Wood Elves  
58:01 - Norsca
1:00:48 - Warhammer 2 Campaign Overview  
1:02:53 - High Elves 
1:05:13 - Dark Elves  
1:08:52 - Lizardmen  
1:12:52 - Skaven  
1:15:08 - Tomb Kings
1:15:58 - Vampire Coast 
1:17:07 - Multiplayer and Conclusions 
1:18:00 - Credits
1:20:05 - The Dial Puzzle

