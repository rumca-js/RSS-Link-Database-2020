# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## Apple and Google contact tracing is a dystopian nightmare
 - [https://www.youtube.com/watch?v=WRalTWAFBY4](https://www.youtube.com/watch?v=WRalTWAFBY4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2020-05-01 00:00:00+00:00

Apple and Google are developing contact tracing mass surveillance system based on Bluetooth Low Energy that is being rolled out as forced updates into users phones without their consent. Let's talk about this!

Support me through Patreon: https://www.patreon.com/thehatedone 

- or donate anonymously:

Monero: 84DYxU8rPzQ88SxQqBF6VBNfPU9c5sjDXfTC1wXkgzWJfVMQ9zjAULL6rd11ASRGpxD1w6jQrMtqAGkkqiid5ef7QDroTPp

Bitcoin: 1HkDxXAVDFhBHSyRjam5WW5uoY88sxn5qz



Apple and Google, the global duopoly of mobile operating systems,
are building a mass surveillance system that will be remotely
introduced into every connected iPhone and Android device in the
world. The aim is to help “government health authorities” and “a
broader ecosystem of apps” trace contacts of infected people.

Sources are listed in the pinned comment of this video to avoid potential demonetization and shadowbanning


Credits
Music by: CO.AG Music https://www.youtube.com/channel/UCcavSftXHgxLBWwLDm_bNvA



 Follow me:
https://twitter.com/The_HatedOne_
https://www.bitchute.com/TheHatedOne/
https://www.reddit.com/r/thehatedone/
https://www.minds.com/The_HatedOne

The footage and images featured in the video were for critical analysis, commentary and parody, which are protected under the Fair Use laws of the United States Copyright act of 1976.

