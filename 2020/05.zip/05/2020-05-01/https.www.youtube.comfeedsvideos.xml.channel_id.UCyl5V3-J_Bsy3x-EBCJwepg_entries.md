# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Cucumber For Christ: The Mike Nawrocki Interview
 - [https://www.youtube.com/watch?v=OSb8NG7V9Cw](https://www.youtube.com/watch?v=OSb8NG7V9Cw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-05-01 00:00:00+00:00

This is The Babylon Bee Interview Show.

 Editor-in-chief Kyle Mann and creative director Ethan Nicolle talk to Larry the Cucumber voice and VeggieTales co-creator and Mike Nawrocki! Mike is a director, producer, writer, voice actor, animator, musician, puppeteer, and assistant professor of Film and Animation at Lipscomb University in Nashville, TN. Kyle, Ethan, and Mike give you the Babylon Bee exclusive behind-the-scenes look into the world of VeggieTales!

 Mike is also the author of a series of children’s books called  The Dead Sea Squirrels—out now!

 You can find more from Mike Nawrocki at Facebook and Instagram.

  Pre-order the new Babylon Bee Best-Of Coffee Table Book coming in 2020! Get a Sneak Peak!

 If you are hurting financially right now, check out our $100,000 COVID relief fund set up by Seth Dillon which you can find out more about by contacting us at our website. If you need financial help contact us! Also donate if you are able to chip in to help!

 Topics Discussed

   How the original VeggieTales became a huge sensation

   How Ethan ruined VeggieTales with In The House

   Kyle and Ethan give Mike free creative advise and character ideas

   Mike's new books The Dead Sea Squirrels

   Subscriber Portion (Begins at 00:42:37)

   Does he have any thoughts on  Phil Vischer’s comments where he regrets aspects of VeggieTales?

   Bacon Bill and MeatyTales

   We get Larry the Cucumber to read some Bible verses you've never heard him read before!

   The entire interview is available for Babylon Bee subscribers only…

 Become a paid subscriber at https://babylonbee.com/plans

