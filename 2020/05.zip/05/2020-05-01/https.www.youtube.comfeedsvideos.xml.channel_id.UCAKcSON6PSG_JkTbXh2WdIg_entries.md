# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Slowdive - Full performance (Live at The Current, 2017)
 - [https://www.youtube.com/watch?v=gliBbiCIFtM](https://www.youtube.com/watch?v=gliBbiCIFtM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-02 00:00:00+00:00

There's something to be said for lifelong friendships. Rachel Goswell and Neil Halstead of the band Slowdive have known one another since their first days of primary school. Together with a group of friends in their hometown of Reading, England, they assembled the band Slowdive in 1989.

Following the release of their 1995 album Pygmalion, the members of Slowdive went on a bit of a break … that lasted 20 years. But because they had been friends for so long, a reunion felt natural. "We made a decision to get back together and do a record, and it just felt like everyone was really keen and excited to do that, so I guess it was pretty easy," Halstead says. "It was weird; as soon as we started rehearsing again, it really felt like it was the same gang. We kind of fell into our respective modes of band behavior. Everyone fell into their spot within the group. We hadn't spent a lot of time together as a group over the past 20 years, so it was so interesting to see those patterns of behavior fall in again."

On May 5, 2017, Slowdive released a new, self-titled album ("We hadn't done a record in so long, it seemed like the obvious but right choice," Halstead says). 

SONGS PERFORMED
00:00 "Sugar For The Pill"
04:27 "Souvlaki Space Station"
09:50 "Star Roving"

The first and third songs are from Slowdive's 2017 self-titled album, available on Dead Oceans; the second song is from Slowdive's 1993 release, Souvlaki, on Creation Records.

PERSONNEL
Rachel Goswell
Neil Halstead
Christian Savill
Nick Chaplin
Simon Scott

MORE FROM THIS SESSION
Star Roving https://www.youtube.com/watch?v=nukZQTFsA10
Sugar for the Pill https://youtu.be/EskZhEUtlb8
Souvlaki Space Station https://youtu.be/oMAJ7RsuYUs
Full Session https://youtu.be/gliBbiCIFtM

#shoegaze #dreampop #indierock

## Slowdive - Souvlaki Space Station (Live at The Current, 2017)
 - [https://www.youtube.com/watch?v=oMAJ7RsuYUs](https://www.youtube.com/watch?v=oMAJ7RsuYUs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-02 00:00:00+00:00

Slowdive perform "Souvlaki Space Station"  from their 1993 release, Souvlaki, on Creation Records.

PERSONNEL
Rachel Goswell
Neil Halstead
Christian Savill
Nick Chaplin
Simon Scott

MORE FROM THIS SESSION
Star Roving https://www.youtube.com/watch?v=nukZQTFsA10
Sugar for the Pill https://youtu.be/EskZhEUtlb8
Full Session https://youtu.be/gliBbiCIFtM

#shoegaze #dreampop #indierock

## Slowdive - Sugar for the Pill (Live at The Current, 2017)
 - [https://www.youtube.com/watch?v=EskZhEUtlb8](https://www.youtube.com/watch?v=EskZhEUtlb8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-02 00:00:00+00:00

Slowdive perform "Sugar for the Pill"  from their  2017 self-titled album, available on Dead Oceans.

PERSONNEL
Rachel Goswell
Neil Halstead
Christian Savill
Nick Chaplin
Simon Scott

MORE FROM THIS SESSION
Star Roving https://www.youtube.com/watch?v=nukZQTFsA10
Full Session https://youtu.be/gliBbiCIFtM

#shoegaze #dreampop #indierock

## Afrobeat drummer Tony Allen dies at 79 (The Current Music News)
 - [https://www.youtube.com/watch?v=6lHZiKBGVDI](https://www.youtube.com/watch?v=6lHZiKBGVDI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-01 00:00:00+00:00

May 1, 2020: Tony Allen, a drummer who helped define the sound of Afrobeat, has died of an aneurysm at age 79. Also: the MusiCares COVID-19 relief fund has dried up, Sirius XM debuts a Prince channel, and 'Weird Al' Yankovic plays Ted Nugent on 'Reno 911.'
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/
Support The Current:

