# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Guitar Hero At 165% Speed And Elijah Wood's Turnip Sale | Good News Gaming
 - [https://www.youtube.com/watch?v=_U6D_lFAc8s](https://www.youtube.com/watch?v=_U6D_lFAc8s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-02 00:00:00+00:00

On Good News Gaming, we take a look at the uplifting news stories from the week, like an incredible Through The Fire And Flames expert run… at 165% speed, as well as Elijah Wood's wholesome Animal Crossing moment, and how to improve movies with Age of Empires sound effects.

This week on Good News Gaming, we look at a blast from the past: Through The Fire And Flames on Guitar Hero 3. Only this time, it's being completed on expert at 165% speed. Better dig out the plastic axe and get practicing. 

The movie Troy gets improved exponentially with the addition of Age of Empires sound effects, there's a baby that looks like a Metal Gear Solid character, and we have some fun with some giant Nintendo DS consoles. 

We also talk about GameSpot's Play For All initiative, and how we're going to be raising money for COVID relief all summer. If you have any uplifting news stories you'd like to see mentioned next week, leave them in the comments!

In this video: 

Distracted boyfriend in FF7 Remake: https://twitter.com/dmseto/status/1253332541269897220?s=20
Through The Fire And Flames at 165%: https://youtu.be/VtEeDUeBrMg
Games for Carers link: giveaways.keymailer.co/nhs 
Super Nintendo fish tank: https://youtu.be/clMe7aQm8y0
Elijah Wood in Animal Crossing: https://twitter.com/directedbyrian/status/1253365992849276934?s=20
Centre For Computing History JustGiving page: https://www.justgiving.com/campaign/computermuseum
Centre For Computing History tour: https://www.youtube.com/watch?v=JkRg1wtSAqw&feature=emb_title 
Troy with Age Of Empires sound effects: https://youtu.be/ocXv7u8iOb0
Huge Nintendo DS: https://twitter.com/HugeNintendoDS
Fatman baby carrier: https://www.reddit.com/r/gaming/comments/gaac2p/my_daughter_in_her_carrier_looks_like_fatman_from/ 
IMG Tennis Stay At Home Slam: https://twitter.com/IMGTennis/status/1255573055558074369 
GameSpot Play For All! https://www.gamespot.com/articles/introducing-play-for-all-gamespots-summer-gaming-c/1100-6476548/

#GoodNewsGaming #GameSpot

## Please, Stop Turning Anime Into Arena Fighters
 - [https://www.youtube.com/watch?v=pCRSXNkgX8M](https://www.youtube.com/watch?v=pCRSXNkgX8M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-02 00:00:00+00:00

If like us you love anime, you'll no doubt have thought about why video games do so little with the games based on them. This is especially true of the shonen genre, with franchises like Naruto, My Hero Academia, One Piece, and One Punch Man. Each of these properties presents fascinating worlds, charismatic characters, and interesting ideas that would work well as a game. And yet, in most cases, we keep getting boilerplate arena fighters.

In this video, Tamoor vents his frustrations with the state of anime and manga to video game adaptations, and remembers one particular example of it being done well. Why is he doing this? Because anime and manga deserve better, and he's hoping that others out there might see the video and feel the same. 

Admittedly, Dragon Ball FighterZ was an excellent recent example of an anime adaption done right, but it's still buried under a pile of forgettable ones. Maybe if we complain loud enough someone will listen to our anguished cries for better anime games. Fingers crossed.

## Trolling Our Friends With GREAT Turnip Prices In Animal Crossing - Vile Villager Episode 4
 - [https://www.youtube.com/watch?v=G67-blaCOOI](https://www.youtube.com/watch?v=G67-blaCOOI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-02 00:00:00+00:00

And y'all thought locking up your neighbors in cages like the animals they are was bad. Clearly, you haven't seen anything yet--because this week, Byle the vile villager has decided to commit an even worse offense: Lie about Animal Crossing: New Horizons turnip prices.

In Episode 4 of Vile Villager, Rob Handlery and Jake Dekker decide to forgo winning employee of the month and tell their fellow GameSpot coworkers that the Nook's Cranny on Byle's island is buying turnips for 544 bells...when they're actually only going for 80. 

"What's wrong with that?" we hear you ask. "After visiting MeatHouse island, you just walk over to Nook's Cranny, see that they lied, and then leave. It's only like a waste of 60 seconds." Well see, here's the thing. Rob and Jake didn't just lie about the turnip prices. They also built an elaborate obstacle course between the MeatHouse airport and Nook's Cranny so you actually had to waste a whole lot of time to only then learn that the entire ordeal wasn't even worth it in the first place. 

In the video above, you can watch Byle build his diabolical trap, attract his would-be victims, dress up as a creepy jester (because why not), and then observe his prey scurry around to his heart's content. Because if it's not clear already, Byle is a psychopath.

## We Turn Predator: Hunting Grounds' Graphics Into One Ugly Motherf***er | Potato Mode
 - [https://www.youtube.com/watch?v=oIJ7S-6FGdQ](https://www.youtube.com/watch?v=oIJ7S-6FGdQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-02 00:00:00+00:00

If Predator: Hunting Grounds' graphics bleed, then we can kill it. On this week's Potato Mode, Jean-Luc and Ben mess up things so bad the very ground disappears.

Predator: Hunting Grounds is a new asymmetric multiplayer game from the team behind Friday the 13th, and pits a team of soldiers against the ultimate movie hunter. But even an extraterrestrial trophy hunter can't escape the scrutiny of Potato Mode, our video series that's always after the biggest game.

In this edition, Ben and Jean-luc sit down to an old-fashioned multiplayer session, first showing the game as it's meant to be seen, and then applying some mad science. The Nvidia Profile Inspector is used to tweak the graphics settings for some extremely un-optimized visuals. At first everything just gets shiny and smooth, but before long the Predator's cloaking technology starts claiming large chunks of the ground.

Check out the video above to see all the horrifying results, and check out Potato Mode for more mad graphics science with the latest games.

#PotatoMode #Predator #HuntingGrounds

## Assassin's Creed Valhalla Details And Apex Legends' New Character Revealed
 - [https://www.youtube.com/watch?v=6PKJ4kZsVQQ](https://www.youtube.com/watch?v=6PKJ4kZsVQQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-01 00:00:00+00:00

Persia talks about Assassin’s Creed Valhalla, Xbox Game Pass and its upcoming cloud game streaming service, and a new Apex Legends new character reveal.

Today, Persia talks about Assassin's Creed Valhalla and what we know about it so far. Gameplay for it will be revealed on Inside Xbox on May 7, along with other next-gen gameplay reveals from Xbox and its partners. In other Xbox news, cloud games streaming service is heading to Game Pass this year.

Persia also talks Apex Legends and the Loba character reveal: Revanant killed her father, she grew up to become to ultimate thief, and now she's out for revenge. We could see how her professional thievery come into play with her abilities soon, but we won't know for sure how she feels within the larger experience until Season 5 begins on May 12.

This is your Save State for Thursday, April 30.

#AssassinsCreed #ApexLegends #GameSpot

## Assassin's Creed: Valhalla Revealed & Overwatch's New Hero - GS After Dark #39
 - [https://www.youtube.com/watch?v=hfczhtE2iWI](https://www.youtube.com/watch?v=hfczhtE2iWI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-01 00:00:00+00:00

On episode 39 of GameSpot After Dark, the crew discusses the new Assassin's Creed game, The Last Of Us Part 2's new release date, and Cyberpunk 2077's leaked rating.

TIMESTAMPS: 
00:00:13 - Introduction
00:00:27 - Assassin's Creed: Valhalla Revealed
00:004:32 - What We've Been Playing
00:32:05 - New Overwatch Hero
00:35:18 - Cyberpunk 2077 Rating Leaked
00:40:56 - The Last of Us Part 2 Discussion
00:53:20 - Listener Questions
01:10:33 - Outro

## Free PS4 PlayStation Plus Games For May 2020 Revealed
 - [https://www.youtube.com/watch?v=FGksbMdKwQM](https://www.youtube.com/watch?v=FGksbMdKwQM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-01 00:00:00+00:00

The PS4 PS Plus games for May 2020 have been revealed. This month, PlayStation Plus subscribers can build their own utopia with Cities: Skylines and grow crops in Farming Simulator 19. These games will be available from May 5 - June 1.

#PS+ #PlayStationPlus #GameSpot

## Free Xbox One And Xbox 360 Games With Gold For May 2020 Revealed
 - [https://www.youtube.com/watch?v=Ypap8E4xBkU](https://www.youtube.com/watch?v=Ypap8E4xBkU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-01 00:00:00+00:00

The Xbox Games with Gold for May 2020 have been revealed. Xbox One is getting V-Rally 4 and Warhammer 40,000: Inquisitor - Martyr, and Xbox 360 is getting Sensible World of Soccer and Overlord 2. The latter two games are backwards compatible with Xbox One as well.

#GamesWithGold #GameSpot

## Our Favorite Legends of Runeterra Cards
 - [https://www.youtube.com/watch?v=krWkECgcA5s](https://www.youtube.com/watch?v=krWkECgcA5s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-01 00:00:00+00:00

(Presented by Legends of Runeterra) Legends of Runeterra is a brand new CCG from Riot Games that brings characters from League of Legends into a whole new world. Here are some of our favorites so far.

## Why The Last Of Us' Story Still Resonates 7 Years Later
 - [https://www.youtube.com/watch?v=5bYAuu-J86U](https://www.youtube.com/watch?v=5bYAuu-J86U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-01 00:00:00+00:00

Naughty Dog's 2013 PlayStation 3 exclusive The Last Of Us is one of the most highly regarded games of the past decade. With the sequel due for release in June, you might be thinking about playing the original game the first time or returning to experience the survival story once more.

In a new video feature, Jess dives into what makes Joel and Ellie's tumultuous cross-country adventure stay timeless and affecting seven years later. Jess argues that The Last of Us' greatest strength is timeless--its portrayal of complex characters embroiled in an emotional and heart-wrenching fight for survival. 

The video covers much more, including how the game cleverly keeps resources limited to elevate its themes of survival and desperation, and how the narrative's linear format and deliberate pace helps drive home the game's most impactful scenes and character moments.

Be sure to check out the full video above, and keep coming back to GameSpot for more Last of Us coverage in the lead-up to The Last Of Us 2's release in June.

#TheLastOfUs #GameSpot

