# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## How to be an Awesome Game Developer
 - [https://www.youtube.com/watch?v=y6f6mmuh_04](https://www.youtube.com/watch?v=y6f6mmuh_04)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-05-01 00:00:00+00:00

Here's a little thought experiment to keep you amused for a while.

