# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Separating fact from fiction as Trump builds a rationale to pardon Michael Flynn
 - [https://www.cnn.com/2020/04/30/politics/flynn-trump-conspiracy-theories-pardon/index.html](https://www.cnn.com/2020/04/30/politics/flynn-trump-conspiracy-theories-pardon/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-01 00:46:53+00:00

President Donald Trump went on a Twitter rampage Thursday about his former adviser Michael Flynn, flooding the zone with conspiracy theories and paper-thin allegations that crooked FBI investigators entrapped Flynn as part of a "deep state" plot.

