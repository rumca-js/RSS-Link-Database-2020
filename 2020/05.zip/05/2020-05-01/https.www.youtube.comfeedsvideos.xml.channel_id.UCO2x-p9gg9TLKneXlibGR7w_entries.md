# Source:Snazzy Labs, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w, language:en-US

## Apple's Next Failure
 - [https://www.youtube.com/watch?v=B_NoBsCPPSE](https://www.youtube.com/watch?v=B_NoBsCPPSE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w
 - date published: 2020-05-02 00:00:00+00:00

Quinn addresses the outlandish rumor that a gaming Mac is coming. It would never work. But... maybe it would? Nah, impossible! But... what if... Valve? Apple? HMM?!

Buy an iMac Pro - https://amzn.to/2SKn6Nx
Buy an AMD RX 5700 XT - https://amzn.to/2Wj4oxo
Subscribe to my podcast Flashback! - http://relay.fm/flashback
Follow me on Twitter - http://twitter.com/snazzyq
Follow me on Instagram - http://instagram.com/snazzyq

In December, a rumor was reported by a bunch of Apple-focused news sites that there could possibly be the release of a gaming Mac with a cost of up to $5,000. There's a number of reasons why I don't think that gaming Macs will overthrow gaming PCs anytime soon. The hardware would be less than ideal thanks to Apple's soured relationship with NVIDIA, the transition to ARM would make game ports from x86 platforms like Windows significantly more difficult, and the software... man... the software. All of Apple's moves in the last couple years (like ditching support for 32-bit libraries with macOS Catalina and insisting to use Metal instead of open graphics APIs like Vulkan) suggest that they're not interested in a gaming Mac. But they could form strong allies with a certain company named Valve.... Steam is essentially tied to the Windows platform and as Microsoft takes an increasingly walled-garden approach to Windows 10 (and future iterations) like Apple has in the past, Valve's core market is in jeopardy and they'd be wise to form new allies in Microsoft's competitors. Linux users have enjoyed a huge influx of games in recent years thanks to Steam Play which is powered by Steam Proton. This is a translation layer that uses Wine and DXVK to allow Direct3D/DirectX games to run on Linux via Vulkan. If Apple permitted something similar on macOS and also acquired a few exclusive titles of their own, the idea of a gaming Mac isn't so farfetched. I mean, let's not forget Apple has $200B cash on hand. If they want to make something happen, they can. The question is... do they? I try and answer that in this video.

