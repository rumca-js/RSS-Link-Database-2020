# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## iPhone 11 Pro Review: 6 Months Later!
 - [https://www.youtube.com/watch?v=nxf41fMX_Y4](https://www.youtube.com/watch?v=nxf41fMX_Y4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-05-02 00:00:00+00:00

iPhone 11 Pro plus iPhone 12 thoughts. I was wrong about 3D Touch!
That wallpaper: https://i.imgur.com/4SwaaPo.jpg
iPhone 11 Pro original review: https://youtu.be/DyX-QZZBgpw

MKBHD Merch: http://shop.MKBHD.com

Video Gear I use: http://kit.co/MKBHD/video-gear#recom...
Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Jordyn Edmonds http://smarturl.it/jordynedmonds
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

