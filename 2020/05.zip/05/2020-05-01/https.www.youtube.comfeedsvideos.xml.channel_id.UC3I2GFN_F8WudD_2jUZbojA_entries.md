# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## YĪN YĪN - Dis̄ Kô Dis̄ Kô (Live on KEXP)
 - [https://www.youtube.com/watch?v=xS3vSPyVvQM](https://www.youtube.com/watch?v=xS3vSPyVvQM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-01 00:00:00+00:00

http://KEXP.ORG presents YĪN YĪN performing “Dis̄ Kô Dis̄ Kô” live at the La Chapelle by Le Studio in Rennes, France, during Trans Musicales 2019. Recorded December 7, 2019.

Audio Engineer: Matt Ogaz
Audio Mixer: Simon Van Boxtel
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

Additional support by 
Jean Baptiste Le Clec’h
Jean-Marc Meleard
Jeremy Meleard

Festival Artwork by Brendan Monroe

Special thanks to Gwenola Le Bris at Trans Musicales, Valérian Mercier at La Chapelle by le Studio, and Destination Renne

http://kexp.org
https://www.lestrans.com
https://www.tourisme-rennes.com
https://www.lachapellebylestudio.com
https://yinyin.bandcamp.com

## YĪN YĪN - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=yxgzfl1yctU](https://www.youtube.com/watch?v=yxgzfl1yctU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-01 00:00:00+00:00

http://KEXP.ORG presents YĪN YĪN performing live at the La Chapelle by Le Studio in Rennes, France, during Trans Musicales 2019. Recorded December 7, 2019.

Songs:
pingpxng
One Inch Punch
Chông ky
Dis̄ Kô Dis̄ Kô

Audio Engineer: Matt Ogaz
Audio Mixer: Simon Van Boxtel
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

Additional support by 
Jean Baptiste Le Clec’h
Jean-Marc Meleard
Jeremy Meleard

Festival Artwork by Brendan Monroe

Special thanks to Gwenola Le Bris at Trans Musicales, Valérian Mercier at La Chapelle by le Studio, and Destination Renne

http://kexp.org
https://www.lestrans.com
https://www.tourisme-rennes.com
https://www.lachapellebylestudio.com
https://yinyin.bandcamp.com

## YĪN YĪN - One Inch Punch (Live on KEXP)
 - [https://www.youtube.com/watch?v=qZlAQOux0WM](https://www.youtube.com/watch?v=qZlAQOux0WM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-01 00:00:00+00:00

http://KEXP.ORG presents YĪN YĪN performing “One Inch Punch” live at the La Chapelle by Le Studio in Rennes, France, during Trans Musicales 2019. Recorded December 7, 2019.

Audio Engineer: Matt Ogaz
Audio Mixer: Simon Van Boxtel
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

Additional support by 
Jean Baptiste Le Clec’h
Jean-Marc Meleard
Jeremy Meleard

Festival Artwork by Brendan Monroe

Special thanks to Gwenola Le Bris at Trans Musicales, Valérian Mercier at La Chapelle by le Studio, and Destination Renne

http://kexp.org
https://www.lestrans.com
https://www.tourisme-rennes.com
https://www.lachapellebylestudio.com
https://yinyin.bandcamp.com

