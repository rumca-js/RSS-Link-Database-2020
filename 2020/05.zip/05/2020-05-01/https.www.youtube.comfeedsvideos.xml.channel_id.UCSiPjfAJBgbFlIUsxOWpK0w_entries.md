# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Happy Together | The Turtles | Pomplamoose
 - [https://www.youtube.com/watch?v=JFMxDBsUtxE](https://www.youtube.com/watch?v=JFMxDBsUtxE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2020-05-01 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

A cover of Happy Together by Pomplamoose.

CREDITS

Lead Vocals: Nataly Dawn
Keys: Jack Conte
Guitar/Bass/Keys/Percussion: Brian Green 
Trumpet: Andris Mattson
Background Vocals: Sarah Dugas
Mixing/Mastering: Caleb Parker
Producer: Brian Green
Video Editor: Dominic Mercurio

Recorded from our homes in San Francisco & Los Angeles.

