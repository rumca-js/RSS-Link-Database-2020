# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## WHY do I pay Adobe $10K a YEAR!?
 - [https://www.youtube.com/watch?v=L9VysWRHPdI](https://www.youtube.com/watch?v=L9VysWRHPdI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-05-02 00:00:00+00:00

Buy CORSAIR Dark Core RGB Pro
On CORSAIR: https://geni.us/BwIcB
On Amazon: https://geni.us/rAGj8
On Newegg: https://geni.us/gQTZB

Check out ORIGIN PC’s new EVO16-S Ready-To-Ship Streamer Bundle today at https://bit.ly/3ahu3LX

Intro by Mbarek Abdelwassaa -  https://www.instagram.com/mbarek_abdel/

It's ridiculous. Can we make our videos without touching a SINGLE Adobe Product?

Apps we used:
Kyno: https://lesspain.software/kyno/
Davinci Resolve / Fusion / Fairlight: https://www.blackmagicdesign.com/products/davinciresolve/
Affinity Photo: https://affinity.serif.com/en-gb/photo/

Buy an Editing Workstation
On Amazon (PAID LINK): https://geni.us/5qwv7e
On B&H (PAID LINK): https://geni.us/195VL9

Buy an AMD Threadripper CPU
On Amazon (PAID LINK): https://geni.us/AeAzI5
On B&H (PAID LINK): https://geni.us/tr9khe

Buy an NVIDIA GPU
On Amazon (PAID LINK): https://geni.us/BgrzU
On B&H (PAID LINK): https://geni.us/WMe5

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1187903-why-do-i-pay-adobe-10k-a-year/


GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Support a Creator code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Test Benches on Amazon: https://lmg.gg/HOx0z
Our Production Gear: https://lmg.gg/4oPzt
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0 https://lmg.gg/fxHYK 
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://lmg.gg/Q9yyQ 
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://lmg.gg/8upii

## Watch Out, Losers! AMD is Making Video Cards for PHONES - WAN Show May 1, 2020
 - [https://www.youtube.com/watch?v=cwPOtPDUlU8](https://www.youtube.com/watch?v=cwPOtPDUlU8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-05-01 00:00:00+00:00

Save 10% at Ridge Wallet with offer code LINUS at https://www.ridge.com/Linus

Use code LTT at MechanicalKeyboards at https://geni.us/VNixUn

Sign up for Private Internet Access VPN at https://lmg.gg/piawan

Buy LTX 2020 Presented by Intel Tickets: https://lmg.gg/ltx20tickets
Learn more about LTX 2020: https://www.ltxexpo.com/
LTX 2020 Activities: https://www.ltxexpo.com/attractions
LTX 2020 Special Guests: https://www.ltxexpo.com/guests

Buy an LTT shirt, hoodie, hat, and even our own water bottle at https://lmg.gg/wanlttstore

Check out Carpool Critics, our new movie podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Podcast Download: http://dts.podtrac.com/redirect.mp3/traffic.libsyn.com/linustechtips/Watch_Out_Losers_AMD_is_Making_Video_Cards_for_PHONES_-_WAN_Show_May_1_2020.mp3

Timestamps: (Courtesy of Sylonce)

00:38 Topics/intro/good lol times rambling
11:45 Linus' joystick sounds like leather
15:55 Intro
16:37 Samsung's new SoC with AMD GPU
29:52 Assassin's Creed Valhalla single purchase same brand cross-console play
44:10 mechanicalkeyboards.com (sponsor) use code LTT
44:52 ridge.com/linus (sponsor) use code LINUS for 10% off 
45:40 lmg.gg/piawan Private Internet Access (sponsor)
46:12 Quick question: Linus, have you ever p* games when you were younger?
57:31 Intel launches 10th gen desktop CPUs
1:01:35 UPS blowing up story update
1:02:38 Intel's 10nm profitability
1:07:40 Superchats
1:09:00 LMG's hiring!
1:10:20 Superchats

