# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Clinton the cat
 - [https://www.youtube.com/watch?v=nb7e_7UJxAY](https://www.youtube.com/watch?v=nb7e_7UJxAY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-05-01 00:00:00+00:00

https://discord.gg/rossmanngroup
Let's get Right to Repair passed! https://gofund.me/1cba2545
Listen to this SCATHING rebuke of eli the computer guy at 0:35!

## Forfeiting my keys: final walkthrough 😞
 - [https://www.youtube.com/watch?v=5rwrEVOUKhk](https://www.youtube.com/watch?v=5rwrEVOUKhk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-05-01 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545

