## Jest afera. Każdy smartfon Xiaomi to podobno „backdoor z funkcjonalnością telefonu”
 - [https://www.benchmark.pl/aktualnosci/smartfony-xiaomi-zbieraja-wszystkie-dane-o-uzytkowniku.html](https://www.benchmark.pl/aktualnosci/smartfony-xiaomi-zbieraja-wszystkie-dane-o-uzytkowniku.html)
 - RSS feed: www.benchmark.pl
 - date published: 2020-05-01 12:04:50+00:00



