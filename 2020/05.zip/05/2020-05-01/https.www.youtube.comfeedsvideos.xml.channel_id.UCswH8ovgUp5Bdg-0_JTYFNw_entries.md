# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## New Senses, New Reality? | Russell Brand & Neuroscientist David Eagleman
 - [https://www.youtube.com/watch?v=9bvyacjGVxk](https://www.youtube.com/watch?v=9bvyacjGVxk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-05-01 00:00:00+00:00

A clip from my #UnderTheSkin podcast with neuroscientist David Eagleman.
You can listen to the entire conversation on the Luminary app: http://luminary.link/russell 

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

