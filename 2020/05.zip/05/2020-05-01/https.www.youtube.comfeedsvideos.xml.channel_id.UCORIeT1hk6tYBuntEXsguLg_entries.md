# Source:PostmodernJukebox, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg, language:en-US

## Black - Pearl Jam (Orchestral Cover) ft. Cortnie Frazier
 - [https://www.youtube.com/watch?v=aJKeNOk3DTI](https://www.youtube.com/watch?v=aJKeNOk3DTI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg
 - date published: 2020-05-01 00:00:00+00:00

Download & Stream "Black" Here: https://pmjlive.com/black?IQid=yt
Experience PMJ Live: https://pmjlive.com?IQid=yt
Shop PMJ Music/Merch:  https://smarturl.it/pmjshop?IQid=yt
Follow Us On Spotify: https://smarturl.it/pmjcomplete?IQid=yt

Months before quarantine, we flew #PMJsearch2019 winner Cortnie Frazier out to LA to star in this hauntingly beautiful orchestral rendition of Pearl Jam's 1991 grunge classic, "Black."

Follow The Musicians:
Cortnie Frazier (Vocals):
Facebook: https://facebook.com/cortniefraziermusic/
Instagram: https://instagram.com/c_frayyy/
Twitter: https://twitter.com/cortniefrazier

Artyom Manukyan (Cello):
https://instagram.com/artyommanukyan/

Grace Rodgers (Violin):
https://instagram.com/graceannviolin/

Kiara Perico (Viola):
https://instagram.com/thekiaraana/

Cooper Appelt (Bass):
https://instagram.com/cooperappelt/?hl=en

Aaron Mclendon (Drums):
https://instagram.com/amacthemusician/

Scott Bradlee (Piano):
YouTube: http://youtube.com/scottbradlee
Facebook: http://facebook.com/scottbradleemusic
Instagram: http://instagram.com/scottbradlee
Twitter: http://twitter.com/scottbradlee
Scott's Book:  http://smarturl.it/outsidethejukebox

Arrangement by: Scott Bradlee
Engineered by: Thai Long Ly
Video by: Braverijah Sage

#PearlJam #Black #Cover

