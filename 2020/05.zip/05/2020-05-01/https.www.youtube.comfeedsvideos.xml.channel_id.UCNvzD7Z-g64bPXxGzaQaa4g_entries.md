# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Best FREE iOS & Android Games of April 2020
 - [https://www.youtube.com/watch?v=TUHIcu1L4vI](https://www.youtube.com/watch?v=TUHIcu1L4vI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-05-02 00:00:00+00:00

Looking for something to play while you're stuck at home? Here's a list of the best free mobile games of April 2020.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

#10 Disorder
Platform: Android, iOS
Price: Free
https://play.google.com/store/apps/details?id=com.netease.disorder&hl=en_IN

#9 Naruto Slugfest
Platform: Android iOS [SOON]
PRICE: FREE
https://apps.apple.com/us/app/naruto-slugfest/id1474940970
https://play.google.com/store/apps/details?id=com.narutoslugfest.cubinet.android&hl=en_IN

#8 Dirt Bike Unchained
Platform: iOS Android
PRICE: FREE
https://apps.apple.com/us/app/dirt-bike-unchained/id1451177077
https://play.google.com/store/apps/details?id=com.redbull.moto

#7 Aura Kingdom 2
Platform: iOS Android
PRICE: FREE
https://apps.apple.com/us/app/aura-kingdom-2/id1492679270
https://play.google.com/store/apps/details?id=com.xlegend.aurakingdom2.global

#6 Legends of Runeterra
Platform: Android, iOS
Price: Free
https://play.google.com/store/apps/details?id=com.riotgames.legendsofruneterra
https://apps.apple.com/us/app/legends-of-runeterra/id1480617557

#5 BLADE XLORD
Platform: iOS, Android
PRICE: FREE
https://apps.apple.com/us/app/blade-xlord/id1496760638
https://play.google.com/store/apps/details?id=jp.co.applibot.us.bladexlord&hl=en_IN


#4 Dino Squad: Online Action
Platform: iOS android
Price: Free
https://apps.apple.com/us/app/dino-squad-online-action/id1499971430
https://play.google.com/store/apps/details?id=com.pixonic.dino&hl=en_IN

#3 Gameloft Classics: 20 Years
Platform: Android
Price: Free
https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftGLCL&hl=en_IN

#2 Game of Thrones Beyond the Wall
Platform: iOS Android
Price: Free
https://apps.apple.com/us/app/game-of-thrones-beyond/id1492828790
https://play.google.com/store/apps/details?id=com.bhvr.beyondthewall&hl=en


#1 Dead by Daylight Mobile
Platform: iOS android
Price: Free
https://apps.apple.com/no/app/dead-by-daylight-mobile/id1452289752
https://play.google.com/store/apps/details?id=com.bhvr.deadbydaylight&hl=en_IN

BONUS

GRIS
Platform: iOS Android
Price: $4.99
https://apps.apple.com/us/app/gris/id1445379072
https://play.google.com/store/apps/details?id=com.devolver.grispaid&hl=en_US

## 10 WEIRD Gaming Stories of April 2020
 - [https://www.youtube.com/watch?v=qz0jdyYvbBI](https://www.youtube.com/watch?v=qz0jdyYvbBI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-05-02 00:00:00+00:00

Despite the state of the world, April was still a weird and crazy month for video game news. Here are some interesting highlights.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1
Bad Robo: https://www.youtube.com/channel/UCtv_wDOg5_71C94AlXvkoGQ

## DOOM ETERNAL CUT GRAPHICS RESTORED, CYBERPUNK 2077 GETS RATING, & MORE
 - [https://www.youtube.com/watch?v=Bho7pA_y9ww](https://www.youtube.com/watch?v=Bho7pA_y9ww)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-05-01 00:00:00+00:00

Get the best deals while shopping online ▸ http://joinhoney.com/gameranx
Honey is FREE and finds coupons with the click of a button. Thanks Honey for sponsoring!

Some Last of Us Part 2 news, Cyberpunk gets an edgy rating, Battlefront 2 finally wraps up, Xbox plans announcements, and more in a week full of gaming news.
Subscribe for more: http://youtube.com/gameranxtv 

*Jakes twitter: https://twitter.com/jakebaldino 
*Instagram: https://goo.gl/HH6mTW 

 discord.gg/gameranx 

 Weekly giveaway link: https://goo.gl/forms/a7zCtr1HuTkzWuOo2 



 ~~~~STORIES~~~~


Doom Eternal graphics
https://www.dsogaming.com/news/doom-eternal-mod-restores-cut-graphics-effects-like-player-shadow-anamorphic-lens-flares-more/

Assassin’s Creed
Trailer: https://youtu.be/L0Fr3cS3MtY
Info: https://youtu.be/9EUt0OC2ZhU

Xbox event
https://twitter.com/Xbox/status/1255889762864361472

Last of Us/Tsushima release dates https://blog.us.playstation.com/2020/04/27/release-date-updates-for-the-last-of-us-part-ii-ghost-of-tsushima/
Naughty Dog responds: https://twitter.com/Naughty_Dog/status/1254840504182665219
Sony confirmation source: https://www.gamesindustry.biz/articles/2020-04-27-the-last-of-us-part-2-leaked-online

Cyberpunk rated R lol
https://twistedvoxel.com/cyberpunk-2077-explicit-adult-content-rating/



WWE 2K Battlegrounds
https://youtu.be/CTqED7mOzrU

Streets of Rage launch trailer:
https://youtu.be/nDXY1WRef0Q

***New Summer Games Fest thing: 
https://www.summergamefest.com/


‘Enlisted’ WW2 MMO FPS:
https://youtu.be/80YmTiL488Q

Battlefront 2 wraps up
https://youtu.be/PiXo9W5jc7Y



Battlefield 2021
https://www.gamespot.com/articles/battlefield-returns-in-2021-for-ps5-and-xbox-serie/1100-6476603/?utm_source=reddit.com


Brothers in Arms show
https://www.gamespot.com/articles/gearboxs-brothers-in-arms-becoming-a-tv-series/1100-6476526/?UniqueID=2257408A-8892-11EA-AB61-EB1C933C408C&ServiceType=twitter&TheTime=2020-04-27T14%3A19%3A41&ftag=ftag%3DGSS-05-10aab8e&PostType=link

