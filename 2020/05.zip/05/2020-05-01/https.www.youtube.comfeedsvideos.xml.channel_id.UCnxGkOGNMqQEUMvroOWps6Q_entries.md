# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Alonzo Bodden Loves Terrible Movies
 - [https://www.youtube.com/watch?v=q35H6n8_hz4](https://www.youtube.com/watch?v=q35H6n8_hz4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-01 00:00:00+00:00

Taken from JRE #1468 w/Alonzo Bodden: https://youtu.be/2cOnu-HMmUk

## Alonzo Bodden and Joe Rogan Talk Gun Laws
 - [https://www.youtube.com/watch?v=ziewKdfOf9Q](https://www.youtube.com/watch?v=ziewKdfOf9Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-01 00:00:00+00:00

Taken from JRE #1468 w/Alonzo Bodden: https://youtu.be/2cOnu-HMmUk

## Joe Talks Marvel Superhero Powers with Alonzo Bodden
 - [https://www.youtube.com/watch?v=GAqwydfZNmU](https://www.youtube.com/watch?v=GAqwydfZNmU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-01 00:00:00+00:00

Taken from JRE #1468 w/Alonzo Bodden:
https://youtu.be/2cOnu-HMmUk

## Joey Diaz's Fungus Moment - JRE Toons
 - [https://www.youtube.com/watch?v=VeC6P-Dwl6Q](https://www.youtube.com/watch?v=VeC6P-Dwl6Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-01 00:00:00+00:00

Another hilarious moment animated by PaulyToon from the Joe Rogan Experience #1409 with Joey Diaz (https://youtu.be/6iYxbRZ21bw).

## Re-Opening States is an Experiment w/Alonzo Bodden | Joe Rogan
 - [https://www.youtube.com/watch?v=YGlwzbWimC4](https://www.youtube.com/watch?v=YGlwzbWimC4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-01 00:00:00+00:00

Taken from JRE #1468 w/Alonzo Bodden:
https://youtu.be/2cOnu-HMmUk

## Will Americans Buy American After the Pandemic?
 - [https://www.youtube.com/watch?v=WPXJRml4qZY](https://www.youtube.com/watch?v=WPXJRml4qZY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-01 00:00:00+00:00

Taken from JRE #1468 w/Alonzo Bodden: https://youtu.be/2cOnu-HMmUk

