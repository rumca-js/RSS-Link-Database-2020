# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Cartalk - Driveway (Live on KEXP)
 - [https://www.youtube.com/watch?v=EApPbFpA1Rk](https://www.youtube.com/watch?v=EApPbFpA1Rk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-29 00:00:00+00:00

http://KEXP.ORG presents Cartalk performing "Driveway" live in the KEXP studio. Recorded January 22, 2020.

Host: John Richards
Audio Engineer: Kevin Suggs
Cameras: Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Alaia D'Alessandro

http://kexp.org
https://cartalk.bandcamp.com

## Cartalk - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=o61ZSaN_U34](https://www.youtube.com/watch?v=o61ZSaN_U34)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-29 00:00:00+00:00

http://KEXP.ORG presents Cartalk performing live in the KEXP studio. Recorded January 22, 2020.

Songs:
Las Manos
Noonday Devil
Driveway
Sleep

Host: John Richards
Audio Engineer: Kevin Suggs
Cameras: Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Alaia D'Alessandro

http://kexp.org
https://cartalk.bandcamp.com

## Cartalk - Las Manos (Live on KEXP)
 - [https://www.youtube.com/watch?v=lL7-1LP0vyI](https://www.youtube.com/watch?v=lL7-1LP0vyI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-29 00:00:00+00:00

http://KEXP.ORG presents Cartalk performing "Las Manos" live in the KEXP studio. Recorded January 22, 2020.

Host: John Richards
Audio Engineer: Kevin Suggs
Cameras: Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Alaia D'Alessandro

http://kexp.org
https://cartalk.bandcamp.com

## Cartalk - Noonday Devil (Live on KEXP)
 - [https://www.youtube.com/watch?v=jkk5gFGP7II](https://www.youtube.com/watch?v=jkk5gFGP7II)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-29 00:00:00+00:00

http://KEXP.ORG presents Cartalk performing "Noonday Devil" live in the KEXP studio. Recorded January 22, 2020.

Host: John Richards
Audio Engineer: Kevin Suggs
Cameras: Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Alaia D'Alessandro

http://kexp.org
https://cartalk.bandcamp.com

## Cartalk - Sleep (Live on KEXP)
 - [https://www.youtube.com/watch?v=TgcJmQw4EMM](https://www.youtube.com/watch?v=TgcJmQw4EMM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-29 00:00:00+00:00

http://KEXP.ORG presents Cartalk performing "Sleep" live in the KEXP studio. Recorded January 22, 2020.

Host: John Richards
Audio Engineer: Kevin Suggs
Cameras: Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Alaia D'Alessandro

http://kexp.org
https://cartalk.bandcamp.com

## Kishi Bashi (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=ljHs2hfRayE](https://www.youtube.com/watch?v=ljHs2hfRayE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-28 00:00:00+00:00

Kishi Bashi performs from home and joins Cheryl Waters live on KEXP on Thursday, May 28, at 3pm PT.

