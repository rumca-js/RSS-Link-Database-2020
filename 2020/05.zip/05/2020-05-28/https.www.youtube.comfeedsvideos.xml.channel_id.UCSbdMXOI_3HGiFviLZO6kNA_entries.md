# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## Oculus Quest VS Oculus Rift S 2020 Guide
 - [https://www.youtube.com/watch?v=rqo1M4alHWI](https://www.youtube.com/watch?v=rqo1M4alHWI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-05-29 00:00:00+00:00

Hello! 

I have used the Oculus Quest and Oculus Rift solid for more than a year now, receiving both of the headsets practically on launch day. After a year of usage for both of them my thoughts and general consensus on what YOU should buy has changed significantly. After the Quest has received update after update and the Rift S has received pretty much nothing new... the tides have definitely shifted. Here is my 2020 analysis of the Oculus Quest Versus the Oculus Rift S.



Here are my links:
My Stream:
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill

