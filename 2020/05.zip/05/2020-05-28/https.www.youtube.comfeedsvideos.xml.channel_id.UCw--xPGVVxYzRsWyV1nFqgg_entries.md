# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## DISCWORLD: Before You Read!
 - [https://www.youtube.com/watch?v=xouqVZ7Hbz4](https://www.youtube.com/watch?v=xouqVZ7Hbz4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-05-29 00:00:00+00:00

My thoughts on what you need to know before you read terry pratchett's iconic Discworld series! 
GET THE BOOKS HERE: 
Guards Guards: https://amzn.to/2XyDUIS
Mort: https://amzn.to/3gtbB79
Small Gods: https://amzn.to/2yByZhF

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## LOTR Cast Reunion🧙 Kingdom Hearts Disney Show❤️ First Law Cover📕 - FANTASY NEWS
 - [https://www.youtube.com/watch?v=CrRHGdKYxCM](https://www.youtube.com/watch?v=CrRHGdKYxCM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-05-28 00:00:00+00:00

News happened, lets talk about it in the fantasy context! 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

NEWS:

YMS Kimba movie: https://www.youtube.com/watch?v=G5B1mIfQuo4&t=0s

Trouble With Peace Cover: https://twitter.com/lordgrimdark/status/1265662899403591686?s=12

Little hatred Paperback/ Trouble with peace signed: https://twitter.com/waterstones/status/1265655247055327233?s=12

Harry Potter HBO Max: https://variety.com/2020/digital/news/harry-potter-all-eight-movies-hbo-max-1234617154/
HBO MAX Content: https://techcrunch.com/2020/05/27/hbo-max-launches-today-heres-what-you-need-to-know/

Darkside Image: https://twitter.com/ZackSnyder/status/1265631646159564800/photo/1

Kingdom Hearts Disney+ All We Know: https://twitter.com/SkylerShuler/status/1265377359537909760?s=20

Green Lantern Justice League Dark “Cinematic Quality”: https://screenrant.com/green-lantern-justice-league-dark-tv-show-quality/

Scholomance Series Adaptation: https://deadline.com/2020/05/universal-mandeville-films-partner-on-naomi-noviks-scholomance-series-1202943726/

Philip Pullman Book Club: https://www.eventbrite.co.uk/e/book-club-with-philip-pullman-tickets-104065398408?ref=eios

Dragon Prince Moon Novel: https://twitter.com/thedragonprince/status/1265389493177081857

To Sleep in a sea of stars excerpts: https://www.tor.com/2020/05/26/preview-christopher-paolini-to-sleep-in-a-sea-of-stars/

Labyrinth Sequel: https://www.tor.com/2020/05/26/labyrinth-sequel-scott-derrickson-director-doctor-strange-jim-henson/

JK Rowling Book: https://twitter.com/DiscussingFilm/status/1265272261172506626

LOTR Reunion: https://twitter.com/joshgad/status/1265709499727241216

Brandon Sanderson Dark One: https://twitter.com/BrandSanderson/status/1265749988774043648

