# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Oh, Pretty Woman | Roy Orbison | Pomplamoose
 - [https://www.youtube.com/watch?v=o1dtiuAaR-w](https://www.youtube.com/watch?v=o1dtiuAaR-w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2020-05-28 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

A cover of Oh, Pretty Woman by Pomplamoose.

CREDITS

Lead Vocals: Nataly Dawn
Percussion: Rob Humphreys
Keys/Additional Percussion: Jack Conte
Background Vocals: Rainbow Girls (Vanessa May, Erin Chapin, and Caitlin Gowdey)
Guitar/Bass/Additional Background Vocals: Lauren O'Connell
Mixing/Mastering: Caleb Parker
Additional Engineering: Jeremy Lyon
Producer: Lauren O'Connell
Video Editor: Dominic Mercurio

Recorded from our homes in San Francisco & Los Angeles.

