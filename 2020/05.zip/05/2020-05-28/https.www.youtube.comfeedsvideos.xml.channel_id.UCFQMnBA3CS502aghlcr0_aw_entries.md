# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## The 5G Forcefield that costs $300
 - [https://www.youtube.com/watch?v=wzBdZWTelWE](https://www.youtube.com/watch?v=wzBdZWTelWE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-05-29 00:00:00+00:00

5G Bioshield is a high end USB stick that claims to create an Anti-5G forcefield REGARDLESS of whether it's plugged in.

We take a closer look to find out:

Pentest's breakdown: 
https://www.pentestpartners.com/security-blog/reverse-engineering-a-5g-bioshield/
5G Bioshield's Response is included here: 
https://www.bbc.com/news/technology-52810220

Music: 
Pay for that Money - The Defibulators

## The Water Wars
 - [https://www.youtube.com/watch?v=0_kub9sEE0k](https://www.youtube.com/watch?v=0_kub9sEE0k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-05-29 00:00:00+00:00

What is the dumbest luxury water product in the world?
Today we find out.

## How to Lose a Billion Dollars - Part 2
 - [https://www.youtube.com/watch?v=480-MGVY_eQ](https://www.youtube.com/watch?v=480-MGVY_eQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-05-28 00:00:00+00:00

Watch part 1 here! https://www.youtube.com/watch?v=VKyu6v-mqfY
FutureNet is a multi-level marketing ponzi scheme that recently collapsed leaving millions in trouble. Today we analyze their downfall and how they hoodwinked so many people.

Music: 
Will FM - forever
Pay for that Money - The Defibulators

