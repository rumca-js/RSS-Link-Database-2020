# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Charlie Parr - full session for Sounds Like Home festival for The Current
 - [https://www.youtube.com/watch?v=2U2JqTVtjbY](https://www.youtube.com/watch?v=2U2JqTVtjbY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-29 00:00:00+00:00

Charlie Parr performs a set of songs as part of The Current's virtual Sounds Like Home Festival.
Songs performed:
01:41 "Mag Wheels"
06:35 "On Stealing a Sailboat"
16:58 "Over the Red Cedar"
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Lady Lark - full session for Sounds Like Home festival for The Current
 - [https://www.youtube.com/watch?v=LjYV61GpQao](https://www.youtube.com/watch?v=LjYV61GpQao)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-29 00:00:00+00:00

Lady Lark performs a set of songs as part of The Current's virtual Sounds Like Home Festival.
Songs performed:
01:35 "My Way"
06:10 "Party Tonight"
10:02 "Shopping Bags"
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Yam Haus - full session for Sounds Like Home festival for The Current
 - [https://www.youtube.com/watch?v=_936lnUPyBw](https://www.youtube.com/watch?v=_936lnUPyBw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-29 00:00:00+00:00

Yam Haus perform a set of songs as part of The Current's virtual Sounds Like Home Festival.
Songs performed:
01:53 "Wow"
05:24 "The Thrill"
10:08 "Cute"
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Artists across America share hurt and anger over death of George Floyd (The Current Music News)
 - [https://www.youtube.com/watch?v=PDb6j64G8Y0](https://www.youtube.com/watch?v=PDb6j64G8Y0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-28 00:00:00+00:00

May 28, 2020: Hurt and anger over the death of George Floyd in police custody have spread from Minneapolis around the world. Artists are sharing grief and calls for action in memory of a man who came to the Twin Cities from Houston, where he was a member of the hip-hop scene.
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Remo Drive - full session for Sounds Like Home festival for The Current
 - [https://www.youtube.com/watch?v=6mxYVnYL_Kw](https://www.youtube.com/watch?v=6mxYVnYL_Kw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-28 00:00:00+00:00

Remo Drive perform a set of songs as part of The Current's virtual Sounds Like Home Festival.
Songs performed:
01:51 "Star Worship"
05:24 "Two Bux"
08:19 "Eat Sh*t"
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Sophia Eris - full session for Sounds Like Home festival for The Current
 - [https://www.youtube.com/watch?v=FPOPvqhckh4](https://www.youtube.com/watch?v=FPOPvqhckh4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-28 00:00:00+00:00

Sophia Eris performs a set of songs as part of The Current's virtual Sounds Like Home Festival.
Songs performed:
02:48 "Who's Got the Boom"
05:36 "Fanny Pack"
14:04 "Trap House"
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

