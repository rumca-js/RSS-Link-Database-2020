# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Bat Plagues and Murder Hornets? Why God?
 - [https://www.youtube.com/watch?v=NkeJhzswC_U](https://www.youtube.com/watch?v=NkeJhzswC_U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-05-29 00:00:00+00:00

Kyle and Ethan ask Dr. Frank Turek why an all-good and all-loving God would allow murder hornets.

## Biden: 'If You Don't Let Me Sniff Your Hair, You Ain't A Woman'
 - [https://www.youtube.com/watch?v=Er9bAH7Zu1c](https://www.youtube.com/watch?v=Er9bAH7Zu1c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-05-29 00:00:00+00:00

"The womenfolk know what's at stake in this election. It's hairy simple. Just let me vote on you, or you vote for me, the vote, b-b-b-blond applesauce baloney. Simple choice. If you don't let me smell your hair, you ain't a woman!" Biden said.

READ the full article 👀 https://babylonbee.com/news/biden-if-you-dont-let-me-sniff-your-hair-you-aint-a-woman

## Worship Song Generator
 - [https://www.youtube.com/watch?v=Bd1jQja4JUs](https://www.youtube.com/watch?v=Bd1jQja4JUs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-05-29 00:00:00+00:00

In this episode of The Babylon Bee podcast, Kyle and Ethan talk about the biggest stories of the week like how we now have an awesome worship song generator on the website now.

Also, Biden can now decide people's race and gender, Florida violates the laws of SCIENCE by not killing more of their citizens, and social media is cracking down on misleading avatars.





Subscribe to the Babylon Bee podcast on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531






Want to gain access to exclusive content and our writing forum, where you can submit and vote on headline pitches? Subscribe to the Bee! https://babylonbee.com/plans





Shop the official Babylon Bee store: https://shop.babylonbee.com





FOLLOW THE BEE:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

