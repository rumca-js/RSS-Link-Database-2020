# Source:BezPlanu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g, language:pl-PL

## Kwarantanna na Filipinach
 - [https://www.youtube.com/watch?v=bcl0Sn711gM](https://www.youtube.com/watch?v=bcl0Sn711gM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g
 - date published: 2020-05-28 00:00:00+00:00

Aktualny odcinek z Port Barton (Palawan, Filipiny)

Wszystkie odcinki chronologicznie: http://bit.ly/2MqAO7Q
(można też klikać w kartę "Następny odcinek" pojawiającą się pod koniec każdego filmu po prawej stronie u góry)

Na wycieczkę zabrał nas Maciek: https://www.instagram.com/maciejkurjanski/

Wsparcie na Patronite: http://bit.ly/2KsFTZk 
Instagram: http://instagram.com/bezplanu_czukesky 
Facebook: https://www.facebook.com/BezPlanu.tv 

Czas akcji: maj 2020 r.

Tłumaczenie na angielski: Michał Stadryniak
www.linkedin.com/in/michał-stadryniak-82b8491a6

