# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Grandma steps in front of police guns to protect grandson
 - [https://www.cnn.com/videos/us/2020/05/28/tye-anders-body-cam-arrest-midland-police-orig-eg-dp.cnn](https://www.cnn.com/videos/us/2020/05/28/tye-anders-body-cam-arrest-midland-police-orig-eg-dp.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 23:59:59+00:00

Police in Midland, Texas released video of the dramatic arrest of 21-year-old Tye Anders.

## The pandemic is changing how much frozen food we buy
 - [https://www.cnn.com/2020/05/28/business/frozen-food-sales-increasing-coronavirus/index.html](https://www.cnn.com/2020/05/28/business/frozen-food-sales-increasing-coronavirus/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 23:54:49+00:00

Pantry-loading has extended into freezer-stuffing in the pandemic, and that means frozen food items like Stouffer's Lasagna, Hot Pockets and Marie Callender's pies are flying off shelves.

## Trump's ridiculous comparison to justify his social media crackdown
 - [https://www.cnn.com/2020/05/28/politics/donald-trump-twitter-facebook-social-media-executive-order/index.html](https://www.cnn.com/2020/05/28/politics/donald-trump-twitter-facebook-social-media-executive-order/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 23:07:44+00:00

Moments before Donald Trump signed an executive order seeking to limit social media companies' ability to fact-check him, the President grasped for a comparison to justify the move.

## Suveillance video does not support police claims about George Floyd's arrest
 - [https://www.cnn.com/collections/george-floyd-intl-052820/](https://www.cnn.com/collections/george-floyd-intl-052820/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 23:01:17+00:00



## The legal limits of Trump's executive order
 - [https://www.cnn.com/2020/05/28/politics/trump-social-media-order-legal-limits/index.html](https://www.cnn.com/2020/05/28/politics/trump-social-media-order-legal-limits/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 22:23:31+00:00

As the White House prepares an executive order aimed at curtailing the power of social media platforms, legal experts are raising serious doubts about the proposal and whether it could survive judicial scrutiny.

## Jim Acosta: Trump's press secretary just told a whopper
 - [https://www.cnn.com/videos/politics/2020/05/28/kayleigh-mcenany-jim-acosta-trump-lie-vpx.cnn](https://www.cnn.com/videos/politics/2020/05/28/kayleigh-mcenany-jim-acosta-trump-lie-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 22:03:43+00:00

CNN's Jim Acosta asks the White House press secretary about President Trump's executive order targeting social media companies after Twitter fact-checked his tweets.

## A Kansas soldier likely saved 'countless lives' by driving into an active shooter, police say
 - [https://www.cnn.com/2020/05/28/us/fort-leavenworth-soldier-stops-active-shooter-trnd/index.html](https://www.cnn.com/2020/05/28/us/fort-leavenworth-soldier-stops-active-shooter-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 22:00:28+00:00

Master Sgt. David Royer stood upright with his interlocking hands in front of him Thursday as he matter-of-factly recounted how he rammed his truck into an active shooter before heading home to hug his kids, mow the grass and have dinner.

## Video doesn't support police claims about Floyd arrest
 - [https://www.cnn.com/2020/05/28/us/video-george-floyd-contradict-resist-trnd/index.html](https://www.cnn.com/2020/05/28/us/video-george-floyd-contradict-resist-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 21:51:59+00:00

• Outrage grows over George Floyd's death
• LIVE: Michigan Gov. activates National Guard
• These are the images of George Floyd you should see

## Boris Johnson outlines UK reopening guidelines
 - [https://www.cnn.com/2020/05/28/world/boris-johnson-outlines-uk-reopening-guidelines-intl/index.html](https://www.cnn.com/2020/05/28/world/boris-johnson-outlines-uk-reopening-guidelines-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 20:58:51+00:00

Britain will begin lifting coronavirus restrictions starting Monday in a phased approach, the UK Prime Minister Boris Johnson said at a press conference today.

## Van Jones calls out the dehumanization of African American men
 - [https://www.cnn.com/videos/us/2020/05/28/van-jones-george-floyd-death-lead-tapper-intv-vpx.cnn](https://www.cnn.com/videos/us/2020/05/28/van-jones-george-floyd-death-lead-tapper-intv-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 20:47:31+00:00

CNN's Van Jones discusses the death of George Floyd, an African American man who died after being held down by a police officer's knee, and the implications this has on racial issues in the United States.

## UConn senior suspected of killing 2 and leading a six-day manhunt was arrested
 - [https://www.cnn.com/2020/05/28/us/connecticut-peter-manfredonia-arrest/index.html](https://www.cnn.com/2020/05/28/us/connecticut-peter-manfredonia-arrest/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 20:26:13+00:00

The University of Connecticut student accused of killing two people, kidnapping another and leading police on a six-day manhunt was arrested in Maryland on Wednesday, authorities said.

## China's legislature approves national security law for Hong Kong that critics say threatens freedoms
 - [https://www.cnn.com/collections/intl-hong-kong-0527/](https://www.cnn.com/collections/intl-hong-kong-0527/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 20:06:52+00:00



## English Premier League will resume season on June 17
 - [https://www.cnn.com/2020/05/28/football/english-premier-league-return-spt-intl/index.html](https://www.cnn.com/2020/05/28/football/english-premier-league-return-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 19:38:54+00:00

The English Premier League season will resume without fans attending on June 17, according to multiple reports, including The Telegraph and Sky Sports.

## Las Vegas is reopening in one week
 - [https://www.cnn.com/travel/article/las-vegas-strip-reopening/index.html](https://www.cnn.com/travel/article/las-vegas-strip-reopening/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 19:35:11+00:00

Detailed housekeeping checklists. Half-empty casinos. Reservations-only dining. No shows, nightclubs or sporting events. These are just some of the realities that travelers can expect when Las Vegas reopens for tourist traffic next week.

## Two major US airlines prepare for potentially massive layoffs
 - [https://www.cnn.com/2020/05/28/business/american-airlines-delta-employee-buyouts/index.html](https://www.cnn.com/2020/05/28/business/american-airlines-delta-employee-buyouts/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 19:04:47+00:00

Plummeting demand for travel has forced two major US carriers — Delta Air Lines and American Airlines — to gut their workforces through voluntary exit programs and layoffs.

## David Guetta is hosting an epic dance party on an iconic rooftop this weekend
 - [https://www.cnn.com/2020/05/28/entertainment/david-guetta-concert-united-at-home-new-york-interview/index.html](https://www.cnn.com/2020/05/28/entertainment/david-guetta-concert-united-at-home-new-york-interview/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 18:21:26+00:00

David Guetta hopes to get you on your feet this weekend.

## What's going to happen to dance clubs?
 - [https://www.cnn.com/style/article/nightlife-and-club-culture-coronavirus/index.html](https://www.cnn.com/style/article/nightlife-and-club-culture-coronavirus/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 17:18:20+00:00

In nightclubs around the world, once-crowded dance floors have remained empty for months. If you need reminding, clubbing is close contact activity: People share drinks, hug, kiss and generally invade each others personal space until the early hours of the morning.

## Trump signs executive order targeting social media companies
 - [https://www.cnn.com/collections/intl-trump-twitter-0527/](https://www.cnn.com/collections/intl-trump-twitter-0527/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 16:51:44+00:00



## The F1 star swapping life in the fast lane for the farm
 - [https://www.cnn.com/2020/05/28/motorsport/daniel-ricciardo-ferrari-mclaren-formula-one-cmd-spt-intl/index.html](https://www.cnn.com/2020/05/28/motorsport/daniel-ricciardo-ferrari-mclaren-formula-one-cmd-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 16:25:53+00:00

Formula One played its own version of musical chairs after Sebastian Vettel revealed he was leaving Ferrari earlier this month.

## GOP operatives worry Trump will lose both the presidency and Senate majority
 - [https://www.cnn.com/2020/05/28/politics/republicans-trump-senate-2020-trouble/index.html](https://www.cnn.com/2020/05/28/politics/republicans-trump-senate-2020-trouble/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 16:07:27+00:00

A little more than three months ago, as Democrats cast their ballots in the Nevada caucuses, Republicans felt confident about their chances in 2020. The coronavirus seemed a distant, far-off threat. Democrats appeared poised to nominate a self-described socialist for president. The stock market was near a record high. The economy was roaring. President Donald Trump looked well-positioned to win a second term, and perhaps pull enough incumbent Republicans along with him to hold the party's majority in the Senate.

## Facebook and Twitter clash over fact-checking
 - [https://www.cnn.com/2020/05/28/media/jack-dorsey-donald-trump-twitter/index.html](https://www.cnn.com/2020/05/28/media/jack-dorsey-donald-trump-twitter/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 15:43:54+00:00

For years, Twitter and Facebook have enjoyed a healthy rivalry: They've competed for acquisitions, talent and advertising dollars, and sometimes gone so far as to copy each others' features in the never-ending pursuit to grow their audiences.

## Prince William reveals how his poor eyesight helped with nerves when public speaking
 - [https://www.cnn.com/2020/05/28/uk/prince-william-mental-health-contacts-intl-scli-gbr/index.html](https://www.cnn.com/2020/05/28/uk/prince-william-mental-health-contacts-intl-scli-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 15:42:30+00:00

Prince William is trying to get men to open up about their mental health, and for a new documentary on the issue he revealed his own unorthodox way of managing his nerves.

## 'Exceedingly rare' cognac from 1762 fetches $146,000 at auction
 - [https://www.cnn.com/style/article/rare-cognac-auction-1762-scli-intl/index.html](https://www.cnn.com/style/article/rare-cognac-auction-1762-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 15:22:25+00:00

A cognac from a 1762 vintage sold for £118,580 ($146,000) at an online auction on Thursday.

## Nissan to cut production capacity by 20% after suffering worst year since 2009
 - [https://www.cnn.com/2020/05/28/business/nissan-earnings-covid-intl-hnk/index.html](https://www.cnn.com/2020/05/28/business/nissan-earnings-covid-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 15:20:47+00:00

Nissan committed on Thursday to slashing production capacity by 20% and closing a plant in Spain as part of a sweeping overhaul announced after the Japanese carmaker revealed its first annual operating loss in more than a decade.

## No sports, no packed casinos. See Las Vegas begin reopening
 - [https://www.cnn.com/videos/travel/2020/05/28/las-vegas-reopen-may-travel-orig.cnn](https://www.cnn.com/videos/travel/2020/05/28/las-vegas-reopen-may-travel-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 14:54:08+00:00

You won't find crowds, concerts or conventions in Las Vegas this summer and gambling will be very different. Regardless, the city is still aiming to be a great escape.

## Preserved ancient Roman mosaic floor found in Italy
 - [https://www.cnn.com/videos/style/2020/05/28/roman-mosaic-floor-italy-newsource-orig-vpx.cnn](https://www.cnn.com/videos/style/2020/05/28/roman-mosaic-floor-italy-newsource-orig-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 14:02:12+00:00

A well preserved ancient Roman floor has been discovered under a vineyard in Negrar, Italy.

## A woman said she saw a wolverine on a Washington state beach. Officials didn't believe her
 - [https://www.cnn.com/2020/05/28/us/wolverine-spotting-washington-trnd/index.html](https://www.cnn.com/2020/05/28/us/wolverine-spotting-washington-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 13:55:43+00:00

When a woman told a wildlife official she thought she'd seen a wolverine on the beach of Washington state's Long Beach Peninsula they didn't believe her.

## Why Twitter will never win a war on truth with Trump
 - [https://www.cnn.com/2020/05/27/politics/twitter-trump-fact-check/index.html](https://www.cnn.com/2020/05/27/politics/twitter-trump-fact-check/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 13:33:45+00:00

On Tuesday afternoon, Twitter tried to strike a blow for truth.

## Netflix isn't sending any films or talent to festivals this awards season
 - [https://www.cnn.com/2020/05/28/entertainment/netflix-awards-season/index.html](https://www.cnn.com/2020/05/28/entertainment/netflix-awards-season/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 13:30:30+00:00

Netflix will not participate in the festival circuit this season.

## Katy Perry shows off baby bump in new photos
 - [https://www.cnn.com/2020/05/28/entertainment/katy-perry-baby-bump-trnd/index.html](https://www.cnn.com/2020/05/28/entertainment/katy-perry-baby-bump-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 13:13:33+00:00

Katy Perry used the space launch delay to talk about another bump.

## Teen rescued trying to cross New Zealand's South and North Islands in dinghy at night
 - [https://www.cnn.com/travel/article/new-zealand-rescue-dinghy-cook-strait-intl-scli/index.html](https://www.cnn.com/travel/article/new-zealand-rescue-dinghy-cook-strait-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 11:54:18+00:00

An 18-year-old who tried to cross New Zealand's Cook Strait in a motorized dinghy was rescued by police on Thursday morning after the dinghy broke down in perilous waters at night.

## How to safely go on a summer vacation during the coronavirus era
 - [https://www.cnn.com/travel/article/summer-vacation-during-coronavirus-trnd/index.html](https://www.cnn.com/travel/article/summer-vacation-during-coronavirus-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 11:27:16+00:00

When the coronavirus pandemic hit and borders closed all over the world, BreAnne Henry scrapped her plans for a summer trip to Ireland and Portugal.

## Judge in rape case removed after asking accuser if she 'closed her legs
 - [https://www.cnn.com/2020/05/28/us/nj-judge-removed-assault-trnd/index.html](https://www.cnn.com/2020/05/28/us/nj-judge-removed-assault-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 11:21:16+00:00

A New Jersey Superior Court judge was removed from his position after several misconduct claims, including because he asked an alleged rape victim how she tried to stop an assault.

## Some countries clap for medical workers. But not here
 - [https://www.cnn.com/2020/05/28/europe/russia-medical-workers-coronavirus-intl/index.html](https://www.cnn.com/2020/05/28/europe/russia-medical-workers-coronavirus-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 11:13:45+00:00

Frontline medical workers in the US, the UK and elsewhere may face major risks in their efforts to battle the coronavirus pandemic, but they've also seen an outpouring of public appreciation. In Russia, health workers say they face fear, mistrust -- and even open hostility.

## No screaming, please: Japan amusement parks issue new Covid-19 guidelines
 - [https://www.cnn.com/travel/article/japan-theme-parks-guidelines-screaming/index.html](https://www.cnn.com/travel/article/japan-theme-parks-guidelines-screaming/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 10:50:35+00:00

Thrill seekers in Japan will soon get to enjoy their favorite roller coasters again now that amusement parks around the country are reopening.

## Largest all-electric aircraft to make maiden flight
 - [https://www.cnn.com/travel/article/first-flight-largest-electric-aircraft-scli-intl/index.html](https://www.cnn.com/travel/article/first-flight-largest-electric-aircraft-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 10:21:15+00:00

As concerns over the environmental cost of flying continue to mount, green propulsion systems can offer an ethical alternative.

## Watch 'chaos' at looted Target in Minneapolis
 - [https://www.cnn.com/videos/us/2020/05/28/minneapolis-protests-george-floyd-target-loot-video-sidner-vpx.cnn](https://www.cnn.com/videos/us/2020/05/28/minneapolis-protests-george-floyd-target-loot-video-sidner-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 07:20:25+00:00

As heated protests over George Floyd's death continue in Minneapolis, CNN's Sara Sidner shows the 'chaotic' scenes as people looted Target and other local businesses.

## Fox News looks the other way as US passes 100,000 deaths
 - [https://www.cnn.com/2020/05/28/media/fox-news-coronavirus-deaths-reliable-sources/index.html](https://www.cnn.com/2020/05/28/media/fox-news-coronavirus-deaths-reliable-sources/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 05:07:25+00:00

A version of this article first appeared in the "Reliable Sources" newsletter. You can sign up for free right here.

## China's defense budget shows Xi's priorities as economy tightens
 - [https://www.cnn.com/2020/05/27/asia/china-military-budget-analysis-intl-hnk/index.html](https://www.cnn.com/2020/05/27/asia/china-military-budget-analysis-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 03:17:57+00:00

When China announced a 6.6% increase in its military budget last week while cutting substantially in other areas, analysts said it made one thing clear: Beijing senses an increasing security threat and is giving the People's Liberation Army the military muscle to deal with it.

## Pentagon moves to provide additional military aid to Ukraine
 - [https://www.cnn.com/2020/05/27/politics/pentagon-ukraine-military-aid/index.html](https://www.cnn.com/2020/05/27/politics/pentagon-ukraine-military-aid/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 03:07:54+00:00

The Pentagon has notified Congress that Ukraine's government has made the necessary progress on key institutional reforms, thereby justifying an additional $125 million in new military assistance, including patrol boats armed with remote-controlled 30mm autocannons, according to a US defense official and a congressional aide.

## Salvadoran leader says he takes hydroxychloroquine
 - [https://www.cnn.com/2020/05/27/americas/salvador-president-coronavirus-hydroxychloroquine-intl/index.html](https://www.cnn.com/2020/05/27/americas/salvador-president-coronavirus-hydroxychloroquine-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 03:06:16+00:00

Salvadoran President Nayib Bukele said Tuesday he uses hydroxychloroquine, the anti-malarial drug touted by US President Donald Trump as a potential coronavirus cure, even though international health experts have questioned its efficacy and have warned of harmful side-effects.

## 100,000 deaths: America's Covid-19 toll brings its own awful judgments on Trump's response
 - [https://www.cnn.com/collections/intl-trump-masks/](https://www.cnn.com/collections/intl-trump-masks/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 02:55:34+00:00



## She posted about equipment shortages. Now, she fears for her job
 - [https://www.cnn.com/videos/world/2020/05/27/russian-doctors-challenges-distrust-coronavirus-chance-tsr-pkg-vpx.cnn](https://www.cnn.com/videos/world/2020/05/27/russian-doctors-challenges-distrust-coronavirus-chance-tsr-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 02:09:07+00:00

Doctors in Russia are facing distrust as they battle the Covid-19 pandemic. CNN's Matthew Chance explores why.

## Biden says he hopes to name vice presidential pick around August 1
 - [https://www.cnn.com/2020/05/27/politics/joe-biden-running-mate/index.html](https://www.cnn.com/2020/05/27/politics/joe-biden-running-mate/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 01:22:37+00:00

Joe Biden announced at a fundraiser Wednesday evening that he hopes to name his running mate around August 1.

## India has an unlikely new type of period health educators: men
 - [https://www.cnn.com/2020/05/27/asia/menstruation-india-education-men-intl-hnk/index.html](https://www.cnn.com/2020/05/27/asia/menstruation-india-education-men-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 01:16:29+00:00

There's no trash can in the cramped washroom shared by almost 200 women at the congested Banjara Basti slum in Thane, a satellite city near Mumbai.

## US secretary of state's decision jeopardizes billions of dollars in trade and could rattle the global economy
 - [https://www.cnn.com/2020/05/27/politics/hong-kong-pompeo-certification/index.html](https://www.cnn.com/2020/05/27/politics/hong-kong-pompeo-certification/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 01:01:59+00:00



## Meet the 13-year-old who graduated from college with four associate's degrees
 - [https://www.cnn.com/2020/05/27/us/13-year-old-jack-rico-youngest-graduate-fullerton-college-trnd/index.html](https://www.cnn.com/2020/05/27/us/13-year-old-jack-rico-youngest-graduate-fullerton-college-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 00:30:21+00:00

With his love for video games and petty arguments with his older sister, Jack Rico might seem like any other 13-year-old.

## Disney CEO explains why it's safe to go back to Disney World
 - [https://www.cnn.com/2020/05/27/media/disney-world-open-bob-chapek/index.html](https://www.cnn.com/2020/05/27/media/disney-world-open-bob-chapek/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 00:21:02+00:00

Disney World is set to reopen, but is it safe to return to the "most magical place on earth"?

## Why the future of political art in Hong Kong is uncertain
 - [https://www.cnn.com/style/article/hong-kong-protests-political-art-intl-hnk/index.html](https://www.cnn.com/style/article/hong-kong-protests-political-art-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-05-28 00:19:09+00:00



