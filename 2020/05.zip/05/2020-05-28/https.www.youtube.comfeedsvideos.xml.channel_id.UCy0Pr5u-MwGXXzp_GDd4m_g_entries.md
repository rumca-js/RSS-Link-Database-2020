# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## BREAKING NEWS: Where are the mimes?
 - [https://www.youtube.com/watch?v=DT6tyFObpeY](https://www.youtube.com/watch?v=DT6tyFObpeY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2020-05-28 00:00:00+00:00

Tonight's top story delves into the silent disappearance of the world's mime population. 
Writer: Julie Nolke
Actors: Gina Phillips & Julie Nolke

