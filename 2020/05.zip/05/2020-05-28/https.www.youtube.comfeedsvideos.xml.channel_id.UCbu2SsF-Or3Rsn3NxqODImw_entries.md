# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Challenging You to Mortal Kombat! (PC) | GameSpot Community Fridays
 - [https://www.youtube.com/watch?v=OGM1X31X7M4](https://www.youtube.com/watch?v=OGM1X31X7M4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-29 00:00:00+00:00

Mortal Kombat 11's Aftermath expansion is out, which means its time to challenge you all! Join Jean-Luc and Ben for some online matches on the PC version of MK11.

## Free PS4 PlayStation Plus Games For June 2020 Revealed
 - [https://www.youtube.com/watch?v=76UozpuKykI](https://www.youtube.com/watch?v=76UozpuKykI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-29 00:00:00+00:00

The free PlayStation Plus PS4 games for June 2020 have been revealed, and both just so happen to be shooters from 2017. Subscribers can grab Call of Duty: WW2 and Star Wars Battlefront II.

## Free Xbox One And Xbox 360 Games With Gold For June 2020 Revealed
 - [https://www.youtube.com/watch?v=mI89IBb-SiU](https://www.youtube.com/watch?v=mI89IBb-SiU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-29 00:00:00+00:00

The free Games with Gold for June 2020 have been announced. Xbox One is getting Shantae & the Pirate's Curse and Coffee Talk. Xbox 360 is getting Sine Mora and an original Xbox game, Destroy All Humans.

## Minecraft Dungeons Review
 - [https://www.youtube.com/watch?v=AXt6WFrrKCg](https://www.youtube.com/watch?v=AXt6WFrrKCg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-29 00:00:00+00:00

Minecraft Dungeons is a welcoming dungeon-crawler entry point for newcomers and a lighthearted throwback for veterans.

Steve Watts spent roughly six hours completing Minecraft Dungeons on Default difficulty, and then another three exploring Adventure difficulty. He still gawks in amazement at ambitious Minecraft builds. Review code was provided by the publisher.

#MinecraftDungeons #GameSpotReview

## Mortal Kombat 11 Aftermath - Krazy Kombos
 - [https://www.youtube.com/watch?v=uJEaKOAxZvA](https://www.youtube.com/watch?v=uJEaKOAxZvA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-29 00:00:00+00:00

Mortal Kombat 11's next expansion, Aftermath, is out now. It features a new cinematic story, three new fighters--Sheeva, Fujin, and RoboCop--and three more skin packs launching over time. In a new GameSpot video, we're looking at some krazy kombos with the new characters.

Be sure to watch the full video to see RoboCop, Fujin, and Sheeva dish out some of the kraziest kombos you can imagine. If you're looking for a new way to style on your opponent, this is the video for you!

Mortal Kombat 11: Aftermath is out now for PS4, Xbox One, Nintendo Switch, and PC. The expansion costs $40 USD.

## PlayStation 5 - The Future Of Gaming Teaser Trailer
 - [https://www.youtube.com/watch?v=jbxCR8VbIiM](https://www.youtube.com/watch?v=jbxCR8VbIiM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-29 00:00:00+00:00

The future of PlayStation games will be revealed June 4, with all-new PS5 announcements.

## The Last Of Us Part 2 State Of Play, Xenoblade Chronicles - GS After Dark #43
 - [https://www.youtube.com/watch?v=u06s-TyejN4](https://www.youtube.com/watch?v=u06s-TyejN4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-29 00:00:00+00:00

On this week's episode of GameSpot After Dark, Michael Higham and Jean-Luc Seipke join us to talk about If Found, Saints Row: The Third Remastered, The Last Of Us Part 2, and Xenoblade Chronicles: Definitive Edition.

00:00:12 - Intro
00:04:48 - Maneater
00:10:01 - Saints Row: The Third Remastered
00:20:31 - If Found
00:30:20 - Xenoblade Chronicles: Definitive Edition
00:41:23 - Last of Us Part II Gameplay
00:48:08 - Listener Questions
01:09:40 - Outro

#GameSpotAfterDark

## Xbox Series X Will Improve Your Old Games! | Save State
 - [https://www.youtube.com/watch?v=8qoTjV8IXcs](https://www.youtube.com/watch?v=8qoTjV8IXcs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-29 00:00:00+00:00

Persia talks about Xbox Series X and its backwards compatibility techniques to make old Xbox games look better. These techniques will also double frame rates and provide HDR support to game that didn't have them before. All backwards compatible games will also have Quick Resume support which will allow you to navigate between multiple xbox games and generations with ease. 

Mortal Kombat creator, Ed Boon, appeared in a livestream recently to discuss PS5 and Xbox Series X. Persia goes over Boon's favorite feature for next-gen which is the slim-to-none loading times. Of course, great graphics are expected but Boon says load times are an underrated and door-opening part of next-gen gaming. 

Persia gives the PSA to Division 2 players as in-game audio files reveal spoilers for the Warlords of New York DLC. The in-game files are on the public test server and if you want to avoid having the story and future manhunt targets spoiled, steer clear of these audio leaks. 

E3 might not be happening this year but we've got you covered. This summer GameSpot is going to be hosting Play For All, a multi-week event that is going to be the best place for you to get all the latest gaming news, features, interviews, and live streams. 

Not only that, but we're also partnering with Direct Relief to raise funds for healthcare workers risking their lives daily on COVID-19 relief efforts. We'll have over 100 hours of awesome content that will feature the GameSpot team, as well as friends from across the industry including the Giant Bomb crew, Kinda Funny's Greg Miller, NoClips Danny O'Dwyer, and many more we'll be announcing over the coming weeks. 

This is your Save State for Thursday, May 28th.

#SaveState #GameSpot

## GameSpot's Play For All - What To Expect
 - [https://www.youtube.com/watch?v=mLwfT4PE6ak](https://www.youtube.com/watch?v=mLwfT4PE6ak)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-28 00:00:00+00:00

Starting from June 1, GameSpot is teaming up with the biggest names in games and entertainment to raise money for the COVID charity, Direct Relief, all the while covering the hottest gaming announcements.

#PlayForAll #GameSpot

## Mortal Kombat 11: Aftermath - Every New Fatality, Stage Fatality and Fatal Blow
 - [https://www.youtube.com/watch?v=-n9hePz42nU](https://www.youtube.com/watch?v=-n9hePz42nU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-28 00:00:00+00:00

The Aftermath expansion is now out for Mortal Kombat 11, adding a brand-new story, playable characters, and skins to developer NetherRealm Studios' fighting game. The three new characters are Robocop (yes, really), Sheeva, and Fujin.

In the video above, we take a look at all of the fatalities and fatal blows for the three new characters added in Aftermath. We also check out every new stage fatality as well, just to really make sure we fulfill that gruesome murder quota for any video having to do with Mortal Kombat.

If you like what you see, there are three ways to buy Mortal Kombat 11: Aftermath. If you already have Mortal Kombat 11, you can just buy the Aftermath expansion for $40 USD or the Aftermath + Kombat Pack bundle for $50. If you don't have NetherRealm's game yet, you can also purchase Mortal Kombat 11: Aftermath Kollection--which includes the base game, the Kombat Pack, and Aftermath.

In GameSpot's Mortal Kombat 11 review, Edmond Tran wrote, "MK11 isn't just a sequel for series fans and NetherRealm devotees, it's a gateway into the realm of fighting games for anyone who has a passing interest in watching ruthless warriors beat each other silly. Streamlined mechanics keep the act of fighting furiously exciting no matter what your skill level, and comprehensive tutorials encourage you to dig into the nitty-gritty. There's a diverse roster of interesting characters and playstyles, and the story mode is an entertaining romp. The randomization of Krypt rewards and the odd issue with the game's always-online nature can occasionally chip away at your patience, but Mortal Kombat 11 absolutely hits where it matters."

#MK11Aftermath #MortalKombat11Aftermath #GameSpot

## Outriders New Gameplay Livestream | Outriders Broadcast #1
 - [https://www.youtube.com/watch?v=Q_R00wvqQxc](https://www.youtube.com/watch?v=Q_R00wvqQxc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-28 00:00:00+00:00

The first Outriders broadcast will showcase new gameplay, new locations, never-before-seen powers, character class breakdowns, development updates, and more. Tune in May 28th at 9AM PT.

## PS5 Reveals Might Be Coming Very Soon | Save State
 - [https://www.youtube.com/watch?v=8HeG5MZo2qg](https://www.youtube.com/watch?v=8HeG5MZo2qg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-28 00:00:00+00:00

According to a Bloomberg report, Sony has PlayStation 5 reveals on the way, as soon as next week. Whether it'll be focused on hardware, games, or both, is still speculative. In confirmed news, Square Enix announced a new trilogy of Dragon Quest games based on a classic manga series, but at this time has only been announced for release in Japan.

Rockstar plans to spend $89 million on marketing in 2023. What the promotion is for hasn't been confirmed yet, but it's very likely to be Grand Theft Auto 6. Lastly, Fast and Furious: Crossroads gets a summer release date. For all the latest gaming news stories, be sure to get your Save State every Monday through Thursday on GameSpot.

#SaveState #GameSpot

## The Last Of Us Part 2 - Inside The Details
 - [https://www.youtube.com/watch?v=4c319gRkE-Y](https://www.youtube.com/watch?v=4c319gRkE-Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-28 00:00:00+00:00

Learn more about the inspiration behind the incredible amount of detail in The Last of Us Part II.

## The Last Of Us Part 2 Exploration & Combat: Everything You Need To Know In Under 4 Minutes
 - [https://www.youtube.com/watch?v=jHItQr4LplA](https://www.youtube.com/watch?v=jHItQr4LplA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-28 00:00:00+00:00

Sony's latest State of Play stream was all about The Last of Us Part 2, and it gave us some insight into the PS4 exclusive's exploration and combat against warring factions.

#TheLastOfUs2 #TLOU2 #GameSpot

