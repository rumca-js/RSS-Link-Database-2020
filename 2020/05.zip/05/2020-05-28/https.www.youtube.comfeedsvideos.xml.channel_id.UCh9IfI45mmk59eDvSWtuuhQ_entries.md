# Source:Ryan George, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ, language:en-US

## If The News Was A Person
 - [https://www.youtube.com/watch?v=IBw61xgcfCw](https://www.youtube.com/watch?v=IBw61xgcfCw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ
 - date published: 2020-05-28 00:00:00+00:00

Hi there please subscribe so I can feed my cats.
Twitter/Instagram: @TheRyanGeorge

Also I guess I should include a description with some keywords, right? The news. That's something that I talk about in this video. Hawaiian cruise ships too I guess. The dog from Lassie. Alright, that should be some solid SEO right there. Thanks.

