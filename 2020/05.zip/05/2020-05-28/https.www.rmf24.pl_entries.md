## Onet: Polski rząd przepłacał za testy na koronawirusa z Turcji - RMF 24
 - [https://www.rmf24.pl/raporty/raport-koronawirus-z-chin/polska/news-onet-polski-rzad-przeplacal-za-testy-na-koronawirusa-z-turcj,nId,4521809#crp_state=1](https://www.rmf24.pl/raporty/raport-koronawirus-z-chin/polska/news-onet-polski-rzad-przeplacal-za-testy-na-koronawirusa-z-turcj,nId,4521809#crp_state=1)
 - RSS feed: https://www.rmf24.pl
 - date published: 2020-05-28 05:37:59+00:00

Onet: Polski rząd przepłacał za testy na koronawirusa z Turcji - RMF 24

