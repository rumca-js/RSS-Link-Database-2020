# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Joe Rogan on People Criticizing Governor Newsom for Reopening "Too Soon"
 - [https://www.youtube.com/watch?v=1cEPMN-l3mE](https://www.youtube.com/watch?v=1cEPMN-l3mE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-29 00:00:00+00:00

Taken from JRE #1483 w/Jesus Trejo:
https://youtu.be/TxEZcP5hmP8

## What If You Had to Live Your Life Over and Over (Until You Got It Right)? w/Jesus Trejo | Joe Rogan
 - [https://www.youtube.com/watch?v=WCFKPJrt0Zk](https://www.youtube.com/watch?v=WCFKPJrt0Zk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-29 00:00:00+00:00

Taken from JRE #1483 w/Jesus Trejo:
https://youtu.be/TxEZcP5hmP8

## Jordan Jonas Field Dressed a Moose with Just a Leatherman
 - [https://www.youtube.com/watch?v=QOS8bv5_oaw](https://www.youtube.com/watch?v=QOS8bv5_oaw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-28 00:00:00+00:00

Taken from JRE #1482 w/Jordan Jonas: https://youtu.be/vrCNpDigVxA

## Jordan Jonas Had a Run In with a Bear in Russia
 - [https://www.youtube.com/watch?v=pQ6NWXKMK0w](https://www.youtube.com/watch?v=pQ6NWXKMK0w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-28 00:00:00+00:00

Taken from JRE #1482 w/Jordan Jonas: https://youtu.be/vrCNpDigVxA

## Jordan Jonas Lived in a Remote Village in Siberia | Joe Rogan
 - [https://www.youtube.com/watch?v=ejtOIh-YJB0](https://www.youtube.com/watch?v=ejtOIh-YJB0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-28 00:00:00+00:00

Taken from JRE #1482 w/Jordan Jonas:
https://youtu.be/vrCNpDigVxA

## Jordan Jonas Used a Homemade Fishing Reel on “Alone”
 - [https://www.youtube.com/watch?v=6wXpsBqW_4o](https://www.youtube.com/watch?v=6wXpsBqW_4o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-28 00:00:00+00:00

Taken from JRE #1482 w/Jordan Jonas: https://youtu.be/vrCNpDigVxA

## Jordan Jonas on Hunting Moose and Lugging Cameras on “Alone”
 - [https://www.youtube.com/watch?v=j-rJRizYNVA](https://www.youtube.com/watch?v=j-rJRizYNVA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-28 00:00:00+00:00

Taken from JRE #1482 w/Jordan Jonas: https://youtu.be/vrCNpDigVxA

## “Alone” Winner Jordan Jonas Tangled with a Wolverine
 - [https://www.youtube.com/watch?v=3RPCUwOBXTw](https://www.youtube.com/watch?v=3RPCUwOBXTw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-05-28 00:00:00+00:00

Taken from JRE #1482 w/Jordan Jonas: https://youtu.be/vrCNpDigVxA

