# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Mortal Kombat 11: Aftermath - Video Game Review
 - [https://www.youtube.com/watch?v=x-S7p1OhnEY](https://www.youtube.com/watch?v=x-S7p1OhnEY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-05-29 00:00:00+00:00

Thanks to Raycon for sponsoring this video,
Go to https://buyraycon.com/jahns for 15% off your order!

MK11 gives us a surprise in the form of new stages, new stage fatalities, 3 new characters, and a continuing story. Does it give you bang for your buck? Here's my review for MORTAL KOMBAT 11: AFTERMATH!

#MortalKombat #MK11

## Face/Off - Movie Review
 - [https://www.youtube.com/watch?v=e1tURUp6uAM](https://www.youtube.com/watch?v=e1tURUp6uAM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-05-28 00:00:00+00:00

Another classic 90's John Woo action movie, this time with Nicholas Cage & John Travolta swapping roles. Here's my review of FACE/OFF!

#FaceOff

