## Roko's Basilisk: The Most Terrifying Thought Experiment
 - [https://www.youtube.com/watch?v=ut-zGHLAVLI](https://www.youtube.com/watch?v=ut-zGHLAVLI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFbtcTaMFnOAP0pFO1L8hVw
 - date published: 2020-05-28 21:22:21+00:00

Roko's Basilisk: The Most Terrifying Thought Experiment

