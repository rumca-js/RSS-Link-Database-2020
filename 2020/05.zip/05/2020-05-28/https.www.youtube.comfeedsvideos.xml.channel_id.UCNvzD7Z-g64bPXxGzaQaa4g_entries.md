# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 38 NEW PS5 Games CONFIRMED? SEGA'S Top Secret Plans, & More
 - [https://www.youtube.com/watch?v=iYCFEp8477o](https://www.youtube.com/watch?v=iYCFEp8477o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-05-29 00:00:00+00:00

A magazine leak reveals a predictable list of PS5 games, Xbox outlines backwards compatibility on Series X, Sonic returns, and more stuff in a week FULL of gaming news.

*Jakes twitter: https://twitter.com/jakebaldino 
*Instagram: https://goo.gl/HH6mTW 

 discord.gg/gameranx 

 Weekly giveaway link: https://goo.gl/forms/a7zCtr1HuTkzWuOo2 



 ~~~~STORIES~~~~

PS5 reveal happening 
https://blog.playstation.com/2020/05/29/youre-invited-a-look-at-the-future-of-gaming-on-playstation-5/

Some confirmed games
https://www.reddit.com/r/PS4/comments/grdv7x/games_confirmed_for_the_ps5_from_the_newest_issue/

This holiday season
https://www.gamesindustry.biz/articles/2020-05-29-sonys-jim-ryan-its-time-to-give-fans-something-that-can-only-be-enjoyed-on-playstation-5

Xbox backwards compatibility 
https://news.xbox.com/en-us/2020/05/28/xbox-series-x-next-generation-backward-compatibility/?fbclid=IwAR0iFSHsHDCUEWplzNe3Kln5h1_k21oO26G5jUr4d3O5VGXtxI1vtDXrims
https://www.tomshardware.com/news/xbox-series-x-backwards-compatibility-runs-faster

What is Sega planning?
https://www.express.co.uk/entertainment/gaming/1287702/SEGA-announcement-teased-rile-up-games-industry




Dead By Daylight Silent Hill
https://youtu.be/N8VGnRN5-mc

Dutch in Predator
https://youtu.be/ZFeuXUfjwAU

BioShock switch
https://youtu.be/ut9Ba_-KDSM

New TLOU2 gameplay
https://youtu.be/_Yr1tQtZVbc


Arkane documentary (MUST WATCH):
https://youtu.be/h4kdqwdbZZ8


Another Sonic movie
https://variety.com/2020/film/news/sonic-the-hedgehog-sequel-1234619356/

## 10 Video Game Bosses Who KEEP COMING BACK
 - [https://www.youtube.com/watch?v=iZUSpzlcQnw](https://www.youtube.com/watch?v=iZUSpzlcQnw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-05-28 00:00:00+00:00

Some video game bosses just refuse to be defeated, even after multiple attempts. Here are some of our favorite examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

