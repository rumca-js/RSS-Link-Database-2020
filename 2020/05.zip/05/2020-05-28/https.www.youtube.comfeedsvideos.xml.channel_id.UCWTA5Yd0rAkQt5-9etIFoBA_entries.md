# Source:SciFun, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCWTA5Yd0rAkQt5-9etIFoBA, language:pl-PL

## Igła kleszcza pod mikroskopem badawczym
 - [https://www.youtube.com/watch?v=c8Q4t8rNPMI](https://www.youtube.com/watch?v=c8Q4t8rNPMI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCWTA5Yd0rAkQt5-9etIFoBA
 - date published: 2020-05-29 00:00:00+00:00

Polski kleszcz i jego hypostom widziany w świetle odbitym mikroskopu badawczego.

Źródła:
https://www.nature.com/articles/s41598-019-56811-2

