# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## "XT" CPUs coming AT YA! - WAN Show May 29, 2020
 - [https://www.youtube.com/watch?v=0sxFWAiKnHg](https://www.youtube.com/watch?v=0sxFWAiKnHg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-05-29 00:00:00+00:00

Get the Anker PowerWave II Pad on Amazon at https://s.krpax.com/r/F8HbpD

Use offer code LTT to save 10% on Savage Jerky at https://lmg.gg/savagejerky 

Sign up for Private Internet Access VPN at https://lmg.gg/piawan 

Buy an LTT shirt, hoodie, hat, and even our own water bottle at https://lmg.gg/wanlttstore

Check out Carpool Critics, our new movie podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Podcast Download: https://dts.podtrac.com/redirect.mp3/traffic.libsyn.com/secure/linustechtips/XT__CPUs_coming_AT_YA_-_WAN_Show_May_29_2020.mp3

Timestamps: (Courtesy of Imp3rial)

0:00 – LIVE
2:42 – Intro
3:18 – Story Time With Linus
11:10 – XT Ryzen 3rd Gen Rumor
20:19 – Social Media Content Censorship and Executive Orders
35:31 – Luke Disappears
37:32 – Sponsors!
 Savage Jerky: savagejerky.com Use Code LTT
 PIA: lmg.gg/piawan
 Anker: https://s.krpax.com/r/F8HbpD
 and of course, lttstore.com
41:50 – PewDiePie Says Linus Must Lift to Become Chad Linus
56:00 – Texas Instruments Banning Assembly Code on Its Calculators
59:07 – SpaceX Launch Delayed
1:00:19 – MacOS 10 Update Has Tool To Keep It’s Battery Healthier
1:02:39 – Anti-5G USB Sticks
1:07:16 – Super Chats
1:14:36 – Outro
1:14:58 – OFFLINE

## The All-AORUS Gaming PC Build!
 - [https://www.youtube.com/watch?v=ZDLbakOm3mM](https://www.youtube.com/watch?v=ZDLbakOm3mM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-05-29 00:00:00+00:00

Thanks to GIGABYTE AORUS for sponsoring this video! Enter their giveaway for a chance to win a GIGABYTE G32QC Gaming Monitor at https://geni.us/g32qcgiveaway
 
Buy GIGABYTE GPU's on Newegg at https://geni.us/ggMkMuk
Buy Z490 AORUS MASTER: https://geni.us/sUNziXc
Buy AORUS RGB AIO Liquid Cooler 280 on Amazon: https://geni.us/ATH3
Buy AORUS RGB Memory 16GB 3600MHz on Amazon: https://geni.us/2lYHcKb
Buy AORUS RGB NVME AIC 1TB SSD on Amazon: https://geni.us/zTlHW
Buy AORUS P750W 80+ GOLD MODULAR: https://www.gigabyte.com/us/Power-Supply/GP-AP750GM#kf
Buy GIGABYTE C200 GLASS Case: https://geni.us/CRD5a6X
Buy GIGABYTE G32QC Gaming Monitor on Newegg: https://geni.us/Jjb1
Buy AORUS M5 Mouse on Amazon: https://geni.us/GjQOZz
Buy AORUS AMP900 Mousepad: https://www.gigabyte.com/us/Mouse/Extended-Gaming-Mouse-Pad#kf
Buy AORUS K9 Keyboard: https://www.gigabyte.com/us/Keyboard/AORUS-K9-Optical#kf
Buy Intel 10th Gen on Newegg: https://geni.us/VpANDQp

## We made the SLOWEST BRAND NEW PC!
 - [https://www.youtube.com/watch?v=3wtKZCHH7l0](https://www.youtube.com/watch?v=3wtKZCHH7l0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-05-28 00:00:00+00:00

Thanks to LastPass for sponsoring a portion of this video. Click here to start using LastPass: https://lastpass.onelink.me/HzaM/2020Q2MayLinus

We’ve come a long way in PC technology in the last decade, and it made us wonder: how slow is the slowest brand new PC you can build? Well today, we’ll find out how slow a desktop can be with reasonable selections if you are on a budget, and compare them to what you SHOULD by, to get a sense of just how slow you can go.

Buy Ryzen 3100:
On Amazon (PAID LINK): https://geni.us/tHTTxo
On Newegg (PAID LINK): https://geni.us/BcE7l

Buy 2TB BarraCuda HDD:
On Amazon (PAID LINK): https://geni.us/P0pR
On Newegg (PAID LINK): https://geni.us/bQrYXv

Buy XFX RX570
On Amazon (PAID LINK): https://geni.us/SJjxn
On Newegg (PAID LINK): https://geni.us/X5pl5L

Buy ASRock B450M Pro4s
On Amazon (PAID LINK): https://geni.us/XNHM
On Newegg (PAID LINK): https://geni.us/h6899XE

Buy HyperX Fury 2x4 3200Ghz
On Amazon (PAID LINK): https://geni.us/koZB
On Newegg (PAID LINK): https://geni.us/AwRNEe

Buy Corsair CV550 PSU
On Amazon (PAID LINK): https://geni.us/WfmjJq
On Newegg (PAID LINK): https://geni.us/NlfMK

Buy WD Blue 250GB SSD
On Amazon (PAID LINK): https://geni.us/0LU4dz
On Newegg (PAID LINK): https://geni.us/ZQLyA

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1201351-we-made-the-slowest-new-pc/

GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Mech Keyboard: https://geni.us/RecNBTI
NEEDforSEAT Gaming Chairs: https://geni.us/needforseat
Get a Displate Metal Print at https://lmg.gg/displateltt
Use code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Gear on Amazon: https://geni.us/lmgamazon
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0 https://lmg.gg/fxHYK 
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://lmg.gg/Q9yyQ 
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://lmg.gg/8upii

