## Koronawirus: Polska. Rząd przepłacał za testy
        
        - Wiadomości
 - [https://wiadomosci.onet.pl/tylko-w-onecie/koronawirus-polska-rzad-przeplacal-za-testy/lqmcpcx](https://wiadomosci.onet.pl/tylko-w-onecie/koronawirus-polska-rzad-przeplacal-za-testy/lqmcpcx)
 - RSS feed: https://wiadomosci.onet.pl
 - date published: 2020-05-28 06:55:50+00:00

Koronawirus: Polska. Rząd przepłacał za testy
        
        - Wiadomości

