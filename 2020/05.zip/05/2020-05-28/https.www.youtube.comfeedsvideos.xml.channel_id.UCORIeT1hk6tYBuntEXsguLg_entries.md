# Source:PostmodernJukebox, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg, language:en-US

## I Only Have Eyes For You (The Flamingos) - Postmodern Jukebox Cover ft. Sunny Holiday
 - [https://www.youtube.com/watch?v=4ZQh50kld4s](https://www.youtube.com/watch?v=4ZQh50kld4s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg
 - date published: 2020-05-29 00:00:00+00:00

Download & Stream The Song Here: https://pmjlive.com/okcrooner
Experience PMJ Live: https://www.pmjtour.com
Shop PMJ Music/Merch:  https://shoppmj.com
Follow Us On Spotify: https://www.pmjlive.com/pmjspotify

Over the past couple of years, Sunny Holiday has worked behind the scenes with PMJ in a variety of roles, including choreographer, wardrobe consultant, and assistant director on tour.  However, those that know Sunny also know that she is a gifted vocalist and fantastic performer - as well as an old soul - and we're excited for her to make her official PMJ debut on the 1959 classic, "I Only Have Eyes For You," with Scott Bradlee on piano. 
____________________________________________

Follow The Musicians:
Miss Sunny Holiday (Vocals)
Facebook: https://www.facebook.com/misssunnyholiday/
Instagram: https://www.instagram.com/misssunnyholiday/
Twitter: https://twitter.com/missunnyholiday

Scott Bradlee (Piano):
YouTube: http://youtube.com/scottbradlee
Facebook: http://facebook.com/scottbradleemusic
Instagram: http://instagram.com/scottbradlee
Twitter: http://twitter.com/scottbradlee

____________________________________________
#IOnlyHaveEyesForYou #Cover

