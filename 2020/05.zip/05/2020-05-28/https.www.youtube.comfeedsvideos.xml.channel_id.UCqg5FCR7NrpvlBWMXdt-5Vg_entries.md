# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Resolutiion | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=NZi-Lt2tOww](https://www.youtube.com/watch?v=NZi-Lt2tOww)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-05-29 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

KC Nwosu reviews Resolutiion, developed by Monolith of Minds. 

Resolutiion on Steam: https://store.steampowered.com/app/975150/Resolutiion/

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Shirley Curry and Backseat Gaming | The Escapist Show
 - [https://www.youtube.com/watch?v=SnZZqWMxFvY](https://www.youtube.com/watch?v=SnZZqWMxFvY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-05-29 00:00:00+00:00

The Escapist Show (Extended) Podcast is now on iTunes, Spotify and Soundcloud. https://soundcloud.com/nick-calandra-612440979/shirley-curry-backseat-gaming

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

This week on The Escapist Show, Nick and Jack discuss the games they've been playing, Shirley Curry and backseat gaming, The Snyder Cut and video game leaks.

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

