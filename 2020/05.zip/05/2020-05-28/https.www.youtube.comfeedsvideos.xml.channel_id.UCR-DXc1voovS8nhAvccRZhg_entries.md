# Source:Jeff Gerling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg, language:en-US

## 25K Special! Open Source Pay it Forward 8GB Pi 4 Giveaway
 - [https://www.youtube.com/watch?v=XpYew5nGo2o](https://www.youtube.com/watch?v=XpYew5nGo2o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg
 - date published: 2020-05-29 00:00:00+00:00

Donate, then fill out this form: https://docs.google.com/forms/d/1pb-MNCK0AzA5e6rRiy1fSLXeb25Xsr_s0TKvqtLZ880/edit

To celebrate 25,000 subscribers on my YouTube channel, I thought I'd do a giveaway. And what better prize than the BRAND NEW Raspberry Pi 4 8GB model B computer I just got in the mail today!

To enter, just donate to any open source project, contributor, or maintainer, and fill out the Google form linked above. See the form for all rules/instructions.

I won't link to my Patreon/GitHub sponsor URLs because I want you to go find another open source contributor and support *that* person today! Thanks for watching, see you soon!

## Raspberry Pi 4 goes 8GB, Pi OS goes 64 bit!
 - [https://www.youtube.com/watch?v=aidkpsWlB40](https://www.youtube.com/watch?v=aidkpsWlB40)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg
 - date published: 2020-05-28 00:00:00+00:00

Today the Raspberry Pi Foundation announced a new $75 Raspberry Pi 4 8GB model, and to go along with that huge increase in RAM, they're releasing a new 64-bit Operating System, and changing the name from 'Raspbian' to 'Raspberry Pi OS.'

I'll share my first experiences with the 64-bit OS in this video.

Raspberry Pi Foundation blog post announcement: https://www.raspberrypi.org/blog/8gb-raspberry-pi-4-on-sale-now-at-75/

Download the 64-bit OS beta: https://www.raspberrypi.org/forums/viewtopic.php?f=117&t=275370

My blog post with benchmarks and more info: https://www.jeffgeerling.com/blog/2020/raspberry-pi-4-goes-8gb-and-raspberry-pi-os-goes-64-bit

Support me on Patreon: https://www.patreon.com/geerlingguy
Sponsor me on GitHub: https://github.com/sponsors/geerlingguy

