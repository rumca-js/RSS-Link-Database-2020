# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Games Where You PLAY AS THE ZOMBIE
 - [https://www.youtube.com/watch?v=Z0Qs6IxP3S8](https://www.youtube.com/watch?v=Z0Qs6IxP3S8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-05-05 00:00:00+00:00

Everyone loves a good zombie video game. Here are favorite games where you actually PLAY as a zombie (and sometimes a skeleton-zombie).
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 10 Best Games of 2004 We NEVER FORGOT
 - [https://www.youtube.com/watch?v=JZW8zv_xTyU](https://www.youtube.com/watch?v=JZW8zv_xTyU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-05-04 00:00:00+00:00

2004 was an absolute powerhouse year for video games. Check out some of our favorite games here - you'll be surprised by just how many historic games released in 2004.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

