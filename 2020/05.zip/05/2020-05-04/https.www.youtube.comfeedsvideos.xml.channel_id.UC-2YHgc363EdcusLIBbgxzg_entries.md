# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## The Golden Ratio Is BS (Kinda) | Answers With Joe
 - [https://www.youtube.com/watch?v=73xCxHv2sXo](https://www.youtube.com/watch?v=73xCxHv2sXo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2020-05-04 00:00:00+00:00

Get a free audiobook and UNLIMITED Originals when you sign up at http://www.audible.com/joescott or text "joescott" to 500-500.
The Golden Ratio is a mathematical construct that has been observed all throughout nature, architecture, and art. And some think it's a universal constant, and divine. But... is it? Or are we only seeing what we want to see?

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

https://www.mathsisfun.com/numbers/fibonacci-sequence.html

https://www.livescience.com/37704-phi-golden-ratio.html

https://www.damninteresting.com/the-baader-meinhof-phenomenon/

https://www.sutori.com/story/timeline-of-the-golden-ratio-used-within-mathematics-and-art--BNGazW8V1yb898TTqrvB2nf1

https://www.bbvaopenmind.com/en/science/mathematics/fibonacci-and-his-magic-numbers/

https://builtin.com/hardware/simulation-theory

https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4141622/

https://www.iflscience.com/plants-and-animals/why-is-the-golden-ratio-seem-to-be-everywhere-in-nature/

https://www.forbes.com/sites/ethansiegel/2015/08/22/it-takes-26-fundamental-constants-to-give-us-our-universe-but-they-still-dont-give-everything/#6fbd35b34b86

