# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Christine & The Queens (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=3bavZe47um4](https://www.youtube.com/watch?v=3bavZe47um4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-05 00:00:00+00:00

Chris, aka Christine & The Queens, performs an exclusive set from home and joins Morgan, live on KEXP on Tuesday, May 5, at 12pm PT.

## Ayron Jones - Boys From The Puget Sound (Live on KEXP)
 - [https://www.youtube.com/watch?v=OHp5Rse5ass](https://www.youtube.com/watch?v=OHp5Rse5ass)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-04 00:00:00+00:00

http://KEXP.ORG presents Ayron Jones performing "Boys From The Puget Sound" live in the KEXP studio. Recorded January 9, 2020.

Host: Eva Walker
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Alaia D'Alessandro

http://kexp.org
https://www.ayronjonesmusic.com

## Ayron Jones - Emily (Live on KEXP)
 - [https://www.youtube.com/watch?v=BQxQEo6navs](https://www.youtube.com/watch?v=BQxQEo6navs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-04 00:00:00+00:00

http://KEXP.ORG presents Ayron Jones performing "Emily" live in the KEXP studio. Recorded January 9, 2020.

Host: Eva Walker
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Alaia D'Alessandro

http://kexp.org
https://www.ayronjonesmusic.com

## Ayron Jones - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=kWYzdhluQpY](https://www.youtube.com/watch?v=kWYzdhluQpY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-04 00:00:00+00:00

http://KEXP.ORG presents Ayron Jones performing live in the KEXP studio. Recorded January 9, 2020.

Songs:
Boys From The Puget Sound
Emily
My Love Remains
Take Me Away

Host: Eva Walker
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Alaia D'Alessandro

http://kexp.org
https://www.ayronjonesmusic.com

## Ayron Jones - My Love Remains (Live on KEXP)
 - [https://www.youtube.com/watch?v=2HUMmmPE8io](https://www.youtube.com/watch?v=2HUMmmPE8io)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-04 00:00:00+00:00

http://KEXP.ORG presents Ayron Jones performing "My Love Remains" live in the KEXP studio. Recorded January 9, 2020.

Host: Eva Walker
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Alaia D'Alessandro

http://kexp.org
https://www.ayronjonesmusic.com

## Ayron Jones - Take Me Away (Live on KEXP)
 - [https://www.youtube.com/watch?v=vzsvCt6WDe0](https://www.youtube.com/watch?v=vzsvCt6WDe0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-05-04 00:00:00+00:00

http://KEXP.ORG presents Ayron Jones performing "Take Me Away" live in the KEXP studio. Recorded January 9, 2020.

Host: Eva Walker
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Alaia D'Alessandro

http://kexp.org
https://www.ayronjonesmusic.com

