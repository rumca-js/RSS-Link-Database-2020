# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Should Epic Games Store Exclusives Be Boycotted? | Slightly Civil War
 - [https://www.youtube.com/watch?v=VspAL677Oj8](https://www.youtube.com/watch?v=VspAL677Oj8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-05-04 00:00:00+00:00

Podcast on Soundcloud: https://soundcloud.com/user-944993929/slightly-civil-war-should-epic-games-store-exclusives-be-boycotted or search "The Escapist" on Spotify / iTunes to find the podcast there.

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

This week on Slightly Civil War, Yahtzee and Jack debate whether or not consumers should boycott exclusives on the Epic Games Store. 

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

