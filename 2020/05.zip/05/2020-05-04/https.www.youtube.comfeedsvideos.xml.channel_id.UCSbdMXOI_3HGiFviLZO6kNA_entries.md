# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## Oculus Quest 2 specs and details
 - [https://www.youtube.com/watch?v=aOpD6xxL_fU](https://www.youtube.com/watch?v=aOpD6xxL_fU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-05-05 00:00:00+00:00

Hello and Welcome to! TUESDAY NEWSDAY! Your number one resource for the entire weeks worth of VR news. 

my links:
My Stream:
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill


Here is what i cover this week:


Two Forbes articles battling about VR:
https://www.forbes.com/sites/joeparlock/2020/05/05/stop-saying-virtual-reality-is-dying/#5c9e5ed8646e
https://www.forbes.com/sites/barrycollins/2020/05/04/vr-headsets-are-dying-a-lonely-death/#205e57644d95

VR has had MASSIVE growth recently:
https://www.roadtovr.com/steam-survey-vr-headset-growth-april-2020-half-life-alyx/

Oculus Quest 2:
https://www.bloomberg.com/news/articles/2020-05-05/facebook-s-oculus-developing-smaller-lighter-quest-vr-headset
https://uploadvr.com/bloomberg-quest-refresh-report/

Meme break:
https://www.reddit.com/r/VR_memes/comments/gdlngy/at_least_it_has_prime/

Oculus has been profitable:
https://www.roadtovr.com/facebooks-non-advertising-revenue-primarily-driven-oculus-80-year-year-297m/

Sony PSVR controller designs:
https://www.roadtovr.com/sony-hand-tracking-vr-controller-knuckles/

Vader Immortal coming to PSVR This summer:
https://www.roadtovr.com/vader-immortal-psvr-launch/

## A completely new way to walk in VR: CyberShoes
 - [https://www.youtube.com/watch?v=Egv9iBRsaFA](https://www.youtube.com/watch?v=Egv9iBRsaFA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-05-04 00:00:00+00:00

Welcome to Virtually Odd! Where I take a look at some of the weirdest Virtual Reality devices over the course of history. Today we'll be focusing on the Cybershoes, a mobile, home sized alternative to something like an omni-directional treadmill. Buckle up though, this is about to get odd. 

Here are my links:

My Stream:
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill

