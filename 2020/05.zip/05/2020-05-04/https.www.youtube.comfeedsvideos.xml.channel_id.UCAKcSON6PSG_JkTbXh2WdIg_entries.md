# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Stranglers keyboardist Dave Greenfield dies of COVID-19 (The Current Music News)
 - [https://www.youtube.com/watch?v=EdgZ7X4jHF4](https://www.youtube.com/watch?v=EdgZ7X4jHF4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-05 00:00:00+00:00

May 5, 2020: Dave Greenfield, keyboardist in the Stranglers, has died of coronavirus at age 71. Also, catalog albums by artists like Fleetwood Mac and Mariah Carey are bumping back up the chart; a new baby for Grimes; a Prince guitar and other rock memorabilia go up for auction; and a little kid in pajamas may have written the song of the summer.
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Missouri allows concerts to resume, but venues remain closed (The Current Music News)
 - [https://www.youtube.com/watch?v=dbjohTrV67E](https://www.youtube.com/watch?v=dbjohTrV67E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-05-04 00:00:00+00:00

May 4, 2020: There's tension in Missouri as the governor says concerts may resume, while venues opt to remain closed. Also, disco drummer Hamilton Bohannon has died at 78; Boston music venue Great Scott has closed; Florence Welch is playing a virtual Met Gala party as big names book a telethon to support NYC; and Germany is trying drive-in raves.
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

