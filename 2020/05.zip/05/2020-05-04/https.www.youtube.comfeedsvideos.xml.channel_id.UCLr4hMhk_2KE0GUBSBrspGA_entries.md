# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## OnePlus 8 Pro: dla tych, którzy mają dość (tych oookrutnych kłamstw)
 - [https://www.youtube.com/watch?v=NwblzwlH2dI](https://www.youtube.com/watch?v=NwblzwlH2dI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-05-04 00:00:00+00:00

Szukania, wybierania i zastanawiania się jakiego flagowca na androidzie wybrać. Proponuję tego. Bardzo dobrego, choć nie bez wad.
OnePlus 8 Pro w Proshop (dzięki za sampel): https://bit.ly/3dd461P
Strona producenta: http://bit.ly/2OrIxhn

