# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## We May Have Solved Our Burping Cows Problem
 - [https://www.youtube.com/watch?v=9UJiTtvKMYk](https://www.youtube.com/watch?v=9UJiTtvKMYk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2020-05-04 00:00:00+00:00

When a bunch of cows burp they can exhale a lot of methane that affects the global warming problem. Researchers are working on finding solutions for it. To learn more about the fight to stop climate change go to https://gatesnot.es/2W1YUbn. Thanks to Bill Gates and Breakthrough Energy for supporting this episode of SciShow.

Hosted by: Hank Green

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Kevin Bealer, Jacob, Katie Marie Magnone, D.A.Noe, Charles Southerland, Eric Jensen, Christopher R Boucher, Alex Hackman, Matt Curls, Adam Brainard, Scott Satovsky Jr, Sam Buck, Ron Kakar, Chris Peters, Kevin Carpentier, Patrick D. Ashmore, Piya Shedden, Sam Lutfi, charles george, Greg

----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://www.epa.gov/sites/production/files/2018-01/documents/2018_complete_report.pdf
https://beef.unl.edu/reduce-methane-production-cattle
https://www.agric.wa.gov.au/climate-change/carbon-farming-reducing-methane-emissions-cattle-using-feed-additives
https://www.hindawi.com/journals/archaea/2010/945785/
https://www.wur.nl/en/show/Methane-mitigation-in-dairy-cows.htm
https://bcdairy.ca/milk/articles/what-do-dairy-cows-eat
https://www.ars.usda.gov/ARSUserFiles/50901500/px-based_v3.2/educ-matrls/pdfs/HO_what-cows-eat.pdf
https://pdfs.semanticscholar.org/68cb/15a0b9f62711a0310f17a9a2b32e139c2885.pdf
https://climate.nasa.gov/faq/33/which-is-a-bigger-methane-source-cow-belching-or-cow-flatulence/
https://e360.yale.edu/features/how-eating-seaweed-can-help-cows-to-belch-less-methane
https://www.adsa.org/2018/Abstracts/LB.pdf
https://www.npr.org/sections/thesalt/2018/07/03/623645396/surf-and-turf-to-reduce-gas-emissions-from-cows-scientists-look-to-the-ocean
https://www.ucdavis.edu/news/can-seaweed-cut-methane-emissions-dairy-farms/
https://www.sciencedirect.com/science/article/pii/S0959652619321559?via%3Dihub
https://advances.sciencemag.org/content/5/7/eaav8391
https://www.nationalgeographic.com/environment/2019/07/can-methane-burps-be-bred-out-of-cows/

Image Sources: 
https://commons.wikimedia.org/wiki/File:Modelo_did%C3%A1tico_bovino_(fundo_branco).jpg
https://www.istockphoto.com/photo/harpoon-weed-red-algae-asparagopsis-armata-gm1168636003-322746528
https://www.istockphoto.com/photo/dairy-cows-feeding-in-a-free-livestock-stall-gm1167198199-321808312
https://www.istockphoto.com/photo/cow-pattern-texture-gm184137891-16921325
https://www.istockphoto.com/photo/girl-learning-to-prepare-meal-from-mother-gm1127294863-297060475
https://www.istockphoto.com/photo/ecological-catastrophy-gm1141520118-305861595
https://www.istockphoto.com/photo/los-angeles-traffic-jam-overlooking-downtown-skyline-gm623781366-109517673
https://www.istockphoto.com/photo/herd-of-steers-looking-at-camera-gm1167064450-321728009
https://www.istockphoto.com/photo/vegetarian-and-cow-gm1185486632-334120761

