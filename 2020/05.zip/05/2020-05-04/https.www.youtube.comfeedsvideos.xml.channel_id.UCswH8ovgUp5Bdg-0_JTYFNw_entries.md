# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Ricky Gervais & Russell Brand On Spirituality & Animals
 - [https://www.youtube.com/watch?v=H87oudm239w](https://www.youtube.com/watch?v=H87oudm239w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-05-04 00:00:00+00:00

A clip from #UnderTheSkin with #RickyGervais!
Watch the entire episode here: https://youtu.be/5Szj5jJeUec
Get the Luminary app with this special promo code to get tO all the latest episodes of Under The Skin: http://lumninary.link/ricky

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

