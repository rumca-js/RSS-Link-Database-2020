# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Apex Legends: Season 5 – Official Fortune's Favor Launch Trailer
 - [https://www.youtube.com/watch?v=tvKhX-73c4Y](https://www.youtube.com/watch?v=tvKhX-73c4Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-05 00:00:00+00:00

When she was nine years old, Loba Andrade witnessed her parents’ murders at the hands of the simulacrum Revenant. Orphaned and tossed into the system, Loba fought tooth and nail to overcome the adversity of her childhood. She grew up to become a famous high society socialite by day, and the Outlands’ most infamous thief by night. Now, her parents’ seemingly immortal killer has re-emerged, and she’s tracked him to the Apex Games. She’s looking for answers, treasure, and a way to take the one thing that’s always been out of her reach: revenge. 
 
Apex Legends™ is a free-to-play battle royale game where legendary characters battle for glory, fame, and fortune on the fringes of the Frontier. Play for free now on Xbox One, PS4, and Origin for PC.

## Doom Eternal Drama, No Halo Infinite Gameplay At Inside Xbox | Save State
 - [https://www.youtube.com/watch?v=K9BSEJBIQ5c](https://www.youtube.com/watch?v=K9BSEJBIQ5c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-05 00:00:00+00:00

Id Software's Marty Stratton weighs in on the Doom Eternal soundtrack drama, there'll be no Halo Infinite gameplay on this week's Inside Xbox, and EA announced its 2020 EA Play dates.

#SaveState #GameSpot

## Mortal Kombat 11 - The Epic Saga Continues Teaser Trailer
 - [https://www.youtube.com/watch?v=oGY7GyiTP40](https://www.youtube.com/watch?v=oGY7GyiTP40)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-05 00:00:00+00:00

The epic saga continues. Full reveal coming May 6.

## Rainbow Six: Siege Review (2020)
 - [https://www.youtube.com/watch?v=mvEsucmLJZk](https://www.youtube.com/watch?v=mvEsucmLJZk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-05-04 00:00:00+00:00

More than four years after the game's release, Rainbow Six Siege has evolved into not only a compelling shooter but one of the best examples of the genre. Ubisoft's tactical FPS Rainbow Six: Siege is available on PS4, Xbox One, and PC. You can read the full written Rainbow Six: Siege review by Mat Paget on GameSpot: https://www.gamespot.com/reviews/rainbow-six-siege-review-2020-smooth-operator/1900-6417459/

