# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Wooden skyscrapers climb to new heights
 - [https://www.cnn.com/style/article/wooden-skyscraper-revolution-timber/index.html](https://www.cnn.com/style/article/wooden-skyscraper-revolution-timber/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-02-19 09:00:39+00:00

Surrounded by farmland and with a population of under 10,000 people, the Norwegian town of Brumunddal might seem like an unlikely setting for a record-breaking high-rise.

