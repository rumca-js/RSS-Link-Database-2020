# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Top 30 NEW Xbox One Games of 2020
 - [https://www.youtube.com/watch?v=iSJRWP9iZOQ](https://www.youtube.com/watch?v=iSJRWP9iZOQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-02-20 00:00:00+00:00

Looking for something to play on Xbox One in 2020? Here are some new and upcoming anticipated games.
Subscribe for more: http://youtube.com/gameranxtv

#30 Twin Mirror

Platform: Xbox One PC PS4

Release Date: 2020



#29 Session

Platform: Xbox One PC

Release Date: 2020



#28 Tell Me Why

Platform: Xbox One PC

Release Date: Mid-2020



#27 Minecraft Dungeons

Platform: Xbox One PC PS4 SWITCH

Release Date: April 2020



#26 Maneater

Platform: Xbox One PC PS4

Release Date: May 22, 2020



#25 The Dark Pictures Anthology: Little Hope

Platform: Xbox One PC PS4

Release Date:TBA 2020



#24 Beyond Good & Evil 2 

Platform: Xbox One PC PS4

Release Date:TBA 2020



#23 Ways to the Woods

Platform: Xbox One

Release Date: TBA 2020



#22 Skull and Bones

Platform: Xbox One PC PS4

Release Date:TBA 2020



#21 Tales of Arise

Platform: Xbox One PC PS4

Release Date:2020



#20 Grounded

Platform: Xbox One PC

Release Date:Q2 2020



#19 Destroy All Humans! REMAKE

Platform: Xbox One PC PS4

Release Date: TBA 2020



#18 Ori and the Will of the Wisps 

Platform: Xbox One PC

Release Date: March 11, 2020



#17 Bleeding Edge

Platform: Xbox One PC

Release Date: 24 March 2020



#16 Wasteland 3

Platform: Xbox One PC PS4 Linux

Release Date: May 19, 2020



#15 Marvel's Avengers

Platform: Xbox One PC PS4 Stadia

Release Date: September 4, 2020



#14 Gods and Monsters

Platform: Xbox One PC PS4 Switch

Release Date: TBA 2020



#13 Watch Dogs Legion

Platform: Xbox One PC PS4 PS5 Stadia Xbox SERIES X

Release Date: TBA 2020



#12 Dragon ball Z Kakarot

Platform: Xbox One PC PS4

Release Date: January 17, 2020



#11 Disintegration

Platform: Xbox One PC PS4

Release Date: TBA 2020



#10 Kerbal Space Program 2

Platform: Xbox One PC PS4

Release Date: TBA 2020



#9 Lego Star Wars: The Skywalker Saga

Platform: Xbox One PC PS4 Switch

Release Date: TBA 2020



#8 Vampire: The Masquerade – Bloodlines 2

Platform: Xbox One PC PS4

Release Date: TBA 2020



#7 Rainbow Six Quarantine

Platform: Xbox One PC PS4

Release Date: TBA 2020



#6 Resident Evil 3 Remake

Platform: Xbox One PC PS4

Release Date: April 3, 2020



#5 Outriders

Platform: Xbox One Xbox 4grn PC PS4 PS5

Release Date: Q4 2020



#4 Doom Eternal

Platform: Xbox One PC PS4 STadia

Release Date: March 20, 2020



#3 Microsoft Flight Simulator

Platform: Xbox One PC

Release Date: TBA 2020



#2 Cyberpunk 2077

Platform: Xbox One PC PS4 STADIA

Release Date: 17 September 2020



#1 Halo Infinite

Platform: Xbox One Xbox 4gen PC

Release Date: Q4 2020









BONUS

Carrion

Platform: Xbox One PC

Release Date: TBA 2020



Dying Light 2

Platform: Xbox One PC PS4

Release Date: TBA 2020



Gears Tactics

Platform: Xbox One PC

Release Date: APRIL 28, 2020



Rust

Platform: Xbox One

Release Date: 2020

## 10 MORE Video Game Levels We All Got LOST IN
 - [https://www.youtube.com/watch?v=709V3DdMoYk](https://www.youtube.com/watch?v=709V3DdMoYk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-02-19 00:00:00+00:00

Sometimes you just can't help but get lost in a video game level: sometimes for good reasons, sometimes for bad ones. Here are our some wild levels.
Subscribe for more: http://youtube.com/gameranxtv
Earlier video: https://www.youtube.com/watch?v=I8HOXlLleK0

## 7 Gamer Problems - THEN VS NOW
 - [https://www.youtube.com/watch?v=bI3uZlAoxak](https://www.youtube.com/watch?v=bI3uZlAoxak)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-02-19 00:00:00+00:00

Video games...have changed. Here's some stuff we experienced during the classic gaming days that are totally different today in 2020.
Subscribe for more: http://youtube.com/gameranxtv

