# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Ellis Delaney - Now Is The Time (Live on Radio Heartland)
 - [https://www.youtube.com/watch?v=3NTld-WYqHI](https://www.youtube.com/watch?v=3NTld-WYqHI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-02-20 00:00:00+00:00

Ellis Delaney performs 'Now Is The Time' from her 2020 album, 'Ordinary Love,' live in the Radio Heartland studio.
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/
https://www.facebook.com/RadioHeartlandMPR/
https://twitter.com/RadioHeartland

## Ellis Delaney - Ordinary Love (Live at Radio Heartland)
 - [https://www.youtube.com/watch?v=YeJXeaYJl4g](https://www.youtube.com/watch?v=YeJXeaYJl4g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-02-20 00:00:00+00:00

Ellis Delaney performs the title track from her 2020 album, 'Ordinary Love,' live in the Radio Heartland studio.
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/
https://www.facebook.com/RadioHeartlandMPR/
https://twitter.com/RadioHeartland

## Ellis Delaney - The Finest Adventure (Live at Radio Heartland)
 - [https://www.youtube.com/watch?v=AeM4yGHiTq8](https://www.youtube.com/watch?v=AeM4yGHiTq8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-02-20 00:00:00+00:00

Ellis Delaney performs 'The Finest Adventure' from her 2020 album, 'Ordinary Love,' live in the Radio Heartland studio.
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/
https://www.facebook.com/RadioHeartlandMPR/
https://twitter.com/RadioHeartland

## Heart Bones - Don't Read the Comments (Live at The Current)
 - [https://www.youtube.com/watch?v=-3_spj8hZ-o](https://www.youtube.com/watch?v=-3_spj8hZ-o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-02-19 00:00:00+00:00

Watch Heart Bones perform 'Don't Read the Comments' from their album, 'Hot Dish,' live in The Current studio.
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Heart Bones - I Like Your Way (Live at The Current)
 - [https://www.youtube.com/watch?v=-siBui55z2M](https://www.youtube.com/watch?v=-siBui55z2M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-02-19 00:00:00+00:00

Watch Heart Bones perform 'I Like Your Way' from their album, 'Hot Dish,' live in The Current studio.
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Heart Bones - Open Relations (Live at The Current)
 - [https://www.youtube.com/watch?v=80RzMmNf1U4](https://www.youtube.com/watch?v=80RzMmNf1U4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-02-19 00:00:00+00:00

Watch Heart Bones perform 'Open Relations' from their album, 'Hot Dish,' live in The Current studio.
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

