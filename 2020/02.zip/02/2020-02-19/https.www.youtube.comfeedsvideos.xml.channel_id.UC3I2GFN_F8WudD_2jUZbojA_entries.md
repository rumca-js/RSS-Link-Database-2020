# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## DakhaBrakha - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=kuAaIe1QDSc](https://www.youtube.com/watch?v=kuAaIe1QDSc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-19 00:00:00+00:00

http://KEXP.ORG presents DakhaBrakha performing live at the Triple Door. Recorded October 15, 2019.

Songs:
Khyma
I've Boarded The Wrong Plane (Rembetika)
Plyve choven
Lado

Host: Darek Mazzone
Audio Engineer: Curt Nelson
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen, Kendall Rock & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
http://www.dakhabrakha.com.ua

## DakhaBrakha - I've Boarded The Wrong Plane (Rembetika) (Live on KEXP)
 - [https://www.youtube.com/watch?v=N0cp--Hhkws](https://www.youtube.com/watch?v=N0cp--Hhkws)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-19 00:00:00+00:00

http://KEXP.ORG presents DakhaBrakha performing "I've Boarded The Wrong Plane (Rembetika)" live at the Triple Door. Recorded October 15, 2019.

Host: Darek Mazzone
Audio Engineer: Curt Nelson
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen, Kendall Rock & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
http://www.dakhabrakha.com.ua

## DakhaBrakha - Khyma (Live on KEXP)
 - [https://www.youtube.com/watch?v=H7cpHodEp1k](https://www.youtube.com/watch?v=H7cpHodEp1k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-19 00:00:00+00:00

http://KEXP.ORG presents DakhaBrakha performing "Khyma" live at the Triple Door. Recorded October 15, 2019.

Host: Darek Mazzone
Audio Engineer: Curt Nelson
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen, Kendall Rock & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
http://www.dakhabrakha.com.ua

## DakhaBrakha - Lado (Live on KEXP)
 - [https://www.youtube.com/watch?v=2zYCBhokaDk](https://www.youtube.com/watch?v=2zYCBhokaDk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-19 00:00:00+00:00

http://KEXP.ORG presents DakhaBrakha performing "Lado" live at the Triple Door. Recorded October 15, 2019.

Host: Darek Mazzone
Audio Engineer: Curt Nelson
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen, Kendall Rock & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
http://www.dakhabrakha.com.ua

## DakhaBrakha - Plyve choven (Live on KEXP)
 - [https://www.youtube.com/watch?v=J2vBp2mRnDk](https://www.youtube.com/watch?v=J2vBp2mRnDk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-19 00:00:00+00:00

http://KEXP.ORG presents DakhaBrakha performing "Plyve choven" live at the Triple Door. Recorded October 15, 2019.

Host: Darek Mazzone
Audio Engineer: Curt Nelson
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen, Kendall Rock & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
http://www.dakhabrakha.com.ua

