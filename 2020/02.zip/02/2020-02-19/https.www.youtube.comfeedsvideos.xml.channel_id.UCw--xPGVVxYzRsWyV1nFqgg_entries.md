# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Taking on Fantasy Characters & Evolving BookTube - Piéra Forde FANTASY CHAT!
 - [https://www.youtube.com/watch?v=3d_nZ8EPt3o](https://www.youtube.com/watch?v=3d_nZ8EPt3o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-02-20 00:00:00+00:00

I sit down to talk with the magnificent Piéra Forde to talk about her work with Nevernight, being a fantasy focused actor, and the growth of #BookTube! 

Her channel: https://www.youtube.com/user/pieraforde4

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## White Night - DRESDEN REVIEW
 - [https://www.youtube.com/watch?v=LE2FysTbXkI](https://www.youtube.com/watch?v=LE2FysTbXkI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-02-19 00:00:00+00:00

My review of White Night by Jim Butcher. Another review into the Dresden Files series. 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

