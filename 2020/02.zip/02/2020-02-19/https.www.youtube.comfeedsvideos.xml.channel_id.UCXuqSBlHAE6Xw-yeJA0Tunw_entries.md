# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Unboxing 3 PETABYTES of storage!!
 - [https://www.youtube.com/watch?v=EtZXMj_gUjU](https://www.youtube.com/watch?v=EtZXMj_gUjU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-02-20 00:00:00+00:00

Monitor and manage your PC in real-time with Pulseway! Create your free account today at https://geni.us/cbwBy

SmartDeploy: Modern endpoint management for IT. Get your exclusive free offer at https://lmg.gg/E7pvL

Thanks 45Drives for continuing to support our crazy server projects!!! Show them some love at https://www.45drives.com/ and https://twitter.com/45Drives

What's better than one petabyte of storage?...

Buy Seagate Exos on Amazon (PAID LINK): https://geni.us/ZaXumr

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1157544-unboxing-3-petabytes-of-storage/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors'
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Come see us at LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

## Building a BEAST Gaming Rig with my 3 Year Old....
 - [https://www.youtube.com/watch?v=D_xftS6ydXQ](https://www.youtube.com/watch?v=D_xftS6ydXQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-02-19 00:00:00+00:00

Thanks to Seasonic for sponsoring this video! Check out Seasonic products:
On Amazon: https://geni.us/q4lnefC
On Newegg: https://lmg.gg/8KV3S
On Walmart: https://geni.us/ARnaD

Purchases made through some store links may provide some compensation to Linus Media Group.

Linus does his third and final father-child PC build, this time with his youngest daughter, age 3.

Discuss on the forum: https://linustechtips.com/main/topic/1157240-3rd-times-the-charm-daddy-daughter-pc-build/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Come see us at LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

