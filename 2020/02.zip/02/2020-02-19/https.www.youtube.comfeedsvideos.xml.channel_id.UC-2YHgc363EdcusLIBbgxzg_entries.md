# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## Why Whales Explode | Random Thursday
 - [https://www.youtube.com/watch?v=Dd5Pw9d7hXg](https://www.youtube.com/watch?v=Dd5Pw9d7hXg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2020-02-20 00:00:00+00:00

Get 20% off your first order of Mack Weldon clothing when you enter promo code "joescott" at http://www.mackweldon.com

Dead whales have a tendency to explode, and in some cases, humans blow them up for them. Here's why. Maybe don't eat while you're watching this.


Support me on Patreon!
http://www.patreon.com/answerswithjoe

Not a fan of Patreon? Become a member!
https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Get cool nerdy t-shirts at
http://www.answerswithjoe.com/shirts

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

