# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Samsung S20 Ultra - zdjęcia i filmy. Gościnnie: Xiaomi Mi Note 10, iPhone 11 Pro i Huawei P30 Pro
 - [https://www.youtube.com/watch?v=Da4vTqkZiVs](https://www.youtube.com/watch?v=Da4vTqkZiVs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-02-20 00:00:00+00:00

Gościnnie występują: Xiaomi Mi Note 10, iPhone 11 Pro i Huawei P30 Pro.
Insta: http://bit.ly/InstaKlawiatur Twittera: http://bit.ly/TTKlawitera i FB: http://bit.ly/FBKlawiatur.

