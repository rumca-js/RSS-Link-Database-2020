# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## Major Breakthrough: Graphene Batteries FINALLY Hit the Market
 - [https://www.youtube.com/watch?v=dnE1nO6o-do](https://www.youtube.com/watch?v=dnE1nO6o-do)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2020-02-20 00:00:00+00:00

Previous Samsung graphene video: https://www.youtube.com/watch?v=Go2g_BNpG_Y

Gary Explains video: https://www.youtube.com/watch?v=uIMegpibt1M

--- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. 

If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- New Thinking Book written by Dagogo Altraide ---
Learn the stories of those who invented the things we use everyday.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

--- ColdFusion Social Media ---
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusionTV

--- ColdFusion Podcast links ---
Google Podcasts - http://bit.ly/2xo8doR
Apple Podcasts - https://apple.co/2WI2IeU
Spotify - https://spoti.fi/2KT1taB
Stitcher - http://bit.ly/2WI4f4E

Sources:

Two layers of Graphene stopping bullets: https://futurism.com/two-layers-graphene-make-diamond-hard-armor-stop-bullet 

https://newatlas.com/diamene-graphene-diamond-armor/52683/

https://www.nature.com/articles/s41565-017-0023-9

https://www.androidauthority.com/graphene-batteries-explained-1070096/

https://www.nature.com/articles/s41467-017-01823-7

https://www.wired.com/story/welcome-to-the-era-of-supercharged-lithium-silicon-batteries/

https://www.digitaltrends.com/features/real-graphene-battery-interview-samuel-gong-ces-2020/

https://www.gizchina.com/2020/01/19/graphene-batteries-are-finally-ready-to-land-in-smartphones/

https://wccftech.com/graphene-batteries-for-smartphones-ready/

https://www.realgrapheneusa.com/graphene

https://www.digitaltrends.com/features/real-graphene-battery-interview-samuel-gong-ces-2020/


//Soundtrack//

Need a Name - Road to Berlin

SleepyFish - Forgot It Was Monday (Original Mix)

SineRider - Telegraph

Paddy Mulcahy - On A Hill In Swinford

HNNY - Till dig

Instupendo - Boy

Burn Water - Does it Get Easier? (Unreleased) 

Pre-release here: https://soundcloud.com/burnwater/does-it-get-easier

» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide

Why are you still reading?

