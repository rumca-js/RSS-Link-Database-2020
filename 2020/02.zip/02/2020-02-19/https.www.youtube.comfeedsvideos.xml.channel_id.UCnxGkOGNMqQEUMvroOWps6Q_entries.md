# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Colin O'Brady Rowed a Boat from South America to Antarctica | Joe Rogan
 - [https://www.youtube.com/watch?v=FvoO3tGKBNY](https://www.youtube.com/watch?v=FvoO3tGKBNY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-20 00:00:00+00:00

Taken from #1429 w/Colin O'Brady:
https://youtu.be/4H_5J4qcij4

## Colin O'Brady Sets Record Straight on Inaccurate Nat Geo Article | Joe Rogan
 - [https://www.youtube.com/watch?v=ToOTCJwn7U0](https://www.youtube.com/watch?v=ToOTCJwn7U0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-20 00:00:00+00:00

Taken from #1429 w/Colin O'Brady:
https://youtu.be/4H_5J4qcij4

## Colin O’Brady Shares Details of HIs Brutal Arctic Training Regimen
 - [https://www.youtube.com/watch?v=Qy7CpioPicg](https://www.youtube.com/watch?v=Qy7CpioPicg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-20 00:00:00+00:00

Taken from JRE #1429 w/Colin O'Brady: https://youtu.be/4H_5J4qcij4

## Colin O’Brady on the Grimy Reality of Row Boating Drake’s Passage
 - [https://www.youtube.com/watch?v=VKjwAm-Gvwg](https://www.youtube.com/watch?v=VKjwAm-Gvwg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-20 00:00:00+00:00

Taken from JRE #1429 w/Colin O'Brady: https://youtu.be/4H_5J4qcij4

## Colin O’Brady: Pain is Mandatory, Suffering is Optional
 - [https://www.youtube.com/watch?v=TxWnIIF6RlM](https://www.youtube.com/watch?v=TxWnIIF6RlM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-20 00:00:00+00:00

Taken from JRE #1429 w/Colin O'Brady: https://youtu.be/4H_5J4qcij4

## Brian Greene Shares His Surprising Take on Religion and Science
 - [https://www.youtube.com/watch?v=gpStPNAB7Cw](https://www.youtube.com/watch?v=gpStPNAB7Cw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-19 00:00:00+00:00

Taken from JRE #1428 w/Brian Greene: https://youtu.be/r4wQsmAtZoc

## Brian Greene and Joe Rogan: Consciousness and Psychedelics
 - [https://www.youtube.com/watch?v=JMYi5j7vZ6A](https://www.youtube.com/watch?v=JMYi5j7vZ6A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-19 00:00:00+00:00

Taken from JRE #1428 w/Brian Greene: https://youtu.be/r4wQsmAtZoc

## Brian Greene on How Music Helped Him Write His New Book
 - [https://www.youtube.com/watch?v=8Vo8DKd6gCM](https://www.youtube.com/watch?v=8Vo8DKd6gCM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-19 00:00:00+00:00

Taken from JRE #1428 w/Brian Greene: https://youtu.be/r4wQsmAtZoc

## Brian Greene on Seeing Humanity in the Context of the Cosmos
 - [https://www.youtube.com/watch?v=U6uT-pA3uIk](https://www.youtube.com/watch?v=U6uT-pA3uIk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-19 00:00:00+00:00

Taken from JRE #1428 w/Brian Greene: https://youtu.be/r4wQsmAtZoc

## Brian Greene: Thought Itself Will Come to an End in the Universe
 - [https://www.youtube.com/watch?v=t9mgdl1Gh6g](https://www.youtube.com/watch?v=t9mgdl1Gh6g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-19 00:00:00+00:00

Taken from JRE #1428 w/Brian Greene: https://youtu.be/r4wQsmAtZoc

## Everything in the Universe Will Die One Day w/Brian Greene | Joe Rogan
 - [https://www.youtube.com/watch?v=khvJypQnwqo](https://www.youtube.com/watch?v=khvJypQnwqo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-19 00:00:00+00:00

Taken from JRE #1428 w/Brian Greene:
https://youtu.be/r4wQsmAtZoc

## Physicist Brian Greene Has a Theory on Why Aliens Haven’t Visited Us
 - [https://www.youtube.com/watch?v=BRo3YXCvgPI](https://www.youtube.com/watch?v=BRo3YXCvgPI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-19 00:00:00+00:00

Taken from JRE #1428 w/Brian Greene: https://youtu.be/r4wQsmAtZoc

## Physicist Brian Greene on Ray Kurzweil's Singularity Predictions | Joe Rogan
 - [https://www.youtube.com/watch?v=XfXih6OvcAg](https://www.youtube.com/watch?v=XfXih6OvcAg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-19 00:00:00+00:00

Taken from JRE #1428 w/Brian Greene:
https://youtu.be/r4wQsmAtZoc

## Physicist Brian Greene on What He Learned from a Meditation Class
 - [https://www.youtube.com/watch?v=W_LWqD22ukI](https://www.youtube.com/watch?v=W_LWqD22ukI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-19 00:00:00+00:00

Taken from JRE #1428 w/Brian Greene: https://youtu.be/r4wQsmAtZoc

## What Was Happening Before the Big Bang? w/Brian Greene | Joe Rogan
 - [https://www.youtube.com/watch?v=FHAA_1Guxlo](https://www.youtube.com/watch?v=FHAA_1Guxlo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-19 00:00:00+00:00

Taken from JRE #1428 w/Brian Greene:
https://youtu.be/r4wQsmAtZoc

