# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## The Paper Kites - Only One live - MUZO.FM
 - [https://www.youtube.com/watch?v=qaeX0U-mWcs](https://www.youtube.com/watch?v=qaeX0U-mWcs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-02-21 00:00:00+00:00

The Paper Kites Only One na żywo, akustycznie w MUZO.FM. Utwór Only One pochodzi z płyty The Paper Kites On the Train Ride Home. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook The Paper Kites: http://www.facebook.com/thepaperkitesband
Instagram The Paper Kites: http://www.instagram.com/thepaperkites
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm

The Paper Kites Only One tekst lyrics

Rain on a river, falling in to the mist
The river is running - don't see the end of it
Rising like a flooded street
All the way to your feet
I was on my knees
You said you had me right from the start of this
Don't get me wrong now
I know the way it is
Only gave you half a life
Gave your words, gave you lies
I didn't know myself
I think it's time to be your only one
I think it's time to be your only one
Only
Made up of water, made up of fire too
Cracking and burning, pouring it out to you
Try to see you take the pain
When you know I'm the flame
I should've known you would
I think it's time to be your only one
I think it's time to be your only one
I think it's time to be your only one
I think I'm ready to be your only one

