# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## I'm A Believer | The Monkees | Pomplamoose
 - [https://www.youtube.com/watch?v=zo4ziXce43Y](https://www.youtube.com/watch?v=zo4ziXce43Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2020-02-21 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 Save this song on Spotify: https://open.spotify.com/track/2mWRxb8U2cm56hDwm0mwIP?si=AWTBITIKSnafdDZIbwRJ2g
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

A cover of I'm A Believer by Pomplamoose.

CREDITS

Lead Vocals: Nataly Dawn
Keys: Jack Conte
Guitar: Brian Green 
Bass: Nick Campbell
Drums: Kyle Crane
Background vocals: Loren Battley (left), Sarah Dugas (right)
Engineer: Tim Sonnefeld 
Mixing/Mastering: Caleb Parker
Video Production: Ricky Chavez
Video Editor: Nataly Dawn

Recorded at Red Star Recording in Los Angeles.

