# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Jurgen Klopp tells young Man Utd fan 'I can't make Liverpool lose'
 - [https://www.bbc.co.uk/news/uk-northern-ireland-foyle-west-51580401](https://www.bbc.co.uk/news/uk-northern-ireland-foyle-west-51580401)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 23:49:21+00:00

Donegal schoolboy Daragh Curley asked the Liverpool manager if his side could lose some matches.

## Grace Millane case: 'I went on a date with her killer after her murder'
 - [https://www.bbc.co.uk/news/uk-england-essex-51563388](https://www.bbc.co.uk/news/uk-england-essex-51563388)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 21:55:39+00:00

"It was a very strange insight into what someone's brain does after they do something like that."

## What are the rules on workplace surveillance?
 - [https://www.bbc.co.uk/news/explainers-51571684](https://www.bbc.co.uk/news/explainers-51571684)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 19:42:25+00:00

Barclays is one of many companies to have used technology to monitor the activity of its staff.

## Middlesbrough police officers help deliver baby on lunch break
 - [https://www.bbc.co.uk/news/uk-england-tees-51578980](https://www.bbc.co.uk/news/uk-england-tees-51578980)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 18:07:18+00:00

The police officers were on their way back to base when they were flagged down.

## Men tell of rescuing woman from submerged car roof
 - [https://www.bbc.co.uk/news/uk-england-gloucestershire-51573683](https://www.bbc.co.uk/news/uk-england-gloucestershire-51573683)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 16:58:36+00:00

Two men waded into floodwater to rescue a woman trapped on the roof of her submerged car for 12 hours.

## Hanau shooting: Has Germany done enough to tackle far-right terror threat?
 - [https://www.bbc.co.uk/news/world-europe-51571177](https://www.bbc.co.uk/news/world-europe-51571177)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 15:52:53+00:00

The Hanau crime fuels fears that Germany has underestimated the far-right terror threat.

## Caroline Flack death: Hairdressers bin gossip magazines
 - [https://www.bbc.co.uk/news/uk-england-51564975](https://www.bbc.co.uk/news/uk-england-51564975)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 14:48:15+00:00

One salon owner said she did not want to see pages of fat-shaming and celebrities without make-up.

## Your pictures on the theme of 'uphill'
 - [https://www.bbc.co.uk/news/in-pictures-51575345](https://www.bbc.co.uk/news/in-pictures-51575345)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 14:23:41+00:00

Each week, we publish a gallery of readers' pictures on a set theme. This week it is "uphill"

## Priti Patel 'tried to move top civil servant'
 - [https://www.bbc.co.uk/news/uk-politics-51571619](https://www.bbc.co.uk/news/uk-politics-51571619)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 12:26:04+00:00

The home secretary and her official disagreed but she did not bully him, a source tells the BBC.

## Weather: Parts of UK could see a month's rain in 24 hours amid floods
 - [https://www.bbc.co.uk/news/uk-51567635](https://www.bbc.co.uk/news/uk-51567635)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 12:14:20+00:00

Downpours continue as some areas struggle to cope with flooding in the wake of Storm Dennis.

## Germany shooting: 'Far-right extremist' carried out shisha bars attacks
 - [https://www.bbc.co.uk/news/world-europe-51567971](https://www.bbc.co.uk/news/world-europe-51567971)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 12:04:10+00:00

Nine people were shot dead in two shisha bars in Hanau in a case being investigated as terrorism.

## Wales recall Davies and Moriarty to face France
 - [https://www.bbc.co.uk/sport/rugby-union/51566590](https://www.bbc.co.uk/sport/rugby-union/51566590)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 12:00:52+00:00

Wales recall scrum-half Gareth Davies and flanker Ross Moriarty to face France in the Six Nations as coach Wayne Pivac makes two changes.

## Tony Blair: Labour hopefuls must offer radical change
 - [https://www.bbc.co.uk/news/uk-politics-51560294](https://www.bbc.co.uk/news/uk-politics-51560294)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 11:53:47+00:00

The ex-PM says the party faces a "make-or-break" moment after losing four elections in a row.

## Two dead as Sydney to Melbourne passenger train derails
 - [https://www.bbc.co.uk/news/world-australia-51573326](https://www.bbc.co.uk/news/world-australia-51573326)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 11:46:58+00:00

Others are injured as a train crashes near the Australian town of Wallan, in Victoria.

## Double murder probe after men stabbed at Dudley cannabis farm
 - [https://www.bbc.co.uk/news/uk-england-birmingham-51572165](https://www.bbc.co.uk/news/uk-england-birmingham-51572165)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 11:37:27+00:00

The men were injured in a street fight after a group had tried to break into a house, police say.

## Rikki Neave: Man appears in court charged with murder
 - [https://www.bbc.co.uk/news/uk-england-cambridgeshire-51571685](https://www.bbc.co.uk/news/uk-england-cambridgeshire-51571685)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 11:31:47+00:00

James Watson is accused of killing six-year-old Rikki Neave who was found strangled in woodland.

## Federer out of French Open after knee surgery
 - [https://www.bbc.co.uk/sport/tennis/51571497](https://www.bbc.co.uk/sport/tennis/51571497)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 10:55:23+00:00

Roger Federer, the 20-time Grand Slam champion, will miss this year's French Open after having surgery on his right knee.

## Samsung explains mystery alert sent overnight
 - [https://www.bbc.co.uk/news/technology-51572775](https://www.bbc.co.uk/news/technology-51572775)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 10:54:36+00:00

The company says it sent the strange "1" alert to Samsung devices by mistake.

## Coronavirus: Britons on Diamond Princess cruise ship to be flown home
 - [https://www.bbc.co.uk/news/uk-51568058](https://www.bbc.co.uk/news/uk-51568058)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 10:35:51+00:00

Only those who are well can travel, and they will be quarantined on their return, it is understood.

## Man, 77, speaks out about fighting off would-be mugger
 - [https://www.bbc.co.uk/news/uk-wales-51564742](https://www.bbc.co.uk/news/uk-wales-51564742)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 10:31:22+00:00

Trevor Weston was at a cash machine and says the man threatened to stab him.

## Dame Julie Walters reveals shock of bowel cancer diagnosis
 - [https://www.bbc.co.uk/news/entertainment-arts-51558450](https://www.bbc.co.uk/news/entertainment-arts-51558450)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 08:49:26+00:00

The actress tells Victoria Derbyshire her next film, The Secret Garden, could possibly be her last.

## 'Birdgirl' Mya-Rose Craig to get Bristol University honorary doctorate
 - [https://www.bbc.co.uk/news/uk-england-bristol-51561747](https://www.bbc.co.uk/news/uk-england-bristol-51561747)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 08:21:19+00:00

Mya-Rose Craig has been campaigning for equality in the environmental movement since 2015.

## Aiming high but with realism setting in - where next for Wolves after rapid rise?
 - [https://www.bbc.co.uk/sport/football/51539821](https://www.bbc.co.uk/sport/football/51539821)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 06:44:48+00:00

As Wolves prepare for their Europa League last-32 tie, BBC Sport's Simon Stone looks at how a club that languished in League One six years ago are now hoping to continue their rise.

## Roma set to talk to other clubs about missing children campaign
 - [https://www.bbc.co.uk/sport/football/51561988](https://www.bbc.co.uk/sport/football/51561988)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 06:06:02+00:00

Roma are set to have talks with other European clubs about raising awareness of missing children after a groundbreaking social media campaign.

## Newspaper headlines: Immigration plan 'backlash' and flooding crisis
 - [https://www.bbc.co.uk/news/blogs-the-papers-51567465](https://www.bbc.co.uk/news/blogs-the-papers-51567465)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 05:52:27+00:00

Thursday's front pages carry a wide mix of stories, including reaction to the government's immigration plan.

## Grace Millane murder: Killer's sentencing 'is not closure'
 - [https://www.bbc.co.uk/news/uk-51568598](https://www.bbc.co.uk/news/uk-51568598)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 05:11:13+00:00

"Grace is gone", her cousin says in a BBC interview, and no jail term will change the fact.

## ‘I was labelled a bad kid when mum went to prison’
 - [https://www.bbc.co.uk/news/newsbeat-51563775](https://www.bbc.co.uk/news/newsbeat-51563775)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 03:11:27+00:00

Toni was 11 when her mum first when to prison, she's now 21 and speaks about her experiences.

## 'Until I met my debt mentor, I couldn't always feed my kids'
 - [https://www.bbc.co.uk/news/stories-51551931](https://www.bbc.co.uk/news/stories-51551931)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 03:11:01+00:00

Audie was in debt and losing hope. But Jeannette, who'd once been in debt herself, was able to help.

## Australia weather: 'We’ve gone from hell to high water'
 - [https://www.bbc.co.uk/news/world-australia-51499687](https://www.bbc.co.uk/news/world-australia-51499687)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 01:50:12+00:00

Australians recount the drought, dust, fire and floods of one of the most turbulent summers in memory.

## How a stolen safe changed a burglar's life
 - [https://www.bbc.co.uk/news/world-us-canada-51406210](https://www.bbc.co.uk/news/world-us-canada-51406210)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 01:23:55+00:00

When Matthew Hahn saw what was inside a safe he had stolen, he knew he had to do something

## In pictures: The battle of the oranges
 - [https://www.bbc.co.uk/news/in-pictures-51474989](https://www.bbc.co.uk/news/in-pictures-51474989)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 01:19:22+00:00

Once a year the citizens of the old medieval town of Ivrea gather in the main square to hurl oranges.

## Sinophobia: How a virus reveals the many ways China is feared
 - [https://www.bbc.co.uk/news/world-asia-51456056](https://www.bbc.co.uk/news/world-asia-51456056)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 00:37:57+00:00

A wave of discrimination that's emerged with the coronavirus crisis shows how differently the world views China.

## Sinn Fein surge puts Irish economy in the spotlight
 - [https://www.bbc.co.uk/news/business-51539521](https://www.bbc.co.uk/news/business-51539521)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 00:27:19+00:00

As the Irish parliament convenes to try to choose its new leader, concerns about inequality linger.

## My Money: 'My husband and I have 90 minutes alone together each week'
 - [https://www.bbc.co.uk/news/business-51492742](https://www.bbc.co.uk/news/business-51492742)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 00:25:19+00:00

As part of a new BBC blog series, Maura Hannon from Switzerland shares what she spent her money on this week.

## Coronavirus: Walking through Beijing's near-empty streets
 - [https://www.bbc.co.uk/news/world-asia-51565016](https://www.bbc.co.uk/news/world-asia-51565016)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 00:06:43+00:00

The city is unrecognisable as people work from home and avoid going out.

## Seeing double: The Indian town filled with twins
 - [https://www.bbc.co.uk/news/world-asia-india-51559350](https://www.bbc.co.uk/news/world-asia-india-51559350)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 00:04:40+00:00

One town in the south Indian state of Tamil Nadu is home to hundreds of twins and no-one knows why.

## 'Sinister, with a typical twist' - How Sochi 2014 'changed four lives forever'
 - [https://www.bbc.co.uk/sport/winter-sports/50820662](https://www.bbc.co.uk/sport/winter-sports/50820662)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 00:04:19+00:00

A celebration five years late. A doping saga still serving up plot twists. Meet the four bobsleighers whose lives changed forever after Sochi 2014.

## No-fault evictions: 'Our lives are falling apart'
 - [https://www.bbc.co.uk/news/business-51508286](https://www.bbc.co.uk/news/business-51508286)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-20 00:02:41+00:00

Becky Palmer and her family were given two months to leave a home they had rented for 12 years.

