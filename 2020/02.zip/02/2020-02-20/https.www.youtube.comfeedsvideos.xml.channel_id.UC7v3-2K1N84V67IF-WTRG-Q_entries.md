# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## The Call Of The Wild - Movie Review
 - [https://www.youtube.com/watch?v=TMXvagozDhw](https://www.youtube.com/watch?v=TMXvagozDhw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-02-21 00:00:00+00:00

A movie about nature, friendship, and most importantly, A Dog! Here's my review of THE CALL OF THE WILD!

#CallOfTheWild

