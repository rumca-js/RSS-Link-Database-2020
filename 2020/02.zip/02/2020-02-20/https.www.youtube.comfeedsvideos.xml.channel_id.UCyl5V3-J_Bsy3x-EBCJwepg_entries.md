# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## God, Gender, and Identity: The Nancy Pearcey
 - [https://www.youtube.com/watch?v=QRu4oXhkjAo](https://www.youtube.com/watch?v=QRu4oXhkjAo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-02-21 00:00:00+00:00

Editor-in-chief Kyle Mann and creative director Ethan Nicolle welcome Professor Nancy Pearcey. She is professor of apologetics and scholar in residence at Houston Baptist University and author of several books, most recently  Love Thy Body: Answering Hard Questions about Life and Sexuality.  Prof. Pearcey's books also include  Total Truth,  Finding Truth,  The Soul of Science,  Saving Leonardo and  How Now Shall We Live? (co-authored with Chuck Colson). They talk about sexuality, gender, abortion, and Christianity's high view of the human body.

  Pre-order the new Babylon Bee Best-Of Coffee Table Book coming in 2020!

 Topics Discussed

   Abortion... scientific human life vs modern Personhood Theory

   Biological Sex vs Gender

   The Christian’s high view of the material world and the human body due to belief in the incarnation of Christ, the resurrection of the dead, and the new heaven &amp; earth.

   Trusting in a design vs individual revolt against nature and biological realities

   Language as a front in the culture war

   All of our actions endorse a worldview

   What about people who identify as “gay Christians” or some other adjective placed before the word Christian?

   Nudity in medieval Christian art

   Subscriber Portion (Begins at 00:48:21)

 The entire interview is available for Babylon Bee subscribers only…

 Become a paid subscriber at https://babylonbee.com/plans

