# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Frankie Cosmos - A Joke (Live on KEXP)
 - [https://www.youtube.com/watch?v=1WhH3oOHvO0](https://www.youtube.com/watch?v=1WhH3oOHvO0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-21 00:00:00+00:00

http://KEXP.ORG presents Frankie Cosmos performing "A Joke" live in the KEXP studio. Recorded October 30, 2019.

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Cameras: Alaia D'Alessandro, Kendall Rock & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
http://frankiecosmosband.com

## Frankie Cosmos - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=DGjuxEevo-8](https://www.youtube.com/watch?v=DGjuxEevo-8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-21 00:00:00+00:00

http://KEXP.ORG presents Frankie Cosmos performing live in the KEXP studio. Recorded October 30, 2019.

Songs:
So Blue
Windows
A Joke
Rings On A Tree

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Cameras: Alaia D'Alessandro, Kendall Rock & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
http://frankiecosmosband.com

## Frankie Cosmos - Rings On A Tree (Live on KEXP)
 - [https://www.youtube.com/watch?v=RglQCZCes3g](https://www.youtube.com/watch?v=RglQCZCes3g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-21 00:00:00+00:00

http://KEXP.ORG presents Frankie Cosmos performing "Rings On A Tree" live in the KEXP studio. Recorded October 30, 2019.

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Cameras: Alaia D'Alessandro, Kendall Rock & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
http://frankiecosmosband.com

## Frankie Cosmos - So Blue (Live on KEXP)
 - [https://www.youtube.com/watch?v=PDslvBQsc-U](https://www.youtube.com/watch?v=PDslvBQsc-U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-21 00:00:00+00:00

http://KEXP.ORG presents Frankie Cosmos performing "So Blue" live in the KEXP studio. Recorded October 30, 2019.

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Cameras: Alaia D'Alessandro, Kendall Rock & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
http://frankiecosmosband.com

## Frankie Cosmos - Windows (Live on KEXP)
 - [https://www.youtube.com/watch?v=bugL7o0Uolg](https://www.youtube.com/watch?v=bugL7o0Uolg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-21 00:00:00+00:00

http://KEXP.ORG presents Frankie Cosmos performing "Windows" live in the KEXP studio. Recorded October 30, 2019.

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Cameras: Alaia D'Alessandro, Kendall Rock & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
http://frankiecosmosband.com

