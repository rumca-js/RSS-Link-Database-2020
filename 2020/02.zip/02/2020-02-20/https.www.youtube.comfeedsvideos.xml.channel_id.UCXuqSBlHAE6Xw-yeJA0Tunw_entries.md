# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I WAS RIGHT!! - WAN Show Feb 21, 2020
 - [https://www.youtube.com/watch?v=7Wm7sEn8Mc8](https://www.youtube.com/watch?v=7Wm7sEn8Mc8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-02-21 00:00:00+00:00

For your unrestricted 30 days free trial, go to https://www.freshbooks.com/WAN and enter in “The WAN Show” in the how you heard about us section.

Save 15% today with offer code LTT on Displate at https://lmg.gg/displatewan

Sign up for Private Internet Access VPN at https://lmg.gg/piawan

Buy an LTT shirt, hoodie, hat, and even our own water bottle at https://lmg.gg/wanlttstore

LTX2020, Save the Date - August 8+9, 2020 - https://www.ltxexpo.com/

Check out Carpool Critics, our new movie podcast: http://carpoolcritics.libsyn.com/

Podcast Download: http://traffic.libsyn.com/linustechtips/I_WAS_RIGHT_-_WAN_Show_Feb_21_2020.mp3

Timestamps: (Courtesy of Loshan T)

0:20: Luke gives an overview of today's WAN show
1:25 Intro
1:56: Linus on YouTube's Premier VoD system
4:58: 1st topic - Nissan Switch a cars-as-a-service subscription scheme
11:03: More info on Nissan vehicle subscription scheme.
12:00 - 13:50: "I will never drink off-brand cola" & "I have never experienced the urge to pee that suddenly and that badly [...] in my life"
15:20 Story on how Linus purchase's a minivan.
24:20: back to the first topic yet again...
28:25:  Sponsors
36:33: 2nd topic - Swiss halts their rollout of 5G over health concerns
38:42: discussion on insomnia over 5g health concerns & anxiety being caused by RF 
42:35: TCL slide-out display phone images leaked
43:21: Luke wants Linus to 'enhance' the leaked images, and they analyse the photos in great detail!
45:58 HTC Project Proton
47:39: Linus reads a 'funny' superchat.
48:44: PCI Express 6.0
51:00: Superchat donations
52:51: LTX Expo info + confirmed creators roster.
58:51: "WAIT! WAIT!": LTT Minecraft server reveal!!!

## Unboxing 3 PETABYTES of storage!!
 - [https://www.youtube.com/watch?v=EtZXMj_gUjU](https://www.youtube.com/watch?v=EtZXMj_gUjU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-02-20 00:00:00+00:00

Monitor and manage your PC in real-time with Pulseway! Create your free account today at https://geni.us/cbwBy

SmartDeploy: Modern endpoint management for IT. Get your exclusive free offer at https://lmg.gg/E7pvL

Thanks 45Drives for continuing to support our crazy server projects!!! Show them some love at https://www.45drives.com/ and https://twitter.com/45Drives

What's better than one petabyte of storage?...

Buy Seagate Exos on Amazon (PAID LINK): https://geni.us/ZaXumr

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1157544-unboxing-3-petabytes-of-storage/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors'
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Come see us at LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

