# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Galaxy Z Flip vs Moto RAZR 2020: 10 Differences!
 - [https://www.youtube.com/watch?v=mx8ZDMb5MBg](https://www.youtube.com/watch?v=mx8ZDMb5MBg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-02-21 00:00:00+00:00

Samsung Galaxy Z Flip vs RAZR 2020 - we finally have context for folding phones!
Galaxy Z Flip Unboxing: https://youtu.be/dPaHNTnN0eE
Motorola RAZR First Look: https://youtu.be/lCKcFFDgtNk

MKBHD Merch: http://shop.MKBHD.com

Video Gear I use: http://kit.co/MKBHD/video-gear#recom...
Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

