# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## A Brutal Beating Showed Raghunath Cappo a Spiritual Truth
 - [https://www.youtube.com/watch?v=HLKgs8LJ3dA](https://www.youtube.com/watch?v=HLKgs8LJ3dA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-21 00:00:00+00:00

Taken from JRE #1430 w/Raghunath Cappo: https://youtu.be/UAx1Sq6usRg

## Bodies Change but the Soul is Eternal w/Raghunath Cappo | Joe Rogan
 - [https://www.youtube.com/watch?v=liOfg6e4qWg](https://www.youtube.com/watch?v=liOfg6e4qWg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-21 00:00:00+00:00

Taken from JRE #1430 w/Raghunath Cappo:
https://youtu.be/UAx1Sq6usRg

## Joe Rogan and Raghunath Cappo on Art and Ego
 - [https://www.youtube.com/watch?v=aiedxklETsE](https://www.youtube.com/watch?v=aiedxklETsE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-21 00:00:00+00:00

Taken from JRE #1430 w/Raghunath Cappo: https://youtu.be/UAx1Sq6usRg

## Keeping the Ego in Check w/Raghunath Cappo | Joe Rogan
 - [https://www.youtube.com/watch?v=EY4e3Ybw9Ac](https://www.youtube.com/watch?v=EY4e3Ybw9Ac)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-21 00:00:00+00:00

Taken from JRE #1430 w/Raghunath Cappo:
https://youtu.be/UAx1Sq6usRg

## Raghunath Cappo Explains Karma, Dharma, and Rebirth
 - [https://www.youtube.com/watch?v=9pv_d-evYJg](https://www.youtube.com/watch?v=9pv_d-evYJg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-21 00:00:00+00:00

Taken from JRE #1430 w/Raghunath Cappo: https://youtu.be/UAx1Sq6usRg

## Raghunath Cappo Fought Off a Guy Who Was Stealing His Car | Joe Rogan
 - [https://www.youtube.com/watch?v=5VGn7UZ_y1I](https://www.youtube.com/watch?v=5VGn7UZ_y1I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-21 00:00:00+00:00

Taken from JRE #1430 w/Raghunath Cappo:
https://youtu.be/UAx1Sq6usRg

## Raghunath Cappo Was a Monk for 6 Years | Joe Rogan
 - [https://www.youtube.com/watch?v=G-IgQhQX1dI](https://www.youtube.com/watch?v=G-IgQhQX1dI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-21 00:00:00+00:00

Taken from JRE #1430 w/Raghunath Cappo:
https://youtu.be/UAx1Sq6usRg

## Raghunath Cappo on Truth in the Bhagavad Gita
 - [https://www.youtube.com/watch?v=btfp_51YCtg](https://www.youtube.com/watch?v=btfp_51YCtg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-21 00:00:00+00:00

Taken from JRE #1430 w/Raghunath Cappo: https://youtu.be/UAx1Sq6usRg

## Raghunath Cappo: We’re Just Doing Time on This Planet
 - [https://www.youtube.com/watch?v=LHSQ8OkzQks](https://www.youtube.com/watch?v=LHSQ8OkzQks)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-21 00:00:00+00:00

Taken from JRE #1430 w/Raghunath Cappo: https://youtu.be/UAx1Sq6usRg

## The Innovations of Eddie Bravo & 10th Planet Jiu-Jitsu w/Raghunath Cappo | Joe Rogan
 - [https://www.youtube.com/watch?v=4hj-JpYDtmg](https://www.youtube.com/watch?v=4hj-JpYDtmg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-21 00:00:00+00:00

Taken from JRE #1430 w/Raghunath Cappo:
https://youtu.be/UAx1Sq6usRg

## The Mystical Aspects of the Bhagavhad Gita (and Spaceships) w/Raghunath Cappo | Joe Rogan
 - [https://www.youtube.com/watch?v=qcB0_4zRnxM](https://www.youtube.com/watch?v=qcB0_4zRnxM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-21 00:00:00+00:00

Taken from JRE #1430 w/Raghunath Cappo:
https://youtu.be/UAx1Sq6usRg

## Colin O'Brady Rowed a Boat from South America to Antarctica | Joe Rogan
 - [https://www.youtube.com/watch?v=FvoO3tGKBNY](https://www.youtube.com/watch?v=FvoO3tGKBNY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-20 00:00:00+00:00

Taken from #1429 w/Colin O'Brady:
https://youtu.be/4H_5J4qcij4

## Colin O'Brady Sets Record Straight on Inaccurate Nat Geo Article | Joe Rogan
 - [https://www.youtube.com/watch?v=ToOTCJwn7U0](https://www.youtube.com/watch?v=ToOTCJwn7U0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-20 00:00:00+00:00

Taken from #1429 w/Colin O'Brady:
https://youtu.be/4H_5J4qcij4

## Colin O’Brady Shares Details of HIs Brutal Arctic Training Regimen
 - [https://www.youtube.com/watch?v=Qy7CpioPicg](https://www.youtube.com/watch?v=Qy7CpioPicg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-20 00:00:00+00:00

Taken from JRE #1429 w/Colin O'Brady: https://youtu.be/4H_5J4qcij4

## Colin O’Brady on the Grimy Reality of Row Boating Drake’s Passage
 - [https://www.youtube.com/watch?v=VKjwAm-Gvwg](https://www.youtube.com/watch?v=VKjwAm-Gvwg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-20 00:00:00+00:00

Taken from JRE #1429 w/Colin O'Brady: https://youtu.be/4H_5J4qcij4

## Colin O’Brady: Pain is Mandatory, Suffering is Optional
 - [https://www.youtube.com/watch?v=TxWnIIF6RlM](https://www.youtube.com/watch?v=TxWnIIF6RlM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-20 00:00:00+00:00

Taken from JRE #1429 w/Colin O'Brady: https://youtu.be/4H_5J4qcij4

