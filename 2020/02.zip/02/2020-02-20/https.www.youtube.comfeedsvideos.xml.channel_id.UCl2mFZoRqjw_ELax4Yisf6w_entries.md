# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Open day 1 - kind of
 - [https://www.youtube.com/watch?v=6CyqdXc8SP0](https://www.youtube.com/watch?v=6CyqdXc8SP0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-02-21 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545

## day 3 of being open - getting closer to a real store..
 - [https://www.youtube.com/watch?v=ioAPNZyan4A](https://www.youtube.com/watch?v=ioAPNZyan4A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-02-21 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545

