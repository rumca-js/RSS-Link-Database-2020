# Source:Vlog Casha, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg, language:pl-PL

## CO PAKUJĘ DO AMERYKI POŁUDNIOWEJ?
 - [https://www.youtube.com/watch?v=5uANe0KwmW8](https://www.youtube.com/watch?v=5uANe0KwmW8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg
 - date published: 2020-02-21 00:00:00+00:00

Wyjazd do Kolumbii już za kilka dni! Nadszedł najwyższy czas, żeby się spakować! :)

SPRAWDŹ KANAŁ ADRIANA KILARA:
http://bit.ly/2HKw872

DJI Mavic Mini od DJI ARS:
https://l.dji-ars.pl/MavicMini

PACSAFE - 15% zniżki na hasło "VLOGCASHA" (produkty nieprzecenione!):
https://niedajsieokrasc.pl/

GREENCELL - 10% na wszystko - kod "VLOGCASHA"
https://greencell.global/pl/

🌏 Vlogi z Azji Płd-Wsch: https://bit.ly/2wrM9t2
🇦🇺 Vlogi z Australii: https://bit.ly/2OJWYOy
🇺🇸 Vlogi z życia i podróży w USA: https://bit.ly/2ya73NV
🚙Vlogi z autostopu 2018: https://bit.ly/2NbHzos

▸ Instagram: https://www.instagram.com/vlogcasha
▸ Facebook: https://www.facebook.com/vlogcasha/
▸ "Grupa Casha" na FB: https://bit.ly/2N1a6wX
▸ Blog Casha: http://blogcasha.pl/


#PodróżeCasha

