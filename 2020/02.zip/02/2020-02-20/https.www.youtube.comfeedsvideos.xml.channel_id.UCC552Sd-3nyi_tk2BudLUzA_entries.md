# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## The ONLY 3 Study Hacks Everyone Should Know - Science Proven Techniques
 - [https://www.youtube.com/watch?v=Y_B6VADhY84](https://www.youtube.com/watch?v=Y_B6VADhY84)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2020-02-21 00:00:00+00:00

The study hacks that everyone should know! Thanks to Bill and Melinda Gates for partnering with us! Check out the 2020 letter here: http://www.inflcr.co/SH1ju

Join our email list: https://mailchi.mp/072240d817d6/asapscience

Subscribe for more asapscience, and hit that bell :)

Created by: Mitchell Moffit and Gregory Brown

FOLLOW US!
Mitch
Instagram: https://instagram.com/mitchellmoffit
Twitter: https://twitter.com/mitchellmoffit 

Greg
Instagram: https://instagram.com/whalewatchmeplz 
Twitter: https://twitter.com/whalewatchmeplz 

AsapSCIENCE
Instagram: https://instagram.com/asapscience 
Facebook: https://facebook.com/asapscience 
Twitter: https://twitter.com/asapscience
Tumblr: https://asapscience.tumblr.com 

Send us stuff!
ASAPSCIENCE INC.
P.O. Box 93, Toronto P
Toronto, ON, M5S2S6

Main Resource:
"Range: Why Generalists Triumph in a Specialized World" By David Epstein
https://www.amazon.com/Range-Generalists-Triumph-Specialized-World/dp/0735214484

Papers/Research:

Hypercorrection Effect
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3604148/
https://psycnet.apa.org/record/2013-44868-002

Spacing Effects
https://www.ncbi.nlm.nih.gov/pubmed/19076480
https://www.ncbi.nlm.nih.gov/pubmed/18578849

Spanish vocab
https://psycnet.apa.org/record/1987-24030-001

Interleaving
https://www.gwern.net/docs/spacedrepetition/2019-rohrer.pdf
https://abdn.pure.elsevier.com/en/publications/when-less-of-the-same-is-more-benefits-of-variability-of-practice
https://link.springer.com/article/10.1007/s11251-007-9015-8

