# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Animal Crossing, Dreams, And PAX Loses Last Of Us 2 | GameSpot After Dark #29
 - [https://www.youtube.com/watch?v=lnjzBmN0Fkw](https://www.youtube.com/watch?v=lnjzBmN0Fkw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-02-21 00:00:00+00:00

On this week’s GameSpot After Dark, we’re joined by Dave Klein from the GameSpot Universe team to talk about the incredible potential of Dreams, preserving retro games, and Sony pulling The Last Of Us Part II’s demo from PAX East. Kallie’s also played Animal Crossing: New Horizons, so we get granular about paving stones. 

TIMESTAMPS:
00:00:24 - Intro
00:00:57 - Chris From Dayton, Ohio 2.2
00:11:51 - What we've been playing/doing
00:40:53 - Sony pulling out of PAX East
00:47:40 - More NES/SNES Games for Nintendo Online
01:01:08 - Animal Crossing: New Horizons Impressions
01:14:05 - Listener Questions
01:24:17 - Outro

## The 6 Biggest Changes To Fortnite Chapter 2 Season 2
 - [https://www.youtube.com/watch?v=xg7wouwe-Rs](https://www.youtube.com/watch?v=xg7wouwe-Rs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-02-21 00:00:00+00:00

We're now in Chapter 2 of Fortnite, which is uncharted territory for Epic Games' massively-popular battle royale. One thing you can always count on, however, is the seasonal change to inject a fresh dose of content into the game. As is usually the case, the transition into a new season brings with it meaningful gameplay changes alongside the usual new customization options. In this video we're going to break down the biggest changes that have arrived in Fortnite Chapter 2 for Season 2.

Whether you're a veteran player or completely fresh to Fortnite, you'll find plenty to interest you. New content ranges from henchmen loitering around the map and new areas such as The Rig, The Grotto, The Shark, The Yacht, and The Agency,  to an interesting new story that involves spies, hideouts, fortresses, and plenty of loot--in case it wasn't abundantly clear, spies, secret agents, and subterfuge is the theme of the season. Excitingly, there's also the opportunity to align yourself with one of two factions and, at some point, you'll need to make a key decision to pledge your allegiance one way or the other.

Perhaps most intriguing of all the new additions, however, is the seemingly random inclusion of Marvel character Deadpool. Whether or not he plays a big part in the events of the season remains a mystery, but at the very least it's looking like players will be able to unlock the Merc With A Mouth's outfit to use as a skin. There's plenty of other changes for Fortnite Chapter 2, Season 2, so you should watch the video for an in-depth discussion of it all.

#FortniteChapter2 #GameSpot

## 19 Things We Learned From The Animal Crossing: New Horizons Direct
 - [https://www.youtube.com/watch?v=rKf4FafryCs](https://www.youtube.com/watch?v=rKf4FafryCs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-02-20 00:00:00+00:00

The Animal Crossing: New Horizons release date is March 20 on Switch, but we've learned a lot more about the new game thanks to the latest Nintendo Direct, including new characters, multiplayer features, island customization, and more.

Animal Crossing: New Horizons is one of the most eagerly-anticipated games of 2020. Unlike a certain other blockbuster game that we're excited about playing that day, the Switch-exclusive is about friendship, community, and achieving simple but meaningful goals. It offers a relaxing gameplay experience that very naturally fits into most people's daily lives in the world. It's exciting and wholesome in equal measure!

Nintendo hadn't revealed much New Horizons since it's initial reveal, but that all changed with the Direct event held on February 20. The 30-minute long stream recapped what we know about the game so far, but then revealed a whole bunch of new information on everything from new characters and character customization options, to the buildings and other facilities players will be able to check out and holiday updates. 

For New Horizons, players take the role of a Resident Representative for an island relocation program. Naturally, the whole setup is courtesy of shrewd businessman Tom Nook and his company. What this means is you have more control on how the island you settle on as a whole develops. You even have a hand shaping the terrain of the island thanks to a new deformation mechanic, so you should truly be able to craft the island of your dreams.

In this video, resident Animal Crossing expert Kallie Plagge breaks down all the most essential information from the New Horizons Direct. Whether you missed the event and need a quick catch-up or want to recap everything important that was revealed, you'll get a bite-sized look a everything you need to know here.

#AnimalCrossing #NewHorizons #GameSpot

## Devil May Cry 3 On Switch - 90 Minutes of Gameplay
 - [https://www.youtube.com/watch?v=U_lzJsoW8XA](https://www.youtube.com/watch?v=U_lzJsoW8XA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-02-20 00:00:00+00:00

Today on GameSpot Live, we check out Devil May Cry 3 and its new features that are now available on the Nintendo Switch. Let's see how the new weapon and style switching mechanics change up this old favorite.

## Fortnite Chapter 2 - Season 2 - Top Secret Launch Trailer
 - [https://www.youtube.com/watch?v=CXEAl8NnWJY](https://www.youtube.com/watch?v=CXEAl8NnWJY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-02-20 00:00:00+00:00

Fortnite goes Top Secret in Chapter 2 - Season 2.

