# Source:Luetin09, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC8RfCCzWsMgNspTI-GTFenQ, language:en-US

## PRIMARCH, SQUADS & CERASTUS CASTIGATOR KNIGHT - LT's ARMY UPDATE 1.1 | WARHAMMER 40K MINIS
 - [https://www.youtube.com/watch?v=zZv4nkDl6dA](https://www.youtube.com/watch?v=zZv4nkDl6dA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC8RfCCzWsMgNspTI-GTFenQ
 - date published: 2020-02-21 00:00:00+00:00

► Siege Studios Courses 2020: https://siegestudios.bigcartel.com/
► Subscribe: http://goo.gl/oeZMBS 
► Goblin Gaming: (Get - 20% off 40K Products) https://tinyurl.com/6vwcayvj
► Premium Storage Solutions: https://www.crystal-fortress.com/
► Patreon: https://www.patreon.com/Luetin 
► Twitch: http://www.twitch.tv/Luetin
► Twitter: http://twitter.com/luetin09

► BGM Credits:
► Kevin MacLeod (Royalty Free Music): http://incompetech.com/music/
► https://epidemicsound.com

This video is an opinion editorial commentary.
Copyright Disclaimer Under Section 107 of the Copyright Act 1976, allowance is made for fair use purposes such as criticism, commentary, parody, news reporting, teaching, scholarship, and research.

All works used in this video (Images, audio etc) belong to their respective authors
(This does not include the audio commentary or licensed BGM).

Games workshop, Warhammer 40,000, Warhammer, 40k, Space Marine Etc are all Trademarks of Games Workshop Ltd. Games Workshop does not endorse or support the 'Lore' videos. All views and opinions expressed in this video belong to Luetin09 and in no way reflect the views or opinions of Games Workshop Ltd.

