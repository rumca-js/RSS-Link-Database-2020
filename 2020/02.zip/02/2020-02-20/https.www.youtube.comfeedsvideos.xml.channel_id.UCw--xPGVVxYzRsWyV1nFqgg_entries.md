# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## WoT Set Photo, New NK Jemisin Novel, Avengers Playing D&D - FANTASY NEWS!
 - [https://www.youtube.com/watch?v=QIyek26gtFE](https://www.youtube.com/watch?v=QIyek26gtFE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-02-21 00:00:00+00:00

Lets just jump into the FANTASY NEWS! 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene


NEWS: 

Quest For The Time Bird: https://variety.com/2019/tv/global/anders-walter-the-quest-for-the-time-bird-1203203128/

Dark Universe Comments: https://theplaylist.net/universal-boss-dark-universe-failure-20200219/

The City We Became: https://twitter.com/orbitbooks/status/1230206656723800064?s=12

Altered Carbon Anime: https://twitter.com/NXOnNetflix/status/1229918520747712515?ref_src=twsrc%5Etfw%7Ctwcamp%5Etweetembed%7Ctwterm%5E1229918520747712515&ref_url=https%3A%2F%2Fgeektyrant.com%2Fnews%2Ffirst-look-at-netflixs-altered-carbon-anime-series-and-premiere-date

#WheelOfTime Wheel Of Time Set Photo: https://twitter.com/WOTonPrime/status/1230175260911099904

Beforeigners: https://www.youtube.com/watch?v=ASr0n5LnWnU

Avengers D&D: https://www.youtube.com/watch?v=xLCvvhzllNw

JordanCon Update: https://dragonmount.com/news/events/jordancon/jordancon-2020-r1090/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+dragonmount%2Fnews+%28Dragonmount+News%29

AMAZON MMORPG - NEW WORLD: https://www.youtube.com/watch?v=RqsLF0GWzUU&feature=youtu.be

The Sandman Begins Filming In May: https://thegww.com/neil-gaimans-the-sandman-netflix-series-will-begin-filming-this-may/?fbclid=IwAR0CR9Iflgv1JXANkDvqMbkgTb4lifebQSqTyC6e6bkErbGqNqXbefI_b34

Cyberpunk 2077 Gforce Release: https://twitter.com/verge/status/1230547694852231168

West World Trailer: https://www.youtube.com/watch?v=pDJbFA32_QY

The Hollow Places: https://www.tor.com/2020/02/20/check-out-the-cover-for-the-hollow-places-t-kingfishers-folk-horror-follow-up-to-the-twisted-ones/

## Taking on Fantasy Characters & Evolving BookTube - Piéra Forde FANTASY CHAT!
 - [https://www.youtube.com/watch?v=3d_nZ8EPt3o](https://www.youtube.com/watch?v=3d_nZ8EPt3o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-02-20 00:00:00+00:00

I sit down to talk with the magnificent Piéra Forde to talk about her work with Nevernight, being a fantasy focused actor, and the growth of #BookTube! 

Her channel: https://www.youtube.com/user/pieraforde4

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

