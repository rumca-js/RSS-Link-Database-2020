# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## CNN [#167] Duchowość jajecznicy
 - [https://www.youtube.com/watch?v=5jiBW21Fu2g](https://www.youtube.com/watch?v=5jiBW21Fu2g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-02-08 00:00:00+00:00

#cnn #dobrewiadomości #ŚwiętoOfiarowaniaPańskiego

Kazanie na niedzielę, w każdą niedzielę, czyli Słowo Na Niedzielę. 
V Niedziela zwykła  , Rok A

1. czytanie (Iz 58, 7-10)

Tak mówi Pan:

«Dziel swój chleb z głodnym, do domu wprowadź biednych tułaczy, nagiego, którego ujrzysz, przyodziej i nie odwracaj się od współziomków.

Wtedy twoje światło wzejdzie jak zorza i szybko rozkwitnie twe zdrowie. Sprawiedliwość twoja poprzedzać cię będzie, chwała Pańska iść będzie za tobą. Wtedy zawołasz, a Pan odpowie, wezwiesz pomocy, a On rzeknie: „Oto jestem!”

Jeśli u siebie usuniesz jarzmo, przestaniesz grozić palcem i mówić przewrotnie, jeśli podasz twój chleb zgłodniałemu i nakarmisz duszę przygnębioną, wówczas twe światło zabłyśnie w ciemnościach, a twoja ciemność stanie się południem».

2. czytanie (1 Kor 2, 1-5)

Bracia, przyszedłszy do was, nie przybyłem, aby błyszcząc słowem i mądrością, głosić wam świadectwo Boże.

Postanowiłem bowiem, będąc wśród was, nie znać niczego więcej, jak tylko Jezusa Chrystusa, i to ukrzyżowanego. I stanąłem przed wami w słabości i w bojaźni, i z wielkim drżeniem. A mowa moja i moje głoszenie nauki nie miały nic z uwodzących przekonywaniem słów mądrości, lecz były ukazywaniem ducha i mocy, aby wiara wasza opierała się nie na mądrości ludzkiej, lecz na mocy Bożej.

Ewangelia (Mt 5, 13-16)

Jezus powiedział do swoich uczniów:

«Wy jesteście solą ziemi. Lecz jeśli sól utraci swój smak, czymże ją posolić? Na nic się już nie przyda, chyba na wyrzucenie i podeptanie przez ludzi.

Wy jesteście światłem świata. Nie może się ukryć miasto położone na górze. Nie zapala się też lampy i nie umieszcza pod korcem, ale na świeczniku, aby świeciła wszystkim, którzy są w domu. Tak niech wasze światło jaśnieje przed ludźmi, aby widzieli wasze dobre uczynki i chwalili Ojca waszego, który jest w niebie».

__________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Targ intencji - luty
 - [https://www.youtube.com/watch?v=WQHa_W784yY](https://www.youtube.com/watch?v=WQHa_W784yY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-02-08 00:00:00+00:00

Targ intencji na luty 2020.

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#425] Zdjęcia
 - [https://www.youtube.com/watch?v=rZFLDeZGbBU](https://www.youtube.com/watch?v=rZFLDeZGbBU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-02-08 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#424] Potknięcie
 - [https://www.youtube.com/watch?v=fc7WDVhYsIo](https://www.youtube.com/watch?v=fc7WDVhYsIo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-02-07 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP
________________________________
Informacje dla tych, którzy chcą pomóc Piotrowi:
W tygodniu, od poniedziałku do piątku, potrzebuję pomocy w nakarmieniu mnie przy obiedzie oraz wieczorami przy takich czynnościach jak: nakarmienie, umycie zębów, twarzy, rąk, a także w przebraniu mnie w piżamę, następnie zdjęciu buta i skarpetki. 
Natomiast w święta, w soboty i niedziele, potrzebuję pomocy: rano przy ubieraniu mnie, nakarmieniu, umyciu zębów, pod pachami albo wykąpaniu mnie. Dodatkowo podczas korzystania z ubikacji potrzebuję wtedy jakieś pół godziny. Tak samo, jak w tygodniu, również potrzebuję kogoś do pomocy przy obiedzie i wieczorem.
Potrzebuję jeszcze dodatkowej pomocy w dojechaniu i w powrocie z rehabilitacji od środy do piątku (na ul. Domaniewską 50a). We wtorek jeżdżę na basen do Anina i byłbym wdzięczny za pomoc w przebraniu mnie na basenie, poczekaniu na mnie i ubraniu mnie. 
Gdyby ktoś miał również ochotę ze mną wyjść na spacer, pójść do kina/teatru, do pubu lub w niedzielę pójść ze mną do kościoła, to byłbym bardzo wdzięczny.
Mieszkam tuż przy skrzyżowaniu ul. Jana Pawła z ul. Anielewicza. Będę bardzo wdzięczny za każdą pomoc. 
Podaję kontakt do mnie:
mail - piter120@gmail.com
scype - piotr.slazak
komórka - 518 747 100, 515 815 388 (tylko smsy)

________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

