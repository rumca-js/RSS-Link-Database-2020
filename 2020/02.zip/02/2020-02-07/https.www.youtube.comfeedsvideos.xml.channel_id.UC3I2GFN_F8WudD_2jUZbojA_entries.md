# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Chouk Bwa & The Ångstromers - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=sO9fTElIyMI](https://www.youtube.com/watch?v=sO9fTElIyMI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-08 00:00:00+00:00

http://KEXP.ORG presents Chouk Bwa & The Ångstromers performing live at the La Chapelle by le Studio in Rennes, France, during Trans Musicales 2019. Recorded December 5, 2019.

Songs:
Vodou Ale
Ogou Bwe
Neg Ginen
Negriye

Audio Engineer: Matt Ogaz
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

Additional support by 
Jean Baptiste Le Clec’h
Jean-Marc Meleard
Jeremy Meleard

Artwork by Brendan Monroe

Special thanks to Gwenola Le Bris at Trans Musicales, Valérian Mercier at La Chapelle by le Studio, and Destination Renne

http://kexp.org
https://www.lestrans.com
https://www.tourisme-rennes.com
https://www.lachapellebylestudio.com
https://www.enthusiastmusic.com

## Chouk Bwa & The Ångstromers - Neg Ginen (Live on KEXP)
 - [https://www.youtube.com/watch?v=Fi9-1IacuE4](https://www.youtube.com/watch?v=Fi9-1IacuE4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-08 00:00:00+00:00

http://KEXP.ORG presents Chouk Bwa & The Ångstromers performing "Neg Ginen" live at the La Chapelle by le Studio in Rennes, France, during Trans Musicales 2019. Recorded December 5, 2019.

Audio Engineer: Matt Ogaz
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

Additional support by 
Jean Baptiste Le Clec’h
Jean-Marc Meleard
Jeremy Meleard

Artwork by Brendan Monroe

Special thanks to Gwenola Le Bris at Trans Musicales, Valérian Mercier at La Chapelle by le Studio, and Destination Renne

http://kexp.org
https://www.lestrans.com
https://www.tourisme-rennes.com
https://www.lachapellebylestudio.com
https://www.enthusiastmusic.com

## Chouk Bwa & The Ångstromers - Negriye (Live on KEXP)
 - [https://www.youtube.com/watch?v=1pRETp1fSQU](https://www.youtube.com/watch?v=1pRETp1fSQU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-08 00:00:00+00:00

http://KEXP.ORG presents Chouk Bwa & The Ångstromers performing "Negriye" live at the La Chapelle by le Studio in Rennes, France, during Trans Musicales 2019. Recorded December 5, 2019.

Audio Engineer: Matt Ogaz
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

Additional support by 
Jean Baptiste Le Clec’h
Jean-Marc Meleard
Jeremy Meleard

Artwork by Brendan Monroe

Special thanks to Gwenola Le Bris at Trans Musicales, Valérian Mercier at La Chapelle by le Studio, and Destination Renne

http://kexp.org
https://www.lestrans.com
https://www.tourisme-rennes.com
https://www.lachapellebylestudio.com
https://www.enthusiastmusic.com

## Chouk Bwa & The Ångstromers - Ogou Bwe (Live on KEXP)
 - [https://www.youtube.com/watch?v=Q3P2IKjX8mo](https://www.youtube.com/watch?v=Q3P2IKjX8mo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-08 00:00:00+00:00

http://KEXP.ORG presents Chouk Bwa & The Ångstromers performing "Ogou Bwe" live at the La Chapelle by le Studio in Rennes, France, during Trans Musicales 2019. Recorded December 5, 2019.

Audio Engineer: Matt Ogaz
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

Additional support by 
Jean Baptiste Le Clec’h
Jean-Marc Meleard
Jeremy Meleard

Artwork by Brendan Monroe

Special thanks to Gwenola Le Bris at Trans Musicales, Valérian Mercier at La Chapelle by le Studio, and Destination Renne

http://kexp.org
https://www.lestrans.com
https://www.tourisme-rennes.com
https://www.lachapellebylestudio.com
https://www.enthusiastmusic.com

## Chouk Bwa & The Ångstromers - Vodou Ale (Live on KEXP)
 - [https://www.youtube.com/watch?v=PwZ4rt7hM2w](https://www.youtube.com/watch?v=PwZ4rt7hM2w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-08 00:00:00+00:00

http://KEXP.ORG presents Chouk Bwa & The Ångstromers performing "Vodou Ale" live at the La Chapelle by le Studio in Rennes, France, during Trans Musicales 2019. Recorded December 5, 2019.

Audio Engineer: Matt Ogaz
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

Additional support by 
Jean Baptiste Le Clec’h
Jean-Marc Meleard
Jeremy Meleard

Artwork by Brendan Monroe

Special thanks to Gwenola Le Bris at Trans Musicales, Valérian Mercier at La Chapelle by le Studio, and Destination Renne

http://kexp.org
https://www.lestrans.com
https://www.tourisme-rennes.com
https://www.lachapellebylestudio.com
https://www.enthusiastmusic.com

## Aldous Harding - Damn (Live on KEXP)
 - [https://www.youtube.com/watch?v=6dgmzs3mdho](https://www.youtube.com/watch?v=6dgmzs3mdho)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-07 00:00:00+00:00

http://KEXP.ORG presents Aldous Harding performing "Damn" live in the KEXP studio. Recorded October 16, 2019.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://www.aldousharding.com

## Aldous Harding - Designer (Live on KEXP)
 - [https://www.youtube.com/watch?v=Og7KQV3aEhk](https://www.youtube.com/watch?v=Og7KQV3aEhk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-07 00:00:00+00:00

http://KEXP.ORG presents Aldous Harding performing "Designer" live in the KEXP studio. Recorded October 16, 2019.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://www.aldousharding.com

## Aldous Harding - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=O-_yCMPNNEo](https://www.youtube.com/watch?v=O-_yCMPNNEo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-07 00:00:00+00:00

http://KEXP.ORG presents Aldous Harding performing live in the KEXP studio. Recorded October 16, 2019.

Songs:
Designer
Treasure
The Barrel
Damn

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://www.aldousharding.com

## Aldous Harding - The Barrel (Live on KEXP)
 - [https://www.youtube.com/watch?v=0h8OZz3dFn0](https://www.youtube.com/watch?v=0h8OZz3dFn0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-07 00:00:00+00:00

http://KEXP.ORG presents Aldous Harding performing "The Barrel" live in the KEXP studio. Recorded October 16, 2019.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://www.aldousharding.com

## Aldous Harding - Treasure (Live on KEXP)
 - [https://www.youtube.com/watch?v=sf61wncorxw](https://www.youtube.com/watch?v=sf61wncorxw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-07 00:00:00+00:00

http://KEXP.ORG presents Aldous Harding performing "Treasure" live in the KEXP studio. Recorded October 16, 2019.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://www.aldousharding.com

