# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Sauron in the Second Age | Tolkien Explained
 - [https://www.youtube.com/watch?v=NhMGyTJVA4s](https://www.youtube.com/watch?v=NhMGyTJVA4s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2020-02-07 00:00:00+00:00

Get ready for Amazon's Lord of the Rings series with this rundown of Sauron's life during the second age. Covering his flight from the Valar, constructing the Rings of Power, The War of Elves and Sauron, his time in Númenor, and finally, his war with the Last Alliance.  Please consider subscribing to the channel and sharing this video to help the channel grow, so I can bring you more fun videos on Middle-earth!
 
Featured in this episode:
The Rise of Sauron
Constructing the Rings of Power
The War of Elves and Sauron
Sauron in Númenor
The War of the Last Alliance

Featuring Sauron's interactions with the elves: Celebrimbor, Gil-galad, Elrond, Cirdan, Galadriel, Oropher, and Thranduil, the Numenoreans: Ar-Pharazon, Elendil, Isildur, and Anarion, the Dwarves of Khazad-dum, as well as his servants, the Nazgul, Haradrim, Easterlings, and orcs.

--------------
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.

If your artwork is used and not credited, please let me know and I will make sure it gets added!
Fall of Númenor - Darrell Sweet
Celebrimbor - Angus McBride
Ar-Pharazon - steamey
Ar-Pharazon - Janka L
Annatar - SaMoart2019
Celebrimbor's Death - peet
Cirdan - moumou38
Gil-galad - jayeybee
Numenorean Armor - Turner Mohan
Oropher - Pelegrin
The Nazgul - spartank42
The Ships of the Faithful - Ted Nasmith
Various - WETA

#sauron #lordoftherings #lotronprime #silmarillion

