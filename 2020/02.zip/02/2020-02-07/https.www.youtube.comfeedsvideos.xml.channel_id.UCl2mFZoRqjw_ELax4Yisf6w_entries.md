# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Glowed Up Show Episode 5  - Louis Rossmann
 - [https://www.youtube.com/watch?v=biLJNwyh9VU](https://www.youtube.com/watch?v=biLJNwyh9VU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-02-08 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
Check them out: https://www.youtube.com/channel/UC04tIpCXqpsulBp_6T5Md6A Before I worked at Avatar Studios, I worked at a smaller place. The first recording session I got tossed into was with Dave Aaron. Here we meet again 13 years later.

## Hawaii hearing on SB2496 Right to Repair
 - [https://www.youtube.com/watch?v=KQnYNMz0AMI](https://www.youtube.com/watch?v=KQnYNMz0AMI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-02-08 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
👉 Thank you to everyone who has contributed, even a cent, to helping me in my journalistic efforts to travel around the country, record hearings, and lobby at them. I DID NOT RECORD THIS, I RIPPED IT FROM HAWAII'S WEBSITE! I hired someone to record it and they didn't plug into the XLR patch panel so the audio was garbage. Hopefully Hawaii doesn't copyright claim me. 
🔵 Patreon: https://www.patreon.com/rossmanngroup
🔴 Credit card: https://bit.ly/tiplouis
⚫ Cryptocurrency:
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

## Macbook user tries to submit Right To Repair testimony, gets owned by Macbook
 - [https://www.youtube.com/watch?v=_w4Byo81J50](https://www.youtube.com/watch?v=_w4Byo81J50)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-02-08 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545

## YOUR TIME IS MORE VALUABLE THAN YOUR MONEY!
 - [https://www.youtube.com/watch?v=pYI-zsLkW3s](https://www.youtube.com/watch?v=pYI-zsLkW3s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-02-08 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
The best thing you can donate to help me out is an email, phone call, letter, or in person meeting with your local representatives on why Right to Repair is important to you. 

👉 Thank you to everyone who has contributed, even a cent, to helping me in my journalistic efforts to travel around the country, record hearings, and lobby at them.
🔵 Patreon: https://www.patreon.com/rossmanngroup
🔴 Credit card: https://bit.ly/tiplouis
⚫ Cryptocurrency:
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

## Day 65 - F Eugene, we got this.
 - [https://www.youtube.com/watch?v=GoE_oWueuNs](https://www.youtube.com/watch?v=GoE_oWueuNs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-02-07 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
🔵 We fix Macbooks & offer free estimates. https://rossmanngroup.com
🔵 Send us your Macbook for repair! http://bit.ly/sendmacbook
🔵 We'll send you a box with a pre-paid shipping label for your repair! http://bit.ly/sendyourmacbook
🔵 We offer iPhone data recovery: http://bit.ly/2BDBX4G
🔵 We offer lab hard drive data recovery: http://bit.ly/labdatarecovery

👉 LEARN HOW TO DO THIS:
› In-person classes: https://bit.ly/classrg
› Beginner's guide: http://bit.ly/2k6uz84
› Support forum: $29/mo http://bit.ly/boardrepairforum

👉 Donate & post a message: http://bit.ly/postamessage 

👉 Below we list tools & recording gear we use, repair guides to help you learn, online chip sources, & donation links:

👉 BlackBerry, Oreo, & Clinton the cat's wish list: https://www.amazon.com/hz/wishlist/ls/2YC1L66N7T5BC?&sort=default

👉 CHIPS & COMPONENTS:
› http://bit.ly/2jaAOXM

👉 Discord: https://tinyurl.com/rossmatrix

👉 TOOLS USED:

✓ Soldering Irons:
› Louis' Hakko station(no tweezers): http://amzn.to/2cKkMyO 
› Paul's Hakko station(works with tweezers): http://amzn.to/2yMvWNy
› Micro Soldering Pencil: http://amzn.to/2d5MWUP
› Hot tweezers: http://amzn.to/2yMvZsZ
› Quick 861DW hot air station: https://bit.ly/atten862

✓ CHEAP HAKKO ALTERNATIVES:
› TS100 soldering iron: https://amzn.to/2Gy1Fqz
› Recommended tips: TS-C4: https://amzn.to/2GSDoz3 TS-KU https://amzn.to/2Elofke

✓ Preferred Soldering Tips
› Fine: http://amzn.to/2d5MgPn 
› Flat: https://amzn.to/2JnsDBT 
› GPU wicking: http://amzn.to/2w8chtB
› Micro soldering tip: http://amzn.to/2qUSFDh

✓ Microscopes:
› Microscope: http://amzn.to/2iLrE16 
› Barlow lens: http://amzn.to/2yMKdKf
› LED light: http://amzn.to/2nzfPT2
› CHEAP alternative microscope: http://amzn.to/2rTlHbj

✓ Soldering/Repair Supplies:
› Solder: http://amzn.to/2cKkxUp
› Desoldering braid: http://bit.ly/2otflOX
› Flux: http://bit.ly/amtechflux
› Solder paste: http://bit.ly/amtechsolderpaste
› THICK insulated jumper wire: https://amzn.to/2rvtD0A
› THIN insulated jumper wire: https://amzn.to/2I47DQY
› Kapton tape: http://amzn.to/2yN0xuq
› Tweezers: http://amzn.to/2d5NBpi
› Blades: http://amzn.to/2ByWnvF
› Freeze Spray: http://amzn.to/2BySozw
› Conformal coating: http://bit.ly/greencoate
› Conformal coating curing pen: http://bit.ly/uvpen

✓ Diagnostic tools:
› USB amp meter: http://bit.ly/2B2Lu5W
› USB-C amp meter: http://bit.ly/usbcamp
› On-Screen multimeter: http://amzn.to/2jtgY9K 
› Multimeter Probes: http://bit.ly/fineprobes
› CHEAP multimeter: http://amzn.to/2zjkg8U
› Bench PSU: CSI3005P http://bit.ly/benchsupply
› Phoneboard: https://phoneboard.co

✓ Ultrasonic Cleaning:
› ALL MACBOOKS & CELLPHONES: Crest P1200H-45: http://bit.ly/P1200H45
› PRE-TOUCHBAR MACBOOKS & CELLPHONES: Crest P500H-45: http://bit.ly/P500H45
› CELLPHONES ONLY: Crest P230H-45: http://bit.ly/P230H45 
› Branson EC cleaning fluid: http://amzn.to/2cKlBrp

✓ Desk supplies:
› Desk: http://amzn.to/2yMShdZ
› Chair: https://amzn.to/2LB8bUB
› Fume Extractor: http://amzn.to/2d5MGoD
› Work mat: http://amzn.to/2yMtlTR
› Outlets: http://amzn.to/2yNsZwo
› Gloves: http://amzn.to/2iUfumS
› Durable lightning cable: http://amzn.to/2yNHzUt
› Fine tipped snippers: http://amzn.to/2HGt4XB

✓ Screwdrivers: 
› iPhone bottom screw: http://amzn.to/2yNwX8p
› Macbook bottom screw: http://amzn.to/2AKMdVb
› Torx T3: http://amzn.to/2zjtxxH
› Torx T5 http://amzn.to/2BLNDn4
› Torx T6 http://amzn.to/2B0XIfA
› Torx T8 http://amzn.to/2CpWp68
› Phillips #0: http://amzn.to/2AJaHhM
› Phillips #000: http://amzn.to/2yNqsCl

✓ Boardview software: https://pldaniels.com/flexbv/

✓ RECORDING EQUIPMENT:
› Work cam: https://amzn.to/2QjHnt0
› Overhead cam: http://amzn.to/2eAH0oT
› Work mic: https://amzn.to/2WGIhzw
› Home mic: https://amzn.to/2xfampC
› Microscope camera: http://amzn.to/2icVQoG - mine is DISCONTINUED, closest one I can find. 
› HDMI capture: http://amzn.to/2iyGcle

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com

👉 Leave a tip for us via cryptocurrency if we've helped you out:
› Credit card: http://bit.ly/postamessage
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

## Day 66 - RENOVATION IS DONE
 - [https://www.youtube.com/watch?v=Vji7wlB_Kf4](https://www.youtube.com/watch?v=Vji7wlB_Kf4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-02-07 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
🔵 We fix Macbooks & offer free estimates. https://rossmanngroup.com
🔵 Send us your Macbook for repair! http://bit.ly/sendmacbook
🔵 We'll send you a box with a pre-paid shipping label for your repair! http://bit.ly/sendyourmacbook
🔵 We offer iPhone data recovery: http://bit.ly/2BDBX4G
🔵 We offer lab hard drive data recovery: http://bit.ly/labdatarecovery

👉 LEARN HOW TO DO THIS:
› In-person classes: https://bit.ly/classrg
› Beginner's guide: http://bit.ly/2k6uz84
› Support forum: $29/mo http://bit.ly/boardrepairforum

👉 Donate & post a message: http://bit.ly/postamessage 

👉 Below we list tools & recording gear we use, repair guides to help you learn, online chip sources, & donation links:

👉 BlackBerry, Oreo, & Clinton the cat's wish list: https://www.amazon.com/hz/wishlist/ls/2YC1L66N7T5BC?&sort=default

👉 CHIPS & COMPONENTS:
› http://bit.ly/2jaAOXM

👉 Discord: https://tinyurl.com/rossmatrix

👉 TOOLS USED:

✓ Soldering Irons:
› Louis' Hakko station(no tweezers): http://amzn.to/2cKkMyO 
› Paul's Hakko station(works with tweezers): http://amzn.to/2yMvWNy
› Micro Soldering Pencil: http://amzn.to/2d5MWUP
› Hot tweezers: http://amzn.to/2yMvZsZ
› Quick 861DW hot air station: https://bit.ly/atten862

✓ CHEAP HAKKO ALTERNATIVES:
› TS100 soldering iron: https://amzn.to/2Gy1Fqz
› Recommended tips: TS-C4: https://amzn.to/2GSDoz3 TS-KU https://amzn.to/2Elofke

✓ Preferred Soldering Tips
› Fine: http://amzn.to/2d5MgPn 
› Flat: https://amzn.to/2JnsDBT 
› GPU wicking: http://amzn.to/2w8chtB
› Micro soldering tip: http://amzn.to/2qUSFDh

✓ Microscopes:
› Microscope: http://amzn.to/2iLrE16 
› Barlow lens: http://amzn.to/2yMKdKf
› LED light: http://amzn.to/2nzfPT2
› CHEAP alternative microscope: http://amzn.to/2rTlHbj

✓ Soldering/Repair Supplies:
› Solder: http://amzn.to/2cKkxUp
› Desoldering braid: http://bit.ly/2otflOX
› Flux: http://bit.ly/amtechflux
› Solder paste: http://bit.ly/amtechsolderpaste
› THICK insulated jumper wire: https://amzn.to/2rvtD0A
› THIN insulated jumper wire: https://amzn.to/2I47DQY
› Kapton tape: http://amzn.to/2yN0xuq
› Tweezers: http://amzn.to/2d5NBpi
› Blades: http://amzn.to/2ByWnvF
› Freeze Spray: http://amzn.to/2BySozw
› Conformal coating: http://bit.ly/greencoate
› Conformal coating curing pen: http://bit.ly/uvpen

✓ Diagnostic tools:
› USB amp meter: http://bit.ly/2B2Lu5W
› USB-C amp meter: http://bit.ly/usbcamp
› On-Screen multimeter: http://amzn.to/2jtgY9K 
› Multimeter Probes: http://bit.ly/fineprobes
› CHEAP multimeter: http://amzn.to/2zjkg8U
› Bench PSU: CSI3005P http://bit.ly/benchsupply
› Phoneboard: https://phoneboard.co

✓ Ultrasonic Cleaning:
› ALL MACBOOKS & CELLPHONES: Crest P1200H-45: http://bit.ly/P1200H45
› PRE-TOUCHBAR MACBOOKS & CELLPHONES: Crest P500H-45: http://bit.ly/P500H45
› CELLPHONES ONLY: Crest P230H-45: http://bit.ly/P230H45 
› Branson EC cleaning fluid: http://amzn.to/2cKlBrp

✓ Desk supplies:
› Desk: http://amzn.to/2yMShdZ
› Chair: https://amzn.to/2LB8bUB
› Fume Extractor: http://amzn.to/2d5MGoD
› Work mat: http://amzn.to/2yMtlTR
› Outlets: http://amzn.to/2yNsZwo
› Gloves: http://amzn.to/2iUfumS
› Durable lightning cable: http://amzn.to/2yNHzUt
› Fine tipped snippers: http://amzn.to/2HGt4XB

✓ Screwdrivers: 
› iPhone bottom screw: http://amzn.to/2yNwX8p
› Macbook bottom screw: http://amzn.to/2AKMdVb
› Torx T3: http://amzn.to/2zjtxxH
› Torx T5 http://amzn.to/2BLNDn4
› Torx T6 http://amzn.to/2B0XIfA
› Torx T8 http://amzn.to/2CpWp68
› Phillips #0: http://amzn.to/2AJaHhM
› Phillips #000: http://amzn.to/2yNqsCl

✓ Boardview software: https://pldaniels.com/flexbv/

✓ RECORDING EQUIPMENT:
› Work cam: https://amzn.to/2QjHnt0
› Overhead cam: http://amzn.to/2eAH0oT
› Work mic: https://amzn.to/2WGIhzw
› Home mic: https://amzn.to/2xfampC
› Microscope camera: http://amzn.to/2icVQoG - mine is DISCONTINUED, closest one I can find. 
› HDMI capture: http://amzn.to/2iyGcle

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com

👉 Leave a tip for us via cryptocurrency if we've helped you out:
› Credit card: http://bit.ly/postamessage
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

## Hawaii sets date for Right To Repair bill!
 - [https://www.youtube.com/watch?v=PD2-oZAVq0Q](https://www.youtube.com/watch?v=PD2-oZAVq0Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-02-07 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
https://www.capitol.hawaii.gov/measure_indiv.aspx?billtype=HB&billnumber=1884 
https://www.capitol.hawaii.gov/session2020/CommReports/HB1884_HD1_HSCR76-20_.htm

## Louis Rossmann DISMANTLES Apple's PR stunt "repair program"
 - [https://www.youtube.com/watch?v=rwgpTDluufY](https://www.youtube.com/watch?v=rwgpTDluufY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-02-07 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
https://www.macrumors.com/2020/02/06/apple-independent-repair-shops-contracts/
https://www.vice.com/en_us/article/qjdjnv/apples-independent-repair-program-is-invasive-to-shops-and-their-customers-contract-shows

