# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Scamming Seniors - the BILLION DOLLAR HUSTLE
 - [https://www.youtube.com/watch?v=z_4swd12iFk](https://www.youtube.com/watch?v=z_4swd12iFk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-02-07 00:00:00+00:00

Snake-oil salesmen can't keep their hands out of grannies pockets.

I cover one of the many types of senior scams - health advice scams, where supposed "miracle cures" to incurable diseases are regularly doled out for small payments of anywhere from $49 - $999+

The Agora - a network of direct response companies and the billions of dollars they have sold in these kinds of schemes.  Their owner is Bill Bonner

some other videos I like: 
Kitboga:
https://www.youtube.com/watch?v=q6a0yvRV4pQ&
https://www.youtube.com/watch?v=J-p9JkH4RY8
music: 
b.sides - dreamin about u
defibulators - pay for that money

Senior Scams - The Billion Dollar Opportunity

