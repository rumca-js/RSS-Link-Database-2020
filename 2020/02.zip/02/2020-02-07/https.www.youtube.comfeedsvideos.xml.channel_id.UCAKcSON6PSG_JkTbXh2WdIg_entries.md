# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Bryan Ferry, Live at Royal Albert Hall 1974 - Teenage Kicks from The Current
 - [https://www.youtube.com/watch?v=8bvBQbQDxRs](https://www.youtube.com/watch?v=8bvBQbQDxRs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-02-08 00:00:00+00:00

Host Jim McGuinn talks about the music of Bryan Ferry and his newly unearthed release, 'Live at the Royal Albert Hall, 1974.'
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## The War and Treaty - artists to know (United States of Americana from The Current)
 - [https://www.youtube.com/watch?v=r9DdbV2HrfY](https://www.youtube.com/watch?v=r9DdbV2HrfY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-02-08 00:00:00+00:00

Host Bill DeVille spotlights Nashville-based duo, The War and Treaty.
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/
https://www.facebook.com/RadioHeartlandMPR/
https://twitter.com/RadioHeartland

