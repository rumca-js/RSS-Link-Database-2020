# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Could You Do What This Man Did? And Not Take Credit?
 - [https://www.youtube.com/watch?v=Kf393bGAa6I](https://www.youtube.com/watch?v=Kf393bGAa6I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-02-07 00:00:00+00:00

A clip from Under The Skin with Michael Beckwith. You can listen to the podcast from tomorrow only on Luminary: http://luminary.link/russell
Michael Beckwith is the Founder and Spiritual Director of the Agape International Spiritual Centre, a trans-denominational community headquartered in Los Angeles comprised of thousands of local members and global live streamers.

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

