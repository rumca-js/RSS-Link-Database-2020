# Source:Vlog Casha, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg, language:pl-PL

## Przepraszam
 - [https://www.youtube.com/watch?v=988Ry39BDmQ](https://www.youtube.com/watch?v=988Ry39BDmQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg
 - date published: 2020-02-07 00:00:00+00:00

🗺️ W dzisiejszym vlogu opowiem Wam o najbliższych planach oraz o tym, jak bardzo i dzięki komu zmieniło się moje życie na przestrzeni ostatnich lat.

Mój profil w serwisie Patronite:
https://patronite.pl/vlogcasha

