# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Mother and daughters told 'too big' for business class
 - [https://www.bbc.co.uk/news/business-51276016](https://www.bbc.co.uk/news/business-51276016)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-07 22:36:26+00:00

Three woman are fighting for refunds after Thai Airways forced them to sit in economy seats.

## Was this Trump's best week yet?
 - [https://www.bbc.co.uk/news/world-us-canada-51417720](https://www.bbc.co.uk/news/world-us-canada-51417720)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-07 22:12:41+00:00

From the Iowa caucus mishap to his acquittal in the Senate, this week has treated the US president well.

## Saracens fined for fielding ineligible player but keep Champions Cup place
 - [https://www.bbc.co.uk/sport/rugby-union/51415778](https://www.bbc.co.uk/sport/rugby-union/51415778)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-07 21:56:16+00:00

Saracens will stay in the Heineken Champions Cup after being fined 50,000 euros instead of a points deduction for fielding an ineligible player.

## GB trail Slovakia 2-0 in Fed Cup tie after Dart loses thriller
 - [https://www.bbc.co.uk/sport/tennis/51419491](https://www.bbc.co.uk/sport/tennis/51419491)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-07 21:49:26+00:00

Great Britain trail Slovakia 2-0 in their Fed Cup qualifier as a battling Harriet Dart loses in three sets to Viktoria Kuzmova.

## Phillip Schofield announcement: How it feels when your partner comes out as gay
 - [https://www.bbc.co.uk/news/uk-51413187](https://www.bbc.co.uk/news/uk-51413187)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-07 20:35:58+00:00

"You doubt everything you've ever believed in your life," says one woman, who still lives with her husband.

## Ex-Pakistan international Jamshed jailed over spot-fixing
 - [https://www.bbc.co.uk/news/uk-england-51419342](https://www.bbc.co.uk/news/uk-england-51419342)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-07 18:24:24+00:00

Nasir Jamshed and his co-defendants "undermined public confidence" in the sport, a judge says

## Brexit: What trade deals has the UK done so far?
 - [https://www.bbc.co.uk/news/uk-47213842](https://www.bbc.co.uk/news/uk-47213842)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-07 15:39:24+00:00

Securing a UK-EU trade deal will be top a priority over the months ahead.

## Spend a penny? Bridgend public toilets sell for £61k
 - [https://www.bbc.co.uk/news/uk-wales-51407335](https://www.bbc.co.uk/news/uk-wales-51407335)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-07 11:35:46+00:00

The Victorian toilets are the latest former public conveniences in Wales to go under the hammer.

## 'My newborn son gave another baby life'
 - [https://www.bbc.co.uk/news/stories-51389801](https://www.bbc.co.uk/news/stories-51389801)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-07 03:22:50+00:00

Valentina Daprile lost her son when he was eight days old. She and her husband donated his organs so another child could live.

