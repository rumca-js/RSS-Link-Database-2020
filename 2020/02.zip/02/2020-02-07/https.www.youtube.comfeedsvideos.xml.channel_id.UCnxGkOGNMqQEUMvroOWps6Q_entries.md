# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## A Real Astronaut on Ridley Scott’s “The Martian”
 - [https://www.youtube.com/watch?v=NLlXcO6V06g](https://www.youtube.com/watch?v=NLlXcO6V06g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-07 00:00:00+00:00

Taken from JRE #1425 w/Garrett Reisman:
https://youtu.be/3RG5pXTpLBI

## Astronaut Garrett Reisman Talks About New Series “For All Mankind”
 - [https://www.youtube.com/watch?v=BPESdvk-cOU](https://www.youtube.com/watch?v=BPESdvk-cOU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-07 00:00:00+00:00

Taken from JRE #1425 w/Garrett Reisman:
https://youtu.be/3RG5pXTpLBI

## Astronaut Garrett Reisman Was Disappointed the First Time He Saw Earth from Space | Joe Rogan
 - [https://www.youtube.com/watch?v=vSXi9PTh96w](https://www.youtube.com/watch?v=vSXi9PTh96w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-07 00:00:00+00:00

Taken from JRE #1425 w/Garrett Reisman:
https://youtu.be/3RG5pXTpLBI

## Astronaut Garrett Reisman on Space Junk and Micrometeorites
 - [https://www.youtube.com/watch?v=fS-45OV9PEM](https://www.youtube.com/watch?v=fS-45OV9PEM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-07 00:00:00+00:00

Taken from JRE #1425 w/Garrett Reisman:
https://youtu.be/3RG5pXTpLBI

## Astronaut Garrett Reisman: From Space Shuttle to SpaceX
 - [https://www.youtube.com/watch?v=Khm3iFsTZu4](https://www.youtube.com/watch?v=Khm3iFsTZu4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-07 00:00:00+00:00

Taken from JRE #1425 w/Garrett Reisman:
https://youtu.be/3RG5pXTpLBI

## Astronaut Garrett Reisman: Space is Our Destiny
 - [https://www.youtube.com/watch?v=lhDd288JhBQ](https://www.youtube.com/watch?v=lhDd288JhBQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-07 00:00:00+00:00

Taken from JRE #1425 w/Garrett Reisman:
https://youtu.be/3RG5pXTpLBI

## Elon Musk Wants to Die on Mars?
 - [https://www.youtube.com/watch?v=P4QqnuVopYQ](https://www.youtube.com/watch?v=P4QqnuVopYQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-07 00:00:00+00:00

Taken from JRE #1425 w/Garrett Reisman:
https://youtu.be/3RG5pXTpLBI

## Garrett Reisman Lived at the Bottom of the Ocean for 2 Weeks | Joe Rogan
 - [https://www.youtube.com/watch?v=wMyRjES1lII](https://www.youtube.com/watch?v=wMyRjES1lII)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-07 00:00:00+00:00

Taken from JRE #1425 w/Garrett Reisman:
https://youtu.be/3RG5pXTpLBI

## In Space Without a Suit? Here’s How You’d Die
 - [https://www.youtube.com/watch?v=n7KommHWRDE](https://www.youtube.com/watch?v=n7KommHWRDE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-07 00:00:00+00:00

Taken from JRE #1425 w/Garrett Reisman:
https://youtu.be/3RG5pXTpLBI

## Is Private Companies Handling Space Travel a Good Thing? w/Garrett Reisman | Joe Rogan
 - [https://www.youtube.com/watch?v=cT6M8FG53Qw](https://www.youtube.com/watch?v=cT6M8FG53Qw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-07 00:00:00+00:00

Taken from JRE #1425 w/Garrett Reisman:
https://youtu.be/3RG5pXTpLBI

## What is it Like to Work for Elon Musk?
 - [https://www.youtube.com/watch?v=GNG6ZzDh9C8](https://www.youtube.com/watch?v=GNG6ZzDh9C8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-07 00:00:00+00:00

Taken from JRE #1425 w/Garrett Reisman:
https://youtu.be/3RG5pXTpLBI

