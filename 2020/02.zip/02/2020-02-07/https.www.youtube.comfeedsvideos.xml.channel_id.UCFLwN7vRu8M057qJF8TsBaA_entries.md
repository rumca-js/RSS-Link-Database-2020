# Source:UpIsNotJump, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFLwN7vRu8M057qJF8TsBaA, language:en-US

## Cooking A Soufflé With Gordon Ramsay Is An Absolute Nightmare - This Is Why
 - [https://www.youtube.com/watch?v=TNN9K6IyujQ](https://www.youtube.com/watch?v=TNN9K6IyujQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLwN7vRu8M057qJF8TsBaA
 - date published: 2020-02-07 00:00:00+00:00

Cooking With Gordon Ramsay Is An Absolute Nightmare, and This Is Why. Following the strange success of the last Gordon Ramsay “cooking” episode I decided to make another, this time I am cooking a souffle, following with a different Gordon Ramsay recipe video.

I am going to continue to make live videos like this for a while, I will move away from cooking shortly of course because there is more to life than Gordon Ramsay videos. Perhaps carpentry next. I have wanted to take on a cooking video for a while, but I gotta stay fresh.

All my music and sound is from here: https://www.epidemicsound.com/referral/8pficg

Support the vidz at Patreon: https://www.patreon.com/upisnotjump 

I hope you all enjoy this new style of video, feel free yo leave in the comments things I can do other than cooking along with Gordon Ramsay and it’s likely I will try it. The souffle honestly turned out pretty good, it didn’t rise because unlike Gordon Ramsay, my ramekins were enormous. 
Excuse my terrible Cosplay as Gordon Ramsay, there aren’t many wigs online that are similar to his hair so I just kinda freestyle it. 

I’ll be taking a break from games until Half Life Alyx comes out. Ideally uintil then I will be making videos a bit more regularly, but we shall see ;)

Anywho, enjoy Cooking With Gordon Ramsay Is An Absolute Nightmare, and This Is Why

My Twitter: https://twitter.com/UpIsNotJump 
My Merch: https://www.pixelempire.com/collectio...

