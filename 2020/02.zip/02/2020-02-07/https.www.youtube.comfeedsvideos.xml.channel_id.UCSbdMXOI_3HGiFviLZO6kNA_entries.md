# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## The sickest I have ever been in VR
 - [https://www.youtube.com/watch?v=ZYdwG2NoMuE](https://www.youtube.com/watch?v=ZYdwG2NoMuE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-02-08 00:00:00+00:00

#vr #virtual reality #virtuallyodd
This is the first episode of VIRTUALLY ODD. I hope you all enjoy. This week I am talking about one of the cheapest 4K VR headset out there that is 6DOF. This is the DPVR E3 4K Vr headset and these are my stories with it.

Omega Patreon VRNinjoe's Youtube Channel:
https://www.youtube.com/user/techNextNow

Join my discord for good times
https://discord.gg/thrill
MY STREAM: 
https://www.twitch.tv/thrilluwu
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill

