# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Joe Rogan Experience #1425 - Garrett Reisman
 - [https://www.youtube.com/watch?v=3RG5pXTpLBI](https://www.youtube.com/watch?v=3RG5pXTpLBI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2020-02-07 00:00:00+00:00

Garrett Reisman is a former NASA Astronaut. He is currently a Professor of Astronautical Engineering at USC and a Senior Advisor at SpaceX.

