# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## You've NEVER Seen ANYTHING Like This Build Before...
 - [https://www.youtube.com/watch?v=jOH5T-HfqXE](https://www.youtube.com/watch?v=jOH5T-HfqXE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-02-08 00:00:00+00:00

Thanks to Micro Center for sponsoring this video!
Micro Center: https://rebrand.ly/gjmrpzo
Full Build Configuration: https://rebrand.ly/s5kb1lz
AMD Ryzen Threadripper 3990X: https://shop-links.co/1721440767994016335

ASUS TRX40 ROG Zenith II Extreme Alpha Motherboard: https://rebrand.ly/5tycke1
EVGA GeForce RTX 2080 Ti XC Video Card: https://rebrand.ly/cr7a351
G.Skill Trident Z Neo Series RGB 128GB (4 x 32GB) DDR4-3200 RAM: https://rebrand.ly/5xan0a6
Samsung 970 EVO+ 1TB SSD:
On Samsung (PAID LINK): https://shop-links.co/172144077271131136
On Best Buy (PAID LINK): https://shop-links.co/1722091657718566791
Toshiba X300 8TB 7200RPM SATA Hard Drive: https://rebrand.ly/zxcbpws
EVGA SuperNOVA 1600W Watt Power Supply: https://rebrand.ly/kewdumx
Lian Li O11 Dynamic XL ROG Computer Case: https://rebrand.ly/ecfrika
Lian Li O11D Distribution Plate G1: https://rebrand.ly/ga24f44
Bitspower Leviathan XF360 Water-Cooling Radiator: https://rebrand.ly/ozl4luv
EKWB EK-CoolStream SE 360 – Triple: https://rebrand.ly/09l7bfw
EKWB EK-Velocity sTR4 D-RGB CPU Block: https://rebrand.ly/s8aojbg
EKWB EK-Vector RTX 2080 Ti RGB Water Block: https://rebrand.ly/hv6ppha
EKWB EK-Vector RTX Backplate: https://rebrand.ly/9o66qea
Bitspower Touchaqua Notos RGB 120mm Case Fan: https://rebrand.ly/j9nb85g

Micro Center AMD Threadripper 3990X Build Guide: https://rebrand.ly/weg6amo
Micro Center AMD Ryzen Threadripper 3990X Review: https://rebrand.ly/5qwuiyb
AMD Ryzen Threadripper 3990X FAQ: https://rebrand.ly/a4l47yd
Micro Center Custom Builds Showcase: https://rebrand.ly/dwdwxse

Discuss on the forum: https://linustechtips.com/main/topic/1153566-youve-never-seen-anything-like-this-build-before/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Come see us at LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

## It's hard to watch, but I can't look away - Threadripper 3990X
 - [https://www.youtube.com/watch?v=1LaKH5etJoE](https://www.youtube.com/watch?v=1LaKH5etJoE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-02-07 00:00:00+00:00

Check out the Massdrop Object 2 Headphone Amp Desktop Edition at https://dro.ps/ltt-obj2

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire

With 64 cores and 128 threads, Threadripper has finally dethroned even Intel’s biggest configurations at a price far lower, to boot. Could it be too good to be true?

Buy a Threadripper 3990X:
On Micro Center: https://lmg.gg/cTHC6
On Amazon (PAID LINK): TBD
On Newegg (PAID LINK): TBD

Buy a Threadripper 3970X:
On Amazon (PAID LINK): https://geni.us/Ru5KB
On Newegg (PAID LINK): https://geni.us/H6txTXD

Buy a Ryzen 9 3950X:
On Amazon (PAID LINK): https://geni.us/UcA4AXn
On Newegg (PAID LINK): https://geni.us/ItkU9W
Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1153123-its-hard-to-watch-but-i-cant-look-away-threadripper-3990x/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Come see us at LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

## PIA Executives Give THEIR Side of the Story - WAN Show Feb 7, 2020
 - [https://www.youtube.com/watch?v=Va9vbM4EXbM](https://www.youtube.com/watch?v=Va9vbM4EXbM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-02-07 00:00:00+00:00

Honey automatically applies the best coupon codes to save you money at different online checkouts, try it now at https://www.joinhoney.com/linus

Visit https://www.squarespace.com/WAN and use offer code WAN for 10% off

Save 15% today with offer code LTT on Displate at https://lmg.gg/displatewan

PIA Partnership Poll: https://www.youtube.com/user/LinusTechTips/community

Full Unlisted LTT x PIA x Kape Interview Video Link: https://youtu.be/vOjOA9tWs7U
Buy an LTT shirt, hoodie, hat, and even our own water bottle at https://lmg.gg/wanlttstore

LTX2020, Save the Date - August 8+9, 2020 - https://www.ltxexpo.com/

Check out Carpool Critics, our new movie podcast: http://carpoolcritics.libsyn.com/

Podcast Download: http://traffic.libsyn.com/linustechtips/PIA_Executives_Give_THEIR_Side_of_the_Story_-_WAN_Show_Feb_7_2020_2.mp3

Timestamps: (Courtesy of Navid Jamali)

0:00 Outfit coordination
2:22 Linus’ lip balm
3:00 Private Internet Access headline
4:56 PIA debt, are they profitable?
5:43 Several quick PIA Q&A
6:24 New CTO Mark Karpelès
8:00 Kape Technologies history lesson
9:08 Mark Zuckerburg
10:14 Clips from the interview
15:17 Linus explains his side of the PIA story
16:58 Linus posts poll(poll is gone now)
18:08 Intel stock buybacks
19:56 Show AMD dominates Amazon
23:27 Back to intel stock discussion
24:44 Power flicker(lasts a few seconds)
27:31 Back to PIA poll results
[SPONSORS]
32:38 Honey
joinhoney.com/linus
33:29 SquareSpace
squarespace.com/wan offercode: WAN
34:23 FloatPlane PIA poll
36:40 ChannelSuperFun
38:20 Displate
LMG.GG/displatewan offercode: LTT
39:24 Tesla removing features from used cars
40:34 What if the software is tied to user
43:00 Future of car ownership
44:26 Cars as a service and licensing features
47:55 Ownership between the generations
50:19 Possible LTX Displate and lttstore.com
50:58 OtterWorldly beating linus
52:50 FlashPoint and death of Adobe Flash
56:22 Xbox and their new main rivals
1:00:20 Super Chats

