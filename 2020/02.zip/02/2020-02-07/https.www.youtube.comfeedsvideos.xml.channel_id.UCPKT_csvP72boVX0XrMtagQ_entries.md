# Source:Cercle, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ, language:en-US

## Lee Burridge at Omnia Bali in Indonesia for Cercle
 - [https://www.youtube.com/watch?v=h96MGcsi7GQ](https://www.youtube.com/watch?v=h96MGcsi7GQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ
 - date published: 2020-02-07 00:00:00+00:00

Lee Burridge playing an exclusive set at Omnia Bali for Cercle.

☞ Support us and get access to exclusive videos & perks: https://Cercle.lnk.to/Patreon
☞ Listen to our playlists, tracks & sets: https://Cercle.lnk.to/Playlists
☞ Subscribe to our newsletter to know about our next shows: https://Cercle.lnk.to/Members
☞ Subscribe to our YouTube channel: Cercle.lnk.to/ytcercle

☞ Lee Burridge
https://www.facebook.com/djleeburridge/
https://open.spotify.com/artist/0334oJHhRSKJRHKpE9i62h

8°50'47.9"S 115°08'27.1"E

Video credits:

Artists: Lee Burridge
Venue: Omnia Bali
Produced by Cercle
Executive producers: Philippe Tuchmann & Derek Barbolla
Film directed by: Pol Souchier & Derek Barbolla
Directors of photography: Mickaël Fidjili & Mathieu Glissant
Drone pilot: Jérémie Tridard
Sound mastering: Laurent de Boisgisson
Technical Manager: Aurélien Moisan
Post-production: Mathieu Glissant / Saison Unique Production

--
Special thanks to:
Paul Hugo, Ferdinand Fernando and Alex Koplin from Omnia Bali. 
Galerie Joseph. 

This artistic performance has been recorded live. 

Tracklist : 

00:00 - Lonely Souls) (or Fate) - Mass Digital
05:05 - Zeca Veloso - Todo Homem (Nacho Varela & Cruz Vittor Edit)
11:00  UNRELEASED
17:40 - Sébastien Léger - Secret [ALL DAY I DREAM] 
24:55 - Rowee ft. Lazarusman - Brightness In The Sky 
29:40 - Maxi Degrassi - Love Goes First
37:05 - Lee Burridge & Lost Desert - Moogami [TRYBESOF] 
44:30 - Tim Green - Vacation To Life [ALL DAY I DREAM]
53:00 - Roy Rosenfeld - Balabamba
1:00:00 - Tim Green & Sébastien Léger - Embre [LOST MIRACLE]
01:07:00 - Roy Rosenfeld - Lift Of Love
1:13:35 - Sløw Hearts - Eyepads (Tim Green Remix) 
1:21:10 - Sébastien Léger - Ashes In The Wind [ALL DAY I DREAM]
1:33:00 Q&A

______

Follow us on http://www.cercle.io

