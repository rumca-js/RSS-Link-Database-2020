# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## FANTASY POWER RANKING! (EP. 2)
 - [https://www.youtube.com/watch?v=kFutPoaGJ2I](https://www.youtube.com/watch?v=kFutPoaGJ2I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-02-08 00:00:00+00:00

I rank fantasy characters based on their power levels! You yell at me about it :)
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene
 
P.O. Box 1016 Dublin, Ohio 43017
with the backup of:
715 Shawan falls Dr. Dublin, Ohio 43017

## ADAPTING PERRIN AYBARA: Changes To Be Made!
 - [https://www.youtube.com/watch?v=xxxfsIV-3Vw](https://www.youtube.com/watch?v=xxxfsIV-3Vw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-02-07 00:00:00+00:00

Perrin Aybara is a loved character, but how much of that internalized thought can be brought to the screen? Lets talk Wheel Of Time. 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene
 
P.O. Box 1016 Dublin, Ohio 43017
with the backup of:
715 Shawan falls Dr. Dublin, Ohio 43017

