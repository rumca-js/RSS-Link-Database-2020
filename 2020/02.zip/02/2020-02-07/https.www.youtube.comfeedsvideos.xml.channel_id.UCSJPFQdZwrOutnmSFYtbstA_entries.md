# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## The Drinker's Top 5 Last Stands
 - [https://www.youtube.com/watch?v=z7PNg3pir0o](https://www.youtube.com/watch?v=z7PNg3pir0o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-02-07 00:00:00+00:00

Everyone loves a heroic last stand, so join me as I count down my top 5 best of all time.

