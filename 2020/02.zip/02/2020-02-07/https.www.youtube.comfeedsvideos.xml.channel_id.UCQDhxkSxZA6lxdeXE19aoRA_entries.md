# Source:Hugh Jeffreys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA, language:en-US

## $105 iPad 5th Generation Repair
 - [https://www.youtube.com/watch?v=ksUBbtEV4b8](https://www.youtube.com/watch?v=ksUBbtEV4b8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA
 - date published: 2020-02-08 00:00:00+00:00

It's time to work on Apples 5th Generation iPad and repair a broken one, hopefully making it fully working once again.
--------------------------------------Socials-------------------------------------
Twitter: https://twitter.com/hughjeffreys
Instagram: http://instagram.com/hughjeffreys
------------------------------iFixit Tools Used------------------------------
Get parts, tools, and free repair guides from iFixit at  
               iFixit.com/hughjeffreys 
Australia Store: https://ifix.gd/2FPxhKy



DISCLAIMER: This video and description contains affiliate links, which means that if you click on one of the product links, l will receive a small commission.

