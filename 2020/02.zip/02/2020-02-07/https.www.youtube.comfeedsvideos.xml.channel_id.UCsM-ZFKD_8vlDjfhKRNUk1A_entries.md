# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## sanah - Koncert (MUZO.FM)
 - [https://www.youtube.com/watch?v=ISrCrcamiQM](https://www.youtube.com/watch?v=ISrCrcamiQM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-02-08 00:00:00+00:00

sanah na żywo w MUZO.FM. Artystka wykonała w naszym studiu specjalne wersje live piosenek: Siebie zapytasz, Proszę pana, Szampan i Cząstka. 

0:00 Siebie Zapytasz
4:00 Proszę pana 
7:08 Szampan 
10:26 Cząstka

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Sanah: http://www.facebook.com/sanahmusic
Instagram Sanah: http://www.instagram.com/sanahmusic
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm 

#popolsku

## Johnossi - Echoes - live MUZO.FM
 - [https://www.youtube.com/watch?v=uvRWryDd39o](https://www.youtube.com/watch?v=uvRWryDd39o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-02-07 00:00:00+00:00

Johnossi Echoes na żywo w MUZO.FM. Johnossi to szwedzki duet rockowy. Utwór Echoes pochodzi z płyty Johnossi "Torch//Flame". 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Johnossi: http://www.facebook.com/johnossi
Instagram Johnossi: http://www.instagram.com/johnossi_official
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm


Johnossi Echoes - tekst

I looked down in an open well
Then I fell into a black hole
I’ve been building a wall of shame
Walking on a tightrope

If our love is a villain now
Then somebody better let go
If our love is a losing game
The player is an asshole

I’ll go there, go there don’t follow me
Guided by my ego
I got my reasons, it shadows my family 
But baby can’t you see though 
That I don’t wanna live my life through echoes
Who could ever set me free

People say you should leave him now
If you care about tomorrow 
But they don’t know what it’s all about 
Kill the time we’ve borrowed

I’ll go there, go there don’t follow me
Guided by my ego
I got my reasons, it shadows my family 
But baby can’t you see though 
That I don’t wanna live my life through echoes
Who could ever set me free

I’ll go there, go there don’t follow me
Guided by my ego
I got my reasons, it shadows my family 
But baby can’t you see though 
That I don’t wanna live my life through echoes
Live my life through echoes
Live my life through echoes
Who could ever set me free

## Panieneczki - Po cóżeś mnie moja mamo - live MUZO.FM
 - [https://www.youtube.com/watch?v=Bu9KRTd78zU](https://www.youtube.com/watch?v=Bu9KRTd78zU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-02-07 00:00:00+00:00

Panieneczki Po cóżeś mnie moja mamo na żywo w MUZO.FM. Pochodzące z Bydgoszczy neofolkowe Panieneczki od kilku lat pasjonuje historia ziemi kujawskiej. Panieneczki występowały na największych polskich festiwalach, m.in. Open’er Festival, OFF Festival czy Enea Spring Break. Brały też udział w trasie koncertowej Korteza, jako gość specjalny. Grupa Panieneczki ma na koncie dwuczęściową EPkę Opowieści zasłyszane na wiosce. 


Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Panieneczki: http://www.facebook.com/panieneczki
Instagram Panieneczki: http://www.instagram.com/panieneczki
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm 

#popolsku

