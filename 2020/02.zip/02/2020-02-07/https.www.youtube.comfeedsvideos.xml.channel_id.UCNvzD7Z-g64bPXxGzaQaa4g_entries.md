# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## UBISOFT TO ANNOUNCE 2 NEW AAA GAMES, ROCKSTAR FACES BIG CHANGE, & MORE
 - [https://www.youtube.com/watch?v=Kdlre6UV87M](https://www.youtube.com/watch?v=Kdlre6UV87M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-02-07 00:00:00+00:00

Thanks to Keeps for sponsoring this video! Head to https://keeps.com/gameranx to learn more and get 50% off your first order of hair loss treatment. 

A Rockstar Games surprise, Cyberpunk 2077 details, game announcement speculation, and more round out a week of gaming news.

Subscribe for more: http://youtube.com/gameranxtv 

*Jakes twitter: https://twitter.com/jakebaldino 
*Instagram: https://goo.gl/HH6mTW 

 discord.gg/gameranx 

 Weekly giveaway link: https://goo.gl/forms/a7zCtr1HuTkzWuOo2 


**Submit your best PHOTO MODE screenshots here:
https://forms.gle/L4FehjBzYjQEiSc39



 ~~~~STORIES~~~~


UBISOFT to announce new AAA Games
https://twinfinite.net/2020/02/ubisoft-aaa-2020-2021/

Cyberpunk side stories revealed
https://www.gamesradar.com/cyberpunk-2077-street-stories/

Dan Houser Rockstar
https://arstechnica.com/gaming/2020/02/take-two-stock-dips-as-rockstar-scribe-dan-houser-announces-departure/



Ocarina of Time 10 min
https://www.zeldadungeon.net/ocarina-of-time-beaten-in-under-10-minutes/

Last of Us Part 2 PS1
https://www.youtube.com/watch?v=B4fSSM4bI04&feature=emb_title

PS5 site https://www.playstation.com/en-gb/explore/ps5/

Wonderful 101 Kickstarter 
https://www.kickstarter.com/projects/platinumgames/the-wonderful-101-remastered?ref=dtf.ru


Crash mobile game leaked
https://twitter.com/jumpbuttoncb/status/1225592964661043200/photo/1




Rod Fergusson
https://www.gamesindustry.biz/articles/2020-02-05-the-coalitions-rod-fergusson-leaves-gears-of-war-for-diablo

**Submit your best PHOTO MODE screenshots here:
https://forms.gle/L4FehjBzYjQEiSc39

