# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## SID music: Wiklund & Fegolhuzz - The Last Truckstop 3 OST (SIDFX 8580 dual mono bx_🎧)
 - [https://www.youtube.com/watch?v=OafnWLBocn8](https://www.youtube.com/watch?v=OafnWLBocn8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-02-07 00:00:00+00:00

"The Last Truckstop 3" demo (Fairlight, 2019) OST by Wiklund & Fegolhuzz (Alexander Wiklund & Figge Wasberger). Pixel art by The Sarge. This upload works for both headphones and speakers.

Jumplist:
00:00 Tune 1 (Wiklund)
03:11 Tune 2 (Wiklund)
07:16 End (Fegolhuzz)

Made using real C64 audio in SIDFX dual mono config (identical audio data output for both chips):

Left channel: CSG 6582A 2792 25/Philippines NM235N18 1200T
Right channel: CSG 8580R5 0590 25/Hong Kong HH032232 HC-30

Project SIDFX:
http://www.sidfx.dk/

