# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## I Am Titania McGrath: The Andrew Doyle Interview
 - [https://www.youtube.com/watch?v=nMSWGbEiS1w](https://www.youtube.com/watch?v=nMSWGbEiS1w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-02-07 00:00:00+00:00

Editor-in-chief Kyle Mann and creative director Ethan Nicolle welcome a special guest: Twitter personality Titania McGrath (A.K.A. Andrew Doyle). Titania McGrath is a self-described activist, healer, and radical intersectionalist poet committed to feminism, social justice and armed peaceful protest. A regular on the live-slam poetry scene, Titania regularly performs at arts festivals, deconsecrated churches and genderqueer spiritual retreats. Her unique blend of art and activism has been variously described as 'inspiring', 'groundbreaking' and 'woke'. 

 You can check out Titania’s new book  Woke: A Guide to Social Justice

  Pre-order the new Babylon Bee Best-Of Coffee Table Book coming in 2020!

 Topics Discussed

   Who is Titania McGrath?

   How do her tweets work? 

   What are the targets of the satire?

   What is the nature of satire?

   Does Titania punch down?

   What is white privilege?

   Can comedy redeem culture and society?

   BREXIT

   Intersectionality/Wokeness

   Where’s the line we shouldn't cross in satire?

    Subscriber Portion starts at 00:39:12

