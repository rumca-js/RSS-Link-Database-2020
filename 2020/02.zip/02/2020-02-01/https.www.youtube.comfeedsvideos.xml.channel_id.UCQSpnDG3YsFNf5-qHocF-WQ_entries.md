# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## What Is Your Computer's "Secret" Windows Benchmark Score?
 - [https://www.youtube.com/watch?v=CP-CBJe0xyU](https://www.youtube.com/watch?v=CP-CBJe0xyU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2020-02-01 00:00:00+00:00

Do you know about the built in benchmark score in Windows? What is your score?

Required Commands:
CMD Command ⇨   winsat formal
Powershell command ⇨   Get-CimInstance Win32_WinSat

The commands allow you to access the "Windows Experience Index" score, which has been built into Windows since Windows Vista. And while the score was easily visible in Windows Vista and 7 right in the system properties, in Windows 8 and 10 the score is not visible there. However, the score still exists, and just has to be accessed via commands.

⇒ Become a channel member for exclusive features! Check it out here: https://www.youtube.com/ThioJoe/join

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe

⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV

My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

#Windows #Computers #Tech #ThioJoe

