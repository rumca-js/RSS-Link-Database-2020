# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Traditional Chinese remedy said to help fight Wuhan coronavirus sparks panic buying
 - [https://www.cnn.com/2020/02/01/asia/chinese-traditional-medicine-claims-coronavirus-intl-scli-hnk/index.html](https://www.cnn.com/2020/02/01/asia/chinese-traditional-medicine-claims-coronavirus-intl-scli-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-02-01 08:02:41+00:00

Could a traditional Chinese medicine help fight the Wuhan coronavirus, or is one of the country's most influential state media outlets promoting pseudoscience and false hope?

## Author Mary Higgins Clark, bestselling 'Queen of Suspense,' dies at 92
 - [https://www.cnn.com/2020/01/31/us/mary-higgins-clark-dead/index.html](https://www.cnn.com/2020/01/31/us/mary-higgins-clark-dead/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-02-01 07:54:16+00:00

Author Mary Higgins Clark, the bestselling "Queen of Suspense" known for dozens of novels sold worldwide, has died.

## Lakers honor Kobe Bryant in pregame ceremony
 - [https://www.cnn.com/2020/01/31/us/kobe-bryant-tribute-lakers-game-trnd/index.html](https://www.cnn.com/2020/01/31/us/kobe-bryant-tribute-lakers-game-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-02-01 07:38:28+00:00

When thousands of fans pour into Staples Center on Friday night for the first Los Angeles Lakers game since Kobe Bryant, one of his daughters and seven others died in a helicopter crash, they will see several tributes to the late NBA legend.

## This is what Kobe Bryant said about basketball, his wife and his daughters
 - [https://www.cnn.com/2020/02/01/us/kobe-bryant-in-his-own-words-trnd/index.html](https://www.cnn.com/2020/02/01/us/kobe-bryant-in-his-own-words-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-02-01 06:45:38+00:00

The Los Angeles Lakers paid tribute to Kobe Bryant during the team's first game since the NBA legend died in a helicopter crash.

## Tourism industry hit hard as Chinese tourists stay home
 - [https://www.cnn.com/travel/article/wuhan-coronavirus-tourism-impact/index.html](https://www.cnn.com/travel/article/wuhan-coronavirus-tourism-impact/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-02-01 06:37:53+00:00

At 6 p.m. on Saturday, Bill Egerton received an alarming email.

## Final vote on Trump acquittal will wait until next week
 - [https://www.cnn.com/collections/0130-impeachment-trial/](https://www.cnn.com/collections/0130-impeachment-trial/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-02-01 06:11:14+00:00



## US bans travel from China in attempt to contain epidemic
 - [https://www.cnn.com/2020/01/31/asia/wuhan-coronavirus-update-intl-hnk/index.html](https://www.cnn.com/2020/01/31/asia/wuhan-coronavirus-update-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-02-01 06:03:25+00:00

The number of confirmed cases of the Wuhan coronavirus is nearing 12,000, as the epidemic continues to spread worldwide, sparking travel bans and outbreaks of ugly anti-Chinese xenophobia.

## Hear LeBron James' emotional tribute to Kobe Bryant
 - [https://www.cnn.com/videos/us/2020/02/01/lebron-james-kobe-bryant-tribute-lakers-game-staples-center-sot-vpx.espn](https://www.cnn.com/videos/us/2020/02/01/lebron-james-kobe-bryant-tribute-lakers-game-staples-center-sot-vpx.espn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-02-01 05:44:00+00:00

LeBron James delivers remarks during a tribute to Kobe Bryant before the Los Angeles Lakers' first game after Bryant, his daughter and seven others were killed in a helicopter crash.

## Biden burns through cash ahead of early 2020 contests
 - [https://www.cnn.com/2020/02/01/politics/joe-biden-2020-campaign-finances/index.html](https://www.cnn.com/2020/02/01/politics/joe-biden-2020-campaign-finances/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-02-01 05:10:46+00:00

Democratic presidential candidate Joe Biden churned through his campaign donations during the last three months of 2019, leaving the former vice president with a little less than $9 million to spend ahead of the first nominating contests of the 2020 race, new filings late Friday show.

## FDA approves first drug to treat peanut allergies in children
 - [https://www.cnn.com/2020/01/31/health/peanut-allergy-treatment-palforzia-trnd/index.html](https://www.cnn.com/2020/01/31/health/peanut-allergy-treatment-palforzia-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-02-01 03:37:04+00:00

The US Food and Drug Administration approved the first drug to treat peanut allergies in children on Friday, following an advisory committee vote of approval in September.

## Zuckerberg: Facebook's new approach will 'piss off a lot of people'
 - [https://www.cnn.com/2020/01/31/tech/zuckerberg-facebook-speech-utah/index.html](https://www.cnn.com/2020/01/31/tech/zuckerberg-facebook-speech-utah/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-02-01 03:23:05+00:00

Mark Zuckerberg says Facebook will stand up for principles like free expression and encryption, even if it means facing a backlash.

## The UK has left the EU -- and the implications for the world are huge
 - [https://www.cnn.com/2020/01/31/uk/brexit-boris-johnson-uk-on-the-world-stage-intl-gbr/index.html](https://www.cnn.com/2020/01/31/uk/brexit-boris-johnson-uk-on-the-world-stage-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-02-01 01:46:31+00:00

Brexit has happened. After 1,316 days of political turmoil, the UK now stands alone as the first nation to have ever left the European Union.

## China's second highest-ranking politician says 'cover-ups will not be allowed' as infections continue to rise
 - [https://www.cnn.com/asia/live-news/coronavirus-outbreak-02-01-20-intl-hnk/index.html](https://www.cnn.com/asia/live-news/coronavirus-outbreak-02-01-20-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-02-01 01:42:11+00:00



## Anger over the Wuhan virus is sparking pushback against censorship
 - [https://www.cnn.com/2020/01/31/asia/wuhan-virus-china-censorship-intl-hnk/index.html](https://www.cnn.com/2020/01/31/asia/wuhan-virus-china-censorship-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-02-01 00:55:39+00:00

The Great Firewall of China has always been annoying, but it's not usually this deadly.

