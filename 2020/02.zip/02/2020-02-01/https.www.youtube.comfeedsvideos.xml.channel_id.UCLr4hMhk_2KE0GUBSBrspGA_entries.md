# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week #2: Czas na chusteczki wielorazowe. Elektryczny Hummer i Musk kopie tunel pod Las Vegas
 - [https://www.youtube.com/watch?v=n3123A-GIso](https://www.youtube.com/watch?v=n3123A-GIso)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-02-02 00:00:00+00:00

Oraz inne rzeczy, choć nie wiem czy jesteśmy na nie gotowi. Zapraszam na insta: http://bit.ly/InstaKlawiatur

Źródła:
Nowy singiel Elona Muska: http://bit.ly/2Ol4voJ
Stary singiel Elona Muska: http://bit.ly/2Uk0hl6
Japoński miliarder już nie szuka dziewczyny: https://cnet.co/2Uk0vZu
Chusteczki wielorazowego użytku: http://bit.ly/3b4pUMY
Film o pieluchach: http://bit.ly/2uaQV0k
Sklep sprzedający papier toaletowy wielorazowy: http://bit.ly/3aYPL8Z
Elektryczny Hummer: https://cnn.it/37RK62u
Hipopotamy Escobara: http://bit.ly/2GIZcLT
Francuzi kradli elektryczne hulajnogi: http://bit.ly/2OoCjSa
Musk kopie tunel pod Las Vegas: https://cnet.co/36P6gRH
Parlament Europejski głosuje za ujednoliceniem ładowarek: http://bit.ly/3b4I6G3

