# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Best of the Week - January 26, 2020 - Joe Rogan Experience
 - [https://www.youtube.com/watch?v=SW3Z6FLuv6s](https://www.youtube.com/watch?v=SW3Z6FLuv6s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-02 00:00:00+00:00

Best of the Week - January 26, 2020 

JRE MMA Show #87 w/Kamaru Usman:
https://www.youtube.com/watch?v=hIQTPo262rQ

JRE MMA Show #88 w/Frankie Edgar:
https://www.youtube.com/watch?v=QtIa_UQ09Ko

JRE MMA Show #89 w/Rafael Lovato Jr.:
https://www.youtube.com/watch?v=nZ7j2KFd0D4

#1419 w/Daryl Davis:
https://www.youtube.com/watch?v=oGTQ0Wj6yIg

#1420 w/Mark Normand:
https://www.youtube.com/watch?v=DEWgei2u6vM

