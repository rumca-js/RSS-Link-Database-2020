# Source:BezPlanu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g, language:pl-PL

## Hongkong - protesty [4K]
 - [https://www.youtube.com/watch?v=hPARMlIn49Q](https://www.youtube.com/watch?v=hPARMlIn49Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g
 - date published: 2020-02-01 00:00:00+00:00

Wszystkie odcinki chronologicznie: http://bit.ly/2MqAO7Q
(można też klikać w kartę "Następny odcinek" pojawiającą się pod koniec każdego filmu po prawej stronie u góry) 

Miałem nic nie filmować w Hongkongu, ale na miejscu okazało się, że to miasto naprawdę  potrafi fascynować. W tym odcinku głównie protesty, w kolejnym więcej Hongkongu

Czas akcji: 19 stycznia  2020r.

Wsparcie BezPlanu w Patronite: http://bit.ly/2KsFTZk
Instagram: http://instagram.com/bezplanu_czukesky
Facebook: https://www.facebook.com/BezPlanu.tv

---------------------------

Tu nowe tłumaczenie (po angielsku), bardziej podzielone na części :
http://bit.ly/2uyV7Ho

---------------------------

Tłumaczenie umieszczone w filmie:
Tłumaczenie z kantońskiego na angielski: @_bluegeek
Tłumaczenie z angielskiego na polski: @mindful.rover

Uwagi tłumaczy:

7:50 * - Policja brutalnie od początków protestów rozwiązuje większość nich. Są także oskarżenia o porwania, gwałty i niekiedy mordestwa obywateli

10:37 ** - Pięć postulatów to:

1. To withdraw the extradition bill
2. To stop labeling protesters as “rioters”
3. To drop charges against protesters
4. To conduct an independent inquiry into police behavior
5. To implement genuine universal suffrage for both the Legislative Council and the Chief Executive

1. Wycofanie ustawy o ekstradycji (od tego protesty się zaczęły, gdyż rząd chiński chciał, aby oskarżeni z Hong Kongu byli wysyłani do chińskich więzień. Co w praktyce by oznaczało, że przeciwnicy polityczni najprawdopodbniej kończyli w chińskich więzieniach, bez możliwości pełnomocnego procesu)
2. Zaprzestania określania protestujących chuliganami.
3. Wycofanie zarzutów stawianych wobec protestujących.
4. Rozpoczęcie niezależnego śledźtwa wobec policji.
5. Stworzenie powszechnego prawa wyborczego w do komisji legislacyjnej  i "Chief Executive". Można do porównać do naszych wyborów samorządowych i wyborów parlamentarnych.
 
10:46 *** - W 1997 roku Hongkong przeszedł pod władanie Chin z rąk Wielkiej Brytanii. Przez 50 lat, do 2047 Hongkong jest w okresie przejściowym. W 2047 zostanie oficjalnie przyłączony do Chin, a nie jak obecnie - jest "państwem w państwie".

12:47 **** - tego samego dnia było jeszcze wiele protestów w innych krajach na świecie m.in. Wielka Brytania, Nowa Zelandia, Francja, Niemcy

13:13 ***** - https://en.wikipedia.org/wiki/Joshua_Wong
Jeden z najbardziej znanych i aktywnych aktywistów, walczący o demokrację w Hong Kongu.

Dodatkowe informacje od tłumaczki z kantońskiego na angielski:

Resources: 
1. Prelude to the Dawn: Anti-extradition Movement and the Awakening of Hong Kong
A 18 mins documentary of the movement 
https://www.youtube.com/watch?v=q3WdLkJS2yg&has_verified=1

2. The New York Times Interactive article about the movement 
https://www.nytimes.com/interactive/2019/world/asia/hong-kong-protests-arc.html

3. 《Hong Kong Protest》 Buried Rights amidst the darkest night
interview of protestors who experienced police violence
https://www.youtube.com/watch?v=imIKq0rMWwA

4. HK Democratic Movement 2019 
Timeline, collage of police brutality and videos of citizens’ press conference 
https://tl.hkrev.info/en/

5. PL4HK - Supporting Hong Kong from Poland Facebook page 
https://www.facebook.com/PL4HK/

