# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## Minimalist Software Prevents THIS...
 - [https://www.youtube.com/watch?v=qRr1KRKVeh8](https://www.youtube.com/watch?v=qRr1KRKVeh8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-02-02 00:00:00+00:00

Soydevs are constantly bloatmaxxing our software and building "features" in the most superficial way redundantly in everything. What is the end result? Can we stop it? In other words, why use minimalist software?

My st build: https://github.com/lukesmithxyz/st
emoji script: https://github.com/LukeSmithxyz/voidrice/blob/master/.local/bin/dmenuunicode
Just requires xclip and dmenu
emoji list used by script: https://github.com/LukeSmithxyz/voidrice/blob/master/.local/share/larbs/emoji

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE NOW: https://lukesmith.xyz/donate 💰😎👌💯

## Color Emoji Fix in st: Suckless software now sucks less!
 - [https://www.youtube.com/watch?v=f9qNXV01yzg](https://www.youtube.com/watch?v=f9qNXV01yzg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-02-01 00:00:00+00:00

You can have color emojis in suckless software now due to a fix in libxft! Color emojis will no longer crash st, dmenu and dwm. I already have them working in my st build, but I'm sure that soon you'll be able to have color emojis in your dwm statusbar as well. Will normies take over suckless software now?

AUR: https://aur.archlinux.org/packages/libxft-bgra/
The PR: https://gitlab.freedesktop.org/xorg/lib/libxft/merge_requests/1
My st build: https://github.com/lukesmithxyz/st

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE NOW: https://lukesmith.xyz/donate 💰😎👌💯

