# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Best OPEN WORLD GANGSTER Games of All Time
 - [https://www.youtube.com/watch?v=qo5PM8NqPK8](https://www.youtube.com/watch?v=qo5PM8NqPK8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-02-02 00:00:00+00:00

Mafia and gangster games aren't as common as you'd think, so we wanted to highlight some of our favorite ones throughout the past few gaming generations.
Subscribe for more: http://youtube.com/gameranxtv

## 10 HOLY SH*T In-game Moments In Recent Video Games
 - [https://www.youtube.com/watch?v=1FaocL8_Kko](https://www.youtube.com/watch?v=1FaocL8_Kko)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-02-01 00:00:00+00:00

The best video games are often filled with surprise moments and 2019 was no slouch in that department. Here are some game moments that shocked us.
Subscribe for more: http://youtube.com/gameranxtv

