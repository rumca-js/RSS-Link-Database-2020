# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Stop Buying the MacBook Air
 - [https://www.youtube.com/watch?v=_VotJ1IZPSw](https://www.youtube.com/watch?v=_VotJ1IZPSw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-02-02 00:00:00+00:00

Visit https://www.squarespace.com/LTT and use offer code LTT for 10% off

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire

The number one selling laptop on Amazon is currently the MacBook Air… from 2017. Guys, I know the logo is pretty, but please stop buying it. 

Buy MacBook Air 
On Amazon (PAID LINK): https://geni.us/lprkiU 
On Newegg: https://geni.us/qyM1 

Buy Acer Aspire 5
On Best Buy (PAID LINK): https://shop-links.co/1722107172950410232
On Amazon (PAID LINK): https://geni.us/n9BfUY 
On Newegg: https://geni.us/WLOJA 

Buy Lenovo Flex 14
On Best Buy (PAID LINK): https://shop-links.co/1722107177805945379
On Amazon (PAID LINK): https://geni.us/hAT0q 
On Newegg: https://geni.us/zSr7Z8 

Buy Dell Inspiron 13 7000 2-in-1
On Best Buy (PAID LINK): https://shop-links.co/1722107179475740748
On Amazon (PAID LINK): https://geni.us/iywNOB 
On Newegg: https://geni.us/LVlAI 

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1151585-stop-buying-the-macbook-air/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Come see us at LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

## This Prototype PC Blew our Minds
 - [https://www.youtube.com/watch?v=SvluAN9ngmk](https://www.youtube.com/watch?v=SvluAN9ngmk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-02-01 00:00:00+00:00

Get iFixit's NEW Mahi Driver Kit today at https://www.ifixit.com/linus

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire

The Comino OTTO is a gaming computer made by a server company... and it is very clear they did their engineering homework.

Check out the Comino OTTO: https://comino.com/en/

Buy Asus X570i 
On Amazon (PAID LINK): https://geni.us/Budd 
On Newegg: https://lmg.gg/JOBAo

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1151255-the-coolest-small-form-factor-pc-comino-otto/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Come see us at LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

