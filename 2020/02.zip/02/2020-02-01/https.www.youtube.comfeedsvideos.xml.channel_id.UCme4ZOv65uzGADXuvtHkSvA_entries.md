# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## [NV#356] 12 znaków, że związek się rozpada
 - [https://www.youtube.com/watch?v=t-a24p6uCMQ](https://www.youtube.com/watch?v=t-a24p6uCMQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-02-02 00:00:00+00:00

#langustanapalmie #niecodziennyvlog #nocnyvlog
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zdjęcia i montaż: Adam Szustak OP
Muzyka: https://soundcloud.com/findinghopemusic

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#166] Boże, stań po mojej stronie!
 - [https://www.youtube.com/watch?v=fEcrnGuwk0k](https://www.youtube.com/watch?v=fEcrnGuwk0k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-02-01 00:00:00+00:00

#cnn #dobrewiadomości #ŚwiętoOfiarowaniaPańskiego

Kazanie na niedzielę, w każdą niedzielę, czyli Słowo Na Niedzielę. Święto ofiarowania Pańskiego , Rok A

1. czytanie (Ml 3, 1-4)
To mówi Pan Bóg: «Oto Ja wyślę anioła mego, aby przygotował drogę przede Mną, a potem nagle przybędzie do swej świątyni Pan, którego wy oczekujecie, i Anioł Przymierza, którego pragniecie. Oto nadejdzie, mówi Pan Zastępów. Ale kto przetrwa dzień Jego nadejścia i kto się ostoi, gdy się ukaże? Albowiem On jest jak ogień złotnika i jak ług farbiarzy. Usiądzie więc, jakby miał przetapiać i oczyszczać srebro, i oczyści synów Lewiego, i przecedzi ich jak złoto i srebro, a wtedy będą składać Panu ofiary sprawiedliwe. Wtedy będzie miła Panu ofiara Judy i Jeruzalem jak za dawnych dni i lat starożytnych».

2. czytanie (Hbr 2, 14-18)
Ponieważ dzieci uczestniczą we krwi i ciele, dlatego i Jezus także bez żadnej różnicy stał się ich uczestnikiem, aby przez śmierć pokonać tego, który dzierżył władzę nad śmiercią, to jest diabła, i aby uwolnić tych wszystkich, którzy przez całe życie przez bojaźń śmierci podlegli byli niewoli. Zaiste bowiem nie aniołów przygarnia, ale przygarnia potomstwo Abrahamowe. Dlatego musiał się upodobnić pod każdym względem do braci, aby stał się miłosiernym i wiernym arcykapłanem wobec Boga dla przebłagania za grzechy ludu.
W czym bowiem sam cierpiał będąc doświadczany, w tym może przyjść z pomocą tym, którzy są poddani próbom.

Ewangelia (Łk 2, 22-40)
Gdy upłynęły dni oczyszczenia Maryi według Prawa Mojżeszowego, rodzice przynieśli Jezusa do Jerozolimy, aby Go przedstawić Panu. Tak bowiem jest napisane w Prawie Pańskim: «Każde pierworodne dziecko płci męskiej będzie poświęcone Panu». Mieli również złożyć w ofierze parę synogarlic albo dwa młode gołębie, zgodnie z przepisem Prawa Pańskiego.
A żył w Jerozolimie człowiek, imieniem Symeon. Był to człowiek sprawiedliwy i pobożny, wyczekiwał pociechy Izraela, a Duch Święty spoczywał na nim. Jemu Duch Święty objawił, że nie ujrzy śmierci, aż nie zobaczy Mesjasza Pańskiego.
Za natchnieniem więc Ducha przyszedł do świątyni. A gdy Rodzice wnosili Dzieciątko Jezus, aby postąpić z Nim według zwyczaju Prawa, on wziął Je w objęcia, błogosławił Boga i mówił:
«Teraz, o Władco, pozwól odejść słudze Twemu 
w pokoju, według Twojego słowa. 
Bo moje oczy ujrzały Twoje zbawienie, 
któreś przygotował wobec wszystkich narodów: 
światło na oświecenie pogan 
i chwałę ludu Twego, Izraela».

A Jego ojciec i Matka dziwili się temu, co o Nim mówiono.
Symeon zaś błogosławił Ich i rzekł do Maryi, Matki Jego: «Oto Ten przeznaczony jest na upadek i na powstanie wielu w Izraelu i na znak, któremu sprzeciwiać się będą. A Twoją duszę miecz przeniknie, aby na jaw wyszły zamysły serc wielu».
Była tam również prorokini Anna, córka Fanuela z pokolenia Asera, bardzo podeszła w latach. Od swego panieństwa siedem lat żyła z mężem i pozostawała wdową. Liczyła już osiemdziesiąty czwarty rok życia. Nie rozstawała się ze świątynią, służąc Bogu w postach i modlitwach dniem i nocą. Przyszedłszy w tej właśnie chwili, sławiła Boga i mówiła o Nim wszystkim, którzy oczekiwali wyzwolenia Jerozolimy.
A gdy wypełnili wszystko według Prawa Pańskiego, wrócili do Galilei, do swego miasta Nazaret.
Dziecię zaś rosło i nabierało mocy, napełniając się mądrością, a łaska Boża spoczywała na Nim.

________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#419] Podnieś głowę
 - [https://www.youtube.com/watch?v=Z-G9tQRE_Dk](https://www.youtube.com/watch?v=Z-G9tQRE_Dk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-02-01 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

