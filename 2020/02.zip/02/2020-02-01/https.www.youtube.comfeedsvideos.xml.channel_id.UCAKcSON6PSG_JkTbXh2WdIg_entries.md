# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Elizabeth Cotten - artist to know (United States of Americana from The Current)
 - [https://www.youtube.com/watch?v=iZfgrd02vjs](https://www.youtube.com/watch?v=iZfgrd02vjs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-02-01 00:00:00+00:00

United States of Americana host Bill DeVille talks about Piedmont legend Elizabeth Cotten, a hugely influential and legendary artist whose musical career took off when she was later in life.
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/
https://www.facebook.com/RadioHeartlandMPR/
https://twitter.com/RadioHeartland

## Prince's Super Bowl XLI Halftime (Interview at The Current)
 - [https://www.youtube.com/watch?v=S4wqCQ8sEoE](https://www.youtube.com/watch?v=S4wqCQ8sEoE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-02-01 00:00:00+00:00

Longtime Prince hair stylist Kim Berry reflects on Prince's legendary halftime performance during Super Bowl XLI in 2007.
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/
https://www.facebook.com/PurpleCurrent/
https://twitter.com/PurpleCurrent

