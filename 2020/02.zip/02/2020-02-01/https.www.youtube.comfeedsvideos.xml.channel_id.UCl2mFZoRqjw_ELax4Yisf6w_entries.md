# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## A petition to end CompTIA anti repair lobbying
 - [https://www.youtube.com/watch?v=e8bny8ZGfAQ](https://www.youtube.com/watch?v=e8bny8ZGfAQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-02-02 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
👉 http://chng.it/2fcKQKWMgQ - DONATIONS MADE ON CHANGE.ORG GO TO CHANGE.ORG THE WEBSITE, NOT RIGHT TO REPAIR, THE REPAIR ASSOCIATION, ROSSMANN REPAIR GROUP, OR LOUIS ROSSMANN! I can't remove that part on the petition that asks for a donation, or edit its wording so it is more clear. I am sorry. I should've done more research before going with change.org for a petition. I realize how misleading it appears when they ask about it, but I can't remove that thing where it asks for money on the petition, or add a note that it goes to change.org - not to any of us. 

THIS VIDEO IS PURELY MY OPINION.

👉 Thank you to everyone who has contributed, even a cent, to helping me in my journalistic efforts to travel around the country, record hearings, and lobby at them. 
🔵 Patreon: https://www.patreon.com/rossmanngroup
🔴 Credit card: https://bit.ly/tiplouis
⚫ Cryptocurrency:
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

## Associated General contractors of Maine oppose Right to Repair
 - [https://www.youtube.com/watch?v=OR3kzuaQjcQ](https://www.youtube.com/watch?v=OR3kzuaQjcQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-02-02 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
👉 Thank you to everyone who has contributed, even a cent, to helping me in my journalistic efforts to travel around the country, record hearings, and lobby at them. 
🔵 Patreon: https://www.patreon.com/rossmanngroup
🔴 Credit card: https://bit.ly/tiplouis
⚫ Cryptocurrency:
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

## CTA testifies against Right to Repair in Maine, says ewaste isn't much of a problem.
 - [https://www.youtube.com/watch?v=L_LnzfVG0RY](https://www.youtube.com/watch?v=L_LnzfVG0RY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-02-02 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
👉 Thank you to everyone who has contributed, even a cent, to helping me in my journalistic efforts to travel around the country, record hearings, and lobby at them. 
🔵 Patreon: https://www.patreon.com/rossmanngroup
🔴 Credit card: https://bit.ly/tiplouis
⚫ Cryptocurrency:
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

## Logging lobbies against right to repair
 - [https://www.youtube.com/watch?v=PTesQNFTYQk](https://www.youtube.com/watch?v=PTesQNFTYQk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-02-02 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
👉 Thank you to everyone who has contributed, even a cent, to helping me in my journalistic efforts to travel around the country, record hearings, and lobby at them. 
🔵 Patreon: https://www.patreon.com/rossmanngroup
🔴 Credit card: https://bit.ly/tiplouis
⚫ Cryptocurrency:
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

## Louis Rossmann AMA
 - [https://www.youtube.com/watch?v=JrwmBxK-E3s](https://www.youtube.com/watch?v=JrwmBxK-E3s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-02-02 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
Support the stream: https://streamlabs.com/louisrossmann 

THANK YOU TO ALL OF OUR PATRONS FOR HELPING TO MAKE THESE LOBBYING TRIPS POSSIBLE!
🔵 Patreon https://www.patreon.com/rossmanngroup

›  Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4

## NEED HELP WITH HEARING IN HAWAII!
 - [https://www.youtube.com/watch?v=mONQ33k9bmQ](https://www.youtube.com/watch?v=mONQ33k9bmQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-02-02 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
https://legiscan.com/HI/bill/HB1884/2020 
https://legiscan.com/HI/bill/SB2496/2020

👉 Thank you to everyone who has contributed, even a cent, to helping me in my journalistic efforts to travel around the country, record hearings, and lobby at them. 
🔵 Patreon: https://www.patreon.com/rossmanngroup
🔴 Credit card: https://bit.ly/tiplouis
⚫ Cryptocurrency:
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

