# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## How Eric Ho Justifies Charging +$15,000 for His "Mentorship" | FAKE GURU
 - [https://www.youtube.com/watch?v=DdLTCmxVLv4](https://www.youtube.com/watch?v=DdLTCmxVLv4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-02-01 00:00:00+00:00

Eric Ho, or Master Sri

