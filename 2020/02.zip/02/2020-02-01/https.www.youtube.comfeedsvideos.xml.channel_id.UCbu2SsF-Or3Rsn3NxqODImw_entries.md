# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Free PS4 PlayStation Plus Games For February 2020 Revealed
 - [https://www.youtube.com/watch?v=Uw6JYwOnnew](https://www.youtube.com/watch?v=Uw6JYwOnnew)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-02-02 00:00:00+00:00

The free PS4 PS Plus games for February have been announced. There are five games awaiting PS4 players in the new month, three of which come from The BioShock Collection, which includes the first game, BioShock 2, and BioShock Infinite. PS4's other offering is The Sims 4, and PSVR owners can also grab Firewall: Zero Hour.

## 11 More Gory Game Deaths
 - [https://www.youtube.com/watch?v=bcO32YvB9WI](https://www.youtube.com/watch?v=bcO32YvB9WI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-02-01 00:00:00+00:00

It's been a while since we've done one of these disgusting, gross lists... so why not bring it back? (SPOILER ALERT)

These deaths are in no particular order but this video is a sequel to our first Gory Game Death list! Missed Part One? Check it out here: https://www.youtube.com/watch?v=IP0gR7nPqIw


Get to the Gore:
11. Tess with the Home Run/Last Of Us @ 00:29
10. Alex's Got Rats/Man Of Medan @ 00:58
9. Jess & Soph's First Kill/Wolfenstein: Younglood @ 1:39
8. Mattugr Helson/God Of War (2018) @ 2:25
7. Molly Schultz/GTA V @ 3:12
6. Eat The Gun/Gears 5 @ 3:39
5. Franco Delille/Dead Space 2 @ 4:16
4. Poor Soldier/RE:& Not A Hero @ 5:13
3. Helios/God Of War 3 @ 6:13
2. Spider Mastermind/Doom (2016) @ 7:02
1. Erron Black's Death Trap/Mortal Kombat 11 @ 7:55

## Escape From Tarkov's 7 Deadly Sins
 - [https://www.youtube.com/watch?v=-XFb8eVPMp8](https://www.youtube.com/watch?v=-XFb8eVPMp8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-02-01 00:00:00+00:00

From the Military Base of Reserve to the underground Labs of Tarkov, there is no PMC, Scav, USEC or BEAR that is without one of these seven deadly sins. 

Be they loot hoarders, Rouble scroungers of the bloodthirsty players who chase a fight.

Escape From Tarkov is a huge game and it is not afraid to throw you face first into its steep learning curve or punish you for your mistakes.

There are many choices and scenarios that can lead to an untimely death for any player, but much of the time these are a result of them succumbing to one of the 7 sins of Tarkov, be that of the bloodthirsty PMC, the lustful loot chaster, the gluttonous hoarder with an inventory fit to burst or the proud BEAR thinking they can take on the world with nothing but an AK and a vest.

In the video above Dave breaks down all of these sins, which we have no doubt even you dear reader, are guilty of.

