# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Gabríel Ólafs - Absent Minded (Live on KEXP)
 - [https://www.youtube.com/watch?v=EfDAXga12SA](https://www.youtube.com/watch?v=EfDAXga12SA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-02 00:00:00+00:00

http://KEXP.ORG presents Gabríel Ólafs performing "Absent Minded" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 7, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Bergur Thorisson
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://www.gabrielolafs.com

## Gabríel Ólafs - Bára (Live on KEXP)
 - [https://www.youtube.com/watch?v=6gF99sp0L5Y](https://www.youtube.com/watch?v=6gF99sp0L5Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-02 00:00:00+00:00

http://KEXP.ORG presents Gabríel Ólafs performing "Bára" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 7, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Bergur Thorisson
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://www.gabrielolafs.com

## Gabríel Ólafs - Cyclist Waltz (Live on KEXP)
 - [https://www.youtube.com/watch?v=tOHMspccFGQ](https://www.youtube.com/watch?v=tOHMspccFGQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-02 00:00:00+00:00

http://KEXP.ORG presents Gabríel Ólafs performing "SONG" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 7, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Bergur Thorisson
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://www.gabrielolafs.com

## Gabríel Ólafs - Filma (Live on KEXP)
 - [https://www.youtube.com/watch?v=QrxdZPprz2k](https://www.youtube.com/watch?v=QrxdZPprz2k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-02 00:00:00+00:00

http://KEXP.ORG presents Gabríel Ólafs performing "Filma" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 7, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Bergur Thorisson
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://www.gabrielolafs.com

## Gabríel Ólafs - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=zig9biqG6bk](https://www.youtube.com/watch?v=zig9biqG6bk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-02 00:00:00+00:00

http://KEXP.ORG presents Gabríel Ólafs performing live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 7, 2019.

Songs:
Absent Minded
Bára
Cyclist Waltz
Lóa (Variation)
Staircase Sonata
Filma

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Bergur Thorisson
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://www.gabrielolafs.com

## Gabríel Ólafs - Lóa (Variation) (Live on KEXP)
 - [https://www.youtube.com/watch?v=qzYD2bCzaeM](https://www.youtube.com/watch?v=qzYD2bCzaeM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-02 00:00:00+00:00

http://KEXP.ORG presents Gabríel Ólafs performing "Lóa (Variation)" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 7, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Bergur Thorisson
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://www.gabrielolafs.com

## Gabríel Ólafs - Staircase Sonata (Live on KEXP)
 - [https://www.youtube.com/watch?v=-QiAYSu-PnY](https://www.youtube.com/watch?v=-QiAYSu-PnY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-02 00:00:00+00:00

http://KEXP.ORG presents Gabríel Ólafs performing "Staircase Sonata" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 7, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Bergur Thorisson
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://www.gabrielolafs.com

## Seabear - Arms (Live on KEXP)
 - [https://www.youtube.com/watch?v=IQH7X_k2cXc](https://www.youtube.com/watch?v=IQH7X_k2cXc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-01 00:00:00+00:00

http://KEXP.ORG presents Seabear performing "Arms" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 7, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director & Editor: Scott Holpainen

http://kexp.org
https://www.facebook.com/seabearband

## Seabear - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=KrmkQ-z-ERk](https://www.youtube.com/watch?v=KrmkQ-z-ERk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-01 00:00:00+00:00

http://KEXP.ORG presents Seabear performing live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 7, 2019.

Songs:
Arms
Waterphone
Leafmask
Song 4
Wolfboy

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director & Editor: Scott Holpainen

http://kexp.org
https://www.facebook.com/seabearband

## Seabear - Leafmask (Live on KEXP)
 - [https://www.youtube.com/watch?v=vPJJZgAubF0](https://www.youtube.com/watch?v=vPJJZgAubF0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-01 00:00:00+00:00

http://KEXP.ORG presents Seabear performing "Leafmask" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 7, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director & Editor: Scott Holpainen

http://kexp.org
https://www.facebook.com/seabearband

## Seabear - Waterphone (Live on KEXP)
 - [https://www.youtube.com/watch?v=favH8xDNgJA](https://www.youtube.com/watch?v=favH8xDNgJA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-01 00:00:00+00:00

http://KEXP.ORG presents Seabear performing "Waterphone" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 7, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director & Editor: Scott Holpainen

http://kexp.org
https://www.facebook.com/seabearband

## Seabear - Wolfboy (Live on KEXP)
 - [https://www.youtube.com/watch?v=dpX56m00toY](https://www.youtube.com/watch?v=dpX56m00toY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-01 00:00:00+00:00

http://KEXP.ORG presents Seabear performing "Wolfboy" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 7, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director & Editor: Scott Holpainen

http://kexp.org
https://www.facebook.com/seabearband

