# Source:Hugh Jeffreys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA, language:en-US

## My TV blew up, can I fix it?
 - [https://www.youtube.com/watch?v=0V0RaKohxZ8](https://www.youtube.com/watch?v=0V0RaKohxZ8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA
 - date published: 2020-02-01 00:00:00+00:00

Sometimes things blow up, but that doesn't mean it needs to be thrown out.
--------------------------------------Socials-------------------------------------
Twitter: https://twitter.com/hughjeffreys
Instagram: http://instagram.com/hughjeffreys
------------------------------iFixit Tools Used------------------------------
Get parts, tools, and free repair guides from iFixit at  
               iFixit.com/hughjeffreys 
Australia Store: https://ifix.gd/2FPxhKy



DISCLAIMER: This video and description contains affiliate links, which means that if you click on one of the product links, l will receive a small commission.

