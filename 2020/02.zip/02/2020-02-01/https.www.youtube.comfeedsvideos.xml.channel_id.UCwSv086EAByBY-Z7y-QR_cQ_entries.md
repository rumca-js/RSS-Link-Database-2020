# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Przewodniczący PE: Auschwitz nie zbudowali Niemcy, tylko ...
 - [https://www.youtube.com/watch?v=II15LQGvJ-Y](https://www.youtube.com/watch?v=II15LQGvJ-Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2020-02-02 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
-------------------------------------------------------------
👀 Mroczne Podcasty: https://goo.gl/cdCFKe
👀 Tatusiek: http://bit.ly/3aSCheE
-------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
-------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
-------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
-------------------------------------------------------------
💲 wsparcie
💰 http://bit.ly/2ETKSyN
-------------------------------------------------------------
✅źródła:
Link 1:                   http://bit.ly/3b0NOJ2
Link 2:                   http://bit.ly/390qidu
-------------------------------------------------------------
🖼Grafika: 
PAP / EPA / Patrick Seeger 
http://bit.ly/2BvtOyk
http://bit.ly/2lxUwAU
---
Christopher Furlong / Getty Images
http://bit.ly/2R92ON4
-------------------------------------------------------------
💡 Tagi: #Niemcy #DavidSassoli
-------------------------------------------------------------

## Taśmy Trumpa! Co myśli o Unii Europejskiej, Polsce i Ukrainie?
 - [https://www.youtube.com/watch?v=lREj5BUo7Io](https://www.youtube.com/watch?v=lREj5BUo7Io)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2020-02-02 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
-------------------------------------------------------------
👀 Mroczne Podcasty: https://goo.gl/cdCFKe
👀 Tatusiek: http://bit.ly/3aSCheE
-------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
-------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
-------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
-------------------------------------------------------------
💲 wsparcie
💰 http://bit.ly/2ETKSyN
-------------------------------------------------------------
✅źródła:
Link 1:                   http://bit.ly/2uYaUja
Link 2:                   http://bit.ly/2toEFZY
Link 3:                   http://bit.ly/2UofT74
Link 4:                   http://bit.ly/3aWo0h8
-------------------------------------------------------------
🖼Grafika: 
canva.com - http://bit.ly/39ba1Td
-------------------------------------------------------------
💡 Tagi: #Trump
-------------------------------------------------------------

