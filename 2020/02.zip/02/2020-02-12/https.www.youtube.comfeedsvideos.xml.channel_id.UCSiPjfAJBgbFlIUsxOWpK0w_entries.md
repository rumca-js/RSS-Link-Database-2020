# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Sooo I have a favor to ask of you...
 - [https://www.youtube.com/watch?v=EWgrQ18MaGg](https://www.youtube.com/watch?v=EWgrQ18MaGg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2020-02-13 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 Pomplamoose was nominated for a Shorty Award! To vote: https://shortyawards.com/category/12th/youtube-musician The only way we can win this thing is if you vote everyday this week. Thank you so so much for helping us reach more people!

Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

