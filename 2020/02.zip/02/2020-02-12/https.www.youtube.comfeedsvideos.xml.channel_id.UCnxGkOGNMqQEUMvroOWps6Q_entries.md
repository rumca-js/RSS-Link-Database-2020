# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Dana White is Becoming a Boxing Promoter
 - [https://www.youtube.com/watch?v=0STxRi98fnc](https://www.youtube.com/watch?v=0STxRi98fnc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-13 00:00:00+00:00

Taken from JRE MMA #91: https://youtu.be/15Ff4I6qsfU

## Is Manny Pacquiao Versus Conor McGregor Going to Happen?
 - [https://www.youtube.com/watch?v=HFa6zknaxQ8](https://www.youtube.com/watch?v=HFa6zknaxQ8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-13 00:00:00+00:00

Taken from JRE MMA #91: https://youtu.be/15Ff4I6qsfU

## Joe Rogan and Radio Rahim on Chavez vs. Jacobs
 - [https://www.youtube.com/watch?v=Be3XV80AXak](https://www.youtube.com/watch?v=Be3XV80AXak)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-13 00:00:00+00:00

Taken from JRE MMA #91: https://youtu.be/15Ff4I6qsfU

## Joe Rogan on the Most Important Skill in MMA
 - [https://www.youtube.com/watch?v=HppXtjVNAUw](https://www.youtube.com/watch?v=HppXtjVNAUw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-13 00:00:00+00:00

Taken from JRE MMA #91: https://youtu.be/15Ff4I6qsfU

## Joe Rogan: Errol Spence Jr. versus Terence Crawford is THE Fight!
 - [https://www.youtube.com/watch?v=FkS2mkX8DXk](https://www.youtube.com/watch?v=FkS2mkX8DXk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-13 00:00:00+00:00

Taken from JRE MMA #91: https://youtu.be/15Ff4I6qsfU

## Joe Rogan: I’m Taking the Night Off for Fury vs. Wilder 2
 - [https://www.youtube.com/watch?v=QH_9zmKmj8U](https://www.youtube.com/watch?v=QH_9zmKmj8U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-13 00:00:00+00:00

Taken from JRE MMA #91: https://youtu.be/15Ff4I6qsfU

## Radio Rahim Filmed Infamous James Toney Sparring Session | Joe Rogan
 - [https://www.youtube.com/watch?v=faDkPoKmGaQ](https://www.youtube.com/watch?v=faDkPoKmGaQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-13 00:00:00+00:00

Taken from JRE #91 w/Radio Rahim:
https://youtu.be/15Ff4I6qsfU

## Radio Rahim: Sparring, Not Fighting, Destroy Fighters
 - [https://www.youtube.com/watch?v=dBzyJ1XrF_w](https://www.youtube.com/watch?v=dBzyJ1XrF_w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-13 00:00:00+00:00

Taken from JRE MMA #91: https://youtu.be/15Ff4I6qsfU

## The Story Behind the "To This Day" Deontay Wilder Meme w/Radio Rahim | Joe Rogan
 - [https://www.youtube.com/watch?v=s_KiXdCkc2U](https://www.youtube.com/watch?v=s_KiXdCkc2U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-13 00:00:00+00:00

Taken from JRE #91 w/Radio Rahim:
https://youtu.be/15Ff4I6qsfU

## Joe Rogan Reacts to USA Marijuana Laws Map
 - [https://www.youtube.com/watch?v=hacWUzKrxUM](https://www.youtube.com/watch?v=hacWUzKrxUM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-12 00:00:00+00:00

Taken from JRE #1426 w/Justin Martindale: 
https://youtu.be/_TStVaAMT3U

## Joe Rogan Watches 2020 Iowa Caucus Coin Flip w/Justin Martindale
 - [https://www.youtube.com/watch?v=CjDE4nB_K58](https://www.youtube.com/watch?v=CjDE4nB_K58)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-12 00:00:00+00:00

Taken from JRE #1426 w/Justin Martindale: 
https://youtu.be/_TStVaAMT3U

## Joe Rogan and Justin Martindale Pay Tribute to Mitzy Shore
 - [https://www.youtube.com/watch?v=2y_HCI_F63M](https://www.youtube.com/watch?v=2y_HCI_F63M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-12 00:00:00+00:00

Taken from JRE #1426 w/Justin Martindale: https://youtu.be/_TStVaAMT3U

## Joe Rogan is Worried About the Coronavirus
 - [https://www.youtube.com/watch?v=6kgj1nvICJM](https://www.youtube.com/watch?v=6kgj1nvICJM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-12 00:00:00+00:00

Taken from JRE #1426 w/Justin Martindale: 
https://youtu.be/_TStVaAMT3U

## LA's Homeless Problem & Mental Health w/Justin Martindale | Joe Rogan
 - [https://www.youtube.com/watch?v=8543ZWfFidg](https://www.youtube.com/watch?v=8543ZWfFidg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-12 00:00:00+00:00

Taken from JRE #1426 w/Justin Martindale: 
https://youtu.be/_TStVaAMT3U

