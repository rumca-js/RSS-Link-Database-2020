# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## HoomanTV Faked Being On Ellen For Clout
 - [https://www.youtube.com/watch?v=TeCG_1-7gCg](https://www.youtube.com/watch?v=TeCG_1-7gCg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-02-13 00:00:00+00:00

HoomanTV says Ellen is all about his SHAMPOO PRANKS, and GOLD DIGGER PRANKS. Don't believe him? Go ask Justin Beiber, Shaq or Drake.  They'll all vouch that this man is a true comedy legend.

