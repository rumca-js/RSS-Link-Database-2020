# Source:Techaltar, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA, language:en-US

## Why Google helps other search engines compete
 - [https://www.youtube.com/watch?v=eOZFnMwkjV8](https://www.youtube.com/watch?v=eOZFnMwkjV8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA
 - date published: 2020-02-12 00:00:00+00:00

Sponsored by Skillshare. The first 500 people who click this link will get 2 free months of Skillshare Premium:  https://skl.sh/techaltar15

[[[ ABOUT THIS VIDEO ]]]: 

We thought Google had already won. Almost a monopoly that couldn't meaningfully be challenged anymore. And yet DuckDuckGo, Ecosia, Startpage, Qwant and many more have risen to take on the behemoth.  - The Story Behind - Episode 62

[[[ TECHALTAR LINKS ]]]: 

Merch: 
http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 

If you want to support TechAltar directly:
https://flattr.com/@techaltar

My video gear: 
https://kit.co/TechAltar/video-gear 

[[[ ATTRIBUTIONS ]]]: 

Music by Edemski:
https://soundcloud.com/edemski
https://facebook.com/edemskimusic

