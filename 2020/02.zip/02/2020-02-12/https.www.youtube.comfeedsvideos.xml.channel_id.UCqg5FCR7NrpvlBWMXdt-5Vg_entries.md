# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Four Years in the Making, Outriders is the Next Game from People Can Fly  | Gameumentary
 - [https://www.youtube.com/watch?v=0EmKYr9jvGY](https://www.youtube.com/watch?v=0EmKYr9jvGY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-02-13 00:00:00+00:00

Read our full hands-on preview written by Nick Calandra: https://www.escapistmagazine.com/v2/outriders-packs-fun-third-person-combat-but-might-lack-a-unique-hook-hands-on/

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Just a quick interview / preview to go alongside our full-written coverage of the latest title from People Can Fly, Outriders. Coming to the PS5, PS4, Xbox One, Xbox Series X and PC this holiday.

Disclosure: Square Enix covered our travel & accommodations for this event. No payment was made for our coverage.

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►► https://sharkrobot.com/collections/zero-punctuation 

Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 

Like us on Facebook ►► http://www.facebook.com/EscapistMag

Follow us on Twitter ►► https://twitter.com/EscapistMag

#Outriders

## The Walking Dead: Saints and Sinners (Zero Punctuation)
 - [https://www.youtube.com/watch?v=UKUEn8FD4YI](https://www.youtube.com/watch?v=UKUEn8FD4YI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-02-12 00:00:00+00:00

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

This week on Zero Punctuation, Yahtzee reviews The Walking Dead: Saints and Sinners.

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►► https://sharkrobot.com/collections/zero-punctuation 

Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 

Like us on Facebook ►► http://www.facebook.com/EscapistMag

Follow us on Twitter ►► https://twitter.com/EscapistMag

