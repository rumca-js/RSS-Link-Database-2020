# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Johnossi - koncert (MUZO.FM)
 - [https://www.youtube.com/watch?v=uiYnkSHPp2E](https://www.youtube.com/watch?v=uiYnkSHPp2E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-02-12 00:00:00+00:00

Johnossi na żywo w MUZO.FM. Johnossi zagrali w naszym studiu utwory: Gone Forever, Longer The Wait, Harder The Fall, Echoes i What's The Point. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Johnossi: http://www.facebook.com/johnossi
Instagram Johnossi: http://www.instagram.com/johnossi_official
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm

