# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Dear Authors: Writing Magic Systems (The Cult Of Brandon)
 - [https://www.youtube.com/watch?v=Xg42d7fcvSs](https://www.youtube.com/watch?v=Xg42d7fcvSs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-02-13 00:00:00+00:00

Here we are pushing back against some of what is being said about magic systems in the fantasy genre. Many complain hard magic systems are the way to go! Others want the return of the soft systems dominating what is popular in the fantasy genre. I say, why not rules VS wonder based magic systems? 

Brandon's Magic System lecture: https://www.youtube.com/watch?v=jXAcA_y3l6M&t=599s
Video on Brandon's Magic: https://www.youtube.com/watch?v=KvloDEpgj9U

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## I BECOME ONE WITH THE PACKAGES 📦☯️
 - [https://www.youtube.com/watch?v=L7itVC_fDqk](https://www.youtube.com/watch?v=L7itVC_fDqk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-02-12 00:00:00+00:00

You send me things, I open them things get weird... er then before. 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene
 
P.O. Box 1016 Dublin, Ohio 43017
with the backup of:
715 Shawan falls Dr. Dublin, Ohio 43017

