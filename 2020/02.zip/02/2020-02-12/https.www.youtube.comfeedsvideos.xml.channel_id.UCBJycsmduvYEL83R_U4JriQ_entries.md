# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Samsung Galaxy Z Flip Impressions: Mixed Feelings!
 - [https://www.youtube.com/watch?v=hiiVniW6l7E](https://www.youtube.com/watch?v=hiiVniW6l7E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-02-12 00:00:00+00:00

Foldable glass and flagship build? Galaxy Z flip proves folding phones are evolving fast... but does that mean this one's worth $1380?

Galaxy S20: https://youtu.be/ZdC9soHxVC8
Galaxy S20 Ultra: https://youtu.be/WPsvw_Db-y4

MKBHD Merch: http://shop.MKBHD.com

Video Gear I use: http://kit.co/MKBHD/video-gear#recom...
Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Connery by Alltta
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

