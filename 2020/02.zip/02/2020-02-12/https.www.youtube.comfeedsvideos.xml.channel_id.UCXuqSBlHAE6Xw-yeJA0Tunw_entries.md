# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Even Corsair Knows Air Cooling is Better - A500 Review
 - [https://www.youtube.com/watch?v=rq8v53y3lRA](https://www.youtube.com/watch?v=rq8v53y3lRA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-02-13 00:00:00+00:00

Get an unrestricted 30-day free trial of FreshBooks at https://www.freshbooks.com/techtips

Thanks to Thermal Grizzly for sponsoring today's episode! Buy Thermal Grizzly Conductonaut on Amazon (PAID LINK) at https://lmg.gg/conductonaut

It’s been 10 years since Corsair was in the air-cooler game, so why come back? Can Corsair compete with the huge selection of already excellent CPU coolers from competitors like Noctua and Deepcool? Let's benchmark it and find out! 

Buy Corsair A500 CPU Cooler:
On Amazon (PAID LINK): https://geni.us/xzXI19b
On Newegg (PAID LINK): https://lmg.gg/9KS4S

Buy Noctua NH-D15:
On Amazon (PAID LINK): https://geni.us/0HVD
On Newegg (PAID LINK): https://geni.us/foplrPc

Buy Deepcool Assassin III:
On Amazon (PAID LINK): https://geni.us/g2i5
On Newegg (PAID LINK): https://geni.us/d0yqTU

Buy Intel 9900K:
On Amazon (PAID LINK): https://geni.us/qgddV
On Newegg (PAID LINK): https://geni.us/n6TD

Buy Extech 407750 Sound Meter:
On Amazon (PAID LINK): https://geni.us/6Qke
On Newegg (PAID LINK): https://geni.us/LqeNxe

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1155219-ltt-even-corsair-knows-water-cooling-sucks/

The BEST Cooling Solution - Air or Water - FINAL ANSWER: https://youtu.be/hr0qLLv3dKc

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Come see us at LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

## Apple BEAT us... but we're STILL TRYING! - Hack Pro pt 4
 - [https://www.youtube.com/watch?v=zNVCP9PeX9c](https://www.youtube.com/watch?v=zNVCP9PeX9c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-02-12 00:00:00+00:00

Get 20% OFF + Free Shipping at Manscaped.com with code TECH - https://mnscpd.com/2ML8ni3

Add Honey for FREE and start collecting Honey Gold today at https://joinhoney.com/ltt

In part 4 of this series, we put together everything we have, throw water at it and pray it boots up. Why? Because the Mac Pro showed up and we need to show it who's boss around these parts. Or try to if everything goes as planned.

Watch part 1: https://youtu.be/o3HlyPsf9uo
Watch part 2: https://youtu.be/194aNoSSvS4
Watch part 3: https://youtu.be/Td1lgAW08ho

Buy EKWB CPU Block
On Amazon (PAID LINK): https://geni.us/0Hep
On Newegg (PAID LINK): https://geni.us/QLpltzD

Buy EKWB G 1/4 Fittings
On Amazon (PAID LINK): https://geni.us/toxxAy

Buy EKWB tubing
On Amazon (PAID LINK): https://geni.us/m7RdmM
On Newegg (PAID LINK): https://geni.us/BThvN5

Buy EKWB GPU Blocks
On Amazon (PAID LINK): https://geni.us/mGxqo
On Newegg (PAID LINK): https://geni.us/AiZHJ

Buy Aorus C621 Xtreme
On Amazon (PAID LINK): https://geni.us/A62g

Buy Radeon Vii's
On Amazon (PAID LINK): https://geni.us/BXCd07
On Newegg (PAID LINK): https://geni.us/o6cXgI

Buy Fenvi FV-T919
On Amazon (PAID LINK): https://geni.us/zQb8Gx
On Newegg (PAID LINK): https://geni.us/8Ahf

Buy SilverStone ST1200-PTS
On Amazon (PAID LINK): https://geni.us/LMDRu
On Newegg (PAID LINK): https://geni.us/yh9AFM

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://lmg.gg/NUVbg

Our Affiliates, Referral Programs, and Sponsors: https://linustechtips.com/main/topic/75969-linus-tech-tips-affiliates-referral-programs-and-sponsors
Displate metal posters: https://lmg.gg/displateltt

Linus Tech Tips merchandise at http://www.LTTStore.com/
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips
Our production gear: http://geni.us/cvOS
Our Chrono.gg game store: https://ltt.chrono.gg/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

