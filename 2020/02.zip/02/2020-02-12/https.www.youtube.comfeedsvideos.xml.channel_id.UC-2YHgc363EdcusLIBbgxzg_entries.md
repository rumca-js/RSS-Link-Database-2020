# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## 10 Surprising Uses For Urine | Random Thursday
 - [https://www.youtube.com/watch?v=wGDvJ1NuZMI](https://www.youtube.com/watch?v=wGDvJ1NuZMI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2020-02-13 00:00:00+00:00

You flush it down the drain every day, but urine is surprisingly useful, and once upon a time, pretty valuable. So today we look at 10 ways urine has been used, and continues to be used today.


Support me on Patreon!
http://www.patreon.com/answerswithjoe

Not a fan of Patreon? Become a member!
https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Get cool nerdy t-shirts at
http://www.answerswithjoe.com/shirts

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

