# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## The Weird Lens That Can Invisibly Photograph Mirrors (Tilt Shift)
 - [https://www.youtube.com/watch?v=ZlaeWRMYwGg](https://www.youtube.com/watch?v=ZlaeWRMYwGg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2020-02-12 00:00:00+00:00

I bet you've never even heard of it
⇒ Become a channel member for exclusive features! Check it out here: https://www.youtube.com/ThioJoe/join

Timestamps:
0:00 - Intro
1:11 - Lens Shifting
2:45 - Mirror Demonstration
3:23 - Lens Tilting
4:53 - How Tilt Focusing Works
6:04 - Modern vs Old Cameras
7:30 - Shifting vs Wide Angle Lenses
8:23 - Acquiring a Tilt-Shift Lens

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe

⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV

My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

#Photography #Tech #ThioJoe

