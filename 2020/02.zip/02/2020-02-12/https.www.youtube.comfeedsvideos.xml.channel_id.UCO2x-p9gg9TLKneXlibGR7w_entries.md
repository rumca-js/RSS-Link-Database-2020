# Source:Snazzy Labs, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w, language:en-US

## THIS $130 TAPE CAN HOLD 30TB!
 - [https://www.youtube.com/watch?v=4wRiJBFYn3A](https://www.youtube.com/watch?v=4wRiJBFYn3A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w
 - date published: 2020-02-12 00:00:00+00:00

Install Raid for Free ✅ IOS: https://clcr.me/Tpoyhg ✅ ANDROID: https://clcr.me/rXwNbS ✅ PC: https://clcr.me/1WgClp and get a special starter pack 💥Available only for the next 30 days

mLogic mRack - https://www.mlogic.com/products/mrack-lto-8
mLogic mTape - https://www.mlogic.com/products/mtape-thunderbolt-lto-8

Snazzy Labs launched a video about Margaret last year—our rescued server that has a 336TB capacity and we use to edit video live over the network via 10 gigabit ethernet. It's been super amazing, but while redundant, it isn't a backup so we're adding Edith to the mix: an i7 Mac mini that communicates with an LTO-8 tape drive made by mLogic.

Follow me on Twitter - http://twitter.com/snazzyq
Follow me on Instagram - http://instagram.com/snazzyq
Download my Podcast "Flashback" - http://relay.fm/flashback

