# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Sunna Fridjons - Bergmál (Live on KEXP)
 - [https://www.youtube.com/watch?v=OuewPjfGEsc](https://www.youtube.com/watch?v=OuewPjfGEsc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-13 00:00:00+00:00

http://KEXP.ORG presents Sunna Fridjons performing "Bergmál" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 8, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://sunnafridjons.bandcamp.com

## Sunna Fridjons - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=Za7R0-4RjZc](https://www.youtube.com/watch?v=Za7R0-4RjZc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-13 00:00:00+00:00

http://KEXP.ORG presents Sunna Fridjons performing live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 8, 2019.

Songs:
Melt
Bergmál
Let The Light In
Milli Svefns Og Vöku
Night Time

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://sunnafridjons.bandcamp.com

## Sunna Fridjons - Let The Light In (Live on KEXP)
 - [https://www.youtube.com/watch?v=uqgzIKZXdzg](https://www.youtube.com/watch?v=uqgzIKZXdzg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-13 00:00:00+00:00

http://KEXP.ORG presents Sunna Fridjons performing "Let The Light In" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 8, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://sunnafridjons.bandcamp.com

## Sunna Fridjons - Melt (Live on KEXP)
 - [https://www.youtube.com/watch?v=Uk7TfH2KQuU](https://www.youtube.com/watch?v=Uk7TfH2KQuU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-13 00:00:00+00:00

http://KEXP.ORG presents Sunna Fridjons performing "Melt" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 8, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://sunnafridjons.bandcamp.com

## Sunna Fridjons - Milli Svefns Og Vöku (Live on KEXP)
 - [https://www.youtube.com/watch?v=IATn9l9dvaU](https://www.youtube.com/watch?v=IATn9l9dvaU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-13 00:00:00+00:00

http://KEXP.ORG presents Sunna Fridjons performing "Milli Svefns Og Vöku" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 8, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://sunnafridjons.bandcamp.com

## Sunna Fridjons - Night Time (Live on KEXP)
 - [https://www.youtube.com/watch?v=1dXbdJLg5J0](https://www.youtube.com/watch?v=1dXbdJLg5J0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-13 00:00:00+00:00

http://KEXP.ORG presents Sunna Fridjons performing "Night Time" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 8, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://sunnafridjons.bandcamp.com

## Lucy Dacus - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=UZUYL65ndqI](https://www.youtube.com/watch?v=UZUYL65ndqI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-12 00:00:00+00:00

http://KEXP.ORG presents Lucy Dacus performing live in the KEXP studio. Recorded October 22, 2019.

Songs:
My Mother & I
Yours & Mine
Timefighter
Night Shift

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Audio Mixer: Aly Carlisle-Steinberg
Cameras: Jim Beckmann, Alaia D'Alessandro & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://lucydacus.com

## Lucy Dacus - My Mother & I (Live on KEXP)
 - [https://www.youtube.com/watch?v=OorIH-fCvjA](https://www.youtube.com/watch?v=OorIH-fCvjA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-12 00:00:00+00:00

http://KEXP.ORG presents Lucy Dacus performing "My Mother & I" live in the KEXP studio. Recorded October 22, 2019.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Audio Mixer: Aly Carlisle-Steinberg
Cameras: Jim Beckmann, Alaia D'Alessandro & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://lucydacus.com

## Lucy Dacus - Night Shift (Live on KEXP)
 - [https://www.youtube.com/watch?v=XDNjt2lHBO4](https://www.youtube.com/watch?v=XDNjt2lHBO4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-12 00:00:00+00:00

http://KEXP.ORG presents Lucy Dacus performing "Night Shift" live in the KEXP studio. Recorded October 22, 2019.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Audio Mixer: Aly Carlisle-Steinberg
Cameras: Jim Beckmann, Alaia D'Alessandro & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://lucydacus.com

## Lucy Dacus - Timefighter (Live on KEXP)
 - [https://www.youtube.com/watch?v=CbTgswhN9PQ](https://www.youtube.com/watch?v=CbTgswhN9PQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-12 00:00:00+00:00

http://KEXP.ORG presents Lucy Dacus performing "Timefighter" live in the KEXP studio. Recorded October 22, 2019.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Audio Mixer: Aly Carlisle-Steinberg
Cameras: Jim Beckmann, Alaia D'Alessandro & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://lucydacus.com

## Lucy Dacus - Yours & Mine (Live on KEXP)
 - [https://www.youtube.com/watch?v=5Jmq8pIIrCA](https://www.youtube.com/watch?v=5Jmq8pIIrCA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-12 00:00:00+00:00

http://KEXP.ORG presents Lucy Dacus performing "Yours & Mine" live in the KEXP studio. Recorded October 22, 2019.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Audio Mixer: Aly Carlisle-Steinberg
Cameras: Jim Beckmann, Alaia D'Alessandro & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://lucydacus.com

