# Source:Laowhy86, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw, language:en-US

## Coronavirus - How They Barely  Escaped Wuhan
 - [https://www.youtube.com/watch?v=AuWQ0Uzq0n0](https://www.youtube.com/watch?v=AuWQ0Uzq0n0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw
 - date published: 2020-02-12 00:00:00+00:00

A Danish citizen, and his Chinese wife, along with an American, and his Chinese wife, and son managed to get home. Here is their story.

Tyler's Go Fund Me - https://tinyurl.com/qkjxj8z

◘ Support me on Patreon for early release, and much more! http://www.patreon.com/laowhy86

◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

◘ OR Become a Sponsor on YouTube:
https://www.youtube.com/channel/UChvithwOECK5g_19TjldMKw/sponsor

◘ My TV show: Conquering Northern China:
https://vimeo.com/ondemand/conqueringnorthernchina

◘ Conquering Southern China
https://vimeo.com/ondemand/conqueringsouthernchina

◘ Discount code for both shows: laowinning

◘ Join me every week for videos about China! Don't forget to subscribe!
http://www.youtube.com/laowhy86

◘ Facebook:
http://www.facebook.com/laowhy86

◘ Instagram: 
http://instagram.com/laowhy86

◘ Music used most of the time - New World Hip Hop
https://soundcloud.com/apollodrivenz
https://www.youtube.com/channel/UCgirAE5d8ufiotRXmBZZbBQ

