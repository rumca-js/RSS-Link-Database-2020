# Source:Ryan George, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ, language:en-US

## The First Guy To Ever Open A Restaurant
 - [https://www.youtube.com/watch?v=iy1vDjxwbpM](https://www.youtube.com/watch?v=iy1vDjxwbpM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ
 - date published: 2020-02-13 00:00:00+00:00

Subscribe: http://bit.ly/2wscuFf
Twitter/Instagram: @TheRyanGeorge

Come on in and be restored! A stranger will prepare a meal for you. Do not interact with this stranger.

