# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Parasite - Movie Review
 - [https://www.youtube.com/watch?v=aYspbIKsiH4](https://www.youtube.com/watch?v=aYspbIKsiH4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-02-13 00:00:00+00:00

Here are (finally) my thoughts on the Best picture Oscar winner PARASITE

#Parasite

