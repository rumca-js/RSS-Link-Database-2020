# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## My Boyfriend is Better Than Yours
 - [https://www.youtube.com/watch?v=MMIN_ZkLBC0](https://www.youtube.com/watch?v=MMIN_ZkLBC0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2020-02-13 00:00:00+00:00

Written By Natalie Metcalfe
Actors: Natalie Metcalfe and Julie Nolke
Videographer: Samuel Larson
A HUGE THANK YOU TO ALL MY PATRONS!! Sign up here: https://www.patreon.com/julienolke

