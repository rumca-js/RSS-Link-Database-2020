# Source:SssethTzeentach, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCD6VugMZKRhSyzWEWA9W2fg, language:en-US

## Heroes of Might and Magic V Review | Available in 221 Countries™
 - [https://www.youtube.com/watch?v=5-c51iIIk2M](https://www.youtube.com/watch?v=5-c51iIIk2M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCD6VugMZKRhSyzWEWA9W2fg
 - date published: 2020-02-13 00:00:00+00:00

The last good entry to a legendary series.
Now without region blocking, courtesy of 4K Media Inc (Konami).

Original video on
Dailymotion: https://www.dailymotion.com/video/x7p9vz8
Bitchute: https://www.bitchute.com/video/Q5cJlh8t1h0F/
Missing Portion: 2:17 to 3:22

Buy it on GOG.COM:
https://af.gog.com/game/heroes_of_might_and_magic_5_bundle?as=1630110786

Official Sseth HoMMV Wiki:
https://heroes-of-might-and-magic-v-dev.fandom.com/wiki/Troubled_Development

Stronghold Music: Ram Ranch 1 and 7 by Grant MacDonald.

A warm thank you to all the merchants for supporting me throughout 2019.
It's been a wild ride.
Have a merry christmas - and a happy new year.

-----------------------
Send Sseth Shekels: https://www.paypal.me/SsethTzeentachGB
Send Sseth Shekels per video:  https://www.patreon.com/Sseth
Send Sseth Shekels / crypto: https://www.subscribestar.com/ssethtzeentach

Website: https://ssethtzeentach.com/
Twitter: https://twitter.com/SsethTzeentach
FB: https://www.facebook.com/sseth672/

