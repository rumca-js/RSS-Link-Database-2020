# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Real Housewives Of The Babylon Bee
 - [https://www.youtube.com/watch?v=n_FFpj7JgwQ](https://www.youtube.com/watch?v=n_FFpj7JgwQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-02-12 00:00:00+00:00

This is the Babylon Bee weekly news podcast for the week of 2/12/2020. 

 In this special Valentine’s episode of The Babylon Bee podcast, editor-in-chief Kyle Mann, creative director Ethan Nicolle, and producer Dan welcome their wives onto the show: Destiny, Jessica, and Chandra.  This episode was recorded on Kyle and Destiny’s wedding anniversary, Ethan and Jessica’s first date anniversary, and Dan and Chandra’s awkward texting anniversary. Love is in the air on this special episode of the Babylon Bee podcast as they tackle the week's biggest stories.

 In the subscriber portion, the couples face off in The Dating Game, where the rules are entirely too vague for Kyle’s finely tuned gaming palate, but everyone still has a fun time!

  Pre-order the new Babylon Bee Best-Of Coffee Table Book coming in 2020!

 Show Outline

 Introduction - Kyle, Ethan, and Dan introduce their better halves and give them permission to speak. We then dive into the stories of the week.

 Story 1 -  AOC: 'You Cannot Literally Wrap Your Head Around Something, You Would Get Hurt'

   AOC immediately fulfilled our  boomer meme with comments about bootstraps and shoelaces. 

   Other idioms AOC will attack?

   What do the ladies think about AOC? 

   Story 2 -  Garnier Fructis Introduces The Biden Collection

   Biden recently told a woman in New Hampshire that she was lying about being to a caucus and called her a “Lying Dog-Faced Pony Soldier”. 

   Destiny informs the men how to pronounce Garnier.

   Story 3 -  Woman Advertising 5 Different MLMs On Back Of Minivan Must Be Extremely Rich, Successful

   The women discuss their favorite MLM schemes and products and we question why there is a culture in the church that seems to replace fellowship with marketing

   Story 4 -  Man Shows Sacrificial, Christlike Love For Wife By Throwing Socks In General Direction Of Laundry Basket 

   We learn disgusting truths about the guys from the wives.

   Story 5 -  'The Milk Is Nowhere To Be Found,' Reports Husband Staring Directly At Jug Of Milk

   The struggle is real.

   Topic of the Week -  For Valentine’s Day, the gang discusses their stories, how God brought each couple together, funny things that happened on first dates, and how the romantic-at-heart Ethan is upstaging other men in the love department.

 Hate Mail/ Feedback - We get an email from someone who can’t believe Christians would lie and deceive their elderly mother about something Bernie Sanders would say.

 Paid-subscriber portion (Starts at 01:10:43)

 Dating game

   If your spouse could go anywhere for a free vacation for a week, where would they go?

   What’s their favorite book of the Bible?

   What adjective best describes your spouse’s family?

   Your spouse wins the lottery. What is their first big purchase?

   Spouse’s most annoying habit?

   Who is the better driver?

   Parting marriage and parenting advice.

 Become a paid subscriber at https://babylonbee.com/plans

