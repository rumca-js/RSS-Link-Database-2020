# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## RELIGION of the DWARVES | Tolkien Explained
 - [https://www.youtube.com/watch?v=GWEbUJu53PU](https://www.youtube.com/watch?v=GWEbUJu53PU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2020-02-04 00:00:00+00:00

Today, we are taking a quick look at the beliefs of Tolkien's dwarves.  How were the dwarves created?  What do they believe about reincarnation?  What happens when dwarves die?

Please consider subscribing to help me grow the channel and make more videos like this!  It will also help you not miss any future videos, including Middle-earth history, News about Amazon's Lord of the Rings series, and more!


--------------
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.

The Seven Houses of the Khazad - Artigas
Aulë and the Seven Fathers - Ted Nasmith
Aulë the Destroyer - Ted Nasmith

#TheLordoftheRings #LotR #dwarves

