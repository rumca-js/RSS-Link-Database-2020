# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## Reflections & Memories of a Minor e-Celeb...
 - [https://www.youtube.com/watch?v=K3B8fIdixo0](https://www.youtube.com/watch?v=K3B8fIdixo0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-02-04 00:00:00+00:00

Ever wanted to start a public online presence? It's easier than you think. You don't need no fancy studio or Pajeets who do your video editing. Just do it and stop making excuses. I take a trip down memory road and talk about my old apartment with a broken toilet where I recorded my first videos.

Videos I mentioned here:
https://www.youtube.com/watch?v=3zpgQpdy_fI (Video on How to Choose a Linux Distro: STOP THINKING!)
https://www.youtube.com/watch?v=DB6UWGeNePk (Video on Mac/Apple)

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE NOW: https://lukesmith.xyz/donate 💰😎👌💯

