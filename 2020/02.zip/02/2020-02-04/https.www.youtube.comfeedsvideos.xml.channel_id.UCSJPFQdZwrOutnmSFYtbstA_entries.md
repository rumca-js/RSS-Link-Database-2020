# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Star Trek Picard - Episode 2 Review
 - [https://www.youtube.com/watch?v=zu04aSEU37c](https://www.youtube.com/watch?v=zu04aSEU37c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-02-04 00:00:00+00:00

We're boldly going in again, this time to review Episode 2 of Star Trek Picard - "Maps and Legends".

