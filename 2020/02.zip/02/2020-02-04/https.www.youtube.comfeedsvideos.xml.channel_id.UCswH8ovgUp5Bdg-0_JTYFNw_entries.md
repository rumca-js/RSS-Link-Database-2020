# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Are Boris's Trump Tactics The Future?
 - [https://www.youtube.com/watch?v=xRRfu_j9ZnQ](https://www.youtube.com/watch?v=xRRfu_j9ZnQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-02-05 00:00:00+00:00

Journalists walked out of a Downing Street briefing on Boris Johnson’s Brexit plans after the prime minister’s director of communications tried to restrict it to selected publications and broadcasters.

Labour accused the prime minister of adopting the tactics of US president Donald Trump, who regularly excludes reporters who he regards as hostile.

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

## What Can Kobe Bryant's Death Teach Us?
 - [https://www.youtube.com/watch?v=rqDt9EYfwYw](https://www.youtube.com/watch?v=rqDt9EYfwYw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-02-04 00:00:00+00:00

My reflections on the sad passing of Kobe Bryant...


Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

