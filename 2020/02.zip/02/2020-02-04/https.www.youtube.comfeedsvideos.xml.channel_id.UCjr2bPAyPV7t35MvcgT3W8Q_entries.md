# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## BREAKING: Google exported your private data to random people
 - [https://www.youtube.com/watch?v=wpa6gQCOmhw](https://www.youtube.com/watch?v=wpa6gQCOmhw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2020-02-05 00:00:00+00:00

Videos from Google Photos were incorrectly exported to random people requesting their data via Google Takeout in a scandalous bug causing privacy and security nightmare for Google Photo users.

Support me through Patreon: https://www.patreon.com/thehatedone 

- or donate anonymously:

Monero: 84DYxU8rPzQ88SxQqBF6VBNfPU9c5sjDXfTC1wXkgzWJfVMQ9zjAULL6rd11ASRGpxD1w6jQrMtqAGkkqiid5ef7QDroTPp

Bitcoin: 1HkDxXAVDFhBHSyRjam5WW5uoY88sxn5qz

I am not affiliated with any of these but I highly recommend them:
Nextcloud https://nextcloud.com/
Syncthing https://syncthing.net/
Crytpomator (to encrypt files uploaded to cloud) https://cryptomator.org/

Sources:
Reddit screenshot of the email Google sent to affected users https://old.reddit.com/r/thehatedone/comments/eynw8t/googles_another_fuckup/
Arstechnica coverage https://arstechnica.com/gadgets/2020/02/google-photos-bug-let-strangers-download-your-private-videos/
From the article: "a security and privacy bug affecting Google Photos users: for a time, it was possible for private videos to be downloaded by unrelated users."

Follow me:
https://twitter.com/The_HatedOne_
https://www.bitchute.com/TheHatedOne/
https://www.reddit.com/r/thehatedone/
https://www.minds.com/The_HatedOne

The footage and images featured in the video were for critical analysis, commentary and parody, which are protected under the Fair Use laws of the United States Copyright act of 1976.

