# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 NEAR IMPOSSIBLE Trophies on the PS4
 - [https://www.youtube.com/watch?v=CbiarLHF8TU](https://www.youtube.com/watch?v=CbiarLHF8TU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-02-05 00:00:00+00:00

Trophies are often challenging, but these PS4 accomplishments really take the cake. Here are some of the hardest, most over-the-top achievements you can try to earn.
Subscribe for more: http://youtube.com/gameranxtv

## Top 10 NEW Medieval Games of 2020
 - [https://www.youtube.com/watch?v=dZM9fRB6v6w](https://www.youtube.com/watch?v=dZM9fRB6v6w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-02-05 00:00:00+00:00

Medieval games! If it has swords and is old, we've got it covered with our most anticipated 2020 games for PC, PS4, Xbox One, and more.
Subscribe for more: http://youtube.com/gameranxtv

10 Crusader Kings III

Platform: PC Linux

Release Date: 2020




9 Darksburg

Platform: PC

Release Date: 2020




8 King's Bounty II

Platform: PC PS4 XBOX ONE

Release Date: TBA 2020




7 Isles of Adalar

Platform:

Release Date:




6 The Settlers

Platform: PC

Release: 2020




5 Valhall

Platform: PC

Release: TBA 2020



4 DARKBORN

Platform: PC PS4 XBOX ONE

Release: 2020




3 Elden Ring

Platform: PC PS4 XBOX ONE

Release date: TBA 2020




2 Ghost of Tsushima

Platform: PS4

Release date:  Q2/Q3 2020




1 Mount & Blade II: Bannerlord

Platform: PC

Release Date: March 2020 (Early Access)



BONUS



Knights of Light: The Prologue

Platform: PC

Release date: TBA 2020




Rustler

Platform: PC

Release date: TBA 2020



Nioh 2

Platform: PS4

Release date: March 13, 2020




Stoneshard

Platform: PC 

Release date: 7 Feb, 2020

## 10 Best FREE iOS & Android Games of January 2020
 - [https://www.youtube.com/watch?v=XlI5OyWiFPA](https://www.youtube.com/watch?v=XlI5OyWiFPA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-02-04 00:00:00+00:00

Looking for something free to play on iPhone or Android? We've got you covered with some newly released mobile games.
Subscribe for more: http://youtube.com/gameranxtv

#10 World Robot Boxing 2
https://play.google.com/store/apps/details?id=com.reliancegames.world.robot.boxing.wrb
https://apps.apple.com/us/app/real-steel-world-robot-boxing/id1477151188

#9 Dream League Soccer 2020
https://apps.apple.com/us/app/dream-league-soccer-2020/id1462911602
https://play.google.com/store/apps/details?id=com.firsttouchgames.dls7

#8 Extraordinary Ones
Price: free
Platform: Android iOS
https://play.google.com/store/apps/details?id=com.netease.frxyna&hl=en
https://apps.apple.com/us/app/extraordinary-ones/id1475627815


#7 Arknights
Price: Free
Platform: iOS Android
https://apps.apple.com/us/app/arknights/id1464872022
https://play.google.com/store/apps/details?id=com.YoStarEN.Arknights&hl=en


#6 AI Dungeon
https://play.google.com/store/apps/details?id=com.aidungeon
https://apps.apple.com/us/app/ai-dungeon/id1491268416


#5 G.I. Joe: War On Cobra
iOS ANDROID
https://apps.apple.com/us/app/g-i-joe-war-on-cobra/id1471554366
https://play.google.com/store/apps/details?id=com.d3go.gijoewaroncobra&hl=en_IN

#4 Magic: ManaStrike
https://play.google.com/store/apps/details?id=com.netmarble.mana
https://apps.apple.com/us/app/magic-manastrike/id1433875462

#3 Vengeance
ANDROID
https://play.google.com/store/apps/details?id=com.dimasgaming.vengeancerpg

#2 Pico Tanks: Multiplayer Mayhem
https://apps.apple.com/us/app/pico-tanks/id1261614771
https://play.google.com/store/apps/details?id=com.pandaarcade.picotanks&hl=en

#1 Warface: Global Operations
iOS ANDROID
https://apps.apple.com/us/app/warface-global-operations/id1460568073
https://play.google.com/store/apps/details?id=com.my.warface.online.fps.pvp.action.shooter



BONUS

Pascal's Wager
iOS, ANDROID[Q2 2020]
https://apps.apple.com/us/app/pascals-wager/id1476649036

RPG Miden Tower
$7.99
https://apps.apple.com/us/app/rpg-miden-tower/id1459592967
https://play.google.com/store/apps/details?id=kemco.execreate.innocentrevenger

## Zombie Army 4: Dead War - Before You Buy
 - [https://www.youtube.com/watch?v=Dk_pW6JV33I](https://www.youtube.com/watch?v=Dk_pW6JV33I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-02-04 00:00:00+00:00

Zombie Army 4: Dead War (PC, PS4, Xbox One) is the latest zombie shooter to release, but it has an interesting twist. How is it? Let's talk!
Subscribe for more: http://youtube.com/gameranxtv ▼▼

Buy Zombie Army: https://amzn.to/2ukm5CH

Watch more 'Before You Buy': https://bit.ly/2kfdxI6

