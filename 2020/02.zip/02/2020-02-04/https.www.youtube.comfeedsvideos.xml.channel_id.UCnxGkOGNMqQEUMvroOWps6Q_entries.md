# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Andrew Doyle's Unveiling as Woke Satirist Titania McGrath | Joe Rogan
 - [https://www.youtube.com/watch?v=JJsonPXKrMI](https://www.youtube.com/watch?v=JJsonPXKrMI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-05 00:00:00+00:00

Taken from JRE #1423 w/Andrew Doyle aka Titania McGrath:
https://youtu.be/NIxhH85cQMY

## Andrew Doyle: The Media Misrepresented Brexit
 - [https://www.youtube.com/watch?v=ufGFhWeljBI](https://www.youtube.com/watch?v=ufGFhWeljBI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-05 00:00:00+00:00

Taken from JRE #1423 w/Andrew Doyle AKA Titania McGrath: https://youtu.be/NIxhH85cQMY

## Andrew Doyle: Woke Politics Are Alienating Liberal Voters
 - [https://www.youtube.com/watch?v=jIhoDt3qZp4](https://www.youtube.com/watch?v=jIhoDt3qZp4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-05 00:00:00+00:00

Taken from JRE #1423 w/Andrew Doyle AKA Titania McGrath: https://youtu.be/NIxhH85cQMY

## Companies Are Doing "Background Checks" on People's Social Media w/Andrew Doyle | Joe Rogan
 - [https://www.youtube.com/watch?v=GB78tVKLIi0](https://www.youtube.com/watch?v=GB78tVKLIi0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-05 00:00:00+00:00

Taken from JRE #1423 w/Andrew Doyle aka Titania McGrath:
https://youtu.be/NIxhH85cQMY

## How Andrew Doyle Trolled a British Newspaper in Epic Fashion
 - [https://www.youtube.com/watch?v=CGO5A5nzfdA](https://www.youtube.com/watch?v=CGO5A5nzfdA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-05 00:00:00+00:00

Taken from JRE #1423 w/Andrew Doyle AKA Titania McGrath: https://youtu.be/NIxhH85cQMY

## Petition to Have Brie Larson Step Down as Captain Marvel w/Andrew Doyle | Joe Rogan
 - [https://www.youtube.com/watch?v=T6oUJZduc0o](https://www.youtube.com/watch?v=T6oUJZduc0o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-05 00:00:00+00:00

Taken from JRE #1423 w/Andrew Doyle aka Titania McGrath:
https://youtu.be/NIxhH85cQMY

## There Are Feminist Kids Books w/Andrew Doyle | Joe Rogan
 - [https://www.youtube.com/watch?v=y5mvg6nzDEk](https://www.youtube.com/watch?v=y5mvg6nzDEk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-05 00:00:00+00:00

Taken from JRE #1423 w/Andrew Doyle aka Titania McGrath:
https://youtu.be/NIxhH85cQMY

## When Will the Religion of Wokeness End?
 - [https://www.youtube.com/watch?v=EpohIY_fhzE](https://www.youtube.com/watch?v=EpohIY_fhzE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-05 00:00:00+00:00

Taken from JRE #1423 w/Andrew Doyle AKA Titania McGrath: https://youtu.be/NIxhH85cQMY

## AI Expert Lex Fridman Weighs in on Simulation Theory
 - [https://www.youtube.com/watch?v=ZFID_rgzE_Y](https://www.youtube.com/watch?v=ZFID_rgzE_Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-04 00:00:00+00:00

Taken from JRE #1422 w/Lex Fridman: https://youtu.be/ZIcQwDkcaWk

## Are Social Media Algorithms More Dangerous Than Killer Robots?
 - [https://www.youtube.com/watch?v=UtBYfrW6jyQ](https://www.youtube.com/watch?v=UtBYfrW6jyQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-04 00:00:00+00:00

Taken from JRE #1422 w/Lex Fridman: https://youtu.be/ZIcQwDkcaWk

## Jim Norton Reflects on Outrageous Opie & Anthony Moments | Joe Rogan
 - [https://www.youtube.com/watch?v=jUG8MjPVqPk](https://www.youtube.com/watch?v=jUG8MjPVqPk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-04 00:00:00+00:00

Taken from JRE #1421 w/Jim Norton: https://youtu.be/yXZn2DkrXig

## Jim Norton and Joe Rogan Debate Bob Lazar's Story
 - [https://www.youtube.com/watch?v=qRQEaQAGyjk](https://www.youtube.com/watch?v=qRQEaQAGyjk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-04 00:00:00+00:00

Taken from JRE #1421 w/Jim Norton: https://youtu.be/yXZn2DkrXig

## Joe Rogan Recalls His First UFC Gig
 - [https://www.youtube.com/watch?v=-YLn1ytAnUc](https://www.youtube.com/watch?v=-YLn1ytAnUc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-04 00:00:00+00:00

Taken from JRE #1421 w/Jim Norton: https://youtu.be/yXZn2DkrXig

## Joe Rogan and Jim Norton Talk Ngannou vs Rozenstruik
 - [https://www.youtube.com/watch?v=LJBkOVRU1PA](https://www.youtube.com/watch?v=LJBkOVRU1PA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-04 00:00:00+00:00

Taken from JRE #1421 w/Jim Norton: https://youtu.be/yXZn2DkrXig

## Joe Rogan on Kim Kardashian's Prison Reform Advocacy
 - [https://www.youtube.com/watch?v=eB6_VwhhCzE](https://www.youtube.com/watch?v=eB6_VwhhCzE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-04 00:00:00+00:00

Taken from JRE #1421 w/Jim Norton: https://youtu.be/yXZn2DkrXig

## Joe Rogan: Dominik Reyes is a Real Threat to Jon Jones
 - [https://www.youtube.com/watch?v=2S9XfE6b_Jk](https://www.youtube.com/watch?v=2S9XfE6b_Jk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-04 00:00:00+00:00

Taken from JRE #1421 w/Jim Norton: https://youtu.be/yXZn2DkrXig

## Joe Rogan: UFC Needs More Judges
 - [https://www.youtube.com/watch?v=tRP5b9mwqyA](https://www.youtube.com/watch?v=tRP5b9mwqyA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-04 00:00:00+00:00

Taken from JRE #1421 w/Jim Norton: https://youtu.be/yXZn2DkrXig

## MIT Scientist Pushes Back on Andrew Yang's Automation Warnings | Joe Rogan
 - [https://www.youtube.com/watch?v=4-rCAUAq7BE](https://www.youtube.com/watch?v=4-rCAUAq7BE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-04 00:00:00+00:00

Taken from JRE #1422 w/Lex Fridman:
https://youtu.be/ZIcQwDkcaWk

## Scientist Explains Self Improving Artificial Intelligence
 - [https://www.youtube.com/watch?v=-g0xOJYPjkQ](https://www.youtube.com/watch?v=-g0xOJYPjkQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-04 00:00:00+00:00

Taken from JRE #1422 w/Lex Fridman: https://youtu.be/ZIcQwDkcaWk

## Tony Ferguson Fight Will Be the Toughest of Khabib’s Career
 - [https://www.youtube.com/watch?v=88axHr57PZg](https://www.youtube.com/watch?v=88axHr57PZg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-04 00:00:00+00:00

Taken from JRE #1421 w/Jim Norton: https://youtu.be/yXZn2DkrXig

## What Lex Fridman Learned From Meeting Elon Musk | Joe Rogan
 - [https://www.youtube.com/watch?v=DTohHXHxe7U](https://www.youtube.com/watch?v=DTohHXHxe7U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-04 00:00:00+00:00

Taken from JRE #1422 w/Lex Fridman:
https://youtu.be/ZIcQwDkcaWk

## Why Jim Norton Stopped Drinking as a Teenager | Joe Rogan
 - [https://www.youtube.com/watch?v=J_aySytmBP0](https://www.youtube.com/watch?v=J_aySytmBP0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-04 00:00:00+00:00

Taken from JRE #1421 w/Jim Norton: https://youtu.be/yXZn2DkrXig

## Why Jim Norton Used to Let UFC Fighters Beat Him Up
 - [https://www.youtube.com/watch?v=2EM6B_zfOy4](https://www.youtube.com/watch?v=2EM6B_zfOy4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-04 00:00:00+00:00

Taken from JRE #1421 w/Jim Norton: https://youtu.be/yXZn2DkrXig

