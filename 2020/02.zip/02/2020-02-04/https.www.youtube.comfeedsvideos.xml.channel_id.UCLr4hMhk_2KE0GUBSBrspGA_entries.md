# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week Extra #1
 - [https://www.youtube.com/watch?v=laZJHSvCKNk](https://www.youtube.com/watch?v=laZJHSvCKNk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-02-04 00:00:00+00:00

Zapis programu na żywo

