# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## Smart Contact Lens: The Trillion Dollar Cyborg Revolution
 - [https://www.youtube.com/watch?v=DHBrdtQBvhg](https://www.youtube.com/watch?v=DHBrdtQBvhg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2020-02-05 00:00:00+00:00

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join
Updated refund policy: Email us within your first month of joining and we'll refund you for your first month. There is no refund if you cancel at a later time. 

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
📸 Follow me on IG for a chance to win $1,000: @jaketran // http://bit.ly/jt-ig
Please watch out for fake accounts. I will never message you asking for money or to invest. As of right now, it's spelled exactly like this: @jaketran
👨👦👦 Join the Tran Mafia Family here: https://bit.ly/patreon-jt
💬 Join the community Discord: http://discord.gg/BmK8EnQ

Stuff I use & recommend:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
🏠 The real estate investing course I love & recommend: https://jake.yt/RE
🌐 Most flexible, affordable website hosting: https://jake.yt/bhd
🖥️ Website platform I use & love: https://jake.yt/kd
💽 Editing software I've used for 7+ years: https://jake.yt/ccd
📒 Online bookkeeping software I use& love: https://jake.yt/benchd 
🧾 Best affordable bookkeeping software: https://jake.yt/fbd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd
📚 Get 3 free audiobooks for life: https://amzn.to/2v58PSu
🎥 My video gear, setup, tech, books: https://jake.yt/stored

✉️ Email me: jake@jaketran.io

Subscribe to the backup channel on LBRY, use reward code "jake-cast" for free coin: https://bit.ly/LBRY-jt
-----------------------

📰 Sources & visuals // https://www.jaketran.io/blog/metadata-smart-contact-lens-the-trillion-dollar-cyborg-revolution

On the Fall of 2015, two Silicon Valley veterans that both have poor eyesight formed a secretive startup

And as the years went by, they recruited talent from Apple, Amazon, HP, Google and much more “to invent something that had never been built before, using technology that was said to have to be ‘called in from the future.’”

Fast forward to January 2020, and Mojo, a startup with over $100m in funding, with the world’s first augmented reality contact lens, as a new player in the Trillion Dollar Cyborg Revolution

AR has been around for a while now so it’s not anything special
We’ve seen things like Google Glass that can be extremely useful, but AR has never really taken off

They’ve created the world’s first real smart contact lenses that’s able to display useful heads up information onto your vision. They’re calling this new form of tech, Invisible Computing

Their focus is helping people with different vision impairments see better

With something like Mojo or other startups, you can imagine that humanity’s future will probably look a lot clearer

In the future, their goal is to also make the lives of consumers and workers a little bit easier

Humans have different levels of needs that need to be fulfilled in a certain order, and every business works within these different levels

Physiological needs, safety, love, esteem, and self-actualization AKA Maslow's Hierarchy of Needs

In business, the lower on that hierarchy of needs that you’re serving to your customers, the more evergreen your industry is gonna be

During a recession or a depression, people aren't gonna waste their money on needless stuff

-----------------------

🌅 Join my Facebook Group for going remote // http://bit.ly/remote-job

-----------------------

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2020 Jake Tran. All rights reserved.

Sound:
Ward Wills - When to Say Goodbye
https://chillhop.ffm.to/whentosaygoodbye.oyd 
faceless woman - less.people
https://soundcloud.com/lesspeople 
Kupla x less people - lost in translation
https://open.spotify.com/track/2aKcNkglfl6NYCAEspKe0F?si=PSAXuLHkT8G1GIPjhChr7g


Music by Chillhop: http://chillhop.com/listen
Listen on Spotify: http://bit.ly/ChillhopSpotify

DISCLAIMER: These videos are for entertainment purposes only. This is not meant to be financial advice. Please always do your due diligence and never stop learning. Best of luck!

AFFILIATE DISCLOSURE: Some of the links in this video description are affiliate links, meaning, at no additional cost to you, I may earn a commission if you click through and make a purchase and/or subscribe. I only promote products that I 100% believe in.

