# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Cartalk - Train In Vain (Live on KEXP)
 - [https://www.youtube.com/watch?v=vwvfqq7BzPY](https://www.youtube.com/watch?v=vwvfqq7BzPY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-05 00:00:00+00:00

http://KEXP.ORG presents Cartalk covering The Clash's "Train In Vain" live in the KEXP studio. Recorded January 22, 2020.

Audio Engineer: Kevin Suggs
Cameras: Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Alaia D'Alessandro

http://kexp.org
https://cartalk.bandcamp.com
http://internationalclashday.com

## Great Grandpa - Big Yellow Taxi (Live on KEXP)
 - [https://www.youtube.com/watch?v=ikbiwQrZVXA](https://www.youtube.com/watch?v=ikbiwQrZVXA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-05 00:00:00+00:00

http://KEXP.ORG presents Great Grandpa covering Joni Mitchell's "Big Yellow Taxi" live in the KEXP studio. Recorded January 6, 2020.

Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
https://www.greatgrandpa.band
http://internationalclashday.com

## Pink Lotion - We Don't Need Another Hero (Live on KEXP)
 - [https://www.youtube.com/watch?v=D23D1K_e8ZQ](https://www.youtube.com/watch?v=D23D1K_e8ZQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-05 00:00:00+00:00

http://KEXP.ORG presents Pink Lotion covering Tina Turner's "We Don't Need Another Hero" live in the KEXP studio. Recorded January 27, 2020.

Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann & Scott Holpainen
Editor: Jim Beckmann

http://kexp.org
https://pinklotion.bandcamp.com
http://internationalclashday.com

## The Joy Formidable - Should I Stay Or Should I Go (Live on KEXP)
 - [https://www.youtube.com/watch?v=gS6ytyAOjYg](https://www.youtube.com/watch?v=gS6ytyAOjYg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-05 00:00:00+00:00

http://KEXP.ORG presents The Joy Formidable covering The Clash's "Should I Stay Or Should I Go" live in the KEXP studio. Recorded December 17, 2019.

Audio Engineers: Dimitrios Leondaridis & Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://thejoyformidable.com
http://internationalclashday.com

## Æ MAK - Dancing Bug (Live on KEXP)
 - [https://www.youtube.com/watch?v=Sd1JomuQRBo](https://www.youtube.com/watch?v=Sd1JomuQRBo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-04 00:00:00+00:00

http://KEXP.ORG presents Æ MAK performing "Dancing Bug" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 9, 2019.

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Jim Beckmann

http://kexp.org
https://www.aemakmusic.com

## Æ MAK - Glow (Live on KEXP)
 - [https://www.youtube.com/watch?v=iAfDOTvP9Jw](https://www.youtube.com/watch?v=iAfDOTvP9Jw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-04 00:00:00+00:00

http://KEXP.ORG presents Æ MAK performing "Glow" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 9, 2019.

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Jim Beckmann

http://kexp.org
https://www.aemakmusic.com

## Æ MAK - I Can Feel It In My Bones (Live on KEXP)
 - [https://www.youtube.com/watch?v=2k8jeWz0RCc](https://www.youtube.com/watch?v=2k8jeWz0RCc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-04 00:00:00+00:00

http://KEXP.ORG presents Æ MAK performing "I Can Feel It In My Bones" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 9, 2019.

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Jim Beckmann

http://kexp.org
https://www.aemakmusic.com

## Æ MAK - I Walk (Live on KEXP)
 - [https://www.youtube.com/watch?v=d68PvsIiN1U](https://www.youtube.com/watch?v=d68PvsIiN1U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-04 00:00:00+00:00

http://KEXP.ORG presents Æ MAK performing "I Walk" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 9, 2019.

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Jim Beckmann

http://kexp.org
https://www.aemakmusic.com

## Æ MAK - Signs (Live on KEXP)
 - [https://www.youtube.com/watch?v=1jGU2VjZcvA](https://www.youtube.com/watch?v=1jGU2VjZcvA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-04 00:00:00+00:00

http://KEXP.ORG presents Æ MAK performing "Signs" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 9, 2019.

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Jim Beckmann

http://kexp.org
https://www.aemakmusic.com

## Æ MAK - Swallow (Live on KEXP)
 - [https://www.youtube.com/watch?v=6lKo-aYMogU](https://www.youtube.com/watch?v=6lKo-aYMogU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-04 00:00:00+00:00

http://KEXP.ORG presents Æ MAK performing "Swallow" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 9, 2019.

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Jim Beckmann

http://kexp.org
https://www.aemakmusic.com

## Æ MAK - Too Sad To Sing (Live on KEXP)
 - [https://www.youtube.com/watch?v=SEuuCZ8p-L4](https://www.youtube.com/watch?v=SEuuCZ8p-L4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-04 00:00:00+00:00

http://KEXP.ORG presents Æ MAK performing "Too Sad To Sing" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 9, 2019.

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Jim Beckmann

http://kexp.org
https://www.aemakmusic.com

## Æ Mak - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=NxHv2yaK6H8](https://www.youtube.com/watch?v=NxHv2yaK6H8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-04 00:00:00+00:00

http://KEXP.ORG presents Æ MAK performing live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 9, 2019.

Songs:
I Walk
Too Sad To Sing
Pink Himalayan Sunlight
Signs
Dancing Bug
Swallow
I Can Feel It In My Bones
Glow

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Jim Beckmann

http://kexp.org
https://www.aemakmusic.com

