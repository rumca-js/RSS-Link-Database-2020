# Source:Snazzy Labs, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w, language:en-US

## The Ultimate $5,000 Apple Pro Display XDR Review!
 - [https://www.youtube.com/watch?v=WgEUHHp0GAU](https://www.youtube.com/watch?v=WgEUHHp0GAU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w
 - date published: 2020-02-05 00:00:00+00:00

Apple's Pro Display costs $4,999 and doesn't include a stand but they herald it as a bargain. But is it? Snazzy Labs' host Quinn Nelson seeks professional advice in this Pro Display XDR Review.

Buy Denver's Cinema Grade software - https://cinemagrade.com
Purchase Pro Display XDR - https://amzn.to/31saRYW
Purchase 16" MacBook Pro - https://geni.us/nzZnyXz
Purchase Hydraulic Monitor Arm (Cheap) - https://geni.us/WHxeHC
Purchase Hydraulic Monitor Arm (Not Cheap) - https://geni.us/HfXAR
Purchase Blackmagic Micro Panel - https://geni.us/huFA
Follow me on Twitter - http://twitter.com/snazzyq
Follow me on Instagram - http://instagram.com/snazzyq

Apple announced the #6K #ProDisplayXDR alongside the new cheese-grater Mac Pro at WWDC 2019 in San Jose, California. After six months of waiting, it finally hit the market in December of 2019. Rather than rush and put a messy review up as soon as we could, we have spent the last 40 days with it putting it through its paces and seeing if it can really compete against the Sony, Eizo, vs Flanders Scientific monitors of the world. We break down the 6K resolution, connectivity issues, GPU limitations, the $1,000 monitor stand's strengths and weaknesses, the display panel's viewing angles, color accuracy, luminance, light rolloff, vignetting issues, HDR capabilities and alleged 1,000,000:1 contrast ratio. This review is a long one that's jam packed with content so sit back and enjoy!

