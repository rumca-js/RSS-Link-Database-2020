# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## We FIXED a DEAD CPU!!
 - [https://www.youtube.com/watch?v=yh2XYkRwtBQ](https://www.youtube.com/watch?v=yh2XYkRwtBQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-02-05 00:00:00+00:00

Visit https://www.squarespace.com/LTT and use offer code LTT for 10% off

Thanks to Thermal Grizzly for sponsoring today's episode! Buy Thermal Grizzly Conductonaut on Amazon (PAID LINK) at https://lmg.gg/conductonaut

Pulled a Linus and dropped your CPU? Got a couple busted pins and want to fix them? Want to save a whole lot of money? We got you fam, we walk you through the process of fixing a Ryzen 3700x with broken pins and get it up and running again. Big thanks to Zettabit. lab and their video:  https://lmg.gg/aHAAH
Also Ethan for trading the CPU for us to work on. 

Solder mask: https://lmg.gg/TzGT4
Buy F2C 858D SMD Rework Station
On Amazon (PAID LINK): https://geni.us/a4LAE
Buy Brightech LightView PRO
On Amazon (PAID LINK): https://geni.us/nAqG9
Buy MG Chemicals 8341 No Clean Flux Paste
On Amazon (PAID LINK): https://geni.us/i9bbFnz
Buy Isopropyl Alcohol 99%
On Amazon (PAID LINK): https://geni.us/kon3A
Buy Heavy Duty Aluminium Foil
On Amazon (PAID LINK): https://geni.us/jYsdsaF

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://lmg.gg/bytck

Our Affiliates, Referral Programs, and Sponsors: https://linustechtips.com/main/topic/75969-linus-tech-tips-affiliates-referral-programs-and-sponsors
Displate metal posters: https://lmg.gg/displateltt

Linus Tech Tips merchandise at http://www.LTTStore.com/
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips
Our production gear: http://geni.us/cvOS
Our Chrono.gg game store: https://ltt.chrono.gg/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

## This Server Deployment was HORRIBLE
 - [https://www.youtube.com/watch?v=xWjOh0Ph8uM](https://www.youtube.com/watch?v=xWjOh0Ph8uM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-02-04 00:00:00+00:00

Get $20 in free credit on your new account at https://www.linode.com/linus

Monitor and manage your PC in real-time with Pulseway! Create your free account today at https://lmg.gg/pulseway

Sub to Level1Techs!! https://www.youtube.com/c/Level1Techs

Our new server is TOO fast... and no, that is not a good thing.

Buy AMD EPYC Rome processors on Amazon (PAID LINK): https://geni.us/PYlsxp

Buy Intel P4500 on Amazon (PAID LINK): https://geni.us/ij2Qd0

Buy Crucial 32GB DDR4-2933 on Amazon (PAID LINK): https://geni.us/c8MOx

Gigabyte EPYC server: https://www.gigabyte.com/Rack-Server/R272-Z32-rev-100#ov

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1152200-this-server-deployment-was-horrible/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Come see us at LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

