# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## 10% of All Macs Have This Virus! (Shlayer)
 - [https://www.youtube.com/watch?v=tTO7qezIEnY](https://www.youtube.com/watch?v=tTO7qezIEnY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2020-02-05 00:00:00+00:00

Are YOU infected with this computer virus?

⇒ Become a channel member for exclusive features! Check it out here: https://www.youtube.com/ThioJoe/join

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe

⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV

My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

#Computers #Security #Tech #ThioJoe

