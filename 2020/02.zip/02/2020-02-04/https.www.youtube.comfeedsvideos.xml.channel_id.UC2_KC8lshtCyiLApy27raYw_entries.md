# Source:KnowledgeHusk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw, language:en-US

## An Intellectual Perspective on "Flapjack"
 - [https://www.youtube.com/watch?v=i8yEVxa5Nsg](https://www.youtube.com/watch?v=i8yEVxa5Nsg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw
 - date published: 2020-02-04 00:00:00+00:00

They ate too much candy

Twitter: https://twitter.com/KnowledgeHubTy
Soundcloud: https://soundcloud.com/user-503704039
Patreon: https://www.patreon.com/theknowledgehub
Second Channel: https://www.youtube.com/channel/UC-KL04Ra6E1Du0pFawN4pWg?view_as=subscriber

