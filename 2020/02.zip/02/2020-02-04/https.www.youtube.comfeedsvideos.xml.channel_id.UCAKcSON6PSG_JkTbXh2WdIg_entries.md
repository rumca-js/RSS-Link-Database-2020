# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Rex Orange County - interview with The Current's Mac Wilson
 - [https://www.youtube.com/watch?v=xz_JdL8SIdQ](https://www.youtube.com/watch?v=xz_JdL8SIdQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-02-04 00:00:00+00:00

Alex O'Connor, known professionally as Rex Orange County, speaks with The Current's Mac Wilson about being on tour, about mental health in the music industry, and about the new album, 'Pony.' 
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

