# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Right to Repair gets Eugene'd! 😢 Work Session on LD1977 in Maine 02/04/2020
 - [https://www.youtube.com/watch?v=freA2cTWd40](https://www.youtube.com/watch?v=freA2cTWd40)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-02-05 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
Find information below on how to reach out to your representatives who spoke today if you live in Maine. 

*Erin Herbig* - she is the one who was speaking in favor of the bill at 12:47, she gets it. https://legislature.maine.gov/District-11 She is also the CHAIR of this committee. Listen at 12:47 and again at 13:45 -  THIS SENATOR COULD BECOME A KEY ALLY HERE!

*Stephen Moriarty*  the retired attorney https://legislature.maine.gov/housedems/moriartys/index.html he has concerns regarding contract law at 16:20

*Joel Stetkis* - he is the one who said no one besides one person from his home state showed up in favor of this legislation. 20:40 I do not think this is a lost cause: he understands what we are talking about. However, he needs to believe that if it is going to be a fight it is 
a) worth it because this is large enough of a problem
b) Something people in his homestate actually find to be an issue. 
He suggested asking the attorney general if people have filed complaints regarding this issue of repair before. I believe CCing Representative Stetkis when writing YOUR attorney general complaints, might be helpful. If you are from Maine, it would be helpful if you let him know you support this bill from his home state. https://legislature.maine.gov/house/house/MemberProfiles/Details/150

*James Handy*  - he is the senator who spoke up when someone asked about impact on small business. he spoke out in defense of small business and explained the impact this would have on small business. I believe he is on our side. https://legislature.maine.gov/housedems/handyj/index.html - he proposed the amendment limiting it in scope, not because he wants to kill it, but because I believe he thinks he got in over his head. Listen at 22:20 - he jumps in to explain the plight of small businesses and is very sympathetic to them. His ONLY question of me was how this legislation would affect small business and he listened when I told him how this would positively affect small repair shops and encourage the starting of more small businesses. I believe his intent is not to kill the bill, but to come up with a compromise that allows it to pass without a line out the door of people looking to wreck a small town, part time legislature. Let's let him know some potential compromises that are less severe, and thank him for being the voice of small business. 

*Senator Guerin* - https://legislature.maine.gov/District-10

*Matthea Daughry* https://legislature.maine.gov/housedems/daughtrym/index.html

https://legislature.maine.gov/legis/bills/display_ps.asp?LD=1977&snum=129 
https://legiscan.com/ME/bill/LD1977/2019

👉 Thank you to everyone who has contributed, even a cent, to helping me in my journalistic efforts to travel around the country, record hearings, and lobby at them. 
🔵 Patreon: https://www.patreon.com/rossmanngroup
🔴 Credit card: https://bit.ly/tiplouis
⚫ Cryptocurrency:
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

## THANK YOU FOR SHOWING UP! LD1977 aftermath.
 - [https://www.youtube.com/watch?v=gdwkQSsjAEA](https://www.youtube.com/watch?v=gdwkQSsjAEA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-02-05 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
Find information below on how to reach out to your representatives who spoke today if you live in Maine. WHEN I GIVE TIMESTAMPS, I AM REFERRING TO THIS VIDEO: https://youtu.be/freA2cTWd40

*Erin Herbig* - she is the one who was speaking in favor of the bill at 12:47, she gets it. https://legislature.maine.gov/District-11 She is also the CHAIR of this committee. Listen at 12:47 and again at 13:45 -  THIS SENATOR COULD BECOME A KEY ALLY HERE!

*Stephen Moriarty*  the retired attorney https://legislature.maine.gov/housedems/moriartys/index.html he has concerns regarding contract law at 16:20

*Joel Stetkis* - he is the one who said no one besides one person from his home state showed up in favor of this legislation. 20:40 I do not think this is a lost cause: he understands what we are talking about. However, he needs to believe that if it is going to be a fight it is 
a) worth it because this is large enough of a problem
b) Something people in his homestate actually find to be an issue. 
He suggested asking the attorney general if people have filed complaints regarding this issue of repair before. I believe CCing Representative Stetkis when writing YOUR attorney general complaints, might be helpful. If you are from Maine, it would be helpful if you let him know you support this bill from his home state. https://legislature.maine.gov/house/house/MemberProfiles/Details/150

*James Handy*  - he is the senator who spoke up when someone asked about impact on small business. he spoke out in defense of small business and explained the impact this would have on small business. I believe he is on our side. https://legislature.maine.gov/housedems/handyj/index.html - he proposed the amendment limiting it in scope, not because he wants to kill it, but because I believe he thinks he got in over his head. Listen at 22:20 - he jumps in to explain the plight of small businesses and is very sympathetic to them. His ONLY question of me was how this legislation would affect small business and he listened when I told him how this would positively affect small repair shops and encourage the starting of more small businesses. I believe his intent is not to kill the bill, but to come up with a compromise that allows it to pass without a line out the door of people looking to wreck a small town, part time legislature. Let's let him know some potential compromises that are less severe, and thank him for being the voice of small business. 

*Senator Guerin* - https://legislature.maine.gov/District-10

*Matthea Daughry* https://legislature.maine.gov/housedems/daughtrym/index.html

https://legislature.maine.gov/legis/bills/display_ps.asp?LD=1977&snum=129 
https://legiscan.com/ME/bill/LD1977/2019


👉 Thank you to everyone who has contributed, even a cent, to helping me in my journalistic efforts to travel around the country, record hearings, and lobby at them. 
🔵 Patreon: https://www.patreon.com/rossmanngroup
🔴 Credit card: https://bit.ly/tiplouis
⚫ Cryptocurrency:
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

## Arrived in Maine for WORK SESSION(NOT HEARING) partisan politics discussion
 - [https://www.youtube.com/watch?v=FURRWw9gXBk](https://www.youtube.com/watch?v=FURRWw9gXBk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-02-04 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
Work session, NOT a hearing: https://legiscan.com/ME/bill/LD1977/2019
Hearing: Feb 4 @ 1:30 pm in Cross Building, Room 202 http://legislature.maine.gov/committee/#Committees/IDEAhttp://legislature.maine.gov/committee/#Committees/IDEA

Comment I am referring to in this video https://imgur.com/a/YgD4MZX  https://youtu.be/IOLhdu_bysI

Right To Repair: 99% inspiration, 1% legislation https://youtu.be/Nhuot32a0xs

