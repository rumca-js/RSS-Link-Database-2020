# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Diversity SWAT Teams And The State Of The Union With Guest Host Adam Ford
 - [https://www.youtube.com/watch?v=uqMrKaUWPec](https://www.youtube.com/watch?v=uqMrKaUWPec)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-02-05 00:00:00+00:00

This is the Babylon Bee weekly news podcast for the week of 2/5/2020 with special guest host ADAM FORD. 

 In this episode of The Babylon Bee podcast, editor-in-chief Kyle Mann and creative director Ethan Nicolle welcome the creator… of the Babylon Bee: Adam Ford. They discuss the week’s top stories like CNN’s coverage of the problematic panel of experts doing something about the deadly coronavirus, now multiple Bernie staffers advocating violent revolution, and Trump’s State Of The Union address where the guys make predictions about media reactions (by the time this episode airs, you can see how prophetic they were).

 In the subscriber portion, Kyle, Ethan, and Adam talk Superbowl half-time sex show, Brexit finally happening, and how our government’s legitimacy is forever gone now since Republican Senators didn’t just do whatever Democrats say.

 Adam Ford is now in the real news business. 

 Check out his new site DISRN. You can also sign up for the daily Adam Ford Newsletter.

  Pre-order the new Babylon Bee Best-Of Coffee Table Book coming in 2020!

 Show Outline

 Introduction - Kyle and Ethan welcome the Babylon Bee creator Adam Ford, discuss Kyle’s recent trip to a libertarian conference, and come up with a theme song for DISRN.

 Story 1 -  CNN Condemns D-Day Soldiers For Lack Of Diversity

   Trump tweeted out a photo of his task force. I guess it was all white males.

   "We will continue to monitor the ongoing developments," the President said in his post. "We have the best experts anywhere in the world, and they are on top of it 24/7!"

   CNN recently posted an  Coronavirus task force another example of Trump administration's lack of diversity… 

   “It's a statement that's as predictable as it is infuriating: President Donald Trump's administration lacks diversity… They communicate a "patronage network that everyone is operating under," as Eric Yellin, an associate professor of history and American studies at the University of Richmond, told The Washington Post last year, about a different set of photos. "Having that network be interracial is really important. But the visuals that have come to define the Trump administration say something else, too. They signal which people in a multi-racial, half-female country Trump values the opinions of: mostly white men who are mirror images of the President himself.

     Story 2 -  Uh-Oh: Sanders Campaign Texting 'Gulag For You' To People Who Aren't Voting For Bernie

   Project Veritas (James O’Keefe) continues to release candid camera clips of Bernie state campaign staffers (latest video highlights four of them)

   No Comment from the campaign

   No corporate media is covering it

   They’re all still employed.  

   Adam Ford Recommendation:  Go read the Gulag Archipelago by Aleksandr Solzhenitsyn.

 Story 3 -  Trump To Deliver State Of The Union In Scuba Gear To Avoid Drowning In Liberal Tears

   Official responses have already been released before the address:

   Snopes: FALSE

   New York Times: Detailed analysis of every person making an OK hand sign during the speech 

   Buzzfeed: Take this quiz to find out what emoji best represents your opinions

   Max Boot: Op ed - I was gonna become a Republican again until this speech

   Alex Jones: Not one word about water turning the frogs gay.

   Mike Pence: smiles, nods

   CNN: (laughs uncontrollably)

   Fox News: Flawless victory

   Marianne Williamson: To really know the State of the union we must consult with these Himalayan salt crystals I got on Etsy

   Greta Thunberg: (play audio)

   Vox: buy these special 3D racism glasses to see all the racism you missed last night 

   Jordan Peterson: (gnaws london broil)

   Topic of the Week -  Is the news worth paying attention to? How much should it take up our lives? How political should we be? With Adam Ford.

 Hate Mail/ Feedback - Apparently we are cowards.

 Paid-subscriber portion (Starts at 01:03:12)

 Story 1 -  Halftime Show Reduces Risk Of Wardrobe Malfunction By Eliminating Most Of Wardrobe (Subscriber Brandon Gaster contributed to this report)

   Jennifer Lopez and Shakira performed at the Super Bowl Halftime show featuring stripper poles, kids in cages, and Puerto Rican flags.

   Story 2 - Millions Drop Dead As Brexit Finalized

  See also Ethan’s lit photoshop on:  Boris Johnson Blows Conch Shell, England Carried Away By Herd Of Manatees  Story 3 -  Dems Who Ran Sham Impeachment Hearings Shocked As Republicans Run Sham Impeachment Trial

  Dan reads Adam Savage's insane tweet.  Kyle's kids make an appearance and shove a firetruck into Ethan's backside.

 Become a paid subscriber at https://babylonbee.com/plans

