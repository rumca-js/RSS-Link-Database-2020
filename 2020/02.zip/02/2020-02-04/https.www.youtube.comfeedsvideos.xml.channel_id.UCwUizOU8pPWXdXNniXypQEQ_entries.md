# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Tesla - Pretend to Save the Environment While Looking Rich
 - [https://www.youtube.com/watch?v=PLxPAwIeL0w](https://www.youtube.com/watch?v=PLxPAwIeL0w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-02-05 00:00:00+00:00

Owning a Tesla is the best way to pretend to save the environment while looking rich. Tesla owners are not only the biggest fans of Elon Musk, but they also know that owning a six figure electric car that's very taxing on the environment is the best way to care for the environment.
Subscribe to my channel for MORE! New videos every week!: https://www.youtube.com/user/AwakenWithJP?sub_confirmation=1

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Click Here to join my PATREON - https://awakenwithjp.com/patron
---- Want to be the first to see my new videos with 24 hour early access? Just click this to receive the alerts! - https://m.me/awakenwithjp?ref=w6836464

Listen and Subscribe to my NEW Podcast here: 
https://podcasts.apple.com/ca/podcast/awaken-with-jp-sears-show/id1436938686
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

-Order my new book at: http://HowToBeUltraSpiritual.com/

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

