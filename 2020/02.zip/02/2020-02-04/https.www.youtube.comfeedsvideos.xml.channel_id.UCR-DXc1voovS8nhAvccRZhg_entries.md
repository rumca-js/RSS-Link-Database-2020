# Source:Jeff Gerling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg, language:en-US

## Drupal 7 to 8 LIVE Migration - Ep 1 - Set up Drupal codebase, git repo, Docker dev environment
 - [https://www.youtube.com/watch?v=EyI_OwhufNk](https://www.youtube.com/watch?v=EyI_OwhufNk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg
 - date published: 2020-02-04 00:00:00+00:00

In this inaugural livestream, I set up a new Drupal project and Git repository for JeffGeerling.com, and show you how I set up a simple local development environment using Docker. I also accidentally cover up my terminal window with my face because it's the first time I've ever done a live stream :)

I will continue doing these live streams every Tuesday, and hopefully end up doing the final live production migration on YouTube soon!

