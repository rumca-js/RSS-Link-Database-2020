# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Jojo Rabbit - Movie Review
 - [https://www.youtube.com/watch?v=5D4OXWYsF1E](https://www.youtube.com/watch?v=5D4OXWYsF1E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-02-04 00:00:00+00:00

So I finally saw JOJO RABBIT...And it's much different (and more heartfelt) than I thought. Here's my review.

#JoJoRabbit

