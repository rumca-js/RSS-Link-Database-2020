# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## December 2019 - Journal/Vlog
 - [https://www.youtube.com/watch?v=3qBkNy98UEg](https://www.youtube.com/watch?v=3qBkNy98UEg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-02-11 00:00:00+00:00

The final chapter in my monthly Journals of 2019. I hope you all enjoyed a look into the life (or one year) of someone who talks about the fun and trivial for a living.

