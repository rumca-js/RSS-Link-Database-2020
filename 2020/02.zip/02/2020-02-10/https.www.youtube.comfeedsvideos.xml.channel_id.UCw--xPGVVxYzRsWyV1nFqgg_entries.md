# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## STORMLIGHT 4 TITLE & ART REVEALED, FANTASY SERIES ENDING IN 2020, BIRDS OF PREY FLOPS - FANTASY NEWS
 - [https://www.youtube.com/watch?v=LwAXBmw16cs](https://www.youtube.com/watch?v=LwAXBmw16cs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-02-11 00:00:00+00:00

Its that time of the week again! Enjoy some FANTASY NEWS!! 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene
 
P.O. Box 1016 Dublin, Ohio 43017
with the backup of:
715 Shawan falls Dr. Dublin, Ohio 43017

NEWS: 

Star Trek Steaming Service: https://arstechnica.com/gadgets/2020/02/viacomcbs-plan-would-unify-all-of-star-trek-and-more-in-one-new-streaming-service/

Series Ending in 2020: https://www.torforgeblog.com/2020/02/05/a-fond-farewell-series-were-saying-goodbye-to-in-2020/

Chaos Walking: https://deadline.com/2020/02/chaos-walking-daisy-ridley-tom-holland-january-2021-release-1202854439/

#Mistborn Screenplay: https://twitter.com/xcatherinereads/status/1225590174190432256
Cathrines channel: https://www.youtube.com/channel/UCJqGacjWwoYXUTbCAihyiyQ

#BabyYoda Funko Pop Sales: https://comicbook.com/gear/2020/02/06/baby-yoda-is-the-best-selling-funko-pop-of-all-time/

Christian Bale Thor 4: https://www.theilluminerdi.com/2020/02/04/christian-bale-villain-thor-4/

Y The Last Man Star Leaves: https://discordapp.com/channels/480406622028431373/500315229666934795

Birds Of Prey Failure: https://www.thewrap.com/birds-of-prey-falls-to-worst-dc-opening-weekend-since-jonah-hex/

#Stormlight 4 Title: https://www.tor.com/2020/02/10/brandon-sanderson-stormlight-archive-book-4-title-revealed-rhythm-of-war/

## HOUSE OF CHAINS - MALAZAN RAMBLE REVIEW
 - [https://www.youtube.com/watch?v=awjzJ34z1mY](https://www.youtube.com/watch?v=awjzJ34z1mY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-02-10 00:00:00+00:00

My ramble review of Malazan Book Of The Fallen's House Of Chains. 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene
 
P.O. Box 1016 Dublin, Ohio 43017
with the backup of:
715 Shawan falls Dr. Dublin, Ohio 43017

