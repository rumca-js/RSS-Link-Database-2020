# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## How to Milk a Cockroach
 - [https://www.youtube.com/watch?v=UYWNXqb0tZM](https://www.youtube.com/watch?v=UYWNXqb0tZM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2020-02-11 00:00:00+00:00

Cow, almond, soy, goat. There are a lot of choices when it comes to milk, but if you're looking for that nutritious boost of vitamins and minerals in the morning, have you considered cockroach milk?

Hosted by: Olivia Gordon

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Kevin Bealer, KatieMarie Magnone, D.A. Noe, Charles Southerland, Eric Jensen, Christopher R Boucher, Alex Hackman, Matt Curls, Adam Brainard, Scott Satovsky Jr, Sam Buck, Avi Yashchin, Ron Kakar, Chris Peters, Kevin Carpentier, Patrick D. Ashmore, Piya Shedden, Sam Lutfi, charles george, Greg 
----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:

https://askentomologists.com/2016/07/31/cockroach-milk-is-not-the-next-superfood/
http://elsakristen.com/docs/diploptera.pdf 
https://www.tandfonline.com/doi/abs/10.1080/01688170.1987.10510267?journalCode=tinv19 
https://www.synchrotron-soleil.fr/en/news/structure-and-nutritive-power-cockroach-milk-crystals
https://www.npr.org/sections/thesalt/2016/08/06/488861223/cockroach-milk-yes-you-read-that-right 
https://vpm.org/news/articles/1619/cockroach-milk 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC397435/
https://www.nytimes.com/1991/03/12/science/can-you-like-a-roach-you-might-be-surprised.html
https://www.washingtonpost.com/archive/1999/11/10/survivors/dbe9a1e4-f86e-4bcd-9dd1-b71e455aef66/
https://pdfs.semanticscholar.org/00a4/0d1ad33fefd60bab8da288ee045972a7f49f.pdf
https://www.ncbi.nlm.nih.gov/pubmed/23644152
https://www.sciencealert.com/scientists-think-we-should-start-drinking-cockroach-milk-superfood

## The Only Water on Earth Without Life
 - [https://www.youtube.com/watch?v=_eFPaeeh-Ys](https://www.youtube.com/watch?v=_eFPaeeh-Ys)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2020-02-10 00:00:00+00:00

When it comes to water on Earth, life finds a way. Even in the hottest, most acidic, and saltiest waters in the world, odds are you'll find some kind of organism adapted to live in it. There is, however, a place with water so extremely inhospitable that no native life has ever been found there. 

Hosted by: Stefan Chin

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Kevin Bealer, KatieMarie Magnone, D.A. Noe, Charles Southerland, Eric Jensen, Christopher R Boucher, Alex Hackman, Matt Curls, Adam Brainard, Scott Satovsky Jr, Sam Buck, Avi Yashchin, Ron Kakar, Chris Peters, Kevin Carpentier, Patrick D. Ashmore, Piya Shedden, Sam Lutfi, charles george, Greg 
----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://www.eurekalert.org/pub_releases/2019-11/f-sf-sfa112219.php
https://www.nature.com/articles/s41559-019-1005-0#Sec1
https://twitter.com/BelillaJodie/status/1137305837469409280
https://www.newscientist.com/article/dn9507-life-finds-a-way-in-the-driest-desert-on-earth/, https://www.frontiersin.org/articles/10.3389/fmicb.2017.00993/full, https://www.nature.com/articles/s41598-018-35051-w
https://www.frontiersin.org/articles/10.3389/fmicb.2019.00780/full,
https://www.nature.com/articles/s41559-019-1021-0?proof=trueHere 
https://www.bbc.com/future/article/20170803-in-earths-hottest-place-life-has-been-found-in-pure-acid
https://pubs.rsc.org/en/content/articlelanding/2015/cp/c4cp04564e#!divAbstract 
http://www1.lsbu.ac.uk/water/kosmotropes_chaotropes.html
https://www.ncbi.nlm.nih.gov/pubmed/16152629 
https://www.liebertpub.com/doi/full/10.1089/ast.2018.1926#s013
https://link.springer.com/content/pdf/10.1007%2Fs002030050649.pdf
https://link.springer.com/content/pdf/10.1007%2F978-3-642-11274-4_336.pdf)
http://www1.lsbu.ac.uk/water/water_activity.html

