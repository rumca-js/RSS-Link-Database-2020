# Source:Kołem się toczy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw, language:pl-PL

## DZIEŃ DOBRY NEPAL! 💥4K
 - [https://www.youtube.com/watch?v=5FcmojaLoxA](https://www.youtube.com/watch?v=5FcmojaLoxA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw
 - date published: 2020-02-11 00:00:00+00:00

Mój kurs filmowania i montażu online 👉 https://www.kursfilmowaniaimontazu.pl/

Zachęcam do subskrypcji 👉 http://bit.ly/2cmWbSO 


Melduję, że dzisiejszy film miał być z Patagonii, jednak będzie z Nepalu, bo po prostu zmontował mi się sam. Po filmie powiem Wam o co chodzi, tymczasem  proszę o zwiększenie głośności, wrzucenie trybu pełnoekranowego, ustawienie 4K i zapraszam do "Dzień Dobry Nepal" w którym samym obrazem i muzyką starałem się podsumować tę nepalską serię i przedstawić jak żyją ludzie w Nepalu. Pokazać kontrast między trudnym życiem w aglomeracji Kathmandu, a chyba jeszcze trudniejszym aczkolwiek piękniejszy życiem na nepalskiej wsi.

Lubisz to co robimy? Zostań Patronem i twórzmy razem ►► https://patronite.pl/kolemsietoczy

Zapraszam też na:
Facebook: http://bit.ly/2flU84f
Instagram: http://bit.ly/2eTrIMc
Blog: http://kolemsietoczy.pl/

