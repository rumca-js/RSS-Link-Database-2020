# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## If We Plant 1 TRILLION Trees Can We Stop Climate Change?
 - [https://www.youtube.com/watch?v=PX1Rc0xlUpk](https://www.youtube.com/watch?v=PX1Rc0xlUpk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2020-02-11 00:00:00+00:00

PBS Member Stations rely on viewers like you. To support your local station, go to: http://to.pbs.org/DonateOKAY
↓ More info and sources below ↓

SUBSCRIBE so you don’t miss a video! ►► http://bit.ly/iotbs_sub 
We’re on PATREON now! Join the community ►► https://www.patreon.com/itsokaytobesmart

Can trees really save us from climate change? For eons, nature has relied on photosynthesis as a big way to keep carbon dioxide levels from getting out of control. But as we have put more carbon into the air, we’ve also cut down many of the forests we need to suck that carbon up. So big tree-planting initiatives like #TeamTrees to the rescue, right? Actually, we need to think bigger. Here’s three ways trees really can help us solve climate change, from a guy who wants to plant a TRILLION trees, to how we might save the forests we’ve got, to scientists hacking biology to make trees even better. 

References: https://sites.google.com/view/3waystreescansavetheclimate/home

Aspect Science: Team Trees Explained https://youtu.be/SLHCA-hHx4Y 

Special thanks to Felix Finkbeiner
https://www.plant-for-the-planet.org/en/home 

Special thanks to our Brain Trust Patrons:
AlecZero
Bob Rosset
Brent M.
Diego Lombeida
Ron Kakar

-----------
Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/

