# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## HE TOUCHED MY FACE!! | Russell Brand Storytime
 - [https://www.youtube.com/watch?v=1zF0E21cRtg](https://www.youtube.com/watch?v=1zF0E21cRtg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-02-10 00:00:00+00:00

IT'S STORYTIME! I was so full of rage about what happened to me at this Superbowl Party - I had to sit down and work it out.

Tell me in the comments below if you have a resentment against a person, place or thing. 
1. Who/what you have the resentment about...
2. Because... (what they DID to you - a very plain and simple explanation e.g. because they cut me up in traffic, because my girlfriend broke up with me)

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

