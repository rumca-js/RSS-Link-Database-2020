# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Galaxy S20 Impressions: New Year, New Samsung!
 - [https://www.youtube.com/watch?v=ZdC9soHxVC8](https://www.youtube.com/watch?v=ZdC9soHxVC8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-02-11 00:00:00+00:00

Samsung Galaxy S20 makes all the right moves in all right places.

Galaxy S20 Ultra: https://youtu.be/WPsvw_Db-y4

MKBHD Merch: http://shop.MKBHD.com

Video Gear I use: http://kit.co/MKBHD/video-gear#recom...
Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Jordyn Edmonds http://smarturl.it/jordynedmonds 
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

## Samsung Galaxy S20 Ultra Impressions: 108 Megapixels!
 - [https://www.youtube.com/watch?v=WPsvw_Db-y4](https://www.youtube.com/watch?v=WPsvw_Db-y4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-02-11 00:00:00+00:00

Galaxy S20 Ultra is the "pro" of Samsung's lineup.

Galaxy S20 and S20+: https://youtu.be/ZdC9soHxVC8

MKBHD Merch: http://shop.MKBHD.com

Video Gear I use: http://kit.co/MKBHD/video-gear#recom...
Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Alltta
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

## Foldable Moto RAZR Unboxing & Second Thoughts!
 - [https://www.youtube.com/watch?v=lCKcFFDgtNk](https://www.youtube.com/watch?v=lCKcFFDgtNk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-02-10 00:00:00+00:00

The new RAZR: Is this really the best way to do a folding phone?

Moto RAZR: https://motorola.com/us/products/razr

MKBHD Merch: http://shop.MKBHD.com

Video Gear I use: http://kit.co/MKBHD/video-gear#recom...
Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Million Dreams by Alltta
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

