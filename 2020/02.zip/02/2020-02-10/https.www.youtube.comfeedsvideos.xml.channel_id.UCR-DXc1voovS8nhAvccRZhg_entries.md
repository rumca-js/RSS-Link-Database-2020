# Source:Jeff Gerling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg, language:en-US

## Drupal 7 to 8 LIVE Migration - Ep 2 - Adding modules with Composer, beginning migrations
 - [https://www.youtube.com/watch?v=yS1qIcpWZZI](https://www.youtube.com/watch?v=yS1qIcpWZZI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg
 - date published: 2020-02-11 00:00:00+00:00

In this second livestream, we take the new Drupal 8 codebase and site we created, add required migration modules via Composer, and start working on migrating configuration and content from Drupal 7 to Drupal 8.

See more: https://www.jeffgeerling.com/blog/2020/migrating-jeffgeerlingcom-drupal-7-drupal-8-how-video-series

