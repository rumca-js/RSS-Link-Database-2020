# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## A Mushroom Trip Convinced Rashad Evans to Become Vegan | Joe Rogan
 - [https://www.youtube.com/watch?v=C_hym_qz4NM](https://www.youtube.com/watch?v=C_hym_qz4NM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-11 00:00:00+00:00

Taken from JRE MMA Show #90 w/Rashad Evans:
https://youtu.be/auslk18GgIE

## Joe Rogan Breaksdown Jon Jones vs. Dominick Reyes w/Rashad Evans
 - [https://www.youtube.com/watch?v=aZlB1pSlwrY](https://www.youtube.com/watch?v=aZlB1pSlwrY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-11 00:00:00+00:00

Taken from JRE MMA Show #90 w/Rashad Evans:
https://youtu.be/auslk18GgIE

## Joe Rogan and Rashad Evans Compare DMT Experiences
 - [https://www.youtube.com/watch?v=j337hH_fYFk](https://www.youtube.com/watch?v=j337hH_fYFk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-11 00:00:00+00:00

Taken from JRE MMA Show #90 w/Rashad Evans: https://youtu.be/auslk18GgIE

## Psychedelics Helped Rashad Evans With Retirement Transition | Joe Rogan
 - [https://www.youtube.com/watch?v=plQsLodHv0M](https://www.youtube.com/watch?v=plQsLodHv0M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-11 00:00:00+00:00

Taken from JRE MMA Show #90 w/Rashad Evans:
https://youtu.be/auslk18GgIE

## Rashad Evans Credits Athletic Gains to Vegan Diet
 - [https://www.youtube.com/watch?v=9Tb8OqfWozI](https://www.youtube.com/watch?v=9Tb8OqfWozI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-11 00:00:00+00:00

Taken from JRE MMA Show #90 w/Rashad Evans: https://youtu.be/auslk18GgIE

## Rashad Evans Premieres MMA Gloves Designed by Trevor Wittman
 - [https://www.youtube.com/watch?v=kRGupKJ8Hbs](https://www.youtube.com/watch?v=kRGupKJ8Hbs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-11 00:00:00+00:00

Taken from JRE MMA Show #90 w/Rashad Evans: https://youtu.be/auslk18GgIE

## Rashad Evans on the Biggest Victory of His Career
 - [https://www.youtube.com/watch?v=3eLMk9R7AC0](https://www.youtube.com/watch?v=3eLMk9R7AC0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-11 00:00:00+00:00

Taken from JRE MMA Show #90 w/Rashad Evans: https://youtu.be/auslk18GgIE

## Rashad Evans on the Blackzilians and ATT Rivalry
 - [https://www.youtube.com/watch?v=6NUPngfHkHI](https://www.youtube.com/watch?v=6NUPngfHkHI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-11 00:00:00+00:00

Taken from JRE MMA Show #90 w/Rashad Evans: https://youtu.be/auslk18GgIE

## Rashad Evans: Greg Jackson’s Mental Training Broke Men Down
 - [https://www.youtube.com/watch?v=QJmwoodHQEU](https://www.youtube.com/watch?v=QJmwoodHQEU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-11 00:00:00+00:00

Taken from JRE MMA Show #90 w/Rashad Evans: https://youtu.be/auslk18GgIE

## The Social Implications of a Man Purse w/Rashad Evans | Joe Rogan
 - [https://www.youtube.com/watch?v=GtMxJ1leWRY](https://www.youtube.com/watch?v=GtMxJ1leWRY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-11 00:00:00+00:00

Taken from JRE MMA Show #90 w/Rashad Evans:
https://youtu.be/auslk18GgIE

## Why Rashad Evans Started Twisting His Nipples Before Fights
 - [https://www.youtube.com/watch?v=MkJuTj0cfg0](https://www.youtube.com/watch?v=MkJuTj0cfg0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-11 00:00:00+00:00

Taken from JRE MMA Show #90 w/Rashad Evans: https://youtu.be/auslk18GgIE

