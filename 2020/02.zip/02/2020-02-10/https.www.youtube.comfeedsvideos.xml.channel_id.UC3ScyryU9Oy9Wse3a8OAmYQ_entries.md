# Source:FRONTLINE PBS | Official, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ, language:en-US

## Netanyahu at War (full documentary) | FRONTLINE
 - [https://www.youtube.com/watch?v=7W-xxpXzAC0](https://www.youtube.com/watch?v=7W-xxpXzAC0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ
 - date published: 2020-02-11 00:00:00+00:00

An inside look at Israeli Prime Minister Benjamin Netanyahu’s political rise and his combative relationship with past U.S. presidents.

This journalism is made possible by viewers like you. Support your local PBS station here: http://www.pbs.org/donate

Love FRONTLINE? Find us on the PBS Video App where there are more than 250 FRONTLINE documentaries available for you to watch any time: https://to.pbs.org/FLVideoApp
 
Subscribe on YouTube: http://bit.ly/1BycsJW

#Netanyahu #Documentary #FrontlinePBS

Instagram: https://www.instagram.com/frontlinepbs
Twitter: https://twitter.com/frontlinepbs
Facebook: https://www.facebook.com/frontline

FRONTLINE is streaming more than 200 documentaries online, for free, here: http://to.pbs.org/hxRvQP 

Funding for FRONTLINE is provided through the support of PBS viewers and by the Corporation for Public Broadcasting. Major funding for FRONTLINE is provided by the John D. and Catherine T. MacArthur Foundation. Additional funding is provided by the Park Foundation, The John and Helen Glessner Family Trust, the Ford Foundation, the Wyncote Foundation, and the FRONTLINE Journalism Fund with major support from Jon and Jo Ann Hagler on behalf of the Jon L. Hagler Foundation.

