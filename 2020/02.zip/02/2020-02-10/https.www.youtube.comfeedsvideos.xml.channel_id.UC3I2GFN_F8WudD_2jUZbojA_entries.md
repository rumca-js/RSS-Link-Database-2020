# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Pillow Queens - Brothers (Live on KEXP)
 - [https://www.youtube.com/watch?v=-25qsesP6Yc](https://www.youtube.com/watch?v=-25qsesP6Yc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-11 00:00:00+00:00

http://KEXP.ORG presents Pillow Queens performing "Brothers" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 9, 2019.

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director & Editor: Scott Holpainen

http://kexp.org
http://pillowqueens.com

## Pillow Queens - Child Of Prague (Live on KEXP)
 - [https://www.youtube.com/watch?v=GjfFffjf5Gc](https://www.youtube.com/watch?v=GjfFffjf5Gc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-11 00:00:00+00:00

http://KEXP.ORG presents Pillow Queens performing "Child Of Prague" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 9, 2019.

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director & Editor: Scott Holpainen

http://kexp.org
http://pillowqueens.com

## Pillow Queens - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=MhINlOM1pbY](https://www.youtube.com/watch?v=MhINlOM1pbY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-11 00:00:00+00:00

http://KEXP.ORG presents Pillow Queens performing live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 9, 2019.

Songs:
HowDoILook
Brothers
Rats
Child Of Prague
Gay Girls
Liffey

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director & Editor: Scott Holpainen

http://kexp.org
http://pillowqueens.com

## Pillow Queens - Gay Girls (Live on KEXP)
 - [https://www.youtube.com/watch?v=DooXtBzpkJ0](https://www.youtube.com/watch?v=DooXtBzpkJ0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-11 00:00:00+00:00

http://KEXP.ORG presents Pillow Queens performing "Gay Girls" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 9, 2019.

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director & Editor: Scott Holpainen

http://kexp.org
http://pillowqueens.com

## Pillow Queens - HowDoILook (Live on KEXP)
 - [https://www.youtube.com/watch?v=P6fetVclinw](https://www.youtube.com/watch?v=P6fetVclinw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-11 00:00:00+00:00

http://KEXP.ORG presents Pillow Queens performing "HowDoILook" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 9, 2019.

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director & Editor: Scott Holpainen

http://kexp.org
http://pillowqueens.com

## Pillow Queens - Liffey (Live on KEXP)
 - [https://www.youtube.com/watch?v=v72wE5sbzB4](https://www.youtube.com/watch?v=v72wE5sbzB4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-11 00:00:00+00:00

http://KEXP.ORG presents Pillow Queens performing "Liffey" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 9, 2019.

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director & Editor: Scott Holpainen

http://kexp.org
http://pillowqueens.com

## Pillow Queens - Rats (Live on KEXP)
 - [https://www.youtube.com/watch?v=2YyWn58fDIQ](https://www.youtube.com/watch?v=2YyWn58fDIQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-11 00:00:00+00:00

http://KEXP.ORG presents Pillow Queens performing "Rats" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 9, 2019.

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director & Editor: Scott Holpainen

http://kexp.org
http://pillowqueens.com

## Whitney - Before I Know It (Live on KEXP)
 - [https://www.youtube.com/watch?v=ZMs369MsSwc](https://www.youtube.com/watch?v=ZMs369MsSwc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-10 00:00:00+00:00

http://KEXP.ORG presents Whitney performing "Before I Know It" live in the KEXP studio. Recorded October 25, 2019.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro, Kendall Rock & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
http://www.whitneytheband.com

## Whitney - Friend Of Mine (Live on KEXP)
 - [https://www.youtube.com/watch?v=Bnf8_97qeLg](https://www.youtube.com/watch?v=Bnf8_97qeLg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-10 00:00:00+00:00

http://KEXP.ORG presents Whitney performing "Friend Of Mine" live in the KEXP studio. Recorded October 25, 2019.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro, Kendall Rock & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
http://www.whitneytheband.com

## Whitney - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=K5WBkdEhs90](https://www.youtube.com/watch?v=K5WBkdEhs90)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-10 00:00:00+00:00

http://KEXP.ORG presents Whitney performing live in the KEXP studio. Recorded October 25, 2019.

Songs:
Friend Of Mine
Giving Up
Before I Know It
Valleys My Love

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro, Kendall Rock & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
http://www.whitneytheband.com

## Whitney - Giving Up (Live on KEXP)
 - [https://www.youtube.com/watch?v=612dqrz8gys](https://www.youtube.com/watch?v=612dqrz8gys)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-10 00:00:00+00:00

http://KEXP.ORG presents Whitney performing "Giving Up" live in the KEXP studio. Recorded October 25, 2019.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro, Kendall Rock & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
http://www.whitneytheband.com

## Whitney - Valleys My Love (Live on KEXP)
 - [https://www.youtube.com/watch?v=HLX4TZJAZmc](https://www.youtube.com/watch?v=HLX4TZJAZmc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-10 00:00:00+00:00

http://KEXP.ORG presents Whitney performing "Valleys My Love" live in the KEXP studio. Recorded October 25, 2019.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro, Kendall Rock & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
http://www.whitneytheband.com

