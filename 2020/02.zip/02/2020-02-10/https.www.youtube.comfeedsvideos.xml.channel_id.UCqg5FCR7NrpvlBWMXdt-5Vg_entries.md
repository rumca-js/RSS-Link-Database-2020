# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Developed by One Person, Bright Memory Is an FPS Absolutely Worth Your Time | UnderDeveloped
 - [https://www.youtube.com/watch?v=-PfH9_Pk8R0](https://www.youtube.com/watch?v=-PfH9_Pk8R0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-02-10 00:00:00+00:00

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

This week Jack looks at Bright Memory, an early access title that shoves five pounds of quality into a two-pound sack.

Bright Memory is a fast-paced, action-heavy first-person shooter that is short, weird, and a heck of a lot of fun.

Is the $7.00 price tag worth it? Are there noticeable bugs? Does the game make any sense!?!? Find out here because this is UnderDeveloped.

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►► https://sharkrobot.com/collections/zero-punctuation 

Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 

Like us on Facebook ►► http://www.facebook.com/EscapistMag

Follow us on Twitter ►► https://twitter.com/EscapistMag

## Zombie Army 4: Dead War | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=VEtwBKBpmQM](https://www.youtube.com/watch?v=VEtwBKBpmQM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-02-10 00:00:00+00:00

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

KC Nwosu reviews Zombie Army 4: Dead War, developed by Rebellion.

Zombie Army 4: Dead War on EGS: https://www.epicgames.com/store/en-US/product/zombie-army-4-dead-war/home

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►► https://sharkrobot.com/collections/zero-punctuation 

Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 

Like us on Facebook ►► http://www.facebook.com/EscapistMag

Follow us on Twitter ►► https://twitter.com/EscapistMag

#ZombieArmy4

