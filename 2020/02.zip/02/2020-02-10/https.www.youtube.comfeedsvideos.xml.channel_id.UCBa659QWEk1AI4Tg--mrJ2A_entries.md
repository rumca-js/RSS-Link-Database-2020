# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## The Dutch headwind cycling championships are amazing
 - [https://www.youtube.com/watch?v=VMinwf-kRlA](https://www.youtube.com/watch?v=VMinwf-kRlA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2020-02-10 00:00:00+00:00

About once a year, on the Oosterscheldekering barrier in the south of the Netherlands, there is NK Tegenwindfietsen: a bicycle race cycling into a headwind. This year it was 120km/h: this is why it's so difficult, and also why it's so brilliant.

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

