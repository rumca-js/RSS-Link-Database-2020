# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## Your Brain's Incredible Healing Powers | Answers With Joe
 - [https://www.youtube.com/watch?v=Ug9vGRVas2Q](https://www.youtube.com/watch?v=Ug9vGRVas2Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2020-02-10 00:00:00+00:00

Get 1 month of CuriosityStream for free and access to Nebula when you sign up at http://www.curiositystream.com/joescott
The placebo effect is the phenomenon of your body responding to a treatment even if it's not real. It happens so much, so strongly, and so often that it has to be factored in to any medical study.

It speaks to the amazing ability of the brain to physiologically change the body in surprising ways.

Want to support this channel? If so, Thanks! You're awesome! Here's how:

Patreon: http://www.patreon.com/answerswithjoe

Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join

Cool shirts and stuff: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link to get discounts and perks:
https://ts.la/joe74700

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

Stanford video on placebo:
https://www.youtube.com/watch?v=udJ31KKXBKk

TED-Ed
https://www.youtube.com/watch?v=z03FQGlGgo0

TED Med
https://www.youtube.com/watch?v=WcQnSW1wpGA

https://www.popsci.com/science/article/2013-06/were-making-less-effective-drugs-now-40-years-ago-study-finds/

https://www.smithsonianmag.com/science-nature/what-is-the-nocebo-effect-5451823/

