# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## How many Chrome tabs can you open with 2TB RAM?
 - [https://www.youtube.com/watch?v=7iwgyzX-76g](https://www.youtube.com/watch?v=7iwgyzX-76g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-02-11 00:00:00+00:00

Buy SK hynix Gold S31 SSD on Amazon: https://geni.us/x6HG
Thanks to SK hynix for sponsoring this video!

Discuss on the forum: https://linustechtips.com/main/topic/1154562-how-many-chrome-tabs-can-you-open-with-2tb-ram/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

## This weird thing made my phone faster...
 - [https://www.youtube.com/watch?v=78dHkn1O1EM](https://www.youtube.com/watch?v=78dHkn1O1EM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-02-10 00:00:00+00:00

Check out the DROP CTRL Mechanical Keyboard at https://dro.ps/ltt-ctrl-feb

Antlion Audio ModMic USB: https://lmg.gg/Ute7a
Antlion Audio ModMic Uni: https://lmg.gg/LgWsR
Antlion Audio ModMic Wireless: https://lmg.gg/FY2cj

What can you do if your phone keeps thermal throttling? We have a few ideas...

Buy Samsung Galaxy S10+ on Amazon (PAID LINK): https://shop-links.co/1721603343657878553

Buy Nubia Red Magic 3 on Amazon (PAID LINK): https://geni.us/msBk5

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1154222-this-ugly-phone-cooler-actually-works/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Come see us at LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

