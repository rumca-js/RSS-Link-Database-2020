# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## AMA before leaving for Maine work session on 13th
 - [https://www.youtube.com/watch?v=HGg2SY_7TR8](https://www.youtube.com/watch?v=HGg2SY_7TR8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-02-11 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
Multistreaming with https://restream.io/

Donate & post a message: https://streamlabs.com/louisrossmann Ask me anything, so long as it isn't ridiculous. I will read the live chat too if it doesn't get to 100+ messages a minute. 

Maine bill: https://legiscan.com/ME/bill/LD1977/2019
Maryland bill: https://legiscan.com/MD/bill/HB1124/2020
Colorado bill: https://legiscan.com/CO/bill/HB1195/2020
Idaho bill: https://legiscan.com/ID/bill/S1300/2020

👉 Thank you to everyone who has contributed, even a cent, to helping me in my journalistic efforts to travel around the country, record hearings, and lobby at them. 
🔵 Patreon: https://www.patreon.com/rossmanngroup
🔴 Credit card: https://bit.ly/tiplouis
⚫ Cryptocurrency:
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

## I'm not angry at CompTIA. I'm just disappointed in them. 😞
 - [https://www.youtube.com/watch?v=hRM7bM0sW9Y](https://www.youtube.com/watch?v=hRM7bM0sW9Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-02-11 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
https://www.capitol.hawaii.gov/Session2020/Testimony/HB1884_TESTIMONY_CPC_01-30-20_.PDF 
https://www.capitol.hawaii.gov/Session2020/Testimony/SB2496_TESTIMONY_CPH_02-06-20_.PDF
https://youtu.be/3VLCIiptbTA 
https://youtu.be/8ZQb6hRP0oY

## 📢 STOP PAYING COMPTIA FOR A+ CERTIFICATIONS!
 - [https://www.youtube.com/watch?v=uSW0Wg32QNI](https://www.youtube.com/watch?v=uSW0Wg32QNI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-02-11 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
https://projects.propublica.org/nonprofits/display_990/61058206/02_2019_prefixes_04-11%2F061058206_201712_990O_2019020816076533

https://projects.propublica.org/nonprofits/organizations/61058206

https://www.theverge.com/2019/5/1/18525542/apple-right-to-repair-bill-california-lobbyist-comptia

https://fcw.com/articles/2014/05/05/comptia-tech-america-merger.aspx

👉 Thank you to everyone who has contributed, even a cent, to helping me in my journalistic efforts to travel around the country, record hearings, and lobby at them.
🔵 Patreon: https://www.patreon.com/rossmanngroup
🔴 Credit card: https://bit.ly/tiplouis
⚫ Cryptocurrency:
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

