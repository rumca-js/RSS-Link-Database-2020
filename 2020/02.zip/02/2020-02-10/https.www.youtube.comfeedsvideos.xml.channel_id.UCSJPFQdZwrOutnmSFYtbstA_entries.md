# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Birds of Prey - It's a Garbage Movie
 - [https://www.youtube.com/watch?v=JXKUriED2gg](https://www.youtube.com/watch?v=JXKUriED2gg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-02-10 00:00:00+00:00

So I watched Birds of Prey last night, and it turns out it was awful. Join me as I explore why this movie was destined to fail.

