# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Johnossi - What's The Point - live MUZO.FM
 - [https://www.youtube.com/watch?v=oD2_t9mfxSs](https://www.youtube.com/watch?v=oD2_t9mfxSs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-02-11 00:00:00+00:00

Johnossi What's The Point na żywo w MUZO.FM. Johnossi to szwedzki duet rockowy. Najnowsza płyta Johnossi nosi tytuł Torch//Flame.

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Johnossi: http://www.facebook.com/johnossi
Instagram Johnossi: http://www.instagram.com/johnossi_official
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm

## Mighty Oaks - All Things Go - live MUZO.FM
 - [https://www.youtube.com/watch?v=TgVPo0AX3gY](https://www.youtube.com/watch?v=TgVPo0AX3gY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-02-11 00:00:00+00:00

Mighty Oaks - All Things Go na żywo w MUZO.FM. Utwór Mighty Oaks All Things Go pochodzi z płyty Mighty Oaks All Things Go. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Mighty Oaks: http://www.facebook.com/mightyoaksmusic
Instagram Mighty Oaks: http://www.instagram.com/mightyoaksmusic
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm


Mighty Oaks All Things Go tekst

Back in Mullingar
We spent our days at Canton Casey's bar
We spent our summers there
And we drank up the Irish air
And I can see you smile
Still today
When I close my eyes
And I still feel your hands
Holding mine back
And goodbye, yeah
All things go
They have their time
Goodbye, yeah
All things go
That's part of life
I was no rich man
But my love you saw past that
An elevator ride
At the right time
From Multyfarnham
All the way back to Gig Harbor
And I still feel your hands
Holding mine back
And goodbye, yeah
All things go
They have their time
Goodbye, yeah
All things go
That's part of life
It takes time 'til you know that
'Til you know that in your life
It takes time 'til you know that
'Til you know that in your life
Goodbye, yeah
All things go
They have their time
Goodbye, yeah
All things go
That's part of life
And all things go
They have their time
Goodbye
Goodbye
And all things go
That's part of life
Goodbye

## Johnossi - Longer The Wait, Harder The Fall - live MUZO.FM
 - [https://www.youtube.com/watch?v=nJII_yjoCX4](https://www.youtube.com/watch?v=nJII_yjoCX4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-02-10 00:00:00+00:00

Johnossi Longer The Wait, Harder The Fall na żywo w MUZO.FM. Johnossi to szwedzki duet rockowy. Najnowsza płyta Johnossi nosi tytuł Torch//Flame.

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Johnossi: http://www.facebook.com/johnossi
Instagram Johnossi: http://www.instagram.com/johnossi_official
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm


Johnossi Longer The Wait, Harder The Fall - tekst 

Downing gasoline 
Running on a dream
In the deep blue sky
Wanna waste no time 
In an open book 
How we need to look
In between dead lines
Wanna figure out 

How to move into… 

Better on a field 
Than in a factory  
Shield me from a stranger's arms
When the future dawns
What they say is not 
Something we should trust
It was a great big lie
Walk into the fire 

Every night, it's slipping out of my hand
Believing in something, I don’t understand 
The light of the day give me nothing at all
The longer the wait, yeah the harder the fall

The longer the wait, yeah the harder the fall
The longer the wait, yeah the harder the fall

Move from ash to dust
Realize, I’m nothing but a conscious stream
Living in between 
It's an open book 
How I need to look
Way above their lies
And walk into the fire

Every night, it's slipping out of my hand
Believing in something, I don’t understand 
The light of the day give me nothing at all
The longer the wait, yeah the harder the fall

And how do I dare to make fun of your ways
We had a solution, but now it's too late
And tell me your dream or say nothing at all
The longer the wait, yeah the harder the fall (Yeah)

The longer the wait, yeah the harder the fall
The longer the wait, yeah the harder the fall
Tell me your dream or say nothing at all
The longer the wait, yeah the harder the fall

## Mighty Oaks - Tell Me What You're Thinking - live MUZO.FM
 - [https://www.youtube.com/watch?v=wcvHTkytRhY](https://www.youtube.com/watch?v=wcvHTkytRhY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-02-10 00:00:00+00:00

Mighty Oaks - Tell Me What You're Thinking na żywo w MUZO.FM. Utwór Mighty Oaks Tell Me What You're Thinking pochodzi z płyty Mighty Oaks All Things Go. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Mighty Oaks: http://www.facebook.com/mightyoaksmusic
Instagram Mighty Oaks: http://www.instagram.com/mightyoaksmusic
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm


Mighty Oaks Tell Me What You're Thinking tekst

I know we've run out of time
But it looks like there's a mountain to climb
Can we get there oh I hardly know
But I will carry this on my own
On my own
Tell me what you're thinking
Do I ever cross your mind
Lately I've been drinking
Just to get me through the night
And all the messages we sent
Are still on my mind
Tell me what you're thinking
Do I ever cross your mind
And I made mistakes all along
But I never meant to do you harm
The thought of going our own ways
Oh you know it kills me more that I could say
More than I could say
Tell me what you're thinking
Do I ever cross your mind
Lately I've been drinking
Just to get me through the night
And all the messages we sent
Are still on my mind
Tell me what you're thinking
Do I ever cross your mind
Should should we go
Back to the beginning
Should should we go
Tell me what you're thinking
Do I ever cross your mind
Lately I've been drinking
Just to get me through the nights
And all the messages we sent
Are still on my mind
Tell me what you're thinking
Do I ever cross your mind
Should should we go
Should we go
Should should we go
Should we go
Should should I know
Should I know
Should should I know
Should I know what you're thinking

