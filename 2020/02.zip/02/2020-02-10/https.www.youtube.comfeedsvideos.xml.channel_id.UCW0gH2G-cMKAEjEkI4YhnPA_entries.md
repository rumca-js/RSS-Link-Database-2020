# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Bilbo's Speech: Insult or Compliment? | Tolkien Explained
 - [https://www.youtube.com/watch?v=5-vyZ9lB5Y4](https://www.youtube.com/watch?v=5-vyZ9lB5Y4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2020-02-11 00:00:00+00:00

Is Bilbo's famous line an insult or a compliment? Yes! (lol.) Basically, it's a bit of both! In the video, I break down why! Special thanks to my subscribers - you're the best!

"I don't know half of you half as well as I should like, and I like less than half of you half as well as you deserve!"  It's one of my favorite lines from Fellowship of the Ring. It's clever, it's complimentary (to some) and insulting (to others), and it shows how our lovable burglar, Bilbo Baggins loves a good joke! 

Please subscribe to Nerd of the Rings to help the channel grow and enable me to bring you more videos! #lordoftherings #bilbospeech

