# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Sharp rise in brain injuries from Iran raid on US base
 - [https://www.bbc.co.uk/news/world-us-canada-51453829](https://www.bbc.co.uk/news/world-us-canada-51453829)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 23:59:47+00:00

President Trump initially said no US troops were injured in the Iranian attack on US bases in Iraq.

## That Peter Crouch Podcast: Rooney was the 'life and soul of the dressing room' at the World Cup
 - [https://www.bbc.co.uk/sport/av/football/51453397](https://www.bbc.co.uk/sport/av/football/51453397)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 20:53:37+00:00

Peter Crouch says Wayne Rooney was "always jovial" and would set quizzes to keep everyone entertained at the World Cup in 2006.

## Women's Six Nations: Abby Dow scores two tries in treacherous Murrayfield conditions
 - [https://www.bbc.co.uk/sport/av/rugby-union/51451217](https://www.bbc.co.uk/sport/av/rugby-union/51451217)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 16:24:44+00:00

England winger Abby Dow scores two great tries in England's 53-0 thumping of Scotland in terrible conditions at Murraryfield.

## Scotland-Northern Ireland bridge: How likely is it to be built?
 - [https://www.bbc.co.uk/news/uk-scotland-south-scotland-49661019](https://www.bbc.co.uk/news/uk-scotland-south-scotland-49661019)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 12:59:34+00:00

The PM's official spokesman says there is a "proper piece of work" being carried out into the feasibility of the idea.

## Storm Ciara: Man dies after tree falls on car during gales
 - [https://www.bbc.co.uk/news/uk-51439152](https://www.bbc.co.uk/news/uk-51439152)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 11:58:49+00:00

Police say a 58-year-old man died in Hampshire after his car was hit during the storm on Sunday.

## Oscars 2020: The Vanity Fair after party
 - [https://www.bbc.co.uk/news/entertainment-arts-51443499](https://www.bbc.co.uk/news/entertainment-arts-51443499)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 11:35:38+00:00

The BBC's Sophie Long and Colin Paterson spoke to stars at the Vanity Fair Oscar party.

## Irish general election: Second day of counting under way
 - [https://www.bbc.co.uk/news/world-europe-51441410](https://www.bbc.co.uk/news/world-europe-51441410)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 11:34:22+00:00

The left-wing republican party heralds a historic result as it takes 24.5% of first-preference votes.

## Coronavirus: Four more people diagnosed in UK
 - [https://www.bbc.co.uk/news/uk-51442314](https://www.bbc.co.uk/news/uk-51442314)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 11:29:24+00:00

The new cases bring the total number of people diagnosed in the UK to eight, the government says.

## Phillip Schofield: Wife Stephanie supports presenter's 'brave step'
 - [https://www.bbc.co.uk/news/entertainment-arts-51443989](https://www.bbc.co.uk/news/entertainment-arts-51443989)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 11:22:36+00:00

Stephanie Lowe says she loves her husband "as much as ever" following his announcement he is gay.

## Oscars 2020: 10 things we learned
 - [https://www.bbc.co.uk/news/entertainment-arts-51432470](https://www.bbc.co.uk/news/entertainment-arts-51432470)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 10:53:03+00:00

How the Oscars fared for diversity, Brad Pitt gets serious and Cats is laughed at - again.

## Mislabelled MPs criticise media's 'racial bias'
 - [https://www.bbc.co.uk/news/uk-51444119](https://www.bbc.co.uk/news/uk-51444119)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 10:42:58+00:00

Dawn Butler, Marsha de Cordova and Bell Ribeiro-Addy were all wrongly captioned by the media last week.

## Climate assembly considers flying bananas
 - [https://www.bbc.co.uk/news/science-environment-51438317](https://www.bbc.co.uk/news/science-environment-51438317)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 10:28:16+00:00

The UK's climate assembly considers the issues of flying bananas and indoor fleeces.

## Spurs midfielder Alli apologises for coronavirus 'joke'
 - [https://www.bbc.co.uk/sport/football/51441898](https://www.bbc.co.uk/sport/football/51441898)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 10:14:22+00:00

Tottenham's Dele Alli apologises for a social media post in which he joked about the coronavirus outbreak, saying "I let myself down and the club".

## East Kent baby deaths: Four more families come forward
 - [https://www.bbc.co.uk/news/uk-england-kent-51439593](https://www.bbc.co.uk/news/uk-england-kent-51439593)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 08:04:10+00:00

Families say their babies would have survived had East Kent NHS Trust provided better care.

## Parasite: Thrilled Koreans hail historic Oscars 2020 win for Bong Joon-ho
 - [https://www.bbc.co.uk/news/world-asia-51439899](https://www.bbc.co.uk/news/world-asia-51439899)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 08:02:36+00:00

"We should all really break out all the soju and makgeolli to celebrate with Bong," said one.

## Coronavirus claims 97 lives in one day - but number of infections stabilises
 - [https://www.bbc.co.uk/news/world-asia-china-51439450](https://www.bbc.co.uk/news/world-asia-china-51439450)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 07:40:43+00:00

Meanwhile, another 60 people have caught the virus on a quarantined cruise ship in Japan.

## Oscars 2020: 13 looks that caused a stir
 - [https://www.bbc.co.uk/news/entertainment-arts-51439026](https://www.bbc.co.uk/news/entertainment-arts-51439026)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 07:19:59+00:00

The most eye-catching outfits from the red carpet, the ceremony and the after parties.

## Storm Ciara: In pictures
 - [https://www.bbc.co.uk/news/uk-51436720](https://www.bbc.co.uk/news/uk-51436720)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 07:12:55+00:00

Pictures show the effects of Storm Ciara's strong winds and heavy rain in the UK.

## Newspaper review: 'Storm of the century' and virus 'super-spreader'
 - [https://www.bbc.co.uk/news/blogs-the-papers-51438815](https://www.bbc.co.uk/news/blogs-the-papers-51438815)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 06:54:33+00:00

The paper's reflect on Storm Ciara, and a Briton is thought to have infected seven with coronavirus.

## 'Ford was excellent - you would have said he was captain the way he stepped up’
 - [https://www.bbc.co.uk/sport/rugby-union/51435385](https://www.bbc.co.uk/sport/rugby-union/51435385)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 06:26:15+00:00

England fly-half George Ford stepped up as a leader in tough conditions at Murrayfield, says World Cup winner Matt Dawson.

## England U15 and AFC Wimbledon player Leo Castledine takes on football 'Wonderkids' challenge
 - [https://www.bbc.co.uk/sport/av/football/51419890](https://www.bbc.co.uk/sport/av/football/51419890)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 06:25:05+00:00

England Under-15 and AFC Wimbledon player Leo Castledine takes on football 'Wonderkids' challenge.

## Oscars 2020: South Korea's Parasite makes history by winning best picture
 - [https://www.bbc.co.uk/news/entertainment-arts-51440241](https://www.bbc.co.uk/news/entertainment-arts-51440241)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 05:58:34+00:00

Brad Pitt, Renee Zellweger and Joaquin Phoenix are among the other Academy Award winners.

## The best of the ceremony in pictures
 - [https://www.bbc.co.uk/news/in-pictures-51294945](https://www.bbc.co.uk/news/in-pictures-51294945)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 05:55:20+00:00

The ceremony saw history being made as the first non-English language film won the main award.

## World's largest firework set off in Colorado, USA
 - [https://www.bbc.co.uk/news/world-us-canada-51439246](https://www.bbc.co.uk/news/world-us-canada-51439246)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 05:37:14+00:00

It weighed 2,800lbs (1,270kg) and was successfully launched in the US state of Colorado.

## Solar Orbiter: Sun mission blasts off
 - [https://www.bbc.co.uk/news/science-environment-51420402](https://www.bbc.co.uk/news/science-environment-51420402)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 04:57:49+00:00

The European probe will gather some of the most detailed ever pictures and movies of our star.

## A quick look at the looks on the Academy Awards red carpet
 - [https://www.bbc.co.uk/news/entertainment-arts-51440449](https://www.bbc.co.uk/news/entertainment-arts-51440449)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 04:56:11+00:00

All the red carpet action on the film world's biggest night in just 30 seconds

## Sydney weather: Record rainfall and flooding causes chaos
 - [https://www.bbc.co.uk/news/world-australia-51439179](https://www.bbc.co.uk/news/world-australia-51439179)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 03:48:22+00:00

Travel chaos and flooded streets as Australia's biggest city has its wettest few days in 30 years.

## NHS cancer patients 'missing out on basics information'
 - [https://www.bbc.co.uk/news/health-51439146](https://www.bbc.co.uk/news/health-51439146)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 03:37:27+00:00

NHS staff pressures are leaving 120,000 patients a year "in the dark" about their illness, a charity says.

## The winners and nominees in full
 - [https://www.bbc.co.uk/news/entertainment-arts-51093954](https://www.bbc.co.uk/news/entertainment-arts-51093954)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 01:55:41+00:00

Find out who won the golden statuettes at this year's Academy Awards.

## Remarkable journey from refugee to Rhodes scholar
 - [https://www.bbc.co.uk/news/world-us-canada-51420370](https://www.bbc.co.uk/news/world-us-canada-51420370)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 01:01:27+00:00

Getting an education was always a matter of life or death for Summia Tora.

## 'Without suicide forums, Callie might still be alive'
 - [https://www.bbc.co.uk/news/newsbeat-51262240](https://www.bbc.co.uk/news/newsbeat-51262240)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 01:01:17+00:00

The Samaritans have called for suicide forums to be "buried" online in a new Panorama documentary.

## Mental health in Kenya: ‘I was accused of bewitching my husband’
 - [https://www.bbc.co.uk/news/world-africa-51222194](https://www.bbc.co.uk/news/world-africa-51222194)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 00:59:47+00:00

Kenyan Esther Kiama's husband had a bipolar disorder, but his family thought she had cast a spell.

## Labour leadership: A century of ups and downs in charts
 - [https://www.bbc.co.uk/news/uk-politics-51193219](https://www.bbc.co.uk/news/uk-politics-51193219)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 00:57:13+00:00

What 100 years of voting tells us about the scale of the task ahead for a new Labour leader.

## Rio and Kate Ferdinand: 'I was naive about being a stepmum-of-three at 27'
 - [https://www.bbc.co.uk/news/newsbeat-51418020](https://www.bbc.co.uk/news/newsbeat-51418020)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 00:51:15+00:00

The former Manchester United star and his new wife talk about their struggle to adapt to being a step family.

## Norfolk film-makers explore 'heartbreaking' experiences of sexual harassment
 - [https://www.bbc.co.uk/news/uk-england-norfolk-51418260](https://www.bbc.co.uk/news/uk-england-norfolk-51418260)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 00:48:47+00:00

Two women have made a film based on "heartbreaking" real experiences of sexual harassment.

## Breathtaking images from the Landscape Photographer of the Year competition
 - [https://www.bbc.co.uk/news/in-pictures-51386024](https://www.bbc.co.uk/news/in-pictures-51386024)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 00:18:20+00:00

The awe-inspiring images came from 840 photographers from around the world.

## The 200-year-old diary that's rewriting gay history
 - [https://www.bbc.co.uk/news/education-51385884](https://www.bbc.co.uk/news/education-51385884)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 00:05:49+00:00

A Yorkshire farmer's journal from 1810 reveals surprisingly modern views on being gay.

## 'I remember the roaches walking across the floor'
 - [https://www.bbc.co.uk/news/business-51376973](https://www.bbc.co.uk/news/business-51376973)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 00:01:47+00:00

When Rob Bernshteyn and his family escaped the Soviet Union, they initially found the US was worse.

## HS2: Six reasons why the rail route is so expensive
 - [https://www.bbc.co.uk/news/business-51415590](https://www.bbc.co.uk/news/business-51415590)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 00:00:16+00:00

The controversial high-speed rail project could potentially cost as much as £106bn.

## Bank of England gold: Rare look inside the vaults
 - [https://www.bbc.co.uk/news/uk-51416500](https://www.bbc.co.uk/news/uk-51416500)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-02-10 00:00:12+00:00

The BBC's Frank Gardner is shown how £194bn worth of gold bars are stored.

