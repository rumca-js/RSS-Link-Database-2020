# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Samsung Galaxy Z Flip Unboxing: It's Growing on Me!
 - [https://www.youtube.com/watch?v=dPaHNTnN0eE](https://www.youtube.com/watch?v=dPaHNTnN0eE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-02-19 00:00:00+00:00

Unboxing and switching to perhaps the most interesting phone in the world...

Galaxy Z Flip leather case: https://geni.us/6PXHM

MKBHD Merch: http://shop.MKBHD.com

Video Gear I use: http://kit.co/MKBHD/video-gear#recom...
Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Jordyn Edmonds
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

