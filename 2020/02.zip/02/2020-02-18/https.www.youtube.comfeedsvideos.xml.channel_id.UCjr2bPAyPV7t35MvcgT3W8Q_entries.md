# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## Biometric "Security" Is NOT Secure
 - [https://www.youtube.com/watch?v=tJw2Kf1khlA](https://www.youtube.com/watch?v=tJw2Kf1khlA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2020-02-19 00:00:00+00:00

Biometric security is strong and unique. But what happens if somebody steals your faceprint or fingerprint? You are compromised everywhere for the rest of your life.

Support me through Patreon: https://www.patreon.com/thehatedone 

- or donate anonymously:

Monero: 84DYxU8rPzQ88SxQqBF6VBNfPU9c5sjDXfTC1wXkgzWJfVMQ9zjAULL6rd11ASRGpxD1w6jQrMtqAGkkqiid5ef7QDroTPp

Bitcoin: 1HkDxXAVDFhBHSyRjam5WW5uoY88sxn5qz

The whole promise of biometric security stands and falls on how easy it is to replicate and abuse biometric modals. And the short answer is – it’s a cat and mouse game. On the long enough timeline, someone will be able to recreate a copy of your face or fingerprints that works just fine enough to fool authenticating systems. Once your biometric data is compromised, it affects all applications at once and you will be affected for the rest of your life.

Sources (in chronological order):

Entropy https://security.stackexchange.com/questions/144428/how-secure-is-a-fingerprint-sensor-versus-a-standard-password 
Biometric data compromise https://securelist.com/biometric-data-processing-and-storage-system-threats/95364/ 
CCC group tricking Apple Touch ID https://www.ccc.de/en/updates/2013/ccc-breaks-apple-touchid → video https://vimeo.com/75324765 
German minister fingerprint https://www.theguardian.com/technology/2014/dec/30/hacker-fakes-german-ministers-fingerprints-using-photos-of-her-hands 
Kaspersky report https://threatpost.com/threatlist-a-third-of-biometric-systems-targeted-by-malware-in-q3/150778/
Taylor Swift using facial recognition  https://www.nbcnews.com/tech/tech-news/facial-recognition-tech-used-scan-stalkers-taylor-swift-show-report-n947581
Vimeo law suit over facial recognition https://threatpost.com/vimeo-slapped-with-lawsuit-over-biometrics-privacy-policy/148695/
Researchers bypass Apple Face ID https://threatpost.com/researchers-bypass-apple-faceid-using-biometrics-achilles-heel/147109/
Another bypass of Face ID https://www.usenix.org/conference/usenixsecurity16/technical-sessions/presentation/xu 
Android face unlock features suck  https://9to5mac.com/2018/03/23/face-id-premium-android-fingerprint-sensors/ 
U.S. Office of Personnel Management data breach https://www.opm.gov/cybersecurity/cybersecurity-incidents/ 
1 million fingerprints lost in a UK data base https://www.theguardian.com/technology/2019/aug/14/major-breach-found-in-biometrics-system-used-by-banks-uk-police-and-defence-firms 
Airline data breaches https://www.cpomagazine.com/cyber-security/airline-data-breaches-worrying/ 
False rejection and false acceptance https://biometrictoday.com/10-advantages-disadvantages-biometrics-technology/ 
and this: https://protonmail.com/blog/biometric-authentication/
Passwords are better https://securelist.com/biometric-data-processing-and-storage-system-threats/95364/ 
Government can abuse Face ID, Touch ID 
https://www.theguardian.com/commentisfree/2016/feb/26/can-government-force-you-to-unlock-your-phone-fifth-amendment












Credits: Music by CO.AG Music https://www.youtube.com/channel/UCcavSftXHgxLBWwLDm_bNvA


Follow me:
https://twitter.com/The_HatedOne_
https://www.bitchute.com/TheHatedOne/
https://www.reddit.com/r/thehatedone/
https://www.minds.com/The_HatedOne

The footage and images featured in the video were for critical analysis, commentary and parody, which are protected under the Fair Use laws of the United States Copyright act of 1976.

