# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week Extra #2
 - [https://www.youtube.com/watch?v=GJ7QrKPXllM](https://www.youtube.com/watch?v=GJ7QrKPXllM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-02-18 00:00:00+00:00



