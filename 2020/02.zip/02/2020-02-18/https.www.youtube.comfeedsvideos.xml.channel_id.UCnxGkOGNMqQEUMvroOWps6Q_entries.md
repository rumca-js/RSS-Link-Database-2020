# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Brian Greene Shares His Surprising Take on Religion and Science
 - [https://www.youtube.com/watch?v=gpStPNAB7Cw](https://www.youtube.com/watch?v=gpStPNAB7Cw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-19 00:00:00+00:00

Taken from JRE #1428 w/Brian Greene: https://youtu.be/r4wQsmAtZoc

## Brian Greene and Joe Rogan: Consciousness and Psychedelics
 - [https://www.youtube.com/watch?v=JMYi5j7vZ6A](https://www.youtube.com/watch?v=JMYi5j7vZ6A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-19 00:00:00+00:00

Taken from JRE #1428 w/Brian Greene: https://youtu.be/r4wQsmAtZoc

## Brian Greene on How Music Helped Him Write His New Book
 - [https://www.youtube.com/watch?v=8Vo8DKd6gCM](https://www.youtube.com/watch?v=8Vo8DKd6gCM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-19 00:00:00+00:00

Taken from JRE #1428 w/Brian Greene: https://youtu.be/r4wQsmAtZoc

## Brian Greene on Seeing Humanity in the Context of the Cosmos
 - [https://www.youtube.com/watch?v=U6uT-pA3uIk](https://www.youtube.com/watch?v=U6uT-pA3uIk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-19 00:00:00+00:00

Taken from JRE #1428 w/Brian Greene: https://youtu.be/r4wQsmAtZoc

## Brian Greene: Thought Itself Will Come to an End in the Universe
 - [https://www.youtube.com/watch?v=t9mgdl1Gh6g](https://www.youtube.com/watch?v=t9mgdl1Gh6g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-19 00:00:00+00:00

Taken from JRE #1428 w/Brian Greene: https://youtu.be/r4wQsmAtZoc

## Everything in the Universe Will Die One Day w/Brian Greene | Joe Rogan
 - [https://www.youtube.com/watch?v=khvJypQnwqo](https://www.youtube.com/watch?v=khvJypQnwqo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-19 00:00:00+00:00

Taken from JRE #1428 w/Brian Greene:
https://youtu.be/r4wQsmAtZoc

## Physicist Brian Greene Has a Theory on Why Aliens Haven’t Visited Us
 - [https://www.youtube.com/watch?v=BRo3YXCvgPI](https://www.youtube.com/watch?v=BRo3YXCvgPI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-19 00:00:00+00:00

Taken from JRE #1428 w/Brian Greene: https://youtu.be/r4wQsmAtZoc

## Physicist Brian Greene on Ray Kurzweil's Singularity Predictions | Joe Rogan
 - [https://www.youtube.com/watch?v=XfXih6OvcAg](https://www.youtube.com/watch?v=XfXih6OvcAg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-19 00:00:00+00:00

Taken from JRE #1428 w/Brian Greene:
https://youtu.be/r4wQsmAtZoc

## Physicist Brian Greene on What He Learned from a Meditation Class
 - [https://www.youtube.com/watch?v=W_LWqD22ukI](https://www.youtube.com/watch?v=W_LWqD22ukI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-19 00:00:00+00:00

Taken from JRE #1428 w/Brian Greene: https://youtu.be/r4wQsmAtZoc

## What Was Happening Before the Big Bang? w/Brian Greene | Joe Rogan
 - [https://www.youtube.com/watch?v=FHAA_1Guxlo](https://www.youtube.com/watch?v=FHAA_1Guxlo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-19 00:00:00+00:00

Taken from JRE #1428 w/Brian Greene:
https://youtu.be/r4wQsmAtZoc

## Angela Hill Started Training for MMA When She Was 24 Years Old | Joe Rogan
 - [https://www.youtube.com/watch?v=jB74qSaIXdc](https://www.youtube.com/watch?v=jB74qSaIXdc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-18 00:00:00+00:00

Taken from MMA Show #92 w/Angela Hill:
https://youtu.be/yTCgRIA0RYo

## Angela Hill on How Training With Men Can Be Misleading
 - [https://www.youtube.com/watch?v=ahtjJRjdES4](https://www.youtube.com/watch?v=ahtjJRjdES4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-18 00:00:00+00:00

Taken from JRE MMA Show Episode #92 w/Angela Hill: https://youtu.be/yTCgRIA0RYo

## Angela Hill on Weili Zhang vs. Joanna Jedrzejczyk
 - [https://www.youtube.com/watch?v=2UwPdgJf0H0](https://www.youtube.com/watch?v=2UwPdgJf0H0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-18 00:00:00+00:00

Taken from JRE MMA Show Episode #92 w/Angela Hill: https://youtu.be/yTCgRIA0RYo

## Angela Hill: Tecia Torres Hustled Me!
 - [https://www.youtube.com/watch?v=cInCJpHFMAs](https://www.youtube.com/watch?v=cInCJpHFMAs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-18 00:00:00+00:00

Taken from JRE MMA Show Episode #92 w/Angela Hill: https://youtu.be/yTCgRIA0RYo

## Are These “Painting Elephants” Being Abused?
 - [https://www.youtube.com/watch?v=Yw-CoJKE92A](https://www.youtube.com/watch?v=Yw-CoJKE92A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-18 00:00:00+00:00

Taken from JRE MMA Show Episode #92 w/Angela Hill: https://youtu.be/yTCgRIA0RYo

## Joe Rogan On What’s Really Depressing About a Wolf Sanctuary
 - [https://www.youtube.com/watch?v=qidJCJXIT4o](https://www.youtube.com/watch?v=qidJCJXIT4o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-18 00:00:00+00:00

Taken from JRE MMA Show Episode #92 w/Angela Hill: https://youtu.be/yTCgRIA0RYo

## Joe Rogan: Valentina Shevchenko is Scary!
 - [https://www.youtube.com/watch?v=VF0UD0GKivs](https://www.youtube.com/watch?v=VF0UD0GKivs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-18 00:00:00+00:00

Taken from JRE MMA Show Episode #92 w/Angela Hill: https://youtu.be/yTCgRIA0RYo

## The Fight That Made Angela Hill Consider Her Mental Game
 - [https://www.youtube.com/watch?v=oNPNW1XxUqs](https://www.youtube.com/watch?v=oNPNW1XxUqs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-18 00:00:00+00:00

Taken from JRE MMA Show Episode #92 w/Angela Hill: https://youtu.be/yTCgRIA0RYo

## The Potential Benefits of a Fighters Union w/Angela Hill | Joe Rogan
 - [https://www.youtube.com/watch?v=lA4-fmqfMjs](https://www.youtube.com/watch?v=lA4-fmqfMjs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-02-18 00:00:00+00:00

Taken from MMA Show #92 w/Angela Hill:
https://youtu.be/yTCgRIA0RYo

