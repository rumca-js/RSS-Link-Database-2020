# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Good Books & Bad Candidates
 - [https://www.youtube.com/watch?v=bwLNlSHS_KI](https://www.youtube.com/watch?v=bwLNlSHS_KI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-02-19 00:00:00+00:00

This is the Babylon Bee weekly news podcast for the week of 2/19/2020. 

 In this episode of The Babylon Bee podcast, editor-in-chief Kyle Mann and creative director Ethan Nicolle discuss the week’s big stories such as the collapse of the Yang campaign, the bipartisan aversion toward the ascendent Bloomberg, and how the 56k modem sound makes us salivate for the internet. The guys then discuss the books that made an impact upon them which means C.S. Lewis, G.K. Chesterton, and J.R.R. Tolkien all feature heavily.  Kyle also tells you which overrated books shouldn’t be considered literary classics. 

 In the subscriber portion, Kyle and Ethan talk more books, feuding Star Wars clubs in high school, and how Paw Patrol is dismantling the State.

  Pre-order the new Babylon Bee Best-Of Coffee Table Book coming in 2020!

 Show Outline

 Introduction - Kyle and Ethan talk about the origin of “This ain’t it, chief,” talk about all the great feedback we got from the Valentine’s episode featuring the Bee wives, and then dive into the week’s top stories.

 Story 1 -  Yang Campaign Collapses After It's Revealed $1,000/Mo Giveaway Would Be Paid For With $1,000/Mo Tax Increase

   Yang suspended Presidential campaign aspirations after poor showings in Iowa and New Hampshire

    NEWSWEEK: 72 percent of Democratic primary voters plan on voting for the party's nominee even if their first choice doesn't prevail in the primaries.

   But only about half of both Sanders and Yang's supporters agreed that they would support any second choice.

   Story 2 -  Bloomberg Stops By Daytona 500 To Hand Out Speeding Tickets

   Donald Trump did a  flyover of the Daytona 500 in Air Force One

   Did a pace lap in “The Beast”- the presidential limo

   NASCAR fans seems to love it, blue checks and media types rushed out their hot takes labeling it as problematic

   Story 3 -  Struggling Biden Campaign Now Offering One Month Of Free AOL For Rally Attendance (Babylon Bee Subscriber Phil VanKlinken contributed to this report)

   Support for Joe Biden in Iowa and New Hampshire didn’t materialize and if he doesn’t pull out a win in South Carolina, he is basically done. His numbers there are  under strain too.

   Topic of the Week -  Novels or non-fiction books that made us the men we are now. In this special topic the guys are just talkin’ about books! 

   The Hobbit/ Lord of The Rings by J.R.R. Tolkien

   Moby Dick by Herman Melville

   Mere Christianity/ Screwtape Letters by C.S. Lewis

   Heretics/ Orthodoxy/ In Defense of Sanity/ The Ball and the Cross by G.K. Chesterton

   Pilgrim’s Progress by John Bunyan

   Misery/ Dark Tower/ The Shining and other Stephen King novels

   David Copperfield by Charles Dickens

   Do Androids Dream Of Electric Sheep

   Dune by Frank Herbert

   H.P Lovecraft books

   1984/ Animal Farm by George Orwell

   The BFG and other books by Roald Dahl

   Love Mail/Hate Mail - We received one of the most touching love mails ever and we got a short hate mail that we have Dave DeAndrea dramatically read.

 Paid-subscriber portion (Starts at 01:08:27)

 Kyle and Ethan talk even more books and Kyle tells a crazy story about the Star Wars clubs at school going all Westside Story. 

 Story 1 -  In New Paw Patrol Episode, Pups Round Up Commies Around Adventure Bay

    Leftist prof says Paw Patrol is propaganda for "capitalist system that (re)produces inequalities and causes environmental harms"

   "I'll start with the depiction of the state. Mayor Humdinger and Mayor Goodway — kind of the representatives of the state or the government — are portrayed negatively. Mayor Humdinger is portrayed as unethical or corrupt. Mayor Goodway as hysterical, bumbling, incompetent."

   "I would argue that the Paw Patrol, as a private corporation, is used to help provide basic social services in the Adventure Bay community. That's problematic in that the Paw Patrol creators are sending this message that we can't depend on the state to provide these services."

   Story 2 -  New Political Bible Adds (R) Or (D) After Each Character's Name

 Become a paid subscriber at https://babylonbee.com/plans

