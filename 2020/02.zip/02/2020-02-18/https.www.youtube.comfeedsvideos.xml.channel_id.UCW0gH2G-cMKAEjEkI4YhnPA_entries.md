# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Elrond & Elros in the First Age | Tolkien Explained
 - [https://www.youtube.com/watch?v=9lPIRf0Nsn4](https://www.youtube.com/watch?v=9lPIRf0Nsn4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2020-02-18 00:00:00+00:00

Twin brothers Elrond and Elros, born in the late first age, grew up during a tumultuous time in Middle-earth.  Check out this recap of their time in the first age before next week's episode where we will look at Elrond's life and childhood during the first age.

Hit subscribe - and the bell - so you never miss a video from Nerd of the Rings!

--------------
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.

If your artwork is used and not credited, please let me know and I will make sure it gets added!
Caranthir - dalomacchi
Celegorm - kaprriss
Ulmo and Tuor - Daniel Pilla
Earendil and Elwing - steamey
Elwing - ekukanova
Amrod and Amras - Jenny Dolfen
Earendil the Mariner - Jenny Dolfen
Maglor - kaprriss
Earendil the Mariner - Ted Nasmith
Maglor's Fostering - Turner Mohan
Little Half-Elf - Tuuliky

#lordoftherings #silmarillion #tolkien

