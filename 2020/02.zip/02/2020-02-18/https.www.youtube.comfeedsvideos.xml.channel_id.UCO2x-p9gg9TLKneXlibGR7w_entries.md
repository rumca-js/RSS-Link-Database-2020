# Source:Snazzy Labs, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w, language:en-US

## Amazing Mac Tips You've Never Used!
 - [https://www.youtube.com/watch?v=HPQobUOx17o](https://www.youtube.com/watch?v=HPQobUOx17o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w
 - date published: 2020-02-18 00:00:00+00:00

Subscribe to my new podcast Flashback - http://relay.fm/flashback
Snazzy Labs shows you the last Mac Tips video for a while. Experts and noobs alike can learn from this jam-packed video!

Follow me on Twitter - http://twitter.com/snazzyq
Follow me on Instagram - http://instagram.com/snazzyq

Snazzy Labs shows some great tips and tricks for macOS Catalina (and prior versions of Mac OS) in this Mac OS X tips video. Keyboard shortcuts, navigation gestures, window management, assistive browser features, and more! Just because we're out of Mac Tips doesn't mean this isn't going to be the last mac video forever. Expect future videos on my favorite apps and modifications you can make to macOS to meet your workflow needs.



Thumbnail template courtesy of - https://www.anthonyboyd.graphics/mockups/2017-macbook-pro-on-desk-mockup/

