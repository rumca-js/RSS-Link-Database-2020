# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Joe Rogan Experience #1428 - Brian Greene
 - [https://www.youtube.com/watch?v=r4wQsmAtZoc](https://www.youtube.com/watch?v=r4wQsmAtZoc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2020-02-19 00:00:00+00:00

Brian Greene is a theoretical physicist, mathematician, and string theorist. He has been a professor at Columbia University since 1996 and chairman of the World Science Festival since co-founding it in 2008. His new book "Until the End of Time" is now available: https://amzn.to/2ug680o

