# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## DakhaBrakha - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=kuAaIe1QDSc](https://www.youtube.com/watch?v=kuAaIe1QDSc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-19 00:00:00+00:00

http://KEXP.ORG presents DakhaBrakha performing live at the Triple Door. Recorded October 15, 2019.

Songs:
Khyma
I've Boarded The Wrong Plane (Rembetika)
Plyve choven
Lado

Host: Darek Mazzone
Audio Engineer: Curt Nelson
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen, Kendall Rock & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
http://www.dakhabrakha.com.ua

## DakhaBrakha - I've Boarded The Wrong Plane (Rembetika) (Live on KEXP)
 - [https://www.youtube.com/watch?v=N0cp--Hhkws](https://www.youtube.com/watch?v=N0cp--Hhkws)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-19 00:00:00+00:00

http://KEXP.ORG presents DakhaBrakha performing "I've Boarded The Wrong Plane (Rembetika)" live at the Triple Door. Recorded October 15, 2019.

Host: Darek Mazzone
Audio Engineer: Curt Nelson
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen, Kendall Rock & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
http://www.dakhabrakha.com.ua

## DakhaBrakha - Khyma (Live on KEXP)
 - [https://www.youtube.com/watch?v=H7cpHodEp1k](https://www.youtube.com/watch?v=H7cpHodEp1k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-19 00:00:00+00:00

http://KEXP.ORG presents DakhaBrakha performing "Khyma" live at the Triple Door. Recorded October 15, 2019.

Host: Darek Mazzone
Audio Engineer: Curt Nelson
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen, Kendall Rock & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
http://www.dakhabrakha.com.ua

## DakhaBrakha - Lado (Live on KEXP)
 - [https://www.youtube.com/watch?v=2zYCBhokaDk](https://www.youtube.com/watch?v=2zYCBhokaDk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-19 00:00:00+00:00

http://KEXP.ORG presents DakhaBrakha performing "Lado" live at the Triple Door. Recorded October 15, 2019.

Host: Darek Mazzone
Audio Engineer: Curt Nelson
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen, Kendall Rock & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
http://www.dakhabrakha.com.ua

## DakhaBrakha - Plyve choven (Live on KEXP)
 - [https://www.youtube.com/watch?v=J2vBp2mRnDk](https://www.youtube.com/watch?v=J2vBp2mRnDk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-19 00:00:00+00:00

http://KEXP.ORG presents DakhaBrakha performing "Plyve choven" live at the Triple Door. Recorded October 15, 2019.

Host: Darek Mazzone
Audio Engineer: Curt Nelson
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen, Kendall Rock & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
http://www.dakhabrakha.com.ua

## Grísalappalísa -  Keyri heim á Þorláksmessu (Live on KEXP)
 - [https://www.youtube.com/watch?v=avaaK8lgLbU](https://www.youtube.com/watch?v=avaaK8lgLbU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-18 00:00:00+00:00

http://KEXP.ORG presents BAND performing "Keyri heim á Þorláksmessu" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 8, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director & Editor: Scott Holpainen

http://kexp.org
http://www.grisalappalisa.com

## Grísalappalísa - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=6nZVAlNF4mg](https://www.youtube.com/watch?v=6nZVAlNF4mg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-18 00:00:00+00:00

http://KEXP.ORG presents BAND performing live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 8, 2019.

Songs:
Keyri heim á Þorláksmessu
Þrjúhundruðsextíuogfimmdagablús sjáðu hjónin
Í fýlu
Kraut í G
Meðaljón
Flýja

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director & Editor: Scott Holpainen

http://kexp.org
http://www.grisalappalisa.com

## Grísalappalísa - Í fýlu (Live on KEXP)
 - [https://www.youtube.com/watch?v=MNXz3xafGGM](https://www.youtube.com/watch?v=MNXz3xafGGM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-18 00:00:00+00:00

http://KEXP.ORG presents BAND performing "Í fýlu" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 8, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director & Editor: Scott Holpainen

http://kexp.org
http://www.grisalappalisa.com

## Grísalappalísa - Kraut í G (Live on KEXP)
 - [https://www.youtube.com/watch?v=qBKCOhhINww](https://www.youtube.com/watch?v=qBKCOhhINww)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-18 00:00:00+00:00

http://KEXP.ORG presents BAND performing "Kraut í G" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 8, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director & Editor: Scott Holpainen

http://kexp.org
http://www.grisalappalisa.com

## Grísalappalísa - Þrjúhundruðsextíuogfimmdagablús sjáðu hjónin (Live on KEXP)
 - [https://www.youtube.com/watch?v=mXPN_SlRkEc](https://www.youtube.com/watch?v=mXPN_SlRkEc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-02-18 00:00:00+00:00

http://KEXP.ORG presents BAND performing "Þrjúhundruðsextíuogfimmdagablús sjáðu hjónin" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 8, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer:  Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director & Editor: Scott Holpainen

http://kexp.org
http://www.grisalappalisa.com

