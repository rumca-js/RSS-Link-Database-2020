# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## Are We Running Out Of Food??
 - [https://www.youtube.com/watch?v=0HdMtR5AkQ8](https://www.youtube.com/watch?v=0HdMtR5AkQ8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2020-02-19 00:00:00+00:00

PBS Member Stations rely on viewers like you. To support your local station, go to: http://to.pbs.org/DonateOKAY
↓ More info and sources below ↓

Thanks to Bill and Melinda Gates for sponsoring today's video. Check out their Annual Letter here: http://www.inflcr.co/SH1jP
We’re on PATREON now! Join the community ►► https://www.patreon.com/itsokaytobesmart

If you tried to sum up the last 150 years or so in one image, a chart of exponential growth would be a good place to start. It shows that some things change faster over time. You could apply it to life expectancy. Or compound interest. Or any number of things. But especially population growth. Back in 1798, a guy named Thomas Malthus noticed that not everything grows this way. And this caused people to worry because they were sure it would lead to massive death and starvation and famine. But that didn’t happen, thanks to something called the Green Revolution and a guy named Norman Borlaug. As we face a future population of ten billion and a world impacted by climate change, how will we do a Green Revolution 2.0? #GatesPartner 

References: https://sites.google.com/view/cansciencefeed10billionpeople/home 

Special thanks to our Brain Trust Patrons:
AlecZero
Bob Rosset
Brent M.
Diego Lombeida
Ron Kakar
vincbis

-----------
Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/

