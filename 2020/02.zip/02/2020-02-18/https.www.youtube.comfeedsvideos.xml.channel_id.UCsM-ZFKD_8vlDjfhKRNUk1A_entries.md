# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Karaś/Rogucki - Katrina - live MUZO.FM
 - [https://www.youtube.com/watch?v=DGb11n3D3pk](https://www.youtube.com/watch?v=DGb11n3D3pk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-02-18 00:00:00+00:00

Karaś/Rogucki - Katrina na żywo w MUZO.FM. Piosenka Katrina pochodzi z płyty duetu Karaś/Rogucki Ostatni bastion romantyzmu. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Karaś/Rogucki: http://www.facebook.com/karasrogucki
Instagram Karaś/Rogucki: http://www.instagram.com/karasrogucki
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm

Karaś/Rogucki Katrina - tekst 

Z głowy wycieka mi chmura
Kształtuje się wyż atlantycki
Nie odzyskacie kontroli
Huragan Katrina, Katrina, Katrina, Katrina

To miasto nie jest gotowe
Na serię kolejnych zamachów
Ogłaszam stan wyjątkowy
Bez gwarantowanej strefy bezpieczeństwa 
Katrina

Katrina, Katrina, Katrina, Katrina 
Ja ciągle wołam cię pod wiatr 
Katrina, Katrina, Katrina Katrina 
Jutro się kończy świat

Chciałbym coś wreszcie poczuć 
Do skóry do kości do kosteczek
Do ości, do osteczek, do chrząstek 
Chciałbym poczuć ciebie

Katrina, Katrina, Katrina, Katrina 
Ja ciągle wołam cię pod wiatr 
Katrina, Katrina, Katrina, Katrina 
Jutro się kończy świat 

#popolsku

