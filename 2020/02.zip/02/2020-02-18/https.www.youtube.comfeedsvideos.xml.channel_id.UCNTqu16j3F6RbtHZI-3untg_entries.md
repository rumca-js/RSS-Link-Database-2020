# Source:Glink, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNTqu16j3F6RbtHZI-3untg, language:en-US

## Games Done Quick: Banned Into Submission
 - [https://www.youtube.com/watch?v=OclBKRQvwCQ](https://www.youtube.com/watch?v=OclBKRQvwCQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNTqu16j3F6RbtHZI-3untg
 - date published: 2020-02-19 00:00:00+00:00

SEIZURE WARNING AT 29:16 BE WARNED

CORRECTIONS: 

-Its "Luz-Bellheim" not "Lulz-Bellheim"

-The picture provided to represent the player Graviton is not actually him, but another player who is friends with R White Goose. This error arose from Graviton being a player with less information online and thus I assumed the person who showed up on google image results with his name in the search bar was him.

-The "vox" political party might hold extreme views (I'm not entirely familiar), but Luz also stated that he only supported their economic policies

-No, I didn't misspeak, GDQ DID raise a whopping $300,000,000 and ended up curing cancer.

Revisiting the controversial climate surrounding Games Done Quick, this time with a little help from my speedrunning friends. Cheese, SHiFT, and Bonesaw all helped contribute to this video by sharing their thoughts with me in eye-opening interviews. I discovered gaming, perfectionism, social isolation, and mental health, and children's card games all play a prominent role within the speedrunning community.

Bonesaw577's channel:
https://www.youtube.com/channel/UChCdy_9rqr8chm_hSDog5yA

Cheese's channel:
https://www.youtube.com/channel/UClvMduw1MDMQ0PuH753-X

SHiFT's channel:
https://www.youtube.com/channel/UC9Y0uUKJ5y78QbhHbntAyFQ

TriHex's channel:
https://www.youtube.com/user/trihex


My stuff:
PATREON - https://www.patreon.com/Glink 
Twitter - https://twitter.com/GlinkLive
Reddit - https://www.reddit.com/r/glink/
Instagram - https://www.instagram.com/glink_between_worlds/
Discord - https://discord.gg/AMMpS5c

