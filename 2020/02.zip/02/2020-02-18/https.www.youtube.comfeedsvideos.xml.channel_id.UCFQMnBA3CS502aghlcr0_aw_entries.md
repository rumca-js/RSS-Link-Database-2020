# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Health scams be like....
 - [https://www.youtube.com/watch?v=VZM_7QVPrNI](https://www.youtube.com/watch?v=VZM_7QVPrNI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-02-18 00:00:00+00:00

"mind controlling micro bugs are causing your farts not to work because the FBI won't let you buy our $49.95 probiotic."

*i'm sorry in advance for this one.*

## I was HOMELESS for 2 hours...
 - [https://www.youtube.com/watch?v=drsnMed40nw](https://www.youtube.com/watch?v=drsnMed40nw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-02-18 00:00:00+00:00

hoomanTV taught me being homeless pays off. So I tried it and discovered a fictional backstory is far more interesting than a real one.

