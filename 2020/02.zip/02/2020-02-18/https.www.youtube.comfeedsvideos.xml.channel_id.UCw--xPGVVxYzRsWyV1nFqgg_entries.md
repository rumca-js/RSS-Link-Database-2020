# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## White Night - DRESDEN REVIEW
 - [https://www.youtube.com/watch?v=LE2FysTbXkI](https://www.youtube.com/watch?v=LE2FysTbXkI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-02-19 00:00:00+00:00

My review of White Night by Jim Butcher. Another review into the Dresden Files series. 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## NEW FIRST LAW UPDATE, MARK HAMILL WITCHER OFFER, MAGIC THE GATHERING DOC - FANTASY NEWS
 - [https://www.youtube.com/watch?v=gboQIfiN59k](https://www.youtube.com/watch?v=gboQIfiN59k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-02-18 00:00:00+00:00

Welcome to another installment of FANTASY NEWS! 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene
 
NEWS:

FANTASY AWARDS: https://www.youtube.com/watch?v=SXVjNPjWRIc&t=774s

Ember 4: https://twitter.com/sabaatahir/status/1228508654544080896?s=19

Magic The Gathering Doc: https://www.polygon.com/2020/2/14/21138231/magic-the-gathering-documentary-igniting-the-spark-toys-that-made-us

Masters of the Universe: https://www.hollywoodreporter.com/live-feed/kevin-smiths-masters-universe-netflix-series-lands-all-star-voice-cast-1279455

Mandalorian Cover: https://www.empireonline.com/movies/news/empire-s-the-mandalorian-covers-revealed/

#UnchartedMovie: https://collider.com/tom-holland-uncharted-movie-story/

Inheritance New Covers: https://twitter.com/orbitbooks/status/1228363525514498048?s=12

#StrangerThings 4: https://www.youtube.com/watch?v=Qhrb1VaFpBM

Green Lantern Anniversary: https://screenrant.com/green-lantern-dc-comics-anniversary-special/

Castlevania Season 3: https://www.youtube.com/watch?v=cYNGDUIBUhE&feature=youtu.be

Mark Hamill Witcher: https://wegotthiscovered.com/tv/netflix-offered-mark-hamill-role-vesemir-witcher-season-2/

Blizzard Adaptation Rumors: https://www.engadget.com/2020/02/17/rumors-resurface-diablo-overwatch-animated-series/

