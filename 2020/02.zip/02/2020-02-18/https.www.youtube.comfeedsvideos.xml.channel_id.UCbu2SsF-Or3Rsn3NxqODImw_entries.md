# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Someone Remade Silent Hills' P.T. in Dreams
 - [https://www.youtube.com/watch?v=PtjMEd-6Xos](https://www.youtube.com/watch?v=PtjMEd-6Xos)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-02-19 00:00:00+00:00

User Lewisc729 has continued to legacy of P.T. in Dreams and we're going to give it a whirl! You can find this level at the following link or from your Dream Surfing Dashboard in the game! Link: https://indreams.me/dream/mJoFhTBRwJa

