# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Star Trek Picard - Episode 4 Review
 - [https://www.youtube.com/watch?v=MHLYtcgZGpg](https://www.youtube.com/watch?v=MHLYtcgZGpg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-02-19 00:00:00+00:00

Grab your beers and dump your warp cores, because we're boldly going once more into the world of Star Trek Picard, this time to review Episode 4 - Absolute Candour.

