# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 MORE Video Game Levels We All Got LOST IN
 - [https://www.youtube.com/watch?v=709V3DdMoYk](https://www.youtube.com/watch?v=709V3DdMoYk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-02-19 00:00:00+00:00

Sometimes you just can't help but get lost in a video game level: sometimes for good reasons, sometimes for bad ones. Here are our some wild levels.
Subscribe for more: http://youtube.com/gameranxtv
Earlier video: https://www.youtube.com/watch?v=I8HOXlLleK0

## 7 Gamer Problems - THEN VS NOW
 - [https://www.youtube.com/watch?v=bI3uZlAoxak](https://www.youtube.com/watch?v=bI3uZlAoxak)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-02-19 00:00:00+00:00

Video games...have changed. Here's some stuff we experienced during the classic gaming days that are totally different today in 2020.
Subscribe for more: http://youtube.com/gameranxtv

## Top 20 NEW Switch Games of 2020
 - [https://www.youtube.com/watch?v=HFQ6n1A9t0g](https://www.youtube.com/watch?v=HFQ6n1A9t0g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-02-18 00:00:00+00:00

2020 is filled with Nintendo Switch games to look forward to. Here are our most anticipated, from open world, to FPS, and everything in-between.
Subscribe for more: http://youtube.com/gameranxtv

20 Deadly Premonition 2: A Blessing in Disguise

Platform: Switch

Release Date: TBA 2020



19 Röki

Platform: PC, Switch

Release Date: TBA 2020



18 Darksiders Genesis

Platform: Switch PS4 Xbox One

Release Date: 14 February 2020



17 Super Meat Boy Forever

Platform: Switch PC PS4 Xbox One Linux

Release Date: 2020



16 Trials of Mana

Platform: Switch PC

Release Date: April 24, 2020



15 The Outer Worlds

Platform: Switch

Release Date: TBA 2020



14 Baldo

Platform: Switch PC PS4 Xbox One

Release Date: TBA 2020



13 Hollow Knight: Silksong

Platform: Switch PC Linux 

Release Date: TBA 2020



12 Lego Star Wars: The Skywalker Saga

Platform: Switch PC PS4 Xbox One

Release Date: TBA 2020



11 Bravely Default II

Platform: Switch

Release Date: TBA 2020



10 Overwatch 2

Platform: Switch PC PS4 Xbox One

Release Date: TBA 2020



9 Gods & Monsters

Platform: Switch PC PS4 Xbox One

Release Date: TBA 2020



8 Axiom Verge 2

Platform: Switch

Release Date: Q3 2020



7 Streets of Rage 4

Platform: Switch PC PS4 Xbox One

Release Date: TBA 2020



6 Pokemon Mystery Dungeon: Rescue Team DX

Platform: Switch 

Release Date: March 6, 2020



5 No More Heroes 3

Platform: Switch 

Release Date: 2020



4 DOOM ETERNAL

Platform: Switch, PC, PS4, XBOX ONE

Release Date: 2020



3 Bayonetta 3

Platform: Switch 

Release Date: TBA 2020



2 Animal Crossing: New Horizons

Platform: Switch

Release Date: March 20, 2020



1 Legend of Zelda: Breath of the Wild sequel

Platform: Switch

Release Date: TBA 2020





BONUS

DOOM 64

Platform: Switch PC PS4 Xbox One

Release Date: March 20, 2020



Pokémon Sword and Shield Expansion

Platform: Switch 

Release Date: TBA 2020

