# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Heart Bones - Don't Read the Comments (Live at The Current)
 - [https://www.youtube.com/watch?v=-3_spj8hZ-o](https://www.youtube.com/watch?v=-3_spj8hZ-o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-02-19 00:00:00+00:00

Watch Heart Bones perform 'Don't Read the Comments' from their album, 'Hot Dish,' live in The Current studio.
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Heart Bones - I Like Your Way (Live at The Current)
 - [https://www.youtube.com/watch?v=-siBui55z2M](https://www.youtube.com/watch?v=-siBui55z2M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-02-19 00:00:00+00:00

Watch Heart Bones perform 'I Like Your Way' from their album, 'Hot Dish,' live in The Current studio.
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Heart Bones - Open Relations (Live at The Current)
 - [https://www.youtube.com/watch?v=80RzMmNf1U4](https://www.youtube.com/watch?v=80RzMmNf1U4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-02-19 00:00:00+00:00

Watch Heart Bones perform 'Open Relations' from their album, 'Hot Dish,' live in The Current studio.
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Half Moon Run - Jello On My Mind (Live at The Current)
 - [https://www.youtube.com/watch?v=7ZP7rqYTGko](https://www.youtube.com/watch?v=7ZP7rqYTGko)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-02-18 00:00:00+00:00

Half Moon Run perform 'Jello On My Mind' from their 2019 album, 'A Blemish in the Great Light,' live in The Current studio.
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

