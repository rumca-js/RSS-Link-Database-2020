# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Miedź, czy nie mieć? Słów kilka o Konfederacji
 - [https://www.youtube.com/watch?v=G5ohxkftOWY](https://www.youtube.com/watch?v=G5ohxkftOWY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2020-02-18 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
-------------------------------------------------------------
👀 Mroczne Podcasty: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
👀 Tatusiek: http://bit.ly/3aSCheE
-------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
-------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
-------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
-------------------------------------------------------------
💲 wsparcie
💰 http://bit.ly/2ETKSyN
-------------------------------------------------------------
✅źródła:
Link 1:                   http://bit.ly/39DSh2Z
Link 2:                   http://bit.ly/2V6iiUr
Link 3:                   http://bit.ly/38La7kE
Link 4:                   http://bit.ly/2V445Y4
Link 5:                   http://bit.ly/39I6E6j
Link 6:                   http://bit.ly/31VmkAv
Link 7:                   http://bit.ly/2SCCR9i
Link 8:                   http://bit.ly/2V2ydDm
Link 9:                   http://bit.ly/2P4ThVL
Link 10:                   
-------------------------------------------------------------
🖼Grafika: 
machines4u.com.au
http://bit.ly/2sTzMaC
---
shutterstock.com
https://shutr.bz/2EiYzHl
---
wikipedia.com / Adrian Grycuk (CC BY-SA 4.0)
http://bit.ly/3bLaPA1
http://bit.ly/327FMu3
-------------------------------------------------------------
💡 Tagi: #miedź #konfederacja
-------------------------------------------------------------

## Trójmorze pod patronatem USA i Niemiec
 - [https://www.youtube.com/watch?v=vwrOUE5-JUw](https://www.youtube.com/watch?v=vwrOUE5-JUw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2020-02-18 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
-------------------------------------------------------------
👀 Mroczne Podcasty: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
👀 Tatusiek: http://bit.ly/3aSCheE
-------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
-------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
-------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
-------------------------------------------------------------
💲 wsparcie
💰 http://bit.ly/2ETKSyN
-------------------------------------------------------------
✅źródła:
Link 1:                   http://bit.ly/2Pi0nqn
Link 2:                   http://bit.ly/2SElghv
Link 3:                   http://bit.ly/3bJoJTj
Link 4:                   http://bit.ly/2HtF0hg
Link 5:                   http://bit.ly/39Jfxg4
Link 6:                   http://bit.ly/2wlb44A
Link 7:                   http://bit.ly/37BCksC
Link 8:                   http://bit.ly/2SW2ZLt
-------------------------------------------------------------
🖼Grafika: 
youtube.com / KREATOR.film - http://bit.ly/38Cp9ci
-------------------------------------------------------------
💡 Tagi: #trójmorze #geopolityka
-------------------------------------------------------------

