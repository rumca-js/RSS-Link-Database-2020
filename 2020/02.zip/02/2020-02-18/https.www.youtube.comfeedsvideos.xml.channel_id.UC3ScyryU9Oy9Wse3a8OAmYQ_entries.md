# Source:FRONTLINE PBS | Official, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ, language:en-US

## Amazon Empire: Andy Jassy Interview | FRONTLINE
 - [https://www.youtube.com/watch?v=NUSFU8RRztI](https://www.youtube.com/watch?v=NUSFU8RRztI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ
 - date published: 2020-02-19 00:00:00+00:00

Amazon Web Services CEO Andy Jassy told FRONTLINE, “We don’t have a large number of police departments that are using our facial recognition technology.” He defended the company’s controversial sale of the tech to law enforcement saying, “We’ve never received any complaints of misuse. Let’s see if somehow they abuse the technology.”
 
Subscribe on YouTube: http://bit.ly/1BycsJW

#Amazon #FrontlinePBS #FacialRecognition

This excerpt is from an interview conducted for FRONTLINE’s documentary “Amazon Empire,” which examines how founder and CEO Jeff Bezos turned Amazon into a business empire that is unprecedented in the history of American capitalism.

For the full story, watch "Amazon Empire: The Rise and Reign of Jeff Bezos" starting Tuesday, Feb. 18 at 9/8c on PBS and online: https://to.pbs.org/2SH9uSj

Instagram: https://www.instagram.com/frontlinepbs
Twitter: https://twitter.com/frontlinepbs
Facebook: https://www.facebook.com/frontline

FRONTLINE is streaming more than 200 documentaries online, for free, here: https://to.pbs.org/37lhSw0

Funding for FRONTLINE is provided through the support of PBS viewers and by the Corporation for Public Broadcasting. Major funding for FRONTLINE is provided by the John D. and Catherine T. MacArthur Foundation and the Ford Foundation. Additional funding is provided by the Abrams Foundation, the Park Foundation, The John and Helen Glessner Family Trust, the Heising-Simons Foundation, and the FRONTLINE Journalism Fund with major support from Jon and Jo Ann Hagler on behalf of the Jon L. Hagler Foundation.

## Amazon Empire: Anima Anandkumar Interview | FRONTLINE
 - [https://www.youtube.com/watch?v=NlJSDa_zLiQ](https://www.youtube.com/watch?v=NlJSDa_zLiQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ
 - date published: 2020-02-19 00:00:00+00:00

“I signed the letter asking Amazon to stop selling face recognition and related software to law enforcement,” former principal scientist at Amazon Web Services Anima Anandkumar told FRONTLINE. In this excerpt, she explains why she felt the need to do so.

Subscribe on YouTube: http://bit.ly/1BycsJW

#Amazon #FrontlinePBS #FacialRecognition

This excerpt is from an interview conducted for FRONTLINE’s documentary “Amazon Empire,” which examines how founder and CEO Jeff Bezos turned Amazon into a business empire that is unprecedented in the history of American capitalism.

For the full story, watch "Amazon Empire: The Rise and Reign of Jeff Bezos" starting Tuesday, Feb. 18 at 9/8c on PBS and online: https://to.pbs.org/2SH9uSj

Instagram: https://www.instagram.com/frontlinepbs
Twitter: https://twitter.com/frontlinepbs
Facebook: https://www.facebook.com/frontline

FRONTLINE is streaming more than 200 documentaries online, for free, here: https://to.pbs.org/37lhSw0

Funding for FRONTLINE is provided through the support of PBS viewers and by the Corporation for Public Broadcasting. Major funding for FRONTLINE is provided by the John D. and Catherine T. MacArthur Foundation and the Ford Foundation. Additional funding is provided by the Abrams Foundation, the Park Foundation, The John and Helen Glessner Family Trust, the Heising-Simons Foundation, and the FRONTLINE Journalism Fund with major support from Jon and Jo Ann Hagler on behalf of the Jon L. Hagler Foundation.

## Amazon Empire: Ardine Williams Interview | FRONTLINE
 - [https://www.youtube.com/watch?v=fLxekKsCZro](https://www.youtube.com/watch?v=fLxekKsCZro)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ
 - date published: 2020-02-19 00:00:00+00:00

Ardine Williams, vice president of workforce development for HQ2 at Amazon, told FRONTLINE, “We employ about 750,000 people around the world, and at our larger sites like Seattle, about half of our population are tech.” With a projected 400,000 people qualified for STEM jobs, and 1.4 million STEM job openings, she said “it means that we are working to recruit from a limited pool of qualified people.”
 
Subscribe on YouTube: http://bit.ly/1BycsJW

#Amazon #FrontlinePBS #techjobs

This excerpt is from an interview conducted for FRONTLINE’s documentary “Amazon Empire,” which examines how founder and CEO Jeff Bezos turned Amazon into a business empire that is unprecedented in the history of American capitalism.

For the full story, watch "Amazon Empire: The Rise and Reign of Jeff Bezos" starting Tuesday, Feb. 18 at 9/8c on PBS and online: https://to.pbs.org/2SH9uSj

Instagram: https://www.instagram.com/frontlinepbs
Twitter: https://twitter.com/frontlinepbs
Facebook: https://www.facebook.com/frontline

FRONTLINE is streaming more than 200 documentaries online, for free, here: https://to.pbs.org/37lhSw0

Funding for FRONTLINE is provided through the support of PBS viewers and by the Corporation for Public Broadcasting. Major funding for FRONTLINE is provided by the John D. and Catherine T. MacArthur Foundation and the Ford Foundation. Additional funding is provided by the Abrams Foundation, the Park Foundation, The John and Helen Glessner Family Trust, the Heising-Simons Foundation, and the FRONTLINE Journalism Fund with major support from Jon and Jo Ann Hagler on behalf of the Jon L. Hagler Foundation.

## Amazon Empire: Dave Limp Interview | FRONTLINE
 - [https://www.youtube.com/watch?v=iVVlrtAe5X8](https://www.youtube.com/watch?v=iVVlrtAe5X8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ
 - date published: 2020-02-19 00:00:00+00:00

Dave Limp, senior vice president of devices and services at Amazon, spoke to FRONTLINE about the Ring security system and the Echo’s Alexa assistant. “I think compared to many of the other types of devices that are much more pervasive in our society, in your lives, we’re doing a good job inventing.”
 
Subscribe on YouTube: http://bit.ly/1BycsJW

#Amazon #FrontlinePBS #Alexa

This excerpt is from an interview conducted for FRONTLINE’s documentary “Amazon Empire,” which examines how founder and CEO Jeff Bezos turned Amazon into a business empire that is unprecedented in the history of American capitalism.

For the full story, watch "Amazon Empire: The Rise and Reign of Jeff Bezos" starting Tuesday, Feb. 18 at 9/8c on PBS and online: https://to.pbs.org/2SH9uSj

Instagram: https://www.instagram.com/frontlinepbs
Twitter: https://twitter.com/frontlinepbs
Facebook: https://www.facebook.com/frontline

FRONTLINE is streaming more than 200 documentaries online, for free, here: https://to.pbs.org/37lhSw0

Funding for FRONTLINE is provided through the support of PBS viewers and by the Corporation for Public Broadcasting. Major funding for FRONTLINE is provided by the John D. and Catherine T. MacArthur Foundation and the Ford Foundation. Additional funding is provided by the Abrams Foundation, the Park Foundation, The John and Helen Glessner Family Trust, the Heising-Simons Foundation, and the FRONTLINE Journalism Fund with major support from Jon and Jo Ann Hagler on behalf of the Jon L. Hagler Foundation.

## Amazon Empire: James Marcus Interview | FRONTLINE
 - [https://www.youtube.com/watch?v=u-azeMbT7WA](https://www.youtube.com/watch?v=u-azeMbT7WA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ
 - date published: 2020-02-19 00:00:00+00:00

James Marcus, former Amazon editor and author of “Amazonia: Five Years at the Epicenter of the Dot.Com Juggernaut,” spoke to FRONTLINE about the early ambitions of Amazon founder and CEO Jeff Bezos: “The breadth of the ambition was amazing and refreshing, but it also, in a way, seemed comically unrealistic.”
 
Subscribe on YouTube: http://bit.ly/1BycsJW

#Amazon #FrontlinePBS #JeffBezos

This excerpt is from an interview conducted for FRONTLINE’s documentary “Amazon Empire,” which examines how founder and CEO Jeff Bezos turned Amazon into a business empire that is unprecedented in the history of American capitalism.

For the full story, watch "Amazon Empire: The Rise and Reign of Jeff Bezos" starting Tuesday, Feb. 18 at 9/8c on PBS and online: https://to.pbs.org/2SH9uSj

Instagram: https://www.instagram.com/frontlinepbs
Twitter: https://twitter.com/frontlinepbs
Facebook: https://www.facebook.com/frontline

FRONTLINE is streaming more than 200 documentaries online, for free, here: https://to.pbs.org/37lhSw0

Funding for FRONTLINE is provided through the support of PBS viewers and by the Corporation for Public Broadcasting. Major funding for FRONTLINE is provided by the John D. and Catherine T. MacArthur Foundation and the Ford Foundation. Additional funding is provided by the Abrams Foundation, the Park Foundation, The John and Helen Glessner Family Trust, the Heising-Simons Foundation, and the FRONTLINE Journalism Fund with major support from Jon and Jo Ann Hagler on behalf of the Jon L. Hagler Foundation.

## Amazon Empire: James Thomson Interview | FRONTLINE
 - [https://www.youtube.com/watch?v=JoDwrDxG7bk](https://www.youtube.com/watch?v=JoDwrDxG7bk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ
 - date published: 2020-02-19 00:00:00+00:00

“When I worked at Amazon, we had training specifically on the use of terms like ‘monopoly,’” James Thomson, whose last role at Amazon was as head of Amazon Services, told FRONTLINE. He spoke about Amazon’s power, its impact on businesses and brands, and the way it handles data.
 
Subscribe on YouTube: http://bit.ly/1BycsJW

#Amazon #FrontlinePBS

This excerpt is from an interview conducted for FRONTLINE’s documentary “Amazon Empire,” which examines how founder and CEO Jeff Bezos turned Amazon into a business empire that is unprecedented in the history of American capitalism.

For the full story, watch "Amazon Empire: The Rise and Reign of Jeff Bezos" starting Tuesday, Feb. 18 at 9/8c on PBS and online: https://to.pbs.org/2SH9uSj

Instagram: https://www.instagram.com/frontlinepbs
Twitter: https://twitter.com/frontlinepbs
Facebook: https://www.facebook.com/frontline

FRONTLINE is streaming more than 200 documentaries online, for free, here: https://to.pbs.org/37lhSw0

Funding for FRONTLINE is provided through the support of PBS viewers and by the Corporation for Public Broadcasting. Major funding for FRONTLINE is provided by the John D. and Catherine T. MacArthur Foundation and the Ford Foundation. Additional funding is provided by the Abrams Foundation, the Park Foundation, The John and Helen Glessner Family Trust, the Heising-Simons Foundation, and the FRONTLINE Journalism Fund with major support from Jon and Jo Ann Hagler on behalf of the Jon L. Hagler Foundation.

## Amazon Empire: Jay Carney Interview | FRONTLINE
 - [https://www.youtube.com/watch?v=ISp0BIjsikI](https://www.youtube.com/watch?v=ISp0BIjsikI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ
 - date published: 2020-02-19 00:00:00+00:00

Jay Carney, Amazon’s senior vice president of global corporate affairs, told FRONTLINE “there’s a lot of misunderstanding” about Amazon’s business model and principles. He said, “I sometimes talk to members of Congress who don’t believe me when I tell them that we’re not the biggest retailer in the United States.”
 
Subscribe on YouTube: http://bit.ly/1BycsJW

#Amazon #FrontlinePBS 

This excerpt is from an interview conducted for FRONTLINE’s documentary “Amazon Empire,” which examines how founder and CEO Jeff Bezos turned Amazon into a business empire that is unprecedented in the history of American capitalism.

For the full story, watch "Amazon Empire: The Rise and Reign of Jeff Bezos" starting Tuesday, Feb. 18 at 9/8c on PBS and online: https://to.pbs.org/2SH9uSj

Instagram: https://www.instagram.com/frontlinepbs
Twitter: https://twitter.com/frontlinepbs
Facebook: https://www.facebook.com/frontline

FRONTLINE is streaming more than 200 documentaries online, for free, here: https://to.pbs.org/37lhSw0

Funding for FRONTLINE is provided through the support of PBS viewers and by the Corporation for Public Broadcasting. Major funding for FRONTLINE is provided by the John D. and Catherine T. MacArthur Foundation and the Ford Foundation. Additional funding is provided by the Abrams Foundation, the Park Foundation, The John and Helen Glessner Family Trust, the Heising-Simons Foundation, and the FRONTLINE Journalism Fund with major support from Jon and Jo Ann Hagler on behalf of the Jon L. Hagler Foundation.

## Amazon Empire: Jeff Wilke Interview | FRONTLINE
 - [https://www.youtube.com/watch?v=hziCY1ohf64](https://www.youtube.com/watch?v=hziCY1ohf64)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ
 - date published: 2020-02-19 00:00:00+00:00

Jeff Wilke, currently CEO of Worldwide Consumer at Amazon, spoke to FRONTLINE about working conditions at Amazon fulfillment centers. “From the moment that I arrived 20 years ago, I made it very clear to our operations teams that we will not compromise the safety of our employees to do anything else.”  

Subscribe on YouTube: http://bit.ly/1BycsJW

#Amazon #FrontlinePBS #AmazonFulfillmentCenter

This excerpt is from an interview conducted for FRONTLINE’s documentary “Amazon Empire,” which examines how founder and CEO Jeff Bezos turned Amazon into a business empire that is unprecedented in the history of American capitalism.

For the full story, watch "Amazon Empire: The Rise and Reign of Jeff Bezos" starting Tuesday, Feb. 18 at 9/8c on PBS and online: https://to.pbs.org/2SH9uSj

Instagram: https://www.instagram.com/frontlinepbs
Twitter: https://twitter.com/frontlinepbs
Facebook: https://www.facebook.com/frontline

FRONTLINE is streaming more than 200 documentaries online, for free, here: https://to.pbs.org/37lhSw0

Funding for FRONTLINE is provided through the support of PBS viewers and by the Corporation for Public Broadcasting. Major funding for FRONTLINE is provided by the John D. and Catherine T. MacArthur Foundation and the Ford Foundation. Additional funding is provided by the Abrams Foundation, the Park Foundation, The John and Helen Glessner Family Trust, the Heising-Simons Foundation, and the FRONTLINE Journalism Fund with major support from Jon and Jo Ann Hagler on behalf of the Jon L. Hagler Foundation.

## Amazon Empire: Jennifer Cast Interview | FRONTLINE
 - [https://www.youtube.com/watch?v=mOF0oflkQmY](https://www.youtube.com/watch?v=mOF0oflkQmY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ
 - date published: 2020-02-19 00:00:00+00:00

In its early days, Amazon’s “philosophy about profitability was: focus on the long term, understand the business model… and don’t be afraid of building for the future,” Jennifer Cast, vice president of specialty recruiting at Amazon, told FRONTLINE.

Subscribe on YouTube: http://bit.ly/1BycsJW

#Amazon #FrontlinePBS

This excerpt is from an interview conducted for FRONTLINE’s documentary “Amazon Empire,” which examines how founder and CEO Jeff Bezos turned Amazon into a business empire that is unprecedented in the history of American capitalism.

For the full story, watch "Amazon Empire: The Rise and Reign of Jeff Bezos" starting Tuesday, Feb. 18 at 9/8c on PBS and online: https://to.pbs.org/2SH9uSj

Instagram: https://www.instagram.com/frontlinepbs
Twitter: https://twitter.com/frontlinepbs
Facebook: https://www.facebook.com/frontline

FRONTLINE is streaming more than 200 documentaries online, for free, here: https://to.pbs.org/37lhSw0

Funding for FRONTLINE is provided through the support of PBS viewers and by the Corporation for Public Broadcasting. Major funding for FRONTLINE is provided by the John D. and Catherine T. MacArthur Foundation and the Ford Foundation. Additional funding is provided by the Abrams Foundation, the Park Foundation, The John and Helen Glessner Family Trust, the Heising-Simons Foundation, and the FRONTLINE Journalism Fund with major support from Jon and Jo Ann Hagler on behalf of the Jon L. Hagler Foundation.

## Amazon Empire: Randy Miller Interview | FRONTLINE
 - [https://www.youtube.com/watch?v=UgwA8xfAnWU](https://www.youtube.com/watch?v=UgwA8xfAnWU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ
 - date published: 2020-02-19 00:00:00+00:00

“People think that’s ruthless.” Randy Miller, former director of merchandise pricing and product management at Amazon, defended Amazon’s business practices, including “the cheetah model,” which he describes as the method the internet retail giant would use to negotiate with book publishers.
 
Subscribe on YouTube: http://bit.ly/1BycsJW

#Amazon #FrontlinePBS

This excerpt is from an interview conducted for FRONTLINE’s documentary “Amazon Empire,” which examines how founder and CEO Jeff Bezos turned Amazon into a business empire that is unprecedented in the history of American capitalism.

For the full story, watch "Amazon Empire: The Rise and Reign of Jeff Bezos" starting Tuesday, Feb. 18 at 9/8c on PBS and online: https://to.pbs.org/2SH9uSj

Instagram: https://www.instagram.com/frontlinepbs
Twitter: https://twitter.com/frontlinepbs
Facebook: https://www.facebook.com/frontline

FRONTLINE is streaming more than 200 documentaries online, for free, here: https://to.pbs.org/37lhSw0

Funding for FRONTLINE is provided through the support of PBS viewers and by the Corporation for Public Broadcasting. Major funding for FRONTLINE is provided by the John D. and Catherine T. MacArthur Foundation and the Ford Foundation. Additional funding is provided by the Abrams Foundation, the Park Foundation, The John and Helen Glessner Family Trust, the Heising-Simons Foundation, and the FRONTLINE Journalism Fund with major support from Jon and Jo Ann Hagler on behalf of the Jon L. Hagler Foundation.

## Amazon Empire: Shel Kaphan Interview | FRONTLINE
 - [https://www.youtube.com/watch?v=MtRkdsrL5Xg](https://www.youtube.com/watch?v=MtRkdsrL5Xg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ
 - date published: 2020-02-19 00:00:00+00:00

Amazon’s first employee, Shel Kaphan, told FRONTLINE, “I think that the characterization of Amazon as being a ruthless competitor is true.” He said, “I think they’re doing what the business schools teach people to do.”
 
Subscribe on YouTube: http://bit.ly/1BycsJW

#Amazon #FrontlinePBS #Capitalism

This excerpt is from an interview conducted for FRONTLINE’s documentary “Amazon Empire,” which examines how founder and CEO Jeff Bezos turned Amazon into a business empire that is unprecedented in the history of American capitalism.

For the full story, watch "Amazon Empire: The Rise and Reign of Jeff Bezos" starting Tuesday, Feb. 18 at 9/8c on PBS and online: https://to.pbs.org/2SH9uSj

Instagram: https://www.instagram.com/frontlinepbs
Twitter: https://twitter.com/frontlinepbs
Facebook: https://www.facebook.com/frontline

FRONTLINE is streaming more than 200 documentaries online, for free, here: https://to.pbs.org/37lhSw0

Funding for FRONTLINE is provided through the support of PBS viewers and by the Corporation for Public Broadcasting. Major funding for FRONTLINE is provided by the John D. and Catherine T. MacArthur Foundation and the Ford Foundation. Additional funding is provided by the Abrams Foundation, the Park Foundation, The John and Helen Glessner Family Trust, the Heising-Simons Foundation, and the FRONTLINE Journalism Fund with major support from Jon and Jo Ann Hagler on behalf of the Jon L. Hagler Foundation.

