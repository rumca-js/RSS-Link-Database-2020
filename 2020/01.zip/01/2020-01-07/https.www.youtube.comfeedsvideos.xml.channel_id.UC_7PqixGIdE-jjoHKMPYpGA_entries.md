# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Takie rzeczy tylko w czarno-białym filmie...
 - [https://www.youtube.com/watch?v=GHFnQTHt-wI](https://www.youtube.com/watch?v=GHFnQTHt-wI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2020-01-07 00:00:00+00:00

Więcej ► https://playdlawosp.pl/
Patronite ► https://patronite.pl/NaukowyBelkot 
Mix audio ► http://ratstudios.pl/

Jak co roku Play gra z WOŚP. Jak co roku w zbiórkę pieniędzy dla dzieci jest zaangażowany #teamplay. A z nim ja. Dzięki temu, że za pośrednictwem aplikacji Play24 wykonano już 200 tysięcy transakcji to Play przekaże po Wielkim Finale 200 tysięcy złotych na rzecz WOŚP. Żeby zaś zachęcić wszystkich do uczestnictwa w tej zbiórce robimy "wyzwanie". Film niezwykły. Prawdopodobnie na tym kanale niepowtarzalny. O tanich efektach specjalnych... z wykorzystaniem prostego tricku z optyki...

Zapraszam :)

Subskrypcja ► https://youtube.com/c/UwagaNaukowyBelkot
Facebook ► https://facebook.com/UwagaNaukowyBelkot
Twitter ► https://twitter.com/NaukowyBelkot
Instagram ► https://www.instagram.com/NaukowyBelkot/

Wyłącznie Naukowy Bełkot ► https://goo.gl/Do7VCc
Grupa na facebooku ► https://goo.gl/HP8J83

