# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Henry Cavill's Face Modded Into The Witcher 3
 - [https://www.youtube.com/watch?v=Vz7sw-t1KwQ](https://www.youtube.com/watch?v=Vz7sw-t1KwQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-01-08 00:00:00+00:00

We're playing The Witcher 3 with Henry Cavill's face modded onto Geralt, in honor of the Netflix series! The mod used is the "Game Lore Henry Cavill Retexture" made by Shadowphonic on NexusMods, which can be found here: https://www.nexusmods.com/witcher3/mods/4163

## Getting An Evolution As Fast As We Can in Temtem (Pokemon-Inspired MMO)
 - [https://www.youtube.com/watch?v=YvGG4S0LL5c](https://www.youtube.com/watch?v=YvGG4S0LL5c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-01-07 00:00:00+00:00

We're back and playing Temtem again to see how fast we can get our starter to evolve. We'll be fighting through multiple dojos and battling various Temtems along the way. Temtem is a Pokemon-inspired MMO game that is currently in Alpha!

