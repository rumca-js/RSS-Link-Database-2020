# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Kælan Mikla - Draumadís (Live on KEXP)
 - [https://www.youtube.com/watch?v=ni2DWG1U-MA](https://www.youtube.com/watch?v=ni2DWG1U-MA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-08 00:00:00+00:00

http://KEXP.ORG presents Kælan Mikla performing "Draumadís" live in the KEXP studio. Recorded October 18, 2019.

Host: Kevin Cole
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://www.facebook.com/Kaelanmikla

## Kælan Mikla - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=SzD3krJBrRM](https://www.youtube.com/watch?v=SzD3krJBrRM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-08 00:00:00+00:00

http://KEXP.ORG presents Kælan Mikla performing live in the KEXP studio. Recorded October 18, 2019.

Songs:
Hvernig kemst ég upp?
Næturblóm
Draumadís
Nótt eftir nótt

Host: Kevin Cole
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://www.facebook.com/Kaelanmikla

## Kælan Mikla - Hvernig kemst ég upp? (Live on KEXP)
 - [https://www.youtube.com/watch?v=2kmqYCmST8g](https://www.youtube.com/watch?v=2kmqYCmST8g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-08 00:00:00+00:00

http://KEXP.ORG presents Kælan Mikla performing "Hvernig kemst ég upp?" live in the KEXP studio. Recorded October 18, 2019.

Host: Kevin Cole
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://www.facebook.com/Kaelanmikla

## Kælan Mikla - Nótt eftir nótt (Live on KEXP)
 - [https://www.youtube.com/watch?v=mO5KgosCITA](https://www.youtube.com/watch?v=mO5KgosCITA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-08 00:00:00+00:00

http://KEXP.ORG presents Kælan Mikla performing "Nótt eftir nótt" live in the KEXP studio. Recorded October 18, 2019.

Host: Kevin Cole
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://www.facebook.com/Kaelanmikla

## Kælan Mikla - Næturblóm (Live on KEXP)
 - [https://www.youtube.com/watch?v=wscjlmsl15E](https://www.youtube.com/watch?v=wscjlmsl15E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-08 00:00:00+00:00

http://KEXP.ORG presents Kælan Mikla performing "Næturblóm" live in the KEXP studio. Recorded October 18, 2019.

Host: Kevin Cole
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://www.facebook.com/Kaelanmikla

