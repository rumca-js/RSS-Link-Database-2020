# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## The Best, Worst & Blandest of 2019 (Zero Punctuation)
 - [https://www.youtube.com/watch?v=FjTv3IfRie8](https://www.youtube.com/watch?v=FjTv3IfRie8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-01-08 00:00:00+00:00

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

This week on Zero Punctuation, Yahtzee looks back at the best, worst and blandest games of 2019. 

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►► https://sharkrobot.com/collections/zero-punctuation 

Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 

Like us on Facebook ►► http://www.facebook.com/EscapistMag

Follow us on Twitter ►► https://twitter.com/EscapistMag

## Yahtzee and Jack Packard Play Dark Souls | Post-ZP Stream
 - [https://www.youtube.com/watch?v=t8eo9OpG4zg](https://www.youtube.com/watch?v=t8eo9OpG4zg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-01-08 00:00:00+00:00

To celebrate the 2010s, we play my pick for most significant game of the decade. The remastered version, anyway.

Want in on the chat? Come join us on Twitch: https://www.twitch.tv/escapistmagazine

