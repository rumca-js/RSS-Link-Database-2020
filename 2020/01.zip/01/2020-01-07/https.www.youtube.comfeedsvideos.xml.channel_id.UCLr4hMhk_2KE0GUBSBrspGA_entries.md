# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Gdyby Jezus jeździł rowerem
 - [https://www.youtube.com/watch?v=ayhrD0qABsI](https://www.youtube.com/watch?v=ayhrD0qABsI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-01-07 00:00:00+00:00

Rower wodny Manta5 (nie ma nic wspólnego z Mantą, którą znamy w Polsce) będzie wystawiony w tym roku na CES. Nam udało się go nagrać wcześniej nad wodą, dlatego powstał ten krótki film -  przerywnik między pierwszym, a drugim odcinkiem naszych CESowych przygód. 
Link do roweru: https://manta5.com

