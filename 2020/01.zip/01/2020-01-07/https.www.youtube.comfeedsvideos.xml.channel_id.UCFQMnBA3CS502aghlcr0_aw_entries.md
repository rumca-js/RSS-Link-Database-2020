# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## this fish cured me of my faith in humanity
 - [https://www.youtube.com/watch?v=uTl8orAV9As](https://www.youtube.com/watch?v=uTl8orAV9As)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-01-08 00:00:00+00:00

The surprising new fad for grannies and pop-pops everywhere.

watch the madness here: http://themiraclecure.com/go/index24.php?aff_id=479
read the insane cure handbook here: https://docs.google.com/document/d/1TxrfFZrjKOpZsxMg3geYz0VmyQEG6MK1BGLGsHRCpCk/edit?usp=sharing

## goop is poop.
 - [https://www.youtube.com/watch?v=Q80d3Rlh5kw](https://www.youtube.com/watch?v=Q80d3Rlh5kw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-01-07 00:00:00+00:00

how can we really milk the sh*t out of this?

goop is an American natural health company owned by actress Gwyneth Paltrow. it shares a lot in common with a familiar conspiracy theorist in terms of sketchy product development, but without the conspiracy talking points.

It was launched as a "lifestyle brand" by Paltrow in September 2008, beginning as a weekly e-mail newsletter providing new age advice, such as "police your thoughts" and "eliminate white foods", and the slogan "Nourish the Inner Aspect". A lifestyle website was later added, and then Goop expanded into e-commerce, collaborating with fashion brands, launching pop-up shops, holding a "wellness summit", launching a print magazine, a podcast, and a docuseries for Netflix.

They have been widely critized for their pseudoscientific products and articles, such as this one from Anthony William, a "medical medium" with no credentials: https://goop.com/wellness/health/the-medical-medium-on-the-origins-of-thyroid-cancer/

