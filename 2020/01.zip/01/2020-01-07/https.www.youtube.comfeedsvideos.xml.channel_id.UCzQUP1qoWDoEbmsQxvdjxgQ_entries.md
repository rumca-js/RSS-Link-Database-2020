# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Joe Rogan Experience #1408 - Ed Calderon
 - [https://www.youtube.com/watch?v=xPBejhoKlb8](https://www.youtube.com/watch?v=xPBejhoKlb8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2020-01-08 00:00:00+00:00

Ed Calderon is a security specialist and combatives instructor with over 10 years experience in public safety along the northern border area of Mexico. Follow him online @EdsManifesto http://edsmanifesto.com

## Joe Rogan Experience #1407 - Michael Malice
 - [https://www.youtube.com/watch?v=83ysf_GO2aw](https://www.youtube.com/watch?v=83ysf_GO2aw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2020-01-07 00:00:00+00:00

Michael Malice is an author and also hosts a podcast called “Your Welcome with Michael Malice” available on the GaS Digital Network. His new book called  “The New Right” is available now.

