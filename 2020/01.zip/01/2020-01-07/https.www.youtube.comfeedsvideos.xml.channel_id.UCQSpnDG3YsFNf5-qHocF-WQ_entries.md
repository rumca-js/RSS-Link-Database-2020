# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## 7 New Internet Scams to Watch Out For (2020)
 - [https://www.youtube.com/watch?v=XfnvIXx-_FU](https://www.youtube.com/watch?v=XfnvIXx-_FU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2020-01-08 00:00:00+00:00

Watch out for these internet, email, and phone scams that are becoming more prevelant! 
⇒ Become a channel member for exclusive features! Check it out here: https://www.youtube.com/ThioJoe/join
● Subscribe Here ➤ https://www.youtube.com/user/ThioJoe?sub_confirmation=1

⇒ Become a channel member for exclusive features! Check it out here: https://www.youtube.com/ThioJoe/join

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe

⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV

My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

#Scams #Security #Tech #ThioJoe

