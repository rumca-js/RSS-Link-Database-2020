# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I thought Razer's "Modular" concept PC was impossible...
 - [https://www.youtube.com/watch?v=N7iTcpLME0M](https://www.youtube.com/watch?v=N7iTcpLME0M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-01-08 00:00:00+00:00

Remotely monitor and manage your server or PC at https://lmg.gg/pulsewayces2020 and get 20% off their Teams plan. Thanks to Pulseway for sponsoring our CES 2020 Coverage! 

The future of PCs (if you're judging by the new Razer Tomahwk N1) looks... modular? What exactly does that mean?...

Purchases made through some store links may provide some compensation to Linus Media Group.

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

## ASUS DITCHES Intel
 - [https://www.youtube.com/watch?v=hGUESEq75ZI](https://www.youtube.com/watch?v=hGUESEq75ZI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-01-07 00:00:00+00:00

Thanks to Pulseway for sponsoring our CES 2020 Coverage! Remotely monitor and manage your server or PC from anyone. Try it for free and get 20% off their Teams plans for a limited time  at https://lmg.gg/pulsewayces2020

ASUS one of the top contenders for gaming laptops makes an interesting switch and leaves big ol' blue left in the dust. 

Buy ASUS AMD Gaming Laptops
On Amazon (PAID LINK): https://geni.us/s9Zk
On Newegg (PAID LINK): https://lmg.gg/a0e8M

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1142667-asus-ditches-intel/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

## Dell Made a "Nintendo Switch" Gaming PC!
 - [https://www.youtube.com/watch?v=2gWqmZ05kq8](https://www.youtube.com/watch?v=2gWqmZ05kq8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-01-07 00:00:00+00:00

Thanks to Pulseway for sponsoring our CES 2020 Coverage! Remotely monitor and manage your server or PC at https://lmg.gg/pulsewayces2020 and get 20% off their Teams plan.

Dell is NOT playing around at CES this year, and they are showing off some seriously awesome prototypes at the show...

Purchases made through some store links may provide some compensation to Linus Media Group.

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

## Who needs a car anyway? - LG's New 8K OLED is BREATHTAKING
 - [https://www.youtube.com/watch?v=NfDuf0NLXV4](https://www.youtube.com/watch?v=NfDuf0NLXV4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-01-07 00:00:00+00:00

Thanks to LG for sponsoring today's video! Check out LG's product line featured at CES2020 at the links below!

LG SIGNATURE OLED 65" TV http://bit.ly/2FnrOti
LG Sound Bar SN11RG http://bit.ly/39Me9K7
LG SIGNATURE ZX 88” Class 8K OLED TV http://bit.ly/2tBAXvy
LG Nano 9 Series 75” 8K Nanocell TV http://bit.ly/35sjB1D
LG gram 17'' Ultra-Lightweight Laptop http://bit.ly/36thuf7
LG 38WN95C-W 38” UltraWide Monitor http://bit.ly/2tvXOJd
LG 27GN950-B 27” UltraGear Monitor http://bit.ly/2N1Lmrp
LG 32'' 32UN880-B UltraFine Monitor http://bit.ly/2QuzGzr

