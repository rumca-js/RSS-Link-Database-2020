# Source:Laowhy86, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw, language:en-US

## I'm Moving Back To China - Wife Divorcing Me
 - [https://www.youtube.com/watch?v=0ls5xg636Nw](https://www.youtube.com/watch?v=0ls5xg636Nw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw
 - date published: 2020-01-08 00:00:00+00:00

Hey Laowinners!

So Chinese media took our video, and fabricated a grand tale about how miserable my wife's life is, and how we moved back to China because she thinks the USA is too dangerous. According to this video, we are also getting divorced. 

◘ Support me on Patreon for early release, and much more! http://www.patreon.com/laowhy86

◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

◘ OR Become a Sponsor on YouTube:
https://www.youtube.com/channel/UChvithwOECK5g_19TjldMKw/sponsor

◘ My TV show: Conquering Northern China:
https://vimeo.com/ondemand/conqueringnorthernchina

◘ Conquering Southern China
https://vimeo.com/ondemand/conqueringsouthernchina

◘ Discount code for both shows: laowinning

◘ Join me every week for videos about China! Don't forget to subscribe!
http://www.youtube.com/laowhy86

For Motorcycle adventures around the world, and a talk-show on two wheels go to ADVChina every Monday 1 PM EST/ 10 AM PST
https://www.youtube.com/advchina
Filial Piety Explained
https://youtu.be/2x3_2qJDfaI

For a realistic perspective on China and world travel from an American father and a Chinese mother with two half-Chinese daughters go to Laowhy86 every Wednesday 1 PM EST/ 10 AM PST
https://www.youtube.com/laowhy86

For a no-nonsense on the street look at Chinese culture and beyond from China’s original YouTuber, join SerpentZA on Friday at 1 PM EST/ 10 AM PST
https://www.youtube.com/serpentza
New Video - Doctors in China
https://youtu.be/HspStZXo1rU

Be a Laowinner!
Like comment subscribe!

◘ Facebook:
http://www.facebook.com/laowhy86

◘ Instagram: 
http://instagram.com/laowhy86

◘ The Muse Maker - (Music in this video)
https://soundcloud.com/themusemaker

◘ Music used most of the time - New World Hip Hop
https://soundcloud.com/apollodrivenz
https://www.youtube.com/channel/UCgirAE5d8ufiotRXmBZZbBQ

