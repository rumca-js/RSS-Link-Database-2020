# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## New Mutants - Official Trailer (My Thoughts)
 - [https://www.youtube.com/watch?v=KPEHi4A2ksE](https://www.youtube.com/watch?v=KPEHi4A2ksE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-01-07 00:00:00+00:00

After 2 years of delays, and unknowns, we have a trailer for NEW MUTANTS! Here are my thoughts on it.

Watch the trailer here: https://www.youtube.com/watch?v=W_vJhUAOFpI&t=3s

