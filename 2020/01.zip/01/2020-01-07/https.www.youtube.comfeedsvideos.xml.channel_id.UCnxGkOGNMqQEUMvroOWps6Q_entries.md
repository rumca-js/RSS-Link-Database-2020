# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Cartel Tech is Years Ahead of the Mexican Government
 - [https://www.youtube.com/watch?v=fttk09usNtY](https://www.youtube.com/watch?v=fttk09usNtY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-08 00:00:00+00:00

Taken from JRE #1408 w/Ed Calderon: https://youtu.be/xPBejhoKlb8

## Chinese Mining Companies Are Partnering With Mexican Cartels
 - [https://www.youtube.com/watch?v=53vOyaEzjeg](https://www.youtube.com/watch?v=53vOyaEzjeg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-08 00:00:00+00:00

Taken from JRE #1408 w/Ed Calderon: https://youtu.be/xPBejhoKlb8

## Ed Calderon Predicts Military Intervention in Mexico in 5 Years | Joe Rogan
 - [https://www.youtube.com/watch?v=DSNZ7EhdpOo](https://www.youtube.com/watch?v=DSNZ7EhdpOo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-08 00:00:00+00:00

Taken from JRE #1408 w/Ed Calderon:
https://youtu.be/xPBejhoKlb8

## Ed Calderon on Life in Mexico Versus America
 - [https://www.youtube.com/watch?v=2n7wxYxPuZ8](https://www.youtube.com/watch?v=2n7wxYxPuZ8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-08 00:00:00+00:00

Taken from JRE #1408 w/Ed Calderon:

## Ed Calderon on Mexican Psychedelic Rituals
 - [https://www.youtube.com/watch?v=1lgsdO14WaI](https://www.youtube.com/watch?v=1lgsdO14WaI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-08 00:00:00+00:00

Taken from JRE #1408 w/Ed Calderon: https://youtu.be/xPBejhoKlb8

## How Accurate is Netflix’s “Narcos”?
 - [https://www.youtube.com/watch?v=TwclnRO_z-0](https://www.youtube.com/watch?v=TwclnRO_z-0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-08 00:00:00+00:00

Taken from JRE #1408 w/Ed Calderon:

## Should Mexican Cartels be Labelled as Terrorist Organizations? w/Ed Calderon | Joe Rogan
 - [https://www.youtube.com/watch?v=dsz3-5GdcT0](https://www.youtube.com/watch?v=dsz3-5GdcT0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-08 00:00:00+00:00

Taken from JRE #1408 w/Ed Calderon:
https://youtu.be/xPBejhoKlb8

## The Future Will Bring Mexico and the USA Together
 - [https://www.youtube.com/watch?v=8Vlf_3tenXo](https://www.youtube.com/watch?v=8Vlf_3tenXo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-08 00:00:00+00:00

Taken from JRE #1408 w/Ed Calderon: https://youtu.be/xPBejhoKlb8

## There's Only One Gun Store in Mexico?
 - [https://www.youtube.com/watch?v=Qh7ePnztwv4](https://www.youtube.com/watch?v=Qh7ePnztwv4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-08 00:00:00+00:00

Taken from JRE #1408 w/Ed Calderon: https://youtu.be/xPBejhoKlb8

## What Will Happen to Mormons in Mexico? w/Ed Calderon | Joe Rogan
 - [https://www.youtube.com/watch?v=AS_ugD6otDo](https://www.youtube.com/watch?v=AS_ugD6otDo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-08 00:00:00+00:00

Taken from JRE #1408 w/Ed Calderon:
https://youtu.be/xPBejhoKlb8

## Why El Chapo's Son Was Released w/Ed Calderon | Joe Rogan
 - [https://www.youtube.com/watch?v=zxBcppwPFuM](https://www.youtube.com/watch?v=zxBcppwPFuM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-08 00:00:00+00:00

Taken from JRE #1408 w/Ed Calderon:
https://youtu.be/xPBejhoKlb8

## Will Crushing the Cartels Require US Military Intervention?
 - [https://www.youtube.com/watch?v=EqM3xvh0m-4](https://www.youtube.com/watch?v=EqM3xvh0m-4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-08 00:00:00+00:00

Taken from JRE #1408 w/Ed Calderon: https://youtu.be/xPBejhoKlb8

## Joe Rogan on Ricky Gervais' Golden Globes Monologue
 - [https://www.youtube.com/watch?v=WRbaQrb3Jhk](https://www.youtube.com/watch?v=WRbaQrb3Jhk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-07 07:37:49+00:00

Joe Rogan on Ricky Gervais' Golden Globes Monologue

## Corpse Flowers and Other Oddities w/Michael Malice | Joe Rogan
 - [https://www.youtube.com/watch?v=S4mDIb0BFOg](https://www.youtube.com/watch?v=S4mDIb0BFOg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-07 00:00:00+00:00

Taken from JRE #1407 w/Michael Malice:
https://youtu.be/83ysf_GO2aw

## Could Hong Kong Be Beginning of the End of Chinese Totalitarianism
 - [https://www.youtube.com/watch?v=jclAjmhlNb0](https://www.youtube.com/watch?v=jclAjmhlNb0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-07 00:00:00+00:00

Taken from JRE #1407 w/Michael Malice: https://youtu.be/83ysf_GO2aw

## Do We Need to Worry About War with Iran?
 - [https://www.youtube.com/watch?v=jdi8KWeUrlY](https://www.youtube.com/watch?v=jdi8KWeUrlY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-07 00:00:00+00:00

Taken from JRE #1406 w/Brian Redban: https://youtu.be/joGS1O-Uto4

## Eagles Are Hungry, Flying Monsters!
 - [https://www.youtube.com/watch?v=4QJQxCoaNqU](https://www.youtube.com/watch?v=4QJQxCoaNqU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-07 00:00:00+00:00

Taken from JRE #1406 w/Brian Redban: https://youtu.be/joGS1O-Uto4

## Greta Thunberg's Media Attention w/Brian Redban | Joe Rogan
 - [https://www.youtube.com/watch?v=RiJ3l8ZWByw](https://www.youtube.com/watch?v=RiJ3l8ZWByw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-07 00:00:00+00:00

Taken from JRE #1406 w/Brian Redban:
https://youtu.be/joGS1O-Uto4

## How Michael Malice Uses Twitter for Psychological Warfare
 - [https://www.youtube.com/watch?v=kwPb-dzd3Sc](https://www.youtube.com/watch?v=kwPb-dzd3Sc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-07 00:00:00+00:00

Taken from JRE #1407 w/Michael Malice: https://youtu.be/83ysf_GO2aw

## Joe Rogan Reacts to New Epstein Information
 - [https://www.youtube.com/watch?v=CVw91S4JXDE](https://www.youtube.com/watch?v=CVw91S4JXDE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-07 00:00:00+00:00

Taken from JRE #1406 w/Brian Redban:
https://youtu.be/joGS1O-Uto4

## Joe Rogan is Annoyed by Off-White Shoe Trend
 - [https://www.youtube.com/watch?v=u3gIOX79bwg](https://www.youtube.com/watch?v=u3gIOX79bwg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-07 00:00:00+00:00

Taken from JRE #1407 w/Michael Malice:
https://youtu.be/83ysf_GO2aw

## Joe Rogan is Trying the Carnivore Diet
 - [https://www.youtube.com/watch?v=2ghTj2tHU6s](https://www.youtube.com/watch?v=2ghTj2tHU6s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-07 00:00:00+00:00

Taken from JRE #1406 w/Brian Redban: https://youtu.be/joGS1O-Uto4

## Joe Rogan on New York Times’ Cenk Uygur Screw Up
 - [https://www.youtube.com/watch?v=JW657KCiAzw](https://www.youtube.com/watch?v=JW657KCiAzw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-07 00:00:00+00:00

Taken from JRE #1406 w/Brian Redban: https://youtu.be/joGS1O-Uto4

## Joe Rogan on “Naked Philanthropist” Kaylen Ward
 - [https://www.youtube.com/watch?v=IZreYx82naU](https://www.youtube.com/watch?v=IZreYx82naU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-07 00:00:00+00:00

Taken from JRE #1406 w/Brian Redban: https://youtu.be/joGS1O-Uto4

## Joe Rogan | The Link Between Religion and Psychedelics
 - [https://www.youtube.com/watch?v=fwV8_Oc0EuY](https://www.youtube.com/watch?v=fwV8_Oc0EuY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-07 00:00:00+00:00

Taken from JRE #1407 w/Michael Malice:
https://youtu.be/83ysf_GO2aw

## Kevin Spacey's Latest Bizarre YouTube Video | Joe Rogan
 - [https://www.youtube.com/watch?v=zRdlVkb58ko](https://www.youtube.com/watch?v=zRdlVkb58ko)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-07 00:00:00+00:00

Taken from JRE #1406 w/Brian Redban:
https://youtu.be/joGS1O-Uto4

## Michael Malice - Jake The Snake's Story of Abuse Helped My Friend | Joe Rogan
 - [https://www.youtube.com/watch?v=vpIfgc8PW98](https://www.youtube.com/watch?v=vpIfgc8PW98)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-07 00:00:00+00:00

Taken from JRE #1407 w/Michael Malice:
https://youtu.be/83ysf_GO2aw

## Michael Malice Thinks Forced Diversity Will Be Embarrassing in Retrospect | Joe Rogan
 - [https://www.youtube.com/watch?v=FuMh6NjxuHg](https://www.youtube.com/watch?v=FuMh6NjxuHg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-07 00:00:00+00:00

Taken from JRE #1407 w/Michael Malice:
https://youtu.be/83ysf_GO2aw

## Michael Malice: A Lot of People Are Basic As Hell
 - [https://www.youtube.com/watch?v=LY-7wHpgov8](https://www.youtube.com/watch?v=LY-7wHpgov8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-07 00:00:00+00:00

Taken from JRE #1407 w/Michael Malice: https://youtu.be/83ysf_GO2aw

## Michael Malice: Kamala Harris Didn’t Really Want to Be President
 - [https://www.youtube.com/watch?v=9D3BzdN9ui4](https://www.youtube.com/watch?v=9D3BzdN9ui4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-07 00:00:00+00:00

Taken from JRE #1407 w/Michael Malice: https://youtu.be/83ysf_GO2aw

## Michael Malice: The Press Loves War
 - [https://www.youtube.com/watch?v=PU2FolI2Lms](https://www.youtube.com/watch?v=PU2FolI2Lms)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-07 00:00:00+00:00

Taken from JRE #1407 w/Michael Malice: https://youtu.be/83ysf_GO2aw

## Michael Malice: We Can still Work Things Out With Iran
 - [https://www.youtube.com/watch?v=bB6ZpfqOp6I](https://www.youtube.com/watch?v=bB6ZpfqOp6I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-07 00:00:00+00:00



## People Are Waking Up to How Depraved Those in Power Really Are
 - [https://www.youtube.com/watch?v=gcRtRUbKnfY](https://www.youtube.com/watch?v=gcRtRUbKnfY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-07 00:00:00+00:00

Taken from JRE #1407 w/Michael Malice: https://youtu.be/83ysf_GO2aw

## The Iran Situation Scares Joe Rogan
 - [https://www.youtube.com/watch?v=UXGajBWtbPc](https://www.youtube.com/watch?v=UXGajBWtbPc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-07 00:00:00+00:00

Taken from JRE #1406 w/Brian Redban:
https://youtu.be/joGS1O-Uto4

## Weinstein Should Receive MDMA Therapy w/Brian Redban | Joe Rogan
 - [https://www.youtube.com/watch?v=wainHf5PJDA](https://www.youtube.com/watch?v=wainHf5PJDA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-07 00:00:00+00:00

Taken from JRE #1406 w/Brian Redban:
https://youtu.be/joGS1O-Uto4

## Were the Unabomber’s Predictions About Technology Correct?
 - [https://www.youtube.com/watch?v=vG8xN-s8gI8](https://www.youtube.com/watch?v=vG8xN-s8gI8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-07 00:00:00+00:00

Taken from JRE #1407 w/Michael Malice: https://youtu.be/83ysf_GO2aw

## What if a Tweet Started WW3? w/Brian Redban | Joe Rogan
 - [https://www.youtube.com/watch?v=QJ0kjeS93_I](https://www.youtube.com/watch?v=QJ0kjeS93_I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-07 00:00:00+00:00

Taken from JRE #1406 w/Brian Redban:
https://youtu.be/joGS1O-Uto4

## Who Makes Cooking Oil Out of Sewage?
 - [https://www.youtube.com/watch?v=yBwwMcYjKWw](https://www.youtube.com/watch?v=yBwwMcYjKWw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-07 00:00:00+00:00

Taken from JRE #1406 w/Brian Redban: https://youtu.be/joGS1O-Uto4

