# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## A MISTAKE WAS MADE - WE HIRED A DISHONEST CONTRACTOR(in my opinion)
 - [https://www.youtube.com/watch?v=7yP9Jm_Z5vs](https://www.youtube.com/watch?v=7yP9Jm_Z5vs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-01-07 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
DON'T INTERRUPT ME EUGENE mug or t-shirts available here: https://teespring.com/don-t-interrupt-me-eugene?pid=2&cid=2122 

We wanted a window in the front, and he put a piece of glass in the window that was black back - not seethrough. He knew it wouldn't work for us, and when his employee pointed it out, he instructed the employee to keep installing it, without asking us. The employee luckily has a conscience and purposely installed it in a manner where it can be removed very easily. 

The contractor knew by doing this, he'd create a change order to put the proper one in later(thus charging us extra to open the wall up after he had closed it and installed the wrong glass). That is a scumbag move - it's time to let him go. Hopefully tomorrow he brings by supplies that were paid for.  If he does not, then we conclude with a lawsuit, DCA complaints, and disclosing the business name so NO ONE EVER GETS SCREWED BY HIM AGAIN. If he does, we still conclude our work together. I cannot work with someone who is actively looking to cut corners, and actively screw me any longer.

TO BE CLEAR - GOTHAM CITY SOLUTIONS IS THIS MAN EUGENE HARRINGTON'S COMPANY THAT WAS HIRED TO DO THE WORK.
GOTHAM CITY BUILDERS IS *NOT* THE SAME BUSINESS
GOTHAM CITY TECHNOLOGY IS *NOT* THE SAME BUSINESS.
They just so happen to be unlucky enough to have similar names in similar areas.

## DAY 38 - CONTRACTOR IS OUT - contract posted in description.
 - [https://www.youtube.com/watch?v=50ByeqNgYjQ](https://www.youtube.com/watch?v=50ByeqNgYjQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-01-07 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
*The video includes us speaking on a public sidewalk where there is no expectation of privacy, outside of my store, and images of me inside of my store which is my property and holds no expectation of privacy.* 

This is a recording of a contractor I paid over $30,000 to, who ripped me off, in my opinion. He lied to me every step of the way throughout the project, about materials he would use, the quality of the work, and more. He represented himself as a licensed contractor, which he is not. He has done this before to other people: read the court case documents on how he sent fake pictures of progress in order to collect money for work he did not perform, that he never denied or refuted. https://iapps.courts.state.ny.us/nyscef/ViewDocument?docIndex=goNm7ZDn3I41eoKeebNbVA==  He has bankruptcy after bankruptcy from being sued after doing this to other people. https://businessbankruptcies.com/cases/eugene-harrington It is my hopes that by making my experience public, he will not have the opportunity to misrepresent his work or his status as a licensed contractor to any other customer again.


Please do consider the fact that this recording is on a public sidewalk, in addition to the public interest of having this information being out there. He owes people hundreds of thousands of dollars that he will never return to them. He used a check cashing facility to cash my checks where he likely paid a 3-5% fee on $11,000 just to avoid using bank accounts because if he used a bank account the wages would be garnished to his past clients who are his creditors. His attempt to silence me through these privacy claims will allow him to continue doing what he did to me to other people. I can survive taking a $30,000 hit, but can the next victim?


To view the contract, https://imgur.com/a/fSjfmVf --- Eugene Harrington of Gotham City Solutions got off with about $30,000. Exact amounts listed. This was not the "lowest bid", this was the recommended/referred bid. The super of the building suggested contractors that bid about $12,000 less to do the job, but was inconsistent in his communication. It was worth the extra to be able to contact the person by phone, know they weren't going to run away, and because he had a referral from an ex-employer/mentor of mine. 

I chose to fire him because I can't trust any of the work he does to be of quality.


Look below at the history. 

https://www.buildzoom.com/contractor/eugene-harrington - this is his name, with a different address listed than what's on my invoice! Ah well, let's get a timeline going and see if this different address leads us anywhere. 

*Early March 2018:* Here, a judgment was applied against him in early 2018 for over $50,000. https://iapps.courts.state.ny.us/nyscef/ViewDocument?docIndex=oR6bDSY0Nvg4h60svkrXPw== (clearly they had a better attorney than whomever I called today!) 

*Mid March 2018:* Here, you can see he files for bankruptcy. https://pdfhost.io/v/5jAfJy+o_initial_filingpdf.pdf

*July 8th, 2018:* His bankruptcy request gets denied by court. https://imgur.com/a/zLvSuOs  

*July 7th, 2018:* The registered business address goes on fire https://www.silive.com/news/2018/07/major_fdny_response_to_house_f.html

Within 24 hours, your bankruptcy filing fails and the house you registered in your filing as your business address goes on fire? 


And the address you include on the top of your invoices is a DIFFERENT address than the one you utilize for any work?

For more information on how this job was done, watch the rest of the series here: https://www.youtube.com/playlist?list=PLkVbIsAWN2lucdpXqcM4qW6ev60OSXdw4 Day 11, Day 17, and the video where he swapped out plywood for OSB are the three best.

TO BE CLEAR - GOTHAM CITY SOLUTIONS IS THIS MAN EUGENE HARRINGTON'S COMPANY THAT WAS HIRED TO DO THE WORK.
GOTHAM CITY BUILDERS IS *NOT* THE SAME BUSINESS
GOTHAM CITY TECHNOLOGY IS *NOT* THE SAME BUSINESS.
They just so happen to be unlucky enough to have similar names in similar areas.

## Day 11 - Steve & Paul call out contractor
 - [https://www.youtube.com/watch?v=XaRSUKmuaa0](https://www.youtube.com/watch?v=XaRSUKmuaa0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-01-07 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
🔵 Watch the rest of this series here: https://www.youtube.com/playlist?list=PLkVbIsAWN2 lucdpXqcM4qW6ev60OSXdw4 
🔵 To view the contract, https://imgur.com/a/fSjfmVf

TO BE CLEAR - GOTHAM CITY SOLUTIONS IS THIS MAN EUGENE HARRINGTON'S COMPANY THAT WAS HIRED TO DO THE WORK.
GOTHAM CITY BUILDERS IS *NOT* THE SAME BUSINESS
GOTHAM CITY TECHNOLOGY IS *NOT* THE SAME BUSINESS.
They just so happen to be unlucky enough to have similar names in similar areas.

## Day 37 - the straw that broke the OSB's back.
 - [https://www.youtube.com/watch?v=xU_a3cbD_Gc](https://www.youtube.com/watch?v=xU_a3cbD_Gc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-01-07 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
The video includes us speaking on a public sidewalk where there is no expectation of privacy, outside of my store. This is a recording of a contractor I paid over $30,000 to, who ripped me off, in my opinion. He lied to me every step of the way throughout the project, about materials he would use, the quality of the work, and more. He represented himself as a licensed contractor, which he is not. He has done this before to other people: read the court case documents on how he sent fake pictures of progress in order to collect money for work he did not perform, that he never denied or refuted. https://iapps.courts.state.ny.us/nyscef/ViewDocument?docIndex=goNm7ZDn3I41eoKeebNbVA==  He has bankruptcy after bankruptcy from being sued after doing this to other people. https://businessbankruptcies.com/cases/eugene-harrington It is my hopes that by making my experience public, he will not have the opportunity to misrepresent his work or his status as a licensed contractor to any other customer again. 


For more information on how this job was done, watch the rest of the series here: https://www.youtube.com/playlist?list=PLkVbIsAWN2lucdpXqcM4qW6ev60OSXdw4

To view the contract, https://imgur.com/a/fSjfmVf

The last straw came today. We wanted a window in the front, and he put a piece of glass in the window that was black back - not seethrough. He knew it wouldn't work for us, and when his employee pointed it out, he instructed the employee to keep installing it, without asking us. The employee luckily has a conscience and purposely installed it in a manner where it can be removed very easily. 

The contractor knew by doing this, he'd create a change order to put the proper one in later(thus charging us extra to open the wall up after he had closed it and installed the wrong glass). That is a scumbag move in my opinion - it's time to let him go and let others know how he intended to rip us off so that you know not to do business with him. Hopefully tomorrow he brings by supplies that were paid for.  If he does not, then we conclude with a lawsuit, DCA complaints, and disclosing the business name so NO ONE EVER GETS SCREWED BY HIM AGAIN. If he does, we still conclude our work together. I cannot work with someone who is actively looking to cut corners, and actively screw me any longer. 


TO BE CLEAR - GOTHAM CITY SOLUTIONS IS THIS MAN EUGENE HARRINGTON'S COMPANY THAT WAS HIRED TO DO THE WORK.
GOTHAM CITY BUILDERS IS *NOT* THE SAME BUSINESS
GOTHAM CITY TECHNOLOGY IS *NOT* THE SAME BUSINESS.
They just so happen to be unlucky enough to have similar names in similar areas.

## I Fired The Contractor. Closure feels good
 - [https://www.youtube.com/watch?v=-_YrPa9Eaqs](https://www.youtube.com/watch?v=-_YrPa9Eaqs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-01-07 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
🔵 Watch the rest of this series here: https://www.youtube.com/playlist?list=PLkVbIsAWN2lucdpXqcM4qW6ev60OSXdw4 
🔵 To view the contract, https://imgur.com/a/fSjfmVf

TO BE CLEAR - GOTHAM CITY SOLUTIONS IS THIS MAN EUGENE HARRINGTON'S COMPANY THAT WAS HIRED TO DO THE WORK.
GOTHAM CITY BUILDERS IS *NOT* THE SAME BUSINESS
GOTHAM CITY TECHNOLOGY IS *NOT* THE SAME BUSINESS.
They just so happen to be unlucky enough to have similar names in similar areas.

## Louis Rossmann AMA stream
 - [https://www.youtube.com/watch?v=9DJujrKPKv8](https://www.youtube.com/watch?v=9DJujrKPKv8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-01-07 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
Buy a DON'T INTERRUPT ME EUGENE mug or t-shirt: https://teespring.com/don-t-interrupt-me-eugene?pid=2&cid=2122

Contract: https://imgur.com/a/fSjfmVf

For more information on how this job was done, watch the rest of the series here: https://www.youtube.com/playlist?list=PLkVbIsAWN2lucdpXqcM4qW6ev60OSXdw4 Day 11, Day 17, and the video where he swapped out plywood for OSB are the three best.

🔵 We fix Macbooks & offer free estimates. https://rossmanngroup.com
🔵 You can send us your Macbook if you live far away! http://bit.ly/sendmacbook
🔵 Busy? We'll send you a box with a pre-paid shipping label inside of it to send us your machine! http://bit.ly/sendyourmacbook
🔵 We offer iPhone data recovery: http://bit.ly/2BDBX4G
🔵 We offer lab hard drive data recovery: http://bit.ly/labdatarecovery

👉 LEARN HOW TO DO THIS:
› In-person classes: https://bit.ly/classrg
› Beginner's guide: http://bit.ly/2k6uz84
› Support forum: $29/mo http://bit.ly/boardrepairforum

👉 Leave a tip for us via cryptocurrency if we've helped you out:
› Credit card: http://bit.ly/postamessage
›  Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4

