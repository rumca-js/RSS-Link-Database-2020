# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## ColdFusion Mixtape for 2020
 - [https://www.youtube.com/watch?v=8Yzh09V788I](https://www.youtube.com/watch?v=8Yzh09V788I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2020-01-07 00:00:00+00:00

0:00 Track 1 Burn Water - She Shines (Neo Flip)

3:34 Track 2 Burn Water - Angel

7:04 Track 3 Burn Water - Movement

10:01 Track 4 Burn Water - I Found U

Free Download (But if you'd like to support me that's cool too): https://burnwater.bandcamp.com/album/angel

» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Video credits for Angel:

» Original Video: "Ride" https://youtu.be/JsXrGxZf_C4
» Director, Producer, and Editor: Jesse Solomon
» Writer & Producer: Shango 
» Producer: Eric Ex
» Assistant Director: Oren Pine
» Starring: Taylor Snook, Shango, Mako & Steven Seagull

