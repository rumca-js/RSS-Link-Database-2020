# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## A Chat With Rebecca Kuang
 - [https://www.youtube.com/watch?v=FceAkFOhQ7M](https://www.youtube.com/watch?v=FceAkFOhQ7M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-01-08 00:00:00+00:00

The Poppy War: https://amzn.to/36B3S1y 
The Dragon Republic: https://amzn.to/2N4riVf
How To Change Your Mind: https://www.amazon.com/Change-Your-Mind-Consciousness-Transcendence/dp/1594204225

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene
 
P.O. Box 1016 Dublin, Ohio 43017
with the backup of:
715 Shawan falls Dr. Dublin, Ohio 43017

## ANOTHER BATMAN? GHIBLI RETURNS! NEW STAR WARS DIRECTION - FANTASY NEWS
 - [https://www.youtube.com/watch?v=HmmavvcWI8k](https://www.youtube.com/watch?v=HmmavvcWI8k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-01-07 00:00:00+00:00

Welcome to some fantasy news! 


Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene
 
P.O. Box 1016 Dublin, Ohio 43017
with the backup of:
715 Shawan falls Dr. Dublin, Ohio 43017


NEWS: 


Witcher Fight Choreographer: https://twitter.com/culturecrave/status/1212618759598301184?s=12


#Witcher Rankings by country: https://cdn.discordapp.com/attachments/500315229666934795/662377380396007447/IMG_20200102_203041.jpg


Dracula Reviews: https://www.independent.co.uk/arts-entertainment/tv/news/dracula-bbc-netflix-steven-moffat-mark-gatiss-claes-bang-a9267291.html?utm_medium=Social&utm_source=Facebook


Gretel and Hansel: https://www.youtube.com/watch?v=QZblQLhKcZQ


No Leto in #BirdsOfPrey: https://twitter.com/culturecrave/status/1212818174241992704?s=12


Witcher Podcast: https://twitter.com/LHissrich/status/1213176515896020993?s=19


Dolittle trailer: https://www.youtube.com/watch?v=zjm6rDgKNMY&feature=youtu.be


Dracula losing viewers: https://deadline.com/2020/01/dracula-loses-uk-viewers-ahead-of-netflix-release-1202820028/amp/


Batman Joker: https://www.comingsoon.net/movies/news/1116955-todd-phillips-wants-a-joker-universe-batman-movie


2 Studio #Ghibli films: https://www.ign.com/articles/2020/01/03/studio-ghibli-confirms-its-working-on-two-new-films-in-2020


Outlander season 5: https://www.youtube.com/watch?v=t745AinnAno


Hulk Back At Marvel: https://wegotthiscovered.com/movies/marvel-studios-rumored-gained-full-control-hulk-namor/


Star Wars Old Republic: https://screenrant.com/star-wars-movie-new-saga-setting-past-rumors/


Eternals concept art: https://twitter.com/CultureCrave/status/1213670340192174080/photo/1


Frozen highest grossing animated movie: https://variety.com/2020/film/box-office/frozen-2-biggest-animated-movie-ever-disney-box-office-1203456758/amp/


Batman begins filming: https://screenrant.com/batman-movie-jeffery-wright-commissioner-gordon-gotham-filming/


Joker wins golden globe: https://twitter.com/polygon/status/1214032848560279554?s=12


New Mutants Trailer: https://www.youtube.com/watch?v=W_vJhUAOFpI&feature=youtu.be


Fantasy Awards: https://www.reddit.com/r/Fantasy/comments/el04tk/2019_stabby_winners/

