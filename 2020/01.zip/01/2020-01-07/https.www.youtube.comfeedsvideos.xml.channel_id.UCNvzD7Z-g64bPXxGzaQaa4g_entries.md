# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Best Video Game Graphics THEN vs NOW [Part 4]
 - [https://www.youtube.com/watch?v=m0c4IHlDIEs](https://www.youtube.com/watch?v=m0c4IHlDIEs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-01-08 00:00:00+00:00

We continue our series where we compare game graphics both new and old. Join us on our never-ending nostalgia trip!
Subscribe for more: http://youtube.com/gameranxtv

## 10 HARDEST BOSSES In Recent Games
 - [https://www.youtube.com/watch?v=V1UcBWo3RVY](https://www.youtube.com/watch?v=V1UcBWo3RVY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-01-07 00:00:00+00:00

2019 and beyond saw many video game bosses that posed a challenge. Here are some of our favorite examples.
Subscribe for more: http://youtube.com/gameranxtv

