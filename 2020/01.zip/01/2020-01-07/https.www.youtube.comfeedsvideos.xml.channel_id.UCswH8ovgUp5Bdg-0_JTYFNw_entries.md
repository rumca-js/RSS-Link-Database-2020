# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Become Willing To Change!
 - [https://www.youtube.com/watch?v=02tD2qGOol4](https://www.youtube.com/watch?v=02tD2qGOol4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-01-08 00:00:00+00:00

Do you ever find it hard to change when you know it might be the right thing to do? Why?

My 12-day course on recovery will be available for FREE this January if you sign up here: https://www.onecommune.com/a/20323/cGftrerE

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

## GET OVER IT!
 - [https://www.youtube.com/watch?v=BEgYW8VCmx8](https://www.youtube.com/watch?v=BEgYW8VCmx8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-01-07 00:00:00+00:00

Gotta a resentment holding you back? This is how you figure out why it's bothering you and how to get over it.

Sign up to my free 12-day course here: https://www.onecommune.com/a/20323/cGftrerE 

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

