# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## How Do Wildfires Affect Animals?
 - [https://www.youtube.com/watch?v=jRdP6n1V2yU](https://www.youtube.com/watch?v=jRdP6n1V2yU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2020-01-08 00:00:00+00:00

How did the Australia fires start? How will they change the Earth? Find out how they may impact you and how to help.

DONATE: 
Save The Children: https://www.savethechildren.org.au/donate/more-ways-to-give/current-appeals/bushfire-emergency
Red Cross: https://www.redcross.org.au/campaigns/disaster-relief-and-recovery-donate
GIVIT: https://givit.worldsecuresystems.com/donate-funds
NSW Rural Fire Service: https://www.rfs.nsw.gov.au/volunteer/support-your-local-brigade

Subscribe: http:/bit.ly/asapsci
Created by: Mitchell Moffit and Gregory Brown

FOLLOW US!
Greg
Instagram: https://instagram.com/whalewatchmeplz 
Twitter: https://twitter.com/whalewatchmeplz 

Mitch
Instagram: https://instagram.com/mitchellmoffit
Twitter: https://twitter.com/mitchellmoffit 

AsapSCIENCE
Instagram: https://instagram.com/asapscience 
Facebook: https://facebook.com/asapscience 
Twitter: https://twitter.com/asapscience
Tumblr: https://asapscience.tumblr.com 

Send us stuff!
ASAPSCIENCE INC.
P.O. Box 93, Toronto P
Toronto, ON, M5S2S6

