# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Listen to Looch: memories of swearing
 - [https://www.youtube.com/watch?v=oXW_DqX6lZg](https://www.youtube.com/watch?v=oXW_DqX6lZg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-01-07 00:00:00+00:00

As we look back on The Current's history, Mary Lucia recalls some sweary moments in the station's early years.
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

