# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## OnePlus Concept One Phone: Disappearing Cameras?
 - [https://www.youtube.com/watch?v=Jp8bBZHDULA](https://www.youtube.com/watch?v=Jp8bBZHDULA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-01-07 00:00:00+00:00

OnePlus Concept One isn't a real phone... but in a future with many cameras in every phone, this tech could be awesome!

Electrochromic tech in the roof of a Mclaren: https://youtu.be/nmnTAOU44SI?t=577

MKBHD Merch: http://shop.MKBHD.com

Video Gear I use: http://kit.co/MKBHD/video-gear#recom...
Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Jordyn Edmonds http://smarturl.it/jordynedmonds 
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

