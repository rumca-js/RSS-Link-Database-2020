# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## This VR Accessory was BANNED by the US Government
 - [https://www.youtube.com/watch?v=VltBOKxpdts](https://www.youtube.com/watch?v=VltBOKxpdts)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-01-07 00:00:00+00:00

Join my discord for good times
https://discord.gg/thrill
MY STREAM: 
https://www.twitch.tv/thrilluwu
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill

Erik Hartley's Video: https://www.youtube.com/watch?v=mtFAOANWpSw&t=148s
Lonn Gameplay: https://www.youtube.com/watch?v=1w_Yn3IdX88

HTC Vive Cosmos Price cut

Feel Real falls under Ban in United States by FDA
https://www.roadtovr.com/feelreal-vr-scent-mask-vaping-fda-ban/
Pimax Artisan

Pico Neo 2 
https://uploadvr.com/ces-2020-pico-neo-2-specs/
PS5 and PSVR

Facebook's take on AR and VR in the future
https://uploadvr.com/michael-abrash-the-information-interview-2020/

