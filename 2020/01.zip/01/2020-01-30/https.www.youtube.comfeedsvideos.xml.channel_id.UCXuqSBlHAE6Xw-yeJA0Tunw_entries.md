# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Is This The Worst Rated Game EVER? - WAN Show Jan 31, 2020
 - [https://www.youtube.com/watch?v=4YIkw7vBGyk](https://www.youtube.com/watch?v=4YIkw7vBGyk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-01-31 00:00:00+00:00

Monitor and manage your PC in real-time with Pulseway! Create your free account today at https://lmg.gg/pulseway

Save 15% today with offer code LTT on Displate at https://lmg.gg/displatewan

Buy an LTT shirt, hoodie, hat, and even our own water bottle at https://lmg.gg/wanlttstore

LTX2020, Save the Date - August 8+9, 2020 - https://www.ltxexpo.com/

Check out Carpool Critics, our new movie podcast: http://carpoolcritics.libsyn.com/

Podcast Download: http://traffic.libsyn.com/linustechtips/Is_This_The_Worst_Rated_Game_EVER_-_WAN_Show_Jan_31_2020.mp3

Timestamps: (Courtesy of Lime12387)

0:18 - Topics
0:52 - Intro
1:33 - Luke and James catch up
2:08 - James perspective on Linus "I'm thinking of retiring" stream
4:48 - new LMG channel 
5:27 - Carpool Critics podcast 
8:58 - Luke blizzard un-banned
15:35 - Warcraft 3 Reforged
24:40 - Samsung folding phone
31:58 - Huawei UK 5G
39:56 - SPONSORS
   - 39:58 - Pulseway
   - 40:36 - Displate
   - 43:08 - LTTSTORE.COM !!!!
   - 45:10 - ( lttstore.com lanyard hack)
46:42 - Android air drop
54:46 - EVE tech company
1:01:28 - Super Chats

## FINALLY Wireless Headphones that Sound GREAT - Massdrop x THX Panda
 - [https://www.youtube.com/watch?v=rei5vMQmD4Q](https://www.youtube.com/watch?v=rei5vMQmD4Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-01-30 00:00:00+00:00

Thanks, RING for sponsoring today's video! Get the RING Welcome Kit today at https://ring.com/LTT

Add Honey for FREE and start saving today at https://joinhoney.com/ltt
Thanks, Honey for sponsoring!

Wireless headphones are great as you get music without the wire but the audio quality can be hit or miss. What happens when you install THX amplifiers in the and take out the fluff? You get the Massdrop x THX Panda Wireless Headphones!

Pre-Order the Massdrop X THX Panda Headphones on INDIEGOGO at https://dro.ps/linustechtips-panda

Buy Bose Quietcomfort 35 II Noise Cancelling Wireless Headphones
On Amazon (PAID LINK): https://geni.us/MC4kmT
On Newegg (PAID LINK): https://geni.us/Q2W3

Buy Sony WH1000XM3 Noise Cancelling Wireless Headphones
On Amazon (PAID LINK): https://geni.us/kbo4k
On Newegg (PAID LINK): https://geni.us/B66waLb

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1150622-finally-wireless-headphones-that-sound-great/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Come see us at LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

