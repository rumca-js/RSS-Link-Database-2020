# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## GAME MAKERS MORE INTERESTED IN PS5? GOOGLE RESPONDS TO NO STADIA ANNOUNCEMENTS & MORE
 - [https://www.youtube.com/watch?v=8m4DAGvYyiY](https://www.youtube.com/watch?v=8m4DAGvYyiY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-01-31 00:00:00+00:00

No new Nintendo Switch model coming from Nintendo in 2020, some Resident Evil 8 rumors, next gen PS5/Xbox Series X battle heats up, and more in a week full of gaming news.
Subscribe for more: http://youtube.com/gameranxtv 

*Jakes twitter: https://twitter.com/jakebaldino 
*Instagram: https://goo.gl/HH6mTW 

 discord.gg/gameranx 

 Weekly giveaway link: https://goo.gl/forms/a7zCtr1HuTkzWuOo2 


**A family in need: https://www.gofundme.com/f/in-memory-of-thomas-valva


 ~~~~STORIES~~~~




Devs more interested in PS5?
https://wccftech.com/gdc-survey-devs-more-interested-in-ps5-than-xsx-or-even-switch-40-think-egs-will-be-a-success/

No new Switch in 2020
https://www.cnet.com/news/nintendo-says-we-wont-get-new-switch-model-in-2020/

Animal Crossing switch
https://www.youtube.com/watch?v=i5GP4G_NW8Q

GOOGLE RESPONDS TO NO STADIA ANNOUNCEMENTS
https://www.gamesindustry.biz/articles/2020-01-30-google-responds-to-complaints-of-slow-stadia-announcements

AbleGamers new wheelchair device:
https://youtu.be/FgKNWc-EpHQ

**Submit your best PHOTO MODE screenshots here:
https://forms.gle/L4FehjBzYjQEiSc39


Watch Dogs interview
https://twitter.com/BBCClick/status/1221013218321207296?ref_src=twsrc%5Etfw%7Ctwcamp%5Etweetembed%7Ctwterm%5E1221013218321207296&ref_url=https%3A%2F%2Fwww.videogameschronicle.com%2Fnews%2Fbbc-conducts-worlds-first-in-game-interview-in-watch-dogs-legion%2F

Disintigration open beta 
https://www.disintegrationgame.com/beta/?utm_source=Google_Search&utm_medium=paid&utm_campaign=beta_signup&utm_term=us&gclid=Cj0KCQiAvc_xBRCYARIsAC5QT9kycIH8KLqEE_6Dl_BTNh1zI_YVyoUbnXK_iM8AZuNNrqe4izDwWEoaAookEALw_wcB

Apex Legends Revenant story trailer
https://youtu.be/QzfsGxrCD4o

FF7 trailer
https://youtu.be/sz9QWTcbXYE



From earlier in the week, RE8
https://www.eurogamer.net/articles/2020-01-28-sounds-like-resident-evil-8-will-be-in-first-person-again

**A family in need: https://www.gofundme.com/f/in-memory-of-thomas-valva

## 10 WEIRD Gaming Stories of January 2020
 - [https://www.youtube.com/watch?v=zoa1P2ua_tM](https://www.youtube.com/watch?v=zoa1P2ua_tM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-01-30 00:00:00+00:00

2020 has only just begun and gaming is just as interesting as ever. Here are some crazy recent gaming news stories.
Subscribe for more: http://youtube.com/gameranxtv

Credit:
https://clips.twitch.tv/SmoothAltruisticArmadilloMVGame?tt_content=url&tt_medium=redt

