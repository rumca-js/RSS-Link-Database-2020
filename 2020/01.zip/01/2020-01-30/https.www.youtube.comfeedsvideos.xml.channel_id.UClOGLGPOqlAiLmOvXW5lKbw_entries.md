# Source:Mandalore Gaming, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw, language:en-US

## Blade Runner Review
 - [https://www.youtube.com/watch?v=zPyqInHrHR8](https://www.youtube.com/watch?v=zPyqInHrHR8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw
 - date published: 2020-01-31 00:00:00+00:00

The Blade Runner review covers the 1997 Westwood adventure game that was recently re-released on GOG with restored content. Enhance.
Support the channel at: https://www.patreon.com/mandaloregaming or https://www.paypal.me/MandaloreGaming
I take video suggestions at mandaloremovies@gmail.com
Twitter: https://twitter.com/Lord_Mandalore
#BladeRunner #BladeRunnerReview #BladeRunnerGame #BladeRunnerPC #BladeRunnerAdventureGame

00:00 - Intro
00:35 - Background
00:56 - Game Premise
2:44 - Visuals
5:05 - Music & Sound Design
8:08 - Gameplay Mechanics
13:16 - Story (SPOILERS)
17:43 - Conclusions
18:21 - Credits
19:27 - Scorpions

