# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Gretel & Hansel - Movie Review
 - [https://www.youtube.com/watch?v=i1pv8qq2LYQ](https://www.youtube.com/watch?v=i1pv8qq2LYQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-01-31 00:00:00+00:00

Thanks Audible for sponsoring.  Visit https://www.audible.com/jahns or text jahns to 500-500. Start listening with a 30-day Audible trial. Choose 1 audiobook and 2 Audible Originals absolutely free.

A new telling of the Hansel & Gretel Grimm fairy tale. Here's my review of GRETEL & HANSEL!

#GretelAndHansel

