# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## How To Tell If Someone Is A Psychopath | Random Thursday
 - [https://www.youtube.com/watch?v=nb2c7gj2Vs4](https://www.youtube.com/watch?v=nb2c7gj2Vs4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2020-01-30 00:00:00+00:00

Do you like to intentionally hurt others? Do you lack empathy of any kind? Do you like bitter foods? If so, you might be a psychopath.

Want to support the channel? Check these out!
Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
Fun and nerdy merch: http://www.answerswithjoe.com/shirts

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

http://www.scholarpedia.org/article/Psychopathy

https://www.discovermagazine.com/mind/into-the-mind-of-a-psychopath

https://www.sciencedirect.com/science/article/abs/pii/S0195666315300428

https://www.scienceofpeople.com/psychopath/ 

https://blogs.royalsociety.org/inside-science/2017/10/09/why-do-some-people-become-psychopaths/

https://psychcentral.com/news/2018/03/17/why-do-people-become-psychopaths/12193.html

https://www.quora.com/What-s-the-difference-between-a-psychopath-and-a-sociopath-1

https://www.psychologytoday.com/us/blog/mindmelding/201706/9-clues-you-may-be-dealing-psychopath

