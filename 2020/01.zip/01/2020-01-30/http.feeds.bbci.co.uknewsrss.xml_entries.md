# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## When a lottery 'wins' sick babies life-saving drugs
 - [https://www.bbc.co.uk/news/world-us-canada-51181840](https://www.bbc.co.uk/news/world-us-canada-51181840)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 21:53:14+00:00

The company behind a gene therapy for muscle-wasting disease SMA will give out 100 doses via lottery.

## Leave or remain - who could be on the move on deadline day?
 - [https://www.bbc.co.uk/sport/football/51270867](https://www.bbc.co.uk/sport/football/51270867)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 20:03:47+00:00

It is deadline day on Friday but which players are likely to be on the move? BBC Sport looks at some of the potential candidates.

## All the completed deals on deadline day
 - [https://www.bbc.co.uk/sport/50965300](https://www.bbc.co.uk/sport/50965300)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 19:20:21+00:00

Check out all the signings during the January transfer window in England, Scotland and around Europe.

## Your pictures on the theme of 'electric'
 - [https://www.bbc.co.uk/news/in-pictures-51308806](https://www.bbc.co.uk/news/in-pictures-51308806)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 16:15:09+00:00

Each week, we publish a gallery of readers' pictures on a set theme. This week it is "electric".

## Shane Fitzsimmons: 'Tireless' fire chief steering Australians through disaster
 - [https://www.bbc.co.uk/news/world-australia-51230844](https://www.bbc.co.uk/news/world-australia-51230844)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 16:11:18+00:00

Fire chief Shane Fitzsimmons has worked tirelessly and "masterfully" to save lives, close observers say.

## Inaccessible first-floor Wisbech property for sale for £100
 - [https://www.bbc.co.uk/news/uk-england-cambridgeshire-51310566](https://www.bbc.co.uk/news/uk-england-cambridgeshire-51310566)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 14:58:33+00:00

You cannot get in to the bricked-up first-floor room - but you can buy it for £100 if you want it.

## Battle of Britain ace fighter pilot Paul Farnes dies aged 101
 - [https://www.bbc.co.uk/news/uk-england-hampshire-51306750](https://www.bbc.co.uk/news/uk-england-hampshire-51306750)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 12:29:05+00:00

Wing Cdr Paul Farnes was the last surviving "ace pilot" and died at his home in Hampshire.

## Coronavirus: Flight taking Britons out of Wuhan is delayed
 - [https://www.bbc.co.uk/news/uk-51304204](https://www.bbc.co.uk/news/uk-51304204)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 12:23:56+00:00

Downing Street says it is working with China to get UK citizens out of the coronavirus-hit city.

## UK interest rates kept on hold at 0.75%
 - [https://www.bbc.co.uk/news/business-51309256](https://www.bbc.co.uk/news/business-51309256)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 12:14:28+00:00

In Mark Carney's final meeting as Bank of England governor, policymakers vote 7-2 to keep rates unchanged.

## 'Bald' hedgehog returns to wild after re-growing spines
 - [https://www.bbc.co.uk/news/uk-scotland-tayside-central-51309748](https://www.bbc.co.uk/news/uk-scotland-tayside-central-51309748)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 12:08:43+00:00

The animal weighed just 324g and was missing its fur and most of its spines when it was found in Comrie.

## North at centre for Wales against Italy with debutant McNicholl on wing
 - [https://www.bbc.co.uk/sport/rugby-union/51306672](https://www.bbc.co.uk/sport/rugby-union/51306672)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 12:00:57+00:00

George North starts at centre in Wales' Six Nations opener against Italy, with uncapped Johnny McNicholl taking his place on the wing.

## Coronavirus: Death toll rises as virus spreads to every Chinese region
 - [https://www.bbc.co.uk/news/world-asia-china-51305526](https://www.bbc.co.uk/news/world-asia-china-51305526)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 11:58:59+00:00

The death toll now stands at 170, with more than 7,700 cases confirmed in China.

## Novak Djokovic beats Roger Federer to reach Australian Open final
 - [https://www.bbc.co.uk/sport/tennis/51309788](https://www.bbc.co.uk/sport/tennis/51309788)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 11:34:58+00:00

Novak Djokovic beats Roger Federer in straight sets to reach the final of the Australian Open.

## PG Tips could be sold by Unilever as cuppa goes out of fashion
 - [https://www.bbc.co.uk/news/business-51309566](https://www.bbc.co.uk/news/business-51309566)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 11:19:18+00:00

Consumer goods giant Unilever says traditional tea sales are slowing as consumers change their habits.

## Greta Thunberg to trademark 'Fridays for Future'
 - [https://www.bbc.co.uk/news/world-europe-51308536](https://www.bbc.co.uk/news/world-europe-51308536)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 10:21:25+00:00

The climate change activist said people had tried to sell products and make money in the movement's name.

## Sarah Sands: Radio 4's Today editor to stand down
 - [https://www.bbc.co.uk/news/entertainment-arts-51307876](https://www.bbc.co.uk/news/entertainment-arts-51307876)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 10:15:28+00:00

Sarah Sands announces decision to leave a day after the BBC announced massive job cuts.

## Muguruza beats Halep to set up Australian Open final with Kenin
 - [https://www.bbc.co.uk/sport/tennis/51307136](https://www.bbc.co.uk/sport/tennis/51307136)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 08:24:25+00:00

Garbine Muguruza continues her recent revival by reaching the Australian Open final with a straight-set win over Romania's Simona Halep.

## Kobe Bryant: Vanessa 'completely devastated' by husband's death
 - [https://www.bbc.co.uk/news/world-us-canada-51306356](https://www.bbc.co.uk/news/world-us-canada-51306356)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 08:12:36+00:00

Vanessa makes her first comments after Sunday's crash that also killed one of the couple's daughters.

## Nike Vaporfly: World Athletics set to rule on running shoe range
 - [https://www.bbc.co.uk/sport/athletics/51292147](https://www.bbc.co.uk/sport/athletics/51292147)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 07:53:23+00:00

World Athletics is set to tighten regulations of high-tech running shoes, including the controversial Nike Vaporfly range.

## Super Bowl 2020: Steve the Madman meets Kansas City Chiefs & San Francisco 49ers stars
 - [https://www.bbc.co.uk/sport/av/american-football/51295045](https://www.bbc.co.uk/sport/av/american-football/51295045)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 06:22:54+00:00

Stevo the Madman takes a tour of Super Bowl media day in a bid to ask stars of the Kansas City Chiefs and San Francisco 49ers the silliest questions they will face.

## US-Mexico border: 'Longest ever' smuggling tunnel discovered
 - [https://www.bbc.co.uk/news/world-us-canada-51304861](https://www.bbc.co.uk/news/world-us-canada-51304861)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 06:11:37+00:00

The tunnel had rail track, drainage and air ventilation systems, and stretched for 4,309ft (1,313m).

## Prison officers describe struggles with anxiety and depression
 - [https://www.bbc.co.uk/news/uk-51301775](https://www.bbc.co.uk/news/uk-51301775)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 06:00:11+00:00

Figures show a rise in prison officers in England and Wales suffering from mental health problems.

## Coronavirus Wuhan diary: Living alone in a city gone quiet
 - [https://www.bbc.co.uk/news/world-asia-china-51276656](https://www.bbc.co.uk/news/world-asia-china-51276656)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 05:58:55+00:00

Loneliness, emptiness, and hyper-hygiene - one woman describes life in a city gone quiet.

## The papers: ITV anchor quits and HS2 'to get green light'
 - [https://www.bbc.co.uk/news/blogs-the-papers-51304606](https://www.bbc.co.uk/news/blogs-the-papers-51304606)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 05:58:45+00:00

The papers focus on HS2's future, why an ITV newsreader is stepping down, and job cuts at BBC News.

## Coronavirus: Scientists race to develop a vaccine
 - [https://www.bbc.co.uk/news/health-51299735](https://www.bbc.co.uk/news/health-51299735)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 05:04:30+00:00

US researchers are already working on a vaccine against the new virus that has emerged in China.

## Sun's surface seen in remarkable new detail
 - [https://www.bbc.co.uk/news/science-environment-51305216](https://www.bbc.co.uk/news/science-environment-51305216)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 02:49:01+00:00

A telescope on top of a Hawaiian volcano acquires remarkable pictures of our convulsing star.

## Most children sleep with mobile phone beside bed
 - [https://www.bbc.co.uk/news/education-51296197](https://www.bbc.co.uk/news/education-51296197)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 01:56:02+00:00

The devices are "dominating" the lives of young people, says research.

## Sweets and football: How the UK celebrated joining Europe
 - [https://www.bbc.co.uk/news/uk-politics-51212714](https://www.bbc.co.uk/news/uk-politics-51212714)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 01:31:05+00:00

A look at the 11-day "Fanfare for Europe" that followed British entry into the EEC in 1973.

## Brexit: Are pet passports still valid? And other questions
 - [https://www.bbc.co.uk/news/uk-politics-uk-leaves-the-eu-51267979](https://www.bbc.co.uk/news/uk-politics-uk-leaves-the-eu-51267979)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 01:29:29+00:00

What will happens after Brexit day? Your questions answered on expats, driving, pensions and more.

## Brexit: Bells and bunting, or shedding a tear - how will you mark it?
 - [https://www.bbc.co.uk/news/uk-51272017](https://www.bbc.co.uk/news/uk-51272017)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 01:26:04+00:00

Will it be celebrations or commiserations on Brexit day? Here are the ways some people will mark the event.

## Brexit: What will change after Friday, 31 January?
 - [https://www.bbc.co.uk/news/uk-politics-51194363](https://www.bbc.co.uk/news/uk-politics-51194363)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 01:22:57+00:00

Brexit will happen at 23:00 on Friday, 31 January, but what changes will we notice?

## Mumford & Sons: The UK's live music scene needs 'sweat on the walls'
 - [https://www.bbc.co.uk/news/newsbeat-51282496](https://www.bbc.co.uk/news/newsbeat-51282496)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 01:19:16+00:00

Ben Lovett shows us around his new venue and explains how he wants to help ensure the future of the UK's live music scene.

## The nursery putting fitness at the heart of learning
 - [https://www.bbc.co.uk/news/education-51194309](https://www.bbc.co.uk/news/education-51194309)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 01:14:12+00:00

Children who are stronger and fitter learn faster, say teachers at a Somerset nursery.

## Running Stories: 'I want to tackle male depression through running'
 - [https://www.bbc.co.uk/news/newsbeat-51301575](https://www.bbc.co.uk/news/newsbeat-51301575)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 01:08:39+00:00

Nii Lartey is an entrepreneur who says he was facing "a lot of negativity and self-doubt". He set up a running group to help other men open-up about issues.

## What ancient Rome may teach on post-Brexit tourism
 - [https://www.bbc.co.uk/news/business-51279876](https://www.bbc.co.uk/news/business-51279876)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 01:06:39+00:00

As more Britons holiday at home and European visitor numbers fall, could we learn from ancient Rome?

## Northern: Three things that went wrong at the rail firm
 - [https://www.bbc.co.uk/news/business-51302755](https://www.bbc.co.uk/news/business-51302755)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 01:04:29+00:00

Why has the network been re-nationalised, and will this fix its problems?

## Break My Stride singer 'thrilled' by TikTok revival
 - [https://www.bbc.co.uk/news/entertainment-arts-51293945](https://www.bbc.co.uk/news/entertainment-arts-51293945)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 00:37:25+00:00

Matthew Wilder was a one-hit-wonder in 1983, but his song's suddenly become a big deal on TikTok.

## Surrogates campaign for senators stuck in Washington
 - [https://www.bbc.co.uk/news/world-us-canada-51303005](https://www.bbc.co.uk/news/world-us-canada-51303005)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 00:31:27+00:00

Celebrities, politicians, and pets step up while senators are sidelined by impeachment duty

## The Goldfish Club: The exclusive society of air-sea crash survivors
 - [https://www.bbc.co.uk/news/uk-england-50307383](https://www.bbc.co.uk/news/uk-england-50307383)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 00:25:23+00:00

The Goldfish Club only admits flyers who have ditched into the sea, and survived to tell the tale.

## The music photographer trusted by the stars
 - [https://www.bbc.co.uk/news/in-pictures-51263999](https://www.bbc.co.uk/news/in-pictures-51263999)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 00:19:59+00:00

Jim Marshall's pictures capture the true face of music in the 1960s and 70s.

## Trachoma: A race to save James's eyesight
 - [https://www.bbc.co.uk/news/world-africa-51269502](https://www.bbc.co.uk/news/world-africa-51269502)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 00:07:01+00:00

A 15-minute surgery can prevent blindness from trachoma, which affects two million people worldwide.

## Super Bowl 2020: Vince Lombardi, the story behind the name on NFL's biggest prize
 - [https://www.bbc.co.uk/sport/american-football/51281357](https://www.bbc.co.uk/sport/american-football/51281357)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 00:02:30+00:00

Vince Lombardi is an NFL legend - his name is on the Super Bowl trophy. But the legacy he left behind goes beyond the sport, too.

## A holiday camp for India's captive elephants
 - [https://www.bbc.co.uk/news/world-asia-india-47238540](https://www.bbc.co.uk/news/world-asia-india-47238540)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-30 00:01:25+00:00

Once a year, captive elephants get pampered at the camp in India which has become a popular event.

