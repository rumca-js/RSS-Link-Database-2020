# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Kwiat Jabłoni - koncert (MUZO.FM)
 - [https://www.youtube.com/watch?v=hWtkxBB9Qcs](https://www.youtube.com/watch?v=hWtkxBB9Qcs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-01-31 00:00:00+00:00

Kwiat Jabłoni na żywo w MUZO.FM. Kasia i Jacek Sienkiewiczowie grają utwory Niemożliwe i Nic więcej z debiutanckiej płyty duetu Kwiat Jabłoni. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Kwiat Jabłoni: http://www.facebook.com/kwiatjabloni
Instagram Kwiat Jabłoni: http://www.instagram.com/kwiatjabloni
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm 

#popolsku

## Stach Bukowski - Lew live - MUZO.FM
 - [https://www.youtube.com/watch?v=4QA3uymHxtc](https://www.youtube.com/watch?v=4QA3uymHxtc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-01-31 00:00:00+00:00

Stach Bukowski - Lew na żywo w MUZO.FM. Stach Bukowski to młody zespół z Olsztyna zakochany w muzyce retro, wychowany na piosenkach Zbigniewa Wodeckiego, Alicji Majewskiej i Anny Jantar. Gra rocka, ale inspiruje się również muzyką klasyczną, rapem i polskim big beatem. Muzycy tworzą z rockandrollowym polotem i mają ucho do chwytliwych melodii. Stach śpiewa i gra na perkusji, brawurowo zasuwa na basie, a Robert odpowiada za precyzyjne gitarowe riffy. 


Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Stach Bukowski: http://www.facebook.com/stachbukowski
Instagram Stach Bukowski: http://www.instagram.com/stachbukowski
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm

Stach Bukowski Lew tekst

Zw.1
Zachód, słońca pół, schody ciągną w dół
Ten sam numer powtarzany setny raz nie ciąży mu
W progu stoi lew, niebezpieczny jest
Wygłodniały patrzy na ofiarę, którą zaraz zje 

Nie słyszy, nie poznaje, ludzi tu 
Każdy o sobie, sobie pomnik, sobie dwór

Ref.
Kolejna nowa gra, ta na dwa
Kto spojrzy w oczy zatrzyma czar
Poruszy gwiazdy ile się da 
Proszę ognia daj 

Nieśmiało mówię pas, to nie tak 
A może ktoś już rozpoczął bal 
Pusty horyzont ile się da 
Proszę ognia daj, proszę ognia daj 
 
Zw.2 
Ona z drugiej mknie, wciąż poprawia brew
Z jedną myślą tylko idzie tam i nie zatrzyma się
Mała szczęścia nić, karuzeli rytm 
Przywiązały ją do tego, który znowu nie chce żyć 
Ryzyko wyższe niż na poker stars, 
w otwarte karty los uśmiechnął się choć raz 
Ref.x2 

#popolsku

## The Paper Kites - Arms live - MUZO.FM
 - [https://www.youtube.com/watch?v=2vOxUgU-SKY](https://www.youtube.com/watch?v=2vOxUgU-SKY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-01-31 00:00:00+00:00

The Paper Kites - Arms na żywo, akustycznie w MUZO.FM. Utwór The Paper Kites Arms pochodzi z płyty The Paper Kites On the Train Ride Home. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook The Paper Kites: http://www.facebook.com/thepaperkitesband
Instagram The Paper Kites: http://www.instagram.com/thepaperkites
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm

## Blauka - Zawzięcie live - MUZO.FM
 - [https://www.youtube.com/watch?v=oGL7XiHRrHM](https://www.youtube.com/watch?v=oGL7XiHRrHM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-01-30 00:00:00+00:00

Blauka - Zawzięcie na żywo w MUZO.FM. Utwór Blauka Zawzięcie pochodzi z debiutanckiej płyty grupy Blauka - Miniatura. Blauka to polski zespół założony przez duet pisarsko-kompozytorski w osobie Georginy Tarasiuk- autorki tekstów i muzyki oraz Piotra Lewańczyka- basisty i producenta muzycznego.

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Blauka: http://www.facebook.com/tojestblauka
Instagram Blauka: http://www.instagram.com/tojestblauka
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm

Blauka - Zawzięcie tekst

Zamknięte oczy ma choć nie śpi
Próbuje nie spinać mięśni
Poznać nie daje mu po sobie 
Że wie i tak mu nie powie
Nie powie
Nie powie

A ona kocha go 
Zawzięcie jedynie za rękę
A on kocha ją zażarcie
Utknęły mu słowa w gardle

A ona kocha go 
Zawzięcie jedynie za rękę
A on kocha ją zażarcie
Utknęły mu słowa w gardle 

Inna wygląda lepiej pewnie
Tak za nim przez okno tęsknie
Jego telefon w nocy warczy 
Niechciane wyją alarmy 
Alarmy
Alarmy 

A ona kocha go 
Zawzięcie jedynie za rękę
A on kocha ją zażarcie
Utknęły mu słowa w gardle

A ona kocha go 
Zawzięcie jedynie za rękę
A on kocha ją zażarcie
Utknęło mu nieraz w gardle

A ona kocha go 
Zawzięcie jedynie za rękę
A on kocha ją zażarcie
Utknęły mu słowa w gardle

A ona kocha go 
Zawzięcie jedynie za rękę
A on kocha ją zażarcie
Utknęły mu słowa w gardle 

#popolsku

## sanah - Cząstka - live MUZO.FM
 - [https://www.youtube.com/watch?v=mw4hAddSCq0](https://www.youtube.com/watch?v=mw4hAddSCq0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-01-30 00:00:00+00:00

sanah Cząstka na żywo w MUZO.FM. Specjalna wersja piosenki sanah Cząstka pochodzi z wyjątkowej sesji w studiu radia MUZO.FM. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Sanah: http://www.facebook.com/sanahmusic
Instagram Sanah: http://www.instagram.com/sanahmusic
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm


sanah - Cząstka tekst 

Widzę jak zerkasz
Takie dziwne to
Chyba myli Cię wzrok 

Przecież tutaj
Tyle innych pań 
I miejsca dla twoich rąk 
 
Po imprezie zabierz mnie na kawę
Powiem co i jak
Skąd to morze łez
Bo ja nadal pojąć nie potrafię 
Jak łatwo przyszło ci tak zostawić mnie

Jak kawałki porcelany kruszę się
Więc proszę powiedz ze choć cząstkę mnie
Chcesz

Gdy ściany iskrzą 
Czuły dla mnie bądź
Weź mnie do tańca plis

A ja w tej kiecce
Jeszcze z ubiegłych świąt 
Ulotnię się tak jak dym
 
Po imprezie zabierz mnie na kawę
Powiem co i jak
Skąd to morze łez
Bo ja nadal pojąć nie potrafię 
Jak łatwo przyszło ci tak zostawić mnie

Jak kawałki porcelany kruszę się
Więc proszę powiedz ze choć cząstkę mnie
Chcesz

Troszeczkę boli
Gdy obok stoi
Szczupła jak osa
Chce papierosa

Dajesz jej ogień
Gadacie sobie
Ja przezroczysta 
Nie widzisz mnie 

Po imprezie zabierz mnie na kawę
Powiem co i jak
Skąd to morze łez
Bo ja nadal pojąć nie potrafię 
Jak łatwo przyszło ci tak zostawić mnie 

#popolsku

