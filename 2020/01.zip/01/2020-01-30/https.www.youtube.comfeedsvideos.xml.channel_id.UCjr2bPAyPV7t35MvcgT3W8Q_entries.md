# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## How to protect privacy on your phone in 5 minutes | Tutorial for normies
 - [https://www.youtube.com/watch?v=tkY9dhOF2WU](https://www.youtube.com/watch?v=tkY9dhOF2WU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2020-01-31 00:00:00+00:00

Quick and easy 5-minute-long mobile OS privacy tutorials for all the normies out there.
Support me through Patreon: https://www.patreon.com/thehatedone 
- or donate anonymously:

Monero: 84DYxU8rPzQ88SxQqBF6VBNfPU9c5sjDXfTC1wXkgzWJfVMQ9zjAULL6rd11ASRGpxD1w6jQrMtqAGkkqiid5ef7QDroTPp

Bitcoin: 1HkDxXAVDFhBHSyRjam5WW5uoY88sxn5qz

How to protect privacy on your smartphone (Android or iPhone). This is a mobile privacy tutorial in 5 minutes for normies and non-tech-savvy people. Get as much privacy as possible with install-and-forget approach - in other words - get the most amount of privacy on your phone while doing minimal work.

Sources:

Application firewall
NetGuard for Android https://play.google.com/store/apps/details?id=eu.faircode.netguard&hl=en
NetGuard on F-Droid https://f-droid.org/en/packages/eu.faircode.netguard/
Lockdown for iOS https://apps.apple.com/us/app/lockdown-apps/id1469783711

Encrypt DNS on Android https://developers.google.com/speed/public-dns/docs/using#android 
DNSCloak for iOS t encrypt DNS system-wide https://apps.apple.com/us/app/dnscloak-secure-dns-client/id1452162351

Limit Ad Tracking on iPhone https://support.apple.com/en-us/HT202074#iOS
Turn off ad personalization on your Google Account https://support.google.com/ads/answer/2662922?hl=en

Disable Location services on Android https://lifehacker.com/psa-your-phone-logs-everywhere-you-go-heres-how-to-t-1486085759
Disable Location Services on iPhone https://support.apple.com/en-us/HT207092

OsmAnd (OpenStreet Map Automated Navigation Directions) https://osmand.net/
OsmAnd on F-Droid https://f-droid.org/en/packages/net.osmand.plus/

DuckDuckGo Privacy Browser https://duckduckgo.com/app
DDG Privacy Browser on F-Droid https://f-droid.org/en/packages/com.duckduckgo.mobile.android/

Signal Private Messenger https://signal.org/

Credits:
Music by CO.AG Music https://www.youtube.com/channel/UCcavSftXHgxLBWwLDm_bNvA

Follow me:
https://twitter.com/The_HatedOne_
https://www.bitchute.com/TheHatedOne/
https://www.reddit.com/r/thehatedone/
https://www.minds.com/The_HatedOne

The footage and images featured in the video were for critical analysis, commentary and parody, which are protected under the Fair Use laws of the United States Copyright act of 1976.

