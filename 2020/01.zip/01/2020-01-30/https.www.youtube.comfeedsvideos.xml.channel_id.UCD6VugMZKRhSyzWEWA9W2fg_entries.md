# Source:SssethTzeentach, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCD6VugMZKRhSyzWEWA9W2fg, language:en-US

## SYNTHETIK REVIEW | ▼LTRA▼IOLENCE EDITION™
 - [https://www.youtube.com/watch?v=r5tsEJgPn30](https://www.youtube.com/watch?v=r5tsEJgPn30)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCD6VugMZKRhSyzWEWA9W2fg
 - date published: 2020-01-31 00:00:00+00:00

Any violence committed by a machine? 
A glitch, an anomaly, a programming error.
Any violence committed by a man?
Perfectly natural.

Buy it on
GOG: https://af.gog.com/game/synthetik_legion_rising?as=1630110786
Steam: https://store.steampowered.com/app/528230/SYNTHETIK_Legion_Rising/

If it's too expensive right now, wait until later February.
It'll be on sale.

-----------------------
Send Sseth Shekels: https://www.paypal.me/SsethTzeentachGB
Send Sseth Shekels per video:  https://www.patreon.com/Sseth
Send Sseth Shekels / crypto: https://www.subscribestar.com/ssethtzeentach

Website: https://ssethtzeentach.com/
Twitter: https://twitter.com/SsethTzeentach
FB: https://www.facebook.com/sseth672/

