# Source:UpIsNotJump, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFLwN7vRu8M057qJF8TsBaA, language:en-US

## Skyrim VR is An Absolute Nightmare - This Is Why - Remastered
 - [https://www.youtube.com/watch?v=xRbOsXg0ISg](https://www.youtube.com/watch?v=xRbOsXg0ISg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLwN7vRu8M057qJF8TsBaA
 - date published: 2020-01-31 00:00:00+00:00

I return to review the biggest VR game of last year and remaster it so it can't be removed from YouTube. Skyrim VR. I may describe Skyrim VR like it is an absolute nightmare but listen closely and you’ll be able to tell its all for fun, this game is the best and easily the best VR game by miles. This is why forever

All my music and sound is from here: https://www.epidemicsound.com/referral/8pficg

Patreon: https://www.patreon.com/user?u=2784847 
Twitter: https://twitter.com/upisnotjump 
My amazing poster: https://www.pixelempire.com/products/upisnotjump

Skyrim VR had none of the problems Fallout 4 VR had on release, I discuss all the things in Skyrim VR that are an absolute nightmare but overall it vastly improves Skyrim vanilla and Bethesda did a great job. I do feela  few things were missing from the release of Skyrim VR but these can easily be fixed with a few mods, I consider modding Skyrim VR an absolute necessity , without it perhaps Skyrim VR really is an absolute nightmare…

If you enjoy my ‘This Is Why’ series please do let me know what you like and what I should do more of, I will eventually move away from VR for a little while and start doing commentary on gameplay, it will just be me having highly edited adventures, I won’t let the quality drop.

