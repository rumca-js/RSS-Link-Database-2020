# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Joe Rogan Responds to Bernie Sanders Endorsement Controversy
 - [https://www.youtube.com/watch?v=P-KjcOQPVeI](https://www.youtube.com/watch?v=P-KjcOQPVeI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-31 00:00:00+00:00

Taken from JRE #1420 w/Mark Normand:
https://youtu.be/DEWgei2u6vM

## Joe Rogan Watches New York Rat Video w/Mark Normand
 - [https://www.youtube.com/watch?v=GAAqRjOxfuU](https://www.youtube.com/watch?v=GAAqRjOxfuU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-31 00:00:00+00:00

Taken from JRE #1420 w/Mark Normand:
https://youtu.be/DEWgei2u6vM

## Joe Rogan on The Devastation of the Australia Fires
 - [https://www.youtube.com/watch?v=MXtXjzIHfdY](https://www.youtube.com/watch?v=MXtXjzIHfdY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-31 00:00:00+00:00

Taken from JRE #1420 w/Mark Normand:
https://youtu.be/DEWgei2u6vM

## Joe Rogan: I Know a Lot of Smart People with Idiots for Parent
 - [https://www.youtube.com/watch?v=_NpWiZJd8Tw](https://www.youtube.com/watch?v=_NpWiZJd8Tw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-31 00:00:00+00:00

Taken from JRE #1420 w/Mark Normand: https://youtu.be/DEWgei2u6vM

## Joe Rogan: The Winnie the Pooh Ride is About an Acid Trip
 - [https://www.youtube.com/watch?v=AiMyEDfpZIk](https://www.youtube.com/watch?v=AiMyEDfpZIk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-31 00:00:00+00:00

Taken from JRE #1420 w/Mark Normand: https://youtu.be/DEWgei2u6vM

## Mark Normand’s Pecker Pic Came Back to Haunt Him
 - [https://www.youtube.com/watch?v=0eyJsN5ToUE](https://www.youtube.com/watch?v=0eyJsN5ToUE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-31 00:00:00+00:00

Taken from JRE #1420 w/Mark Normand: https://youtu.be/DEWgei2u6vM

## Street Fight Videos Are Scary w/Mark Normand | Joe Rogan
 - [https://www.youtube.com/watch?v=VkWZqZ7g9yk](https://www.youtube.com/watch?v=VkWZqZ7g9yk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-31 00:00:00+00:00

Taken from JRE #1420 w/Mark Normand:
https://youtu.be/DEWgei2u6vM

## Daryl Davis Explains the Hierarchy of the KKK | Joe Rogan
 - [https://www.youtube.com/watch?v=FQbDljycom8](https://www.youtube.com/watch?v=FQbDljycom8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-30 00:00:00+00:00

Taken from JRE #1419 w/Daryl Davis:
https://youtu.be/oGTQ0Wj6yIg

## Daryl Davis Predicts More "Lone Wolf" Terrorist Attacks
 - [https://www.youtube.com/watch?v=guZ9ihYf224](https://www.youtube.com/watch?v=guZ9ihYf224)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-30 00:00:00+00:00

Taken from JRE #1419 w/Daryl Davis: https://youtu.be/oGTQ0Wj6yIg

## Daryl Davis Responds to Dave Chappelle’s Clayton Bigsby Sketch
 - [https://www.youtube.com/watch?v=UETvxBYadhI](https://www.youtube.com/watch?v=UETvxBYadhI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-30 00:00:00+00:00

Taken from JRE #1419 w/Daryl Davis: https://youtu.be/oGTQ0Wj6yIg

## Daryl Davis' Tense First Meeting with a Klan Member | Joe Rogan
 - [https://www.youtube.com/watch?v=Bj-4Q416C8w](https://www.youtube.com/watch?v=Bj-4Q416C8w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-30 00:00:00+00:00

Taken from JRE #1419 w/Daryl Davis:
https://youtu.be/oGTQ0Wj6yIg

## Daryl Davis: Ending Racism Begins with Education
 - [https://www.youtube.com/watch?v=yPGG9UaZ1Rc](https://www.youtube.com/watch?v=yPGG9UaZ1Rc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-30 00:00:00+00:00

Taken from JRE #1419 w/Daryl Davis: https://youtu.be/oGTQ0Wj6yIg

## Daryl Davis: Media Failed to Report Unite the Right Was About Hate
 - [https://www.youtube.com/watch?v=G-plh34YPqs](https://www.youtube.com/watch?v=G-plh34YPqs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-30 00:00:00+00:00

Taken from JRE #1419 w/Daryl Davis: https://youtu.be/oGTQ0Wj6yIg

## Daryl Davis: We Need to Get Rid of Black History Month
 - [https://www.youtube.com/watch?v=SLnpDlfP_8Y](https://www.youtube.com/watch?v=SLnpDlfP_8Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-30 00:00:00+00:00

Taken from JRE #1419 w/Daryl Davis: https://youtu.be/oGTQ0Wj6yIg

## How Daryl Davis Came to Convince KKK Members to Leave | Joe Rogan
 - [https://www.youtube.com/watch?v=Z6FDQ301Q7s](https://www.youtube.com/watch?v=Z6FDQ301Q7s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-30 00:00:00+00:00

Taken from JRE #1419 w/Daryl Davis:
https://youtu.be/oGTQ0Wj6yIg

## The Reason Daryl Davis Collects Robes of Former Klansmen | Joe Rogan
 - [https://www.youtube.com/watch?v=75fGNLFAoIc](https://www.youtube.com/watch?v=75fGNLFAoIc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-30 00:00:00+00:00

Taken from JRE #1419 w/Daryl Davis:
https://youtu.be/oGTQ0Wj6yIg

## The Tea Party’s Slogan Has a Very Dark History
 - [https://www.youtube.com/watch?v=16X4idzK-4o](https://www.youtube.com/watch?v=16X4idzK-4o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-30 00:00:00+00:00

Taken from JRE #1419 w/Daryl Davis: https://youtu.be/oGTQ0Wj6yIg

## What Actually Happens at Klan Meetings w/Daryl Davis | Joe Rogan
 - [https://www.youtube.com/watch?v=RCAvAn7GoUQ](https://www.youtube.com/watch?v=RCAvAn7GoUQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-30 00:00:00+00:00

Taken from JRE #1419 w/Daryl Davis:
https://youtu.be/oGTQ0Wj6yIg

## Why People Join The KKK w/Daryl Davis | Joe Rogan
 - [https://www.youtube.com/watch?v=q_4b5-mtV2w](https://www.youtube.com/watch?v=q_4b5-mtV2w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-30 00:00:00+00:00

Taken from JRE #1419 w/Daryl Davis:
https://youtu.be/oGTQ0Wj6yIg

