# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Anarchist Hecktopia: The Michael Malice Interview
 - [https://www.youtube.com/watch?v=VjtnF4ivaNI](https://www.youtube.com/watch?v=VjtnF4ivaNI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-01-31 00:00:00+00:00

Editor-in-chief Kyle Mann and creative director Ethan Nicolle welcome back popular podcaster and resident expert on anarchism, the “new” right, and North Korea: Michael Malice. He is the author of  Dear Reader: The Unauthorized Autobiography of Kim Jon Il and The New Right: A Journey to the Fringe of American Politics. He is also the podcast host of  "YOUR WELCOME" and Night Shade. Kyle and Ethan continue their efforts to convert him into Michael Mercy and discuss strange sea creatures, visiting North Korea, and why anarchists hate Presidents so much.

  Pre-order the new Babylon Bee Best-Of Coffee Table Book coming in 2020!

 Topics Discussed

 Anarchy Hecktopia Owned

   Your house is burning down, do you put the fire out with liberal tears?

   What would the children pledge allegiance to?

   Who would indoctrinate the children?

   Who would deliver Amazon prime?

   What war criminals would we print on money?

   What would we do with the Hall of President?

   What would we call Lincoln Logs?

   What would they rename Washington State?

   Who would take my money and tell me what goods and services I need?

   Who would kill Jeffrey Epstein?

   Who would shoot the dogs?

   Who would you rather have run national parks? Costco or Sam’s Club?

   Who would be the best anarchist president?

   North Korea

   You’ve been to North Korea. Tell us about that. What was it like getting off the plane? Isn’t there a travel ban to going there?

   Western journalists endangering North Korean citizens’ lives

   Thought crimes when you’re always being watched

   Kim Jong Un worship. Was it real? 

   What dystopian novel gets closest to the reality? 

   Black markets

   North Korea’s cult of the gun and military

   How is Trump’s handling of Iran and North Korea?

   Anarchy and Political Theory

   Michael Malice tries to think of top 5 Presidents and ends up rating his 5 worst Presidents, and mentions something weird about Grover Cleveland

   Michael Malice delves into the heart anarchy

   Miscellaneous

  The power of social media and the strange alliances against progressivism, strange sea creatures, and how sometimes it is a sin not to eat the ham.  The entire interview is available for Babylon Bee subscribers only…

 Become a paid subscriber at https://babylonbee.com/plans

