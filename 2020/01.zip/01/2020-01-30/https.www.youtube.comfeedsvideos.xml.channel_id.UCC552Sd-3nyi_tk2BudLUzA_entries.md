# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## What Actually Happens If You Get Coronavirus?
 - [https://www.youtube.com/watch?v=OTYfke545vI](https://www.youtube.com/watch?v=OTYfke545vI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2020-01-30 00:00:00+00:00

What is the coronavirus and what does it actually do in your body?
Are COVID Vaccines Causing Magnetism? https://youtu.be/bVi-GlOY9iM
JOIN OUR NEW EMAIL LIST https://mailchi.mp/072240d817d6/asapscience

Subscribe for more asapscience, and hit that bell :)

Created by: Mitchell Moffit and Gregory Brown

Animations created by and for
the Vaccine Makers Project. http://www.VaccineMakers.org Copyright © 2016, Medical History
Pictures, Inc. All rights reserved.;

FOLLOW US!
Mitch
Instagram: https://instagram.com/mitchellmoffit
Twitter: https://twitter.com/mitchellmoffit 

Greg
Instagram: https://instagram.com/whalewatchmeplz 
Twitter: https://twitter.com/whalewatchmeplz 

AsapSCIENCE
Instagram: https://instagram.com/asapscience 
Facebook: https://facebook.com/asapscience 
Twitter: https://twitter.com/asapscience
Tumblr: https://asapscience.tumblr.com 

Send us stuff!
ASAPSCIENCE INC.
P.O. Box 93, Toronto P
Toronto, ON, M5S2S6

