# Source:Chris Ray Gun, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCctjGdm2NlMNzIlxz02IsXA, language:en-US

## VIDEO BLAMES! - Ray Gun Recap
 - [https://www.youtube.com/watch?v=ZauJji11tCg](https://www.youtube.com/watch?v=ZauJji11tCg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCctjGdm2NlMNzIlxz02IsXA
 - date published: 2020-01-30 00:00:00+00:00

WEEKLY SNARK TANK PODCAST! ► http://www.patreon.com/thesnarktank

It's a brand new day! In a brand new year! In a brand new decade! So, what better way to start than with an argument resurrected from the early 2000s? From Hillary Clinton fighting with Bernie Sanders to establishment politicians blaming video games for the worlds ills. We may have bone marrow DNA soul usurpers in the 2020s, but we haven't changed much. 

Thanks to Foot of a Ferret for Paul's VO!
https://www.youtube.com/user/FootofaFerret

Gameplay ► BONEWORKS 
https://store.steampowered.com/app/823500/BONEWORKS/

SHIRTS ► https://teespring.com/stores/chris-ray-gun
TWITTER ► https://twitter.com/ChrisRGun
FACEBOOK ► http://on.fb.me/15OyE7z
TWITCH ► http://www.twitch.tv/chrisraygun
PATREON ► https://www.patreon.com/ChrisRay
SUBREDDIT ► https://www.reddit.com/r/ChrisRayGun/
SACRED SYMBOLS  ► https://apple.co/2Rqmklc
SECOND CHANNEL ► https://www.youtube.com/channel/UCiNediqB-JC_TjbsB4hJuHA

