# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Jerzy Zięba radzi jak leczyć koronawirusa. Czy informacje dotrą do Chin?
 - [https://www.youtube.com/watch?v=t_VZ_cnTbVw](https://www.youtube.com/watch?v=t_VZ_cnTbVw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2020-01-31 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
-------------------------------------------------------------
👀 Mroczne Podcasty: https://goo.gl/cdCFKe
👀 Tatusiek: http://bit.ly/3aSCheE
-------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
-------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
-------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
-------------------------------------------------------------
💲 wsparcie
💰 http://bit.ly/2ETKSyN
-------------------------------------------------------------
✅źródła:
Link 1:                   http://bit.ly/37OKRcA
Link 2:                   http://bit.ly/2GIqaTC
Link 3:                   http://bit.ly/37IM2u0
Link 4:                   http://bit.ly/2GCELA2
Link 5:                   http://bit.ly/37K7QFR
Link 6:                   http://bit.ly/2RJl2oz
-------------------------------------------------------------
💡 Tagi: #Zięba #koronawirus
-------------------------------------------------------------

## Czy Polska będzie płaciła reparacje rodzinom radzieckich żołnierzy?
 - [https://www.youtube.com/watch?v=72abW1c5lNA](https://www.youtube.com/watch?v=72abW1c5lNA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2020-01-30 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
-------------------------------------------------------------
👀 Mroczne Podcasty: https://goo.gl/cdCFKe
👀 Tatusiek: http://bit.ly/3aSCheE
-------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
-------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
-------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
-------------------------------------------------------------
💲 wsparcie
💰 http://bit.ly/2ETKSyN
-------------------------------------------------------------
✅źródła:
Link 1:                   http://bit.ly/37HllpF
Link 2:                   http://bit.ly/36GGnn9
Link 3:                   http://bit.ly/38Kp85I
Link 4:                   http://bit.ly/31d5wo7
Link 5:                   http://bit.ly/38S3jRB
Link 6:                   http://bit.ly/36C0x1j
Link 7:                   http://bit.ly/37JFdZd
-------------------------------------------------------------
🖼Grafika: 
Time Inc / Grigory Vayl
https://nyti.ms/319NqDA
---
wikipedia.org
http://bit.ly/2ObK3a0
-------------------------------------------------------------
💡 Tagi: #Rosja #historia
-------------------------------------------------------------

