# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Nuages | Django Reinhardt | Pomplamoose ft. John Tegmeyer
 - [https://www.youtube.com/watch?v=GxAlMM8M8Ko](https://www.youtube.com/watch?v=GxAlMM8M8Ko)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2020-01-31 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 Get our French EP on vinyl or CD! - http://bit.ly/pomplamoosemerch

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

A cover of Nuages by Pomplamoose.

CREDITS

Lead Vocals: Nataly Dawn
Accordion: Jack Conte
Clarinet: John Tegmeyer
Guitar: John Schroeder
Guitar/Trumpet: Erik Miron
Upright Bass: Ellie Athayde
Harmonica: Ross Garren
Drums: Ben Rose
Engineer: Tim Sonnefeld 
Assistant Engineer: Jason Clark
Mixing/Mastering: Caleb Parker
Producers: John Schroeder & Caleb Parker
Video Direction/Production: Ricky Chavez
Camera Operators: Merlin Showalter, Dijon Herron
Video Editor: Dominic Mercurio

Recorded at Band House Studios in Los Angeles.

