# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## The Drinker's Unhappy Hour - Episode #5 (feat. Nerdrotic and Bowlestrek)
 - [https://www.youtube.com/watch?v=MqfE3jzWnNg](https://www.youtube.com/watch?v=MqfE3jzWnNg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-01-31 00:00:00+00:00

Join Gary, Bowlestrek and myself as we pick apart Star Trek Picard, The Witcher and Doctor Who, answer questions and generally shoot the breeze.

Link to Nerdrotic's channel: https://www.youtube.com/user/sutrowatchtower
Link to Bowlestrek's channel: https://www.youtube.com/user/bowlestrek

