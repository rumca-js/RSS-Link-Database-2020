# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Ministry of Broadcast | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=xhdX3RtiO8c](https://www.youtube.com/watch?v=xhdX3RtiO8c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-01-30 00:00:00+00:00

CORRECTION: $14.99 on Steam. Not $39.99.

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

KC Nwosu reviews Ministry of Broadcast, developed by Ministry of Broadcast Studios. 

Ministry of Broadcast on Steam: https://store.steampowered.com/app/874040/Ministry_of_Broadcast/

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►► https://sharkrobot.com/collections/zero-punctuation 

Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 

Like us on Facebook ►► http://www.facebook.com/EscapistMag

Follow us on Twitter ►► https://twitter.com/EscapistMag

#MinistryofBroadcast

