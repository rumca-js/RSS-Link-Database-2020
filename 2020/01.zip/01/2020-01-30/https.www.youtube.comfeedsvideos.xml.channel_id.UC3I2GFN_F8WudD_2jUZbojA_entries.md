# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Andrew Bird - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=o-BrVkJCHgg](https://www.youtube.com/watch?v=o-BrVkJCHgg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-31 00:00:00+00:00

http://KEXP.ORG presents Andrew Bird performing live in the KEXP studio. Recorded October 19, 2019.

Songs:
Sisyphus
Olympians
Proxy War
Manifest

Host: Morgan
Audio Engineer: Tom Hall
Cameras: Jim Beckmann, Alaia D'Alessandro, Kendall Rock & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
http://www.andrewbird.net

## Andrew Bird - Manifest (Live on KEXP)
 - [https://www.youtube.com/watch?v=uDbJFF7H91M](https://www.youtube.com/watch?v=uDbJFF7H91M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-31 00:00:00+00:00

http://KEXP.ORG presents Andrew Bird performing "Manifest" live in the KEXP studio. Recorded October 19, 2019.

Host: Morgan
Audio Engineer: Tom Hall
Cameras: Jim Beckmann, Alaia D'Alessandro, Kendall Rock & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
http://www.andrewbird.net

## Andrew Bird - Olympians (Live on KEXP)
 - [https://www.youtube.com/watch?v=BFdOuOjM_H8](https://www.youtube.com/watch?v=BFdOuOjM_H8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-31 00:00:00+00:00

http://KEXP.ORG presents Andrew Bird performing "Olympians" live in the KEXP studio. Recorded October 19, 2019.

Host: Morgan
Audio Engineer: Tom Hall
Cameras: Jim Beckmann, Alaia D'Alessandro, Kendall Rock & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
http://www.andrewbird.net

## Andrew Bird - Proxy War (Live on KEXP)
 - [https://www.youtube.com/watch?v=nCfVslFTXUY](https://www.youtube.com/watch?v=nCfVslFTXUY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-31 00:00:00+00:00

http://KEXP.ORG presents Andrew Bird performing "Proxy War" live in the KEXP studio. Recorded October 19, 2019.

Host: Morgan
Audio Engineer: Tom Hall
Cameras: Jim Beckmann, Alaia D'Alessandro, Kendall Rock & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
http://www.andrewbird.net

## Andrew Bird - Sisyphus (Live on KEXP)
 - [https://www.youtube.com/watch?v=oOyfBIkbnCA](https://www.youtube.com/watch?v=oOyfBIkbnCA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-31 00:00:00+00:00

http://KEXP.ORG presents Andrew Bird performing "Sisyphus" live in the KEXP studio. Recorded October 19, 2019.

Host: Morgan
Audio Engineer: Tom Hall
Cameras: Jim Beckmann, Alaia D'Alessandro, Kendall Rock & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
http://www.andrewbird.net

