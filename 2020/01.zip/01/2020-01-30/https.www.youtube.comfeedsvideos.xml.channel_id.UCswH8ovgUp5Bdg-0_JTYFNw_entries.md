# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Dealing With Life.
 - [https://www.youtube.com/watch?v=RPd6ynbDB1g](https://www.youtube.com/watch?v=RPd6ynbDB1g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-01-30 00:00:00+00:00

A clip from my upcoming Under The Skin podcast with one of the pioneers of Yoga & Recovery - Tommy Rosen. He is a fountain of knowledge and wisdom. Listen this Saturday 1st February only on Luminary -  http://luminary.link/russell

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Come and see me on tour: https://www.russellbrand.com/live/

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

