## The EARN IT Act: How to Ban End-to-End Encryption Without Actually Banning It | Center for Internet and Society
 - [https://cyberlaw.stanford.edu/blog/2020/01/earn-it-act-how-ban-end-end-encryption-without-actually-banning-it](https://cyberlaw.stanford.edu/blog/2020/01/earn-it-act-how-ban-end-end-encryption-without-actually-banning-it)
 - RSS feed: https://cyberlaw.stanford.edu
 - date published: 2020-01-30 07:46:45+00:00

The EARN IT Act: How to Ban End-to-End Encryption Without Actually Banning It | Center for Internet and Society

