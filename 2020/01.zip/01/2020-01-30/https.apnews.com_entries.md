## Australia defends plan to create island quarantine camp | AP News
 - [https://apnews.com/c129280f6ab2a832908b8dcf4888364b](https://apnews.com/c129280f6ab2a832908b8dcf4888364b)
 - RSS feed: https://apnews.com
 - date published: 2020-01-30 20:15:13+00:00

Australia defends plan to create island quarantine camp | AP News

