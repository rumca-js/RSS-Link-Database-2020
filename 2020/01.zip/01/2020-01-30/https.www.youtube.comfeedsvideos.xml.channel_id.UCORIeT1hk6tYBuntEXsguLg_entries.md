# Source:PostmodernJukebox, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg, language:en-US

## 99 Luftballons (Jazz Vibes Nena Cover) ft. Aly Ryan
 - [https://www.youtube.com/watch?v=TliE9rTrzXg](https://www.youtube.com/watch?v=TliE9rTrzXg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg
 - date published: 2020-01-31 00:00:00+00:00

GET TIX TO OUR GRAND REOPENING WORLD TOUR: http://www.pmjtour.com
Download & Stream "99 Luftballons" Here: https://pmjlive.com/99luftballons?IQid=yt
Shop PMJ Music/Merch:  https://smarturl.it/pmjshop?IQid=yt
Follow Us On Spotify: https://smarturl.it/pmjcomplete?IQid=yt

German rising star Aly Ryan is back to help us celebrate our European tour announcement with this dreamy remake of a German pop classic: “99 Luftballons” by Nena (in English: 99 Red Balloons).  Geniesst die schöne Musik!

____________________________________________

Follow The Musicians: 
Aly Ryan (Vocals):
Instagram: https://instagram.com/alyryanmusic/
Twitter: https://twitter.com/alyryanmusic
YouTube: https://youtube.com/channel/UClOBHt60WRyRGtGD-fiPaYQ

Nick Mancini (Vibraphone):
Instagram: https://instagram.com/nickthemancini/

Ian Solomon (Bass)

Aaron McLendon (Drums):
Instagram: https://instagram.com/amacthemusician

Scott Bradlee (Piano):
YouTube: http://youtube.com/scottbradlee
Facebook: http://facebook.com/scottbradleemusic
Instagram: http://instagram.com/scottbradlee
Twitter: http://twitter.com/scottbradlee

Arrangement by: Scott Bradlee
Mixed & Mastered by: Thai Long Ly
Video by: Braverijah Sage
____________________________________________
#PMJTour #Nena #99Luftballons #Cover

