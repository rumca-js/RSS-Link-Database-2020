## Facebook will remove some coronavirus conspiracy theories | Mashable
 - [https://mashable.com/article/facebook-will-remove-coronavirus-conspiracy-theories](https://mashable.com/article/facebook-will-remove-coronavirus-conspiracy-theories)
 - RSS feed: https://mashable.com
 - date published: 2020-01-30 08:40:59+00:00

Facebook will remove some coronavirus conspiracy theories | Mashable

