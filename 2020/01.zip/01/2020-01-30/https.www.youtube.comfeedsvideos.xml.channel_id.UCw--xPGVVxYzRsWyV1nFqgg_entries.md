# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## NEW ORBIT FANTASY EPIC, WHEEL OF TIME CASTING, VESEMIR MAIN PROTAGONIST? - FANTASY NEWS
 - [https://www.youtube.com/watch?v=LCjcCd0eHNg](https://www.youtube.com/watch?v=LCjcCd0eHNg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-01-31 00:00:00+00:00

Welcome to another fantasy news :) 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene
 
P.O. Box 1016 Dublin, Ohio 43017
with the backup of:
715 Shawan falls Dr. Dublin, Ohio 43017

NEWS: 

Vesemir Witcher Nightmare of the Wolf: https://comicbook.com/gaming/2020/01/30/the-witcher-nightmare-of-the-wolf-netflix-animated-series-vesemir/

The Quest: https://variety.com/2020/tv/news/the-quest-disney-plus-reality-maze-meet-chimps-pixar-1203484822/

We Ride The Storm: https://www.tor.com/2020/01/28/orbit-acquired-devin-madson-we-ride-the-storm-epic-fantasy/

The Case of the Somewhat Mythic Sword: https://www.tor.com/2020/01/29/the-case-of-the-somewhat-mythic-sword-garth-nix/

The Letter For The King:  https://www.digitalspy.com/tv/ustv/a30687137/netflix-letter-for-the-king-first-look-fantasy-show/

War Of The Worlds: https://www.youtube.com/watch?v=XeYmeGyQKuM

Rise Of Skywalker Directors Cut: https://wegotthiscovered.com/movies/lucasfilm-release-directors-cut-star-wars-rise-skywalker/

Philip Pullman Boycott: https://www.bbc.com/news/entertainment-arts-51269012?ns_mchannel=social&ns_source=twitter&ns_linkname=scotland&ns_campaign=bbc_scotland_news

Witcher Author Comments: https://io9.gizmodo.com/i-do-not-like-working-too-hard-or-too-long-a-refreshin-1841209529

Ghost In The Shell Trailer: https://www.youtube.com/watch?v=nIqzdn-Gjwk

## I scream at books 📖 and boxes 📦
 - [https://www.youtube.com/watch?v=mFCo11wskXo](https://www.youtube.com/watch?v=mFCo11wskXo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-01-30 00:00:00+00:00

You send things, things require gloves. 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene
 
P.O. Box 1016 Dublin, Ohio 43017
with the backup of:
715 Shawan falls Dr. Dublin, Ohio 43017

