# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## When Actors have to Tape an Audition
 - [https://www.youtube.com/watch?v=Mz7lb_Pl7P8](https://www.youtube.com/watch?v=Mz7lb_Pl7P8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2020-01-30 00:00:00+00:00

Huge thanks to the amazingly talented Gina Phillips & Sara Garcia!
Check out my Patreon for exclusive perks: https://www.patreon.com/julienolke

