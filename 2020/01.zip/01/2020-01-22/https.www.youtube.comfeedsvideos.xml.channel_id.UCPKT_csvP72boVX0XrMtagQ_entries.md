# Source:Cercle, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ, language:en-US

## Mind Against at Centro Ceremonial Otomí in Mexico for Cercle
 - [https://www.youtube.com/watch?v=coloJDqNBRg](https://www.youtube.com/watch?v=coloJDqNBRg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ
 - date published: 2020-01-23 00:00:00+00:00

Mind Against playing an exclusive set in the Centro Ceremonial Otomí, in Mexico for Cercle.

☞ Support us and get access to exclusive videos & perks: https://Cercle.lnk.to/Patreon
☞ Listen to our playlists, tracks & sets: https://Cercle.lnk.to/Playlists
☞ Subscribe to our newsletter to know about our next shows: https://Cercle.lnk.to/Members
☞ Subscribe to our YouTube channel: Cercle.lnk.to/ytcercle

☞ Mind Against
https://www.facebook.com/mindagainst/
https://open.spotify.com/artist/48LWLoeY0dhwaiX1FRsn72

19°31'53.7"N 99°31'20.3"W

Video credits:

Artists: Mind Against
Venue: Centro Ceremonial Otomí
Produced by Cercle
Executive producers: Philippe Tuchmann & Derek Barbolla
Film directed by: Pol Souchier & Derek Barbolla
Directors of photography: Mickaël Fidjili & Haytham Omar
Drone pilot: Alexis Olas 
Stage Manager: Alvaro Hernandez
Sound engineer: Joel Neri
Sound mastering: Laurent de Boisgisson
Technical Manager: Aurélien Moisan
Post-production: Mathieu Glissant / Saison Unique Production

--
Special thanks to:
Adrian Valadez from Dynamic Waves, the CEPANAF and the supreme leader of Otomi. 
Galerie Joseph. 

This artistic performance has been recorded live. 

______

Follow us on http://www.cercle.io

