# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Exploring the Novation Peak with Foxhunt
 - [https://www.youtube.com/watch?v=q2XznRT7jsA](https://www.youtube.com/watch?v=q2XznRT7jsA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2020-01-22 00:00:00+00:00

I'm new to the Novation Peak, Foxhunt isn't.
Join us as this talented EDM musician takes us from the basics to beyond on this fantastic synthesizer, talks workflow, and shows off patches from his new album, 'Unhallowed'.
Get 'Unhallowed' here: https://foxhuntelectronic.bandcamp.com/album/unhallowed
------------------------------------
Patreon: http://bit.ly/rmrpatreon
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe
T-Shirts: http://bit.ly/rmrshirts
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

