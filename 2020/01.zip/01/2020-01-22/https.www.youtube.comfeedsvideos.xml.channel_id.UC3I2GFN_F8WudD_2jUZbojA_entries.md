# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## GRÓA - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=w7i_9IFju1E](https://www.youtube.com/watch?v=w7i_9IFju1E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-23 00:00:00+00:00

http://KEXP.ORG presents GRÓA performing live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 6, 2019.

Songs:
María
Tralalalala
Fullkomið
Skrímslið er að ná þér
Jetpackstelpan
Meiða eyrun

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://www.facebook.com/GROAband

## GRÓA - Fullkomið (Live on KEXP)
 - [https://www.youtube.com/watch?v=lhk9u8AOgsM](https://www.youtube.com/watch?v=lhk9u8AOgsM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-23 00:00:00+00:00

http://KEXP.ORG presents GRÓA performing "Fullkomið" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 6, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://www.facebook.com/GROAband

## GRÓA - Jetpackstelpan (Live on KEXP)
 - [https://www.youtube.com/watch?v=rzI3_dIs6vQ](https://www.youtube.com/watch?v=rzI3_dIs6vQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-23 00:00:00+00:00

http://KEXP.ORG presents GRÓA performing "Jetpackstelpan" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 6, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://www.facebook.com/GROAband

## GRÓA - María (Live on KEXP)
 - [https://www.youtube.com/watch?v=kzB2u9ZndfE](https://www.youtube.com/watch?v=kzB2u9ZndfE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-23 00:00:00+00:00

http://KEXP.ORG presents GRÓA performing "María" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 6, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://www.facebook.com/GROAband

## GRÓA - Meiða eyrun (Live on KEXP)
 - [https://www.youtube.com/watch?v=KYK3XilFdvg](https://www.youtube.com/watch?v=KYK3XilFdvg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-23 00:00:00+00:00

http://KEXP.ORG presents GRÓA performing "Meiða eyrun" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 6, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://www.facebook.com/GROAband

## GRÓA - Skrímslið er að ná þér (Live on KEXP)
 - [https://www.youtube.com/watch?v=oj004jhxhdg](https://www.youtube.com/watch?v=oj004jhxhdg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-23 00:00:00+00:00

http://KEXP.ORG presents GRÓA performing "Skrímslið er að ná þér" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 6, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://www.facebook.com/GROAband

## GRÓA - Tralalalala (Live on KEXP)
 - [https://www.youtube.com/watch?v=V55d2PtX4QA](https://www.youtube.com/watch?v=V55d2PtX4QA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-23 00:00:00+00:00

http://KEXP.ORG presents GRÓA performing "Tralalalala" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 6, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://www.facebook.com/GROAband

## Brittany Howard - Georgia (Live on KEXP)
 - [https://www.youtube.com/watch?v=p5MFfzO2gwg](https://www.youtube.com/watch?v=p5MFfzO2gwg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-22 00:00:00+00:00

http://KEXP.ORG presents Brittany Howard performing "Georgia" live in the KEXP studio. Recorded November 18, 2019.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://brittanyhoward.com

## Brittany Howard - He Loves Me (Live on KEXP)
 - [https://www.youtube.com/watch?v=-xXKu5yY-ak](https://www.youtube.com/watch?v=-xXKu5yY-ak)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-22 00:00:00+00:00

http://KEXP.ORG presents Brittany Howard performing "He Loves Me" live in the KEXP studio. Recorded November 18, 2019.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://brittanyhoward.com

## Brittany Howard - Presence (Live on KEXP)
 - [https://www.youtube.com/watch?v=j6gapPsC5Uc](https://www.youtube.com/watch?v=j6gapPsC5Uc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-22 00:00:00+00:00

http://KEXP.ORG presents Brittany Howard performing "Presence" live in the KEXP studio. Recorded November 18, 2019.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://brittanyhoward.com

## Brittany Howard - Stay High (Live on KEXP)
 - [https://www.youtube.com/watch?v=kVjIGALoaY0](https://www.youtube.com/watch?v=kVjIGALoaY0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-22 00:00:00+00:00

http://KEXP.ORG presents Brittany Howard performing "Stay High" live in the KEXP studio. Recorded November 18, 2019.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://brittanyhoward.com

