# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## This is the First LIVING Robot and it's Unbelievable
 - [https://www.youtube.com/watch?v=js6uTRT8KO4](https://www.youtube.com/watch?v=js6uTRT8KO4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2020-01-22 00:00:00+00:00

Will this new robot make others obsolete? Xenobots are the first bio-robots: living, programmable cells. How do you feel about them?
Subscribe for more asapscience, and hit that bell :)

Created by: Mitchell Moffit and Gregory Brown

FOLLOW US!
Mitch
Instagram: https://instagram.com/mitchellmoffit
Twitter: https://twitter.com/mitchellmoffit 

Greg
Instagram: https://instagram.com/whalewatchmeplz 
Twitter: https://twitter.com/whalewatchmeplz 

AsapSCIENCE
Instagram: https://instagram.com/asapscience 
Facebook: https://facebook.com/asapscience 
Twitter: https://twitter.com/asapscience
Tumblr: https://asapscience.tumblr.com 

Send us stuff!
ASAPSCIENCE INC.
P.O. Box 93, Toronto P
Toronto, ON, M5S2S6

SOURCES:
The Xenobot research paper:
https://www.pnas.org/content/early/2020/01/07/1910837117?utm_source=TrendMD&utm_medium=cpc&utm_campaign=Proc_Natl_Acad_Sci_U_S_A_TrendMD_0

