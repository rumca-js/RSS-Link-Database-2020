# Source:Mandalore Gaming, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw, language:en-US

## Gothic Remake Playable Teaser Impressions
 - [https://www.youtube.com/watch?v=TTb8ILmrZFA](https://www.youtube.com/watch?v=TTb8ILmrZFA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw
 - date published: 2020-01-23 00:00:00+00:00

It's only a demo so I can't call it a Gothic Remake review, but I do have some feedback for the developers from my impressions. Big thanks to @GrimBeard @RagnarRoxShow @Indigo_Gaming and @SpicyChickenGodAJ for their contributions.
Support the channel at: https://www.patreon.com/mandaloregaming or https://www.paypal.me/MandaloreGaming
I take video suggestions at mandaloremovies@gmail.com
Twitter: https://twitter.com/Lord_Mandalore

#Gothic #GothicRemake #GothicPlayableTeaser #GothicRemakeReview #GothicRemakeImpressions #GothicPC

00:00 - Intro
00:48 - Game Intro
1:36 - Roight...roight...
2:47 - Main Character & Tone
5:21 - Visuals
6:37 - Gameplay Mechanics & Issues
9:22 - Grimbeard Thoughts
10:24 - RagnarRox Thoughts
11:45- Indigo Gaming Thoughts
13:15- SpicyChickenGod Thoughts
14:12 - Conclusions
14:44 - Credits
15:40 - Coyotes Start Fighting

