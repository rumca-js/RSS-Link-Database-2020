# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Top 10 NEW Open World Games of 2020
 - [https://www.youtube.com/watch?v=1MenwQ5D_FI](https://www.youtube.com/watch?v=1MenwQ5D_FI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-01-23 00:00:00+00:00

Video games with open worlds continue to roll out in 2020 on PC, PS4, Xbox One, Nintendo Switch, and beyond. Here are some to look forward to!
Subscribe for more: http://youtube.com/gameranxtv

#10 No More Heroes 3

Platform: Switch

Release Date: 2020



#9 Dying Light 2

Platform: PC PS4 XBOX ONE

Release Date: TBA 2020



#8 Everwild

Platform: XBOX ONE 

Release Date: TBA 2020



#7 Gods & Monsters

Platform: PC PS4 XBOX ONE Switch

Release Date: TBA 2020



#6 Mount & Blade 2: Bannerlord

Platform: PC PS4 XBOX ONE 

Release Date: TBA 2020



#5 Dragon Ball Z Kakarot

Platform: PC PS4 XBOX ONE 

Release Date: January 17, 2020 



#4 Watch Dogs Legion

Platform: PC PS4 XBOX ONE

Release Date: TBA 2020



#3 Elden Ring

Platform: PC PS4 XBOX ONE

Release Date: TBA 2020



#2 Ghost of Tsushima

Platform: PS4

Release Date: Q2/Q3 2020



#1 Cyberpunk 2077

Platform: PC PS4 XBOX ONE STADIA

Release Date: 17 September 2020







BONUS

Microsoft Flight Simulator

Platform: PC XBOX ONE

Release Date: TBA 2020



Yakuza: Like a Dragon

Platform: PS4

Release Date: 2020



Animal Crossing: New Horizons

Platform: Switch

Release Date: March 20, 2020



Unannounced Assassin’s Creed

Platform: PC PS4 XBOX ONE

Release Date: TBA 2020

## PS5 VS XBOX SERIES X: How Will They Be Different?
 - [https://www.youtube.com/watch?v=ujCjF_KMM7A](https://www.youtube.com/watch?v=ujCjF_KMM7A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-01-22 00:00:00+00:00

As the next generation encroaches, more and more information about the PlayStation 5 and next Xbox comes out. Now that we have some concrete info, how will these two devices stand out from one another? Let's talk.
Subscribe for more: http://youtube.com/gameranxtv

