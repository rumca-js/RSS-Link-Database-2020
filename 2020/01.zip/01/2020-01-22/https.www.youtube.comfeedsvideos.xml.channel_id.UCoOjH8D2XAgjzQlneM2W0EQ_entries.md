# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## War Dogs: How to Make Money Off of World War 3
 - [https://www.youtube.com/watch?v=yuDAQihbklE](https://www.youtube.com/watch?v=yuDAQihbklE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2020-01-22 00:00:00+00:00

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join
Updated refund policy: Email us within your first month of joining and we'll refund you for your first month. There is no refund if you cancel at a later time. 

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
📸 Follow me on IG for a chance to win $1,000: @jaketran // http://bit.ly/jt-ig
Please watch out for fake accounts. I will never message you asking for money or to invest. As of right now, it's spelled exactly like this: @jaketran
👨👦👦 Join the Tran Mafia Family here: https://bit.ly/patreon-jt
💬 Join the community Discord: http://discord.gg/BmK8EnQ

Stuff I use & recommend:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
🏠 The real estate investing course I love & recommend: https://jake.yt/RE
🌐 Most flexible, affordable website hosting: https://jake.yt/bhd
🖥️ Website platform I use & love: https://jake.yt/kd
💽 Editing software I've used for 7+ years: https://jake.yt/ccd
📒 Online bookkeeping software I use& love: https://jake.yt/benchd 
🧾 Best affordable bookkeeping software: https://jake.yt/fbd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd
📚 Get 3 free audiobooks for life: https://amzn.to/2v58PSu
🎥 My video gear, setup, tech, books: https://jake.yt/stored

✉️ Email me: jake@jaketran.io

Subscribe to the backup channel on LBRY, use reward code "jake-cast" for free coin: https://bit.ly/LBRY-jt
-----------------------

📰 Sources & visuals // https://docs.google.com/document/d/1UbFfnSvlvB5Yk9NnBeObDLUXhW0ECb4yRJgO8bTYQuY/edit?usp=sharing

If this escalates to another major war in the middle east or hell, maybe even WWIII, theres a lot of money to be made

At the height of the Iraq invasion starting in 2003, the US had around 150,000 soldiers deployed.

The US government has to outfit all these soldiers with $17,500 of equipment each + all the logistical costs: food, housing, water, plumbing, transportation

The gov doesn’t manufacture or provide any of this stuff. So that means at some point in the process, these products and services have to exchange hands with every day citizens like you and I.

And the way the government lets citizens and companies provide these products and services is through US government contracts.

The US spent nearly $5 trillion dollars on the war. All that money had to go to somebody.

You have the giant companies that secure the big defense contracts like Boeing, Lockheed, Halliburton. But when the US needs small orders, these big businesses can't fullfill them

Why waste your time for a few thousand to a few million in profit when you can build entire military bases for billions of dollars?

And for two young entrepreneurs David and Efraim, that is what they took advantage of.

When there are gov contracts that the big boys deem too small and not worth their time, we pick up their scraps, offer a competitive bid, fulfill the contract at all costs, and make a profit. 

And within their first year of business, they landed over 100 US contracts which totaled up to over $10 million dollars. Then they landed a giant $298 million dollar contract.


-----------------------

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2020 Jake Tran. All rights reserved.

Sound:

Plucky Daisy - Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 3.0 License
https://creativecommons.org/licenses/by/3.0/ 

Kupla - Feathers https://spoti.fi/2SjgtCA 
Kupla - emerald https://spoti.fi/2P5Uh9p 
Kupla - Friendly Creatures https://spoti.fi/2EespN4 

Music by Chillhop: http://chillhop.com/listen
Listen on Spotify: http://bit.ly/ChillhopSpotify

DISCLAIMER: These videos are for entertainment purposes only. This is not meant to be financial advice. Please always do your due diligence and never stop learning. Best of luck!

AFFILIATE DISCLOSURE: Some of the links in this video description are affiliate links, meaning, at no additional cost to you, I may earn a commission if you click through and make a purchase and/or subscribe. I only promote products that I 100% believe in.

