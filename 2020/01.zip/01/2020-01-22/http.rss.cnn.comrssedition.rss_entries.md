# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## House managers kick off opening argument on why the Senate must hold Trump accountable
 - [https://www.cnn.com/politics/live-news/trump-impeachment-trial-01-22-20/index.html](https://www.cnn.com/politics/live-news/trump-impeachment-trial-01-22-20/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 21:42:17+00:00

• Analysis: At 1am, Chief Justice Roberts decided he had had enough
• Analysis: Things are worse now than ever
• Analysis: Bitter exchanges and incriminating evidence rock impeachment trial

## Macron shouts at Israeli security officers in altercation in Jerusalem
 - [https://www.cnn.com/2020/01/22/middleeast/france-macron-jerusalem-intl/index.html](https://www.cnn.com/2020/01/22/middleeast/france-macron-jerusalem-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 20:43:26+00:00

French President Emmanuel Macron has been involved in an altercation with Israeli security officers in Jerusalem's Old City.

## Kansas and Kansas State basketball game ends in all-out brawl
 - [https://www.cnn.com/2020/01/21/us/kansas-kansas-state-basketball-brawl-spt-trnd/index.html](https://www.cnn.com/2020/01/21/us/kansas-kansas-state-basketball-brawl-spt-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 19:35:55+00:00

A college basketball game between the University of Kansas and Kansas State University ended in an all-out brawl Tuesday.

## At 1am, Chief Justice Roberts had had enough
 - [https://www.cnn.com/2020/01/22/politics/john-roberts-admonishment-analysis/index.html](https://www.cnn.com/2020/01/22/politics/john-roberts-admonishment-analysis/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 19:31:34+00:00

John Roberts had been in the chair, presiding over the Senate impeachment trial for nearly 12 hours when he had had enough. He suddenly asserted his presence and made clear his rigorous sense of decorum.

## Senate chaplain delivers pointed message with prayer before trial
 - [https://www.cnn.com/2020/01/22/politics/senate-chaplain-impeachment-trial-prayer/index.html](https://www.cnn.com/2020/01/22/politics/senate-chaplain-impeachment-trial-prayer/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 19:03:52+00:00

The Senate's chaplain began Wednesday's proceedings in the impeachment trial of President Donald Trump with a prayer urging senators to "remember that patriots reside on both sides of the aisle," a pointed prayer that came hours after Chief Justice John Roberts scolded Democrats and Republicans for their bellicose tone on the trial's first full day.

## Terry Jones, 'Monty Python' star, dead at 77
 - [https://www.cnn.com/2020/01/22/entertainment/terry-jones-dies-scli-gbr-intl/index.html](https://www.cnn.com/2020/01/22/entertainment/terry-jones-dies-scli-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 18:41:47+00:00

"Monty Python" star Terry Jones has died aged 77, Britain's PA Media news agency has reported, citing his agent.

## Schiff claims Trump 'bragged' about withholding material from Congress
 - [https://www.cnn.com/collections/intl-impeachment-0122/](https://www.cnn.com/collections/intl-impeachment-0122/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 18:28:33+00:00



## Schiff claims Trump 'bragged' about withholding material
 - [https://www.cnn.com/2020/01/22/politics/adam-schiff-donald-trump-material-congress/index.html](https://www.cnn.com/2020/01/22/politics/adam-schiff-donald-trump-material-congress/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 18:24:16+00:00

The lead Democratic impeachment manager claimed Wednesday that President Donald Trump had "bragged" about withholding materials from Congress as lawmakers weigh removing him from office -- partly because they allege he's obstructing their investigations.

## See the market believed to be source of the virus
 - [https://www.cnn.com/videos/world/2020/01/22/coronavirus-outbreak-wuhan-ground-zero-china-culver-pkg-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2020/01/22/coronavirus-outbreak-wuhan-ground-zero-china-culver-pkg-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 18:19:40+00:00

A deadly outbreak of the new coronavirus emerged in Wuhan, China, a city of 11 million people in December 2019. Within weeks, the virus has killed nine people, sickened hundreds and spread as far as the United States. CNN's David Culver reports.

## Trump lawyers make at least three false claims
 - [https://www.cnn.com/2020/01/22/politics/trump-lawyers-impeachment-false-claims-scif/index.html](https://www.cnn.com/2020/01/22/politics/trump-lawyers-impeachment-false-claims-scif/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 18:09:42+00:00

President Donald Trump's legal team made at least three false claims during Senate impeachment proceedings on Tuesday, plus two more claims we'll call misleading.

## UN calls for investigation after Saudi crown prince implicated in hack of Jeff Bezos' phone
 - [https://www.cnn.com/2020/01/22/tech/jeff-bezos-mbs-phone-hack/index.html](https://www.cnn.com/2020/01/22/tech/jeff-bezos-mbs-phone-hack/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 18:05:38+00:00

A forensics team hired by Jeff Bezos has concluded with medium to high probability that a hack of the Amazon CEO's mobile phone originated from an account controlled by Saudi Crown Prince Mohammed bin Salman, according to a source.

## Inside one of the world's newest (and wettest!) national parks
 - [https://www.cnn.com/travel/article/ibera-national-park-argentina-new/index.html](https://www.cnn.com/travel/article/ibera-national-park-argentina-new/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 17:41:18+00:00

If the Everglades and the Serengeti had a child together, it might look a bit like the Iberá Wetlands of northeastern Argentina.

## Thousands of Nigerian slum dwellers left homeless after mass eviction
 - [https://www.cnn.com/2020/01/22/africa/nigeria-tarkwa-bay-evictions-intl/index.html](https://www.cnn.com/2020/01/22/africa/nigeria-tarkwa-bay-evictions-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 17:40:35+00:00

Authorities in Nigeria evicted thousands of impoverished residents from a Lagos slum, leaving many homeless, residents and eyewitnesses told CNN.

## Prince Charles: We need a new economic model or the planet will burn
 - [https://www.cnn.com/2020/01/22/business/prince-charles-climate-davos/index.html](https://www.cnn.com/2020/01/22/business/prince-charles-climate-davos/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 17:21:33+00:00

Only a revolution in the way the global economy and financial markets work can save the planet from the climate crisis and secure future prosperity, Prince Charles warned on Wednesday

## Orlando Bloom to voice Prince Harry in animated royal family comedy
 - [https://www.cnn.com/2020/01/22/entertainment/orlando-bloom-prince-harry-satire-gbr-intl-scli/index.html](https://www.cnn.com/2020/01/22/entertainment/orlando-bloom-prince-harry-satire-gbr-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 17:03:01+00:00

A new series based on the British royal family is coming to TV screens. And it's likely to be a world away from the stately realism of "The Crown."

## Life inside ground zero of the deadly virus outbreak
 - [https://www.cnn.com/collections/intl-china-wuhan-spreads/](https://www.cnn.com/collections/intl-china-wuhan-spreads/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 17:02:26+00:00



## Tesla finally wins the right to sell cars in Michigan
 - [https://www.cnn.com/2020/01/22/tech/tesla-michigan/index.html](https://www.cnn.com/2020/01/22/tech/tesla-michigan/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 16:57:11+00:00

Tesla is finally coming to Michigan, the home of the US auto industry.

## At 1am, Chief Justice Roberts decided he had had enough
 - [https://www.cnn.com/collections/intl-john-roberts-0122/](https://www.cnn.com/collections/intl-john-roberts-0122/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 16:57:03+00:00



## Trump dismisses injuries of US military troops, proves (again) there is no bottom
 - [https://www.cnn.com/2020/01/22/politics/donald-trump-iran-attack-headaches/index.html](https://www.cnn.com/2020/01/22/politics/donald-trump-iran-attack-headaches/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 16:46:19+00:00

Before leaving the internal gathering at Davos, Switzerland, on Wednesday, President Donald Trump held a hastily scheduled press conference. In it, he was asked about the clear discrepancy between his initial claim that no Americans had been harmed in Iran's retaliatory strikes against a US base in Iraq and reports of 11 military personnel diagnosed with concussions and an unnamed number of others also being treated in the wake of the attack.

## Tulsi Gabbard sues Hillary Clinton for defamation over Russia remarks
 - [https://www.cnn.com/2020/01/22/politics/tulsi-gabbard-hillary-clinton-lawsuit/index.html](https://www.cnn.com/2020/01/22/politics/tulsi-gabbard-hillary-clinton-lawsuit/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 16:23:28+00:00

Tulsi Gabbard filed a defamation lawsuit against Hillary Clinton on Wednesday, alleging the former secretary of state and 2016 Democratic presidential nominee "lied" about the Hawaii congresswoman's ties to Russia during a 2019 interview.

## US threatens to hike tariffs on UK car exports
 - [https://www.cnn.com/2020/01/22/business/steven-mnuchin-uk-car-taxes/index.html](https://www.cnn.com/2020/01/22/business/steven-mnuchin-uk-car-taxes/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 16:16:12+00:00

Treasury Secretary Steven Mnuchin said Wednesday that the United States would consider imposing tariffs on cars made in the United Kingdom if the country moves ahead with a tax on digital services.

## An Italian restaurant in Australia made a 100-meter pizza to raise funds for firefighters
 - [https://www.cnn.com/2020/01/22/australia/pizza-australia-firefighters-nsw-trnd/index.html](https://www.cnn.com/2020/01/22/australia/pizza-australia-firefighters-nsw-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 16:10:50+00:00

A brother and sister proved one size doesn't have to fit all when it comes to raising money for embattled firefighters in Australia: Their restaurant created a 103-meter long Margherita pizza that was gobbled up for charity.

## Jessica Simpson opens up about drinking and pill addiction in new memoir
 - [https://www.cnn.com/2020/01/22/entertainment/jessica-simpson-addiction-book-trnd/index.html](https://www.cnn.com/2020/01/22/entertainment/jessica-simpson-addiction-book-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 16:09:25+00:00

Jessica Simpson has written a memoir titled "Open Book," in which she reveals a struggle with alcohol and pills that led her to believe she was killing herself.

## Science may have found the secret to a better, and more sustainable, espresso coffee shot
 - [https://www.cnn.com/2020/01/22/us/how-to-make-brew-better-espresso-study-scn/index.html](https://www.cnn.com/2020/01/22/us/how-to-make-brew-better-espresso-study-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 16:05:05+00:00

Espresso is one of the most popular ways to drink coffee, but it's also the most complicated to make.

## Chess referee caught up in hijab controversy
 - [https://www.cnn.com/2020/01/22/sport/iran-chess-shohreh-bayat-spt-intl/index.html](https://www.cnn.com/2020/01/22/sport/iran-chess-shohreh-bayat-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 15:43:57+00:00

An Iranian chess referee says she is frightened to return home after she was criticized online for not wearing the appropriate headscarf during an international tournament.

## Tilda Swinton launches $4.6m campaign to save legendary filmmaker's home
 - [https://www.cnn.com/style/article/tilda-swinton-derek-jarman-prospect-cottage/index.html](https://www.cnn.com/style/article/tilda-swinton-derek-jarman-prospect-cottage/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 14:35:33+00:00

The Art Fund, a UK national fundraising charity for art, is launching a public appeal to save Prospect Cottage, the former home of visionary British filmmaker and activist Derek Jarman.

## Is Javier Hernandez the biggest MLS signing since David Beckham?
 - [https://www.cnn.com/2020/01/22/football/javier-chicharito-hernandez-la-galaxy-mls-spt-intl/index.html](https://www.cnn.com/2020/01/22/football/javier-chicharito-hernandez-la-galaxy-mls-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 14:25:36+00:00

LA Galaxy's signing of David Beckham in 2007 revolutionized Major League Soccer, helping draw more eyeballs to North American football than ever before.

## Bernie Sanders surges to join Biden atop Democratic presidential pack
 - [https://www.cnn.com/2020/01/22/politics/cnn-poll-sanders-biden-january-national/index.html](https://www.cnn.com/2020/01/22/politics/cnn-poll-sanders-biden-january-national/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 14:17:35+00:00

Vermont Sen. Bernie Sanders has improved his standing in the national Democratic race for president, joining former Vice President Joe Biden in a two-person top tier above the rest of the field, according to a new CNN poll conducted by SSRS.

## Greece gets its first female president
 - [https://www.cnn.com/2020/01/22/europe/greece-president-katerina-sakellaropoulou-intl/index.html](https://www.cnn.com/2020/01/22/europe/greece-president-katerina-sakellaropoulou-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 13:41:12+00:00

High court judge and human rights advocate Katerina Sakellaropoulou has been elected Greece's first female president by  parliament on Wednesday.

## This newly restored 15th-century lamb is worrying art lovers
 - [https://www.cnn.com/style/article/ghent-altarpiece-restoration-scli-intl/index.html](https://www.cnn.com/style/article/ghent-altarpiece-restoration-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 13:18:52+00:00

"There are no words to express the result" was the beaming reaction of Belgium's Royal Institute for Cultural Heritage, after a 15th-century masterpiece -- painted over shortly after completion -- was restored to its former glory.

## Woman says a plane passenger assaulted her as she slept
 - [https://www.cnn.com/2020/01/22/us/spirit-airlines-detroit-flight-alleged-assault/index.html](https://www.cnn.com/2020/01/22/us/spirit-airlines-detroit-flight-alleged-assault/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 13:17:32+00:00

A Michigan woman says a passenger assaulted her as she slept on a Spirit Airlines morning flight from Atlanta to Detroit.

## Kobe Bryant backs women to play in NBA 'right now'
 - [https://www.cnn.com/2020/01/22/sport/kobe-bryant-women-nba-spt-intl/index.html](https://www.cnn.com/2020/01/22/sport/kobe-bryant-women-nba-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 13:06:02+00:00

Basketball superstar Kobe Bryant lent his voice to calls for women to one day be allowed to compete in the NBA, claiming there are female stars who could make the leap right now.

## Trump: I'd love for these people to testify, but ...
 - [https://www.cnn.com/videos/politics/2020/01/22/trump-impeachment-trial-testimony-john-bolton-mike-pompeo-rick-perry-sot-vpx.cnn](https://www.cnn.com/videos/politics/2020/01/22/trump-impeachment-trial-testimony-john-bolton-mike-pompeo-rick-perry-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 12:53:02+00:00

President Donald Trump says former national security adviser John Bolton, Secretary of State Mike Pompeo, and former Secretary of Energy Rick Perry can't testify at his impeachment trial due to national security concerns.

## First fires, then floods. Now Australians need to watch out for deadly spiders
 - [https://www.cnn.com/2020/01/22/australia/australia-funnel-web-spider-intl-hnk-scli/index.html](https://www.cnn.com/2020/01/22/australia/australia-funnel-web-spider-intl-hnk-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 12:43:11+00:00

Australia has already dealt with extreme fires, flooding and hail this year. Now experts are warning people to watch out for deadly funnel-web spiders due to "perfect conditions" for the arachnid to thrive.

## Caroline Wozniacki accuses opponent of gamesmanship during Australian Open win
 - [https://www.cnn.com/2020/01/22/tennis/caroline-wozniacki-dayana-yastremska-australian-open-spt-intl/index.html](https://www.cnn.com/2020/01/22/tennis/caroline-wozniacki-dayana-yastremska-australian-open-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 12:41:15+00:00

Caroline Wozniacki has pointed the finger at her second round opponent at the Australian Open, accusing Dayana Yastremska of faking injury.

## Coco Gauff sets up Naomi Osaka showdown at Australian Open
 - [https://www.cnn.com/2020/01/22/tennis/naomi-osaka-coco-gauff-australian-open-tennis-spt-intl/index.html](https://www.cnn.com/2020/01/22/tennis/naomi-osaka-coco-gauff-australian-open-tennis-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 12:00:15+00:00

For the first time at a grand slam, Naomi Osaka has her dad watching on from the players' box during the Australian Open.

## Saved from the circus, tigers and lions freed into sanctuary
 - [https://www.cnn.com/videos/world/2020/01/22/big-cats-rescued-circuses-guatemala-south-africa-tigers-lions-mckenzie-pkg-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2020/01/22/big-cats-rescued-circuses-guatemala-south-africa-tigers-lions-mckenzie-pkg-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 10:24:25+00:00

Over the course of the 18-month "Operation Liberty" rescue mission, 21 tigers and lions were saved from circuses in Guatemala. Now 17 of those big cats will be arriving at a secret sanctuary in South Africa. CNN's David McKenzie reports from Free State, South Africa.

## Kim Kardashian 'solutionwear' brand Skims to launch in stores across the US
 - [https://www.cnn.com/style/article/kim-kardashian-west-skims-nordstrom/index.html](https://www.cnn.com/style/article/kim-kardashian-west-skims-nordstrom/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 09:52:16+00:00

Kim Kardashian West has announced a deal with US retailer Nordstrom to make her Skims range available in brick-and-mortar stores for the first time.

## Mother charged with killing 3 kids under age 4. Two victims tried to stop her, police say
 - [https://www.cnn.com/2020/01/22/us/phoenix-mother-children-smothered-wednesday/index.html](https://www.cnn.com/2020/01/22/us/phoenix-mother-children-smothered-wednesday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 09:29:25+00:00

An Arizona mother killed her three children, all under age 4, by smothering them, and one of the victims yelled and punched her to try and stop her, a court document shows.

## Man who killed the McStay family sentenced to death
 - [https://www.cnn.com/2020/01/22/us/mcstay-family-killer-sentenced/index.html](https://www.cnn.com/2020/01/22/us/mcstay-family-killer-sentenced/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 06:51:33+00:00

The man convicted of killing a California family of four and burying them in the Mojave Desert nearly 10 years ago has been sentenced to death, San Bernardino County Superior Court Judge Michael A. Smith announced in court on Tuesday.

## Toyota and Honda recall millions of vehicles
 - [https://www.cnn.com/2020/01/22/business/toyota-honda-recall/index.html](https://www.cnn.com/2020/01/22/business/toyota-honda-recall/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 06:19:29+00:00

Two of Japan's biggest automakers, Toyota and Honda, are recalling millions of cars over unrelated safety issues.

## Fashion's Chinese New Year quandary: Can rats ever be luxury?
 - [https://www.cnn.com/style/article/lunar-new-year-rat-fashion-campaigns/index.html](https://www.cnn.com/style/article/lunar-new-year-rat-fashion-campaigns/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 06:01:32+00:00

As the Year of the Rat nears, can rodents behind the bubonic plague ever appeal to China's luxury market?

## RuPaul is hosting 'SNL' for the first time
 - [https://www.cnn.com/2020/01/22/entertainment/snl-rupaul-host-trnd/index.html](https://www.cnn.com/2020/01/22/entertainment/snl-rupaul-host-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-22 05:14:12+00:00

This is not a drill, Mama Ru will be sashaying into Studio 8H.

