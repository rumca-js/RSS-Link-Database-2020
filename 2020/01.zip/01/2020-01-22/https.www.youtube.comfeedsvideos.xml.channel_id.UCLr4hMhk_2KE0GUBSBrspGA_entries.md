# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Latający fidget spinner: Flynova
 - [https://www.youtube.com/watch?v=fjrwRDdadaU](https://www.youtube.com/watch?v=fjrwRDdadaU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-01-23 00:00:00+00:00

Gadżet, którego nikt nie potrzebuje, dlatego kupiłem trzy.

