# Source:FRONTLINE PBS | Official, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ, language:en-US

## How Insys Therapeutics Bribed Doctors and Made Millions | FRONTLINE
 - [https://www.youtube.com/watch?v=NqXZnAczbkM](https://www.youtube.com/watch?v=NqXZnAczbkM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ
 - date published: 2020-01-23 00:00:00+00:00

Opioid maker Insys Therapeutics bribed doctors to prescribe a drug that’s stronger than heroin. It’s been linked to hundreds of deaths. Speaking publicly for the first time since the criminal trial against Insys executives began, the company’s former VP of sales explains how he ran the scheme.

Sales reps with “almost no conscience.” Vulnerable doctors. Quid pro quos. In his own words, WATCH what Alec Burlakoff says about how Insys bribed doctors to prescribe the opioid painkiller Subsys — and read more about the prison sentencing of Burlakoff and other Insys executives.

#OpioidCrisis #InsysTherapeutics #Documentary 

A full documentary and podcast investigating Insys Therapeutics, from FRONTLINE and The Financial Times, comes to PBS in the spring of 2020.

Director: Thomas Jennings
Producers: Annie Wong, Nick Verbitsky
Associate Producer: Rebecca Blandon
Line Producer: Julie Rasquin
Camera: John Baynard
Audio: John O'Connor
Editors: Miles Alvord and Pascal Akesson
Music: Griffin Jennings
 
Director of Digital Video: Carla Borrás
Managing Editor: Andrew Metz
Executive Producer: Raney Aronson-Rath

--

Subscribe on YouTube: http://bit.ly/1BycsJW

Instagram: https://www.instagram.com/frontlinepbs
Twitter: https://twitter.com/frontlinepbs
Facebook: https://www.facebook.com/frontline

FRONTLINE is streaming more than 200 documentaries online, for free, here: http://to.pbs.org/hxRvQP 

Funding for FRONTLINE is provided through the support of PBS viewers and by the Corporation for Public Broadcasting. Major funding for FRONTLINE is provided by the John D. and Catherine T. MacArthur Foundation and the Ford Foundation. Additional funding is provided by the Abrams Foundation, the Park Foundation, The John and Helen Glessner Family Trust, the Heising-Simons Foundation, and the FRONTLINE Journalism Fund with major support from Jon and Jo Ann Hagler on behalf of the Jon L. Hagler Foundation.

