# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## F-Droid - All Of Android Free (and Open Source) Software in One Place
 - [https://www.youtube.com/watch?v=7FfWz1NRQJQ](https://www.youtube.com/watch?v=7FfWz1NRQJQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2020-01-22 00:00:00+00:00

F-Droid is a repository of Free and Open Source apps for Android. It's your first step on the journey to improve your smartphone privacy and security.

Support me through Patreon: https://www.patreon.com/thehatedone 

- or donate anonymously:

Monero: 84DYxU8rPzQ88SxQqBF6VBNfPU9c5sjDXfTC1wXkgzWJfVMQ9zjAULL6rd11ASRGpxD1w6jQrMtqAGkkqiid5ef7QDroTPp

Bitcoin: 1HkDxXAVDFhBHSyRjam5WW5uoY88sxn5qz

If you want to regain more control over your device and enhance your privacy and security, F-Droid is where you want to start. F-Droid gives you the opportunity to take your phone completely Google-free, because you can find a free and privacy-respecting alternative for pretty much any mainstream app on Play Store that doesn’t sell your data to Facebook or Google. If you are running LineageOS or some other custom ROM, you can avoid Google privacy invasion through Play Store by using F-Droid instead. 

Sources
F-Droid https://f-droid.org/
How to install APK files from unknown sources on Android https://www.maketecheasier.com/install-apps-from-unknown-sources-android/ 
APK verifying tool https://apkpure.com/apk-signature-verification 
NetGuard https://f-droid.org/en/packages/eu.faircode.netguard/
WebApps https://f-droid.org/en/packages/com.tobykurien.webapps/
Bromite for F-Droid https://www.bromite.org/fdroid
DuckDuckGo Privacy Browser https://f-droid.org/en/packages/com.duckduckgo.mobile.android/
Firefox Focus (Klar) https://f-droid.org/en/packages/org.mozilla.klar/
New Pipe https://f-droid.org/en/packages/org.schabi.newpipe/
Simple Apps - all can be found on F-Droid https://www.simplemobiletools.com/

Credits:
Music by CO.AG Music https://www.youtube.com/channel/UCcavSftXHgxLBWwLDm_bNvA

Follow me:
https://twitter.com/The_HatedOne_
https://www.bitchute.com/TheHatedOne/
https://www.reddit.com/r/thehatedone/
https://www.minds.com/The_HatedOne

The footage and images featured in the video were for critical analysis, commentary and parody, which are protected under the Fair Use laws of the United States Copyright act of 1976.

