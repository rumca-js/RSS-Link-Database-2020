# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## The Best VR Headset... got BETTER!?
 - [https://www.youtube.com/watch?v=AGScX_8plYw](https://www.youtube.com/watch?v=AGScX_8plYw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-01-23 00:00:00+00:00

Request a free trial of CooperVision Biofinity Energys contact lenses, designed specifically for digital lifestyles!
USA: https://lmg.gg/bfenergystrial [lmg.gg]
Canada: https://lmg.gg/linus-tech [lmg.gg]

Save 10% and Free Worldwide Shipping at Ridge Wallets by using offer code LINUS at https://www.ridge.com/LINUS

The Oculus Quest was already arguably the best VR headset, at least in terms of versatility. But the addition of built-in hand tracking AND playing desktop VR games via Oculus Link might just make it the MUST-HAVE VR headset.

Buy Oculus Quest:
On Amazon: https://geni.us/iwObXF
On Newegg: https://geni.us/PBKbi6Y

Buy Anker Powerline+:
On Amazon: https://geni.us/YWJ2Gvx
On Newegg: https://geni.us/ccYUQ

Buy Active USB 3.0 Extension cable:
On Amazon: https://geni.us/UiYzxC
On Newegg: https://geni.us/FIPQsK

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1148376-the-best-vr-headset-got-better/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Come see us at LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

## I've been thinking of retiring.
 - [https://www.youtube.com/watch?v=hAsZCTL__lo](https://www.youtube.com/watch?v=hAsZCTL__lo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-01-22 00:00:00+00:00

I've been thinking of retiring.

## It’s time to upgrade your GPU - RX 5600 XT
 - [https://www.youtube.com/watch?v=rKn-vWDMkwQ](https://www.youtube.com/watch?v=rKn-vWDMkwQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-01-22 00:00:00+00:00

Go to https://privacy.com/linus ​to get $5 off your first purchase!

Get an unrestricted 30-day free trial of FreshBooks at https://www.freshbooks.com/techtips

The latest Steam Hardware Survey shows most people are still using a GPU from 3 years ago! Now that there's some more competition, maybe now is finally the right time to upgrade.

Buy a Radeon RX 5600 XT:
On Amazon (PAID LINK): https://geni.us/F2K2Zc
On Newegg (PAID LINK): https://lmg.gg/sBT4t

Buy a GeForce RTX 2060:
On Amazon (PAID LINK): https://geni.us/KK5GV8F
On Newegg (PAID LINK): https://lmg.gg/DOGw4

Buy a GeForce GTX 1660 SUPER:
On Amazon (PAID LINK): https://geni.us/Ps6JpK6
On Newegg (PAID LINK): https://lmg.gg/RRo1y

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1148022-it%E2%80%99s-time-to-upgrade-your-gpu-rx-5600-xt/

Our Affiliates, Referral Programs, and Sponsors:
https://linustechtips.com/main/topic/75969-linus-tech-tips-affiliates-referral-programs-and-sponsors
Displate metal posters: https://lmg.gg/displateltt

Linus Tech Tips merchandise at http://www.LTTStore.com/
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips
Our production gear: http://geni.us/cvOS
Our Chrono.gg game store: https://ltt.chrono.gg/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech

Intro Screen Music Credit: Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High
http://www.youtube.com/approachingnirvana

