# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## How I Pray & Meditate | Russell Brand
 - [https://www.youtube.com/watch?v=WoYG9vJ7CPY](https://www.youtube.com/watch?v=WoYG9vJ7CPY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-01-23 00:00:00+00:00

We're on Day 11 of the free course - 1 day left to take a look!
Check it out here: https://www.onecommune.com/a/20323/cGftrerE 

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

## Why Are These 3 Places BANNED From The Surveillance State?
 - [https://www.youtube.com/watch?v=Cvr94hqG34c](https://www.youtube.com/watch?v=Cvr94hqG34c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-01-22 00:00:00+00:00

A clip from my upcoming Under The Skin podcast with science communicator Ziya Tong. Ziya is author of The Reality Bubble: Blind Spots, Hidden Truths, and the Dangerous Illusions that Shape Our World. You can listen to the full podcast this Saturday 25th Jan only on Luminary - get the app here: http://luminary.link/russell

Come see me live on my Recovery Live tour in Australia, New Zealand and Canada - check the dates and get tickets here: https://www.russellbrand.com/live/

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

