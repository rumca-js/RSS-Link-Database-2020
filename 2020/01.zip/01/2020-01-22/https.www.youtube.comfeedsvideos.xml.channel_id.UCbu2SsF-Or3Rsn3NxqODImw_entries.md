# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Dragon Ball Z: Kakarot Review
 - [https://www.youtube.com/watch?v=4pRBgQrCSeg](https://www.youtube.com/watch?v=4pRBgQrCSeg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-01-23 00:00:00+00:00

Dragon Ball Z: Kakarot's emphasis on making the world and character interactions of Dragon Ball as important as the fights makes for a solid action-RPG experience.

#DragonBallZKakarot #GameSpotReview

## Kingdom Hearts 3 Re:Mind DLC Is Out On PS4
 - [https://www.youtube.com/watch?v=ap7pI7iBjjk](https://www.youtube.com/watch?v=ap7pI7iBjjk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-01-23 00:00:00+00:00

The Kingdom Hearts 3 DLC is finally here! Today we get to see the other half of the tale and even a few returning faces. Kingdom Hearts 3 Re:Mind is out now on PS4 and will be released on Xbox One on February 25th.

## Mortal Kombat 11 - Joker Fatalities, Brutalities, And Fatal Blow Gameplay
 - [https://www.youtube.com/watch?v=IzEu28-yCfk](https://www.youtube.com/watch?v=IzEu28-yCfk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-01-23 00:00:00+00:00

The Joker joins the Mortal Kombat roster! This PS4 gameplay shows off a variety of Fatalities, Brutalities and his Fatal Blow, as well as an alternate costume. Joker comes to Mortal Kombat 11 on January 28th.

## Warframe’s Ambitious 2020 Plans
 - [https://www.youtube.com/watch?v=RPwJ66804jQ](https://www.youtube.com/watch?v=RPwJ66804jQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-01-23 00:00:00+00:00

We sit down with Warframe's Rebb Ford to discuss the lessons Digital Extremes learned from 2019, and how the studio plans to adapt in 2020. Topics include: Digital Extremes' release schedule, managing player expectations, and the status of The New War, Duviri Paradox, and more.

## We Terrorize Humans in DEEEER Simulator
 - [https://www.youtube.com/watch?v=evXtBcUYx3Q](https://www.youtube.com/watch?v=evXtBcUYx3Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-01-22 00:00:00+00:00

Yet another insane animal simulator is out - DEEEER Simulator lets you play as a deer that can ... well, see for yourself.

