# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Gun Rallies, Gulags, And MLK: Week Of 1/22/20 Podcast
 - [https://www.youtube.com/watch?v=UvTDCNbVJP8](https://www.youtube.com/watch?v=UvTDCNbVJP8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-01-22 00:00:00+00:00

In this episode of The Babylon Bee podcast, editor-in-chief Kyle Mann and creative director Ethan Nicolle discuss this week's stories like the media hyping up a white nationalist rally which turned out to be a peaceful gun rights protest, a Bernie Sanders staffer getting caught preaching the benefits of gulags, and Nancy Pelosi catching flack for handing out commemorative pens to celebrate a somber day of impeachment. In the subscriber portion, Kyle, Ethan and producer Dan discuss the deaths of Christopher Tolkien, the death of Rush lyricist and master drummer Neil Peart, and talk about how much money a gang of known criminals is telling you they want to take from you.

 Doug TenNapel, a friend of the Bee, has a new Earthworm Jim Kickstarter.

  Pre-order the new Babylon Bee Best-Of Coffee Table Book coming in 2020!

 Show Outline

 Introduction - Kyle and Ethan talk about Ethan’s proficiency with a mandolin slicer, hilarious Amazon reviews, and how Disneyland is getting old for Kyle’s kids. Kyle tells Ethan he is as beautiful and perfect as a Trump phone call.

 Story 1 -  Media Offers Thoughts And Prayers That Someone Would Start Some Violence At Gun Rights Rally

   VA government is considering several gun control measures such as: a return to Virginia’s one-handgun-per-month purchase policy; red flag laws; and universal background checks for all gun sales except those among immediate family members, through inheritance or antiques.

   Big media and blue checkmarks hyped up the protest rally as a "white nationalist rally" and militias and insurrectionists who were going to be threatening. See Ben Collins' now-deleted tweet or this montage of CNN and MSNBC for example.

   "They're not coming to peacefully protest. They are coming to intimidate and cause harm," Gov Northam said declaring a state of emergency and banning all carrying of guns in the capital square.

    22,000 gun rights activists showed up and finished peacefully. They even cleaned up after themselves.   People were openly and legally carrying firearms, including AR-style rifles, outside the gun-free Capitol Square.

   Story 2 -  Bernie Sanders Clarifies His Gulags Will Be Democratic Gulags

   Project Veritas (James O’Keefe, a conservative political activist) releases undercover video of one of Bernie Sanders’ “top tier Iowa organizer” Staffer Kyle Jurek saying cities [will] burn” if President Donald Trump is re-elected, “free education” policies to “teach you how to not be a "flowerbed"-ing nazi.”; 'There is a reason Stalin had Gulags'; 'Expect violent reaction' for speech. If Bernie doesn't get nomination "Milwaukee will burn"... Project Veritas says they have more clips of more people too.

   The video has millions of views, almost zero coverage in mainstream media, and zero comment from Sanders campaign.

   Story 3 -  Pelosi Releases Limited-Edition Replica Of Dentures Worn During Trump Impeachment

   'They claim it's a somber, serious occasion they're heartbroken over...and then they pass out impeachment-signing pens with special cases.'

   The pens look like they are especially engraved, with gold, and were brought out on silver platters of some kind.

   Hate Mail - We got a special flowerbed-filled hate mail this week that trashed us and our audience.

 Topic of the Week - Martin Luther King, Jr. Day and Race

   MLK Jr was the most visible spokesperson for civil rights through non-violent protest movements inspired by Mohatma Ghandi/India Independence. 

   1955 organized Montgomery bus protest after Rosa Parks refused to give up her seat.

   Fought against desegregation and for voter’s rights

   In 1963 March on Washington gave his 'I Have A Dream' speech

   In 1964 won the nobel peace prize.

   Was investigated and spied on by the government for his supposed communist sympathies

   Assassinated in Memphis, TN in 1968.

   Joe Carter of TGC has  9 things you need to know about him. 

   Dr.  Robert Gagnon points out some of the controvery in modern evangelical circles regarding whether we should we praise King while condemning Trump.

     Is MLK cancelled? 

   Conservatives and leftists both try to make MLK Jr supports their views on social justice, economics, or affirmative action.

   What does the Bible say about race?

   What did MLK’s speech actually say ( we read from lengethier sections)

   "I have a dream that one day this nation will rise up and live out the true meaning of its creed: "We hold these truths to be self-evident, that all men are created equal."

   "I have a dream that my four little children will one day live in a nation where they will not be judged by the color of their skin but by the content of their character."

   “Unearned suffering is redemptive.” Ethan also mentions Man’s Search For Meaning

       What are some principles we can apply to the race issue to cut through the...

