# Source:Laowhy86, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw, language:en-US

## China's Coronavirus is Much Worse Than You Think
 - [https://www.youtube.com/watch?v=VLp8CHeKQkI](https://www.youtube.com/watch?v=VLp8CHeKQkI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw
 - date published: 2020-01-22 00:00:00+00:00

The coronavirus in China is spreading, and largely could have been prevented. A town 7 km from where the virus was discovered in Wuhan had a state run banquet with 100,000 people eating off of the same dishes. This was 2 days after 49 cases were confirmed in Wuhan, China. The Chinese government is trying to save face, and now it is backfiring. 

◘ Support me on Patreon for early release, and much more! http://www.patreon.com/laowhy86

◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

◘ OR Become a Sponsor on YouTube:
https://www.youtube.com/channel/UChvithwOECK5g_19TjldMKw/sponsor

◘ My TV show: Conquering Northern China:
https://vimeo.com/ondemand/conqueringnorthernchina

◘ Conquering Southern China
https://vimeo.com/ondemand/conqueringsouthernchina

◘ Discount code for both shows: laowinning

◘ Join me every week for videos about China! Don't forget to subscribe!
http://www.youtube.com/laowhy86

For Motorcycle adventures around the world, and a talk-show on two wheels go to ADVChina every Monday 1 PM EST/ 10 AM PST
https://www.youtube.com/advchina
Why China thinks it's better than you
https://youtu.be/ExPUFA6Hxeo

For a realistic perspective on China and world travel from an American father and a Chinese mother with two half-Chinese daughters go to Laowhy86 every Wednesday 1 PM EST/ 10 AM PST
https://www.youtube.com/laowhy86

For a no-nonsense on the street look at Chinese culture and beyond from China’s original YouTuber, join SerpentZA on Friday at 1 PM EST/ 10 AM PST
https://www.youtube.com/serpentza
New Video - Why did China invent the Social Credit system?
https://youtu.be/2XLTxgwf6Gk

Be a Laowinner!
Like comment subscribe!

◘ Facebook:
http://www.facebook.com/laowhy86

◘ Instagram: 
http://instagram.com/laowhy86

◘ Music in this video - The Muse Maker
https://soundcloud.com/themusemaker

◘ Music used most of the time - New World Hip Hop
https://soundcloud.com/apollodrivenz
https://www.youtube.com/channel/UCgirAE5d8ufiotRXmBZZbBQ

