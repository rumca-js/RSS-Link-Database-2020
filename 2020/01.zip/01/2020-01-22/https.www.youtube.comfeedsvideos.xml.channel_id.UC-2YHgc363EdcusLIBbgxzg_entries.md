# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## Meet Your Tiniest Ancestor (Who Might Still Be Around) | Random Thursday
 - [https://www.youtube.com/watch?v=sJ3AWZAAs1M](https://www.youtube.com/watch?v=sJ3AWZAAs1M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2020-01-23 00:00:00+00:00

Homo Floresiensis is a human ancestor that lived only 18,000 years ago - while humans were still around. How did they get there? Why are they so small? And could there still be some of them around?

Support the channel here!
Patreon!: http://www.patreon.com/answerswithjoe

Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Get cool nerdy t-shirts at
http://www.answerswithjoe.com/shirts

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

