# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## FAKE GURU DEBATE: JOHN CRESTANI VS COFFEEZILLA
 - [https://www.youtube.com/watch?v=hRHBC1AtEv8](https://www.youtube.com/watch?v=hRHBC1AtEv8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-01-22 00:00:00+00:00

I say all the time that anyone can challenge me on my show. I extend an open invitation to gurus! Up till now, all the fake gurus have been scared to... Until today.  

John "Racks" Crestani has stepped up to the plate.
we're going to be debating the following:
Refunds
Financing
Stefan James of Project Life Mastery 
Copywriting/Webinars

John Crestani describes himself as: "John Crestani is a growth hacker known for his contributions in helping companies reach more people and sell more products using the business model of affiliate marketing. He is an online expert in all forms of paid advertising; from Facebook Ads, Google Adwords, Youtube Ads, and Native advertising networks."

