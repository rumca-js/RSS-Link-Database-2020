# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Don Gavin Remembers a Wild Night at Boston Comedy Club Ding Ho
 - [https://www.youtube.com/watch?v=a_Y6auOeixc](https://www.youtube.com/watch?v=a_Y6auOeixc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-23 00:00:00+00:00

Taken from JRE #1418 w/Don Gavin: https://youtu.be/vPDRlhgblZg

## Don Gavin Was a Teacher By Day, Comic By Night | Joe Rogan
 - [https://www.youtube.com/watch?v=xLSzreIigFg](https://www.youtube.com/watch?v=xLSzreIigFg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-23 00:00:00+00:00

Taken from JRE #1418 w/Don Gavin:
https://youtu.be/vPDRlhgblZg

## How the Legendary Boston Comedy Scene Was Born w/Don Gavin | Joe Rogan
 - [https://www.youtube.com/watch?v=zJni2GS1VFo](https://www.youtube.com/watch?v=zJni2GS1VFo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-23 00:00:00+00:00

Taken from JRE #1418 w/Don Gavin:
https://youtu.be/vPDRlhgblZg

## The IRS Came After the Boston Comics w/Don Gavin | Joe Rogan
 - [https://www.youtube.com/watch?v=-QqpmjBiYXc](https://www.youtube.com/watch?v=-QqpmjBiYXc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-23 00:00:00+00:00

Taken from JRE #1418 w/Don Gavin:
https://youtu.be/vPDRlhgblZg

## Can You Prevent Leg Breaks from Leg Kicks? w/Kevin Ross | Joe Rogan
 - [https://www.youtube.com/watch?v=2pr_FNl9fwo](https://www.youtube.com/watch?v=2pr_FNl9fwo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-22 00:00:00+00:00

Taken from JRE #1417 w/Kevin Ross: 
https://youtu.be/XiWYB_xTd9k

## Does DNA Make Us Who We Are?
 - [https://www.youtube.com/watch?v=iecHAAk-YjI](https://www.youtube.com/watch?v=iecHAAk-YjI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-22 00:00:00+00:00

Taken from JRE #1417 w/Kevin Ross: https://youtu.be/XiWYB_xTd9

## Joe Rogan on Why You Need Hardship to Thrive
 - [https://www.youtube.com/watch?v=sxKYgezFFZ8](https://www.youtube.com/watch?v=sxKYgezFFZ8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-22 00:00:00+00:00

Taken from JRE #1417 w/Kevin Ross: https://youtu.be/XiWYB_xTd9

## Joe Rogan: Conversation is a Lost Art
 - [https://www.youtube.com/watch?v=v2Aak7sbXO8](https://www.youtube.com/watch?v=v2Aak7sbXO8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-22 00:00:00+00:00

Taken from JRE #1417 w/Kevin Ross: https://youtu.be/XiWYB_xTd9

## Kevin Ross Overcame Alcohol Addiction to Become a Champion | Joe Rogan
 - [https://www.youtube.com/watch?v=wnk0lsfKTfo](https://www.youtube.com/watch?v=wnk0lsfKTfo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-22 00:00:00+00:00

Taken from JRE #1417 w/Kevin Ross: 
https://youtu.be/XiWYB_xTd9k

## Kevin Ross Recounts Heart Wrenching Story of Sexual Abuse | Joe Rogan
 - [https://www.youtube.com/watch?v=_1JWY4wqpk0](https://www.youtube.com/watch?v=_1JWY4wqpk0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-22 00:00:00+00:00

Taken from JRE #1417 w/Kevin Ross: 
https://youtu.be/XiWYB_xTd9k

## Muai Thai Fighter Kevin Ross: We’re All One Bad Day From Failure
 - [https://www.youtube.com/watch?v=aL2DxQHwoiA](https://www.youtube.com/watch?v=aL2DxQHwoiA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-22 00:00:00+00:00

Taken from JRE #1417 w/Kevin Ross: https://youtu.be/XiWYB_xTd9

## Nothing’s Normal  Everything’s Crazy  No One Knows What’s Going On
 - [https://www.youtube.com/watch?v=wzfayEv9dG0](https://www.youtube.com/watch?v=wzfayEv9dG0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-22 00:00:00+00:00

Taken from JRE #1417 w/Kevin Ross: https://youtu.be/XiWYB_xTd9

## There is No Destination: Just a Journey — Joe Rogan
 - [https://www.youtube.com/watch?v=vHCY0nRI9_M](https://www.youtube.com/watch?v=vHCY0nRI9_M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-22 00:00:00+00:00

Taken from JRE #1417 w/Kevin Ross: https://youtu.be/XiWYB_xTd9

