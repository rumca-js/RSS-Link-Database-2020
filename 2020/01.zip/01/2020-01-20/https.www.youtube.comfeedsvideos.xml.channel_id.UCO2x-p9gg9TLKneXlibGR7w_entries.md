# Source:Snazzy Labs, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w, language:en-US

## We Ditched Mac Pro for THIS...
 - [https://www.youtube.com/watch?v=P2dACq3F_W4](https://www.youtube.com/watch?v=P2dACq3F_W4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w
 - date published: 2020-01-20 00:00:00+00:00

The 2019 Mac Pro has been lauded by many as the end-all-be-all of video editing workstations. But that's only if you have big $$$. We put Linux on our AMD Ryzen 3950X PC and see how it holds up.

Follow me on Twitter - http://twitter.com/snazzyq
Follow me on Instagram - http://instagram.com/snazzyq

Many tech YouTubers use Final Cut Pro X and Adobe Premiere Pro to edit their videos, but Derek, the cinematographer here at Snazzy Labs uses Blackmagic Davinci Resolve. Unlike the other two popular NLEs, Resolve is available for Mac, Windows, and Linux but was originally developed for Linux to use in a professional studio/post-processing environment. We took our PC rocking a 3950X CPU, a GTX 1080 (ya, we know, we're waiting on the new 2080 Ti Super), and put this thing to the test. Not only does it run Linux, but it does so very well. Running the Debian/Ubuntu-based Pop!_OS, this thing is ready to rumble.

