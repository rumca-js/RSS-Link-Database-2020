# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## The Dragon Prince S1 - REVIEW
 - [https://www.youtube.com/watch?v=CpjjSaNJXMY](https://www.youtube.com/watch?v=CpjjSaNJXMY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-01-21 00:00:00+00:00

My review of the Dragon Prince on Netflix. What do you think of The Dragon Prince? 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene
 
P.O. Box 1016 Dublin, Ohio 43017
with the backup of:
715 Shawan falls Dr. Dublin, Ohio 43017

## PEACE TALKS COVER, ANOTHER SANDERSON LIVE STREAM, WoT SCRIPT PIC - FANTASY NEWS
 - [https://www.youtube.com/watch?v=xVc7ElBtbYg](https://www.youtube.com/watch?v=xVc7ElBtbYg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-01-20 00:00:00+00:00

Enjoy the news! 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene
 
P.O. Box 1016 Dublin, Ohio 43017
with the backup of:
715 Shawan falls Dr. Dublin, Ohio 43017

NEWS: 

Waititi Star Wars: https://twitter.com/DiscussingFilm/status/1217942706317594624

Watchmen latest news: https://decider.com/2020/01/16/watchmen-season-2-casey-bloys-damon-lindelof/

Brandon Sanderson Livestream: https://twitter.com/BrandSanderson/status/1217939535071367169?s=20

THE WATCH images: https://thewertzone.blogspot.com/2020/01/bbc-america-release-first-publicity.html

WoT Script Images: https://twitter.com/wheeloftimenews/status/1218139879902732294

Peace Talks Cover: https://ew.com/books/2020/01/16/jim-butcher-peace-talks-preview/

Dark Horse Alien: https://www.hollywoodreporter.com/heat-vision/dark-horse-publish-alien-original-screenplay-comic-book-series-1270420

Cyberpunk 2077 crunch: https://www.ign.com/articles/cyberpunk-2077-developers-to-crunch-despite-delay

Obi-Wan hoax: https://www.thewrap.com/no-the-star-wars-disney-series-about-obi-wan-kenobi-has-not-been-canceled/

The Last God D&D: https://screenrant.com/dc-last-god-dnd-sourcebook-dungeons-dragons/

Sanderson Live Stream: https://www.youtube.com/watch?v=H4lWbkERlxo

