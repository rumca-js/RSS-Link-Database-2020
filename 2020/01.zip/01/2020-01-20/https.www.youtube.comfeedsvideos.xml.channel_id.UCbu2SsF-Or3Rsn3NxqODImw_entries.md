# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## 7 Minutes Of Brutal DOOM Eternal PC Gameplay
 - [https://www.youtube.com/watch?v=kIkogIe9Qp4](https://www.youtube.com/watch?v=kIkogIe9Qp4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-01-21 00:00:00+00:00

Hell on earth has become a reality. In this PC gameplay, the Doom Slayer faces off against new and returning enemies including Hell Knights, Revenants, and Gargoyles in all-new multi-leveled environments. DOOM Eternal releases for PS4, Xbox One, and PC on March 20th.

## DOOM Eternal Has A Hub Area, Here's What's In it
 - [https://www.youtube.com/watch?v=na-0a3OSyKE](https://www.youtube.com/watch?v=na-0a3OSyKE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-01-21 00:00:00+00:00

Behold the Fortress of Doom. This massive hub is where you can find armor upgrades, training grounds, and several unlockable items. To unlock the entire fortress you'll need to restore power using a number of sentinel batteries. DOOM Eternal releases for PS4, Xbox One, and PC on March 20th.

## DOOM Eternal Is Metal As F**k
 - [https://www.youtube.com/watch?v=ttVIdbD7tO8](https://www.youtube.com/watch?v=ttVIdbD7tO8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-01-21 00:00:00+00:00

We played the first three hours of Doom Eternal on PC and saw QUITE A LOT. In the video above, Mike recounts his hellish escapades to Ashley while she does her best to understand what on Earth he's talking about.

## DOOM Eternal's Combat Is Absolute Chaos, And It's Awesome
 - [https://www.youtube.com/watch?v=kNoBL1cYLqU](https://www.youtube.com/watch?v=kNoBL1cYLqU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-01-21 00:00:00+00:00

We spent three hours with Doom Eternal on PC, we try to explain just how intense, bloody, and ultra-fast demon slaying is. Glory kills, chainsaws, super shotguns, hookshots, dashing through the air, it's all there. DOOM Eternal releases for PS4, Xbox One, and PC on March

## DOOM Eternal: Glory Kills Compilation
 - [https://www.youtube.com/watch?v=zXes95xZ8uo](https://www.youtube.com/watch?v=zXes95xZ8uo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-01-21 00:00:00+00:00

Glory kills are back! DOOM Eternal's fast-paced combat sees the return of the satisfyingly gruesome glory kill. Like in 2016’s DOOM, an enemy will blink when they’re weak enough to activate the gory final blow. Here’s a very NSFW compilation of all the glory kills we’ve seen so far. DOOM Eternal comes to PS4, Xbox One, and PC on March 20th.

## Pokemon-Inspired MMO, Temtem, Just Launched Early Access
 - [https://www.youtube.com/watch?v=rbHItbzOZLo](https://www.youtube.com/watch?v=rbHItbzOZLo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-01-21 00:00:00+00:00

Now that Pokemon-Inspired MMO Temtem is in early access, let's get past the crazy login queues and see what Temtem we can capture & evolve!

## 7 Wildly Unique Games You Should Play In 2020
 - [https://www.youtube.com/watch?v=rSBwd0QybQE](https://www.youtube.com/watch?v=rSBwd0QybQE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-01-20 00:00:00+00:00

2020 is set to feature a bunch of exciting-looking games that you may have forgotten about! Here are some we're looking forward to that range from breathtaking adventures to brutal horror, arriving on PS4, Xbox One, PC, and Nintendo Switch.

0:28 Way To The Woods
1:17 The Pathless
2:10 Twelve Minutes
3:00 Mineko's Night Market
3:40 Carrion
4:31 Kentucky Route Zero: TV Edition
5:21 Empire of Sin

## Warframe's Rebb Ford Predicts 23 Celebrities' Favorite Frames
 - [https://www.youtube.com/watch?v=FSCWwGRPljo](https://www.youtube.com/watch?v=FSCWwGRPljo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-01-20 00:00:00+00:00

Rebecca Ford of Warframe fame... warframe stopped by the GameSpot NY office to chat with Mike Mahardy. They had a very serious discussion about very serious people.

