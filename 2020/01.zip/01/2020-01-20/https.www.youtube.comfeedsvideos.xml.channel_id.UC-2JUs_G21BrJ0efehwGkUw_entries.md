# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Etta James Lauryn Hill mashup ft. Maiya Sykes & Ben Folds
 - [https://www.youtube.com/watch?v=9wNPug7h1gQ](https://www.youtube.com/watch?v=9wNPug7h1gQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2020-01-20 00:00:00+00:00

Patreon: http://modal.scarypocketsfunk.com/patreon
Store: https://www.scarypocketsfunk.com
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A mashup of Etta James' "I'd Rather Go Blind" and Lauryn Hill’s “Doo Wop” by Scary Pockets.

CREDITS
Lead vocal: Maiya Sykes
Piano/tambourine: Ben Folds
Keys: Jack Conte
Guitar: Ryan Lerman
Drums: Tamir Barzilay
Bass: Joe Ayoub 

Recording Engineer: Caleb Parker
Mixing/Mastering: Caleb Parker
Video Production: Ricky Chavez

Recorded Live at Scary Pockets HQ in Highland Park, CA. 

Watch more videos! 
All of Scary Pockets: http://modal.scarypocketsfunk.com/full-yt-catalog 
90s Hits Funkified: http://modal.scarypocketsfunk.com/90s-yt-hits 
Scary Goldings: http://modal.scarypocketsfunk.com/yt-scary-goldings 
Most Popular: http://modal.scarypocketsfunk.com/top-yt-hits

#ScaryPockets #Funk #EttaJames #LaurenHill #Mashup

