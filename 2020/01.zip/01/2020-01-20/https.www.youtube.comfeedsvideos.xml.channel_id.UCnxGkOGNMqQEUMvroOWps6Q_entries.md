# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Anti-Semitism is Built Into the Scaffolding of Western Civilization?
 - [https://www.youtube.com/watch?v=kxMpLI8JnN0](https://www.youtube.com/watch?v=kxMpLI8JnN0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-21 00:00:00+00:00

Taken from JRE #1415 w/Bari Weiss: https://youtu.be/nL-YwrjKqZU

## Bari Weiss Anti-Semitic Attacks in NYC
 - [https://www.youtube.com/watch?v=kiI7Lo0o3vc](https://www.youtube.com/watch?v=kiI7Lo0o3vc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-21 00:00:00+00:00

Taken from JRE #1415 w/Bari Weiss: https://youtu.be/nL-YwrjKqZU

## Bari Weiss Deconstructs “Great Replacement” Conspiracy Theory
 - [https://www.youtube.com/watch?v=_kSigGDhlXA](https://www.youtube.com/watch?v=_kSigGDhlXA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-21 00:00:00+00:00

Taken from JRE #1415 w/Bari Weiss: https://youtu.be/nL-YwrjKqZU

## Bari Weiss on Trump and the Mainstreaming of Alt-Right Ideas
 - [https://www.youtube.com/watch?v=I-0lfxHoF5I](https://www.youtube.com/watch?v=I-0lfxHoF5I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-21 00:00:00+00:00

Taken from JRE #1415 w/Bari Weiss: https://youtu.be/nL-YwrjKqZU

## Bari Weiss: There’s Anti-Semitism on the Left, Too
 - [https://www.youtube.com/watch?v=kZ3HRHidAhY](https://www.youtube.com/watch?v=kZ3HRHidAhY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-21 00:00:00+00:00

Taken from JRE #1415 w/Bari Weiss: https://youtu.be/nL-YwrjKqZU

## Bari Weiss: What’s So Troublesome About Anti-Zionism
 - [https://www.youtube.com/watch?v=zV4kML9eHyQ](https://www.youtube.com/watch?v=zV4kML9eHyQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-21 00:00:00+00:00

Taken from JRE #1415 w/Bari Weiss: https://youtu.be/nL-YwrjKqZU

## Cheerleading Led Rob Kearney to Being a Strongman | Joe Rogan
 - [https://www.youtube.com/watch?v=6CANf2tZrzU](https://www.youtube.com/watch?v=6CANf2tZrzU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-21 00:00:00+00:00

Taken from JRE #1416 w/Rob Kearney:
https://youtu.be/74TaVlSuipo

## Circumcisions Are Unnecessary And They Kill Hundreds of Babies a Year
 - [https://www.youtube.com/watch?v=htEObEvAMTE](https://www.youtube.com/watch?v=htEObEvAMTE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-21 00:00:00+00:00

Taken from JRE #1415 w/Bari Weiss: https://youtu.be/nL-YwrjKqZU

## How Professional Strongman Rob Kearney Prepares for Competition
 - [https://www.youtube.com/watch?v=gYdvYwtm6iI](https://www.youtube.com/watch?v=gYdvYwtm6iI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-21 00:00:00+00:00

Taken from JRE #1416 w/Rob Kearney: https://youtu.be/74TaVlSuipo

## Joe Rogan Discusses Presidential Candidates with Bari Weiss
 - [https://www.youtube.com/watch?v=F0PT_vQXtZM](https://www.youtube.com/watch?v=F0PT_vQXtZM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-21 00:00:00+00:00

Taken from JRE #1415 w/Bari Weiss:
https://youtu.be/nL-YwrjKqZU

## Joe Rogan and Bari Weiss on Free Speech and Online Radicalization
 - [https://www.youtube.com/watch?v=1bTbv_o5Whg](https://www.youtube.com/watch?v=1bTbv_o5Whg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-21 00:00:00+00:00

Taken from JRE #1415 w/Bari Weiss: https://youtu.be/nL-YwrjKqZU

## Pro Strongman Rob Kearney on Being An Openly Gay Athlete
 - [https://www.youtube.com/watch?v=vmGPfyPkbKo](https://www.youtube.com/watch?v=vmGPfyPkbKo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-21 00:00:00+00:00

Taken from JRE #1416 w/Rob Kearney: https://youtu.be/74TaVlSuipo

## Religion Replacing Politics w/Bari Weiss | Joe Rogan
 - [https://www.youtube.com/watch?v=gByvD2zrU10](https://www.youtube.com/watch?v=gByvD2zrU10)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-21 00:00:00+00:00

Taken from JRE #1415 w/Bari Weiss:
https://youtu.be/nL-YwrjKqZU

## Rob Kearney Explains How They Choose Strongman Challenges
 - [https://www.youtube.com/watch?v=2qYslaMBHw8](https://www.youtube.com/watch?v=2qYslaMBHw8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-21 00:00:00+00:00

Taken from JRE #1416 w/Rob Kearney: https://youtu.be/74TaVlSuipo

## Rob Kearney on Being an Openly Gay Strongman | Joe Rogan
 - [https://www.youtube.com/watch?v=gG_D5UBS0Uw](https://www.youtube.com/watch?v=gG_D5UBS0Uw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-21 00:00:00+00:00

Taken from JRE #1416 w/Rob Kearney:
https://youtu.be/74TaVlSuipo

## Strongman Rob Kearney Pulled 2 Monster Trucks | Joe Rogan
 - [https://www.youtube.com/watch?v=N_9ySaTwNvY](https://www.youtube.com/watch?v=N_9ySaTwNvY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-21 00:00:00+00:00

Taken from JRE #1416 w/Rob Kearney:
https://youtu.be/74TaVlSuipo

## The Deadly Sleep Disorder Common Among Strongmen
 - [https://www.youtube.com/watch?v=9N4BGrxzeuA](https://www.youtube.com/watch?v=9N4BGrxzeuA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-21 00:00:00+00:00

Taken from JRE #1416 w/Rob Kearney: https://youtu.be/74TaVlSuipo

## The Real Problem with Elizabeth Warren Saying She's Native American | Joe Rogan
 - [https://www.youtube.com/watch?v=ch_EJ7BC4jo](https://www.youtube.com/watch?v=ch_EJ7BC4jo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-21 00:00:00+00:00

Taken from JRE #1415 w/Bari Weiss:
https://youtu.be/nL-YwrjKqZU

## There’s a Strongman Competition Based on Conan’s Wheel of Pain
 - [https://www.youtube.com/watch?v=ozLwZ9Cr1IE](https://www.youtube.com/watch?v=ozLwZ9Cr1IE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-21 00:00:00+00:00

Taken from JRE #1416 w/Rob Kearney: https://youtu.be/74TaVlSuipo

## Why Bari Weiss Wrote “How to Fight Anti Semitism”
 - [https://www.youtube.com/watch?v=7xRRSkGsoZA](https://www.youtube.com/watch?v=7xRRSkGsoZA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-21 00:00:00+00:00

Taken from JRE #1415 w/Bari Weiss: https://youtu.be/nL-YwrjKqZU

## Courage vs. Conformity | JRE 10 Year Anniversary
 - [https://www.youtube.com/watch?v=6OkZOxK8pN4](https://www.youtube.com/watch?v=6OkZOxK8pN4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-20 00:00:00+00:00

Taken from JRE 10 Years in Review:
https://www.youtube.com/watch?v=_IBDvROmdGU

## It's Mike Tyson! | JRE 10 Year Anniversary
 - [https://www.youtube.com/watch?v=oqO6JNnYn9w](https://www.youtube.com/watch?v=oqO6JNnYn9w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-20 00:00:00+00:00

Taken from JRE 10 Years in Review:
https://www.youtube.com/watch?v=_IBDvROmdGU

## Joe "Have You Ever Done DMT?" Rogan | JRE 10 Year Anniversary
 - [https://www.youtube.com/watch?v=A0JlDI3pasc](https://www.youtube.com/watch?v=A0JlDI3pasc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-20 00:00:00+00:00

Taken from JRE 10 Years in Review:
https://www.youtube.com/watch?v=_IBDvROmdGU

## Joe Rogan Experience Cartoon Opening | JRE 10 Year Anniversary
 - [https://www.youtube.com/watch?v=a_uR8D-JVNI](https://www.youtube.com/watch?v=a_uR8D-JVNI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-20 00:00:00+00:00

Taken from JRE 10 Years in Review:
https://www.youtube.com/watch?v=_IBDvROmdGU

Animation by Freddie Crocheron 

Music by Paul Cecchetti

