# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Karen Carney column: Why Mikel Arteta is making Arsenal fitter and better
 - [https://www.bbc.co.uk/sport/football/51123201](https://www.bbc.co.uk/sport/football/51123201)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 22:21:33+00:00

In her latest BBC Sport column, Karen Carney analyses how Mikel Arteta is making Arsenal fitter and better.

## The battle over which flag to fly in America's Chinatowns
 - [https://www.bbc.co.uk/news/world-us-canada-51129460](https://www.bbc.co.uk/news/world-us-canada-51129460)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 20:00:57+00:00

Chinatowns across the US are switching to the flag of mainland China, but not without protest.

## Sittingbourne widower learns ballet and passes exam
 - [https://www.bbc.co.uk/news/uk-england-kent-51182411](https://www.bbc.co.uk/news/uk-england-kent-51182411)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 18:24:02+00:00

Bernard Bibby took up the ballet classes four years ago following the death of his wife of 55 years.

## Sri Lanka: 'Too many twins' hinder world record attempt
 - [https://www.bbc.co.uk/news/world-asia-51182271](https://www.bbc.co.uk/news/world-asia-51182271)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 17:50:17+00:00

An event vying to be the world's largest gathering of twins hit problems thanks to a huge turnout.

## Cardiff's Fitzalan High class all receive A* GCSE grade
 - [https://www.bbc.co.uk/news/uk-wales-51182051](https://www.bbc.co.uk/news/uk-wales-51182051)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 17:16:56+00:00

The pupils gasped as they realised they had all achieved the top result, their assistant head teacher says.

## Can one mile take 10 years off your life?
 - [https://www.bbc.co.uk/news/51149506](https://www.bbc.co.uk/news/51149506)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 15:15:32+00:00

Is Sir Keir Starmer right that Somers Town in London has life expectancy 10 years below somewhere a mile away?

## Jones names eight uncapped players in England Six Nations squad
 - [https://www.bbc.co.uk/sport/rugby-union/51173798](https://www.bbc.co.uk/sport/rugby-union/51173798)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 12:28:16+00:00

England head coach Eddie Jones names eight uncapped players in his 34-man squad for the Six Nations.

## Lord Hall to step down as BBC's director general
 - [https://www.bbc.co.uk/news/entertainment-arts-51176588](https://www.bbc.co.uk/news/entertainment-arts-51176588)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 12:08:23+00:00

Tony Hall says the decision to leave after seven years in the role has "been hard".

## Ffair Rhos: Boy, 4, critical after fire killed brother in caravan
 - [https://www.bbc.co.uk/news/uk-wales-51172893](https://www.bbc.co.uk/news/uk-wales-51172893)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 12:04:23+00:00

The three-year-old boy died after a touring caravan and vehicle were destroyed in the blaze.

## New China virus: Number of cases jumps as infection spreads to Beijing
 - [https://www.bbc.co.uk/news/world-asia-china-51171035](https://www.bbc.co.uk/news/world-asia-china-51171035)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 11:49:34+00:00

The number of cases of the respiratory illness triples, as it spreads to Beijing and Shenzhen.

## Department store Beales collapses into administration
 - [https://www.bbc.co.uk/news/business-51176418](https://www.bbc.co.uk/news/business-51176418)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 11:29:07+00:00

The collapse of the company, founded in 1881, puts more than 1,000 jobs at risk

## Harry and Meghan: No other option but to step back, says duke
 - [https://www.bbc.co.uk/news/uk-51170973](https://www.bbc.co.uk/news/uk-51170973)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 11:11:38+00:00

The prince says he and Meghan wanted to continue serving the Queen, but "that wasn't possible".

## In pictures: Clouds create perfect conditions for stunning sunset
 - [https://www.bbc.co.uk/news/uk-scotland-51174308](https://www.bbc.co.uk/news/uk-scotland-51174308)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 11:10:29+00:00

High cloud and exceptionally clear air created the perfect conditions for an incredible sunset on Sunday.

## Super Bowl 2020: Mahomes runs in 27-yard touchdown as Kansas City Chiefs beat Tennessee Titans
 - [https://www.bbc.co.uk/sport/av/american-football/51176568](https://www.bbc.co.uk/sport/av/american-football/51176568)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 10:50:30+00:00

Kansas City Chiefs quarterback Patrick Mahomes scores a brilliant touchdown after evading several tackles in a 27-yard run as Chiefs beat the Tennessee Titans.

## HS2: Rail link costs could rise to £106bn, says review
 - [https://www.bbc.co.uk/news/business-51171249](https://www.bbc.co.uk/news/business-51171249)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 10:37:29+00:00

There is "considerable risk" the price of the high-speed line could rise by another 20%, a report finds.

## England in South Africa: Tourists win by an innings in Port Elizabeth
 - [https://www.bbc.co.uk/sport/cricket/51174068](https://www.bbc.co.uk/sport/cricket/51174068)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 10:18:45+00:00

England seal their biggest away win in more than nine years in the third Test against South Africa to move 2-1 up with one match to play.

## Seven Kings stabbing: Three killed after disturbance
 - [https://www.bbc.co.uk/news/uk-england-london-51171184](https://www.bbc.co.uk/news/uk-england-london-51171184)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 10:07:42+00:00

The men in their 20s and 30s were pronounced dead at the scene in Ilford - two men have been arrested.

## Brad Pitt and Jennifer Aniston celebrate together at SAG Awards
 - [https://www.bbc.co.uk/news/entertainment-arts-51173888](https://www.bbc.co.uk/news/entertainment-arts-51173888)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 09:29:43+00:00

The former couple briefly reunite backstage after receiving prizes from the Screen Actors Guild.

## Madonna cancels Lisbon show: 'I must listen to my body'
 - [https://www.bbc.co.uk/news/entertainment-arts-51173928](https://www.bbc.co.uk/news/entertainment-arts-51173928)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 08:36:01+00:00

"I must listen to my body and rest," the star tells fans in Lisbon, Portugal.

## Outrage after Chinese theme park forces pig to bungee jump
 - [https://www.bbc.co.uk/news/world-asia-china-51171495](https://www.bbc.co.uk/news/world-asia-china-51171495)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 08:10:03+00:00

After the 75kg pig was pushed off a tower, it was reportedly sent to the slaughterhouse.

## 'Dad died violent death in dementia care unit'
 - [https://www.bbc.co.uk/news/uk-northern-ireland-51129031](https://www.bbc.co.uk/news/uk-northern-ireland-51129031)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 06:23:52+00:00

John O'Reilly died a week after being pushed by another patient at a dementia care unit in County Armagh.

## WSL: Three brilliant goals - Beth England, Keira Walsh and Sophie Ingle score stunning goals
 - [https://www.bbc.co.uk/sport/av/football/51169843](https://www.bbc.co.uk/sport/av/football/51169843)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 06:21:36+00:00

Watch Beth England, Keira Walsh and Sophie Ingle score stunning goals as Manchester City and Chelsea both win in the WSL.

## The Papers: Harry's 'sadness' and 'duke and duchess of Netflix'
 - [https://www.bbc.co.uk/news/blogs-the-papers-51170964](https://www.bbc.co.uk/news/blogs-the-papers-51170964)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 05:37:51+00:00

Prince Harry's first speech since he and Meghan said they would step back from royal duties dominates Monday's papers.

## Australia storms: Huge hail causes chaos in two cities
 - [https://www.bbc.co.uk/news/world-australia-51171285](https://www.bbc.co.uk/news/world-australia-51171285)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 04:18:13+00:00

Melbourne and Canberra are pelted by golf-ball sized stones, causing widespread damage.

## GB's Evans comes back from two sets down to advance at Australian Open
 - [https://www.bbc.co.uk/sport/tennis/51171934](https://www.bbc.co.uk/sport/tennis/51171934)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 03:33:51+00:00

British number one Dan Evans fights back from two sets down to beat American Mackenzie McDonald in the Australian Open first round.

## Should schools be allowed to ban slang words like 'peng'?
 - [https://www.bbc.co.uk/news/education-51064279](https://www.bbc.co.uk/news/education-51064279)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 00:57:17+00:00

Research suggests that slang bans in schools may be more harmful than good.

## Influencers 'being offered thousands for sex'
 - [https://www.bbc.co.uk/news/technology-50828386](https://www.bbc.co.uk/news/technology-50828386)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 00:55:49+00:00

One influencer said social media had become "a catalogue" for men to select their next conquest.

## UK-born children of migrants 'feel more discriminated against' than foreign migrants
 - [https://www.bbc.co.uk/news/uk-51170406](https://www.bbc.co.uk/news/uk-51170406)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 00:52:58+00:00

Data suggests 30% of second generation migrants feel discriminated against because of their ethnicity.

## UK-Africa summit: Wooing Africa after Brexit
 - [https://www.bbc.co.uk/news/world-africa-51149093](https://www.bbc.co.uk/news/world-africa-51149093)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 00:39:59+00:00

Heads of state are meeting in London for a UK-Africa summit ahead of the UK's departure from the EU.

## HPV puts 'strain' on sex and dating
 - [https://www.bbc.co.uk/news/health-51121305](https://www.bbc.co.uk/news/health-51121305)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 00:38:59+00:00

Changes to smear tests will mean more HPV diagnoses but there is concern over myths about the virus.

## How has immigration changed in your area?
 - [https://www.bbc.co.uk/news/uk-51099579](https://www.bbc.co.uk/news/uk-51099579)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 00:37:17+00:00

Four maps on how immigration has changed Britain.

## Are migrants who cross the Channel sent back?
 - [https://www.bbc.co.uk/news/uk-england-50813246](https://www.bbc.co.uk/news/uk-england-50813246)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 00:35:07+00:00

Home Office figures suggest many migrants crossing the Channel in boats are granted asylum.

## Five times immigration changed the UK
 - [https://www.bbc.co.uk/news/uk-politics-51134644](https://www.bbc.co.uk/news/uk-politics-51134644)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 00:34:53+00:00

Over the past century many groups have left and entered the country, changing the shape of the nation.

## Australia fires: Your questions about arson, travel and recovery
 - [https://www.bbc.co.uk/news/world-australia-51016191](https://www.bbc.co.uk/news/world-australia-51016191)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 00:30:08+00:00

Your questions about the Australia bushfires.

## The traditional dance where men perform as women
 - [https://www.bbc.co.uk/news/world-asia-51152952](https://www.bbc.co.uk/news/world-asia-51152952)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 00:18:20+00:00

Rianto is a master of Lengger Lanang, a traditional Indonesia dance where men perform as women.

## Is China addicted to coal?
 - [https://www.bbc.co.uk/news/world-asia-51152951](https://www.bbc.co.uk/news/world-asia-51152951)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 00:16:14+00:00

China is a country caught in the middle of a global struggle: to develop but also be green.

## Preparing for an active volcano to stir
 - [https://www.bbc.co.uk/news/stories-51125528](https://www.bbc.co.uk/news/stories-51125528)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 00:15:07+00:00

People living at the foot of a volcano in Ecuador are being taught what to do if disaster strikes

## Trump impeachment: What's Ukraine got to do with it?
 - [https://www.bbc.co.uk/news/world-51152351](https://www.bbc.co.uk/news/world-51152351)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-20 00:04:35+00:00

The reason US President Donald Trump is facing an impeachment trial lies thousands of miles away.

