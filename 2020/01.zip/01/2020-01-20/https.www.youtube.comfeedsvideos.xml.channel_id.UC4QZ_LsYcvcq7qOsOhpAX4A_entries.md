# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## The New Space Race of the 2020's (Documentary)
 - [https://www.youtube.com/watch?v=bqYbgWbKMPc](https://www.youtube.com/watch?v=bqYbgWbKMPc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2020-01-21 00:00:00+00:00

Click here to explore your creativity and get 2 free months of Premium Membership: https://skl.sh/coldfusion2

--- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. 

If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- New Thinking Book written by Dagogo Altraide ---
Learn the stories of those who invented the things we use everyday.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

--- ColdFusion Social Media ---
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusionTV

--- ColdFusion Podcast links ---
Google Podcasts - http://bit.ly/2xo8doR
Apple Podcasts - https://apple.co/2WI2IeU
Spotify - https://spoti.fi/2KT1taB
Stitcher - http://bit.ly/2WI4f4E

Sources:

https://www.youtube.com/watch?v=fUj1-cPaFgo
https://www.nytimes.com/2019/10/22/science/blue-origin-jeff-bezos.html
https://techcrunch.com/2019/11/15/virgin-galactic-begins-astronaut-readiness-program-for-first-paying-customers/
https://www.youtube.com/watch?v=vS7aidy2bwk
https://www.cnbc.com/2019/10/28/virgin-galactic-stock-trading-debut-on-nyse-under-the-ticker-spce.html
https://dearmoon.earth/
https://www.theverge.com/2019/11/18/20971307/nasa-clps-program-spacex-blue-origin-sierra-nevada-ceres-tyvak-viper-rover
https://www.theverge.com/2018/11/29/18117741/nasa-clps-program-moon-lunar-landers-commercial-partnerships
https://www.nasa.gov/press-release/new-companies-join-growing-ranks-of-nasa-partners-for-artemis-program
https://www.forbes.com/sites/jonathanocallaghan/2019/11/18/this-is-not-coolastronomers-despair-as-spacex-starlink-train-ruins-observation-of-nearby-galaxies/#35b756956538
https://futurism.com/the-byte/elon-musk-tweeted-spacex-satellite-internet?fbclid=IwAR2QL77BVNiC61VarCuXeQyXzBOM9Gg7uu65VfhujDVsHS02sH2vCIJmBOE
https://www.nasa.gov/image-feature/blue-origin-lunar-lander-concept
https://www.nasa.gov/specials/moontomars/index.html
https://www.cnbc.com/2019/10/22/bezos-blue-origin-will-work-on-lunar-lander-with-lockheed-northrop-draper.html?fbclid=IwAR1CWVY9ZTPb45ngz-UUx57UeoV12QfBaUfx_PAERLhKgAbQbXUcC4wfy7I
https://www.blueorigin.com/news/blue-origin-announces-national-team-for-nasas-human-landing-system-artemis
https://techcrunch.com/2019/11/18/nasa-adds-spacex-blue-origin-and-more-to-list-of-companies-set-to-make-deliveries-to-the-surface-of-the-moon/
https://www.nasa.gov/specials/moontomars/index.html
https://www.nasa.gov/image-feature/blue-origin-lunar-lander-concept
https://techcrunch.com/2019/11/15/virgin-galactic-begins-astronaut-readiness-program-for-first-paying-customers/
https://futurism.com/the-byte/nasa-moon-visitors-stay-longer-apollo?fbclid=IwAR38e-S3TGMqLOu-6Un2xoQaob-4vQZ-AcBH1aIdFpSj3azgRetcJRfJoss
https://arstechnica.com/science/2019/10/nasa-shares-details-of-lunar-surface-missions-and-theyre-pretty-cool/
https://www.fastcompany.com/company/made-in-space

//Soundtrack//

Blue States - Vision Trail

Sublab - So In Love

Roald Velden - Peaceful

BUCK UK __ Once

Sean Williams - Fray

Oren Lavie - locked in a room

Delectatio - It-s Ok

Burn Water - Never Lose Sight

Burn Water - Call to Earth

» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide

Why are you still reading?

