# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## THEORY: Isildur Will Be Main Character of Amazon's Lord of the Rings Series
 - [https://www.youtube.com/watch?v=w45E0jHhVA0](https://www.youtube.com/watch?v=w45E0jHhVA0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2020-01-21 00:00:00+00:00

Could Robert Aramayo be playing Isildur in the lead role of Amazon's Lord of the Rings? Here, I share my thoughts on why he just may be the main character of the show. I'd love to hear your thoughts on the upcoming #LOTRonPrime show and/or what you think of the video - feel free to leave a comment! 

Please Subscribe to the channel - this helps me to bring you more videos! 


Artwork: The Fleet of Ar-Pharazon - John Howe 
The Ships of the Faithful - Ted Nasmith 
The Pillars of the Kings - Ted Nasmith 
Ar-Pharazon - Paula DiSante 
Fate of Isildur - Anato Finnstark 
Fall of Numenor - Darrell Sweet 
Sauron and Ar-Pharazon - Janka Latečková

If your artwork is used and is not credited, please let me know and I will add it to this list of fantastic work!

