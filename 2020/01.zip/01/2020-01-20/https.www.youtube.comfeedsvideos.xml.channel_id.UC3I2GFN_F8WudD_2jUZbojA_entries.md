# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Kristofer Rodriguez Svönuson - Are You Here? (Live on KEXP)
 - [https://www.youtube.com/watch?v=nciPghvblg0](https://www.youtube.com/watch?v=nciPghvblg0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-21 00:00:00+00:00

http://KEXP.ORG presents Kristofer Rodriguez Svönuson performing "Are You Here?" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 5, 2019.

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director & Editor: Scott Holpainen

http://kexp.org
https://www.facebook.com/pg/kristoferrodriguezsvonuson

## Kristofer Rodriguez Svönuson - Combo Macondo (Live on KEXP)
 - [https://www.youtube.com/watch?v=b4usr5JZDPc](https://www.youtube.com/watch?v=b4usr5JZDPc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-21 00:00:00+00:00

http://KEXP.ORG presents Kristofer Rodriguez Svönuson performing "Combo Macondo" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 5, 2019.

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director & Editor: Scott Holpainen

http://kexp.org
https://www.facebook.com/pg/kristoferrodriguezsvonuson

## Kristofer Rodriguez Svönuson - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=0tuF9sPzim0](https://www.youtube.com/watch?v=0tuF9sPzim0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-21 00:00:00+00:00

http://KEXP.ORG presents Kristofer Rodriguez Svönuson performing live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 5, 2019.

Songs:
Primo
Combo Macondo
Memento Vivere
Are You Here?

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director & Editor: Scott Holpainen

http://kexp.org
https://www.facebook.com/pg/kristoferrodriguezsvonuson

Read an interview with Kristofer Rodriguez Svönuson here: https://www.kexp.org/read/2020/1/21/meet-kristofer-rodriguez-svonuson-drummer-bringing-latin-jazz-iceland-live-video-interview/

## Kristofer Rodriguez Svönuson - Interlude / Mamaou (Live on KEXP)
 - [https://www.youtube.com/watch?v=o1Ns3SBVHSc](https://www.youtube.com/watch?v=o1Ns3SBVHSc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-21 00:00:00+00:00

http://KEXP.ORG presents Kristofer Rodriguez Svönuson performing "Primo" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 5, 2019.

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director & Editor: Scott Holpainen

http://kexp.org
https://www.facebook.com/pg/kristoferrodriguezsvonuson

## Kristofer Rodriguez Svönuson - Memento Vivere (Live on KEXP)
 - [https://www.youtube.com/watch?v=kaRdWSTtcSk](https://www.youtube.com/watch?v=kaRdWSTtcSk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-21 00:00:00+00:00

http://KEXP.ORG presents Kristofer Rodriguez Svönuson performing "Memento Vivere" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 5, 2019.

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director & Editor: Scott Holpainen

http://kexp.org
https://www.facebook.com/pg/kristoferrodriguezsvonuson

## Kristofer Rodriguez Svönuson - Primo (Live on KEXP)
 - [https://www.youtube.com/watch?v=Dhh6359wob4](https://www.youtube.com/watch?v=Dhh6359wob4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-21 00:00:00+00:00

http://KEXP.ORG presents Kristofer Rodriguez Svönuson performing "Primo" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 5, 2019.

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director & Editor: Scott Holpainen

http://kexp.org
https://www.facebook.com/pg/kristoferrodriguezsvonuson

## Shovels & Rope - By Blood (Live on KEXP)
 - [https://www.youtube.com/watch?v=qY-Kc5yXMiI](https://www.youtube.com/watch?v=qY-Kc5yXMiI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-20 00:00:00+00:00

http://KEXP.ORG presents Shovels & Rope performing "By Blood" live in the KEXP studio. Recorded October 25, 2019.

Host: Evie
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Kendall Rock & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
https://shovelsandrope.com

## Shovels & Rope - C'Mon Utah! (Live on KEXP)
 - [https://www.youtube.com/watch?v=W3TEu5qV-p0](https://www.youtube.com/watch?v=W3TEu5qV-p0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-20 00:00:00+00:00

http://KEXP.ORG presents Shovels & Rope performing "C'Mon Utah!" live in the KEXP studio. Recorded October 25, 2019.

Host: Evie
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Kendall Rock & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
https://shovelsandrope.com

## Shovels & Rope - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=HaPShTa-O38](https://www.youtube.com/watch?v=HaPShTa-O38)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-20 00:00:00+00:00

http://KEXP.ORG presents Shovels & Rope performing live in the KEXP studio. Recorded October 25, 2019.

Songs:
By Blood
I'm Comin' Out
C'Mon Utah!
Mississippi Nuthin'

Host: Evie
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Kendall Rock & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
https://shovelsandrope.com

## Shovels & Rope - I'm Comin' Out (Live on KEXP)
 - [https://www.youtube.com/watch?v=49LMXvZM-Fc](https://www.youtube.com/watch?v=49LMXvZM-Fc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-20 00:00:00+00:00

http://KEXP.ORG presents Shovels & Rope performing "I'm Comin' Out" live in the KEXP studio. Recorded October 25, 2019.

Host: Evie
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Kendall Rock & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
https://shovelsandrope.com

## Shovels & Rope - Mississippi Nuthin' (Live on KEXP)
 - [https://www.youtube.com/watch?v=ggtvirBePdg](https://www.youtube.com/watch?v=ggtvirBePdg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-20 00:00:00+00:00

http://KEXP.ORG presents Shovels & Rope performing "Mississippi Nuthin'" live in the KEXP studio. Recorded October 25, 2019.

Host: Evie
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Kendall Rock & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
https://shovelsandrope.com

