# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Temtem Is a Solid Pokémon Clone and I’m Excited to Play More | UnderDeveloped
 - [https://www.youtube.com/watch?v=2ZoelbWEIm4](https://www.youtube.com/watch?v=2ZoelbWEIm4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-01-20 00:00:00+00:00

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

This week Jack wades into the tall grass to get an early look at Temtem, a Pokémon-like game that is also an MMO. Temtem has customizable characters, online co-op play, and (most importantly) adorable creatures… but will that be enough to push Pokémon players towards team Temtem?

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►► https://sharkrobot.com/collections/zero-punctuation 

Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 

Like us on Facebook ►► http://www.facebook.com/EscapistMag

Follow us on Twitter ►► https://twitter.com/EscapistMag

#Temtem

