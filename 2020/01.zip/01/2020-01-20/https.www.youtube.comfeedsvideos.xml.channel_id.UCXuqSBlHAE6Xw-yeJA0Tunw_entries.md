# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## WE FINALLY DID IT!! - Water Cooling the 8K Camera!
 - [https://www.youtube.com/watch?v=imJ9QgOJHzY](https://www.youtube.com/watch?v=imJ9QgOJHzY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-01-21 00:00:00+00:00

Find a Micro Center near you: http://bit.ly/2QEZrfg
Maingear Element Laptop: http://bit.ly/35g9DQG
Maingear Element Laptop (Amazon): https://amzn.to/2SGDJub

Thanks to Thermal Grizzly for sponsoring today's episode! Buy Thermal Grizzly Conductonaut on Amazon (PAID LINK) at https://lmg.gg/conductonaut

It's finally happening. We are water cooling our RED 8K camera, and it is a beautiful thing.

Part 1: https://youtu.be/qFrK-l3VSzY
Part 1.5: https://youtu.be/O43IIVhb3ak

Check out the tools we used at OhCanadaSupply and enter to win a tool kit! at http://bit.ly/MWKGiveaway

Try out Solidworks Flow Simulation: https://www.solidworks.com/Linus
Check out the CAD models: https://grabcad.com/library/red-camera-water-cooling-1

Buy Noctua fans
On Amazon (PAID LINK): https://geni.us/4qrPAXZ
On Newegg (PAID LINK): https://lmg.gg/XYT4L

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1147676-we-finally-did-it-water-cooling-the-8k-camera/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Come see us at LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

## We Water Cooled an SSD!!
 - [https://www.youtube.com/watch?v=lQmI5A27Iv8](https://www.youtube.com/watch?v=lQmI5A27Iv8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-01-20 00:00:00+00:00

Visit https://www.squarespace.com/LTT and use offer code LTT for 10% off

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire

Should YOU water cool an SSD in your gaming PC?

Alphacool MCX RAM: https://www.alphacool.com/shop/mainboard-cooler/chip-cooler/599/alphacool-mcx-ram?c=20693
MCX RAM Copper Edition: https://www.alphacool.com/shop/mainboard-cooler/chip-cooler/10762/alphacool-mcx-ram-copper-edition?c=20693
Corsair MP600: https://www.corsair.com/ca/en/Categories/Products/Storage/M-2-SSDs/Force-Series%E2%84%A2-Gen-4-PCIe-NVMe-M-2-SSD/p/CSSD-F2000GBMP600

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1147333-we-water-cooled-an-ssd/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Come see us at LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

