# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Doom Eternal vs DOOM 2016: 10 BIGGEST CHANGES
 - [https://www.youtube.com/watch?v=iKmo8t3wt2g](https://www.youtube.com/watch?v=iKmo8t3wt2g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-01-21 00:00:00+00:00

Doom Eternal (PC, PS4, Xbox One) is  greatly expanding on the ideas laid out by Doom 2016. Here's what we've seen so far.
Subscribe for more: http://youtube.com/gameranxtv

## Dragon Ball Z: Kakarot - Top 10 Secrets, Easter Eggs & References
 - [https://www.youtube.com/watch?v=gvx_3LSGKJc](https://www.youtube.com/watch?v=gvx_3LSGKJc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-01-20 00:00:00+00:00

Dragon Ball Z Kakarot (PC, PS4, Xbox One) is filled with charming references, secrets, and Easter eggs related to Dragon Ball lore and pop culture. Here are some of the best examples.
Subscribe for more: http://youtube.com/gameranxtv

