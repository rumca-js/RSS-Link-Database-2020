# Source:KnowledgeHusk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw, language:en-US

## Playstation: The Perils of Ego
 - [https://www.youtube.com/watch?v=Aymqrm28_RA](https://www.youtube.com/watch?v=Aymqrm28_RA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw
 - date published: 2020-01-21 00:00:00+00:00

PlayStation is a company right? They make the games? The fun games? The fun fun video games and stuff? Yeah?
Yeah.

Second Channel: https://www.youtube.com/channel/UC-KL04Ra6E1Du0pFawN4pWg?view_as=subscriber

Patreon: https://www.patreon.com/theknowledgehub

SoundCloud: https://soundcloud.com/user-503704039

Twitter: https://twitter.com/KnowledgeHubTy

Game footage credits
Engadget
Benedict Gameplays
Xbox Kai Fam
ScottishAuto
GXZ95
The Truth We Seek
EightBitHD
Dual Shock

