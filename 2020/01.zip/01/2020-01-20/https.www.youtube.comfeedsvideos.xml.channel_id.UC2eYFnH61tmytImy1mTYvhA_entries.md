# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## The Flaws of Academic Statistics: the Null Ritual
 - [https://www.youtube.com/watch?v=an0RFLzJ5Yo](https://www.youtube.com/watch?v=an0RFLzJ5Yo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-01-20 00:00:00+00:00

https://notrelated.xyz

Nearly every academic paper published since the 1960s has used statistics known to be faulty.

 That sounds extreme, but it's actually not even controversial in the statistical literature.

 In the 1950s, Ronald Fisher invented a statistical technique to solve the philsophical Problem of Induction. Neyman and Pearson developed a technique for statistical quality control in factories. Yet somehow, these two techniques were confused and merged into the Null Ritual of today, which is the neurotic pattern that every paper in many disicplines have to follow.

 The Null Ritual is one of the clearest examples of academic consensus so far off the tracks that scholar treat the techniques in textbooks were religious devotion, rather than with critical awareness of what they are actually supposed to be. The end result? Nearly every field is rife with misuse of numbers, publication bias, misunderstandings and fake conclusions.

 Gigerenzer, Gerd. Mindless statistics. The Journal of Socio-Economics. 2004.

 Fisher, Ronald. Statistical Methods and Scientific Induction. Journal of the Royal Statistical Society 17.1 (69-78). 1955.

 Neyman, Jerzy. "Inductive Behavior" as a Basic Concept of Philosophy of Science. Revue de l'Institut International de Statistique 25 (7-22). 1957.

 Halpin, Peter and Henderikus Stam. Inductive Inference or Inductive Behavior: Fisher and Neyman: Pearson Approaches to Statistical Testing in Psychological Research (1940-1960). The American Journal of Psychology 119.4 (635-653). 2006.

 Perezgonzalez, Jose. Fisher, Neyman-Pearson or NHST? A tutorial for teaching data testing. Frontiers in Psychology 6. 2015.

 Ioannidis, John. Why Most Published Research Findings Are False: Author's Reply to Goodman and Greenland. PLoS 4.6. 2007.

 Francis, Gregory. Replication, statistical consistency, and publication bias. Journal of Mathematical Psychology 57.5 (153-169). 2013.

 Fanelli, Daniele. "Positive" Results Increase Down the Hierarchy of the Sciences. PLoS 5.4. 2010.

 Gigerenzer, Gerd. Replication, statistical consistency, and publication bias. 2015.

 Taleb, Nassim. A Short Note on P-Value Hacking.

