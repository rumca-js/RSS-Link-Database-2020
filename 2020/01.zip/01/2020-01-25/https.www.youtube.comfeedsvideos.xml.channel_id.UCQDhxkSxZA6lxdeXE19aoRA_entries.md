# Source:Hugh Jeffreys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA, language:en-US

## $101 Note8 Restoration
 - [https://www.youtube.com/watch?v=hJXfDZjhE6Y](https://www.youtube.com/watch?v=hJXfDZjhE6Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA
 - date published: 2020-01-25 00:00:00+00:00

---------------------------------------Links---------------------------------------
Get parts, tools, and thousands of free repair guides from iFixit at: 
    https://iFixit.com/hughjeffreys
Australia Store: https://ifix.gd/2FPxhKy
--------------------------------------Socials-------------------------------------
Twitter: https://twitter.com/hughjeffreys
Instagram: http://instagram.com/hughjeffreys
--------------------------------------------------------------------------------------

DISCLAIMER: This video and description contains affiliate links, which means that if you click on one of the product links, l will receive a small commission.

