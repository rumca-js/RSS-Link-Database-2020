# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Barmy Army trumpeter to give up cricket tours
 - [https://www.bbc.co.uk/sport/cricket/51241192](https://www.bbc.co.uk/sport/cricket/51241192)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 22:29:34+00:00

Billy Cooper, the Barmy Army's trumpet player, will retire after England's current tour of South Africa.

## Jordan Sinnott: Murder inquiry after Matlock Town footballer dies
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-51249670](https://www.bbc.co.uk/news/uk-england-nottinghamshire-51249670)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 21:54:49+00:00

Matlock Town's Jordan Sinnott suffered head injuries in an attack in Retford, Nottinghamshire.

## FA Cup fourth round: Long-range screamers and horrible misses
 - [https://www.bbc.co.uk/sport/av/football/51252332](https://www.bbc.co.uk/sport/av/football/51252332)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 20:15:03+00:00

Watch all the best bits from the FA Cup fourth round including long-range goals, a mascot race and some horrible misses.

## Madonna Madame X tour: Star cancels first London show
 - [https://www.bbc.co.uk/news/entertainment-arts-51250871](https://www.bbc.co.uk/news/entertainment-arts-51250871)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 18:02:56+00:00

The star says she has been "plagued" by injuries since the start of her tour and has been told to rest.

## China coronavirus: Stricter measures start Lunar New Year
 - [https://www.bbc.co.uk/news/world-asia-china-51249208](https://www.bbc.co.uk/news/world-asia-china-51249208)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 12:19:25+00:00

On the first day of the year of the rat, China announces more anti-coronavirus steps.

## Fraud victims 'failed' as criminals 'operate with impunity' - report
 - [https://www.bbc.co.uk/news/uk-51246926](https://www.bbc.co.uk/news/uk-51246926)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 12:16:55+00:00

A review into the handling of fraud cases finds forces have "not kept pace" with the rise in cases.

## Highlights: Haaland scores two as Borussia Dortmund thrash Cologne
 - [https://www.bbc.co.uk/sport/av/football/51249408](https://www.bbc.co.uk/sport/av/football/51249408)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 12:16:06+00:00

Erling Braut Haaland gets two more Borussia Dortmund goals - and makes history as the first player to score five times in his first two Bundesliga games.

## Pliskova & Svitolina out in third round
 - [https://www.bbc.co.uk/sport/tennis/51246784](https://www.bbc.co.uk/sport/tennis/51246784)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 12:13:46+00:00

Second seed Karolina Pliskova and fifth seed Elina Svitolina both fall to straight-set defeats in the Australian Open third round.

## Mark Wallinger: The artist who wants to provoke pupils' creativity
 - [https://www.bbc.co.uk/news/education-51235615](https://www.bbc.co.uk/news/education-51235615)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 12:05:45+00:00

Top artist Mark Wallinger has become a school's artist-in-residence to fight for more creativity.

## Sheffield mum finds stranger's poem where daughter died
 - [https://www.bbc.co.uk/news/uk-england-south-yorkshire-51241302](https://www.bbc.co.uk/news/uk-england-south-yorkshire-51241302)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 12:04:40+00:00

Sharon Green has left flowers for the past two decades - this year there was a poem waiting for her.

## Turkey earthquake: At least 22 dead as buildings collapse
 - [https://www.bbc.co.uk/news/world-europe-51245088](https://www.bbc.co.uk/news/world-europe-51245088)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 11:12:14+00:00

Several people are trapped under collapsed buildings after Friday's quake which killed 22 people.

## Real-life Rapunzel and other stories you may have missed
 - [https://www.bbc.co.uk/news/world-51245426](https://www.bbc.co.uk/news/world-51245426)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 11:02:18+00:00

A few of the stories you may have missed this week.

## Robert Archibald: Former GB and Scotland basketball player dies at 39
 - [https://www.bbc.co.uk/sport/basketball/51248659](https://www.bbc.co.uk/sport/basketball/51248659)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 10:33:55+00:00

Former Great Britain player Robert Archibald, the only Scot to have played in the United States' National Basketball Association, dies aged 39.

## Veterans' charity Combat Stress stops new referrals over funding crisis
 - [https://www.bbc.co.uk/news/uk-51243098](https://www.bbc.co.uk/news/uk-51243098)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 09:50:56+00:00

Combat Stress says it cannot take on new referrals due to a cut in financial support from the NHS.

## 'Awesome' warrior queen Boudicca seen in Norfolk clouds
 - [https://www.bbc.co.uk/news/uk-england-norfolk-51235975](https://www.bbc.co.uk/news/uk-england-norfolk-51235975)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 09:47:45+00:00

The cloud formation looks like "a spear-carrying Boudicca striding across the skies", the photographer says.

## The Papers: Chinese images of virus lockdown, while Taylor Swift talks
 - [https://www.bbc.co.uk/news/blogs-the-papers-51245316](https://www.bbc.co.uk/news/blogs-the-papers-51245316)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 06:13:15+00:00

A number of papers lead on concerns over coronavirus, while Taylor Swift reveals her eating disorder.

## FA Cup: Pubs, Bees & Bradley Walsh - Brentford FC in 2 minutes
 - [https://www.bbc.co.uk/sport/av/football/51238265](https://www.bbc.co.uk/sport/av/football/51238265)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 06:10:01+00:00

BBC Sport plots the history of Brentford FC, from its founding in a local pub to the 'moneyball' approach that has taken the Bees to the cusp of the Premier League and a new home.

## Martin Scorsese's editor on his hatred of eyebrows
 - [https://www.bbc.co.uk/news/entertainment-arts-51230754](https://www.bbc.co.uk/news/entertainment-arts-51230754)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 04:00:43+00:00

Thelma Schoonmaker reveals Scorsese's problem with eyebrows and how Netflix saved The Irishman.

## Labour Party sees surge in membership amid leadership race
 - [https://www.bbc.co.uk/news/uk-51245211](https://www.bbc.co.uk/news/uk-51245211)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 03:41:04+00:00

Some local party groups see hundreds of new members in the last month, BBC Newsnight learns.

## ‘Vale ended our lives’: Broken Brumadinho a year after dam collapse
 - [https://www.bbc.co.uk/news/world-latin-america-51220373](https://www.bbc.co.uk/news/world-latin-america-51220373)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 02:57:45+00:00

One year on from the dam collapse at Brazil's Corrego de Feijao mine, many are still seeking answers.

## Home sellers risk losing money over quick sales
 - [https://www.bbc.co.uk/news/business-your-money-51234455](https://www.bbc.co.uk/news/business-your-money-51234455)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 02:35:40+00:00

Trading Standards warns homeowners to be careful when using quick-sale estate agents.

## The best pictures from around the world this week
 - [https://www.bbc.co.uk/news/in-pictures-51236425](https://www.bbc.co.uk/news/in-pictures-51236425)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 00:23:34+00:00

A selection of striking news images from around the world this week.

## Hannah: the body positive quadruple amputee
 - [https://www.bbc.co.uk/news/stories-51206154](https://www.bbc.co.uk/news/stories-51206154)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 00:23:03+00:00

Hannah shares her life on social media to encourage self-confidence.

## Six Nations: How did Welsh rugby become a game for all?
 - [https://www.bbc.co.uk/news/uk-wales-51192459](https://www.bbc.co.uk/news/uk-wales-51192459)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 00:20:28+00:00

How did rugby develop into an integral part of Welsh culture more than 100 years ago?

## Why China’s LGBT hide their identities at Lunar New Year
 - [https://www.bbc.co.uk/news/world-asia-china-51199309](https://www.bbc.co.uk/news/world-asia-china-51199309)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 00:14:33+00:00

Representation of China's LGBT community is improving but many still struggle during Lunar New Year.

## Auschwitz: Searching for traces of my grandfather
 - [https://www.bbc.co.uk/news/world-europe-51187969](https://www.bbc.co.uk/news/world-europe-51187969)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 00:11:45+00:00

Meijer Nieweg was murdered in August 1942. It has taken decades for details of his death to emerge.

## Meet the teenager who collects vacuum cleaners
 - [https://www.bbc.co.uk/news/uk-england-merseyside-51244155](https://www.bbc.co.uk/news/uk-england-merseyside-51244155)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 00:03:51+00:00

Mathew Lock's passion for collecting vacuum cleaners started at the age of two.

## Wild swimming group at Yorkshire Dales waterfall
 - [https://www.bbc.co.uk/news/uk-england-york-north-yorkshire-51241322](https://www.bbc.co.uk/news/uk-england-york-north-yorkshire-51241322)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 00:02:15+00:00

A group of friends are wild swimming every day in January for charity.

## Salt 'n' sauce - Scotland's culinary divide
 - [https://www.bbc.co.uk/news/uk-scotland-51193539](https://www.bbc.co.uk/news/uk-scotland-51193539)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 00:02:06+00:00

What is chippy sauce and why has this chip shop tradition never spread beyond Scotland's east coast?

## Exhibition hits high notes of Leeds' music history
 - [https://www.bbc.co.uk/news/uk-england-leeds-51220319](https://www.bbc.co.uk/news/uk-england-leeds-51220319)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 00:01:42+00:00

From composers to rock stars, a new exhibition charts the changing music scene of Leeds.

## Sky Brown: Skating towards Tokyo 2020 Olympics
 - [https://www.bbc.co.uk/news/uk-51223089](https://www.bbc.co.uk/news/uk-51223089)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 00:01:20+00:00

Sky Brown has set her sights on competing in the Tokyo Olympics in 2020, where she'd be Britain's youngest ever summer Olympian.

## Instagram rejected model's rosacea images
 - [https://www.bbc.co.uk/news/uk-england-london-51210037](https://www.bbc.co.uk/news/uk-england-london-51210037)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-25 00:00:58+00:00

The social media platform told Lex Gillies it doesn't allow "undesirable" body states.

