# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I'm Returning my Mac Pro
 - [https://www.youtube.com/watch?v=mIB389tqzCI](https://www.youtube.com/watch?v=mIB389tqzCI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-01-26 00:00:00+00:00

Get a $20 Off Perk on the Massdrop x Sennheiser PC37X Gaming Headset at https://dro.ps/ltt-pc37x-jan

Get an unrestricted 30-day free trial of FreshBooks at https://www.freshbooks.com/techtips

We finally got our hands on Apple’s first new proper desktop computer in over a decade – And their most expensive computer EVER. Could it possibly justify its price tag?

Buy a Mac Pro:
From Apple: https://lmg.gg/vplG8

Buy Pro Display XDR:
On Amazon (PAID LINK): https://geni.us/swe7rle
From Apple: https://lmg.gg/U0rL0

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1149347-im-returning-my-mac-pro/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Come see us at LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

## The RGB HDMI cable ISN'T as dumb as you'd think...
 - [https://www.youtube.com/watch?v=nva6oPszm60](https://www.youtube.com/watch?v=nva6oPszm60)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-01-25 00:00:00+00:00

Get an unrestricted 30-day free trial of FreshBooks at https://www.freshbooks.com/techtips

Thanks to Thermal Grizzly for sponsoring today's episode! Buy Thermal Grizzly Conductonaut on Amazon (PAID LINK) at https://lmg.gg/conductonaut

It finally happened. RGB has permeated every Gaming PC part from motherboards, to graphics cards, to RAM, and now this: an RGB HDMI cable. The final frontier.

Buy RGB HDMI cable
On Amazon (PAID LINK): https://geni.us/rlKgZ9o

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1149019-the-rgb-hdmi-cable-isnt-as-dumb-as-youd-think/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Come see us at LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

