# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## [NV#353] Nie żyj przeciętnie!
 - [https://www.youtube.com/watch?v=17NjFBapuDc](https://www.youtube.com/watch?v=17NjFBapuDc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-01-26 00:00:00+00:00

#langustanapalmie #niecodziennyvlog #nocnyvlog
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zdjęcia i montaż: Adam Szustak OP
Muzyka: https://soundcloud.com/findinghopemusic

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#165] Może się wreszcie ruszysz?
 - [https://www.youtube.com/watch?v=-PU2Y0oT4-E](https://www.youtube.com/watch?v=-PU2Y0oT4-E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-01-25 00:00:00+00:00

#CNN #dobrewiadomości 
Kazanie na niedzielę, w każdą niedzielę, czyli Słowo Na Niedzielę.
III Niedziela Zwykła , Rok A
________________________________________
1. czytanie (Iz 8, 23b – 9, 3)

W dawniejszych czasach upokorzył Pan krainę Zabulona i krainę Neftalego, za to w przyszłości chwałą okryje drogę do morza, wiodącą przez Jordan, krainę pogańską. Naród kroczący w ciemnościach ujrzał światłość wielką; nad mieszkańcami kraju mroków światło zabłysło. Pomnożyłeś radość, zwiększyłeś wesele. Rozradowali się przed Tobą, jak się radują w żniwa, jak się weselą przy podziale łupu. Bo złamałeś jego ciężkie jarzmo i drążek na jego ramieniu, pręt jego ciemięzcy, jak w dniu porażki Madianitów.

2. czytanie (1 Kor 1, 10-13. 17)

Upominam was, bracia, w imię Pana naszego, Jezusa Chrystusa, abyście żyli w zgodzie i by nie było wśród was rozłamów; abyście byli jednego ducha i jednej myśli. Doniesiono mi bowiem o was, bracia moi, przez ludzi Chloe, że zdarzają się między wami spory. Myślę o tym, co każdy z was mówi: «Ja jestem od Pawła, a ja od Apollosa; ja jestem Kefasa, a ja Chrystusa». Czyż Chrystus jest podzielony? Czyż Paweł został za was ukrzyżowany? Czyż w imię Pawła zostaliście ochrzczeni?

Nie posłał mnie Chrystus, abym chrzcił, lecz abym głosił Ewangelię, i to nie w mądrości słowa, by nie zniweczyć Chrystusowego krzyża.

Ewangelia (Mt 4, 12-23)

Gdy Jezus posłyszał, że Jan został uwięziony, usunął się do Galilei. Opuścił jednak Nazaret, przyszedł i osiadł w Kafarnaum nad jeziorem, na pograniczu ziem Zabulona i Neftalego. Tak miało się spełnić słowo proroka Izajasza: «Ziemia Zabulona i ziemia Neftalego, na drodze ku morzu, Zajordanie, Galilea pogan! Lud, który siedział w ciemności, ujrzał światło wielkie, i mieszkańcom cienistej krainy śmierci wzeszło światło».

Odtąd począł Jezus nauczać i mówić: «Nawracajcie się, albowiem bliskie jest królestwo niebieskie».

Przechodząc obok Jeziora Galilejskiego, Jezus ujrzał dwóch braci: Szymona, zwanego Piotrem, i brata jego, Andrzeja, jak zarzucali sieć w jezioro; byli bowiem rybakami. I rzekł do nich: «Pójdźcie za Mną, a uczynię was rybakami ludzi». Oni natychmiast, zostawiwszy sieci, poszli za Nim.

A idąc stamtąd dalej, ujrzał innych dwóch braci: Jakuba, syna Zebedeusza, i brata jego, Jana, jak z ojcem swym Zebedeuszem naprawiali w łodzi swe sieci. Ich też powołał. A oni natychmiast zostawili łódź i ojca i poszli za Nim.

I obchodził Jezus całą Galileę, nauczając w tamtejszych synagogach, głosząc Ewangelię o królestwie i lecząc wszelkie choroby i wszelkie słabości wśród ludu.

________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#413] Mniej boli
 - [https://www.youtube.com/watch?v=C3CuMumLxHY](https://www.youtube.com/watch?v=C3CuMumLxHY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-01-25 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

