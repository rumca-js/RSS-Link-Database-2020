# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Run DMC, 'King of Rock' (Teenage Kicks from The Current)
 - [https://www.youtube.com/watch?v=kIsDVV9tr_k](https://www.youtube.com/watch?v=kIsDVV9tr_k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-01-25 00:00:00+00:00

Host Jim McGuinn looks at "King of Rock," a landmark 1985 album from Run DMC.
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## The Current's 2020 Grammys Preview
 - [https://www.youtube.com/watch?v=Xn_aMENFHmo](https://www.youtube.com/watch?v=Xn_aMENFHmo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-01-25 00:00:00+00:00

#Lizzo, Bon Iver, and many other names familiar to Current listeners are up for #Grammys this Sunday, including Billie Eilish (becoming the youngest artist to be nominated across all four major categories), Lana Del Rey, Vampire Weekend, #Yola, and Maggie Rogers slotted significant nominations. 

Other Minnesota-connected artists recognized this year include Big Thief, led by Minnesota native Adrianne Lenker, nominated for Best Alternative Music Album (U.F.O.F.). J.S. Ondara, a singer-songwriter from Kenya by way of Minnesota, was nominated for Best Americana Album for his Tales of America. The Gopher State’s Okee Dokee Brothers, who’ve landed multiple past Grammy nominations and won in 2011 for Best Children’s Album (Can You Canoe?), are nominated in that category again for Winterland.

