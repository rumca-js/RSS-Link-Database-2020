# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## YouTube Diamond Play Button Review!
 - [https://www.youtube.com/watch?v=7xtX1KNSlrY](https://www.youtube.com/watch?v=7xtX1KNSlrY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-01-25 00:00:00+00:00

The Diamond Play Button for 10 million subscribers!

10,000,000: https://youtu.be/NvQmi_ciL1k

WhatsInside video: https://youtu.be/hI5jggQTAsM

MKBHD Merch: http://shop.MKBHD.com

Video Gear I use: http://kit.co/MKBHD/video-gear#recom...
Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Jordyn Edmonds http://smarturl.it/jordynedmonds 
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

