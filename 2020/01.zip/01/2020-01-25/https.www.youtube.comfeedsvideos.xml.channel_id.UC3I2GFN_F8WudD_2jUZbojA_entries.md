# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## GDRN - Hvað Ef (Live on KEXP)
 - [https://www.youtube.com/watch?v=GVGxQ-f2y28](https://www.youtube.com/watch?v=GVGxQ-f2y28)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-26 00:00:00+00:00

http://KEXP.ORG presents GDRN performing "Hvað Ef" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 7, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://www.facebook.com/pg/GDRNmusic

## GDRN - Komdu yfir (Live on KEXP)
 - [https://www.youtube.com/watch?v=t6_gkJK-qPU](https://www.youtube.com/watch?v=t6_gkJK-qPU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-26 00:00:00+00:00

http://KEXP.ORG presents GDRN performing "Komdu yfir" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 7, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://www.facebook.com/pg/GDRNmusic

## GDRN - Lætur Mig (Live on KEXP)
 - [https://www.youtube.com/watch?v=ugV-UUueZn8](https://www.youtube.com/watch?v=ugV-UUueZn8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-26 00:00:00+00:00

http://KEXP.ORG presents GDRN performing "Lætur Mig" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 7, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://www.facebook.com/pg/GDRNmusic

## GDRN - Treystu mér (Live on KEXP)
 - [https://www.youtube.com/watch?v=QoygQRdczDE](https://www.youtube.com/watch?v=QoygQRdczDE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-26 00:00:00+00:00

http://KEXP.ORG presents GDRN performing "Treystu mér" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 7, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://www.facebook.com/pg/GDRNmusic

## GDRN - Upp (Live on KEXP)
 - [https://www.youtube.com/watch?v=tbT4KJeJUKk](https://www.youtube.com/watch?v=tbT4KJeJUKk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-26 00:00:00+00:00

http://KEXP.ORG presents GDRN performing "Upp" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 7, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://www.facebook.com/pg/GDRNmusic

