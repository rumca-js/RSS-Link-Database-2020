# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Taylor Swift won't attend the Grammys, source says
 - [https://www.cnn.com/2020/01/25/entertainment/taylor-swift-grammy-awards-trnd/index.html](https://www.cnn.com/2020/01/25/entertainment/taylor-swift-grammy-awards-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-25 22:53:10+00:00

Taylor Swift won't be attending the Grammys on Sunday, a source close to the singer told CNN.

## Artifact found at Civil War site may be a 'witch bottle' used to ward off evil spirits. Really
 - [https://www.cnn.com/2020/01/25/us/witch-bottle-virginia-civil-war-trnd/index.html](https://www.cnn.com/2020/01/25/us/witch-bottle-virginia-civil-war-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-25 22:22:16+00:00

Never heard of a "witch bottle"? Step right in, friend, sit a spell (not the evil kind) and we'll tell you why archaeologists believe a broken bottle found in Virginia just might be one.

## 49er treating family of fallen Army sergeant to the Super Bowl
 - [https://www.cnn.com/2020/01/25/us/49ers-george-kittle-super-bowl-trnd/index.html](https://www.cnn.com/2020/01/25/us/49ers-george-kittle-super-bowl-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-25 22:05:55+00:00

Before US Army Sgt. Martin LaMar was killed in Iraq, he spent his weekends cheering on the San Francisco 49ers. Next week, LaMar's service will be honored during Super Bowl LIV.

## FedEx driver shoveled snow off customer's stoop
 - [https://www.cnn.com/2020/01/25/us/michigan-fedex-driver-trnd/index.html](https://www.cnn.com/2020/01/25/us/michigan-fedex-driver-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-25 21:45:34+00:00

A delivery driver's good deed is being shared with the world, thanks to a doorbell camera.

## This is the bar Trump's defense needs to clear
 - [https://www.cnn.com/2020/01/25/opinions/trumps-defense-impeachment-zelizer/index.html](https://www.cnn.com/2020/01/25/opinions/trumps-defense-impeachment-zelizer/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-25 21:31:32+00:00

On Saturday, President Trump's defense team, as expected, simply brushed aside mountains of evidence and testimony -- including a new audio recording -- that shows a concerted effort from the White House to leverage aid to Ukraine in exchange for investigations that would politically benefit the President.

## Two teens accused of killing their mothers and siblings
 - [https://www.cnn.com/2020/01/25/us/alabama-utah-teen-suspects/index.html](https://www.cnn.com/2020/01/25/us/alabama-utah-teen-suspects/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-25 21:11:01+00:00

Two teens in Utah and Alabama killed their mothers and siblings in separate incidents, leaving their communities shocked in what appear to be unrelated cases.

## An Australian runner found dangerous spikes hidden on a popular nature trail
 - [https://www.cnn.com/2020/01/25/world/austrlain-homemade-spikes-trnd/index.html](https://www.cnn.com/2020/01/25/world/austrlain-homemade-spikes-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-25 20:48:14+00:00

Police in Australia are urging the public to stay alert after a runner found homemade spikes methodically hidden on a popular running trail Monday.

## For the rich and famous, there's no silver bullet to avoid phone hacks
 - [https://www.cnn.com/2020/01/25/tech/bezos-amazon-cybersecurity/index.html](https://www.cnn.com/2020/01/25/tech/bezos-amazon-cybersecurity/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-25 20:21:48+00:00

The world might be turning to technology to solve everything from traffic to dating, but no one app or gadget will save the rich and famous from falling prey to cyberattacks, according to digital security experts.

## Death toll rises to 29 and at least 1,400 injured in Turkey earthquake
 - [https://www.cnn.com/2020/01/25/europe/turkey-earthquake-intl/index.html](https://www.cnn.com/2020/01/25/europe/turkey-earthquake-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-25 20:06:45+00:00

At least 29 people died and more than 1,400 are injured in eastern Turkey after an earthquake rattled the region on Friday evening, according to authorities.

## US arranging charter flight to evacuate diplomats and citizens out of China
 - [https://www.cnn.com/2020/01/25/politics/coronavirus-us-evacuate-americans-china/index.html](https://www.cnn.com/2020/01/25/politics/coronavirus-us-evacuate-americans-china/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-25 18:27:23+00:00

The US government is arranging a charter flight to evacuate American diplomats and citizens from the Chinese city that has become ground zero for a new deadly strain of coronavirus, a US official with knowledge of the matter told CNN Saturday.

## A baby covered AC/DC's 'Thunderstruck,' after his dad recorded his noises for a year
 - [https://www.cnn.com/2020/01/25/us/thunderstruck-video-baby-acdc-trnd/index.html](https://www.cnn.com/2020/01/25/us/thunderstruck-video-baby-acdc-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-25 17:47:46+00:00

Does it seem like recording artists are getting younger and younger?

## A 4-year-old accidentally shot while play-wrestling with his father has died, police say
 - [https://www.cnn.com/2020/01/25/us/father-son-play-wrestling-shot-head-saturday-trnd/index.html](https://www.cnn.com/2020/01/25/us/father-son-play-wrestling-shot-head-saturday-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-25 17:22:57+00:00

A 4-year-old Indiana boy who was accidentally shot in the head while play-wrestling with his father has died, authorities said.

## Javier Hernandez clarifies 'retirement' comments after crying over LA Galaxy transfer
 - [https://www.cnn.com/2020/01/25/football/javier-hernandez-la-galaxy-retirement-comments-spt-intl/index.html](https://www.cnn.com/2020/01/25/football/javier-hernandez-la-galaxy-retirement-comments-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-25 16:47:32+00:00

The arrival of Javier Hernandez at Los Angeles Galaxy was treated as a seminal moment for Major League Soccer and for the club.

## Ugandan climate activist cropped out of photo with white peers
 - [https://www.cnn.com/2020/01/25/world/vanessa-nakate-cropped-intl-scli/index.html](https://www.cnn.com/2020/01/25/world/vanessa-nakate-cropped-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-25 16:03:31+00:00

The Associated Press news agency (AP) has apologized after cropping a Ugandan climate activist from a photograph where she had posed with her white peers after a press conference in Davos, Switzerland.

## Pentagon's vow to protect impeachment witness from retaliation tested after senator attacked his patriotism
 - [https://www.cnn.com/2020/01/25/politics/pentagon-retaliation-vindman-marsha-blackburn-tweet/index.html](https://www.cnn.com/2020/01/25/politics/pentagon-retaliation-vindman-marsha-blackburn-tweet/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-25 15:13:50+00:00

• Romney 'very likely' to favor calling witnesses
• OPINION: Trump's team has the upper hand
• OPINION: This is the bar Trump's defense needs to clear

## Wonderkid Håland smashes German league record
 - [https://www.cnn.com/2020/01/25/football/erling-braut-hland-borussia-dortmund-two-more-goals-spt-intl/index.html](https://www.cnn.com/2020/01/25/football/erling-braut-hland-borussia-dortmund-two-more-goals-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-25 15:11:08+00:00

You might have thought scoring a debut hat-trick might earn you a start in the next game.

## Channing Tatum no longer a single man
 - [https://www.cnn.com/2020/01/25/entertainment/channing-tatum-jessie-j-back-together-trnd/index.html](https://www.cnn.com/2020/01/25/entertainment/channing-tatum-jessie-j-back-together-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-25 14:04:08+00:00

An Instagram kiss and inflatable unicorn horns are pointing to Channing Tatum and Jessie J getting back together.

## Kyrgios rages at umpire over bleeding hand during victory at Australian Open
 - [https://www.cnn.com/2020/01/25/tennis/nick-kyrgios-injury-time-out-argument-australian-open-spt-intl/index.html](https://www.cnn.com/2020/01/25/tennis/nick-kyrgios-injury-time-out-argument-australian-open-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-25 13:21:02+00:00

It's barely been 48 hours since Nick Kyrgios made headlines for mocking Rafael Nadal's routine, and now, he's causing another stir.

## What's in store for the Year of the Rat? Hong Kong's most famous fortune teller reveals all
 - [https://www.cnn.com/collections/year-of-the-rat-2020-intl/](https://www.cnn.com/collections/year-of-the-rat-2020-intl/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-25 04:02:29+00:00



## China is a massive headache for Europe
 - [https://www.cnn.com/2020/01/24/europe/europe-china-problem-analysis-gbr-intl/index.html](https://www.cnn.com/2020/01/24/europe/europe-china-problem-analysis-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-25 03:01:51+00:00



## Live updates: Lunar New Year festivities canceled as dozens die of China virus
 - [https://www.cnn.com/asia/live-news/coronavirus-outbreak-hnk-intl-01-25-20/index.html](https://www.cnn.com/asia/live-news/coronavirus-outbreak-hnk-intl-01-25-20/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-25 01:01:18+00:00



## Deradicalization camps for Kashmiris? That's just absurd, experts say
 - [https://www.cnn.com/2020/01/24/asia/india-general-kashmir-deradicalization-intl-hnk/index.html](https://www.cnn.com/2020/01/24/asia/india-general-kashmir-deradicalization-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-25 00:34:06+00:00



## Virus exposes flaws in Xi's control
 - [https://www.cnn.com/collections/intl-wuhan-virus-0124/](https://www.cnn.com/collections/intl-wuhan-virus-0124/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-25 00:31:58+00:00



## At least 15 dead, more than 500 injured in Turkey earthquake
 - [https://www.cnn.com/2020/01/24/europe/turkey-quake-intl/index.html](https://www.cnn.com/2020/01/24/europe/turkey-quake-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-25 00:31:35+00:00

A 6.7-magnitude earthquake hit eastern Turkey on Friday evening, according to the US Geological Survey (USGS).

## World Bank to consider giving Tanzania $500 million education loan despite ban on pregnant schoolgirls
 - [https://www.cnn.com/2020/01/24/africa/tanzania-pregnant-girls-world-bank-loan-asequals-intl/index.html](https://www.cnn.com/2020/01/24/africa/tanzania-pregnant-girls-world-bank-loan-asequals-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-25 00:19:17+00:00

A multi-million dollar World Bank education loan to Tanzania is back on the table for possible approval next week after it was pulled over a year ago amid concerns about the country's policy of banning pregnant girls and young mothers from attending state school.

