# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Why Do People CHEAT In Video Games?
 - [https://www.youtube.com/watch?v=w8O3_7mLPuQ](https://www.youtube.com/watch?v=w8O3_7mLPuQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-01-26 00:00:00+00:00

Cheating and hacking in gaming is widespread, but why does it happen? Who does it? Let's dive in.
Subscribe for more: http://youtube.com/gameranxtv

## 6 GTA Easter Eggs Found YEARS LATER
 - [https://www.youtube.com/watch?v=1TieKn0W4o0](https://www.youtube.com/watch?v=1TieKn0W4o0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-01-25 00:00:00+00:00

The Grand Theft Auto series is filled with fun secret Easter eggs. Luckily, it has a dedicated group of gamers willing to discover even the most hidden surprises.
Subscribe for more: http://youtube.com/gameranxtv

