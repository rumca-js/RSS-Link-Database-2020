# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## 37 games, 32 wins, 89 goals, 101 points - how Liverpool went year unbeaten in Premier League
 - [https://www.bbc.co.uk/sport/football/50688370](https://www.bbc.co.uk/sport/football/50688370)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 23:43:21+00:00

Liverpool's win over Sheffield United means they are a year unbeaten in the Premier League. How did they do it and what is the record?

## Canteen workers honoured alongside US presidents
 - [https://www.bbc.co.uk/news/world-us-canada-50977199](https://www.bbc.co.uk/news/world-us-canada-50977199)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 21:58:36+00:00

The walls of a prestigious US university now have portraits of dinner ladies alongside historical figures.

## TS Eliot letter sheds light on early relationship
 - [https://www.bbc.co.uk/news/entertainment-arts-50975555](https://www.bbc.co.uk/news/entertainment-arts-50975555)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 16:50:58+00:00

A newly published personal letter reveals the poet was glad he never married teacher Emily Hale.

## Detroit fire crews investigated for burning house selfie
 - [https://www.bbc.co.uk/news/world-us-canada-50975362](https://www.bbc.co.uk/news/world-us-canada-50975362)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 16:49:22+00:00

Detroit's fire chief said it was "inappropriate" for the crew to pose for a snap as a building burned.

## Belfast artist PJ Lynch designs Chinese New Year coin
 - [https://www.bbc.co.uk/news/uk-northern-ireland-50971500](https://www.bbc.co.uk/news/uk-northern-ireland-50971500)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 15:45:04+00:00

PJ Lynch is known for his children's art works - now he has designed a coin for the Royal Mint.

## Veganism: Why are vegan diets on the rise?
 - [https://www.bbc.co.uk/news/business-44488051](https://www.bbc.co.uk/news/business-44488051)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 14:11:13+00:00

More and more people are buying plant-powered products. What’s behind the rise?

## Australia fires: Angry residents berate PM Morrison in blaze-ravaged town
 - [https://www.bbc.co.uk/news/world-australia-50973232](https://www.bbc.co.uk/news/world-australia-50973232)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 12:20:21+00:00

Scott Morrison is confronted in Cobargo as residents insult him and tell him he is unwelcome.

## Rail fares rise by 2.7%, hitting millions of commuters
 - [https://www.bbc.co.uk/news/uk-50966546](https://www.bbc.co.uk/news/uk-50966546)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 12:09:04+00:00

Many passengers are facing an increase of more than £100 for annual season tickets.

## Cat found after Ceredigion to Cardiff removal van trip
 - [https://www.bbc.co.uk/news/uk-wales-50971300](https://www.bbc.co.uk/news/uk-wales-50971300)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 11:56:41+00:00

Tiger the cat travelled from mid to south Wales after climbing into a removal van.

## Australia fires: Son of firefighter Geoffrey Keaton awarded medal at funeral
 - [https://www.bbc.co.uk/news/world-australia-50971313](https://www.bbc.co.uk/news/world-australia-50971313)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 11:55:14+00:00

Australian toddler Harvey Keaton sucked on a dummy as he received his father's posthumous medal.

## Kyrgios donates as cricket stars pay tribute to those affected by bushfires
 - [https://www.bbc.co.uk/sport/cricket/50970784](https://www.bbc.co.uk/sport/cricket/50970784)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 11:38:06+00:00

Australian Nick Kyrgios will donate A$200 (£106) for each ace he hits in the Australian summer swing to those affected by fires in the country.

## Army urges under-confident young people to sign up
 - [https://www.bbc.co.uk/news/uk-50966542](https://www.bbc.co.uk/news/uk-50966542)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 11:19:27+00:00

Social media addicts, gym junkies and binge-drinkers are all targets of the recruitment drive.

## Dracula: Critics applaud 'energetic and fun' revival of vampire classic
 - [https://www.bbc.co.uk/news/entertainment-arts-50972189](https://www.bbc.co.uk/news/entertainment-arts-50972189)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 11:14:09+00:00

A new version of Bram Stoker's novel from the creators of Sherlock receives a five-star welcome.

## France protests: Longest strike in decades stuck in deadlock
 - [https://www.bbc.co.uk/news/world-europe-50971439](https://www.bbc.co.uk/news/world-europe-50971439)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 11:00:50+00:00

The strike against pension reforms is now in its 29th day, making it France's longest since 1968.

## Three fans arrested for alleged racial and homophobic abuse at Brighton's draw with Chelsea
 - [https://www.bbc.co.uk/sport/football/50971696](https://www.bbc.co.uk/sport/football/50971696)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 10:54:28+00:00

Two Brighton fans and a Chelsea supporter are arrested for alleged "unacceptable abuse" during Wednesday's 1-1 draw at the Amex Stadium.

## NBA: LA Lakers' LeBron James & Anthony Davis 'show-off' their dunking skills
 - [https://www.bbc.co.uk/sport/av/basketball/50973249](https://www.bbc.co.uk/sport/av/basketball/50973249)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 10:53:42+00:00

The Los Angeles' Lakers' LeBron James and Anthony Davis put on a dunking masterclass as they beat the Phoenix Suns 117-107.

## Chris Barker: Former Cardiff City defender dies aged 39
 - [https://www.bbc.co.uk/sport/football/50971215](https://www.bbc.co.uk/sport/football/50971215)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 10:19:37+00:00

Former Cardiff City, Stoke City, Barnsley and Queens Park Rangers defender Chris Barker dies aged 39.

## Jakarta floods: 'Not ordinary rain', say officials
 - [https://www.bbc.co.uk/news/world-asia-50969418](https://www.bbc.co.uk/news/world-asia-50969418)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 10:13:35+00:00

At least 21 people have died in the Indonesian capital amid record-breaking rainfall.

## Marvel to get first transgender superhero
 - [https://www.bbc.co.uk/news/newsbeat-50970519](https://www.bbc.co.uk/news/newsbeat-50970519)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 09:59:44+00:00

There's a trans character in a film that's currently being shot, according to Marvel's boss.

## Stormont talks: Talks to restore devolution back under way
 - [https://www.bbc.co.uk/news/uk-northern-ireland-50968588](https://www.bbc.co.uk/news/uk-northern-ireland-50968588)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 09:41:37+00:00

Irish Deputy PM Simon Coveney says he is hopeful of "a new beginning for politics in NI".

## Sacked vegan brings landmark discrimination case
 - [https://www.bbc.co.uk/news/uk-50969168](https://www.bbc.co.uk/news/uk-50969168)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 08:39:37+00:00

A tribunal will decide for the first time if veganism is a "philosophical belief" akin to a religion.

## Bang Bang: The artist who’s tattooed LeBron James, Lewis Hamilton and Thierry Henry
 - [https://www.bbc.co.uk/sport/av/50861709](https://www.bbc.co.uk/sport/av/50861709)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 06:20:12+00:00

Tattoo artist Bang Bang tells his stories of inking the world’s biggest sports stars and celebrities, and reveals the tattoos that the likes of Katy Perry and Kylie Jenner have done on him.

## Top psychologist: No certainty terror offenders can be 'cured'
 - [https://www.bbc.co.uk/news/uk-50967100](https://www.bbc.co.uk/news/uk-50967100)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 05:30:08+00:00

A top psychologist says there is probably no scheme that can "cure" or "de-programme" a terror offender.

## The Papers: 'Australia burns' and the 2020 'rail rip-off'
 - [https://www.bbc.co.uk/news/blogs-the-papers-50968938](https://www.bbc.co.uk/news/blogs-the-papers-50968938)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 05:21:55+00:00

Thursday's papers feature striking images of Australia's bushfires, and anger over rail fare hikes.

## Plane crash fatalities fell more than 50% in 2019
 - [https://www.bbc.co.uk/news/business-50953712](https://www.bbc.co.uk/news/business-50953712)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 03:08:28+00:00

The high-profile Boeing 737 Max crash in Ethiopia in March accounted for more than half of those deaths.

## What if Hitler was your imaginary friend?
 - [https://www.bbc.co.uk/news/entertainment-arts-50850133](https://www.bbc.co.uk/news/entertainment-arts-50850133)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 01:06:22+00:00

Roman Griffin Davis, the Golden Globe-nominated young star of the film Jojo Rabbit, on his new role.

## The airborne commute - a flight of fancy?
 - [https://www.bbc.co.uk/news/technology-50096640](https://www.bbc.co.uk/news/technology-50096640)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 00:45:43+00:00

Which firms are competing to make flying taxis and will they ever be mass market?

## Thailand's disappeared Karen activist Billy and the burned village
 - [https://www.bbc.co.uk/news/world-asia-50823872](https://www.bbc.co.uk/news/world-asia-50823872)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 00:44:50+00:00

A young activist went out to work and was never seen again. It would take five years of fighting to find out what happened.

## The tobacco farmers chasing a sweeter crop
 - [https://www.bbc.co.uk/news/business-50629107](https://www.bbc.co.uk/news/business-50629107)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 00:13:31+00:00

Greek farmers have hit a sweet spot after growing sugar substitute stevia instead of tobacco.

## This dad took his son to Mongolia just to get him off his phone
 - [https://www.bbc.co.uk/news/world-us-canada-50830944](https://www.bbc.co.uk/news/world-us-canada-50830944)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 00:09:36+00:00

Mountaineer Jamie Clarke wanted to bond with his son. So he took him on a trek across Mongolia.

## Language apps: Can phones replace classrooms?
 - [https://www.bbc.co.uk/news/uk-wales-50321918](https://www.bbc.co.uk/news/uk-wales-50321918)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 00:03:37+00:00

With a boom in Japanese ahead of the Rugby World Cup, can apps offer more spontaneity and freedom?

## The UK charity bringing life back to Iraq's landmine hotspots
 - [https://www.bbc.co.uk/news/world-middle-east-50872818](https://www.bbc.co.uk/news/world-middle-east-50872818)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 00:01:46+00:00

A UK-based charity is working to clear Iraqi villages of landmines so that residents can return.

## Writing a ‘national anthem' for Mars
 - [https://www.bbc.co.uk/news/world-asia-50840814](https://www.bbc.co.uk/news/world-asia-50840814)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 00:01:31+00:00

A former software analyst and rising opera star has penned a song for the Red Planet.

## Balloon modeller Emma Nettleton took a career change after mum's cancer scare
 - [https://www.bbc.co.uk/news/uk-england-essex-50867717](https://www.bbc.co.uk/news/uk-england-essex-50867717)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 00:01:14+00:00

A financial analyst pursues her dream to be a balloon artist after her mother got cancer.

## Who's the woman watching over this Brazilian street?
 - [https://www.bbc.co.uk/news/world-50324423](https://www.bbc.co.uk/news/world-50324423)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-02 00:00:55+00:00

How a giant portrait above a main road in São Paulo is reflecting the changing face of Brazil.

