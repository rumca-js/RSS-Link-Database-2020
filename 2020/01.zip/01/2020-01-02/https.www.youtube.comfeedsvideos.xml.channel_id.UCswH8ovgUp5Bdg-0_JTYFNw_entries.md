# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Are Women Tricked Into Believing They're Failures?
 - [https://www.youtube.com/watch?v=1bZaeq0B23U](https://www.youtube.com/watch?v=1bZaeq0B23U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-01-03 00:00:00+00:00

A clip from tomorrow's Under The Skin podcast with Elizabeth Day - author of "How To Fail" and host of the "How To Fail" podcast.
You can listen to the entire podcast on Luminary: http://luminary.link/russell

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

## Embark On A Journey Of Awakening | Russell Brand
 - [https://www.youtube.com/watch?v=Gy0AgfwYxS4](https://www.youtube.com/watch?v=Gy0AgfwYxS4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-01-02 00:00:00+00:00

You can sign up to my free 12-day online course here:
https://www.onecommune.com/a/20323/cGftrerE 

You should be able to make life more manageable, no matter how far or deep you are in your pain or addiction. You are constantly confronted by your fears of change, of self doubt, of yourself! 
 
The journey of recovery, especially in Step 2,  is where you remember and recognize that you are going somewhere, that there is a better version of you! 

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

