## Who’s Really Responsible for Climate Change?
 - [https://harvardpolitics.com/climate-change-responsibility/](https://harvardpolitics.com/climate-change-responsibility/)
 - RSS feed: https://harvardpolitics.com
 - date published: 2020-01-02 14:33:49+00:00

Who’s Really Responsible for Climate Change?

