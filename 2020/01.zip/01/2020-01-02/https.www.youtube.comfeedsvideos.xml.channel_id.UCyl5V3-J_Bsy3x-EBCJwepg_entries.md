# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Episode 30: How To Own Atheists With Greg Koukl
 - [https://www.youtube.com/watch?v=w6HEgIv1Dfw](https://www.youtube.com/watch?v=w6HEgIv1Dfw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-01-03 00:00:00+00:00

In the thirtieth episode of The Babylon Bee podcast, editor-in-chief Kyle Mann and creative director Ethan Nicolle get ready to say goodbye to 2019 and ring in the new year with a rock-star apologist: Greg Koukl. He’s an accomplished author, speaker, radio host, founder and president of Stand To Reason, an adjunct professor at BIOLA, and he guarantees he can convince anyone to become a Christian in three minutes or less. Well maybe that last part was a bit of an exaggeration, but Greg believes that when Christianity and its values are clearly articulated they can “stand to reason” in the public square. They discuss apologetics fails, how to bring your faith into a conversation without being totally awkward, and what the goal of apologetics really should be.

 Greg Koukl’s 10th anniversary edition of  Tactics: A Game Plan For Discussing Your Christian Convictions is available now.

  Pre-order the new Babylon Bee Best-Of Coffee Table Book coming in 2020!

 Show Outline

 Introduction - Kyle and Ethan open up some bubbly sparkling water to ring in the new year, discuss the Babylon Bee’s top ten stories of 2019, and make bold predictions for 2020.

 Top 10 Bee Stories of the Year

 10 -  Bernie Sanders Arrives In Hong Kong To Lecture Protesters On How Good They Have It Under Communism

 9 -  In Genius Move, Trump Supports Impeachment, Forcing Democrats To Oppose

 8 -  Disney CEO: 'To Avoid Filming Among Depraved, Immoral People, We Are Moving All Our Georgia Operations Back To Hollywood'

 7 -  Portland Police: 'We Wish There Were Some Kind Of Organized, Armed Force That Could Fight Back Against Antifa'

 6 -  Ocasio-Cortez Appears On 'The Price Is Right,' Guesses Everything Is Free

 5 -  Walmart Discontinues Auto Part Sales To Prevent Car Accidents

 4 -  Georgia Lawmaker Claims Chick-Fil-A Employee Told Her To Go Back To Her Country, Later Clarifies He Actually Said 'My Pleasure'

 3 - Husband Daycare Now Available At All Hobby Lobby Locations

 2 -  Ilhan Omar Withdraws Support From Bill To Save The Earth After Learning That’s Where Israel Is

 1 -  Motorcyclist Who Identifies As Bicyclist Sets Cycling World Record

 Predictions for 2020

 Interview - Greg Koukl

 Kyle and Ethan discuss with Greg the Babylon Bee's 10 Arguments For Christianity That Are Guaranteed Mic Drops and get into some listener submitted questions for Greg.

 Topics Discussed

 How did Greg end up becoming an apologetics guy?

 How do you start a conversation about God without coming off like a total tool?

 What do you do when Mormons or Jehovah's Witnesses come to your door?

 At what point is it a sin not to share the gospel with a stranger?

 What do you wish Christians would shut up about? What are the WORST arguments you hear from your own side?

 Hate Mail - We get podcast reviews. Also, this story has been passed around as being real and the comments are interesting: Trump: 'I Have Done More For Christianity Than Jesus'

 Paid-subscriber portion - The interview with Greg Koukl continues and he takes some questions submitted by Babylon Bee readers.

 "Can people of other religions that don't know Christ or are so devout to their own way they never even allow themselves to hear and choose Him be saved by the grace of God?" -Jonathan

 "Why doesn't God reveal himself in undeniable ways like he did in the Bible? Why does it seem that as mankind's ability to test and verify supernatural claims goes up, supernatural occurrences go down?" -Daniel

 "I’ve always wondered if there was a rebellion in God’s pre-human heaven, what would prevent the possibility of another rebellion in eternity?" -Michael

 Become a paid subscriber at https://babylonbee.com/plans

