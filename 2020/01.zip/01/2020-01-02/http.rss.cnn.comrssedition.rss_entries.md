# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Uber passenger gives life-changing gift to driver
 - [https://www.cnn.com/videos/us/2020/01/02/uber-driver-passenger-gift-acfc-full-episode-vpx.cnn](https://www.cnn.com/videos/us/2020/01/02/uber-driver-passenger-gift-acfc-full-episode-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 23:59:39+00:00

An Uber driver says she is one step closer to achieving her dream of becoming a lawyer thanks to a random passenger who paid off her college debt when he heard her life's story. Watch "Full Circle" weeknights at 5 p.m. ET.

## Twin sisters deliver babies hours apart
 - [https://www.cnn.com/videos/us/2020/01/02/sisters-babies-born-same-day-acfc-goods-vpx.cnn](https://www.cnn.com/videos/us/2020/01/02/sisters-babies-born-same-day-acfc-goods-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 23:59:17+00:00

Twin sisters in El Paso, Texas, were shocked to find out they were both pregnant, but that wasn't the biggest coincidence.  Watch "Full Circle" weeknights at 5 p.m. ET.

## 'Affluenza' teen arrested again
 - [https://www.cnn.com/2020/01/02/us/ethan-couch-affluenza-accused-of-probation-violation/index.html](https://www.cnn.com/2020/01/02/us/ethan-couch-affluenza-accused-of-probation-violation/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 23:24:45+00:00

Ethan Couch, known for his "affluenza" defense in his deadly drunk driving case, was arrested Thursday in Texas, accused of violating his probation again, officials said.

## Magic Johnson says David Stern's response to HIV announcement changed the world
 - [https://www.cnn.com/2020/01/01/us/david-stern-death-reactions/index.html](https://www.cnn.com/2020/01/01/us/david-stern-death-reactions/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 23:20:17+00:00

The NBA was a far different league when David Stern took over as commissioner in 1984.

## She drank diet soda for 13 years thinking she'd lose weight. Court rules she was wrong
 - [https://www.cnn.com/2020/01/02/business/diet-soda-lawsuit/index.html](https://www.cnn.com/2020/01/02/business/diet-soda-lawsuit/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 22:37:04+00:00

There's nothing deceptive or dishonest about soda makers using the word "diet" to describe the reduced calorie alternatives to their traditional sugary soft drinks, a federal appellate court has ruled.

## American Kennel Club announces two new dog breeds
 - [https://www.cnn.com/2020/01/02/us/american-kennel-club-barbet-dogo-argentino-trnd/index.html](https://www.cnn.com/2020/01/02/us/american-kennel-club-barbet-dogo-argentino-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 22:16:39+00:00

This decade is off to a paws-itive start, with the recognition of two new dog breeds by the American Kennel Club.

## Best and worst diets for 2020, ranked by experts, with a popular one near last
 - [https://www.cnn.com/2020/01/02/health/best-diet-worst-diet-2020-wellness/index.html](https://www.cnn.com/2020/01/02/health/best-diet-worst-diet-2020-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 22:01:27+00:00

Who won the 2020 battle of the diets?

## Testing drivers for cannabis is hard. Here's why
 - [https://www.cnn.com/2020/01/02/business/cannabis-breathalyzers-are-coming-to-market/index.html](https://www.cnn.com/2020/01/02/business/cannabis-breathalyzers-are-coming-to-market/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 21:50:58+00:00

As a growing number of states legalize cannabis, health officials are increasingly sounding the alarm for technology that can quickly determine when drivers are stoned.

## Over 1,000 of T.S. Eliot's letters to his companion are opened for the first time
 - [https://www.cnn.com/2020/01/02/us/ts-eliot-letters-unveiled-trnd/index.html](https://www.cnn.com/2020/01/02/us/ts-eliot-letters-unveiled-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 20:49:38+00:00

While T.S. Eliot may have measured out his life with coffee spoons, researchers and fans of the poet are hoping to measure his legacy through a newly revealed collection of letters which has been unseen in over 60 years.

## Hanukkah stabbing victim's family releases photo to show brutality of anti-Semitic attack
 - [https://www.cnn.com/2020/01/02/us/monsey-new-york-hanukkah-stabbings/index.html](https://www.cnn.com/2020/01/02/us/monsey-new-york-hanukkah-stabbings/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 19:02:41+00:00

The children of the most seriously injured victim of the mass stabbing at an upstate New York Hanukkah celebration made an emotional appeal Thursday for an end to anti-Semitic attacks as their father underwent surgery.

## Report: Order to freeze Ukraine aid came from Trump, according to unredacted documents
 - [https://www.cnn.com/collections/trump-bucket-intl-010219/](https://www.cnn.com/collections/trump-bucket-intl-010219/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 18:44:21+00:00



## More experience doesn't mean a higher salary in this job market
 - [https://www.cnn.com/2020/01/02/perspectives/wage-stagnation/index.html](https://www.cnn.com/2020/01/02/perspectives/wage-stagnation/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 18:31:41+00:00

At 11 years running, the United States is experiencing its longest economic expansion ever. And unemployment is at a 50-year low. But workers' wages haven't grown as fast as one would expect. At just above 3%, current wage growth lags well behind where it was during other periods this past century, when the jobs market was also booming.

## Jakarta floods leave dozens dead and 60,000 displaced
 - [https://www.cnn.com/2020/01/02/asia/jakarta-floods-intl/index.html](https://www.cnn.com/2020/01/02/asia/jakarta-floods-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 18:21:11+00:00

Severe flooding in Jakarta that's left swaths of the capital underwater has killed at least 30 people and forced tens of thousands to flee their homes, according to Indonesia's disaster agency.

## Ranking the 5 Democrats with the best chance of winning in 2020
 - [https://www.cnn.com/collections/intl-2020-race-0102/](https://www.cnn.com/collections/intl-2020-race-0102/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 16:57:52+00:00



## Japan tries to solve the mystery of Carlos Ghosn's audacious escape
 - [https://www.cnn.com/2020/01/02/business/ghosn-escape-japan-lebanon-raid/index.html](https://www.cnn.com/2020/01/02/business/ghosn-escape-japan-lebanon-raid/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 16:22:11+00:00

Japanese authorities have raided the house where fugitive auto executive Carlos Ghosn was staying before he escaped to Lebanon earlier this week.

## The world's safest airlines revealed
 - [https://www.cnn.com/travel/article/worlds-safest-airlines-2020-airlineratings/index.html](https://www.cnn.com/travel/article/worlds-safest-airlines-2020-airlineratings/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 16:02:19+00:00

Airline safety is one of those things you hope you'll never have to worry about when you travel.

## Google's AI system can beat doctors at detecting breast cancer
 - [https://www.cnn.com/2020/01/02/tech/google-health-breast-cancer/index.html](https://www.cnn.com/2020/01/02/tech/google-health-breast-cancer/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 15:19:55+00:00

Google says it has developed an artificial intelligence system that can detect the presence of breast cancer more accurately than doctors.

## Giuliani: I would testify at impeachment trial
 - [https://www.cnn.com/videos/politics/2020/01/01/rudy-giuliani-impeachment-trial-testimony-nr-vpx.cnn](https://www.cnn.com/videos/politics/2020/01/01/rudy-giuliani-impeachment-trial-testimony-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 14:16:51+00:00

President Donald Trump's personal attorney Rudy Giuliani told reporters he is willing to testify in the impeachment trial of the President.

## Vegans could get the same legal protections as religious people, as a landmark case is heard
 - [https://www.cnn.com/2020/01/02/uk/vegan-discrimination-case-gbr-scli-intl/index.html](https://www.cnn.com/2020/01/02/uk/vegan-discrimination-case-gbr-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 13:54:07+00:00

A vegan sacked by his employer is bringing a landmark legal case to a British court on Thursday, hoping to change the law to ensure that veganism is considered a protected "philosophical belief" similar to religion.

## Fast food worker films argument about her hijab
 - [https://www.cnn.com/videos/us/2020/01/02/fast-food-worker-sent-home-after-refusing-to-take-off-hijab-lon-orig-na.cnn](https://www.cnn.com/videos/us/2020/01/02/fast-food-worker-sent-home-after-refusing-to-take-off-hijab-lon-orig-na.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 13:53:55+00:00

Stefanae Coleman, a recent Muslim convert, arrived at work wearing a hijab for the first time but she was left feeling "disrespected, baffled and highly upset" when a manager told her she could not wear the headscarf at work.

## Uyghur gravesites in China wiped off the map
 - [https://www.cnn.com/videos/world/2020/01/02/china-uyghur-graves-rivers-newday-pkg-vpx.cnn](https://www.cnn.com/videos/world/2020/01/02/china-uyghur-graves-rivers-newday-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 12:08:56+00:00

More than 100 Uyghur gravesites and tombs in China appear to have been destroyed. CNN's Matt Rivers reports.

## He was mocked for proposing in KFC, but the internet found them and gave them their dream wedding
 - [https://www.cnn.com/2019/12/31/africa/kfc-couple-south-africa/index.html](https://www.cnn.com/2019/12/31/africa/kfc-couple-south-africa/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 09:04:29+00:00

South African couple, Hector Mkansi and Nonhlanhla Soldaat had their dream wedding December 31, right in time for new year, after a video of their proposal went viral in November.

## The Pashmina goat herders in a struggle against climate change
 - [https://www.cnn.com/style/article/pashmina-goat-herders-struggle-against-climate-change/index.html](https://www.cnn.com/style/article/pashmina-goat-herders-struggle-against-climate-change/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 08:51:29+00:00

At an altitude of more than 14,000 feet, where winter temperatures can fall to minus 40 degrees Fahrenheit, it is hard to believe anyone, or anything, can survive in the vast ice desert that is Changthang, on the Tibetan Plateau between India and China. Situated between the Himalayan and Karakorum mountain ranges, it is the highest permanently inhabited plateau in the world, and home to an extremely hardy and rare breed of goat -- the Changra, or Pashmina goat.

## The Australian state of New South Wales could also begin forced evacuations from fire-stricken areas, as emergency crews brace for a dangerous weekend ahead
 - [https://www.cnn.com/2020/01/02/australia/australia-fire-evacuation-intl-hnk-scli/index.html](https://www.cnn.com/2020/01/02/australia/australia-fire-evacuation-intl-hnk-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 06:50:49+00:00



## Months after failed lunar landing, India reveals plan for third moon mission
 - [https://www.cnn.com/2020/01/02/tech/india-moon-mission-intl-hnk-scli/index.html](https://www.cnn.com/2020/01/02/tech/india-moon-mission-intl-hnk-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 06:37:35+00:00

India has announced it will make another attempt to land on the moon, following a mission that ended in failure last year.

## Kim Jong Un threatens new 'strategic weapon'
 - [https://www.cnn.com/2019/12/31/politics/north-korea-kim-jong-un-us-policy-denuclearization/index.html](https://www.cnn.com/2019/12/31/politics/north-korea-kim-jong-un-us-policy-denuclearization/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 05:15:30+00:00

North Korean Leader Kim Jong Un said Tuesday that there "will never" be denuclearization on the Korean Peninsula if the US "persists in its hostile policy towards" the hermit nation, according to the country's state news agency.

## Nick Gordon, the former boyfriend of Bobbi Kristina Brown, dies at 30
 - [https://www.cnn.com/2020/01/02/entertainment/nick-gordon-bobbi-kristina-brown-exboyfriend-dead/index.html](https://www.cnn.com/2020/01/02/entertainment/nick-gordon-bobbi-kristina-brown-exboyfriend-dead/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 05:09:32+00:00

Nick Gordon, the former boyfriend of Bobbi Kristina Brown, has died three years after he was found liable for her death.

## State of emergency declared as Australia's deadly bushfires rage
 - [https://www.cnn.com/collections/intl-australia-fires-0101/](https://www.cnn.com/collections/intl-australia-fires-0101/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 05:07:02+00:00



## Jack Sheldon, jazz legend and 'Schoolhouse Rock!' singer, dies at 88
 - [https://www.cnn.com/2020/01/01/entertainment/jack-sheldon-dead/index.html](https://www.cnn.com/2020/01/01/entertainment/jack-sheldon-dead/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 05:06:45+00:00

Jazz great Jack Sheldon, known for his work on "The Merv Griffin Show" and "Schoolhouse Rock!," has died. He was 88.

## Drones are flying around rural Colorado and Nebraska and no one knows who's behind it
 - [https://www.cnn.com/2020/01/01/us/colorado-nebraska-drones-faa-trnd/index.html](https://www.cnn.com/2020/01/01/us/colorado-nebraska-drones-faa-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 04:29:22+00:00

Mysterious drones have been flying over Colorado and Nebraska in recent weeks and authorities can't figure out who's behind the aircraft.

## 'Tune out the noise,' plus other New Year's resolutions from media and tech executives
 - [https://www.cnn.com/2020/01/01/media/media-tech-executives-new-year-resolutions-reliable-sources/index.html](https://www.cnn.com/2020/01/01/media/media-tech-executives-new-year-resolutions-reliable-sources/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 04:03:59+00:00

A version of this article first appeared in the "Reliable Sources" newsletter. You can sign up for free right here.

## Why the world is waiting for Betelgeuse to go supernova
 - [https://www.cnn.com/2020/01/01/opinions/betelgeuse-star-dimming-supernova-opinion-lincoln/index.html](https://www.cnn.com/2020/01/01/opinions/betelgeuse-star-dimming-supernova-opinion-lincoln/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 03:55:01+00:00

"My love for you is as eternal as the sun" might be a heartfelt line in a love letter written by a young man to his beloved. As poetic as the sentiment might be, it doesn't mean quite what the young swain intended, for the sun, like all stars, was born and now lives in vibrant middle age, but it is destined to die one day. While that inevitable moment is billions of years in the sun's future, a nearby star may be facing a more imminent demise.

## Tesla crash that killed 2 people investigated
 - [https://www.cnn.com/2020/01/01/us/tesla-fatal-crash-nhtsa/index.html](https://www.cnn.com/2020/01/01/us/tesla-fatal-crash-nhtsa/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 03:43:16+00:00

The National Highway Traffic Safety Administration is investigating a crash involving a Tesla in California that left two people dead.

## Netanyahu seeks immunity from prosecution in corruption cases
 - [https://www.cnn.com/2020/01/01/middleeast/israel-netanyahu-immunity-request/index.html](https://www.cnn.com/2020/01/01/middleeast/israel-netanyahu-immunity-request/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 03:37:04+00:00

Israeli Prime Minister Benjamin Netanyahu has requested immunity from prosecution in three corruption cases in which he faces indictment on charges of bribery, fraud and breach of trust.

## Pope Francis apologizes for slapping woman's hand on New Year's Eve
 - [https://www.cnn.com/2020/01/01/europe/pope-francis-slap-woman-apology-intl/index.html](https://www.cnn.com/2020/01/01/europe/pope-francis-slap-woman-apology-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 02:38:06+00:00

Pope Francis has apologized for slapping a woman's hand to free himself from her grip while greeting children and pilgrims in St. Peter's Square on New Year's Eve.

## Shanghai stocks pop on first day of trading in 2020
 - [https://www.cnn.com/2020/01/01/investing/asian-market-latest/index.html](https://www.cnn.com/2020/01/01/investing/asian-market-latest/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 02:24:57+00:00

Markets in Shanghai and Hong Kong rose Thursday after China announced that it will take more action to bolster its slowing economy.

## 10 famous buildings in Singapore
 - [https://www.cnn.com/style/article/famous-buildings-singapore/index.html](https://www.cnn.com/style/article/famous-buildings-singapore/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 01:27:02+00:00

Whether you're a student of architecture or a casual admirer of interesting buildings, Singapore is an observational hothouse (to go along with its tropical climate).

## Tumbleweeds blocked a highway, trapping people in their cars
 - [https://www.cnn.com/2020/01/01/us/tumbleweeds-block-washington-highway-trnd/index.html](https://www.cnn.com/2020/01/01/us/tumbleweeds-block-washington-highway-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 00:34:45+00:00

This is probably not the way motorists in Washington state wanted to spend their New Year's Eve.

## Hundreds of tumbleweeds flood highway
 - [https://www.cnn.com/videos/us/2020/01/01/tumbleweeds-block-road-vpx.cnn](https://www.cnn.com/videos/us/2020/01/01/tumbleweeds-block-road-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 00:32:53+00:00

Several people got trapped in their cars on New Year's Eve after strong winds blew a thicket of tumbleweeds into a portion of a state highway, according to Washington State Patrol Trooper Chris Thorson.

## Arsenal gets first win under Arteta
 - [https://www.cnn.com/2020/01/01/football/arsenal-manchester-united-pogba-spt-intl/index.html](https://www.cnn.com/2020/01/01/football/arsenal-manchester-united-pogba-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 00:27:14+00:00

Arsenal and Manchester United, two teams that dominated the English Premier League at the start of the century, began its third decade with a 2-0 victory for the Gunners to give Mikel Arteta his first win in charge.

## Slow day turns into large surprise for fishermen
 - [https://www.cnn.com/videos/us/2020/01/01/fishermen-catch-great-white-shark-florida-pkg-vpx.wsvn](https://www.cnn.com/videos/us/2020/01/01/fishermen-catch-great-white-shark-florida-pkg-vpx.wsvn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-02 00:04:14+00:00

A group of fishermen caught a surprise when they reeled in a 13-foot great white shark off the coast of Broward County, Florida. CNN affiliate WSVN reports.

