# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## Trying to remember the name of the guy I banged...
 - [https://www.youtube.com/watch?v=uflB7b448X0](https://www.youtube.com/watch?v=uflB7b448X0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2020-01-02 00:00:00+00:00

It's not Warren, I think I would remember a Warren.

