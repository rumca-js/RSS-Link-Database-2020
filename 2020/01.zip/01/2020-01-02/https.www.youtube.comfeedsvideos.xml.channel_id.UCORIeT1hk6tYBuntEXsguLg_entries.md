# Source:PostmodernJukebox, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg, language:en-US

## Mr. Blue Sky (Electric Light Orchestra) - Postmodern Jukebox ft. Allison Young
 - [https://www.youtube.com/watch?v=NTbNCezCJNM](https://www.youtube.com/watch?v=NTbNCezCJNM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg
 - date published: 2020-01-03 00:00:00+00:00

Download & Stream "Mr. Blue Sky": https://pmjlive.com/okcrooner
Experience PMJ Live: https://www.pmjtour.com
Shop PMJ Music/Merch:  https://www.shoppmj.com
Follow Us On Spotify: https://pmjlive.com/pmjspotify

OK Internet - you've been requesting ELO's "Mr. Blue Sky" for quite some time now, so here's our first video of the 'Twenties. We're joined by Nashville's Allison Young - a young artist with a classic style and an undeniable vocal gift.
____________________________________________

Follow The Musicians:
Allison Young (Vocals)
Facebook: https://www.facebook.com/allisonyoungmusic/
Instagram: https://www.instagram.com/allisonyoung.xo/
YouTube: https://www.youtube.com/channel/UCyVttxb4-zHo62CB4lwvMXg

Megan Mullins (Violin)
Instagram: https://www.instagram.com/meganmullins10/

Emily Nelson (Cello):
Instagram: https://www.instagram.com/enelsoncello/

CJ Colandrea (Pedal Steel Guitar):
Instagram: https://www.instagram.com/cjcolandrea/?hl=en

Darius Salazar (Bass)
Twitter: https://twitter.com/king_salz

Patrick Bubert (Drums)
Instagram: https://www.instagram.com/patbubert/ 

Scott Bradlee (Piano):
YouTube: http://youtube.com/scottbradlee
Facebook: http://facebook.com/scottbradleemusic
Instagram: http://instagram.com/scottbradlee
Twitter: http://twitter.com/scottbradlee

Arrangement by: Scott Bradlee
Engineered by: Thai Ly Long
Video by: Andrew Rozario and Mike Stryker
____________________________________________
#ElectricLightOrchestra #MrBlueSky #Cover

