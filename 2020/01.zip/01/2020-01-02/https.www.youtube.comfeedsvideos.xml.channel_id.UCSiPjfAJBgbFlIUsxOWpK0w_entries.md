# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Les Champs-Elysées | Joe Dassin | Pomplamoose ft. John Schroeder
 - [https://www.youtube.com/watch?v=7B4CLQGxHmI](https://www.youtube.com/watch?v=7B4CLQGxHmI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2020-01-02 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 Get our French EP on vinyl or CD! - http://bit.ly/pomplamoosemerch

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

A cover of Les Champs-Elysées by Pomplamoose.

CREDITS

Lead Vocals: Nataly Dawn
Keys: Jack Conte
Guitar/Arrangement: John Schroeder
Drums: Ben Rose
Upright Bass: Eliana Athayde
Harmonica: Ross Garren
Clarinet: John Tegmeyer
Second guitar/Trumpet: Erik Miron
Engineer: Tim Sonnefeld 
Assistant Engineer: Jason Clark
Producers: Ben Rose & John Schroeder
Mixing/Mastering: Caleb Parker
Video Direction/Production: Ricky Chavez
Camera Operators: Merlin Showalter, Dijon Herron
Video Editor: Dominic Mercurio

Recorded at Band House Studios in Los Angeles.

