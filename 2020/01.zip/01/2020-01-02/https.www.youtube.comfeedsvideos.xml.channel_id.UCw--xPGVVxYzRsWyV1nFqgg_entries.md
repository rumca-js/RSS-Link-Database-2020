# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## HIS DARK MATERIALS - REVIEW
 - [https://www.youtube.com/watch?v=ifMqW4tYbo4](https://www.youtube.com/watch?v=ifMqW4tYbo4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-01-03 00:00:00+00:00

My review of the BBC / HBO's adaptation of Philip Pullman's His Dark Materials. 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## Stormlight Archive 4 is FINISHED! Witcher Passes Mandalorian? Fantasy Fraud? - FANTASY NEWS
 - [https://www.youtube.com/watch?v=D8K-qjOhXiE](https://www.youtube.com/watch?v=D8K-qjOhXiE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-01-02 00:00:00+00:00

Its a new year, but it is still your old reliable FANTASY NEWS! 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene
 
NEWS: 

#Witcher Downloads: https://twitter.com/Marcin360/status/1211368344420573185

Mandalorian Characters: https://twitter.com/culturecrave/status/1211529418562134016?s=12

Japanese Baby Sonic: https://www.youtube.com/watch?v=-9DA3DEYeHM

#KingKiller Show Runner Reacts To Witcher: https://www.newsweek.com/witcher-reviews-make-kingkiller-chronicle-glad-tv-series-release-1479095?amp=1

Witcher Larger than Mandalorian: https://amp.businessinsider.com/witcher-passed-mandalorian-as-biggest-tv-show-in-the-world-2019-12

Dr. Strange Character Debuts: https://www.cbr.com/doctor-strange-multiverse-madness-debuts-character-marvel-always-wanted-to-use-unexpected/?utm_source=CBR-FB-P&utm_medium=Social-Distribution&utm_campaign=CBR-FB-P

Fantasy Does Well At Netflix: https://variety.com/2019/tv/news/netflix-most-popular-tv-series-2019-stranger-things-the-witcher-when-they-see-us-1203453295/

#Uncharted Director Leaves: https://twitter.com/culturecrave/status/1211747440065298433?s=12

New Mutants Trailer: https://twitter.com/lightscamerapod/status/1211761642729562112?s=12

Obi-Wan Casting Young Luke Skywalker: https://screenrant.com/star-wars-obi-wan-show-young-luke-skywalker/

Paolini Fraud Alert: https://www.instagram.com/p/B6wgBenI5Qq/?igshid=1hotk0jfsge78

WandaVision Release Date Moved: https://twitter.com/culturecrave/status/1212398080688934913?s=12

Brandon Twitter Thread: https://twitter.com/BrandSanderson

Sanderson Stormlight 4 Writing Playlist: https://open.spotify.com/playlist/3GfAiWLeIk3zrLaqtfL3ah

