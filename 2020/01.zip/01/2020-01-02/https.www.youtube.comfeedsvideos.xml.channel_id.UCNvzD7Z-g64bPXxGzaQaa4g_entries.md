# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 7 CANCELLED ROCKSTAR Games You Probably Didn't Know
 - [https://www.youtube.com/watch?v=ccSALO-djA8](https://www.youtube.com/watch?v=ccSALO-djA8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-01-02 00:00:00+00:00

Rockstar has put out a ton of great games through the years but there's a bunch that they canceled. Here are some projects we would love to see.
Subscribe for more: http://youtube.com/gameranxtv

## Top 25 UPCOMING Games Announced Last Year
 - [https://www.youtube.com/watch?v=KidQe_c-Qi8](https://www.youtube.com/watch?v=KidQe_c-Qi8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-01-02 00:00:00+00:00

There's a slew of great games hitting in 2020 that have been announced over the last year.
Subscribe for more: http://youtube.com/gameranxtv

*DISCLAIMER*
We Aren't Including Cyberpunk 2077, Doom Eternal, Dreams, Dying Light 2, Final Fantasy 7 Remake, Ghost Of Tsushima, Halo Infinite, The Last Of Us Part 2, Nioh 2, Marvel’s Avengers, Minecraft Dungeons, Wasteland 3, Bayonetta 3, Elder Scrolls 6 Or Starfield As They Were Announced Before 2019.


#25 Plan 8

Platform: PC, TBA

Release Date: TBA



#24 Medal of Honor: Above and Beyond

Platform: PC

Release Date: TBA 2020



#23 Diablo 4

Platform: PC PS4 XBOX ONE

Release Date: TBA 2020



#22 Overwatch 2

Platform: PC PS4 XBOX ONE Nintendo Switch

Release Date: TBA 2020



#21 Outriders

Platform: PC PS4 XBOX ONE

Release Date: Q2 2020



#20 ANIMAL CROSSING: NEW HORIZONS

Platform: Nintendo Switch

Release Date: March 20, 2020



#19 KERBAL SPACE PROGRAM 2

Platform: PC PS4 XBOX ONE

Release Date: TBA 2020



#18 Sons of the Forest

PC, CONSOLES[TBA]

RELEASE: TBA



#17 Senua's Saga: Hellblade 2

Xbox Series X, PC

RELEASE: Q4 2020



#16 GODFALL

PS5, PC

RELEASE: TBA



#15 The Wolf Among Us 2

PC, CONSOLES[TBA]

RELEASE: TBA



#14 No More Heroes 3

Platform: Nintendo Switch

Release Date: 2020



#13 Gods & Monsters

Platform: PC PS4 XBOX Nintendo Switch Stadia

Release Date: Feb 25, 2020



#12 Psychonauts 2

Platform:  PC PS4 XBOX ONE LINUX

Release Date: 2020



#11 Watch Dogs Legion

Platform: PC PS4 XBOX ONE STADIA

Release Date: TBA 2020



#10 Ghostwire Tokyo

Platform: PC PS4 XBOX ONE

Release Date: TBA 2020



#9 DRAGON BALL Z: KAKAROT

Platform: PC PS4 XBOX ONE

Release Date: January 17, 2020



#8 Rainbow Six Quarantine

Platform: PC PS4 XBOX ONE

Release Date: TBA 2020



#7 Microsoft Flight Simulator

Platform: PC XBOX ONE

Release Date: 2020



#6 Deathloop

Platform: PC PS4 XBOX ONE

Release Date: TBA 2020



#5 Baldur's Gate 3

Platform: PC Stadia

Release Date: TBA 2020



#4 HALF-LIFE: ALYX

Platform: PC

Release Date: MARCH 2020



#3 Resident Evil 3 Remake

Platform: PC PS4 XBOX ONE

Release Date: APRIL 3, 2020



#2 Elden Ring

Platform: PC PS4 XBOX ONE

Release Date: TBA 2020



#1 THE LEGEND OF ZELDA BREATH OF THE WILD 2

Platform: Nintendo SWITCH

Release Date: TBA 2020



BONUS



GHOSTRUNNER

Platform: PC PS4 XBOX ONE

Release Date: TBA 2020



CrossFire X

Platform: XBOX ONE 

Release Date: TBA 2020



Chernobylite

Platform: PC

Release Date: TBA 2020



Path of Exile 2

Platform: PC 

Release Date: TBA 2020



Destroy All Humans! Remake

Platform: PC PS4 XBOX ONE STADIA

Release Date: TBA 2020

