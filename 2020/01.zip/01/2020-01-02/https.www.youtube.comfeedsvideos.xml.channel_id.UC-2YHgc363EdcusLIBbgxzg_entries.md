# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## 5 Ridiculous 2020 Predictions | Random Thursday
 - [https://www.youtube.com/watch?v=LrgijOYzD4c](https://www.youtube.com/watch?v=LrgijOYzD4c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2020-01-02 00:00:00+00:00

Predicting the future is hard.

Interested in Fully Charged Live? I'll be there along with Tim Dodd the Everyday Astronaut, Ben Sullins from Teslanomics, as well as some of your favorite electric car YouTubers. Find out more here:
https://fullycharged.show/events/fully-charged-live-north-america/

Want to support the channel? Here's how!
Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-shirts and Merch: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

These facts and more from here:
https://bestlifeonline.com/2020-predictions/

Thomas Edison interview about Stainless Steel:
https://www.cbsnews.com/news/thomas-edisons-predictions-spot-on/

Nikola Tesla on coffee and tea:
https://www.pbs.org/tesla/res/res_art11.html

Time article on UBI from 1966:
http://content.time.com/time/subscriber/article/0,33009,835128-5,00.html

Scientific American on soil depletion:
https://www.scientificamerican.com/article/soil-depletion-and-nutrition-loss/

