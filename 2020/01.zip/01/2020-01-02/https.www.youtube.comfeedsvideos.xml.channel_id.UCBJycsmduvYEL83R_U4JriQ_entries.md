# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## The Banned Huawei Mate 30 Pro: Best Phone You Shouldn't Buy!
 - [https://www.youtube.com/watch?v=sr2fBCzXo4g](https://www.youtube.com/watch?v=sr2fBCzXo4g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-01-03 00:00:00+00:00

The Mate 30 Pro is the best phone I'd never recommend.

The Huawei Ban Explained: https://youtu.be/qZGpmWrVSaU

Installing Google services on Mate 30 Pro: https://www.xda-developers.com/huawei-mate-30-pro-install-google-apps-new-workaround-hisuite-backup-restore/

MKBHD Merch: http://shop.MKBHD.com

Video Gear I use: http://kit.co/MKBHD/video-gear#recom...
Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: 
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

