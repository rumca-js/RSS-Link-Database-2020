# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## All the Books I Got in 2019 (and how I got them)
 - [https://www.youtube.com/watch?v=X9cBFNbihFU](https://www.youtube.com/watch?v=X9cBFNbihFU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-01-03 00:00:00+00:00

Abbreviated List:
Schools of Linguistics - Geoff Sampson 
Everything I Want to Do Is Illegal -- Joel Salatin 
Devavanipraveshika 
The Golden Bough -- James Frazier 
Reader's Digest Guide to Gardening 
John Seymour 
Rosicrucian Enlightenment -- Frances Yates 
Totally Crazy Easy Florida Gardening -- David the Good 
Nag Hammadi Library 
Corpus Hermeticum 
The Kybalion 
Key to Theosophy and Voice of Silence by Helen Blavatsky 
There is a River, the Story of Edgar Cayce 
Book of Common Prayer 
Canterbury Tales by Geoffrey Chaucer 
Septuagint with the Apocrypha and Greek New Testament 
Archeofuturism by Guillaume Faye 
Paradise Lost by Milton 
Tales from Ovid by Ted Hughes (Ovid's Metamorphoses) 
Le Morte d'Arthur by Thomas Mallory 
Divine Comedy by Dante 
The Prose and Poetic Edda by Snorri Sturluson 
Screwtape Letters by C.S. Lewis 
Once and Future King 
Jason and the Argonauts 
Ben Hur 
La tabla de Flandés 
Grimm Fairy Tales 
Five Great Encyclicals 
Sophocles (everything) 
Games People Play 
Beyond Equality 
Economics in One Lesson by Henry Hazlitt 
Myth of Innocence 
Epic of Gilgamesh 
Alien Nation by Peter Brimelow 
Death on the Nile by Agatha Christie 
Civilization and its Discontents by Sigmund Freud 
The Q Document 
Socialism: Utopian and Scientific by Engels 
The Jesuits 
How to Win Friends and Influence People by Dale Carnegie 
Feast of Leviathan 
Pliny a Self-Portrait 
An Economic Interpretation of the Constitution of the United States by Charles Beard 
Painting as a Pastime 
Beowulf 
Lost Christianities by Bart Ehrman 
The Death of a Nation by John Stormer 
The Blue Book of the John Birch Society 
The International Jew: The World's Foremost Problem by Henry Ford 
The Rise and Fall of the Third Reich 
Morals and Dogma of the Ancient and Accepted Rite by Alfred Pike 
Introduction to the New Testament 
Before the Golden Age by Isaac Asimov 
The Great Gatsby 
Edgar Allan Poe Reader 
The Lord of the Flies 
Virgil's Aeneid 
Manga Guide to Statistics 
Contiguity Theory by Norvin Richards 

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE NOW: https://lukesmith.xyz/donate 💰😎👌💯

