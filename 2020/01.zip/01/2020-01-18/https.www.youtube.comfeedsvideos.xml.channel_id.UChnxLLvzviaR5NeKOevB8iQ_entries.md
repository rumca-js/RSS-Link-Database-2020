# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Surfing The Korg Wavestate at NAMM 2020
 - [https://www.youtube.com/watch?v=V5HY5-PgySU](https://www.youtube.com/watch?v=V5HY5-PgySU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2020-01-19 00:00:00+00:00

I touched a Korg Wavestate for the first time at NAMM 2020. I liked it quite a bit. It's like a mini workstation with 2.0 GB of PCM data that can be stacked and sequenced in wild ways. 

Here's the footage of me surfing presets and making tweaks while playing. It's a little raw, but there are some really fun moments.

I want one. Please, Korg, notice me.
------------------------------------
Patreon: http://bit.ly/rmrpatreon
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe
T-Shirts: http://bit.ly/rmrshirts
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

## Surfing the ASM Hydrasynth at NAMM 2020
 - [https://www.youtube.com/watch?v=U2_3iNMtDwU](https://www.youtube.com/watch?v=U2_3iNMtDwU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2020-01-19 00:00:00+00:00

I touched an ASM Hydrasynth for the first time at NAMM 2020. I like it a lot. It's very well laid out and sounds really good. I REALLY like the arp patch at the end.

Here's the footage of me surfing presets and making tweaks while playing.

When you see me not playing and being bothered it's because Mylar Melodies was next to me doing a video for Future Music and wouldn't stop talking to me. Dammit.
------------------------------------
Patreon: http://bit.ly/rmrpatreon
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe
T-Shirts: http://bit.ly/rmrshirts
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

