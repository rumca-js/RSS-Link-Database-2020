# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## "Orphan 55" - The Worst Doctor Who Episode Ever
 - [https://www.youtube.com/watch?v=CLYmvg-U1fA](https://www.youtube.com/watch?v=CLYmvg-U1fA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-01-18 00:00:00+00:00

Join me as I pick apart Series 12, Episode 3 of Doctor Who - Orphan 55.

