# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## In pictures: Harry and Meghan's life together
 - [https://www.bbc.co.uk/news/uk-51041958](https://www.bbc.co.uk/news/uk-51041958)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-18 19:34:21+00:00

The couple, who plan to step back from being "senior" royals, have been together for almost four years.

## Harry and Meghan: Queen and Buckingham Palace statements in full
 - [https://www.bbc.co.uk/news/uk-51164232](https://www.bbc.co.uk/news/uk-51164232)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-01-18 18:49:29+00:00

The couple will no longer use their HRH titles or formally represent the Queen.

