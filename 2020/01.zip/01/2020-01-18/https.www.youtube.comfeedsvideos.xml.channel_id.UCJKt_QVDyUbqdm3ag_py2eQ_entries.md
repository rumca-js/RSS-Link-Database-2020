# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## SID music: Jason Page - Last Ninja 2 Central Park Remake (FPGASID 8580 custom stereo bx_🎧)
 - [https://www.youtube.com/watch?v=z0rFy_-QxeY](https://www.youtube.com/watch?v=z0rFy_-QxeY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-01-19 00:00:00+00:00

"Last Ninja 2 Central Park Remake" (2020) by Jason Page. Original by Matt Gray. Graphics "SIDBlaster" (2019) by Dr. TerrorZ (#4 at Syntax 2019 mixed compo), background edited to be black instead of original brownish.

Made using hardware emulated audio via FPGASID running in C64 Reloaded MK2.

FPGASID:
http://www.fpgasid.de/

## SID music: Jason Page & Mark TDK Knight - Albino 4 (FPGASID 8580 pseudo-stereo bx_🎧)
 - [https://www.youtube.com/watch?v=Do-ReR9kwNE](https://www.youtube.com/watch?v=Do-ReR9kwNE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-01-18 00:00:00+00:00

"Albino 4" (2019-2020) SID version by Jason Page & Mark TDK Knight. Original by Mark TDK Knight. Graphics "All Good in the Hood" (2019) by Facet (#1 at Under Construction 2019 mixed graphics compo).

This music was made for the WIP C64 game MiniMIKE (to be as title music):
http://www.indieretronews.com/2019/05/minimike-early-c64-game-preview-feels.html

Studio version of Albino 4 can be heard in TDK's "Reawakening" album:
https://marktdkknight.bandcamp.com/album/reawakening

Made using hardware emulated audio via FPGASID running in C64 Reloaded MK2.

FPGASID:
http://www.fpgasid.de/

