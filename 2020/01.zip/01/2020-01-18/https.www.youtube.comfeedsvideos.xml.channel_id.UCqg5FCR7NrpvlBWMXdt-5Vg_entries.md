# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## I Thought I'd Hate Death Stranding, Instead I Loved It | The Joy of Gaming
 - [https://www.youtube.com/watch?v=KhyZpC0KYA4](https://www.youtube.com/watch?v=KhyZpC0KYA4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-01-18 00:00:00+00:00

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

This week on The Joy of Gaming, Nate takes a look at Death Stranding, a game he thought he'd hate, but ended up thoroughly enjoying. 

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►► https://sharkrobot.com/collections/zero-punctuation 

Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 

Like us on Facebook ►► http://www.facebook.com/EscapistMag

Follow us on Twitter ►► https://twitter.com/EscapistMag

#DeathStranding

