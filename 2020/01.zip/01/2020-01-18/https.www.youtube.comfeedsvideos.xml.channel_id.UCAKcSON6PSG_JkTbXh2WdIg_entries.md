# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Yola - Ride Out In The Country (Live on The Current)
 - [https://www.youtube.com/watch?v=MhbxVWt4OgE](https://www.youtube.com/watch?v=MhbxVWt4OgE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-01-19 00:00:00+00:00

Yola performs 'Ride Out in the Country' from her 2019 album, 'Walk Through Fire,' live in The Current studio.
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/
https://www.facebook.com/RadioHeartlandMPR/
https://twitter.com/RadioHeartland

## Yola - Shady Grove (Live at The Current)
 - [https://www.youtube.com/watch?v=jnQ1fg0tqPI](https://www.youtube.com/watch?v=jnQ1fg0tqPI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-01-19 00:00:00+00:00

Yola performs 'Shady Grove' from her 2019 album, 'Walk Through Fire,' live in The Current studio.
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/
https://www.facebook.com/RadioHeartlandMPR/
https://twitter.com/RadioHeartland

## Yola - Walk Through Fire (Live at The Current)
 - [https://www.youtube.com/watch?v=EB1eu7msn1c](https://www.youtube.com/watch?v=EB1eu7msn1c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-01-19 00:00:00+00:00

Yola performs the title track from her 2019 album, 'Walk Through Fire,' live in The Current studio.
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/
https://www.facebook.com/RadioHeartlandMPR/
https://twitter.com/RadioHeartland

## 26 Bats! Full performance Jan. 18, 2020 (The Current's 15th Anniversary Party)
 - [https://www.youtube.com/watch?v=Vg12XuZgkvw](https://www.youtube.com/watch?v=Vg12XuZgkvw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-01-18 00:00:00+00:00

Bailey Cogan (keyboards/vocals), Karl Remus (guitar), Warren Thomas Fenzi (drums), Daniel Chavez (trumpet), and Christian Wheeler (bass) have been releasing music as 26 BATS! since 2017. Cogan says that the band's music is "very fluid; it is very me. I use jazz chords, but it's not really jazz. It has elements of jazz, R&B, alternative rock. I feel like when I'm writing for 26 BATS!, I know it's 26 BATS! because it's a scene in my head — it's the color purple, or it's a night sky with stars and moons. It's going to emulate a vision."

The Minneapolis ensemble kick off The Current's 15th Anniversary, live from First Avenue in Minneapolis, Minn.

## Black Pumas Full performance Jan. 18, 2020 (The Current's 15th Anniversary Party)
 - [https://www.youtube.com/watch?v=Vt9G98kDgok](https://www.youtube.com/watch?v=Vt9G98kDgok)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-01-18 00:00:00+00:00

Black Pumas are on the rise. Nominated for a Grammy for best new artist and an impressive array of singles – like Colors, Fire, and Black Moon Rising – hitting airwaves and playlists, the #soulful #rock group is getting the attention they richly deserve. Watch the Adrian Quesada and Eric Burton-led group from Austin, Texas headline The Current's 15th Anniversary, #live from First Avenue in Minneapolis, Minn.

## Kate Bush, 'The Whole Story' (Teenage Kicks from The Current)
 - [https://www.youtube.com/watch?v=wvpPt8RBgxc](https://www.youtube.com/watch?v=wvpPt8RBgxc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-01-18 00:00:00+00:00

Host Jim McGuinn talks about Kate Bush's album, 'The Whole Story,' which was almost a greatest-hits album of sorts, but it raced up the charts to No. 1 back in 1987.
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## MaLLy Full performance Jan. 18, 2020 (The Current's 15th Anniversary Party)
 - [https://www.youtube.com/watch?v=nki8WIJAsIo](https://www.youtube.com/watch?v=nki8WIJAsIo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-01-18 00:00:00+00:00

Watch #Minneapolis powerhouse rapper MaLLy play a #live set at The Current's 15th Anniversary, live from First Avenue in Minneapolis, Minn. MaLLy (Malik Watkins) and DJ Just Nine will perform songs from MaLLy's new album, The Journey To A Smile, an album that surrounds the rapper's journey to living a more intentional lifestyle. #hiphop

## Seratones Full performance Jan. 18, 2020 (The Current's 15th Anniversary Party)
 - [https://www.youtube.com/watch?v=m6g8mjmG-Gg](https://www.youtube.com/watch?v=m6g8mjmG-Gg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-01-18 00:00:00+00:00

Watch the Shreveport, La., garage gospel #soul group play #live at The Current's 15th Anniversary #concert, live from First Avenue in Minneapolis, Minn. Seratones first broke onto the scene in 2016 with their debut album, Get Gone, and now they're back with their second release, Power. Lead singer and guitarist AJ Haynes was not intimidated by the proverbial sophomore album. "Always walk into everything with no expectations," she says. "It's exciting; it's a time to reinvent yourself. … It feels really good. I'd never really had an anxiety about a sophomore record — you know: buy the ticket, take the ride."

## The Bad Man Full performance Jan. 18, 2020 (The Current's 15th Anniversary Party)
 - [https://www.youtube.com/watch?v=HJAhDEGU0Q8](https://www.youtube.com/watch?v=HJAhDEGU0Q8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-01-18 00:00:00+00:00

Formed in 2016, The Bad Man have quickly garnered a reputation for rowdy and adrenaline-fueled #live shows. Watch the ska-tinged pub rock group from Minneapolis play at The Current's 15th Anniversary, live from First Avenue in Minneapolis, Minn. "Late nights, early mornings, and expensive bar tabs," that's how frontman Peter Memorich describes the lifestyle of the raucous group.

## Yola - artist to know (United States of Americana from The Current)
 - [https://www.youtube.com/watch?v=GJ123qP24xw](https://www.youtube.com/watch?v=GJ123qP24xw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-01-18 00:00:00+00:00

Host Bill DeVille shares some information about English singer-songwriter Yola, an artist who is up for four Grammys this year!
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/
https://www.facebook.com/RadioHeartlandMPR/
https://twitter.com/RadioHeartland

