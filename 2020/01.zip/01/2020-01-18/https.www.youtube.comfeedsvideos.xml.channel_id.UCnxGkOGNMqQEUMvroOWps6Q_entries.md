# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Best of the Week - January 12, 2020 - Joe Rogan Experience
 - [https://www.youtube.com/watch?v=CmumMEAP8Wk](https://www.youtube.com/watch?v=CmumMEAP8Wk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-19 00:00:00+00:00

Best of the Week - January 5, 2020 

#1409 w/Joey Diaz:
https://www.youtube.com/watch?v=6iYxbRZ21bw

#1410 w/Ash Dykes:
https://www.youtube.com/watch?v=RGLgfGT032s

#1411 w/Robert Downey Jr. : 
https://www.youtube.com/watch?v=d5XTDmm0KUQ

#1412 w/Jimmy Dore:
https://www.youtube.com/watch?v=amx14K9N5CY

#1413 w/Bill Maher:
https://www.youtube.com/watch?v=-KQGZa773sI

#1414 w/Mike Baker:
https://www.youtube.com/watch?v=wQ0GD9SpH_o

## Former CIA Agent Breaks Down Jeffrey Epstein Case
 - [https://www.youtube.com/watch?v=FozCkl1xj-w](https://www.youtube.com/watch?v=FozCkl1xj-w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-18 00:00:00+00:00

Taken from JRE #1414 w/Mike Baker: https://youtu.be/wQ0GD9SpH_o

## Former CIA Agent Mike Baker Bursts Iran WW3 Bubble | Joe Rogan
 - [https://www.youtube.com/watch?v=eRlkH1OpXGI](https://www.youtube.com/watch?v=eRlkH1OpXGI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-18 00:00:00+00:00

Taken from JRE #1414 w/Mike Baker:
https://youtu.be/wQ0GD9SpH_o

## Former CIA Agent Mike Baker on Russian Burisma Hack
 - [https://www.youtube.com/watch?v=-_ajL4bVyqU](https://www.youtube.com/watch?v=-_ajL4bVyqU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-18 00:00:00+00:00

Taken from JRE #1414 w/Mike Baker: https://youtu.be/wQ0GD9SpH_o

## Former Intelligence Agent on Air Force UFO Sightings
 - [https://www.youtube.com/watch?v=AiFBtBLFsx0](https://www.youtube.com/watch?v=AiFBtBLFsx0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-18 00:00:00+00:00

Taken from JRE #1414 w/Mike Baker: https://youtu.be/wQ0GD9SpH_o

## Joe Rogan Doesn't See Elizabeth Warren Beating Trump in 2020 Election
 - [https://www.youtube.com/watch?v=omawt4Ot218](https://www.youtube.com/watch?v=omawt4Ot218)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-18 00:00:00+00:00

Taken from JRE #1414 w/Mike Baker:
https://youtu.be/wQ0GD9SpH_o

## Joe Rogan Ponders Whether Aliens Have Visited Earth
 - [https://www.youtube.com/watch?v=icCWSK_czEk](https://www.youtube.com/watch?v=icCWSK_czEk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-18 00:00:00+00:00

Taken from JRE #1414 w/Mike Baker: https://youtu.be/wQ0GD9SpH_o

## Joe Rogan on Prince Harry and Meghan Leaving Royal Family
 - [https://www.youtube.com/watch?v=8WvbOB_3Nyg](https://www.youtube.com/watch?v=8WvbOB_3Nyg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-18 00:00:00+00:00

Taken from JRE #1414 w/Mike Baker: https://youtu.be/wQ0GD9SpH_o

## Racism Against Native Americans w/Mike Baker | Joe Rogan
 - [https://www.youtube.com/watch?v=axLxftqLDjM](https://www.youtube.com/watch?v=axLxftqLDjM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-18 00:00:00+00:00

Taken from JRE #1414 w/Mike Baker:
https://youtu.be/wQ0GD9SpH_o

## The Army Views Tik Tok as a Cyber Threat w/Mike Baker | Joe Rogan
 - [https://www.youtube.com/watch?v=NBHhcALdMcI](https://www.youtube.com/watch?v=NBHhcALdMcI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-18 00:00:00+00:00

Taken from JRE #1414 w/Mike Baker:
https://youtu.be/wQ0GD9SpH_o

## Why Do They Want to Marginalize Bernie Sanders? w/Mike Baker | Joe Rogan
 - [https://www.youtube.com/watch?v=1obclh_YhNU](https://www.youtube.com/watch?v=1obclh_YhNU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-18 00:00:00+00:00

Taken from JRE #1414 w/Mike Baker:
https://youtu.be/wQ0GD9SpH_o

