# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Laura Secord - Crop Circles (Live on KEXP)
 - [https://www.youtube.com/watch?v=fU07GRBIQ1s](https://www.youtube.com/watch?v=fU07GRBIQ1s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-19 00:00:00+00:00

http://KEXP.ORG presents Laura Secord performing "Crop Circles" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 6, 2019.

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://laurasecord.bandcamp.com

## Laura Secord - Embrace (Live on KEXP)
 - [https://www.youtube.com/watch?v=rhQzJEfk8PM](https://www.youtube.com/watch?v=rhQzJEfk8PM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-19 00:00:00+00:00

http://KEXP.ORG presents Laura Secord performing "Embrace" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 6, 2019.

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://laurasecord.bandcamp.com

## Laura Secord - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=1P1mGHfEDUw](https://www.youtube.com/watch?v=1P1mGHfEDUw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-19 00:00:00+00:00

http://KEXP.ORG presents Laura Secord performing live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 6, 2019.

Songs:
Crop Circles
I Thought, I Thought
Embrace
Sweat
Rock Star Suicide
Pornography For The Socially Aware
This Place Is The Answer To A Question I'm Not Asking

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://laurasecord.bandcamp.com

Read an interview with Laura Secord here: https://www.kexp.org/read/2020/1/19/iceland-laura-secord-diy-ethics-and-ending-friendships-live-video-interview/

## Laura Secord - I Thought, I Thought (Live on KEXP)
 - [https://www.youtube.com/watch?v=WaybJsRG6NU](https://www.youtube.com/watch?v=WaybJsRG6NU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-19 00:00:00+00:00

http://KEXP.ORG presents Laura Secord performing "SONG" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 6, 2019.

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://laurasecord.bandcamp.com

## Laura Secord - Pornography For The Socially Aware (Live on KEXP)
 - [https://www.youtube.com/watch?v=VR5MCbbeZhs](https://www.youtube.com/watch?v=VR5MCbbeZhs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-19 00:00:00+00:00

http://KEXP.ORG presents Laura Secord performing "Pornography For The Socially Aware" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 6, 2019.

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://laurasecord.bandcamp.com

## Laura Secord - Rock Star Suicide (Live on KEXP)
 - [https://www.youtube.com/watch?v=YACEznIHlVE](https://www.youtube.com/watch?v=YACEznIHlVE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-19 00:00:00+00:00

http://KEXP.ORG presents Laura Secord performing "Rock Star Suicide" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 6, 2019.

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://laurasecord.bandcamp.com

## Laura Secord - Sweat (Live on KEXP)
 - [https://www.youtube.com/watch?v=iu_BOacrQeY](https://www.youtube.com/watch?v=iu_BOacrQeY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-19 00:00:00+00:00

http://KEXP.ORG presents Laura Secord performing "Sweat" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 6, 2019.

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://laurasecord.bandcamp.com

## Laura Secord - This Place Is The Answer To A Question I'm Not Asking (Live on KEXP)
 - [https://www.youtube.com/watch?v=pFNslTfm95k](https://www.youtube.com/watch?v=pFNslTfm95k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-19 00:00:00+00:00

http://KEXP.ORG presents Laura Secord performing "This Place Is The Answer To A Question I'm Not Asking" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 6, 2019.

Host: Kevin Cole
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://laurasecord.bandcamp.com

