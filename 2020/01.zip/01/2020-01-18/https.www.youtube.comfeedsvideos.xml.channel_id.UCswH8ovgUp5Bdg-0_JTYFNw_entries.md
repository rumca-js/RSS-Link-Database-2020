# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Russell Brand & Logan Paul | Under The Skin Podcast
 - [https://www.youtube.com/watch?v=wfAR4VPSVHk](https://www.youtube.com/watch?v=wfAR4VPSVHk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-01-19 00:00:00+00:00

#112 Fame & The Communication Revolution with Logan Paul
This week’s guest on Under The Skin is Logan Paul. Logan is one of YouTube’s biggest stars with over 20 million subscribers. He known for his outrageous sometimes controversial but highly successful videos. In this podcast we discuss how this new manifestation of fame has engulfed the digital landscape and the effect it has had on Logan. Check out his podcast Impaulsive on YouTube!

You can listen all the latest episodes of my Under The Skin podcast here: 
http://luminary.link/russell

I'm going on tour in Australia, New Zealand and Canada this year - check the dates and get tickets here: http://www.russellbrand.com/live

Check out my 12-Day Online Recovery Course here: https://www.onecommune.com/a/20323/cGftrerE 

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

