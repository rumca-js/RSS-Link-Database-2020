# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Should you buy a $50 CPU??
 - [https://www.youtube.com/watch?v=JISJ_YTI9s0](https://www.youtube.com/watch?v=JISJ_YTI9s0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-01-19 00:00:00+00:00

Get 20% OFF + Free Shipping at Manscaped.com with code TECH - https://mnscpd.com/2ML8ni3

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire

At just $50 AMD's new Athlon 3000G looks darn compelling - but can we overclock it enough for it to make sense for gamers?

Buy the AMD Athlon 3000G
On Amazon (PAID LINK): https://geni.us/NUML
On Newegg (PAID LINK): https://lmg.gg/8mPto

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1146992-should-you-buy-a-50-cpu/

Our Affiliates, Referral Programs, and Sponsors: https://linustechtips.com/main/topic/75969-linus-tech-tips-affiliates-referral-programs-and-sponsors Displate metal posters: https://lmg.gg/displateltt

Linus Tech Tips merchandise at http://www.LTTStore.com/ Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips Our production gear: http://geni.us/cvOS Our Chrono.gg game store: https://ltt.chrono.gg/

Twitter - https://twitter.com/linustech Facebook - http://www.facebook.com/LinusTech Instagram - https://www.instagram.com/linustech Twitch - https://www.twitch.tv/linustech

Intro Screen Music Credit: Title: Laszlo - Supernova Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712 Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

## Apple’s Pro Display XDR – A PC Guy’s Perspective
 - [https://www.youtube.com/watch?v=X089oYPc5Pg](https://www.youtube.com/watch?v=X089oYPc5Pg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-01-18 00:00:00+00:00

Get an unrestricted 30-day free trial of FreshBooks at https://www.freshbooks.com/techtips

Get 15% off your order with offer code LINUS15 and free shipping on Ruggable at https://myruggable.com/LINUS15

Love it or hate it, Apple’s EXPENSIVE Pro Display XDR is here and ready for its close-up – How many blemishes will show through, and is it REALLY “pro”?

Buy a Pro Display XDR:
On Amazon (PAID LINK): https://geni.us/CtivByN
From Apple: https://lmg.gg/FcE2X

Buy a Pro Stand:
On Amazon (PAID LINK): https://geni.us/C65BM

Buy a VESA Mount Adapter:
On Amazon (PAID LINK): https://geni.us/eBh06

Buy an arm mount to go with the VESA Mount Adapter:
On Amazon (PAID LINK): https://geni.us/kSEAJ
On Newegg (PAID LINK): https://lmg.gg/RUGkZ

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1146666-apple%E2%80%99s-pro-display-xdr-%E2%80%93-a-pc-guy%E2%80%99s-perspective/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Come see us at LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

