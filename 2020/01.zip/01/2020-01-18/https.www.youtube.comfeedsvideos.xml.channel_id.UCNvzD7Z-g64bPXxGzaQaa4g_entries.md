# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Dragon Ball Z: Kakarot - 10 Things The Game Doesn't Tell You
 - [https://www.youtube.com/watch?v=f1S9F0KOUzo](https://www.youtube.com/watch?v=f1S9F0KOUzo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-01-19 00:00:00+00:00

Dragon Ball Z Kakarot (PC, PS4, Xbox One) has quite a few systems to master. Here are some tips that might help you for Goku's adventures
Subscribe for more: http://youtube.com/gameranxtv

## Dragon Ball Z: Kakarot - Before You Buy
 - [https://www.youtube.com/watch?v=HIlqhi-D_L8](https://www.youtube.com/watch?v=HIlqhi-D_L8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-01-18 00:00:00+00:00

DBZ Kakarot (PC, PS4, Xbox One) is a third person action adventure RPG centered around Goku and the main sagas of famed franchise. How is it? Let's talk.
Subscribe for more: http://youtube.com/gameranxtv ▼▼


Buy DBZ Kakarot: https://amzn.to/38ebAiu




Watch more 'Before You Buy': https://bit.ly/2kfdxI6

