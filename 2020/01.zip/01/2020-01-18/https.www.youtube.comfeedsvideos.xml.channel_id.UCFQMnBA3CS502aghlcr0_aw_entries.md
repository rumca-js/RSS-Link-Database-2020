# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## while you studied the law, he studied the blade
 - [https://www.youtube.com/watch?v=l2EEDfrvnu4](https://www.youtube.com/watch?v=l2EEDfrvnu4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-01-18 00:00:00+00:00

man requests trial by combat with his ex-wife using japanese katana swords.

