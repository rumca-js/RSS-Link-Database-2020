# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Ex-professor accused of spending grant money on strippers, sports bars and iTunes
 - [https://www.cnn.com/2020/01/18/us/drexel-former-professor-grant-money-strippers-trnd/index.html](https://www.cnn.com/2020/01/18/us/drexel-former-professor-grant-money-strippers-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 23:26:25+00:00

A former Drexel University professor faces criminal charges after allegedly stealing $185,000 in research grant money and using it at adult entertainment venues and on purchases for iTunes, meals and other expenses.

## Hank Azaria says he will no longer voice controversial Indian-American character on 'The Simpsons'
 - [https://www.cnn.com/2020/01/18/entertainment/apu-hank-azaria-simpsons-trnd/index.html](https://www.cnn.com/2020/01/18/entertainment/apu-hank-azaria-simpsons-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 21:55:03+00:00

After 30 years as a controversial Indian-American character on "The Simpsons," Hank Azaria has announced he will no longer voice the thickly accented Apu Nahasapeemapetilon.

## A Winnie the Pooh painting has been missing and the FBI needs help finding it
 - [https://www.cnn.com/2020/01/18/us/winnie-the-pooh-day-stolen-watercolor-trnd/index.html](https://www.cnn.com/2020/01/18/us/winnie-the-pooh-day-stolen-watercolor-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 21:51:12+00:00

The FBI wants some help finding the adorable golden bear.

## Maximilian Günther becomes youngest Formula E winner in history
 - [https://www.cnn.com/2020/01/18/sport/formula-e-santiago-e-prix-maximilian-gnther-spt-intl/index.html](https://www.cnn.com/2020/01/18/sport/formula-e-santiago-e-prix-maximilian-gnther-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 21:41:46+00:00

What's in a name?

## Pence's outrageous op-ed holds deeper meaning
 - [https://www.cnn.com/2020/01/18/opinions/mike-pence-wsj-oped-is-wrong-suri/index.html](https://www.cnn.com/2020/01/18/opinions/mike-pence-wsj-oped-is-wrong-suri/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 21:14:29+00:00

For only the third time in American history, the US Senate has opened a trial for an impeached president. On Thursday, Supreme Court Chief Justice John Roberts administered a special oath to all senators, requiring that they "do impartial justice" in their judgment of the president's alleged "high crimes and misdemeanors." What does that mean in practice, when the Senate is so divided by party, with a majority leader who has promised to coordinate closely with the impeached president?

## Teen sensation Erling Braut Håland scores debut hat-trick to save Borussia Dortmund
 - [https://www.cnn.com/2020/01/18/football/borussia-dortmund-erling-braut-hland-augsburg-spt-intl/index.html](https://www.cnn.com/2020/01/18/football/borussia-dortmund-erling-braut-hland-augsburg-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 19:39:16+00:00

As debut performances go, Erling Braut Håland's for Borussia Dortmund was certainly one to remember.

## Couple will now use these titles instead
 - [https://www.cnn.com/videos/world/2020/01/18/harry-and-meghan-no-longer-working-royals-foster-vpx.cnn](https://www.cnn.com/videos/world/2020/01/18/harry-and-meghan-no-longer-working-royals-foster-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 19:38:40+00:00

CNN's Max Foster explains the significance of the news that Harry and Meghan, the Duke and Duchess of Sussex, will no longer use the titles of His and Her Royal Highness after announcing they would step back from their roles as senior members of the royal family.

## Watch this soldier surprise his mom after two years apart
 - [https://www.cnn.com/videos/us/2020/01/18/soldier-surprises-mom-after-two-years-deployment-atlanta-orig-sc.cnn](https://www.cnn.com/videos/us/2020/01/18/soldier-surprises-mom-after-two-years-deployment-atlanta-orig-sc.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 18:58:18+00:00

L.J. Williamson, a high school police officer in Atlanta, was being honored during a pep rally when she got a big surprise from her son, US Army Spc. Shakir Aquill.

## WaPo: National Archives admits to altering 2017 photo
 - [https://www.cnn.com/videos/politics/2020/01/18/washington-post-national-archives-womens-march-photo-nr-vpx.cnn](https://www.cnn.com/videos/politics/2020/01/18/washington-post-national-archives-womens-march-photo-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 18:47:59+00:00

The National Archives admitted to altering a 2017 photograph of the Women's March to censor signs referencing women's anatomy and President Donald Trump's name, according to The Washington Post.

## This state held a contest for better highway safety signs. The winners are hilarious
 - [https://www.cnn.com/2020/01/18/us/georgia-safety-message-highway-signs-contest-trnd/index.html](https://www.cnn.com/2020/01/18/us/georgia-safety-message-highway-signs-contest-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 18:06:37+00:00

"Click it or ticket," once upon a time, was a snappy way for traffic officials to encourage motorists to buckle up.

## Trump details Soleimani strike to GOP donors
 - [https://www.cnn.com/videos/politics/2020/01/18/trump-soleimani-details-mar-a-lago-audio-vpx.cnn](https://www.cnn.com/videos/politics/2020/01/18/trump-soleimani-details-mar-a-lago-audio-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 17:17:47+00:00

President Trump recounted minute-by-minute details of the US strike that killed Iran's top military commander during remarks to high-dollar Republican donors at his South Florida estate, according to audio obtained by CNN.

## Spotify wants your pet to listen to music too
 - [https://www.cnn.com/videos/business/2020/01/15/spotify-pet-playlist-podcast-orig.cnn-business](https://www.cnn.com/videos/business/2020/01/15/spotify-pet-playlist-podcast-orig.cnn-business)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 16:34:24+00:00

Spotify is rolling out a playlist generator for your dogs, cats, hamsters, birds, and iguanas.

## Painting found hidden in Italian gallery wall confirmed as long-lost Klimt
 - [https://www.cnn.com/style/article/klimt-painting-authentic-intl-scli/index.html](https://www.cnn.com/style/article/klimt-painting-authentic-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 15:51:53+00:00

Italian authorities have confirmed a painting found hidden in the wall of a Piacenza art gallery is the long-lost "Portrait of a Lady" by Austrian artist Gustav Klimt.

## A man found $43,000 in a secondhand couch and returned it all
 - [https://www.cnn.com/2020/01/18/us/couch-money-found-trnd/index.html](https://www.cnn.com/2020/01/18/us/couch-money-found-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 15:39:36+00:00

A Michigan man bought a used couch for his man cave in December, and this week, he made an interesting discovery — $43,000 in cash hidden in the cushion.

## 'It's going to be devastating': Senators gear up to play by the impeachment trial's strict rules
 - [https://www.cnn.com/collections/intl-impeachment-0118/](https://www.cnn.com/collections/intl-impeachment-0118/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 15:04:48+00:00



## Brothers smash world records rowing across Atlantic
 - [https://www.cnn.com/2020/01/18/sport/scottish-rowing-atlantic-intl-scli-gbr-spt/index.html](https://www.cnn.com/2020/01/18/sport/scottish-rowing-atlantic-intl-scli-gbr-spt/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 15:03:22+00:00

Three brothers from Scotland have set three world records after rowing 3,000 miles across the Atlantic Ocean in 35 days.

## Iran will send downed plane's black boxes to Ukraine for analysis
 - [https://www.cnn.com/2020/01/18/middleeast/iran-ukraine-plane-crash-black-boxes-intl/index.html](https://www.cnn.com/2020/01/18/middleeast/iran-ukraine-plane-crash-black-boxes-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 14:51:43+00:00

Iran will send to Ukraine the black boxes of a Ukrainian airliner that its military accidentally shot down this month, killing all 176 people on board, Iranian media reports.

## New documents released on possible surveillance of US ambassador to Ukraine
 - [https://www.cnn.com/2020/01/17/politics/lev-parnas-documents-january-17/index.html](https://www.cnn.com/2020/01/17/politics/lev-parnas-documents-january-17/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 14:41:02+00:00



## Police backup called to guard President Macron amid protests
 - [https://www.cnn.com/2020/01/18/europe/france-macron-protests-intl/index.html](https://www.cnn.com/2020/01/18/europe/france-macron-protests-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 14:40:33+00:00

Police in Paris were forced to call for backup on Friday as dozens of protesters outside a theater tried to storm the building and reach President Emmanuel Macron.

## Michelin strips third star from legendary restaurant after 55 years
 - [https://www.cnn.com/2020/01/18/europe/france-restaurant-michelin-paul-bocuse-intl/index.html](https://www.cnn.com/2020/01/18/europe/france-restaurant-michelin-paul-bocuse-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 14:38:53+00:00

Michelin has stripped the late legendary chef Paul Bocuse's flagship restaurant of one of its stars after 55 years of holding three, drawing anger from the world of fine French cuisine.

## Millions remain in the path of a large-scale winter storm as it tracks through the Northeast
 - [https://www.cnn.com/2020/01/18/weather/storm-forecast-snow-ice-saturday-northeast/index.html](https://www.cnn.com/2020/01/18/weather/storm-forecast-snow-ice-saturday-northeast/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 14:14:57+00:00

Heavy snow will fall across the Midwest as tens of millions remain in the path of a dangerous winter storm through the weekend.

## Trump reveals new details of Soleimani strike to donors at Mar-a-Lago
 - [https://www.cnn.com/2020/01/18/politics/trump-soleimani-details-mar-a-lago/index.html](https://www.cnn.com/2020/01/18/politics/trump-soleimani-details-mar-a-lago/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 14:00:57+00:00

• The evolving US justification for killing Iran's top general

## More than 1,000 people likely infected by China's mysterious virus
 - [https://www.cnn.com/2020/01/18/asia/china-coronavirus-study-intl/index.html](https://www.cnn.com/2020/01/18/asia/china-coronavirus-study-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 13:58:46+00:00

The number of cases in an outbreak of a new strain of coronavirus in China is likely to have been grossly underestimated, according to a new study, which warns that human-to-human transmission of the mysterious virus may be possible.

## The pain of losing civil rights icons in the Trump era
 - [https://www.cnn.com/2020/01/18/politics/john-lewis-elijah-cummings-civil-rights-icons-trump-era/index.html](https://www.cnn.com/2020/01/18/politics/john-lewis-elijah-cummings-civil-rights-icons-trump-era/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 12:51:57+00:00

As America remembers Martin Luther King Jr. this weekend, it's hard to think about the slain reverend's shrinking number of surviving associates and immediate successors and not feel a distinct sadness.

## Meet the man trying to walk 1,000 miles ... in a Speedo
 - [https://www.cnn.com/2020/01/18/sport/speedo-mick-walking-everton-football-spt-intl/index.html](https://www.cnn.com/2020/01/18/sport/speedo-mick-walking-everton-football-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 11:53:48+00:00

The bleak midwinter can be tough. It doesn't matter how many layers you put on, you just can't shake the cold. It's even worse when the rain or snow comes.

## Can Roger Federer add to 20 Grand Slam titles?
 - [https://www.cnn.com/2020/01/18/tennis/australian-open-rafa-nadal-novak-djokovic-roger-federer-serena-williams-tennis-spt-intl/index.html](https://www.cnn.com/2020/01/18/tennis/australian-open-rafa-nadal-novak-djokovic-roger-federer-serena-williams-tennis-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 11:32:43+00:00

With the impact of bushfire smoke dominating the buildup to the Australian Open, it's easy to forget what might happen on the court.

## Clock projection but no Big Ben 'bong' planned for Brexit Day
 - [https://www.cnn.com/2020/01/18/uk/big-ben-clock-projection-intl-scli-gbr/index.html](https://www.cnn.com/2020/01/18/uk/big-ben-clock-projection-intl-scli-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 11:06:47+00:00

A clock counting down to the second the United Kingdom leaves the European Union on January 31 will be projected onto the bricks of Downing Street as part of government plans to mark Brexit, a spokeswoman for Downing Street told CNN on Saturday.

## 4 killed, 1 wounded in Utah shooting
 - [https://www.cnn.com/2020/01/17/us/utah-grantsville-shooting/index.html](https://www.cnn.com/2020/01/17/us/utah-grantsville-shooting/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 10:51:03+00:00

Four people were shot to death in a residence in Grantsville, Utah, Friday night, according to police.

## Nurses and doctors are flocking to TikTok. But are they eroding patients' trust?
 - [https://www.cnn.com/2020/01/18/us/tiktok-doctors-nurses-trnd/index.html](https://www.cnn.com/2020/01/18/us/tiktok-doctors-nurses-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 10:06:09+00:00

Scroll past the teens who film themselves flossing (that's the dance, not the act of dental hygiene) and the young activists satirizing the issues of the day, and you might find a board-certified physician thrusting furiously to a Ciara song, extolling the virtues of complex carbohydrates.

## Did '13 Reasons Why' lead to a spike in adolescent suicides? Researchers are divided
 - [https://www.cnn.com/2020/01/18/health/13-reasons-why-study-suicides-trnd/index.html](https://www.cnn.com/2020/01/18/health/13-reasons-why-study-suicides-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 10:01:43+00:00

When Netflix debuted "13 Reasons Why" in 2017, some mental health experts argued the show was "dangerous" for its depiction of teen suicide.

## Conor McGregor is making his return to the octagon tonight for UFC 246
 - [https://www.cnn.com/2020/01/18/us/conor-mcgregor-ufc-246-spt-trnd/index.html](https://www.cnn.com/2020/01/18/us/conor-mcgregor-ufc-246-spt-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 10:01:28+00:00

UFC superstar Conor "The Notorious" McGregor returns to the octagon Saturday evening for UFC 246.

## Declassified FBI bulletin says Saudi officials help their citizens flee US legal issues
 - [https://www.cnn.com/2020/01/18/us/saudi-officials-flee-legal-issues-fbi/index.html](https://www.cnn.com/2020/01/18/us/saudi-officials-flee-legal-issues-fbi/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 09:46:49+00:00

The FBI believes that the Kingdom of Saudi Arabia officials "almost certainly" help their US-based citizens flee the country to avoid legal issues, according to a recently declassified intelligence bulletin.

## The truth behind baseball's sign stealing legend
 - [https://www.cnn.com/2020/01/18/us/sign-stealing-baseball-houston-astros-boston-red-sox-trnd/index.html](https://www.cnn.com/2020/01/18/us/sign-stealing-baseball-houston-astros-boston-red-sox-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 09:06:06+00:00

Baseball is a game of legend. Babe Ruth. "Casey at the Bat." Hammerin' Hank Aaron. "A League of Their Own:" In every great and true baseball story, there's a little bit of fiction, and its greatest myths are just believable enough to be true.

## New documents released on possible surveillance of ambassador
 - [https://www.cnn.com/collections/intl-yovanovich-surveillance-ukraine-0118/](https://www.cnn.com/collections/intl-yovanovich-surveillance-ukraine-0118/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 08:59:02+00:00



## Gas heating is the biggest threat to Britain's climate goal
 - [https://www.cnn.com/2020/01/18/business/uk-net-zero-emissions-2050/index.html](https://www.cnn.com/2020/01/18/business/uk-net-zero-emissions-2050/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 07:55:26+00:00

The United Kingdom made history last year when it became the first major economy to commit to pumping no more greenhouse gases into the atmosphere than it removes by 2050.

## A 14-year-old girl was kidnapped by three men and used Snapchat to alert her friends, police say
 - [https://www.cnn.com/2020/01/18/us/snapchat-kidnapping-california/index.html](https://www.cnn.com/2020/01/18/us/snapchat-kidnapping-california/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 06:12:43+00:00

A 14-year-old girl who was kidnapped in Northern California used Snapchat to share her location with her friends, who then called 911, police said.

## A teen's final days with the flu
 - [https://www.cnn.com/2020/01/17/health/flu-ohio-teen-kaylee-roberts-death-eprise/index.html](https://www.cnn.com/2020/01/17/health/flu-ohio-teen-kaylee-roberts-death-eprise/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 05:08:03+00:00

On Christmas Day, 16-year-old Kaylee Roberts opened presents at her aunt's house in suburban Cleveland, joyfully celebrating the holiday and laughing with her cousins.

## How the doctor Evelyn Yang accused was allowed to go free
 - [https://www.cnn.com/2020/01/17/politics/evelyn-yang-doctor-sexual-assault-manhattan-da-vance/index.html](https://www.cnn.com/2020/01/17/politics/evelyn-yang-doctor-sexual-assault-manhattan-da-vance/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 01:14:29+00:00

Evelyn Yang's revelation that she was sexually assaulted by her OB-GYN has renewed national focus on a sweetheart plea deal between Manhattan's district attorney and her former doctor.

## A powerful eruption could happen at any moment. But some residents refuse to leave
 - [https://www.cnn.com/2020/01/17/asia/taal-volcano-philippines-fatal-attraction-intl-hnk/index.html](https://www.cnn.com/2020/01/17/asia/taal-volcano-philippines-fatal-attraction-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 00:57:40+00:00

• Desolate images from Taal volcano show horses and cows buried in ash

## See Lev Parnas photos just released by House Democrats
 - [https://www.cnn.com/videos/politics/2020/01/17/new-evidence-released-lev-parnas-photos-ebof-vpx.cnn](https://www.cnn.com/videos/politics/2020/01/17/new-evidence-released-lev-parnas-photos-ebof-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 00:53:48+00:00

New documents released by House Democrats include communications and photos from indicted Rudy Giuliani associate Lev Parnas.

## Opinion: Eminem went too far
 - [https://www.cnn.com/2020/01/17/opinions/eminem-surprise-album-same-tired-act-thomas/index.html](https://www.cnn.com/2020/01/17/opinions/eminem-surprise-album-same-tired-act-thomas/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-18 00:25:28+00:00

You'd think that, after nearly a quarter of a century, Eminem might have had his fill of controversy. But if his latest lyrics are any indication, his appetite for outrage remains unsatisfied.

