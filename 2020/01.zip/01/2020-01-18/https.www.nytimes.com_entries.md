## The Secretive Company That Might End Privacy as We Know It - The New York Times
 - [https://www.nytimes.com/2020/01/18/technology/clearview-privacy-facial-recognition.html](https://www.nytimes.com/2020/01/18/technology/clearview-privacy-facial-recognition.html)
 - RSS feed: https://www.nytimes.com
 - date published: 2020-01-18 19:58:54+00:00

The Secretive Company That Might End Privacy as We Know It - The New York Times

