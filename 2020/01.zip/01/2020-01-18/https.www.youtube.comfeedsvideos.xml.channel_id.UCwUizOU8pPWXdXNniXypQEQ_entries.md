# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## You’re Full of Sh*t! Here’s Why - Authentic JP
 - [https://www.youtube.com/watch?v=8QjbxB5A6mE](https://www.youtube.com/watch?v=8QjbxB5A6mE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-01-18 00:00:00+00:00

You're full of sh*t! In this video you'll learn why that's a good thing and how it helps you be true to yourself. Trying to be who you think you are will wear you out. Self-acceptance and the self growth journey into being yourself will liberate you. This video will help!
#AuthenticJP #SincereSaturday
Subscribe to my channel for MORE! New videos every week!: https://www.youtube.com/user/AwakenWithJP?sub_confirmation=1

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Click Here to join my PATREON - https://awakenwithjp.com/patron
---- Want to be the first to see my new videos with 24 hour early access? Just click this to receive the alerts! - https://m.me/awakenwithjp?ref=w6836464

-Join my private membership community, AwakenWithJP PremiumAF at: https://awakenwithjp.com/subscribe

Listen and Subscribe to my NEW Podcast here: 
https://podcasts.apple.com/ca/podcast/awaken-with-jp-sears-show/id1436938686
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

-Order my new book at: http://HowToBeUltraSpiritual.com/

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

