# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## [NV#350] Nie bierz ślubu z tych powodów!
 - [https://www.youtube.com/watch?v=fqvVsYsYz04](https://www.youtube.com/watch?v=fqvVsYsYz04)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-01-19 00:00:00+00:00

#NocnyVlog
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zdjęcia i montaż: Adam Szustak OP
Muzyka: https://soundcloud.com/findinghopemusic

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#164] Masz nóż nad głową?
 - [https://www.youtube.com/watch?v=2BKjxZvjN8M](https://www.youtube.com/watch?v=2BKjxZvjN8M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-01-18 00:00:00+00:00

#CNN #dobrewiadomości 
Kazanie na niedzielę, w każdą niedzielę, czyli Słowo Na Niedzielę.
II Niedziela Zwykła , Rok A
________________________________________
1. czytanie (Iz 49, 3. 5-6)
Pan rzekł do mnie: «Ty jesteś sługą moim, Izraelu, w tobie się rozsławię».
Wsławiłem się w oczach Pana, Bóg mój stał się moją siłą. A teraz przemówił Pan, który mnie ukształtował od urodzenia na swego Sługę, bym nawrócił do Niego Jakuba i zgromadził Mu Izraela.

A mówił: «To zbyt mało, iż jesteś Mi Sługą dla podźwignięcia pokoleń Jakuba i sprowadzenia ocalałych z Izraela! Ustanowię cię światłością dla pogan, aby moje zbawienie dotarło aż do krańców ziemi».

2. czytanie (1 Kor 1, 1-3)

Paweł, z woli Bożej powołany na apostoła Jezusa Chrystusa, i Sostenes, brat, do Kościoła Bożego w Koryncie, do tych, którzy zostali uświęceni w Jezusie Chrystusie i powołani do świętości wespół ze wszystkimi, co na każdym miejscu wzywają imienia Pana naszego, Jezusa Chrystusa, ich i naszego Pana. Łaska wam i pokój od Boga Ojca naszego i Pana Jezusa Chrystusa!

Ewangelia (J 1, 29-34)

Jan zobaczył podchodzącego ku niemu Jezusa i rzekł: «Oto Baranek Boży, który gładzi grzech świata. To jest Ten, o którym powiedziałem: „Po mnie przyjdzie Mąż, który mnie przewyższył godnością, gdyż był wcześniej ode mnie”. Ja Go przedtem nie znałem, ale przyszedłem chrzcić wodą w tym celu, aby On się objawił Izraelowi».

Jan dał takie świadectwo: «Ujrzałem ducha, który zstępował z nieba jak gołębica i spoczął na Nim. Ja Go przedtem nie znałem, ale Ten, który mnie posłał, abym chrzcił wodą, powiedział do mnie: „Ten, nad którym ujrzysz ducha zstępującego i spoczywającego na Nim, jest Tym, który chrzci Duchem Świętym”. Ja to ujrzałem i daję świadectwo, że On jest Synem Bożym».
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Już się nie wstydzę || Adam Szustak OP || Zapowiedź
 - [https://www.youtube.com/watch?v=nBu3Nh0zb3w](https://www.youtube.com/watch?v=nBu3Nh0zb3w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-01-18 00:00:00+00:00

Dawno temu na początku istnienia świata, kiedy wszystko się popsuło schowaliśmy się w krzakach. Ze wstydu. Wstydu własnego grzechu, słabości i poczucia przegranej. Wstydu, który sprawia, że ciągle się boimy osądzenia, odrzucenia i pokazania światu jacy naprawdę jesteśmy. Wstydu naszej brzydoty, naszych porażek i poczucia bezsensu. Najwyższa pora z tym skończyć! Zapraszam Was do kilkunastu miast Polski na niezwykłe spotkania, na których pozwolimy, żeby ogarnęło nas światło, które wreszcie pozwoli nam wyjść z cienia, z mroku naszego wstydu. Żebyśmy wreszcie mogli z podniesioną głową spojrzeć w twarz ludziom, światu, Panu Bogu i sobie samym. Żebyśmy mogli wreszcie powiedzieć: Już się nie wstydzę!

Zapraszamy na cykl konferencji tylko dla dorosłych

Spotkaniom towarzyszyć muzycznie będzie zespół w składzie: 
Agnieszka Musiał || Jan Smoczyński || Kamil Siciak.

LINK do całej trasy na FB ☞ http://bit.ly/JużSięNieWstydzę
🎫 BILETY ☞ WYPRZEDANE  🎫

poszczególne wydarzenia:

20.04.2020 Katowice  
Międzynarodowe Centrum Kongresowe - Sala Audytoryjna 
FB ☞ http://bit.ly/jużsięniewstydzęKatowice 


21.04.2020 Katowice  
Międzynarodowe Centrum Kongresowe - Sala Audytoryjna 
FB ☞ http://bit.ly/jużsięniewstydzeKatowice2 

22.04.2020 Lublin  
Centrum Spotkania Kultur w Lublinie - Sala Operowa 
FB ☞ http://bit.ly/jużsięniewstydzęLublin 

23.04.2020 Wrocław 
Sala Audytoryjna WCK przy Hali Stulecia 
FB ☞ http://bit.ly/jużsięniewstydzęWrocław 

24.04.2020 Poznań  
MTP - Sala Ziemi 
FB ☞ http://bit.ly/jużsięniewstydzęPoznań

27.04.2020 Łódź  
Klub Wytwórnia 
FB ☞ http://bit.ly/jużsięniewstydzęŁódź

28.04.2020 Kraków  
Centrum Kongresowego ICE Kraków 
FB ☞ http://bit.ly/jużsięniewstydzęKraków

29.04.2020 Kielce 
Targi Kielce 
FB ☞ http://bit.ly/jużsięniewstydzęKielce

30.04.2020 Gdańsk 
Teatr Szekspirowski 
FB ☞ http://bit.ly/jużsięniewstydzęGdańskTeatr

01.05.2020 Gdańsk 
Polska Filharmonia Bałtycka im. Fryderyka Chopina w Gdańsku 
FB ☞ http://bit.ly/jużsięniewstydzęGdańskFilharmonia

02.05.2020 Warszawa 
Teatr Polski im. Arnolda Szyfmana w Warszawie 
FB ☞ http://bit.ly/jużsięniewstydzęWarszawaTeatrPolski

05.05.2020 Gorzów Wielkopolski 
Filharmonia Gorzowska 
FB ☞ http://bit.ly/jużsięniewstydzęGorzów

06.05.2020 Toruń  
CKK Jordanki 
FB ☞ http://bit.ly/jużsięniewstydzęToruń

07.05.2020 Bydgoszcz  
Filharmonia Pomorska im. I. J. Paderewskiego w Bydgoszczy 
FB ☞ http://bit.ly/jużsięniewstydzęBydgoszcz

09.05.2020 Szczecin 
Filharmonia im. Mieczysława Karłowicza w Szczecinie 
FB ☞ http://bit.ly/jużsięniewstydzęSzczecin

11.05.2020 Białystok  
Opera i Filharmonia Podlaska - Europejskie Centrum Sztuki w Białymstoku 
FB ☞ http://bit.ly/jużsięniewstydzęBiałystok 

12.05.2020 Warszawa 
Palladium 
FB ☞ http://bit.ly/jużsięniewstydzęWarszawaPalladium 

13.05.2020 Warszawa 
Palladium 
FB ☞ http://bit.ly/juzsięniewstydzeWarszawaPalladium

14.05.2020 Częstochowa  
Filharmonia Częstochowska 
FB ☞ http://bit.ly/jużsięniewstydzeCzęstochowa

zdjęcia i montaż: Marcin Jończyk
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#407] Nie myj się!
 - [https://www.youtube.com/watch?v=fRu5S-D3wTI](https://www.youtube.com/watch?v=fRu5S-D3wTI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-01-18 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

