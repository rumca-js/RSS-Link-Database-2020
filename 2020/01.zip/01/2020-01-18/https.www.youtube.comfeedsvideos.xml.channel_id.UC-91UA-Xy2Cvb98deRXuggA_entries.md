# Source:Joshua Fluke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-91UA-Xy2Cvb98deRXuggA, language:en-US

## Business & Side Hustle - #grindreel #entrepreneurship
 - [https://www.youtube.com/watch?v=H6lvcRvbLW4](https://www.youtube.com/watch?v=H6lvcRvbLW4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-91UA-Xy2Cvb98deRXuggA
 - date published: 2020-01-19 00:00:00+00:00

❤️ Support me because corporate sponsors rarely do! 
 https://www.patreon.com/joshuafluke

🔥 Need a resume/cover letter? Check out my templates!  
https://grindreel.com/

👊 Join the community! 
https://discord.gg/Joshuafluke

My Other Socials🤳
https://www.tiktok.com/@joshua_fluke
https://www.instagram.com/joshuafluke/  📸
https://twitter.com/joshuafluke  🐦

📧 Email me directly!: grindreel@gmail.com
📧 Business inquiries: Joshuafluke@thoughtleaders.io  

My Gear ⚙️:  https://kit.co/JoshuaFluke

## BANNED AGAIN - (How EVERYONE can be self employed) #grindreel
 - [https://www.youtube.com/watch?v=jfloMYuPBBI](https://www.youtube.com/watch?v=jfloMYuPBBI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-91UA-Xy2Cvb98deRXuggA
 - date published: 2020-01-18 00:00:00+00:00

❤️ Support me because corporate sponsors rarely do! 
 https://www.patreon.com/joshuafluke

🔥 Need a resume/cover letter? Check out my templates!  
https://grindreel.com/

👊 Join the community! 
https://discord.gg/Joshuafluke

My Other Socials🤳
https://www.tiktok.com/@joshua_fluke
https://www.instagram.com/joshuafluke/  📸
https://twitter.com/joshuafluke  🐦

📧 Email me directly!: grindreel@gmail.com
📧 Business inquiries: Joshuafluke@thoughtleaders.io  

My Gear ⚙️:  https://kit.co/JoshuaFluke

