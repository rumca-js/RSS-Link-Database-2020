# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## The Evolution Of Gears 5's Unlikeliest Hero | Audio Logs
 - [https://www.youtube.com/watch?v=Kd86k4DzWYE](https://www.youtube.com/watch?v=Kd86k4DzWYE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-01-19 00:00:00+00:00

Gears 5's unlikeliest hero isn't Kait Diaz, or even Marcus Fenix, but the little bot that could: JACK. From his origins as a glorified door opener to a character with Pixar-esque complexity, The Coalition's Rod Fergusson discusses how the team embraced inclusive design practices to make JACK not only playable, but a core part of Gears.

Executive Producer: Chris Beaumont
Showrunner: Lucy James
Edited by: Chris Morris
GFX by: Gurkan Erdemli
Additional Production: Tamoor Hussain, Adam Mason
Camera by: Richard Li
Sound by: Jean-Luc Seipke

#Gears5 #RodFergusson #AudioLogs

## How Games Became Obsessed With Nuclear Weapons  - Loadout
 - [https://www.youtube.com/watch?v=j5BZoRCnF9o](https://www.youtube.com/watch?v=j5BZoRCnF9o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-01-18 00:00:00+00:00

The threat of nuclear warfare looms large over our pop culture, from video games like Fallout 3, Metro Exodus and Far Cry: New Dawn, to iconic film franchises like Godzilla and The Terminator. But while nuclear weapons are often the centerpiece of a lot of the movies and games we experience, they remain, in reality, a devastating and immoral force of destruction. So that begs the question: why have we adopted nuclear annihilation as a common setting for our escapism?

## How the World of Dragon Ball Z: Kakarot Replicates the Show
 - [https://www.youtube.com/watch?v=4INhFpxvToY](https://www.youtube.com/watch?v=4INhFpxvToY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-01-18 00:00:00+00:00

(Presented by Bandai Namco) From its nostalgic collectibles to hidden bosses from the past, find out how Dragon Ball Z: Kakarot aims to bring the world of the show to life! Also, look up the pronunciation of ‘Saiyan’ from the original Japanese dub before you call us out!

