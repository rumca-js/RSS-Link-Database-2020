# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## The BEST of VR at CES 2020
 - [https://www.youtube.com/watch?v=lIiZg3aszGk](https://www.youtube.com/watch?v=lIiZg3aszGk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-01-19 00:00:00+00:00

Hello and Welcome to one of the Days newsday, your number one resource for the entire weeks worth of VR news

Sorry its late, but stuff happens.
Join my discord for good times
https://discord.gg/thrill
MY STREAM: 
https://www.twitch.tv/thrilluwu
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill

Things I cover today:
Half Life Alyx leaks:
https://www.videogameschronicle.com/news/new-half-life-alyx-images/
Mark Zuckerberg on the future of VR:
https://www.roadtovr.com/facebook-mark-zuckerberg-ar-vr-telepresence-housing-crisis/
CES for VR;
BHaptics Suit:https://www.bhaptics.com/
TeslaSuit: https://www.roadtovr.com/ces-2020-teslasuit-hands-on-haptics-electic/
Pimax Headsets:
https://www.pimax.com/
Panasonic Video from Upload VR:
https://www.youtube.com/watch?v=0tKumAgOtB8
Xtal 8k Headset:
https://vrgineers.com/vrgineers-at-ces-2020-witness-the-launch-of-xtal-new-generation-with-unbeatable-8k-resolution/

