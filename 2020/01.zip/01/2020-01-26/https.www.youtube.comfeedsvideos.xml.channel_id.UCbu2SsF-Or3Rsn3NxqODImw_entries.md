# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Journey To The Savage Planet Is 2020's First Great Co-Op Game
 - [https://www.youtube.com/watch?v=2W186FbGzus](https://www.youtube.com/watch?v=2W186FbGzus)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-01-27 00:00:00+00:00

Rob Handlery and Jake Dekker explore the wacky world of Journey To The Savage Planet in this video. There are exploding chickens, deadly jellyfish, and lots of slapping. You can pick up Journey To The Savage Planet on Xbox One, PS4, and PC on January 28th.

## Pokemon-Like MMO Temtem Early Access (Let's Try It Again!)
 - [https://www.youtube.com/watch?v=m95suo6ROqo](https://www.youtube.com/watch?v=m95suo6ROqo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-01-27 00:00:00+00:00

#Temtem (a Pokemon-Inspired MMO) saw an early access launch filled with crazy login queues. One week later, we revisit the game to see how things are going.

