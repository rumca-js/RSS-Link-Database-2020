# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Journey to the Savage Planet | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=ypeKSnXu7dI](https://www.youtube.com/watch?v=ypeKSnXu7dI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-01-27 00:00:00+00:00

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Larryn Bell reviews Journey to the Savage Planet, developed by Typhoon Studios.

Journey to the Savage Planet on EGS (also available on PS4 and Xbox One): https://www.epicgames.com/store/en-US/product/journey-to-the-savage-planet/home

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►► https://sharkrobot.com/collections/zero-punctuation 

Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 

Like us on Facebook ►► http://www.facebook.com/EscapistMag

Follow us on Twitter ►► https://twitter.com/EscapistMag

#JourneytotheSavagePlanet

## Why's It So Gosh Darn Hard to Make a DOOM Movie? | UnderDeveloped
 - [https://www.youtube.com/watch?v=2K50hNfFgDc](https://www.youtube.com/watch?v=2K50hNfFgDc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-01-27 00:00:00+00:00

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Doom is a video game about a lone Marine fighting demons from Hell.

Doom: Annihilation is a movie about a group of Marines fighting zombies.

Jack Packard is me, fighting to stay awake while watching it.

Annihilation is another cheap, boring, cash grab video game adaptation that is instantly forgettable and inexcusably deaf to the source material.

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►► https://sharkrobot.com/collections/zero-punctuation 

Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 

Like us on Facebook ►► http://www.facebook.com/EscapistMag

Follow us on Twitter ►► https://twitter.com/EscapistMag

#Doom: Annihilation

