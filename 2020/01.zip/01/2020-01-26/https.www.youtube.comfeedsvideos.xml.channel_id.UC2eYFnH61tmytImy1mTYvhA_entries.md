# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## Brave: The Ideal Browser for both Normies and Neckbeards!
 - [https://www.youtube.com/watch?v=n7lYxXrzbjk](https://www.youtube.com/watch?v=n7lYxXrzbjk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-01-26 00:00:00+00:00

Get Brave: https://brave.com/luk005
It's in the AUR as well.
Yeah people noticed; I fell for the Brave meme: been using it for months and it's actually good. Has tor windows, blocks ads and trackers, FLOSS and gibs you Monopoly money for it. Can you argue with that?

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE NOW: https://lukesmith.xyz/donate 💰😎👌💯

