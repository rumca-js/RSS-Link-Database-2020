# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Panieneczki - Heniuchna live - MUZO.FM
 - [https://www.youtube.com/watch?v=VteRYPaYi_o](https://www.youtube.com/watch?v=VteRYPaYi_o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-01-27 00:00:00+00:00

Panieneczki Heniuchna na żywo w MUZO.FM. Pochodzące z Bydgoszczy neofolkowe Panieneczki od kilku lat pasjonuje historia ziemi kujawskiej. Panieneczki występowały na największych polskich festiwalach, m.in. Open’er Festival, OFF Festival czy Enea Spring Break. Brały też udział w trasie koncertowej Korteza, jako gość specjalny. Grupa Panieneczki ma na koncie dwuczęściową EPkę Opowieści zasłyszane na wiosce. 


Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Panieneczki: http://www.facebook.com/panieneczki
Instagram Panieneczki: http://www.instagram.com/panieneczki
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm 

#popolsku

## sanah - Siebie zapytasz - live MUZO.FM
 - [https://www.youtube.com/watch?v=VJVBL7OKSjI](https://www.youtube.com/watch?v=VJVBL7OKSjI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-01-26 00:00:00+00:00

sanah Siebie zapytasz na żywo w MUZO.FM. Specjalna wersja piosenki sanah Siebie zapytasz pochodzi z wyjątkowej sesji w studiu radia MUZO.FM. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook sanah: http://www.facebook.com/sanahmusic
Instagram sanah: http://www.instagram.com/sanahmusic
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm


sanah - Siebie zapytasz tekst 

zapomniałam gdzie to było
czy się śniło
bo za miło
czekaj może iskrę widać
mmm chwila
ty jakiś taki inny przy niej
może pójdę będzie milej
myślę nawet nie zauważy
taki był czas okrutny
paskudny
złudny
jaka byłam ja głupia
mmm jaka
ty za to jakiś inny w oczach
spoko więcej mnie nie spotkasz
ja się tu już nie pojawię

ty siebie zapytasz
zapytasz się
co ta panna do ciebie ma
przecież to widać
patrzy na ciebie jak ja
nie zapamiętasz
zapamiętasz mnie
dużo panien niebo ci da
ty mnie zapomnisz
zapomnę ciebie i ja

robię się jakaś spięta
śnięta 
szurnięta
trochę inna niż dziewczęta
mmm dziewczęta
bo pannie nie przystoi płakać
gdy tylko w małych tarapatach
niestety czuję taką pozostanę

ty siebie zapytasz
zapytasz się
co ta panna do ciebie ma
przecież to widać
patrzy na ciebie jak ja
nie zapamiętasz
zapamiętasz mnie
dużo panien niebo ci da
ty mnie zapomnisz
zapomnę ciebie i ja

płynie czas pójdę już
do domu
wymknę się cicho po
kryjomu
mogę udawać że 
nie widzisz
lecz na co to komu

ty siebie zapytasz
zapytasz się
co ta panna do ciebie ma
przecież to widać
patrzy na ciebie jak ja
nie zapamiętasz
zapamiętasz mnie
dużo panien niebo ci da
ty mnie zapomnisz
zapomnę ciebie i ja 

#popolsku

