# Source:Ryan George, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ, language:en-US

## Where Those Instagram AR Filters Are Headed
 - [https://www.youtube.com/watch?v=67gE94Fyx7I](https://www.youtube.com/watch?v=67gE94Fyx7I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ
 - date published: 2020-01-27 00:00:00+00:00

Subscribe: http://bit.ly/2wscuFf
Twitter/Instagram: @TheRyanGeorge
I freakin' love these filters! I found out that I'm Ursula from Disney, the Sorting Hat from Harry Potter, and Team Rocket from Pokemon!

 Here's my Amazon "Influencer" link where you'll find all the equipment I use to make these videos! If you buy anything on Amazon through this link (not just items from this equipment list) Amazon gives me a little bit of money! And that lets me buy food for my cats!
https://www.amazon.ca/shop/ryangeorge

