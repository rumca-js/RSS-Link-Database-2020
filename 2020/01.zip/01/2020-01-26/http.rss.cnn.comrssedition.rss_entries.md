# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Jennifer Aniston surprised unsuspecting 'Friends' fans
 - [https://www.cnn.com/videos/entertainment/2020/01/25/jennifer-aniston-surprises-fans-will-ferrell-orig-jk.cnn](https://www.cnn.com/videos/entertainment/2020/01/25/jennifer-aniston-surprises-fans-will-ferrell-orig-jk.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-26 15:57:45+00:00

While hosting "The Ellen DeGeneres Show," Jennifer Aniston surprised "Friends" fans on the Central Perk set and talked to Will Ferrell about his most enduring role as Buddy the Elf.

## The WHO should sound the alarm on Wuhan coronavirus
 - [https://www.cnn.com/2020/01/25/opinions/who-should-sound-alarm-on-coronavirus-bociurkiw/index.html](https://www.cnn.com/2020/01/25/opinions/who-should-sound-alarm-on-coronavirus-bociurkiw/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-26 03:16:02+00:00

As the Wuhan coronavirus continues to spread around the world, the World Health Organization's decision to hold off on declaring the outbreak "a public health emergency of international concern" is baffling.

## Republic Day 2020: Join India's great big constitution party
 - [https://www.cnn.com/travel/article/republic-day-india-2020/index.html](https://www.cnn.com/travel/article/republic-day-india-2020/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-26 02:43:39+00:00

India is the world's largest democracy, and it's serious about its constitution. The country goes all out to celebrate its remarkable achievement in self-governing each Republic Day.

## Death toll rises as healthcare workers say supplies are running out
 - [https://www.cnn.com/2020/01/25/china/wuhan-coronavirus-update-intl-hnk/index.html](https://www.cnn.com/2020/01/25/china/wuhan-coronavirus-update-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-26 02:32:50+00:00

The death toll from the Wuhan coronavirus in China continues rising as authorities and health care workers struggle to contain the outbreak.

## Man charged with human trafficking after police allege he kept sex slave for 5 years
 - [https://www.cnn.com/2020/01/25/us/north-carolina-human-trafficking/index.html](https://www.cnn.com/2020/01/25/us/north-carolina-human-trafficking/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-26 02:00:32+00:00

A North Carolina man is facing a human trafficking charge after police alleged he kept a person in sexual servitude for five years.

## More than 50 people dead from Wuhan coronavirus across mainland China, almost 2,000 cases confirmed, 57 million people facing lockdowns
 - [https://www.cnn.com/asia/live-news/coronavirus-outbreak-hnk-intl-01-26-20/index.html](https://www.cnn.com/asia/live-news/coronavirus-outbreak-hnk-intl-01-26-20/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-26 01:55:48+00:00



## In the camp world of K-pop, it's hard for stars to be gay
 - [https://www.cnn.com/2020/01/25/asia/k-pop-gay-star-intl-hnk/index.html](https://www.cnn.com/2020/01/25/asia/k-pop-gay-star-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-26 01:49:43+00:00

On a brightly lit stage, two male K-pop stars with glowing skin and perfectly coiffed hair are nibbling either end of the same long, chocolate stick.

## Louise Linton sides with Greta Thunberg after husband Steve Mnuchin takes jab at activist
 - [https://www.cnn.com/2020/01/25/politics/steve-mnuchin-louise-linton-greta-thunberg/index.html](https://www.cnn.com/2020/01/25/politics/steve-mnuchin-louise-linton-greta-thunberg/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-01-26 00:34:33+00:00

Treasury Secretary Steve Mnuchin's wife Louise Linton on Saturday showed support for climate activist Greta Thunberg, days after her husband took a jab at the teenager.

