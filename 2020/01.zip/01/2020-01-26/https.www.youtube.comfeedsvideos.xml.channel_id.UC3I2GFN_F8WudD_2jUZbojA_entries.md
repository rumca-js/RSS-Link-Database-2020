# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Sólstafir - Bláfjall (Live on KEXP)
 - [https://www.youtube.com/watch?v=y1sFV32qhMI](https://www.youtube.com/watch?v=y1sFV32qhMI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-27 00:00:00+00:00

http://KEXP.ORG presents Sólstafir performing "Bláfjall" live in the KEXP studio. Recorded October 19, 2019.

Host: Troy Nelson
Audio Engineer: Tom Hall
Cameras: Jim Beckmann, Alaia D'Alessandro & Kendall Rock
Editor: Jim Beckmann

http://kexp.org
https://www.solstafir.net

## Sólstafir - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=ShR4VfpvdBQ](https://www.youtube.com/watch?v=ShR4VfpvdBQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-27 00:00:00+00:00

http://KEXP.ORG presents Sólstafir performing live in the KEXP studio. Recorded October 19, 2019.

Songs:
Silfur refur
Ísafold
Necrologue
Bláfjall

Host: Troy Nelson
Audio Engineer: Tom Hall
Cameras: Jim Beckmann, Alaia D'Alessandro & Kendall Rock
Editor: Jim Beckmann

http://kexp.org
https://www.solstafir.net

## Sólstafir - Ísafold (Live on KEXP)
 - [https://www.youtube.com/watch?v=q-7fJ8JEYJ8](https://www.youtube.com/watch?v=q-7fJ8JEYJ8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-27 00:00:00+00:00

http://KEXP.ORG presents Sólstafir performing "Ísafold" live in the KEXP studio. Recorded October 19, 2019.

Host: Troy Nelson
Audio Engineer: Tom Hall
Cameras: Jim Beckmann, Alaia D'Alessandro & Kendall Rock
Editor: Jim Beckmann

http://kexp.org
https://www.solstafir.net

## Sólstafir - Necrologue (Live on KEXP)
 - [https://www.youtube.com/watch?v=6FvCu5D4jnY](https://www.youtube.com/watch?v=6FvCu5D4jnY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-27 00:00:00+00:00

http://KEXP.ORG presents Sólstafir performing "Necrologue" live in the KEXP studio. Recorded October 19, 2019.

Host: Troy Nelson
Audio Engineer: Tom Hall
Cameras: Jim Beckmann, Alaia D'Alessandro & Kendall Rock
Editor: Jim Beckmann

http://kexp.org
https://www.solstafir.net

## Sólstafir - Silfur refur (Live on KEXP)
 - [https://www.youtube.com/watch?v=aS8eC0V5mYM](https://www.youtube.com/watch?v=aS8eC0V5mYM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-27 00:00:00+00:00

http://KEXP.ORG presents Sólstafir performing "Silfur refur" live in the KEXP studio. Recorded October 19, 2019.

Host: Troy Nelson
Audio Engineer: Tom Hall
Cameras: Jim Beckmann, Alaia D'Alessandro & Kendall Rock
Editor: Jim Beckmann

http://kexp.org
https://www.solstafir.net

## GDRN - Hvað Ef (Live on KEXP)
 - [https://www.youtube.com/watch?v=GVGxQ-f2y28](https://www.youtube.com/watch?v=GVGxQ-f2y28)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-26 00:00:00+00:00

http://KEXP.ORG presents GDRN performing "Hvað Ef" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 7, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://www.facebook.com/pg/GDRNmusic

## GDRN - Komdu yfir (Live on KEXP)
 - [https://www.youtube.com/watch?v=t6_gkJK-qPU](https://www.youtube.com/watch?v=t6_gkJK-qPU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-26 00:00:00+00:00

http://KEXP.ORG presents GDRN performing "Komdu yfir" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 7, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://www.facebook.com/pg/GDRNmusic

## GDRN - Lætur Mig (Live on KEXP)
 - [https://www.youtube.com/watch?v=ugV-UUueZn8](https://www.youtube.com/watch?v=ugV-UUueZn8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-26 00:00:00+00:00

http://KEXP.ORG presents GDRN performing "Lætur Mig" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 7, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://www.facebook.com/pg/GDRNmusic

## GDRN - Treystu mér (Live on KEXP)
 - [https://www.youtube.com/watch?v=QoygQRdczDE](https://www.youtube.com/watch?v=QoygQRdczDE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-26 00:00:00+00:00

http://KEXP.ORG presents GDRN performing "Treystu mér" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 7, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://www.facebook.com/pg/GDRNmusic

## GDRN - Upp (Live on KEXP)
 - [https://www.youtube.com/watch?v=tbT4KJeJUKk](https://www.youtube.com/watch?v=tbT4KJeJUKk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-01-26 00:00:00+00:00

http://KEXP.ORG presents GDRN performing "Upp" live at Kex Hostel in Reykjavik during Iceland Airwaves 2019. Recorded November 7, 2019.

Host: John Richards
Audio Engineers: Onundur Hofsteinn Pálsson, Kevin Suggs & Róbert Högni Þorbjörnsson
Audio Mixer: Kevin Suggs
Cameras: Alaia D'Alessandro, Matt Ogaz & Kendall Rock
Director: Scott Holpainen
Editor: Alaia D'Alessandro

http://kexp.org
https://www.facebook.com/pg/GDRNmusic

