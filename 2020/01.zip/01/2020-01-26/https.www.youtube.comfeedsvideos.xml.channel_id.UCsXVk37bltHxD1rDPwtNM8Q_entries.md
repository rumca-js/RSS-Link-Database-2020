# Source:Kurzgesagt – In a Nutshell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsXVk37bltHxD1rDPwtNM8Q, language:en-US

## Milk. White Poison or Healthy Drink?
 - [https://www.youtube.com/watch?v=oakWgLqCwUc](https://www.youtube.com/watch?v=oakWgLqCwUc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsXVk37bltHxD1rDPwtNM8Q
 - date published: 2020-01-26 00:00:00+00:00

Head over to our shop to get exclusive kurzgesagt merch and sciency products designed with love. 
Getting something from the kurzgesagt shop is the best way to support us and to keep our videos free for everyone. 
►► https://kgs.link/shop-117
(Worldwide Shipping Available)



Sources:
https://sites.google.com/view/sourcesmilk/

Over the last decade milk has become a bit controversial. Some people say it’s a necessary and nutritious food, vital for healthy bones, but others say it can cause cancer and lead to an early death.

So who is right? And why are we drinking it anyway?


OUR CHANNELS
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
German Channel: https://kgs.link/youtubeDE 
Spanish Channel: https://kgs.link/youtubeES 


HOW CAN YOU SUPPORT US?
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
This is how we make our living and it would be a pleasure if you support us!

Get Merch designed with ❤ from https://kgs.link/shop-117  
Join the Patreon Bird Army 🐧 https://kgs.link/patreon  


DISCUSSIONS & SOCIAL MEDIA
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
Reddit:            https://kgs.link/reddit
Instagram:     https://kgs.link/instagram
Twitter:           https://kgs.link/twitter
Facebook:      https://kgs.link/facebook
Discord:          https://kgs.link/discord
Newsletter:    https://kgs.link/newsletter


OUR VOICE
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
The Kurzgesagt voice is from 
Steve Taylor:  https://kgs.link/youtube-voice


OUR MUSIC ♬♪
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
700+ minutes of Kurzgesagt Soundtracks by Epic Mountain:

Spotify:            https://kgs.link/music-spotify
Soundcloud:   https://kgs.link/music-soundcloud
Bandcamp:     https://kgs.link/music-bandcamp
Youtube:          https://kgs.link/music-youtube
Facebook:       https://kgs.link/music-facebook

The Soundtrack of this video:

Soundcloud: https://bit.ly/2tDtHA1
Bandcamp: https://bit.ly/2Gg8crD
Youtube: https://bit.ly/2CZ6PeN
Facebook: http://bit.ly/2qW6bY4 


🐦🐧🐤 PATREON BIRD ARMY 🐤🐧🐦
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
Many Thanks to our wonderful Patreons from http://kgs.link/patreon who support us every month and made this video possible:

Keelan Rose, Devesh Dhole, Olof Pettersson, Hung Doan, Amelia Puteri, Michele Brusutti, Dan Mangiarelli, Benjamin Lambert, Tom, Masoom Kumar, Abdulrahman Aljurbua, Nathan Benton, Evan Viljoen, Rahul Razdan, Benjamin LaCara, Simon Navarro, Mario Hermes, Chloé Nicole, Håvard Skjold, Deon Naude, FloweroftheForest, Finn Fleischer, Ron Kakar, Iryan, Chris W., Dominic Nadeau, Sriram Kannan, Guy Butler, Titus Taylor, Baraka Peterman, Rob Bos, Andrew McCandliss, Kathryn Meyer, Marty Galinskas, Itay Levi, Kyle Smith, Lara, James Wood, Erik Welander, Arklur, Sören, Dennis Swiercinsky, Ike Saunders, Filippo Cona, Vancey Le, Pavel Schweizer, Igor Petrushevskiy, Goran Niksic, Richard Hai, Ellis Choy, Jason Meredith, Jack Bennett, nathan hatfield, Edward Liu, Matthew Hwang, Joseph Siler, Jonathan Schultz, Sterling Bates, Shiran, Billy Jameson, Raanan Fickler, Simon Marois, Jared, Luca Privitera, Andrew Hodgson, Alex Moore, Domiepotato, Jason Seah, Luca Steeb, Eddie Pettis, Adolfo Puertas, Tobias Henriksson, Hugo Leonardi, Leo August, Alex Denor, David Platte, Jean-Manuel Izaret, Rico Jasper, Tyler Mckenna, Jayson Domingo, Kevin Stoodt, Moritz Hegmann, Alex Paden, Bread Bread, Dan, George Papadopoulos, Ben Patterson, Ahmed Elmesmary, Theoldfiend ., Vincent Dinger, Realistic Management, Mike H, SUBSCOPE, hb0, Dayan, Steven Paz, Ralph, John Underwood, Cory Matt, Heytun, Simon Sardeson-Coe, YILDIZ KABARAN, Henry Furman, es

