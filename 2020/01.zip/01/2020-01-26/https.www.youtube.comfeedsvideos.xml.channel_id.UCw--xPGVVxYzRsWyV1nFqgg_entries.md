# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## The Dark Tower Broke Me
 - [https://www.youtube.com/watch?v=fP_0qLSZbzg](https://www.youtube.com/watch?v=fP_0qLSZbzg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-01-27 00:00:00+00:00

I was Broken By Stpehen King's The Dark Tower. Here are my thoughts/Review!
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene
 
P.O. Box 1016 Dublin, Ohio 43017
with the backup of:
715 Shawan falls Dr. Dublin, Ohio 43017

