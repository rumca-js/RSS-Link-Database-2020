# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## I can use your help with a last minute write-up.
 - [https://www.youtube.com/watch?v=MJ7a7JZWBoI](https://www.youtube.com/watch?v=MJ7a7JZWBoI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-01-27 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545

## John Deere dealerships are lobbying AGAINST right to repair. Farmers, please help me out here.
 - [https://www.youtube.com/watch?v=38O1zEuLOMM](https://www.youtube.com/watch?v=38O1zEuLOMM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-01-27 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
FARMERS: I realize you do not HAVE TIME to show up at these hearings. If you are open to emailing me and taking the time to educate me as to why these arguments the John Deere dealerships give are bad, I will happily advocate on your behalf every chance I get. I promise I will not let you down. email is louis@rossmanngroup.com  Thank you.

## Let's have a robust conversation about one of my FAVORITE new websites. 😃
 - [https://www.youtube.com/watch?v=zyesJQ3lsto](https://www.youtube.com/watch?v=zyesJQ3lsto)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-01-27 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
🔵 We fix Macbooks & offer free estimates. https://rossmanngroup.com
🔵 Send us your Macbook for repair! http://bit.ly/sendmacbook
🔵 We'll send you a box with a pre-paid shipping label for your repair! http://bit.ly/sendyourmacbook
🔵 We offer iPhone data recovery: http://bit.ly/2BDBX4G
🔵 We offer lab hard drive data recovery: http://bit.ly/labdatarecovery

👉 LEARN HOW TO DO THIS:
› In-person classes: https://bit.ly/classrg
› Beginner's guide: http://bit.ly/2k6uz84
› Support forum: $29/mo http://bit.ly/boardrepairforum

👉 Donate & post a message: http://bit.ly/postamessage 

👉 Below we list tools & recording gear we use, repair guides to help you learn, online chip sources, & donation links:

👉 BlackBerry, Oreo, & Clinton the cat's wish list: https://www.amazon.com/hz/wishlist/ls/2YC1L66N7T5BC?&sort=default

👉 CHIPS & COMPONENTS:
› http://bit.ly/2jaAOXM

👉 Discord: https://tinyurl.com/rossmatrix

👉 TOOLS USED:

✓ Soldering Irons:
› Louis' Hakko station(no tweezers): http://amzn.to/2cKkMyO 
› Paul's Hakko station(works with tweezers): http://amzn.to/2yMvWNy
› Micro Soldering Pencil: http://amzn.to/2d5MWUP
› Hot tweezers: http://amzn.to/2yMvZsZ
› Quick 861DW hot air station: https://bit.ly/atten862

✓ CHEAP HAKKO ALTERNATIVES:
› TS100 soldering iron: https://amzn.to/2Gy1Fqz
› Recommended tips: TS-C4: https://amzn.to/2GSDoz3 TS-KU https://amzn.to/2Elofke

✓ Preferred Soldering Tips
› Fine: http://amzn.to/2d5MgPn 
› Flat: https://amzn.to/2JnsDBT 
› GPU wicking: http://amzn.to/2w8chtB
› Micro soldering tip: http://amzn.to/2qUSFDh

✓ Microscopes:
› Microscope: http://amzn.to/2iLrE16 
› Barlow lens: http://amzn.to/2yMKdKf
› LED light: http://amzn.to/2nzfPT2
› CHEAP alternative microscope: http://amzn.to/2rTlHbj

✓ Soldering/Repair Supplies:
› Solder: http://amzn.to/2cKkxUp
› Desoldering braid: http://bit.ly/2otflOX
› Flux: http://bit.ly/amtechflux
› Solder paste: http://bit.ly/amtechsolderpaste
› THICK insulated jumper wire: https://amzn.to/2rvtD0A
› THIN insulated jumper wire: https://amzn.to/2I47DQY
› Kapton tape: http://amzn.to/2yN0xuq
› Tweezers: http://amzn.to/2d5NBpi
› Blades: http://amzn.to/2ByWnvF
› Freeze Spray: http://amzn.to/2BySozw
› Conformal coating: http://bit.ly/greencoate
› Conformal coating curing pen: http://bit.ly/uvpen

✓ Diagnostic tools:
› USB amp meter: http://bit.ly/2B2Lu5W
› USB-C amp meter: http://bit.ly/usbcamp
› On-Screen multimeter: http://amzn.to/2jtgY9K 
› Multimeter Probes: http://bit.ly/fineprobes
› CHEAP multimeter: http://amzn.to/2zjkg8U
› Bench PSU: CSI3005P http://bit.ly/benchsupply
› Phoneboard: https://phoneboard.co

✓ Ultrasonic Cleaning:
› ALL MACBOOKS & CELLPHONES: Crest P1200H-45: http://bit.ly/P1200H45
› PRE-TOUCHBAR MACBOOKS & CELLPHONES: Crest P500H-45: http://bit.ly/P500H45
› CELLPHONES ONLY: Crest P230H-45: http://bit.ly/P230H45 
› Branson EC cleaning fluid: http://amzn.to/2cKlBrp

✓ Desk supplies:
› Desk: http://amzn.to/2yMShdZ
› Chair: https://amzn.to/2LB8bUB
› Fume Extractor: http://amzn.to/2d5MGoD
› Work mat: http://amzn.to/2yMtlTR
› Outlets: http://amzn.to/2yNsZwo
› Gloves: http://amzn.to/2iUfumS
› Durable lightning cable: http://amzn.to/2yNHzUt
› Fine tipped snippers: http://amzn.to/2HGt4XB

✓ Screwdrivers: 
› iPhone bottom screw: http://amzn.to/2yNwX8p
› Macbook bottom screw: http://amzn.to/2AKMdVb
› Torx T3: http://amzn.to/2zjtxxH
› Torx T5 http://amzn.to/2BLNDn4
› Torx T6 http://amzn.to/2B0XIfA
› Torx T8 http://amzn.to/2CpWp68
› Phillips #0: http://amzn.to/2AJaHhM
› Phillips #000: http://amzn.to/2yNqsCl

✓ Boardview software: https://pldaniels.com/flexbv/

✓ RECORDING EQUIPMENT:
› Work cam: https://amzn.to/2QjHnt0
› Overhead cam: http://amzn.to/2eAH0oT
› Work mic: https://amzn.to/2WGIhzw
› Home mic: https://amzn.to/2xfampC
› Microscope camera: http://amzn.to/2icVQoG - mine is DISCONTINUED, closest one I can find. 
› HDMI capture: http://amzn.to/2iyGcle

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com

👉 Leave a tip for us via cryptocurrency if we've helped you out:
› Credit card: http://bit.ly/postamessage
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

## Louis' ex employee's take on right to repair
 - [https://www.youtube.com/watch?v=4mdEJCbjMjU](https://www.youtube.com/watch?v=4mdEJCbjMjU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-01-27 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
subscribe to Sunny - https://www.youtube.com/watch?v=GPl78IEVfzQ

## CTIA testifies AGAINST right to repair at Maine Legislature.
 - [https://www.youtube.com/watch?v=Mjsann_Efhc](https://www.youtube.com/watch?v=Mjsann_Efhc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-01-26 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
The chair of the committee announced this was a public hearing that was being recorded and livestreamed several times before and throughout the hearing: listen to that announcement here. https://www.youtube.com/watch?v=sPQ7bM0DOMc&feature=youtu.be There is NO expectation of privacy here. 

Lisa McCabe is a registered lobbyist: https://nebraskalegislature.gov/lobbyist/view.php?link=view_lobbyist&id=3568 attending a public hearing at a state legislature that anyone is free to attend, and record. You are required to state your full name and company affiliation for the record. There is no expectation of privacy here. 

Lobbyists are required to register themselves in many states if they are taking part in paid lobbying efforts on behalf of corporate interests in databases that are openly available and viewable by the general public. There is no expectation of privacy as a corporate lobbyist. 

The law does not allow for expectation of privacy in these hearings - neither should YouTube. 

This recording is of a public hearing at a government legislature where open testimony is given in front of senators. Lisa McCabe is a paid lobbyist for CTIA speaking against this bill: http://legislature.maine.gov/legis/bills/getPDF.asp?paper=SP0679&item=1&snum=129

I believe that censoring the identity of a paid corporate lobbyist speaking in a public forum against consumer rights hurts the democratic process. To remove this content goes against the spirit of laws regarding lobbying. What is the point of requiring public registration of paid corporate lobbyists and identification in a public forum if it is going to be censored once it reaches the news?

## ESA's Kathryn Gunter says Right to Repair will pick digital locks, then says they're already picked.
 - [https://www.youtube.com/watch?v=KAVp1WVq-1Q](https://www.youtube.com/watch?v=KAVp1WVq-1Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-01-26 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
👉 Thank you to everyone who has contributed, even a cent, to helping me in my journalistic efforts to travel around the country, record hearings, and lobby at them. 
🔵 Patreon https://www.patreon.com/rossmanngroup
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

## RIP Louis' first real lens - 2014-2020. ⚰️ Cause of death - TSA 😞
 - [https://www.youtube.com/watch?v=ASlpEq5igVw](https://www.youtube.com/watch?v=ASlpEq5igVw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-01-26 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
SELP18200 Lens: https://amzn.to/30QN84o
NEX-EA50 camcorder: https://www.amazon.com/Sony-NEX-EA50UH-Professional-Discontinued-Manufacturer/dp/B009GKRQF2

## The ESA broke my brain with this awful testimony from Kathryn Gunter
 - [https://www.youtube.com/watch?v=gxACAvHMSLU](https://www.youtube.com/watch?v=gxACAvHMSLU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-01-26 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
🔵 We fix Macbooks & offer free estimates. https://rossmanngroup.com
🔵 Send us your Macbook for repair! http://bit.ly/sendmacbook
🔵 We'll send you a box with a pre-paid shipping label for your repair! http://bit.ly/sendyourmacbook
🔵 We offer iPhone data recovery: http://bit.ly/2BDBX4G
🔵 We offer lab hard drive data recovery: http://bit.ly/labdatarecovery

👉 LEARN HOW TO DO THIS:
› In-person classes: https://bit.ly/classrg
› Beginner's guide: http://bit.ly/2k6uz84
› Support forum: $29/mo http://bit.ly/boardrepairforum

👉 Donate & post a message: http://bit.ly/postamessage 

👉 Below we list tools & recording gear we use, repair guides to help you learn, online chip sources, & donation links:

👉 BlackBerry, Oreo, & Clinton the cat's wish list: https://www.amazon.com/hz/wishlist/ls/2YC1L66N7T5BC?&sort=default

👉 CHIPS & COMPONENTS:
› http://bit.ly/2jaAOXM

👉 Discord: https://tinyurl.com/rossmatrix

👉 TOOLS USED:

✓ Soldering Irons:
› Louis' Hakko station(no tweezers): http://amzn.to/2cKkMyO 
› Paul's Hakko station(works with tweezers): http://amzn.to/2yMvWNy
› Micro Soldering Pencil: http://amzn.to/2d5MWUP
› Hot tweezers: http://amzn.to/2yMvZsZ
› Quick 861DW hot air station: https://bit.ly/atten862

✓ CHEAP HAKKO ALTERNATIVES:
› TS100 soldering iron: https://amzn.to/2Gy1Fqz
› Recommended tips: TS-C4: https://amzn.to/2GSDoz3 TS-KU https://amzn.to/2Elofke

✓ Preferred Soldering Tips
› Fine: http://amzn.to/2d5MgPn 
› Flat: https://amzn.to/2JnsDBT 
› GPU wicking: http://amzn.to/2w8chtB
› Micro soldering tip: http://amzn.to/2qUSFDh

✓ Microscopes:
› Microscope: http://amzn.to/2iLrE16 
› Barlow lens: http://amzn.to/2yMKdKf
› LED light: http://amzn.to/2nzfPT2
› CHEAP alternative microscope: http://amzn.to/2rTlHbj

✓ Soldering/Repair Supplies:
› Solder: http://amzn.to/2cKkxUp
› Desoldering braid: http://bit.ly/2otflOX
› Flux: http://bit.ly/amtechflux
› Solder paste: http://bit.ly/amtechsolderpaste
› THICK insulated jumper wire: https://amzn.to/2rvtD0A
› THIN insulated jumper wire: https://amzn.to/2I47DQY
› Kapton tape: http://amzn.to/2yN0xuq
› Tweezers: http://amzn.to/2d5NBpi
› Blades: http://amzn.to/2ByWnvF
› Freeze Spray: http://amzn.to/2BySozw
› Conformal coating: http://bit.ly/greencoate
› Conformal coating curing pen: http://bit.ly/uvpen

✓ Diagnostic tools:
› USB amp meter: http://bit.ly/2B2Lu5W
› USB-C amp meter: http://bit.ly/usbcamp
› On-Screen multimeter: http://amzn.to/2jtgY9K 
› Multimeter Probes: http://bit.ly/fineprobes
› CHEAP multimeter: http://amzn.to/2zjkg8U
› Bench PSU: CSI3005P http://bit.ly/benchsupply
› Phoneboard: https://phoneboard.co

✓ Ultrasonic Cleaning:
› ALL MACBOOKS & CELLPHONES: Crest P1200H-45: http://bit.ly/P1200H45
› PRE-TOUCHBAR MACBOOKS & CELLPHONES: Crest P500H-45: http://bit.ly/P500H45
› CELLPHONES ONLY: Crest P230H-45: http://bit.ly/P230H45 
› Branson EC cleaning fluid: http://amzn.to/2cKlBrp

✓ Desk supplies:
› Desk: http://amzn.to/2yMShdZ
› Chair: https://amzn.to/2LB8bUB
› Fume Extractor: http://amzn.to/2d5MGoD
› Work mat: http://amzn.to/2yMtlTR
› Outlets: http://amzn.to/2yNsZwo
› Gloves: http://amzn.to/2iUfumS
› Durable lightning cable: http://amzn.to/2yNHzUt
› Fine tipped snippers: http://amzn.to/2HGt4XB

✓ Screwdrivers: 
› iPhone bottom screw: http://amzn.to/2yNwX8p
› Macbook bottom screw: http://amzn.to/2AKMdVb
› Torx T3: http://amzn.to/2zjtxxH
› Torx T5 http://amzn.to/2BLNDn4
› Torx T6 http://amzn.to/2B0XIfA
› Torx T8 http://amzn.to/2CpWp68
› Phillips #0: http://amzn.to/2AJaHhM
› Phillips #000: http://amzn.to/2yNqsCl

✓ Boardview software: https://pldaniels.com/flexbv/

✓ RECORDING EQUIPMENT:
› Work cam: https://amzn.to/2QjHnt0
› Overhead cam: http://amzn.to/2eAH0oT
› Work mic: https://amzn.to/2WGIhzw
› Home mic: https://amzn.to/2xfampC
› Microscope camera: http://amzn.to/2icVQoG - mine is DISCONTINUED, closest one I can find. 
› HDMI capture: http://amzn.to/2iyGcle

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com

👉 Leave a tip for us via cryptocurrency if we've helped you out:
› Credit card: http://bit.ly/postamessage
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

## What pisses me off about lobbyists in the United States.
 - [https://www.youtube.com/watch?v=cHQYyYSZdvQ](https://www.youtube.com/watch?v=cHQYyYSZdvQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-01-26 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
The citations at 12:50 in the video for the farm equipment dealers & AT&T lobbyist paying off senators can be found at followthemoney.org , the part starting at 12:40 is the most important part of this video if you want a TL;DR 

👉 Thank you to everyone who has contributed, even a cent, to helping me in my journalistic efforts to travel around the country, record hearings, and lobby at them. 
🔵 Patreon https://www.patreon.com/rossmanngroup
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

