# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Star Trek Picard - Episode 1 Review
 - [https://www.youtube.com/watch?v=A2XrkuexUaY](https://www.youtube.com/watch?v=A2XrkuexUaY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-01-27 00:00:00+00:00

Set phasers to stunning as I review the first episode of Star Trek Picard, "Remembrance".

