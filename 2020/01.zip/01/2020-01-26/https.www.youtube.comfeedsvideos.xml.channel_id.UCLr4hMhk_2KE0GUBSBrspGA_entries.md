# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week #1: Koronawirus - to wcale nie jest śmieszne. Okulary Mutrics, kamera Insta360
 - [https://www.youtube.com/watch?v=HyepapgbofQ](https://www.youtube.com/watch?v=HyepapgbofQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-01-26 00:00:00+00:00

Ale czy kiedykolwiek było? 
Insta: http://bit.ly/InstaKlawiatur

Tłumaczenie: www.locatheart.com

Źródła:
Strona do śledzenia Koronawirusa: http://bit.ly/2von19i
Kamery do rozpoznawania twarzy w Londynie: http://bit.ly/2S3HO9Z
Robot bez nóg: https://cnet.co/2t2J0So
Bose zamyka sklepy stacjonarne: http://bit.ly/38GPGVn
Grające okulary: http://bit.ly/37uZOjZ
Kamera Insta360 Twin edition: http://bit.ly/2QHldQJ
Dron jajo 2: http://bit.ly/2ROfOa0
Aplikacja do robienia zdjęć 3D: http://bit.ly/2RMLdJY

