# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## Is Algae The Fuel Of The Future? | Answers With Joe
 - [https://www.youtube.com/watch?v=xwHdl2cD5bk](https://www.youtube.com/watch?v=xwHdl2cD5bk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2020-01-27 00:00:00+00:00

Get 2 months of CuriosityStream for free when you sign up at http://www.curiositystream.com/joescott

Algae biofuels have been touted as the fuel of the future. They lock away carbon, grow very fast and everywhere, and produce a lot of oil. So why hasn't it taken off yet?

Support me on Patreon!
http://www.patreon.com/answerswithjoe

Become a member!
https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Get cool nerdy t-shirts at
http://www.answerswithjoe.com/shirts

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

https://www.greentechmedia.com/articles/read/lessons-from-the-great-algae-biofuel-bubble

https://www.power-technology.com/features/algal-biofuels-challenges-opportunities/

https://www.americanscientist.org/article/making-biofuel-from-microalgae

Algae-powered building
https://www.fastcompany.com/3033019/this-algae-powered-building-actually-works

