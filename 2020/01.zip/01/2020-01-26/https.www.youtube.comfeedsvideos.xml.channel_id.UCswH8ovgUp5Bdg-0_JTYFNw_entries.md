# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## What Are We Supposed To Do Now?
 - [https://www.youtube.com/watch?v=lRQqz4r_598](https://www.youtube.com/watch?v=lRQqz4r_598)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-01-27 00:00:00+00:00

This is an excerpt from my free 12-Day Recovery Course - it finished a few days ago but you can still get the discounted version here: https://www.onecommune.com/a/20323/cGftrerE 

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

## Behind The Scenes with Steven Tyler, Aerosmith & MusiCares!
 - [https://www.youtube.com/watch?v=APi2gcUdOrs](https://www.youtube.com/watch?v=APi2gcUdOrs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-01-26 00:00:00+00:00

I hosted this year's Grammy's MusiCares event honour Aerosmith! 
MusiCares are a charity that help musicians and artists in need of support and help, they have done a lot of work for those with addiction issues and in recovery - check 'em out https://www.grammy.com/musicares

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

