# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Top 10 NEW Games of February 2020
 - [https://www.youtube.com/watch?v=GmJWSWEqDoo](https://www.youtube.com/watch?v=GmJWSWEqDoo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-01-27 00:00:00+00:00

February 2020 is shaping up to be a quiet month, but there's still a few games worth considering on PC, PS4, Xbox One, Nintendo Switch, and more. 
Subscribe for more: http://youtube.com/gameranxtv

#10 Monster Energy Supercross 3

Platform: PlayStation 4, Xbox One, Switch, PC)

Release date: February 4



#9 Zombie Army 4: Dead War

Platform: Win, PS4, XBO

Release date: FEB 4, 2020



#8 Darksiders Genesis

Platform: NS, PS4, XBO

Release date: FEB 14, 2020



#7 Stoneshard

Platform: PC

Release date:FEB 7, 2020



#6 The Dark Crystal: Age of Resistance Tactics

Platform: Win, Mac, NS, PS4, XBO

Release date:FEB 4, 2020



#5 Two Point Hospital

Platform: PlayStation 4, Xbox One, Switch

Release date: February 25, 2020



#4 Mega Man Zero/ZX Legacy Collection

Platform: PlayStation 4, Nintendo Switch, PC, Xbox One

Release date: February 25, 2020



#3 Street Fighter V: Champion Edition

Platform: Win, PS4

Release date: FEB 14, 2020



#2 One-Punch Man: A Hero Nobody Knows

Platform: PlayStation 4, Xbox One, Microsoft Windows

Release date: FEB 27, 2020



#1 DREAMS

Platform: PS4

Release date: FEB 14, 2020



BONUS

Hunt: Showdown

Platform: PS4

Release date: February 18, 2020

## Why Do People CHEAT In Video Games?
 - [https://www.youtube.com/watch?v=w8O3_7mLPuQ](https://www.youtube.com/watch?v=w8O3_7mLPuQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-01-26 00:00:00+00:00

Cheating and hacking in gaming is widespread, but why does it happen? Who does it? Let's dive in.
Subscribe for more: http://youtube.com/gameranxtv

