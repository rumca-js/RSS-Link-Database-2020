# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Best of the Week - January 19, 2020 - Joe Rogan Experience
 - [https://www.youtube.com/watch?v=Hag-qNs8YY8](https://www.youtube.com/watch?v=Hag-qNs8YY8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-01-26 00:00:00+00:00

Best of the Week - January 19, 2020

#1415 w/Bari Weiss:
https://www.youtube.com/watch?v=nL-YwrjKqZU

#1416 w/Rob Kearney:
https://www.youtube.com/watch?v=74TaVlSuipo

#1417 w/Kevin Ross:
https://www.youtube.com/watch?v=XiWYB_xTd9k

#1418 w/Don Gavin:
https://www.youtube.com/watch?v=vPDRlhgblZg

JRE MMA Show #86 w/Josh Thomson;
https://www.youtube.com/watch?v=8zkXLwBnORg

