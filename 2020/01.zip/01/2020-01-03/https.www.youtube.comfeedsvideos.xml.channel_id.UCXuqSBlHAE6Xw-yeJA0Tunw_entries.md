# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## SIXTEEN Cores for the Price of EIGHT!
 - [https://www.youtube.com/watch?v=IqJoMdxT7XI](https://www.youtube.com/watch?v=IqJoMdxT7XI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-01-04 00:00:00+00:00

Get an unrestricted 30-day free trial of FreshBooks at https://www.freshbooks.com/techtips

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire

You can get SO MANY MORE cores for your money with this one product... but should you try it?

Buy Intel Xeon processors on Amazon (PAID LINK): https://geni.us/1HEe6Ts

Get this motherboard on Aliexpress: https://geni.us/Gc9PU

Buy Noctua NH-U12s on Amazon (PAID LINK): https://geni.us/9arXgs

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1141888-sixeteen-cores-for-the-price-of-eight/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

## Apple's $5000 Gaming PC? - WAN Show Jan 3, 2020
 - [https://www.youtube.com/watch?v=c7k-5orDn6k](https://www.youtube.com/watch?v=c7k-5orDn6k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-01-03 00:00:00+00:00

Save 15% today with offer code LTT on Displate at https://lmg.gg/displatewan

Visit https://www.squarespace.com/WAN and use offer code WAN for 10% off

Learn more about the Viewsonic Gaming Elite Series monitor at https://bit.ly/2CYkPWz or buy it on Amazon (paid link) at https://geni.us/BNbSU7 

LTX2020, Save the Date - August 8+9, 2020 - https://www.ltxexpo.com/

Check out Carpool Critics, our new movie podcast: http://carpoolcritics.libsyn.com/

Podcast Download: http://traffic.libsyn.com/linustechtips/Apples_5000_Gaming_PC_-_WAN_Show_Jan_3_2020.mp3

Timestamps: (Courtesy of 1littlelee)

3:20 Apple's gaming computer
12:23 Apple's gaming computer Specs
16:36 Apples Gaming Computer Peripherals
22:07 - LTT store RAM, processor T-shirts in stock
22:45 - CES Team T-Shirts
25:16 - New California Consumer Privacy Act
35:34 - T-Shirt Poll Results
36:14 - SPONSOR SPACE - Squarespace.com
37:27 - SPONSOR SPACE - Displate
38:25 - SPONSOR SPACE - Viewsonic
39:15 - Lukes Keyboard broke
41:27 - LTX 2020 - August 8-9 (Vancouver Conference center)
43:20 - Carpool critics - podcast
45:47 - Star Wars Rise of the Skywalker - Talk
55:29 - Segway chair
57:10 - Superchat read

## I deliberately downloaded ransomware… - Acronis True Image 2020 Showcase
 - [https://www.youtube.com/watch?v=cg4rfeX4m_E](https://www.youtube.com/watch?v=cg4rfeX4m_E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-01-03 00:00:00+00:00

Thanks to Acronis for sponsoring today's video! Get Acronis True Image 2020 40% off with offer code Linus2020 at https://go.acronis.com/linus2020 (expires Jan 16/20)

Ransomware is one of the biggest cyber threats today, and we're going to show you just how easy it is to get infected… by getting infected!

Have questions on Acronis? Check out https://reddit.com/r/Acronis

Buy Laptops
On Amazon (PAID LINK): https://geni.us/M2dnU
On Newegg (PAID LINK): https://lmg.gg/RXQKl

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1141540-i-deliberately-downloaded-ransomware%E2%80%A6-acronis-true-image-2020-showcase/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

