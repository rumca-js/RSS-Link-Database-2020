# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Why The Witcher 3: Wild Hunt is Nate's Game of the Decade | The Joy of  Gaming
 - [https://www.youtube.com/watch?v=1II_vEg5ZY8](https://www.youtube.com/watch?v=1II_vEg5ZY8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-01-04 00:00:00+00:00

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

The decade is over and Nate takes some time to look back at The Witcher 3: Wild Hunt and why it's his personal game of the decade.

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►► https://sharkrobot.com/collections/zero-punctuation 

Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 

Like us on Facebook ►► http://www.facebook.com/EscapistMag

Follow us on Twitter ►► https://twitter.com/EscapistMag

#TheWitcher3WildHunt

## Yahtzee and Kess Play A Hat in Time | Stream Archive
 - [https://www.youtube.com/watch?v=ofDw4-o9yHU](https://www.youtube.com/watch?v=ofDw4-o9yHU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-01-04 00:00:00+00:00

We play a good game that I like because it's nice. It's just NICE, OKAY.

Want in on the chat? Come join us on Twitch: https://www.twitch.tv/escapistmagazine

