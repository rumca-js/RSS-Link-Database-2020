# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## How Aliens’ Iconic Pulse Rifle Was Created  - Loadout
 - [https://www.youtube.com/watch?v=zDIPuP7T64Q](https://www.youtube.com/watch?v=zDIPuP7T64Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-01-04 00:00:00+00:00

Few fictional weapons are as iconic and influential as the Pulse Rifle. First seen in James Cameron’s 1986 sci-fi blockbuster, Aliens, the M41A has undeniably become a cornerstone of pop culture. Its sleek futuristic design has influenced everything from the armoury of Halo to the prototype weaponry of the US military, and the rifle has appeared in a range of video games including Alien Versus Predator and Aliens: Colonial Marines. But how was this sci-fi icon created? Watch and find out.

Thank you to Jonathan Ferguson, Keeper of Firearms & Artillery, as well as the Royal Armouries museum (https://www.youtube.com/user/RoyalArmouries/) for helping make this video happen.

## Free PS4 PlayStation Plus Games For January 2020 Revealed
 - [https://www.youtube.com/watch?v=bcRPW9HMsxI](https://www.youtube.com/watch?v=bcRPW9HMsxI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-01-03 00:00:00+00:00

The free PS Plus games for January 2020 have been announced. PS4 players can start the new year off right with Uncharted: The Nathan Drake Collection, which includes the first three games in the series: Drake's Fortune, Among Thieves, and Drake's Deception. PS4's other free January game is Goat Simulator.

## Grand Theft Auto V Comes To Xbox Game Pass | GameSpot Live
 - [https://www.youtube.com/watch?v=dZnsR0A0aVg](https://www.youtube.com/watch?v=dZnsR0A0aVg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-01-03 00:00:00+00:00

GTA V has officially come to Xbox Game Pass which means we absolutely had to boot it up and relive the 2013 magic that has never ended in San Andreas.

