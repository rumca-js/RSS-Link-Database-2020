# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## BIGGEST SURPRISES OF THE LAST DECADE
 - [https://www.youtube.com/watch?v=8KtWW5e1Nbg](https://www.youtube.com/watch?v=8KtWW5e1Nbg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-01-04 00:00:00+00:00

Games always have a way of surprising us. It's sometimes a bigger surprise, though - not to give too much away! Here's some of the times Gameranx really got shocked.
Subscribe for more: http://youtube.com/gameranxtv

