# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## The Grudge - Movie Review
 - [https://www.youtube.com/watch?v=d5c-doEr9Ic](https://www.youtube.com/watch?v=d5c-doEr9Ic)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-01-04 00:00:00+00:00

Look, it's a horror movie released in January, so let's get through this and hopefully have some fun talking about it. Here's my review for the 2020 THE GRUDGE

#TheGrudge

