# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## THE SWORD OF KAIGEN - REVIEW
 - [https://www.youtube.com/watch?v=2pqwa1u_v2M](https://www.youtube.com/watch?v=2pqwa1u_v2M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-01-04 00:00:00+00:00

My review of The Sword Of Kaigen by M L Wang. The future of the fantasy genre? 
Get the book: https://amzn.to/36otazM
SPFBO: http://mark---lawrence.blogspot.com/2019/06/spfbo-5-phase-1.html

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene
 
P.O. Box 1016 Dublin, Ohio 43017
with the backup of:
715 Shawan falls Dr. Dublin, Ohio 43017

## HIS DARK MATERIALS - REVIEW
 - [https://www.youtube.com/watch?v=ifMqW4tYbo4](https://www.youtube.com/watch?v=ifMqW4tYbo4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-01-03 00:00:00+00:00

My review of the BBC / HBO's adaptation of Philip Pullman's His Dark Materials. 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

