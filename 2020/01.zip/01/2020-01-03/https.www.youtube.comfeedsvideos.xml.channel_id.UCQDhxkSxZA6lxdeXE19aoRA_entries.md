# Source:Hugh Jeffreys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA, language:en-US

## The Unrepairable iPod Touch
 - [https://www.youtube.com/watch?v=GTcYP_WcG-g](https://www.youtube.com/watch?v=GTcYP_WcG-g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA
 - date published: 2020-01-04 00:00:00+00:00

Known for its hard to repair design, what makes the iPod so hard to repair and will Hugh be able to fix his?
--------------------------------------Socials-------------------------------------
Twitter: https://twitter.com/hughjeffreys
Instagram: http://instagram.com/hughjeffreys
------------------------------iFixit Tools Used------------------------------
Get parts, tools, and free repair guides from iFixit at  
               iFixit.com/hughjeffreys 
Australia Store: https://ifix.gd/2FPxhKy



DISCLAIMER: This video and description contains affiliate links, which means that if you click on one of the product links, l will receive a small commission.

