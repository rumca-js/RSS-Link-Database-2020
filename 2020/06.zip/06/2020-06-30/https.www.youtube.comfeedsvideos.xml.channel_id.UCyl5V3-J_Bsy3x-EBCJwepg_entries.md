# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Navy SEALs To Be Replaced With Social Workers
 - [https://www.youtube.com/watch?v=S-10tnWwtwM](https://www.youtube.com/watch?v=S-10tnWwtwM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-07-01 00:00:00+00:00



## Growing Up Hinn: The Costi Hinn Interview
 - [https://www.youtube.com/watch?v=uFBKUtq2W-U](https://www.youtube.com/watch?v=uFBKUtq2W-U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-06-30 00:00:00+00:00

Today on The Babylon Bee Podcast, Kyle and Ethan talk to Costi Hinn, nephew of notorious faith healer Benny Hinn. After leaving that ministry behind, Costi Hinn is now a pastor at Redeemer Bible Church in Gilbert, Arizona. He is the author of God, Greed, and the (Prosperity) Gospel. They talk about Costi’s childhood living large like a Kardashian, learning about a different gospel from a pink study bible, and what goes on behind the scenes of a prominent prosperity gospel ministry.

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Gain Access to the Exclusive Content and Writing Forum: https://babylonbee.com/plans

The Official Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

