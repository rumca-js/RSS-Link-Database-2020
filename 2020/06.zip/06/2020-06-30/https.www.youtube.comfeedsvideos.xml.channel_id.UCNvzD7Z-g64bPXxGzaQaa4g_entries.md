# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Best FREE iOS & Android Games of June 2020
 - [https://www.youtube.com/watch?v=BGZRfKE12Dg](https://www.youtube.com/watch?v=BGZRfKE12Dg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-07-01 00:00:00+00:00

Looking for something to play on iOS and Android this summer? We've got you covered with these free mobile games.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Exos Heroes
Platform: iOS Android
Price: Free
https://play.google.com/store/apps/details?id=com.linegames.exos
https://apps.apple.com/us/app/exos-heroes/id1472315054

Stellaris: Galaxy Command
Platform: iOS Android
Price: Free
https://apps.apple.com/app/stellaris-galaxy-command/id1455954927
https://play.google.com/store/apps/details?id=com.paradoxplaza.lassie

The Academy: The First Riddle
Platform: iOS Android
Price: Free
https://apps.apple.com/us/app/the-academy-the-first-riddle/id1470125745
https://play.google.com/store/apps/details?id=com.snapbreak.theacademy

Rose and Camellia
Platform: Android iOS
Price: Free
https://apps.apple.com/us/app/rose-and-camellia/id1494666973
https://apps.apple.com/us/app/rose-and-camellia/id1494666973


Desert Riders
Platform: Android iOS
Price: Free
https://play.google.com/store/apps/details?id=com.desert.riders
https://apps.apple.com/us/app/desert-riders/id1516289529


Endurance - space action
Platform: Android iOS
Price: Free
https://apps.apple.com/us/app/endurance-space-action/id1504643083
https://play.google.com/store/apps/details?id=com.IvanPanasenko.Endurance


Johnny Trigger Sniper
Android
Price: FREE
https://play.google.com/store/apps/details?id=com.jtsniper.game

HopBound
Platform: iOS Android
Price: Free
https://apps.apple.com/us/app/hopbound/id1499147637
https://play.google.com/store/apps/details?id=com.appsir.hopbound

Romancing SaGa Re;univerSe
Platform: iOS Android
Price: Free
https://apps.apple.com/us/app/romancing-saga-re-universe/id1477941081
https://play.google.com/store/apps/details?id=com.square_enix.android_googleplay.RSRSWW


Pokémon Café Mix
Platform: iOS Android
Price: Free
https://apps.apple.com/us/app/pok%C3%A9mon-caf%C3%A9-mix/id1496738228
https://play.google.com/store/apps/details?id=jp.pokemon.pokemoncafemix

BONUS

Crying Suns
Platform: iOS Android
Price: $8.99
https://apps.apple.com/app/id1511788295
https://play.google.com/store/apps/details?id=com.altshift.cryingsuns

Fallout Shelter Online [ONLY AVAILABLE IN ASIA]
Platform: iOS Android
Price: Free
https://apps.apple.com/ph/app/fallout-shelter-online/id1476237088
https://play.google.com/store/apps/details?id=com.gaea.sdg.shelter

Dead Cells
Platform: iOS Android
Price:   $8.99
https://apps.apple.com/us/app/dead-cells/id1389752090
https://play.google.com/store/apps/details?id=com.playdigious.deadcells.mobile

## 7 Games That SUCKED in 2020 [First Half]
 - [https://www.youtube.com/watch?v=DDCCnHYovL0](https://www.youtube.com/watch?v=DDCCnHYovL0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-06-30 00:00:00+00:00

2020 is filled with surprises, but unfortunately some games did not live up to our expectations. Here are some examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

