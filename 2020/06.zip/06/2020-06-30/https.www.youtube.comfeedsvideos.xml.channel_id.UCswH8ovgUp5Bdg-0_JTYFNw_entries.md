# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Is EVERYTHING CONSCIOUS!? | Russell Brand & Prof. Philip Goff
 - [https://www.youtube.com/watch?v=AsExIj7PQ6U](https://www.youtube.com/watch?v=AsExIj7PQ6U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-07-01 00:00:00+00:00

A clip from the upcoming #UnderTheSkin podcast with Philip Goff!
You can listen to it on Luminary: http://luminary.link/russell

If you’d like learn more, check out Dr. Philip Goff’s book below:

UK version: https://www.penguin.co.uk/books/111/1117019/galileo-s-error/9781846046018.html
US version: https://www.penguinrandomhouse.com/books/599229/galileos-error-by-philip-goff/

Twitter: @philip_goff

Website: www.philipgoffphilosophy.com

Blog: www.conscienceandconsciousness.com  

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

