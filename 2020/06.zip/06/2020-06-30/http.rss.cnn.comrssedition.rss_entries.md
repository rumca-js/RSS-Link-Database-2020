# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Mississippi retires flag with Confederate emblem
 - [https://www.cnn.com/videos/politics/2020/06/30/mississippi-state-flag-confederate-emblem-removal-tsr-vpx.cnn](https://www.cnn.com/videos/politics/2020/06/30/mississippi-state-flag-confederate-emblem-removal-tsr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 23:19:46+00:00

Mississippi Gov. Tate Reeves signed a bill that takes a historic step to retire the last US state flag to feature the Confederate insignia. CNN's Martin Savidge reports.

## Chris Cuomo: Florida governor had a chance to speak, and he spoke too soon
 - [https://www.cnn.com/videos/politics/2020/06/30/chris-cuomo-ron-desantis-florida-coronavirus-cpt-vpx.cnn](https://www.cnn.com/videos/politics/2020/06/30/chris-cuomo-ron-desantis-florida-coronavirus-cpt-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 22:09:24+00:00

CNN's Chris Cuomo discusses Gov. Ron DeSantis (R-FL) praising his own response to the pandemic in May now that Florida has recorded nearly 10,000 new daily cases of coronavirus.

## Fox News reporter asks Biden about his cognitive ability
 - [https://www.cnn.com/videos/politics/2020/06/30/biden-cognitive-ability-question-reporter-lead-vpx.cnn](https://www.cnn.com/videos/politics/2020/06/30/biden-cognitive-ability-question-reporter-lead-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 21:31:48+00:00

A Fox News reporter asked former Vice President Joe Biden about his cognitive ability, an attack that President Trump and his allies have seized on.

## Delta Air Lines brings back beer and wine on flights
 - [https://www.cnn.com/travel/article/delta-beer-wine-coronavirus/index.html](https://www.cnn.com/travel/article/delta-beer-wine-coronavirus/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 18:32:32+00:00

Delta Air Lines is restoring wine and beer options across most of its US flights three months after it eliminated the options as the pandemic began to cripple demand for air travel.

## Senator challenges Fauci. Watch his response.
 - [https://www.cnn.com/videos/health/2020/06/30/anthony-fauci-rand-paul-schools-coronavirus-vpx.cnn](https://www.cnn.com/videos/health/2020/06/30/anthony-fauci-rand-paul-schools-coronavirus-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 18:28:09+00:00

Sen. Rand Paul (R-KY) pressed Dr. Anthony Fauci on sending children back to school amid the coronavirus pandemic.

## Belgium's King sends 'regrets' to Congo for Leopold II atrocities -- but doesn't apologize
 - [https://www.cnn.com/2020/06/30/europe/belgium-drc-leopold-ii-regrets-scli-intl/index.html](https://www.cnn.com/2020/06/30/europe/belgium-drc-leopold-ii-regrets-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 16:15:45+00:00

The King of Belgium has sent his "deepest regrets" to the President of the Democratic Republic of Congo (DRC) for the "suffering and humiliation" his nation inflicted while it colonized the region -- but stopped short of apologizing for his ancestor Leopold II's atrocities.

## From pandering to Putin to abusing allies, Trump's phone calls alarm US officials
 - [https://www.cnn.com/collections/intl-trump-0630/](https://www.cnn.com/collections/intl-trump-0630/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 16:11:37+00:00



## Carl Reiner, longtime comedy legend, dies at 98
 - [https://www.cnn.com/2020/06/30/entertainment/car-reiner-obit/index.html](https://www.cnn.com/2020/06/30/entertainment/car-reiner-obit/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 16:10:11+00:00

Carl Reiner, the writer, actor, director and producer whose many decades' worth of credits -- including "The Dick Van Dyke Show" and "The 2000-Year-Old Man" -- showcased a ready wit and a generous spirit, has died, his son, director Rob Reiner, announced in a tweet.

## Woman gored by a bison at Yellowstone National Park when she tried to take a picture
 - [https://www.cnn.com/travel/article/bison-gores-woman-yellowstone-trnd/index.html](https://www.cnn.com/travel/article/bison-gores-woman-yellowstone-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 16:08:26+00:00

A 72-year-old California woman was gored by a bison in Yellowstone National Park, a news release from the park said.

## These are Carl Reiner's biggest movies and tv shows
 - [https://www.cnn.com/videos/entertainment/2020/06/30/carl-reiner-dead-obit-pkg-vpx.cnn](https://www.cnn.com/videos/entertainment/2020/06/30/carl-reiner-dead-obit-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 16:00:28+00:00

Carl Reiner, the writer, actor, director and producer whose many decades' worth of credits - including "The Dick Van Dyke Show" and "The 2000-Year-Old Man" -- has died at the age of 98.

## Former President Obama aide: This is how to help fix US democracy
 - [https://www.cnn.com/videos/politics/2020/06/29/election-2020-david-litt-opinion-fixing-democracy-mh-orig.cnn](https://www.cnn.com/videos/politics/2020/06/29/election-2020-david-litt-opinion-fixing-democracy-mh-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 15:58:36+00:00

David Litt, a former Obama speechwriter and author of "Democracy In One Book Or Less," says there are some easy fixes to issues like voting and transparency.

## Supreme Court opens door to state funding for religious schools
 - [https://www.cnn.com/2020/06/30/politics/espinoza-montana-religious-schools-scholarship-supreme-court/index.html](https://www.cnn.com/2020/06/30/politics/espinoza-montana-religious-schools-scholarship-supreme-court/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 15:57:04+00:00

In a ruling that will open the door to more public funding for religious education, the Supreme Court on Tuesday ruled in favor of parents in Montana seeking to use a state scholarship program to send their children to religious schools.

## This one graphic shows exactly why European countries are shutting Americans out
 - [https://www.cnn.com/2020/06/30/europe/european-union-travel-us-graphic-intl/index.html](https://www.cnn.com/2020/06/30/europe/european-union-travel-us-graphic-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 15:24:41+00:00

US tourists will be excluded from visiting the European Union after the bloc finalized its list of 15 safe countries for travel to member states on Tuesday.

## Boeing hit with its biggest cancellation of 737 Max crisis
 - [https://www.cnn.com/2020/06/30/business/boeing-737-max-norwegian-air-cancels-orders/index.html](https://www.cnn.com/2020/06/30/business/boeing-737-max-norwegian-air-cancels-orders/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 15:22:49+00:00

Norwegian Air Shuttle canceled orders for 97 Boeing jets, the largest cancellation by a single Boeing customer since the grounding of the 737 Max 15 months ago.

## The best DIY face mask material and design? Quilting cotton beats bandana, new study suggests
 - [https://www.cnn.com/2020/06/30/health/masks-homemade-design-trnd-wellness-scn/index.html](https://www.cnn.com/2020/06/30/health/masks-homemade-design-trnd-wellness-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 15:17:42+00:00

Wearing face masks and coverings is recommended, or in some places mandatory, in public spaces to help stop the spread of Covid-19.

## What EU's new border rules mean for travelers
 - [https://www.cnn.com/travel/article/eu-borders-open-but-not-to-americans-intl/index.html](https://www.cnn.com/travel/article/eu-borders-open-but-not-to-americans-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 15:03:58+00:00

The European Union has formally agreed a set of recommendations that will allow travelers from outside the bloc to visit EU countries, but the United States is not on the list of 14 countries now allowed in.

## Largest tanzanite gemstones in history sold for $3m
 - [https://www.cnn.com/2020/06/30/africa/tanzanite-largest-gems-scli-intl/index.html](https://www.cnn.com/2020/06/30/africa/tanzanite-largest-gems-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 14:57:25+00:00

A team of Tanzanian miners has discovered the largest tanzanite stones ever seen in the country's history.

## More Americans have died from Covid-19 than in four wars combined
 - [https://www.cnn.com/collections/intl-global-coronavirus-0629/](https://www.cnn.com/collections/intl-global-coronavirus-0629/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 14:53:35+00:00



## What if Trump loses and refuses to leave?
 - [https://www.cnn.com/videos/politics/2020/06/29/president-trump-and-the-2020-election-orig-dp-jm.cnn](https://www.cnn.com/videos/politics/2020/06/29/president-trump-and-the-2020-election-orig-dp-jm.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 14:51:01+00:00

President Trump has joked about running for a third term, but what happens if he refuses to leave after a loss in November? CNN's Nick Watt looks into how it could all play out.

## China researchers discover new swine flu with 'pandemic potential'
 - [https://www.cnn.com/2020/06/30/asia/china-swine-flu-pandemic-intl-hnk-scli-scn/index.html](https://www.cnn.com/2020/06/30/asia/china-swine-flu-pandemic-intl-hnk-scli-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 14:48:04+00:00

Chinese researchers have discovered a new type of swine flu that can infect humans and has the potential to cause a future pandemic, according to a study released on Monday.

## The Supreme Court decision on Trump's tax records just became more urgent than ever
 - [https://www.cnn.com/2020/06/30/opinions/scotus-trump-tax-return-opinion-avlon/index.html](https://www.cnn.com/2020/06/30/opinions/scotus-trump-tax-return-opinion-avlon/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 14:43:11+00:00

Reports that the Russians bribed the Taliban with bounties for killing US service members were stunning -- and not just because of the alleged targeting of American soldiers, but because the Trump administration apparently did nothing to retaliate against Russia.

## Soccer star hospitalized after assault and robbery in Liverpool
 - [https://www.cnn.com/2020/06/30/football/andre-wisdom-derby-county-assault-football-spt-intl-gbr/index.html](https://www.cnn.com/2020/06/30/football/andre-wisdom-derby-county-assault-football-spt-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 14:42:45+00:00

Derby County defender Andre Wisdom is recovering in hospital after an "unprovoked assault and robbery," according to a statement from the club.

## The white-collar revolt against Trump is peaking
 - [https://www.cnn.com/2020/06/30/politics/trump-2020-voter-polls/index.html](https://www.cnn.com/2020/06/30/politics/trump-2020-voter-polls/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 14:38:26+00:00

From his open defiance of public health officials when holding rallies to his increasingly explicit embrace of White racial backlash, President Donald Trump has set a course for his reelection campaign that could produce the GOP's largest deficit in the history of modern polling among well-educated White voters.

## Beijing says it's 'strongly concerned' by India's decision to ban Chinese apps
 - [https://www.cnn.com/collections/intl-india-china-0630/](https://www.cnn.com/collections/intl-india-china-0630/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 14:20:37+00:00



## Journalists like Maria Ressa face death threats and jail for doing their jobs. Facebook must take its share of the blame
 - [https://www.cnn.com/2020/06/30/opinions/maria-ressa-facebook-intl-hnk/index.html](https://www.cnn.com/2020/06/30/opinions/maria-ressa-facebook-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 14:17:20+00:00

In September 2018, a group of academics, civil society organizations and journalists gathered at Facebook's headquarters in Menlo Park, California. The off-the-record event, designed to explore how social media content can lead to offline harm in vulnerable communities, coincided with the publication of a UN report that concluded Facebook had played a "determining role" in Mynamar's Rohingya genocide.

## A family rescued a bear after it was found swimming with a plastic tub on its head
 - [https://www.cnn.com/2020/06/29/us/family-rescues-bear-with-plastic-tub-on-its-head-trnd/index.html](https://www.cnn.com/2020/06/29/us/family-rescues-bear-with-plastic-tub-on-its-head-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 14:16:10+00:00

A Wisconsin family rescued a young bear after it got a plastic cheese ball container stuck on its head.

## Couple in St. Louis wield guns near protesters on private street
 - [https://www.cnn.com/videos/us/2020/06/29/st-louis-couple-protest-firearms-orig-mg.cnn](https://www.cnn.com/videos/us/2020/06/29/st-louis-couple-protest-firearms-orig-mg.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 13:54:02+00:00

Protesters en route to demonstrate outside of the St. Louis mayor's residence were walking on a private street when two armed individuals came out of a home brandishing weapons.

## Paul Walker and Vin Diesel's kids take 'family, forever' selfie
 - [https://www.cnn.com/2020/06/30/entertainment/meadow-walker-vin-diesel-kids/index.html](https://www.cnn.com/2020/06/30/entertainment/meadow-walker-vin-diesel-kids/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 13:15:09+00:00

Paul Walker and Vin Diesel were BFFs and it looks like their children are continuing that tradition.

## $84M painting smashes sales expectations in virtual auction
 - [https://www.cnn.com/style/article/francis-bacon-sothebys-hybrid-auction/index.html](https://www.cnn.com/style/article/francis-bacon-sothebys-hybrid-auction/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 13:08:50+00:00

A Francis Bacon triptych sold for over $84 million during a virtual auction at Sotheby's, on what was an encouraging -- and highly unusual -- evening for the coronavirus-hit art market.

## Shell warns of $22 billion hit from coronavirus price slump
 - [https://www.cnn.com/2020/06/30/business/shell-oil-prices-coronavirus/index.html](https://www.cnn.com/2020/06/30/business/shell-oil-prices-coronavirus/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 13:07:02+00:00

Royal Dutch Shell is writing down the value of its assets by as much as $22 billion as lower oil prices push the Anglo-Dutch company to accelerate a shift away from fossil fuels.

## Experts say spread of Covid-19 in US is now hard to control
 - [https://www.cnn.com/2020/06/30/health/us-coronavirus-tuesday/index.html](https://www.cnn.com/2020/06/30/health/us-coronavirus-tuesday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 12:45:20+00:00

At least 16 states have paused or rolled back their reopening plans in response to a surge in new coronavirus infections, but some health officials say the spread of the virus will still be difficult to control.

## Djokovic event fallout: Kyrgios calls Becker a 'doughnut'
 - [https://www.cnn.com/2020/06/30/tennis/nick-kyrgios-boris-becker-alexander-zverev-tennis-coronavirus-party-spt-intl/index.html](https://www.cnn.com/2020/06/30/tennis/nick-kyrgios-boris-becker-alexander-zverev-tennis-coronavirus-party-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 12:33:51+00:00

The fallout from Novak Djokovic's Adria Tour continues, with tennis great Boris Becker and current star Nick Kyrgios embroiled in a verbal tit-for-tat.

## Step inside the luxury homes of this Latin superstar
 - [https://www.cnn.com/style/article/j-balvin-architectural-digest/index.html](https://www.cnn.com/style/article/j-balvin-architectural-digest/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 12:01:34+00:00

Latin music superstar J Balvin is known for his bold style -- including his mix of streetwear and couture, and his ever-evolving hair color. But he likes to keep things more subdued on the interior design front.

## Investigating the disappearance of a massive star in a distant galaxy
 - [https://www.cnn.com/2020/06/30/world/massive-star-disappearance-scn/index.html](https://www.cnn.com/2020/06/30/world/massive-star-disappearance-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 11:43:41+00:00

A massive star has quietly disappeared in a dwarf galaxy 75 million light-years away, according to a new study. Given the lack of a visible supernova, the researchers believe the star grew dim and was obscured from view by dust or reached the end of its life and collapsed into a black hole.

## SR-71 Blackbird: Still the fastest plane
 - [https://www.cnn.com/videos/design/2019/11/04/blackbird-sr-71-spy-plane-design-style-orig.cnn](https://www.cnn.com/videos/design/2019/11/04/blackbird-sr-71-spy-plane-design-style-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 11:39:43+00:00

During the Cold War, the SR-71 Blackbird spy plane could fly higher and faster than any other -- and 55 years after its first flight, it still does.

## This new high-tech glove translates sign language into speech in real time
 - [https://www.cnn.com/2020/06/30/health/sign-language-glove-ucla-scn-scli-intl/index.html](https://www.cnn.com/2020/06/30/health/sign-language-glove-ucla-scn-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 11:34:52+00:00

A glove that translates sign language into speech in real time has been developed by scientists -- potentially allowing deaf people to communicate directly with anyone, without the need for a translator.

## New Trimonoran superyacht concept could be future of luxury sailing
 - [https://www.cnn.com/travel/article/trimonoran-yacht-concept-escalade/index.html](https://www.cnn.com/travel/article/trimonoran-yacht-concept-escalade/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 11:23:07+00:00

A yacht concept at least 20 years in the making, Escalade is being touted as a "game changer" by the team behind it.

## More Americans have died from Covid-19 than in four wars
 - [https://www.cnn.com/2020/06/30/health/us-coronavirus-toll-in-numbers-june-trnd/index.html](https://www.cnn.com/2020/06/30/health/us-coronavirus-toll-in-numbers-june-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 11:10:28+00:00

• Experts say spread of coronavirus in the US is now hard to control

## Barcelona slaps $448 million buyout clause on new star
 - [https://www.cnn.com/2020/06/30/football/barcelona-miralem-pjanic-juventus-spt-intl/index.html](https://www.cnn.com/2020/06/30/football/barcelona-miralem-pjanic-juventus-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 10:23:00+00:00

Barcelona has slapped an eye-watering buyout clause of nearly $450 million (400m euros) on new signing Miralem Pjanić.

## In a tiny African mountain kingdom, one soccer club is driving social change
 - [https://www.cnn.com/2020/06/30/football/lesotho-football-club-kick4life-fc-equal-budget-spt-intl/index.html](https://www.cnn.com/2020/06/30/football/lesotho-football-club-kick4life-fc-equal-budget-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 09:57:42+00:00

Puky Ramokoatsi believes football helped saved her life.

## South Africa turns recreational center into field hospital
 - [https://www.cnn.com/videos/world/2020/06/30/south-africa-coronavirus-covid-19-pandemic-field-hospital-mckenzie-walk-and-talk-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2020/06/30/south-africa-coronavirus-covid-19-pandemic-field-hospital-mckenzie-walk-and-talk-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 09:40:55+00:00

CNN's David McKenzie reports from a recreational center in South Africa converted into a field hospital as the country grapples with the worst coronavirus outbreak in Africa.

## The body of one of three missing men has been found on Mount Rainier
 - [https://www.cnn.com/2020/06/30/us/mount-rainier-missing-hikers-body-found/index.html](https://www.cnn.com/2020/06/30/us/mount-rainier-missing-hikers-body-found/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 08:11:13+00:00

The body of one of the three men who have gone missing on separate excursions in Washington's Mount Rainier National Park has been found, according to the National Park Service.

## Meet the Japanese man who holds the world's only master's degree in ninja studies
 - [https://www.cnn.com/2020/06/30/asia/ninja-studies-graduate-intl-hnk-scli/index.html](https://www.cnn.com/2020/06/30/asia/ninja-studies-graduate-intl-hnk-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 07:25:59+00:00

A Japanese man has become the first person in the world to hold a master's degree in ninja studies, after completing a graduate course that involved learning basic martial arts and how to stealthily climb mountains.

## Wrongly arrested Black man said he knew he was going to be falsely accused as police approached him
 - [https://www.cnn.com/2020/06/30/us/valdosta-wrongly-arrested-black-man-antonio-smith/index.html](https://www.cnn.com/2020/06/30/us/valdosta-wrongly-arrested-black-man-antonio-smith/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 06:27:27+00:00

As Valdosta police approached Antonio Smith, he was terrified and thought he was going to "get pinned for something I didn't do," he told CNN.

## Pro-choice and pro-life activists react to SCOTUS decision
 - [https://www.cnn.com/videos/us/2020/06/29/supreme-court-louisiana-june-medical-services-russo-orig-lr-mss.cnn](https://www.cnn.com/videos/us/2020/06/29/supreme-court-louisiana-june-medical-services-russo-orig-lr-mss.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 02:26:23+00:00

The Supreme Court blocked a Louisiana law that barred doctors from performing abortions unless they had admitting privileges at hospitals — a win for supporters of abortion access. Here's what Louisiana pro-choice and pro-life groups think of the decision.

## Cooper on US numbers: 'This is what failure looks like'
 - [https://www.cnn.com/videos/us/2020/06/30/coronavirus-numbers-rise-cooper-sot-kth-ac360-vpx.cnn](https://www.cnn.com/videos/us/2020/06/30/coronavirus-numbers-rise-cooper-sot-kth-ac360-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 01:28:15+00:00

CNN's Anderson Cooper reacts to the latest coronavirus numbers in the US, as the death toll surpasses 126,000 and only four of 50 states are experiencing a drop in new cases.

## The US watched Italy's coronavirus outbreak in horror. See what it looks like now
 - [https://www.cnn.com/videos/world/2020/06/30/italy-reopening-us-coronavirus-surge-wedeman-pkg-ebof-vpx.cnn](https://www.cnn.com/videos/world/2020/06/30/italy-reopening-us-coronavirus-surge-wedeman-pkg-ebof-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-30 01:12:44+00:00

Months ago, the US looked on in horror as the Covid-19 outbreak devastated Italy. Now, as Italy is returning to normal, the US is experiencing a surge in cases. CNN's Ben Wedeman reports.

