# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## This is the NEW Oculus VR prototype
 - [https://www.youtube.com/watch?v=hURYmrVQths](https://www.youtube.com/watch?v=hURYmrVQths)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-06-30 00:00:00+00:00

Hello and welcome to Tuesday Newsday! Your number one resource for the entire weeks worth of VR news.  
VRCover new Valve Index link (affiliate):
https://vrcover.com/product/silicone-cover-for-valve-index/?itm=322&campaign=Thrillseeker

Ridge Wallet: Use discount code: Thrill

Here are my links:
Twitch Stream with cosmos elite today!
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill

Outro Music: Protostar Overdrive:
https://open.spotify.com/track/3QifigzYiNKYk39TuwhPhJ?si=-_Y0FN1VQ7WavTIgx6zY5A

Here is everything I covered today:

00:00 TUESDAY NEWSDAY!
01:28 - End of VR Exclusives
05:26 - Oculus New VR 2.0 Prototype
09:01 - meme break
10:19 - BIG oculus news
11:52 - Steam Summer Sale
12:01 - new Vr covers for Valve index
12:30 - Stream info


https://www.engadget.com/facebook-holographic-vr-displays-230133045.html?guccounter=1&guce_referrer=aHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS8&guce_referrer_sig=AQAAAESjBh2wMgNhO6QsdfoF2GIyjK0qidELm8RFQzT391Jtzh_VYuKGfVwWYfLaVUy1oEadr60teptg3NlHOMH5ULqq9lEzZKLKbOdCEZ28-Y4G2LlFPSeNYRBBQIEB8FTJwbyAqdOKZzZ6LhQCbXpnMnDfBj7jIdz_g6rydMXCg7bl
https://www.roadtovr.com/steam-summer-sale-half-life-alyx-walking-dead-discount/
https://uploadvr.com/valve-openxr-steamvr-beta/
https://www.oculus.com/blog/an-update-on-the-evolution-of-the-oculus-platform-/?locale=en_US

