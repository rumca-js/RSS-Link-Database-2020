# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## John Delorean - FBI Agents, Civil War and a Car
 - [https://www.youtube.com/watch?v=mln2SymT73s](https://www.youtube.com/watch?v=mln2SymT73s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2020-07-01 00:00:00+00:00

This is one of the wildest stories in automotive history, a story of how far a man would go to chase his dream. This is the John Delorean story.

--- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. 

If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- New Thinking Book written by Dagogo Altraide ---
This book was rated the 9th best technology history book by book authority.
In the book you’ll learn the stories of those who invented the things we use everyday and how it all fits together to form our modern world.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

--- ColdFusion Social Media ---
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusionTV

Script by Fil Zivko

Sources:

https://time.com/4180894/delorean-history/

https://www.adweek.com/brand-marketing/once-upon-a-time-the-delorean-promised-to-lay-rubber-through-the-automotive-industry/

https://www.entermyworld.com/cat/articles/playboy/pbmay81c1x1.jpg

https://www.youtube.com/watch?v=3cbIunv7UpI

https://www.considerable.com/entertainment/retronaut/john-delorean-car-history/

https://people.com/movies/who-was-john-delorean-80s-mogul-arrested-for-cocaine/

https://www.vanityfair.com/hollywood/2019/06/framing-john-delorean-movie

https://www.cnet.com/roadshow/news/john-delorean-dmc-facts/

https://www.forbes.com/wheels/news/john-delorean-reinvented-the-dream-car-then-he-totaled-it/

https://www.bbc.com/news/world-us-canada-47860011

https://www.britannica.com/biography/John-Zachary-DeLorean

https://edition.cnn.com/style/article/dmc-delorean/index.html

https://www.irishtimes.com/topics/topics-7.1213540?article=true&tag_person=John+Delorean



//Soundtrack//

Hiatus - Cloud City

Justin Martin - Don't Go (Dusky Remix)

LUCA - Your Name is Jim

Catching Flies - The Long Journey Home

no spirit - leaves covered by snow

Lemongrass - Heartbreaker

Catching Flies - Satisfied (Ambient Reprise)

Blue States - Vision Trail

Tony Anderson - Dwell (Snowfall Remix)

Burn Water - She Shines

» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide

Why are you still reading?

