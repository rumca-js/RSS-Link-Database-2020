## YouTube bans David Duke and other US far-right users
 - [https://www.theguardian.com/technology/2020/jun/30/youtube-bans-david-duke-and-other-us-far-right-users](https://www.theguardian.com/technology/2020/jun/30/youtube-bans-david-duke-and-other-us-far-right-users)
 - RSS feed: https://www.theguardian.com
 - date published: 2020-06-30 20:01:50+00:00

test

