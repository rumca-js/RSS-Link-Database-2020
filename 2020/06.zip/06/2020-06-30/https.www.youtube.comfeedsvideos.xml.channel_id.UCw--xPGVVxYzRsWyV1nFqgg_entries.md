# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Mistborn Script Changes📜  Harry Potter Game🧙  Pirates of the Caribbean Reboot🏴‍☠️ -FANTASY NEWS
 - [https://www.youtube.com/watch?v=EzgA2BWKmkM](https://www.youtube.com/watch?v=EzgA2BWKmkM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-07-01 00:00:00+00:00

welcome to the sloppy fantasy news I recorded with little sleep and feeling good! 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

NEWS: 

Shadow and Bone collectors edition: https://twitter.com/LBardugo/status/1277996847668162560

The Boys Season 2 Trailer: https://www.youtube.com/watch?v=1OC5NSRW9Lw

Joe Abercrombie Progress Repot: https://joeabercrombie.com/progress-report-june-20/

Kuang Chakraborty Event: https://www.brooklinebooksmith.com/events/2020-07/virtual-event-r.a.chakraborty-with-r.f.kuang/

Harry Potter Video Game: https://www.bloomberg.com/news/articles/2020-06-29/harry-potter-game-developers-rattled-by-j-k-rowling-backlash

The Experts System’s Champion: https://www.tor.com/2020/06/29/revealing-adrian-tchaikovskys-the-expert-systems-champion/

Mistborn Movie Changes: https://www.reddit.com/r/Mistborn/comments/hc03ak/mistborn_movie_news/?utm_term=34567015724&utm_medium=comment_embed&utm_source=embed&utm_name=e3cbad06-ba46-11ea-b183-0eb2956a09fb&utm_content=footer

Pirates of the Caribbean Reboot: https://www.koimoi.com/hollywood-2/robert-downey-jr-to-appear-in-pirates-of-the-caribbean-6-read-deets-about-his-character/

Princess Bride Fan Film: https://www.vanityfair.com/hollywood/2020/06/the-princess-bride-homemade-fan-film

## Who Writes The Best Action?
 - [https://www.youtube.com/watch?v=aB2PxhXEHvs](https://www.youtube.com/watch?v=aB2PxhXEHvs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-06-30 00:00:00+00:00

You all voted without even knowing. Let's go ahead and break it down. Who writes the best action? Is it Abercrombie? Sanderson? Let's look at the data and figure it out!
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

