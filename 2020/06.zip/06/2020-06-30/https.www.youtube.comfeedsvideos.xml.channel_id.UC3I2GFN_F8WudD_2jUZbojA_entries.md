# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Empress Of (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=EFN4WNv5iYQ](https://www.youtube.com/watch?v=EFN4WNv5iYQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-07-01 00:00:00+00:00

Lorely Rodriguez, aka Empress Of, shares an exclusive live set and joins DJ Troy Nelson live on KEXP at Home on Wednesday, July 1, at 12pm PT.

## Naeem (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=He0eUrRK-NI](https://www.youtube.com/watch?v=He0eUrRK-NI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-06-30 00:00:00+00:00

Naeem Juwan, who previously recorded as Spank Rock, now records under his first name. On Tuesday, June 30, Naeem shares an exclusive live set he performed for KEXP and joins Larry Mizell, Jr. live from home.

