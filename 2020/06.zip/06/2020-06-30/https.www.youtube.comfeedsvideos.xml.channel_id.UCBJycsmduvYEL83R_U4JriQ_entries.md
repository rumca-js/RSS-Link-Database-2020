# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## On the iPhone With No Charger...
 - [https://www.youtube.com/watch?v=8IB7JcKJEeI](https://www.youtube.com/watch?v=8IB7JcKJEeI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-07-01 00:00:00+00:00

iPhone 12 could ship with no charger. I have some thoughts.

Articles mentioned:
https://www.theverge.com/2020/6/30/21307463/apple-iphone-12-power-adapter-charger-rumor-usb-c
https://500ish.com/unlimited-power-but-the-opposite-427be9ad6db8

MKBHD Merch: http://shop.MKBHD.com

Video Gear I use: http://kit.co/MKBHD/video-gear#recom...
Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: http://youtube.com/20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

