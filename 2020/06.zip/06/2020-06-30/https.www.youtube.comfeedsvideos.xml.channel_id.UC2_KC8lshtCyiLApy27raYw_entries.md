# Source:KnowledgeHusk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw, language:en-US

## What Defined the 2000s?
 - [https://www.youtube.com/watch?v=8rkd6X1PMPg](https://www.youtube.com/watch?v=8rkd6X1PMPg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw
 - date published: 2020-06-30 00:00:00+00:00

Remember the 2000s. Hey guys. Guys. Remember the 2000s? Remember the 2000s guys weren’t the 2000s great guys. Guys? Guys. The 2000s/

Yeah.

Twitter: https://twitter.com/KnowledgeHubTy

Soundcloud: https://soundcloud.com/user-503704039

Patreon: https://www.patreon.com/theknowledgehub

Second Channel: https://www.youtube.com/channel/UC-KL04Ra6E1Du0pFawN4pWg

Spotify: https://open.spotify.com/artist/3STpelEilrthF8UxsQTaaw?si=52TH_ZKTQhaKhfnK1Jomfg

