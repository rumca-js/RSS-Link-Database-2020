# Source:Laowhy86, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw, language:en-US

## How I Escaped From China - The Untold Story
 - [https://www.youtube.com/watch?v=z7CPqROtanA](https://www.youtube.com/watch?v=z7CPqROtanA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw
 - date published: 2020-07-01 00:00:00+00:00

I finally tell the story of how I escaped from China. I filmed the story a few days after I ran away. 

SerpentZA's story on how he left China - https://youtu.be/nWgqdfAomVI

◘ Support me on Patreon for early release, and much more! http://www.patreon.com/laowhy86
◘ Or, if you prefer, Subscribestar - https://www.subscribestar.com/laowhy86

Car channel - https://www.youtube.com/worthlesswhips
ADVChina - https://www.youtube.com/advchina
SerpentZA - https://www.youtube.com/serpentza
ADVPodcasts - https://www.youtube.com/advpodcasts

◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

◘ OR Become a Sponsor on YouTube:
https://www.youtube.com/channel/UChvithwOECK5g_19TjldMKw/sponsor

◘ My TV show: Conquering Northern China:
https://vimeo.com/ondemand/conqueringnorthernchina

◘ Conquering Southern China
https://vimeo.com/ondemand/conqueringsouthernchina

◘ Discount code for both shows: laowinning

◘ Join me every week for videos about China! Don't forget to subscribe!
http://www.youtube.com/laowhy86

Be a Laowinner!
Like comment subscribe!

◘ Facebook:
http://www.facebook.com/laowhy86

◘ Instagram: 
http://instagram.com/laowhy86

Music in this video - The Muse Maker
https://soundcloud.com/themusemaker

◘ Music used most of the time - New World Hip Hop
https://soundcloud.com/apollodrivenz
https://www.youtube.com/channel/UCgirAE5d8ufiotRXmBZZbBQ

