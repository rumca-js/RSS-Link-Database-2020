# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Lucifer - Series Review (So far)
 - [https://www.youtube.com/watch?v=0JbSJY83_08](https://www.youtube.com/watch?v=0JbSJY83_08)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-06-30 00:00:00+00:00

Thank you to Scentbird for sponsoring this video!
Click here https://sbird.co/2UMayWV and use my code JEREMY30 to get 30% OFF your first month at Scentbird.
Download Scentbird app here https://sbird.co/2Y1hgdw


I have mentioned the series LUCIFER in a few videos, so here are my thoughts on the series so far!



This month with Scentbird, I tried:
Oxford Bleu by English Laundry https://sbird.co/3gfJ7gt
Awaken by TUMI https://sbird.co/2VtSdOp
Man Intense by Mercedes-Benz https://sbird.co/2YKaskE

#Lucifer

