# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## STOP Using Adobe Flash
 - [https://www.youtube.com/watch?v=3T636Xqqusc](https://www.youtube.com/watch?v=3T636Xqqusc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2020-07-01 00:00:00+00:00

Adobe flash will soon reach it's end of life. You may as well uninstall it now if you still have it.
• Uninstall from Windows: https://helpx.adobe.com/flash-player/kb/uninstall-flash-player-windows.html
• Uninstall from Mac: https://helpx.adobe.com/flash-player/kb/uninstall-flash-player-mac-os.html

⇒ Become a channel member for exclusive features! Check it out here: https://www.youtube.com/ThioJoe/join

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe

⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV

My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

#Tech #ThioJoe

