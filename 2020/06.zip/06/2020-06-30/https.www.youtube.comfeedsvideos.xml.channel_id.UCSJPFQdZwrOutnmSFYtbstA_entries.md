# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## The Last of Us Part 2 - A Beautiful Nightmare
 - [https://www.youtube.com/watch?v=iGtKUaPhdfk](https://www.youtube.com/watch?v=iGtKUaPhdfk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-06-30 00:00:00+00:00

The time has come for me to review this beast. After playing Last of Us 2 from start to finish, here is my review.

