# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Czy powinniśmy zabić wszystkie komary?
 - [https://www.youtube.com/watch?v=w3ywsy2pdto](https://www.youtube.com/watch?v=w3ywsy2pdto)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2020-07-01 00:00:00+00:00

Patronite ► https://patronite.pl/NaukowyBelkot 
Mix audio ► http://ratstudios.pl/

Pytanie niby proste - ale jak się tak nad nim zastanowić...

Subskrypcja ► https://youtube.com/c/UwagaNaukowyBelkot
Facebook ► https://facebook.com/UwagaNaukowyBelkot
Twitter ► https://twitter.com/NaukowyBelkot
Instagram ► https://www.instagram.com/NaukowyBelkot/

Wyłącznie Naukowy Bełkot ► https://goo.gl/Do7VCc
Grupa na facebooku ► https://goo.gl/HP8J83

===
Timestampy:

0:00 Wstęp
2:30 Morderczyni seryjna
7:00 Wszystkie?
12:39 Czy powinniśmy?
17:03 Trzy problematyczne litery
21:00 Jeśli tak - to jak?

===
Źródła (wybrane)

T. Winegard - The Mosquito: A Human History of Our Deadliest Predator
S. Shah - The Fever: How Malaria Has Ruled Humankind for 500,000 Years
A. A. James - Gene drive systems in mosquitoes: rules of the road
S. Mainali i in. - Looking over the Backyard Fence: Householders and Mosquito Control
J. R. Gilles - Towards mosquito sterile insect technique programmes: exploring genetic, molecular, mechanical and behavioural methods of sex separation in mosquitoes
M. Fletcher - Mutant mosquitoes: Can gene editing kill off malaria?
D.A. Wijesundere i in. - Analysis of Historical Trends and Recent Elimination of Malaria from Sri Lanka and Its Applicability for Malaria Control in Other Countries 

https://www.wnycstudios.org/podcasts/radiolab/articles/kill-em-all
https://www.forbes.com/sites/quora/2017/09/13/what-would-happen-if-we-eliminated-the-worlds-mosquitoes/#3da150be11f6
https://www.gatesnotes.com/health/most-lethal-animal-mosquito-week
https://www.smithsonianmag.com/innovation/kill-all-mosquitos-180959069/
https://edition.cnn.com/2016/02/05/health/zika-virus-kill-all-mosquitoes/index.html

