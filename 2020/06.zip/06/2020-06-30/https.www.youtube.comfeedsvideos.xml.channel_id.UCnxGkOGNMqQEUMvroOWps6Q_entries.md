# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Barbara Frees Says Industrial Denial Dates Back to the British Slave Trade | Joe Rogan
 - [https://www.youtube.com/watch?v=iQAqqkUOFc8](https://www.youtube.com/watch?v=iQAqqkUOFc8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-01 00:00:00+00:00

Taken from JRE #1500 w/Barbara Freese:
https://youtu.be/cP0D2_jhqPU

## Environmental Attorney Barbara Freese on the State of Climate Change Action
 - [https://www.youtube.com/watch?v=s-ZESGm-rMo](https://www.youtube.com/watch?v=s-ZESGm-rMo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-01 00:00:00+00:00

Taken from JRE #1500 w/Barbara Freese: https://youtu.be/cP0D2_jhqPU

## Gruesome Radioactive Deformities Freak Joe Rogan Out
 - [https://www.youtube.com/watch?v=EZvXQHvrTtY](https://www.youtube.com/watch?v=EZvXQHvrTtY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-01 00:00:00+00:00

Taken from JRE #1500 w/Barbara Freese: https://youtu.be/cP0D2_jhqPU

## The Psychology and Denial of a Tobacco Executive w/Barbara Freese | Joe Rogan
 - [https://www.youtube.com/watch?v=yH3vkkrfpKA](https://www.youtube.com/watch?v=yH3vkkrfpKA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-01 00:00:00+00:00

Taken from JRE #1500 w/Barbara Freese:
https://youtu.be/cP0D2_jhqPU

## Why Climate Change is the Most Divisive Issue w:Barbara Freese | Joe Rogan
 - [https://www.youtube.com/watch?v=sMLnu2BQwzM](https://www.youtube.com/watch?v=sMLnu2BQwzM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-01 00:00:00+00:00

Taken from JRE #1500 w/Barbara Freese:
https://youtu.be/cP0D2_jhqPU

## Why You Don’t Hear About the Hole in the Ozone Layer Anymore
 - [https://www.youtube.com/watch?v=mYJHtauiP9Q](https://www.youtube.com/watch?v=mYJHtauiP9Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-01 00:00:00+00:00

Taken from JRE #1500 w/Barbara Freese: https://youtu.be/cP0D2_jhqPU

## Aron Snyder Faced Down a Grizzly Bear | Joe Rogan
 - [https://www.youtube.com/watch?v=14fG4x_tkT8](https://www.youtube.com/watch?v=14fG4x_tkT8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-30 00:00:00+00:00

Taken from JRE #1499 w/Aron Snyder:
https://youtu.be/VmgYeeE31_8

## Bow Hunter Aron Snyder's Most Painful Experiences in the Woods
 - [https://www.youtube.com/watch?v=-KXGeXFYgDY](https://www.youtube.com/watch?v=-KXGeXFYgDY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-30 00:00:00+00:00

Taken from JRE #1499 w/Aron Snyder: https://youtu.be/VmgYeeE31_8

## How  Was One Man Struck by Lighting Seven times?
 - [https://www.youtube.com/watch?v=gE90REaA1pY](https://www.youtube.com/watch?v=gE90REaA1pY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-30 00:00:00+00:00

Taken from JRE #1499 w/Aron Snyder: https://youtu.be/VmgYeeE31_8

## Steroids Wreaked Havoc on Aron Snyder’s Health
 - [https://www.youtube.com/watch?v=rMZjX2Z1pFA](https://www.youtube.com/watch?v=rMZjX2Z1pFA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-30 00:00:00+00:00

Taken from JRE #1499 w/Aron Snyder: https://youtu.be/VmgYeeE31_8

