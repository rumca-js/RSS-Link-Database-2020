# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Bright Bird with Mary Kish | Play For All
 - [https://www.youtube.com/watch?v=YMoaZl0IWVI](https://www.youtube.com/watch?v=YMoaZl0IWVI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-07-01 00:00:00+00:00

BLACK LIVES MATTER: http://bit.ly/gs-blm

COVID-19 Direct Relief: http://bit.ly/gs-covid

Twitch's Mary Kish joins us for a charity livestream to play Bright Bird, a chill side-scroller full of challenging puzzles!

## Death Stranding - Exclusive PC Features Trailer
 - [https://www.youtube.com/watch?v=jTManeyrtHE](https://www.youtube.com/watch?v=jTManeyrtHE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-07-01 00:00:00+00:00

In this GameSpot Exclusive, check out a quick look at Hideo Kojima's Death Stranding running on PC, along with a glimpse of the Half-Life crossover content.

## Dungeon Of Naheulbeuk Exclusive Release Date Reveal Trailer
 - [https://www.youtube.com/watch?v=ZezQwhKq-fA](https://www.youtube.com/watch?v=ZezQwhKq-fA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-07-01 00:00:00+00:00

Take a look at this exclusive trailer showing off characters and a release date for Dungeon of Naheulbeuk: The Amulet of Chaos.

## How Deathloop’s Multiplayer Works
 - [https://www.youtube.com/watch?v=XHuVHOnhOPw](https://www.youtube.com/watch?v=XHuVHOnhOPw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-07-01 00:00:00+00:00

Kurt Indovina chats with Deathloop's director Dinga Bakaba and art director Sebastien Mitton about the game's distinctive aesthetic, world building, and what it was like to adapt multiplayer into an immersive sim.

## The Waylanders' Take On The Classic RPG
 - [https://www.youtube.com/watch?v=6d-Xs7yidSA](https://www.youtube.com/watch?v=6d-Xs7yidSA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-07-01 00:00:00+00:00

Emily Grace Buck joins us to share what RPG fans can expect from The Waylanders early access story, and multiple character classes.

## Xbox Series X Could've Been Here In August | Save State
 - [https://www.youtube.com/watch?v=WcOu4n7Msd8](https://www.youtube.com/watch?v=WcOu4n7Msd8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-07-01 00:00:00+00:00

Persia talks about Microsoft's original plan to launch the Xbox Series X in August of this year. Of course, due to the pandemic and no E3, that launch date was delayed to the 2020 holiday season. This also means that the unannounced but heavily rumored Project Lockhart has also been delayed. It has been suggested that the official announcement will happen this August instead. 

Persia also talks about a recent discovery that you can pet the cats in Cyberpunk 2077. There is no word on the ability to pet the dogs, however. Considering the fact that Geralt couldn't pet cats in The Witcher, this is a small detail that feels like a big win for the cat-lovers out there. 

Lastly, during #PlayForAll, the voice actors of Arthur Morgan, Sadie Adler, and Dutch from Red Dead Redemption 2 joined Lucy James and shared some insight on content that didn't make it into the game. We already knew that about five hours worth of content that did not made it to the final game, but Roger Clark talked about a specific mission that he was sad to see let go. 

New to #PlayForAll? Play For All is multi-week summer gaming celebration and charity event featuring special guests and many familiar GameSpot faces. We've already raised thousands of dollars for #BlackLivesMatter and COVID-19 Relief Efforts thanks to all of you! Be sure to tune in every day between 12 PM and 2 PM PDT for interviews, livestreams, and everything in between. 

Play For All schedule: https://www.gamespot.com/play-for-all

Where to donate: BLACK LIVES MATTER: http://bit.ly/gs-blm

COVID-19 Direct Relief: http://bit.ly/gs-covid

#SaveState #GameSpot

## Free PS4 PlayStation Plus Games For July 2020 Revealed
 - [https://www.youtube.com/watch?v=NEsL8OqM7CU](https://www.youtube.com/watch?v=NEsL8OqM7CU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-30 00:00:00+00:00

The free PlayStation Plus games for July 2020 have been revealed, and to celebrate 10 years of PS Plus, there are three games coming your way in the new month. PS4 players can grab NBA 2K20, Rise of the Tomb Raider, and Erica. There will also be a special PS4 theme, but we don't know what that looks like yet.

## Leaving Halo Behind: The Creation Of Disintegration | Audio Logs
 - [https://www.youtube.com/watch?v=wAGO7i8tAQU](https://www.youtube.com/watch?v=wAGO7i8tAQU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-30 00:00:00+00:00

On this episode of Audio Logs we talk to Marcus Lehto, co-creator of Master Chief, who left Bungie to found his own studio, V1 Interactive. Following the launch of V1's debut title, Disintegration, Lehto talks about leaving AAA behind, and how working on Halo has shaped his latest project.

## Ubisoft Has A Battle Royale Dropping Into The Arena | Save State
 - [https://www.youtube.com/watch?v=l9A7ZhVvpyo](https://www.youtube.com/watch?v=l9A7ZhVvpyo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-30 00:00:00+00:00

Ubisoft teases its own battle royale game, Hyper Scape, The Last Of Us Part II will not be getting story DLC, and Call Of Duty: Warzone is adding a 200 player mode.

Ubisoft teases its own battle royale game, Hyper Scape, with a teaser website for a fictional tech company called Prisma Dimensions. The website details that more information on Hyper Scape is coming on July 2. It's reportedly launching for PC and consoles on July 12 with cross-play.

The Last Of Us Part II will not be getting story DLC, but an online mode is still on the way. Unlike the first game, which got the Left Behind story DLC, director and co-writer Neil Druckmann stated on a Kinda Funny podcast that the story for The Last Of Us Part II is finished. Lastly for today's Save State, Call Of Duty: Warzone is getting a big update that adds a 200 player mode, as well as new modes and gear. 

Meanwhile, Play For All keeps on trucking. Play For All is multi-week summer gaming celebration and charity event featuring special guests like Troy Baker, Danny O'Dwyer, and many familiar GameSpot faces. We've already raised thousands of dollars for #BlackLivesMatter and COVID-19 Relief Efforts thanks to all of you! Be sure to tune in every day between 12 PM and 2 PM PDT for interviews, livestreams, and everything in between. 

Play For All schedule: https://www.gamespot.com/play-for-all

Where to donate: BLACK LIVES MATTER: http://bit.ly/gs-blm

COVID-19 Direct Relief: http://bit.ly/gs-covid

#SaveState #GameSpot

## What's Good Games Live Podcast: GOTY 2020 (So Far)
 - [https://www.youtube.com/watch?v=Zcl5nrSt77Y](https://www.youtube.com/watch?v=Zcl5nrSt77Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-30 00:00:00+00:00

Where to donate:
BLACK LIVES MATTER: http://bit.ly/gs-blm

COVID-19 Direct Relief: http://bit.ly/gs-covid
Join Andrea, Britt, and Steimer, from What's Good Games and our own Kallie Plagge for a live podcast where they each decide their Game of the Year (so far) for 2020, plus a live Q and A with the chat!

