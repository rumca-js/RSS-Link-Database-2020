# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## "Wealth Seminar" Debt Killed UK Man - Family Speaks Out
 - [https://www.youtube.com/watch?v=xE7IB81QhqA](https://www.youtube.com/watch?v=xE7IB81QhqA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-06-30 00:00:00+00:00

Danny Butcher took Samuel Leeds course in early 2019. In October 2019 he unfortunately took his life after getting in crippling debt.  His family is speaking out to get this industry regulated.
Change Petition - https://www.change.org/p/uk-parliament-regulations-of-the-property-investment-training-sector?recruiter=313682219&utm_source=share_petition&utm_medium=facebook&utm_campaign=share_petition&utm_term=Search%3ESAP%3EUK%3ENonBrand-Tier%201%3EDiscovery%3EBMM&recruited_by_id=96d45390-1000-11e5-9f36-09857476b550&utm_content=starter_fb_share_content_en-gb%3Av13
If you'd like to donate to the Danny Butcher Foundation you can get in touch with them here:
TheDannyButcherFoundation@gmail.com

I've featured a lot of sad stories on this channel before: this is the most tragic I've ever heard. Wealth Seminars need to be regulated. They're predatory.

i'm still on vacation this is just a scheduled post. ✌️

