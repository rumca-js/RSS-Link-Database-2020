# Source:Snazzy Labs, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w, language:en-US

## macOS Big Sur’s Big Secret
 - [https://www.youtube.com/watch?v=NXG5REBi2fo](https://www.youtube.com/watch?v=NXG5REBi2fo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w
 - date published: 2020-07-01 00:00:00+00:00

The visual changes to macOS Big Sur are actually the small part. Snazzy Labs explains why the Mac will soon gain a touchscreen.

Purchase an iPhone 11 Pro - https://amzn.to/3i0DxzW
Purchase an iPad Pro - https://amzn.to/31cp4Lt
Purchase a MacBook Pro - https://amzn.to/2B93ahB
Subscribe to my podcast Flashback! - http://relay.fm/flashback
Follow me on Twitter - http://twitter.com/snazzyq
Follow me on Instagram - http://instagram.com/snazzyq

Apple announced macOS 11 Big Sur to much surprise this last week at WWDC. Along with the transition to ARM came a bevy of visual changes (we won’t call them upgrades, per se) and the announcement that Apple Silicon Macs would be able to run iOS apps without modification. Not only that, but that Apple would be placing all iPad and iPhone apps available to download in the Apple Silicon Mac App Store by default unless the developer specifically states that they don’t want it listed. A bunch of multi-touch apps and games require touch input, however, and we’re as sure as ever that touchscreen Macs are on the horizon despite Apple’s insistence that they’re not coming soon. We talk about visual indications we’ve found hidden in macOS Big Sur that help argue why macOS Big Sur hidden secrets hint at a touch-capable future. #macOS #BigSur #SnazzyLabs

