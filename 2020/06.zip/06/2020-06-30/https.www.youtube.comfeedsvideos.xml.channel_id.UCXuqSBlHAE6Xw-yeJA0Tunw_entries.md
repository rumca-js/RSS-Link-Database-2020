# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## This is the BEST game controller. Let me explain…
 - [https://www.youtube.com/watch?v=3qlZmXnE1mw](https://www.youtube.com/watch?v=3qlZmXnE1mw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-07-01 00:00:00+00:00

Sign up for Private Internet Access VPN at https://lmg.gg/pialinus2

Save 10% and Free Worldwide Shipping at Ridge Wallets by using offer code LINUS at https://www.ridge.com/LINUS

Is there a middle ground to the controller vs mouse & keyboard war?? Is JoyShockMapper any good? Want to add air mouse functionality and use stuff you already have? That’s what Jibb Smart aimed to do with his development of JoyShockMapper, allowing users to easily integrate the Dual shock 4, Switch pro controller, and Joy Cons into everyday gaming similar to that of the Xbox controller.

Follow JibbSmart: twitter.com/JibbSmart 
JoyShockMapper: https://github.com/JibbSmart/JoyShockMapper
Check out the Wiki: gyrowiki.jibbsmart.com
Check out Jibb's channel: youtube.com/c/GyroGamingJS 

Buy DualShock 4: 
On Amazon (PAID LINK): https://geni.us/YB5V1 
On Newegg (PAID LINK): https://geni.us/olBBAXq

Buy Switch Pro Controller: 
On Amazon (PAID LINK): https://geni.us/B5ZJN 
On Newegg (PAID LINK): https://geni.us/yafCq1

Buy Joy Cons: 
On Amazon (PAID LINK): https://geni.us/68rSbL 
On Newegg (PAID LINK): https://geni.us/aGqTkJi

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://lmg.gg/SoT5W

GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Mech Keyboard: https://geni.us/RecNBTI
NEEDforSEAT Gaming Chairs: https://geni.us/needforseat
Get a Displate Metal Print at https://lmg.gg/displateltt
Use code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Gear on Amazon: https://geni.us/lmgamazon
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0 https://lmg.gg/fxHYK 
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://lmg.gg/Q9yyQ 
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://lmg.gg/8upii

## Ultimate PC Building RACE!
 - [https://www.youtube.com/watch?v=7DhWFIrQeDA](https://www.youtube.com/watch?v=7DhWFIrQeDA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-06-30 00:00:00+00:00

Thanks to GIGABYTE AORUS for sponsoring this video! Check out Intel 10th Gen CPUs at https://geni.us/nak2r

Buy Z490 AORUS PRO AX Motherboards
On Amazon: https://geni.us/ZlIxhxZ
On Newegg: https://geni.us/RpED

Anthony and Linus face off in the first ever Linus Tech Tips PC Building Triathlon. Build, Bench, and Game, who do you think will emerge victorious?

Buy GIGABYTE RTX 2060 SUPER GAMING OC
On GIGABYTE: https://www.gigabyte.com/us/Graphics-Card/GV-N206SGAMINGOC-WHITE-8GC#kf
On Amazon: https://geni.us/jXUu91
On Newegg: https://geni.us/AyFbU4O

Buy AORUS 512GB M.2 SSD
On Amazon: https://geni.us/ZWncnT
On Newegg: https://geni.us/hSTbV

Buy AORUS AIO 240mm Cooler
On Amazon: https://geni.us/EVnu
On Newegg: https://geni.us/Hq3vhFi

Buy AORUS 750W GOLD PSU
On Amazon: https://geni.us/bcVzrZ

Buy GIGABYTE C200G Case
On Amazon: https://geni.us/KFATBeY

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1216338-ultimate-pc-building-race/

GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Mech Keyboard: https://geni.us/RecNBTI
NEEDforSEAT Gaming Chairs: https://geni.us/needforseat
Get a Displate Metal Print at https://lmg.gg/displateltt
Use code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Gear on Amazon: https://geni.us/lmgamazon
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0 https://lmg.gg/fxHYK 
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://lmg.gg/Q9yyQ 
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://lmg.gg/8upii

