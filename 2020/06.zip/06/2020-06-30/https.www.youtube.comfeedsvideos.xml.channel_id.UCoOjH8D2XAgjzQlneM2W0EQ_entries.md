# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## The Economics of CHAZ / CHOP: Anarchy at its Finest
 - [https://www.youtube.com/watch?v=i8l-UxhFew0](https://www.youtube.com/watch?v=i8l-UxhFew0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2020-07-01 00:00:00+00:00

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join 

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
Subscribe to  @Economics Explained  for the inspiration!
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
📸 Follow me on IG:@jaketran // http://bit.ly/jt-ig
👨👦👦 Join the Tran Mafia Family here: https://bit.ly/patreon-jt
💬 Join the community Discord: http://discord.gg/BmK8EnQ

Stuff I use & recommend:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
🏠 The real estate investing course I love & recommend: https://jake.yt/RE
🌐 Most flexible, affordable website hosting: https://jake.yt/bhd
🖥️ Website platform I use & love: https://jake.yt/kd
💽 Editing software I've used for 7+ years: https://jake.yt/ccd
📒 Online bookkeeping software I use& love: https://jake.yt/benchd 
🧾 Best affordable bookkeeping software: https://jake.yt/fbd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd
📚 Get 3 free audiobooks for life: https://amzn.to/2v58PSu
🎥 My video gear, setup, tech, books: https://jake.yt/stored

✉️ Email me: jake@jaketran.io

Subscribe to the backup channel on LBRY, use reward code "jake-cast" for free coin: https://bit.ly/LBRY-jt

📰 Sources & visuals: https://bit.ly/38iq3uV

-----------------------
THIS is the nation of CHAZ, the Capitol Hill Autonomous Zone, who recently changed their name to CHOP. CHAZ is the world’s newest nation and was founded in the heart of Seattle by colonists who ripped away land from the local population. CHAZ was founded on very noble causes. But not so noble was the fact that the moment the nation was formed - a border wall was put up, border patrol guards, a monarch filled the power vacuum etc. 

The root of every country and economy is the government. CHAZ, or CHOP, first identified as an “Autonomous Zone”.  They're modelling the idea of an “Autonomous Zone” coined by Hakim Bey. These autonomous zones can be used as a tactic by anarchists to sneak anarchy into formal society. Or it could be that these dissenters wanted a cool name and just power hungry. 

CHAZ is more of complete chaotic anarchy. Once CHAZ was formed, the Chazians found themselves with a new monarch - a war lord that declared his power, Raz Simone. But Raz isn’t the only one that’s power hungry in CHAZ, as there are other people challenging his rule, leaders trying to organize things in the background.

You know, what do they make, what are they known for, how does this economy make money? We’ll just have to do an estimate. CHAZ strives to be an independent nation with a thriving agricultural industry. Other industries include street markets, bazaars, a very popular street art culture. And of course, you can’t forget about the classic business of extorting local business owners for protection money. Stability is the name of the game. And CHAZ, has none! CHAZ’s economy has one thing that no other nation in the world has - the complete, indisputable support from another gov’t.

Another thing an economy needs is safety. Since CHAZ bans police, they had to build a very elite group of police, medics, and border patrol guards from scratch.  There’s no pesky things like freedom of religion. 

After the recent shootings, the Major claims that they’re gonna take back the police station. If you’re the leaders of CHAZ and you don’t control the violence, if you can’t keep the image of just a peaceful protest - you will be crushed. CHAZ did the smart thing by changing its name from CHAZ, the Capital Hill Autonomous Zone, to CHOP, the Capital Hill “Occupied Protest”. 

Before you start a revolution, make sure you have a detailed plan in place or else things will very quickly descend into chaos
-----------------------

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2020 Jake Tran. All rights reserved.

Music by Chillhop: http://chillhop.com/listen
Listen on Spotify: http://bit.ly/ChillhopSpotify

DISCLAIMER: These videos are for entertainment purposes only. This is not meant to be financial advice. Please always do your due diligence and never stop learning.

AFFILIATE DISCLOSURE: Some of the links in this video description are affiliate links, meaning, at no additional cost to you, I may earn a commission if you click through and make a purchase and/or opt-in. I only promote products that I 100% believe in.

