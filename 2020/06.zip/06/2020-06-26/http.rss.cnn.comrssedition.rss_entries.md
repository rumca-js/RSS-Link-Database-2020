# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Siya Kakkar, teenage TikTok star, has died, her manager confirms
 - [https://www.cnn.com/2020/06/26/entertainment/siya-kakkar-tiktok-dies-scli-intl/index.html](https://www.cnn.com/2020/06/26/entertainment/siya-kakkar-tiktok-dies-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 23:27:01+00:00

Siya Kakkar, a teenage TikTok influencer with a significant fanbase on the video-sharing platform, has died, her manager has said.

## An antibody treatment could be closer than a vaccine
 - [https://www.cnn.com/2020/06/26/health/antibody-therapies-covid-19-update-wellness/index.html](https://www.cnn.com/2020/06/26/health/antibody-therapies-covid-19-update-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 21:22:33+00:00

Vaccines have gotten all the attention in the race to fight Covid-19, but there is a major push in the United States to develop antibody therapies to treat coronavirus. There's so much of a push that some scientists think these treatments may be available this year, even before a vaccine.

## Reporter asks Pence a tricky question
 - [https://www.cnn.com/videos/politics/2020/06/26/pence-coronavirus-task-force-briefing-dana-bash-vietnam-era-bts-nr-vpx.cnn](https://www.cnn.com/videos/politics/2020/06/26/pence-coronavirus-task-force-briefing-dana-bash-vietnam-era-bts-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 21:00:42+00:00

CNN's Dana Bash compares Vice President Mike Pence's remarks at the coronavirus task force briefing to the infamous Vietnam-era 'Five o'clock follies' where the government provided a version of events that were very different from the reality people were seeing.

## Mike Pence pressed on holding campaign events amid pandemic
 - [https://www.cnn.com/videos/politics/2020/06/26/pence-campaign-rally-masks-coronavirus-task-force-sot-vpx.cnn](https://www.cnn.com/videos/politics/2020/06/26/pence-campaign-rally-masks-coronavirus-task-force-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 19:49:52+00:00

Vice President Mike Pence was pressed on the wisdom of holding campaign rallies, even as the administration's own public health experts continue to warn against large public gatherings and as coronavirus cases surge.

## See rare home videos of Michael Jackson
 - [https://www.cnn.com/videos/celebrities/2020/06/26/michael-jackson-daughter-paris-jackson-docuseries-the-soundflowers-orig-kj.cnn](https://www.cnn.com/videos/celebrities/2020/06/26/michael-jackson-daughter-paris-jackson-docuseries-the-soundflowers-orig-kj.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 19:48:05+00:00

Facebook Watch's "Unfiltered: Paris Jackson & Gabriel Glenn" takes viewers on a journey through music and life with Michael Jackson's daughter Paris.

## Sherlock Holmes is too nice in Netflix adaptation, lawsuit argues
 - [https://www.cnn.com/2020/06/26/entertainment/netflix-enola-holmes-sherlock-lawsuit-scli-intl-gbr/index.html](https://www.cnn.com/2020/06/26/entertainment/netflix-enola-holmes-sherlock-lawsuit-scli-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 19:24:25+00:00

Arthur Conan Doyle's estate is suing Netflix, among others, over its upcoming film "Enola Holmes" -- arguing that the show's depiction of Sherlock Holmes as kind, caring and respectful of women is a violation of the author's copyright.

## Dr. Gupta: We are in the middle of a public health disaster
 - [https://www.cnn.com/videos/politics/2020/06/26/coronavirus-task-force-briefing-pence-gupta-bts-crn-vpx.cnn](https://www.cnn.com/videos/politics/2020/06/26/coronavirus-task-force-briefing-pence-gupta-bts-crn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 19:18:38+00:00

CNN's Sanjay Gupta breaks down the White House coronavirus task force briefing in which Vice President Mike Pence said that the reopening economy was encouraging news as cases hit an all-time record in the US.

## Justin Bieber files $20 million defamation lawsuit against women who accused him of assault
 - [https://www.cnn.com/2020/06/26/entertainment/justin-bieber-defamation-lawsuit-assault/index.html](https://www.cnn.com/2020/06/26/entertainment/justin-bieber-defamation-lawsuit-assault/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 19:11:06+00:00

Justin Bieber has filed a $20 million defamation lawsuit against two women who accused him earlier this week of sexual assault.

## Witness in Mueller investigation gets 10 years in prison in child sex case
 - [https://www.cnn.com/2020/06/26/politics/george-nader-prison-sentence-mueller/index.html](https://www.cnn.com/2020/06/26/politics/george-nader-prison-sentence-mueller/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 17:38:04+00:00

George Nader, who was a key witness in the Russia investigation and informally advised President Donald Trump's team on foreign policy, was sentenced on Friday to 10 years in prison by a federal judge in Virginia, stemming from his convictions on child sex charges.

## Germany troop withdrawal highlights rise of two White House allies
 - [https://www.cnn.com/2020/06/26/politics/germany-troop-withdrawal-obrien-grenell-esper-isolation-pentagon-tensions-trump/index.html](https://www.cnn.com/2020/06/26/politics/germany-troop-withdrawal-obrien-grenell-esper-isolation-pentagon-tensions-trump/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 17:30:05+00:00

The White House's plan to withdraw thousands of US troops from Germany is emerging as a new point of tension between the President and top Pentagon leaders, including Defense Secretary Mark Esper, who has avoided criticizing the move publicly but has significant concerns about it, multiple current and former officials tell CNN.

## Wrongly arrested man sues police
 - [https://www.cnn.com/videos/us/2020/06/26/wrongful-arrest-black-man-georgia-valdosta-orig-jba.cnn](https://www.cnn.com/videos/us/2020/06/26/wrongful-arrest-black-man-georgia-valdosta-orig-jba.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 17:29:17+00:00

Video shows the moment police in Valdosta, Georgia slammed a man to the ground and broke his wrist before it turned out that he was not the person they were looking for.

## NASA is offering $35,000 to design a toilet that will work on the moon
 - [https://www.cnn.com/2020/06/26/tech/nasa-moon-toilet-scn-trnd/index.html](https://www.cnn.com/2020/06/26/tech/nasa-moon-toilet-scn-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 17:24:30+00:00

NASA wants you to help put the loo in lunar, so it's offering $35,000 in prizes to design a toilet that can be used on the moon.

## Photos show the Cape Town you don't usually see
 - [https://www.cnn.com/travel/article/cape-town-photography-unfiltered-spc-intl/index.html](https://www.cnn.com/travel/article/cape-town-photography-unfiltered-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 15:57:43+00:00

When you think of Cape Town, what do you imagine? Perhaps you picture Table Mountain, penguins on the sand, or the stunning beaches that surround this city.

## This major cruise ship is headed for the scrap heap amid Covid-19 crisis
 - [https://www.cnn.com/travel/article/costa-victoria-carnival-retire-ships/index.html](https://www.cnn.com/travel/article/costa-victoria-carnival-retire-ships/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 15:25:40+00:00

A major cruise liner with only 23 years of service has been earmarked for the scrap heap amid a coronavirus-driven downturn for the leisure shipping industry.

## Satellite images show buildup at site of deadly India-China border clash
 - [https://www.cnn.com/collections/intl-india-china-tensions-0626/](https://www.cnn.com/collections/intl-india-china-tensions-0626/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 11:37:13+00:00



## Endless summers of the communist riviera
 - [https://www.cnn.com/travel/article/hungary-lake-balaton-communist-riviera/index.html](https://www.cnn.com/travel/article/hungary-lake-balaton-communist-riviera/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 10:15:29+00:00

During the communist era, travel options were limited in Hungary and Central Europe, which meant Lake Balaton became the region's most popular vacation destination.

## America reports nearly 40,000 new Covid-19 cases in highest single-day rise
 - [https://www.cnn.com/world/live-news/coronavirus-pandemic-06-26-20-intl/index.html](https://www.cnn.com/world/live-news/coronavirus-pandemic-06-26-20-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 10:01:48+00:00

• Behind California's massive surge in cases
• The CDC reveals a 'stunning' new statistic
• Bill Gates: US 'not even close' to doing enough to fight pandemic

## How this Long Island man ended up in a Chinese prison on espionage charges
 - [https://www.cnn.com/2020/06/25/asia/us-china-detention-li-kai-intl-hnk/index.html](https://www.cnn.com/2020/06/25/asia/us-china-detention-li-kai-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 09:58:21+00:00

Driving from their home in New York to Cambridge, Massachusetts, Harrison Li had no idea it would be the last time he saw his father for more than a decade.

## Ex-F1 supremo Bernie Ecclestone: 'In lots of cases Black people are more racist than White people'
 - [https://www.cnn.com/2020/06/26/motorsport/bernie-ecclestone-formula-one-motorsport-lewis-hamilton-spt-intl/index.html](https://www.cnn.com/2020/06/26/motorsport/bernie-ecclestone-formula-one-motorsport-lewis-hamilton-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 09:39:05+00:00

Bernie Ecclestone is credited with transforming Formula One into a global, billion-dollar business with races in all corners of the world, but like many organizations, the sport he helped create has come under scrutiny following George Floyd's death.

## How a bespectacled man-hugger guided a once-great team back to triumph
 - [https://www.cnn.com/collections/liverpool-premier-league-win-intl/](https://www.cnn.com/collections/liverpool-premier-league-win-intl/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 09:28:02+00:00



## White supremacists openly organize racist violence on Telegram, report finds
 - [https://www.cnn.com/2020/06/26/tech/white-supremacists-telegram-racism-intl/index.html](https://www.cnn.com/2020/06/26/tech/white-supremacists-telegram-racism-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 09:14:40+00:00

On June 5, a car full of White supremacists drove through the streets of Knoxville, Tennessee, harassing and abusing people attending a Black Lives Matter protest. One of those in the car shouted to a group of protesters: "You wanna die? Come on in. 9mm with your name on it."

## Ramen pizza? Crazy mashup revealed by Pizza Hut Taiwan
 - [https://www.cnn.com/travel/article/pizza-hut-ramen-pizza/index.html](https://www.cnn.com/travel/article/pizza-hut-ramen-pizza/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 09:10:08+00:00

You may need chopsticks for this pizza.

## This is the noose that was found in Bubba Wallace's garage stall
 - [https://www.cnn.com/2020/06/25/us/nascar-noose-investigation-complete-trnd/index.html](https://www.cnn.com/2020/06/25/us/nascar-noose-investigation-complete-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 09:01:33+00:00

NASCAR has released a photo of the noose that was found hanging in Bubba Wallace's team garage at the Talladega Superspeedway last week.

## US Senate passes new sanctions to punish China over Hong Kong
 - [https://www.cnn.com/2020/06/25/politics/sanction-china-hong-kong-us-senate/index.html](https://www.cnn.com/2020/06/25/politics/sanction-china-hong-kong-us-senate/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 08:59:32+00:00

The Senate passed a pair of bills by unanimous consent Thursday that would punish China for moves its making that lawmakers fear will crush democratic freedoms in Hong Kong.

## Four years after Brexit vote, support for the EU surges in Britain
 - [https://www.cnn.com/2020/06/25/uk/uk-supports-eu-four-years-after-brexit-intl-gbr/index.html](https://www.cnn.com/2020/06/25/uk/uk-supports-eu-four-years-after-brexit-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 08:56:31+00:00

Four years on from the UK's Brexit vote, a majority of British voters would now opt to remain inside the European Union, says new research.

## Changing doubters to believers. How Jurgen Klopp turned Liverpool into title winners
 - [https://www.cnn.com/2020/06/25/football/jurgen-klopp-liverpool-premier-league-title-spt-int/index.html](https://www.cnn.com/2020/06/25/football/jurgen-klopp-liverpool-premier-league-title-spt-int/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 08:20:24+00:00

After 30 years of waiting, Liverpool are once again England's dominant team. The champions of Europe are now English Premier League winners, guided to the summit by their gregarious German manager, the bespectacled man-hugger extraordinaire who has captivated the city and the club.

## Ex-officer who fatally shot Rayshard Brooks shot a suspect three times in 2015 and was concerned he'd face charges
 - [https://www.cnn.com/2020/06/26/us/rayshard-brooks-garrett-rolfe-2015-three-shots/index.html](https://www.cnn.com/2020/06/26/us/rayshard-brooks-garrett-rolfe-2015-three-shots/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 08:14:15+00:00

The former Atlanta police officer who fatally shot Rayshard Brooks was concerned he would face charges after firing three shots during a 2015 car chase and arrest, according to dash camera footage obtained by CNN.

## YouTube influencer quits her channel after blackface backlash
 - [https://www.cnn.com/2020/06/26/entertainment/jenna-marbles-quits-youtube-intl-hnk-scli/index.html](https://www.cnn.com/2020/06/26/entertainment/jenna-marbles-quits-youtube-intl-hnk-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 07:44:53+00:00

YouTube star Jenna Mourey, known by her channel name Jenna Marbles, announced Thursday she is leaving the platform amid a controversy over racially offensive videos.

## 'Major incident' declared as thousands flock to UK beaches
 - [https://www.cnn.com/travel/article/bournemouth-major-incident-beaches-scli-intl-gbr/index.html](https://www.cnn.com/travel/article/bournemouth-major-incident-beaches-scli-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 07:36:43+00:00

Officials in southern England have declared a "major incident" after thousands of people flocked to local beaches.

## Trump's post-Covid bubble is popping
 - [https://www.cnn.com/collections/trump-0626-itnl/](https://www.cnn.com/collections/trump-0626-itnl/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 07:08:50+00:00



## China loves John Bolton's book for embarrassing Trump, but not the parts about Xi Jinping
 - [https://www.cnn.com/2020/06/25/asia/china-john-bolton-book-intl-hnk/index.html](https://www.cnn.com/2020/06/25/asia/china-john-bolton-book-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 07:08:19+00:00

It's safe to say former White House national security adviser John Bolton's book has made a splash.

## Japan resumes flights to Vietnam for the first time since coronavirus travel restrictions
 - [https://www.cnn.com/travel/article/japan-vietnam-travel-intl-hnk/index.html](https://www.cnn.com/travel/article/japan-vietnam-travel-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 06:16:29+00:00

A planeful of Japanese business travelers landed in Vietnam on June 25, marking the first flight between the two countries since they imposed border restrictions in a bid to stop the spread of coronavirus.

## Trump's post-Covid bubble is popping
 - [https://www.cnn.com/2020/06/26/politics/donald-trump-coronavirus-single-worst-day-new-cases/index.html](https://www.cnn.com/2020/06/26/politics/donald-trump-coronavirus-single-worst-day-new-cases/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 05:22:56+00:00

• Analysis: Trump entrenched in failed strategy as aides and allies try to encourage a pivot
• Analysis: Trump may face landslide loss

## Chinese city launches domestic violence database for couples planning to get married
 - [https://www.cnn.com/2020/06/26/asia/china-domestic-violence-database-intl-hnk-scli/index.html](https://www.cnn.com/2020/06/26/asia/china-domestic-violence-database-intl-hnk-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 04:48:48+00:00

A city in eastern China is launching a database for people considering marriage to check the domestic violence records of their partner.

## Wrongly arrested Black man sues a Georgia city and police officers for excessive force and injury
 - [https://www.cnn.com/2020/06/26/us/valdosta-wrongly-arrested-black-man-sues-police/index.html](https://www.cnn.com/2020/06/26/us/valdosta-wrongly-arrested-black-man-sues-police/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 04:25:31+00:00

A Black man who was slammed to the ground as he was wrongly arrested is suing the Georgia city of Valdosta and numerous Valdosta Police Department officers for excessive force and for violating his civil rights, according to court documents.

## Trump administration asks Supreme Court to invalidate Obamacare
 - [https://www.cnn.com/2020/06/25/politics/trump-administration-obamacare-supreme-court/index.html](https://www.cnn.com/2020/06/25/politics/trump-administration-obamacare-supreme-court/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 04:16:43+00:00

In the midst of a global pandemic with the presidential election just months away, the Justice Department asked the Supreme Court on Thursday to invalidate the Affordable Care Act, the landmark health care law that enabled millions of Americans to get insurance coverage and that remains in effect despite the pending legal challenge.

## Military called in after TikTok 'tea war' goes global
 - [https://www.cnn.com/travel/article/tiktok-tea-diplomatic-incident/index.html](https://www.cnn.com/travel/article/tiktok-tea-diplomatic-incident/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 02:49:10+00:00

You'll remember the Boston Tea Party of 1773, when American revolutionaries famously trolled the British by throwing chests of tea into Boston Harbor.

## What you need to know about China's national security law in Hong Kong
 - [https://www.cnn.com/2020/06/25/asia/hong-kong-national-security-law-explainer-intl-hnk-scli/index.html](https://www.cnn.com/2020/06/25/asia/hong-kong-national-security-law-explainer-intl-hnk-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 02:27:29+00:00

China is introducing a sweeping national security law for Hong Kong that has sparked protest, fear and controversy in the semi-autonomous city.

## Bill Gates predicted the pandemic. Hear his advice now.
 - [https://www.cnn.com/videos/health/2020/06/26/bill-gates-virus-prediction-advice-town-hall-vpx.cnn](https://www.cnn.com/videos/health/2020/06/26/bill-gates-virus-prediction-advice-town-hall-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 02:22:18+00:00

Microsoft founder Bill Gates discusses his pandemic prediction, and why the US is struggling to contain the coronavirus.

## Court dismisses motion by Trump's brother to block tell-all book by President's niece
 - [https://www.cnn.com/2020/06/25/media/mary-trump-book-court/index.html](https://www.cnn.com/2020/06/25/media/mary-trump-book-court/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 02:04:57+00:00

A judge on Thursday dismissed an attempt by President Trump's younger brother to block the publication of a forthcoming unflattering tell-all book by Mary L. Trump, the President's niece.

## City councilman among 4 facing voter fraud charges in New Jersey
 - [https://www.cnn.com/2020/06/25/politics/new-jersey-attorney-general-announces-voting-fraud-charges/index.html](https://www.cnn.com/2020/06/25/politics/new-jersey-attorney-general-announces-voting-fraud-charges/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 01:33:19+00:00

A city councilman and a councilman-elect are among the four people charged with voting fraud related to the May 12 municipal election, New Jersey Attorney General Gurbir Grewal announced Thursday.

## Dr. Sanjay Gupta shows how to stay safe on a road trip
 - [https://www.cnn.com/videos/health/2020/06/26/road-trip-safety-coronavirus-gupta-cnn-town-hall-sot-vpx.cnn](https://www.cnn.com/videos/health/2020/06/26/road-trip-safety-coronavirus-gupta-cnn-town-hall-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 01:28:44+00:00

With the summer travel season in full swing and the Fourth of July approaching, CNN's Dr. Sanjay Gupta demonstrates how to stay safe on a road trip as the number of Covid-19 cases are on the rise in many states.

## Bill Gates: US 'not even close' to doing enough to fight pandemic
 - [https://www.cnn.com/2020/06/25/us/bill-gates-coronavirus-town-hall-us/index.html](https://www.cnn.com/2020/06/25/us/bill-gates-coronavirus-town-hall-us/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 01:27:04+00:00

Microsoft founder Bill Gates said Thursday that the current coronavirus picture, both globally and in the US, is "more bleak" than he would have expected.

## House approves police reform bill named in honor of George Floyd
 - [https://www.cnn.com/2020/06/25/politics/house-police-reform-legislation-vote/index.html](https://www.cnn.com/2020/06/25/politics/house-police-reform-legislation-vote/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 00:57:29+00:00

The House of Representatives on Thursday passed policing legislation named in honor of George Floyd, whose death in police custody has sparked nationwide calls to address police misconduct and racial injustice and prompted weeks of protests and civil unrest.

## The Dixie Chicks are now called The Chicks
 - [https://www.cnn.com/videos/entertainment/2020/06/25/dixie-chicks-change-name-the-chicks-orig-llr-kj.cnn](https://www.cnn.com/videos/entertainment/2020/06/25/dixie-chicks-change-name-the-chicks-orig-llr-kj.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-26 00:17:11+00:00

The former Dixie Chicks announced they will now be known as The Chicks, dropping the reference to the pre-Civil War South from the group's name.

