# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## CNN [#187] Mamy trzech przeciwników!
 - [https://www.youtube.com/watch?v=JyEtqenqvCo](https://www.youtube.com/watch?v=JyEtqenqvCo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-06-27 00:00:00+00:00

#cnn #kazaniedookienka @Langusta na palmie 
Kazanie XIII Niedzielę zwykłą, Rok A

1. czytanie (2 Krl 4, 8-12a. 14-16a)

Pewnego dnia Elizeusz przechodził przez Szunem. Była tam kobieta bogata, która zawsze nakłaniała go do spożycia posiłku. Ilekroć więc przechodził, udawał się tam, by spożyć posiłek. Powiedziała ona do swego męża: «Oto jestem przekonana, że świętym mężem Bożym jest ten, który ciągle do nas przychodzi. Przygotujmy mały pokój na górze, obmurowany, i wstawmy tam dla niego łóżko, stół, krzesło i lampę. Kiedy przyjdzie do nas, to tam się uda».

Gdy więc pewnego dnia Elizeusz tam przyszedł, udał się na górę i tam ułożył się do snu. I powiedział do Gechaziego, swojego sługi: «Co można uczynić dla tej kobiety?» Odpowiedział Gechazi: «Niestety, ona nie ma syna, a mąż jej jest stary». Rzekł więc: «Zawołaj ją!» Zawołał ją i stanęła przed wejściem. I powiedział: «O tej porze za rok będziesz pieściła syna».

2. czytanie (Rz 6, 3-4. 8-11)

Bracia: My wszyscy, którzy otrzymaliśmy chrzest zanurzający w Chrystusa Jezusa, zostaliśmy zanurzeni w Jego śmierć. Zatem przez chrzest zanurzający nas w śmierć zostaliśmy razem z Nim pogrzebani po to, abyśmy i my postępowali w nowym życiu – jak Chrystus powstał z martwych dzięki chwale Ojca.

Otóż, jeżeli umarliśmy razem z Chrystusem, wierzymy, że z Nim również żyć będziemy, wiedząc, że Chrystus, powstawszy z martwych, już więcej nie umiera, śmierć nad Nim nie ma już władzy. Bo to, że umarł, umarł dla grzechu tylko raz, a że żyje, żyje dla Boga. Tak i wy rozumiejcie, że umarliście dla grzechu, żyjecie zaś dla Boga w Chrystusie Jezusie.

Ewangelia (Mt 10, 37-42)

Jezus powiedział do swoich apostołów: «Kto kocha ojca lub matkę bardziej niż Mnie, nie jest Mnie godzien. I kto kocha syna lub córkę bardziej niż Mnie, nie jest Mnie godzien. Kto nie bierze swego krzyża, a idzie za Mną, nie jest Mnie godzien. Kto chce znaleźć swe życie, straci je, a kto straci swe życie z mego powodu, znajdzie je.

Kto was przyjmuje, Mnie przyjmuje; a kto Mnie przyjmuje, przyjmuje Tego, który Mnie posłał.

Kto przyjmuje proroka jako proroka, nagrodę proroka otrzyma. Kto przyjmuje sprawiedliwego jako sprawiedliwego, nagrodę sprawiedliwego otrzyma.

Kto poda kubek świeżej wody do picia jednemu z tych najmniejszych, dlatego że jest uczniem, zaprawdę, powiadam wam, nie utraci swojej nagrody».
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Ksiądz gra w grę: Detroit Become Human [#06] Emocje czy rozum?
 - [https://www.youtube.com/watch?v=D_VtucTgwaQ](https://www.youtube.com/watch?v=D_VtucTgwaQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-06-27 00:00:00+00:00

@Langustanapalmie  #detroitbecomehuman #ksiądzgrawgrę
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Miriam [#42] Królowa bez zmazy pierworodnej poczęta
 - [https://www.youtube.com/watch?v=BZ0TbrHaj6I](https://www.youtube.com/watch?v=BZ0TbrHaj6I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-06-27 00:00:00+00:00

#Miriam #litanialoretańska  @Langustanapalmie 
________________________________________
Komentarze do wezwań Litanii Loretańskiej. 

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#542] Radość
 - [https://www.youtube.com/watch?v=1M-NqqXTqRw](https://www.youtube.com/watch?v=1M-NqqXTqRw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-06-27 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał  

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Ksiądz gra w grę: Uncharted Zaginione Dziedzictwo [#06] Nie buduj na kłamstwie!
 - [https://www.youtube.com/watch?v=AdODlbxPfLQ](https://www.youtube.com/watch?v=AdODlbxPfLQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-06-26 00:00:00+00:00

@Langusta na palmie   #ksiądzgrawgrę #uncharted 
________________________________________
Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Miniaturkę stworzył dla nas: Sebastian Gwóźdź

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#541] Droga
 - [https://www.youtube.com/watch?v=FVSf651kLPw](https://www.youtube.com/watch?v=FVSf651kLPw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-06-26 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał  

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

