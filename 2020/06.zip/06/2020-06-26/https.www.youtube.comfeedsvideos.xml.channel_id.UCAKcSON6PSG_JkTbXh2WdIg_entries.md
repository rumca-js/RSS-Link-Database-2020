# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Remo Drive - full 2019 session at The Current
 - [https://www.youtube.com/watch?v=0ZWpiyZs_rk](https://www.youtube.com/watch?v=0ZWpiyZs_rk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-06-26 00:00:00+00:00

On Friday, June 26, Remo Drive will release "A Portrait of an Ugly Man," their third studio album. With that in mind, here are three songs from Remo Drive's most recent session in our studio, recorded in May 2019.

SONGS PERFORMED
00:00 "Two Bux"
02:33 "The Grind"
06:04 "The Devil"

PERSONNEL
Erik Paulson – guitar and vocals
Stephen Paulson - bass
Sam Becht - drums

CREDITS
Video & Photo: Nate Ryan, Mary Mathis
Audio: Michael DeMark, Adam Biel
Production: Derrick Stevens

FIND MORE:
2019 studio session: https://www.thecurrent.org/feature/2019/05/29/remo-drive-kick-out-a-rocking-set-in-the-current-studio

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## The Beths - Live Virtual Session for The Current
 - [https://www.youtube.com/watch?v=3epSK-AVzFg](https://www.youtube.com/watch?v=3epSK-AVzFg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-06-26 00:00:00+00:00

Elizabeth Stokes and Jonathan Pearce of The Beths join Jade of The Current for a live virtual session.

Songs performed:
10:25 "I’m Not Getting Excited"
21:25 "Future Me Hates Me"

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

