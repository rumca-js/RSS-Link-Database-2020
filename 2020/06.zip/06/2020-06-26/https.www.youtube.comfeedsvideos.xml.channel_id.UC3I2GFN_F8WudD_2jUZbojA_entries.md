# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## The New Pornographers - Dreamlike And On The Rush (Live on KEXP)
 - [https://www.youtube.com/watch?v=6n0K8h2mAkg](https://www.youtube.com/watch?v=6n0K8h2mAkg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-06-26 00:00:00+00:00

http://KEXP.ORG presents The New Pornographers performing "Dreamlike And On The Rush" live in the KEXP studio. Recorded January 30, 2020.

Host:Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
http://www.thenewpornographers.com

## The New Pornographers - Falling Down The Stairs Of Your Smile (Live on KEXP)
 - [https://www.youtube.com/watch?v=6fSQ_E0qSLk](https://www.youtube.com/watch?v=6fSQ_E0qSLk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-06-26 00:00:00+00:00

http://KEXP.ORG presents The New Pornographers performing "Falling Down The Stairs Of Your Smile" live in the KEXP studio. Recorded January 30, 2020.

Host:Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
http://www.thenewpornographers.com

## The New Pornographers - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=WhHtWOUQf-o](https://www.youtube.com/watch?v=WhHtWOUQf-o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-06-26 00:00:00+00:00

http://KEXP.ORG presents The New Pornographers performing live in the KEXP studio. Recorded January 30, 2020.

Songs:
Falling Down The Stairs Of Your Smile
The Surprise Knock
Higher Beams
You Won't Need Those Where You're Going
Dreamlike And On The Rush

Host:Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
http://www.thenewpornographers.com

## The New Pornographers - Higher Beams (Live on KEXP)
 - [https://www.youtube.com/watch?v=FOeBuKBRe7Q](https://www.youtube.com/watch?v=FOeBuKBRe7Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-06-26 00:00:00+00:00

http://KEXP.ORG presents The New Pornographers performing "Higher Beams" live in the KEXP studio. Recorded January 30, 2020.

Host:Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
http://www.thenewpornographers.com

## The New Pornographers - The Surprise Knock (Live on KEXP)
 - [https://www.youtube.com/watch?v=9zVFo-XY55w](https://www.youtube.com/watch?v=9zVFo-XY55w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-06-26 00:00:00+00:00

http://KEXP.ORG presents The New Pornographers performing "The Surprise Knock" live in the KEXP studio. Recorded January 30, 2020.

Host:Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
http://www.thenewpornographers.com

## The New Pornographers - You Won't Need Those Where You're Going (Live on KEXP)
 - [https://www.youtube.com/watch?v=x-MXhBUPMA4](https://www.youtube.com/watch?v=x-MXhBUPMA4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-06-26 00:00:00+00:00

http://KEXP.ORG presents The New Pornographers performing "You Won't Need Those Where You're Going" live in the KEXP studio. Recorded January 30, 2020.

Host:Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
http://www.thenewpornographers.com

