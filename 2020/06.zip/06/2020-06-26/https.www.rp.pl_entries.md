## Eksperyment Kentlera. Jak w Niemczech przekazywano dzieci pedofilom
 - [https://www.rp.pl/spoleczenstwo/art654161-eksperyment-kentlera-jak-w-niemczech-przekazywano-dzieci-pedofilom](https://www.rp.pl/spoleczenstwo/art654161-eksperyment-kentlera-jak-w-niemczech-przekazywano-dzieci-pedofilom)
 - RSS feed: https://www.rp.pl
 - date published: 2020-06-26 07:32:08+00:00

Eksperyment Kentlera. Jak w Niemczech przekazywano dzieci pedofilom

