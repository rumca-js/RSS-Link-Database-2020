# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Jon Stewart Asks Joe Rogan About Health and Personal Responsibility
 - [https://www.youtube.com/watch?v=h1RrJfOtGKQ](https://www.youtube.com/watch?v=h1RrJfOtGKQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-26 00:00:00+00:00

Taken from JRE #1498 w/Jon Stewart: https://youtu.be/SXOUCRLW2UI

## Jon Stewart Talks With Joe Rogan About His Switch to a Plant-Based Diet
 - [https://www.youtube.com/watch?v=Gz9qT4pdh7U](https://www.youtube.com/watch?v=Gz9qT4pdh7U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-26 00:00:00+00:00

Taken from JRE #1498 w/Jon Stewart: https://youtu.be/SXOUCRLW2UI

## Jon Stewart and Joe Rogan: Wearing Masks and Weathering Online Criticism
 - [https://www.youtube.com/watch?v=woB8hGu9cFk](https://www.youtube.com/watch?v=woB8hGu9cFk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-26 00:00:00+00:00

Taken from JRE #1498 w/Jon Stewart: https://youtu.be/SXOUCRLW2UI

## Jon Stewart on George Floyd Protests, Enacting Change | Joe Rogan
 - [https://www.youtube.com/watch?v=wHf2ewxMblU](https://www.youtube.com/watch?v=wHf2ewxMblU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-26 00:00:00+00:00

Taken from JRE #1498 w/Jon Stewart: 
https://youtu.be/SXOUCRLW2UI

## Jon Stewart's Advocacy for Veterans Exposed to Toxic Waste in Iraq and Afghanistan | Joe
 - [https://www.youtube.com/watch?v=HNASvb1gXLY](https://www.youtube.com/watch?v=HNASvb1gXLY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-26 00:00:00+00:00

Taken from JRE #1498 w/Jon Stewart: 
https://youtu.be/SXOUCRLW2UI

## What the 2008 Financial Collapse Shows Us About Coronavirus Financial Crisis w/Jon Stewart
 - [https://www.youtube.com/watch?v=tMCJbu3IwIQ](https://www.youtube.com/watch?v=tMCJbu3IwIQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-26 00:00:00+00:00

Taken from JRE #1498 w/Jon Stewart: 
https://youtu.be/SXOUCRLW2UI

## Why Jon Stewart Retired from The Daily Show | Joe Rogan
 - [https://www.youtube.com/watch?v=EvxxAHZe-V8](https://www.youtube.com/watch?v=EvxxAHZe-V8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-26 00:00:00+00:00

Taken from JRE #1498 w/Jon Stewart:
https://youtu.be/SXOUCRLW2UI

