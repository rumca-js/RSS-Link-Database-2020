# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Become Awake Now! | Eckhart Tolle & Russell Brand - Full Episode
 - [https://www.youtube.com/watch?v=6EwzvKF-o_Y](https://www.youtube.com/watch?v=6EwzvKF-o_Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-06-27 00:00:00+00:00

You can listen to my #UnderTheSkin podcast right now on Luminary - get the app via this special Eckhart promo link: http://luminary.link/tolle There's a new podcast every Saturday! 

Eckhart teaches that Presence is available to us in every moment, but we all know how the demands of daily life can feel distracting, chaotic, and overwhelming. Deepening Into Stillness: 7 Days of Teachings and Meditations with Eckhart Tolle and Kim Eng, will allow you to heighten your awareness of stillness and bring presence into every area of your life. Receive your gift here: https://eckharttolle.com/deepening-into-stillness/

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at http://apple.co/russell 

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary.

SEE ME LIVE! Check out my live events and buy tickets here https://www.russellbrand.com/live-dates/ 

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/AwakeningWithRussell

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

## Why The Left Can't Handle Donald Trump | Russell Brand
 - [https://www.youtube.com/watch?v=YofLsS3vfOU](https://www.youtube.com/watch?v=YofLsS3vfOU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-06-26 00:00:00+00:00

Why The Left can't handle Donald Trump - are the media underestimating him? What do you think?

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

