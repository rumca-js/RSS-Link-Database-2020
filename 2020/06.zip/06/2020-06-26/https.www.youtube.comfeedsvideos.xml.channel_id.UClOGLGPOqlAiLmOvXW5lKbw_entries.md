# Source:Mandalore Gaming, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw, language:en-US

## Brigador Review
 - [https://www.youtube.com/watch?v=5bp3ivWv7Vs](https://www.youtube.com/watch?v=5bp3ivWv7Vs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw
 - date published: 2020-06-26 00:00:00+00:00

GREAT LEADER IS DEAD. SOLO NOBRE MUST FALL.
My Brigador review covers the Up-Armored Edition which everyone got updated for free anyways. 
Support the channel at: https://www.patreon.com/mandaloregaming or https://www.paypal.me/MandaloreGaming
I take video suggestions at mandaloremovies@gmail.com
Twitter: https://twitter.com/Lord_Mandalore

Game is officially double endorsed by @SsethTzeentach 

#Brigador #BrigadorPC #BrigadorReview #BrigadorUpArmoredEdition #BrigadorGameplay #SoloNobreMustFall

00:00 - Intro
00:42 - Game Premise
1:32 - Controls
3:01 - Visuals
6:12 - Music & Sound Design
8:51 - Gameplay Mechanics
13:50 - Story & Writing
14:55 - Conclusions & Appeals
16:07 - Credits
17:13 - The Most Powerful Horn

