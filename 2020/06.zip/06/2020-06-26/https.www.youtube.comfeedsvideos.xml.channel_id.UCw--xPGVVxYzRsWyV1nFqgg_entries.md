# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Wheel Of Time Casting x2👨‍👨‍👧 Cyberpunk 2077 Netflix Show📽️ Author Accusations - FANTASY NEWS
 - [https://www.youtube.com/watch?v=UL96HuvMYWs](https://www.youtube.com/watch?v=UL96HuvMYWs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-06-27 00:00:00+00:00

Let's jump into what will without a doubt be the most controversial fantasy news to date. Oh boy! 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

NEWS: 

Last of Us Two Sales: https://www.eurogamer.net/articles/2020-06-26-the-last-of-us-part-2-sold-4m-copies-in-two-days

Wheel of Time Casting Part 1: https://twitter.com/WOTonPrime/status/1275842452990001152?s=19

https://twitter.com/WOTonPrime/status/1275842455967985670

Wheel of Time Casting Part 2: https://redanianintelligence.com/2020/06/26/amazons-wheel-of-time-adds-five-new-cast-members/

Warcraft What Would Have Happened: https://www.eurogamer.net/articles/2020-06-24-warcraft-movie-director-outlines-what-would-have-happened-in-the-trilogy

Magic School Bus: https://www.thewrap.com/elizabeth-banks-hops-aboard-the-magic-school-bus-live-action-film-as-ms-frizzle/

Dune Leaks: https://twitter.com/DuneNews/status/1276217415077179394

CyberPunk Midnight Wire: https://www.youtube.com/watch?v=ToWfeUEAeeQ&feature=youtu.be

Pierce Sanderson event: https://www.eventbrite.com/e/pp-live-tamora-pierce-brandon-sanderson-tempests-slaughter-starsight-tickets-110330585752?utm-medium=discovery&utm-campaign=social&utm-content=attendeeshare&aff=escb&utm-source=cp&utm-term=listing

Edgerunners Cyberpunk 2077: https://www.youtube.com/watch?v=E7dKVCw7bkE

D&D No more evil races: https://www.pcgamer.com/dandd-is-trying-to-move-away-from-racial-stereotypes/?utm_content=buffereaf2d&utm_medium=social&utm_source=twitter&utm_campaign=buffer-pcgamertw

The Burning Gods Excerpts: https://twitter.com/kuangrf/status/1275868537509359617?s=12

Avengers Trailer: https://www.youtube.com/watch?v=BN21FhykXyQ

George R R Martin Blog Post: https://twitter.com/GRRMspeaking/status/1275813621751259137

## Wheel of Time Show - What They Can't Change!
 - [https://www.youtube.com/watch?v=v3HGG1XTNIM](https://www.youtube.com/watch?v=v3HGG1XTNIM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-06-26 00:00:00+00:00

We got another wheel of time rant here boys! Here is me spewing thought on what they should NOT change for the upcoming wheel of time show. 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

