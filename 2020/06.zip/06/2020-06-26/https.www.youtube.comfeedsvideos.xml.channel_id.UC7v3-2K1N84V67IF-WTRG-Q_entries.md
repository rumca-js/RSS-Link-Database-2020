# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## The Last of Us Part II - SPOILER Talk
 - [https://www.youtube.com/watch?v=sMSlH802M34](https://www.youtube.com/watch?v=sMSlH802M34)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-06-27 00:00:00+00:00

Now I dive into the spoiler-ish things. This video came across more negative than I intended, but GOOD NEWS!....2020 is almost half way done!

#TLOU2 #TheLastOfUs2

