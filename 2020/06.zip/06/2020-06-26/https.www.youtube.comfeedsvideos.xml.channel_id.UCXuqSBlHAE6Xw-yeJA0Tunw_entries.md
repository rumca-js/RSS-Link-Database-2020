# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Building a FULL Streaming Setup on the Cheap!
 - [https://www.youtube.com/watch?v=L6ZJaKqALgM](https://www.youtube.com/watch?v=L6ZJaKqALgM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-06-27 00:00:00+00:00

Thanks to OWN3D.tv for sponsoring this video! Jumpstart your stream with assets and tools from OWN3D.tv, use code LINUS to get 50% off at https://geni.us/own3d

Streaming or online content creation can be a seemingly VERY expensive endeavour, so today, we explore some cheap or free options so you can get started streaming today!

Buy the Logitech C270:
On Amazon (PAID LINK): https://geni.us/xxgS 
On Newegg (PAID LINK): https://geni.us/9YiVo2J

Buy Clamp Lights:
On Amazon (PAID LINK): https://geni.us/A2Vi
On Newegg (PAID LINK): https://geni.us/g048O

Buy FiFine K669: 
On AliExpress: https://geni.us/osfzJ

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1215072-building-a-full-streaming-setup-on-the-cheap-sponsored/

GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Mech Keyboard: https://geni.us/RecNBTI
NEEDforSEAT Gaming Chairs: https://geni.us/needforseat
Get a Displate Metal Print at https://lmg.gg/displateltt
Use code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Gear on Amazon: https://geni.us/lmgamazon
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0 https://lmg.gg/fxHYK 
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://lmg.gg/Q9yyQ 
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://lmg.gg/8upii

## Intel... What the HECK are you DOING?? - WAN Show June 26, 2020
 - [https://www.youtube.com/watch?v=YcZfBeFmWOE](https://www.youtube.com/watch?v=YcZfBeFmWOE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-06-26 00:00:00+00:00

Use offer code LINUSTECH to get 15% off everything at https://sewelldirect.com/collections/packs

Get the Anker PowerExpand 7-in-2 USB-C Adapter on Amazon (PAID LINK) at https://geni.us/5iIa

Pay what you want and donate on a new pair of sneakers at https://www.vessifootwear.com/linustechtips 

Buy an LTT shirt, hoodie, hat, and even our own water bottle at https://lmg.gg/wanlttstore

Check out Carpool Critics, our new movie podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Podcast Download: https://dts.podtrac.com/redirect.mp3/traffic.libsyn.com/secure/linustechtips/Intel..._What_the_HECK_are_you_DOING_-_WAN_Show_June_26_2020.mp3

Timestamps: (Courtesy of Michael O'Brien)

00:00:00 - Video Start
00:00:02 - Welcome! Second Time's a Charm! OBS problems like last week caused a 04:12 failed stream :( 
 00:00:16 - Twitch Ban teaser
 00:00:46 - Microsoft teaser #1
 00:01:06 - Intel teaser + Linus' angst
 00:01:39 - Microsoft teaser #2 + scripted surprise ;)
00:02:11 - ROLL INTRO!
 00:02:33 - Lucky Sponsors
 00:02:53 - Faux start
00:03:19 - Topic #1: Intel's misleading marketing slides
 00:08:43 - Calulator napkin math
 00:10:03 - Evil or Stupid?
 00:11:06 - They shouldn't have done it. Overall credibility loss
 00:14:26 - Transistor design optimization on process node
 00:15:35 - Honest truth & intelligence conflated with biased marketing
 00:20:23 - rant & why Intel's metrics are wrong/right-ish/wrong
 00:29:58 - Luke chimes in
 00:33:34 - Fundamental issue recap
00:38:24 - Topic #2: Dr DisRespect ban on Twitch
 00:39:02 - Disclaimer & Platform responsibility
 00:40:45 - What that means
 00:41:55 - Luke's take
 00:43:22 - LTT's experience on legal similarities
 00:44:21 - Xbox 1 Launch precedent & reprocussions
 00:45:44 - Linus'/Luke's speculation
00:47:00 - Surprised Linus! - someone make a meme
 00:47:24 - The pariah that is Facebook
00:50:08 - Sponsors!
 00:50:12 - Anker
 00:51:29 - Mos Organizer
 00:52:26 - Vessi Footwear - Linus wears shoes
00:53:50 - Topic #3: Microsoft 'nixes Mixer
 00:54:51 - Death! due to lack of growth
 00:56:07 - Good chart this time!
 00:57:00 - Wild amounts of money offered, maybe
 00:58:16 - The loualty of Linus
 01:00:25 - Speculation of deplatformed streamers' actions
 01:04:38 - YouTube's neutrality
 01:06:12 - Set-for-life & final takes
 01:07:47 - Floatplane!
01:09:28 - Topic #4: Microsoft's store closures
 01:10:11 - Microsoft's success vs Apple's
 01:12:11 - Digital vs physical time investment
 01:13:33 - Layoff speculation
01:14:10 - Topics not discussed
01:15:39 - Death of retail fruitions
01:16:28 - Superchats
01:23:21 - Outro and Goodbyes

