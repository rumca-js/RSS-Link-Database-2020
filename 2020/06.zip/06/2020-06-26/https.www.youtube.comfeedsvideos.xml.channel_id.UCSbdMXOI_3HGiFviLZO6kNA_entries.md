# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## The TRUTH about the HTC Vive Cosmos
 - [https://www.youtube.com/watch?v=N2ZvDX2IGsY](https://www.youtube.com/watch?v=N2ZvDX2IGsY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-06-27 00:00:00+00:00

Here is my experience with the HTC Vive Cosmos and the Cosmos elite. I have had a very weird history with these VR headsets and while I have come to like the Cosmos elite for some very specific things, there are a number of factors seriously holding the headset and HTC back from a larger adoption from VR consumers. It's a good headset don't get me wrong, and wireless is awesome, it's just too darn expensive. So here's the truth all about it. And some ranting.

Here are my links

Twitch Stream
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill

01:40 basic Cosmos review and my issues with it
04:03 The reasons why the cosmos failed and has the elite fixed that
06:18 reason 2 for failure
07:03 why the cosmos can be the best VR has to offer (for a price)
09:45 how good is the wireless and why its good
12:15 CONCLUSION
13:14 final words

