# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Realme copied Xiaomi again...
 - [https://www.youtube.com/watch?v=NkVcpUF-OEE](https://www.youtube.com/watch?v=NkVcpUF-OEE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2020-06-26 00:00:00+00:00

0:00 Intro
0:28 Apple Silicon
4:58 Realme copies Redmi
6:12 Mixer
7:39 Tech Quiz
8:11 Crrowd update 

https://crrowd.com/quiz

Got topic suggestions for next week? Tweet them at me at https://twitter.com/techaltar using the #FridayCheckout hashtag

[[[ TECHALTAR LINKS ]]]: 

Merch: 
http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 

If you want to support TechAltar directly:
https://flattr.com/@techaltar

My video gear: 
https://kit.co/TechAltar/video-gear

