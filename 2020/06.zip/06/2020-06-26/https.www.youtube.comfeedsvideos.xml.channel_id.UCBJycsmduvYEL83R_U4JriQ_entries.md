# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Apple Responds to Your Comments!
 - [https://www.youtube.com/watch?v=Q2aaCDNjWEg](https://www.youtube.com/watch?v=Q2aaCDNjWEg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-06-26 00:00:00+00:00

Some insight with Craig Federighi about the iOS 14 and the more controversial 2020 announcements!
Full WVFRM episode: http://bit.ly/WaveformMKBHD
Thanks for ExpressVPN for sponsoring: http://expressvpn.com/MKBHD

WWDC 2020 Impressions: https://youtu.be/0we7kcmgDOw
iOS 14 Hands-On: https://youtu.be/ZLyDvABxGF0

Timestamps:
0:00 Intro
1:32 Default Apps
5:08 Siri
8:34 MacOS Big Sur Design/Icons
14:30 iPad Weather and Calculator
16:06 Apple Watch on iPad
17:38 Sponsor

MKBHD Merch: http://shop.MKBHD.com

Video Gear I use: http://kit.co/MKBHD/video-gear#recom...
Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Jordyn Edmonds http://smarturl.it/jordynedmonds
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

