# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## SID music: Jammer - Take Your Time, Babe (SIDFX 8580 dual mono bx_🎧)
 - [https://www.youtube.com/watch?v=ErgUxvHimwU](https://www.youtube.com/watch?v=ErgUxvHimwU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-06-27 00:00:00+00:00

"Take Your Time, Babe" (2020) by Jammer/EXON^MSL^Samar (Kamil Wolnikowski). Art "Crazy Ghettoblaster" (2015) by Joodas/Albion Crew, 1st at Stary Piernik 10. Use headphones for optimal listening experience.

Made using real C64 audio in SIDFX dual mono config (identical audio data for both chips):

Left channel: CSG 6582A 2792 25/Philippines NM235N18 1200T
Right channel: CSG 8580R5 0590 25/Hong Kong HH032232 HC-30

Project SIDFX:
http://www.sidfx.dk/

