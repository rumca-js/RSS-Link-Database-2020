# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 BEST Games of 2020 [FIRST HALF]
 - [https://www.youtube.com/watch?v=3tjp2iuXBsA](https://www.youtube.com/watch?v=3tjp2iuXBsA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-06-27 00:00:00+00:00

2020 has already seen tons of great games for PC, PS4, Xbox One, Nintendo Switch, and more. Here's what we've been enjoying.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

#10 Maneater
Platform: PC XBOX ONE PS4

#9 Gears Tactics
Platform: PC XBOX ONE

#8 Half-Life Alyx
Platform: PC 

#7 Ori and the Will of the Wisps
Platform: PC XBOX ONE

#6 The Last of Us Part II
Platform: PS4

#5. Mount and Blade II: Bannerlord
Platform: PC

#4. Call of Duty: Warzone
Platform: PC PS4 XBOX ONE

#3. FF7 Remake
Platform: PS4

#2. Animal Crossing: New Horizons
Platform: SWITCH

#1. Doom Eternal
Platform: PC PS4 XBOX ONE

BONUS

Resident Evil 3
Platform: PC PS4 XBOX ONE

Nioh 2
Platform: PS4

DBZ Kakarot
Platform: PC PS4 XBOX ONE

Satisfactory
Platform: PC

## CYBERPUNK 2077 BIG NEW CHANGES, ANOTHER NEW XBOX CONSOLE LEAKED, & MORE
 - [https://www.youtube.com/watch?v=yu1gf3vttjY](https://www.youtube.com/watch?v=yu1gf3vttjY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-06-26 00:00:00+00:00

To experience the world’s first 100% waterproof knit shoe, and get $40 off your order visit http://vessifootwear.com/gameranx
Thanks to Vessi for sponsoring our video.

Xbox 'Lockhart' is in the news again, more rumors for Rocksteady's next Batman game, Cyberpunk details, and more in a week full of gaming news.
Subscribe for more: https://www.youtube.com/gameranxTV?su...


 Weekly giveaway link: https://goo.gl/forms/a7zCtr1HuTkzWuOo2 


*Jake's other channel: https://bit.ly/2YgTA4Y



 ~~~~STORIES~~~~



New Cyberpunk details and changes:
https://www.gfinityesports.com/article/4701/cyberpunk-2077-melee-guide-and-how-the-system-has-changed-since-demo
https://www.gamesradar.com/cyberpunk-2077-character-creation/
https://venturebeat.com/2020/06/25/cyberpunk-2077-adds-more-ray-tracing-features-for-rtx-graphics-cards/

Great Cyberpunk preview:
https://youtu.be/4EDC9tyep_M

Xbox console leaked
https://www.theverge.com/2020/6/26/21304112/microsoft-xbox-series-x-lockhart-leaked-document-specs-rumors


Mixer
https://www.theverge.com/2020/6/22/21299032/microsoft-mixer-closing-facebook-gaming-partnership-xcloud-features



Pokemon unite
https://youtu.be/oElrP4oAwjA

Crash Bandicoot 
https://youtu.be/aOGwx3Ju6QQ

Halo Infinite tease 
https://youtu.be/9rYzOXqSM_k

Bloodstained 2https://www.youtube.com/watch?v=Ynesdjzxix0

Turok story lol
https://www.vg247.com/2020/06/24/change-name-to-turok/


Animal Crossing updates: https://youtu.be/jO0luDEHesc

Suicide Squad
https://www.eurogamer.net/articles/2020-06-22-yes-batman-arkham-developer-rocksteady-is-making-a-suicide-squad-game

