# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## Which of these TWO ways do you perceive time?
 - [https://www.youtube.com/watch?v=5b0Nn9jE5Hc](https://www.youtube.com/watch?v=5b0Nn9jE5Hc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2020-06-26 00:00:00+00:00

Comment below which one you are!
Mask vs No Mask Lab Results - Do they work? https://youtu.be/qDeP7-rUZmo
JOIN OUR NEW EMAIL LIST: https://mailchi.mp/072240d817d6/asapscience
Check out our podcast channel: http://youtube.com/sidenotepodcast

Subscribe for more asapscience, and hit that bell :)
Created by: Mitchell Moffit and Gregory Brown
Edited By: Luka Šarlija

FOLLOW US!
Mitch
Instagram: https://instagram.com/mitchellmoffit
Twitter: https://twitter.com/mitchellmoffit 

Greg
Instagram: https://instagram.com/whalewatchmeplz 
Twitter: https://twitter.com/whalewatchmeplz 

AsapSCIENCE
Instagram: https://instagram.com/asapscience 
Facebook: https://facebook.com/asapscience 
Twitter: https://twitter.com/asapscience
TikTok: @AsapSCIENCE 

MORE INFO/SOURCES:

https://www.thenational.ae/arts-culture/how-do-you-perceive-time-viral-tiktok-video-explains-the-different-ways-people-interpret-the-clock-1.1036930

https://onlinelibrary.wiley.com/doi/abs/10.1002/ejsp.1906

http://www-cogsci.ucsd.edu/~nunez/web/timeaftertimeF+.pdf

https://www.researchgate.net/publication/236058562_Moving_Away_From_a_Bad_Past_and_Toward_a_Good_Future_Feelings_Influence_the_Metaphorical_Understanding_of_Time

http://groups.psych.northwestern.edu/gentner/papers/Gentner01.pdf

http://groups.psych.northwestern.edu/gentner/newpdfpapers/GentnerImaiBoroditsky02.pdf

https://www.researchgate.net/publication/318191040_Moving-Time_and_Moving-Ego_Metaphors_from_a_Translational_and_Contrastive-Linguistic_Perspective

https://www.aclweb.org/anthology/Y07-1017.pdf

http://lingwistyka.pbworks.com/f/boroditsky.pdf

https://pdfs.semanticscholar.org/3a9f/51a7d92ef3fdcd3b7310f6873b8bb82f2ac5.pdf

https://psycnet.apa.org/record/2017-52066-001

