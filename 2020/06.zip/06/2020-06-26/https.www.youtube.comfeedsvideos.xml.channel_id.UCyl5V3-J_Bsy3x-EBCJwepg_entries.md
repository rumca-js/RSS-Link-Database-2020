# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Answering A Teen’s Objections To Police Authority
 - [https://www.youtube.com/watch?v=FxYR8GB4Vgg](https://www.youtube.com/watch?v=FxYR8GB4Vgg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-06-27 00:00:00+00:00

On the latest Babylon Bee Podcast, Kira gives some advice to Ethan’s teen daughter who questions the role of police in America today and if all white people are born racist.

FULL ➡️ https://youtu.be/UbXjsqSm_PY

## Cops, Kanye, and Candace with Kira Davis
 - [https://www.youtube.com/watch?v=UbXjsqSm_PY](https://www.youtube.com/watch?v=UbXjsqSm_PY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-06-26 00:00:00+00:00

Today on The Babylon Bee Podcast, Kyle and Ethan welcome guest host Kira Davis who is editor-at-large at RedState. They talk about the difference between protesting and rioting, some problems Kira sees with the approach of Candace Owens, and how we need to have a reality show where everyone gets stuck in an elevator with someone they hate until we achieve world peace.

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Gain Access to the Exclusive Content and Writing Forum: https://babylonbee.com/plans

The Official Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

