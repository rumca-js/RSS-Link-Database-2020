# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## The Desks Of The 2020 Tiny Desk Contest
 - [https://www.youtube.com/watch?v=jWQR4HrDCIo](https://www.youtube.com/watch?v=jWQR4HrDCIo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2020-06-06 00:00:00+00:00

The first rule of the Tiny Desk Contest is simple: Each entry has to have a desk in it. This year, the Contest community showed us all sorts of desks: from huge to tiny, from simple to ornate, from store-bought to handmade and more. Here are some of the best desks. Check out more entries at tinydeskcontest.npr.org/2020/browse

Song: “Blue Velvet” by Nané

#tinydesk #tinydeskcontest

