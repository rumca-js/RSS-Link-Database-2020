# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## I Catfished Several Forex Scammers To Find The BIGGEST Fraud
 - [https://www.youtube.com/watch?v=ctINTpI0Lg4](https://www.youtube.com/watch?v=ctINTpI0Lg4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-06-06 00:00:00+00:00

Forex trading is one of the most popular new forms of day trading. Promoted as a way to make money, instagram "traders" often promote extreme earnings and lifestyles which "you can have to" if you pay them, invest with them, join their brokerage or buy their signals. These claims are usually false, and you're almost ALWAYS better off investing in simple index funds. These target forex beginners who are looking to learn forex fast and easy.

A summary of some of the sketchy forex schemes out there.
https://en.wikipedia.org/wiki/Foreign_exchange_fraud#:~:text=Foreign%20exchange%20fraud%20is%20any,U.S.%20Commodity%20Futures%20Trading%20Commission.

If you want to watch more about forex, Biaheza has several good videos on the subject:
I Tried Day Trading Forex With $50,000
https://www.youtube.com/watch?v=BY60VhkndcU
I Tried Forex Day Trading for a Week (Complete Beginner)
https://www.youtube.com/watch?v=Z0QLk-LYwPM&

Ending song: Pay for that Money - The Defibulators

Subscribe to Coffeezilla for more!

