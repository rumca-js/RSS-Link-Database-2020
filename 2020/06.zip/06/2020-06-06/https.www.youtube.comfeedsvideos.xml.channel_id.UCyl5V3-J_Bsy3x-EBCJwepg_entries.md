# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Can Justice and Equality Exist Without God?
 - [https://www.youtube.com/watch?v=60JgALV9pXw](https://www.youtube.com/watch?v=60JgALV9pXw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-06-06 00:00:00+00:00

From the Bee podcast 🎙Kyle and Ethan discuss critical race theory in the church and society, because apparently COVID isn't a thing anymore?

FULL: https://youtu.be/DTW7_EcWnmc

