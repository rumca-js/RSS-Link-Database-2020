# Source:BezPlanu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g, language:pl-PL

## Co dalej ? Q&A
 - [https://www.youtube.com/watch?v=9_Yzaky3zvQ](https://www.youtube.com/watch?v=9_Yzaky3zvQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g
 - date published: 2020-06-07 00:00:00+00:00

Trzecia w historii kanału seria odpowiedzi na Wasze pytania
Port Barton (Palawan, Filipiny)

Wszystkie odcinki chronologicznie: http://bit.ly/2MqAO7Q
(można też klikać w kartę "Następny odcinek" pojawiającą się pod koniec każdego filmu po prawej stronie u góry)

Wsparcie na Patronite: http://bit.ly/2KsFTZk 
Instagram: http://instagram.com/bezplanu_czukesky 
Facebook: https://www.facebook.com/BezPlanu.tv 

Czas akcji: 2 czerwca 2020 r.

Tłumaczenie na angielski: Michał Stadryniak
www.linkedin.com/in/michał-stadryniak-82b8491a6

