# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## RANKING MY MOST POPULAR VIDEOS!
 - [https://www.youtube.com/watch?v=ceshgCh86TI](https://www.youtube.com/watch?v=ceshgCh86TI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-06-06 00:00:00+00:00

I rank my own videos! From wheel of time and Witcher to Stephen King. Let me knwo what your favorite video of mine is. Do your own Tier List: https://tierlists.com/create/my-videos-1

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

