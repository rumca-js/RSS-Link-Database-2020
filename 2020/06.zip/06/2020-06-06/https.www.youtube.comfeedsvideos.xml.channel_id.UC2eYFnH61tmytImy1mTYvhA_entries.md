# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## Bash commands to not look dumb at the Interview...
 - [https://www.youtube.com/watch?v=Gl4DKyicKKg](https://www.youtube.com/watch?v=Gl4DKyicKKg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-06-07 00:00:00+00:00

In this second episode of my basic shell/bash/terminal guide, I show you some basic commands to get system, user, time and hard drive information so you don't look too clueless when you have to figure something out in the terminal.

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE: https://lukesmith.xyz/donate 💰😎👌💯
OR affiliate links to things l use:
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://brave.com/luk005 Get the Brave browser.
https://lbry.tv/$/invite/@Luke View my videos on LBRY.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase.

## New to Linux? Yeah, just use Manjaro...
 - [https://www.youtube.com/watch?v=eWowqM2S9VU](https://www.youtube.com/watch?v=eWowqM2S9VU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-06-06 00:00:00+00:00

Instead of just telling people "not to distro hop" and to figure it out for themselves, sometimes it's better just to tell them what to do. Just use Manjaro XFCE (https://manjaro.org). When I install Linux on a normie's computer, I've always chosen Manjaro for them and that always works best.

It's an easy to use distro, which has most all of the advantages of Arch Linux, including AUR access, rolling release for muh gaymes for gamers and if you git gud you can also play around with desktop environments and window managers easily.

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE: https://lukesmith.xyz/donate 💰😎👌💯
OR affiliate links to things l use:
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://brave.com/luk005 Get the Brave browser.
https://lbry.tv/$/invite/@Luke View my videos on LBRY.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase.

