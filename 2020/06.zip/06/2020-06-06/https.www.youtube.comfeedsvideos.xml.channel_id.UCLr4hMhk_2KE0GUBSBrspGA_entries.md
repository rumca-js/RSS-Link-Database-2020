# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Wreszcie TECH WEEK! Elektryczny samochód Dyson, iPhone 11 Pro, Sony Xperia 1 II, OnePlus 8 Pro
 - [https://www.youtube.com/watch?v=QS0IbA3MYgY](https://www.youtube.com/watch?v=QS0IbA3MYgY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-06-07 00:00:00+00:00

Wróciłem! Obecny jestem również tu: insta: http://bit.ly/InstaKlawiatur Twitter: http://bit.ly/TTKlawitera i FB: http://bit.ly/FBKlawiatur.
Recenzja gadżetu dla kota: https://youtu.be/-u09VNgCzAs

Źródła:
Elektryczny samochód Dysona: https://bit.ly/2AIE4pk
Samolot elektryczny: https://bit.ly/2XDZvR9
Nowa elektrownia węglowa w Niemczech: https://bit.ly/2XCLLGm
Podeszwy z "zębami": https://bit.ly/2XGyoVW
Escobar pozywa Apple: https://bit.ly/376VdF2
Film MKBHD o iPhone 11 Pro: https://youtu.be/Ns8ydpZ5-4o
Unbox Therapy o Sony Xperia 1 II: https://bit.ly/3cF676h
OnePlus 8 Pro i prześwietlanie damskich bluzek: https://bit.ly/3eQPZA6

