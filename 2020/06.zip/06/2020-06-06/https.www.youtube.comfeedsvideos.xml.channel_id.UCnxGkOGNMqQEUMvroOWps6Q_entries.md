# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Best of the Week - May 31, 2020 - Joe Rogan Experience
 - [https://www.youtube.com/watch?v=jbBSnHZXowo](https://www.youtube.com/watch?v=jbBSnHZXowo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-07 00:00:00+00:00

#1484 w/Reggie Watts
https://www.youtube.com/watch?v=Mcle87Uvh8Y

#1485 w/Krystal & Saagar
https://www.youtube.com/watch?v=eA9Tpf5Uuxs

#1486 w/Honey Honey
https://www.youtube.com/watch?v=KqXYKjkVf9Q

#1487 w/Janet Zuccarini & Evan Funke
https://www.youtube.com/watch?v=vUw8dqDHcB4

## Chef Evan Funke on the Art of Making Pasta | Joe Rogan
 - [https://www.youtube.com/watch?v=9mNLy4PnnJY](https://www.youtube.com/watch?v=9mNLy4PnnJY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-06 00:00:00+00:00

Taken from JRE #1487 w/Janet Zuccarini and Evan Funke:
https://youtu.be/vUw8dqDHcB4

## LA Chef Evan Funke’s Tips for Cooking a Good Steak
 - [https://www.youtube.com/watch?v=8msMpoCE-SU](https://www.youtube.com/watch?v=8msMpoCE-SU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-06 00:00:00+00:00

Taken from JRE #1487 w/Janet Zuccarini and Evan Funke: https://youtu.be/vUw8dqDHcB4

