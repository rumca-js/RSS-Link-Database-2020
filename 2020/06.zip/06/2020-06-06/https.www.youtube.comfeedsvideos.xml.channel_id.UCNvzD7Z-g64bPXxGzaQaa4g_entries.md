# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Last of Us Part 2 - 10 Things You NEED TO KNOW
 - [https://www.youtube.com/watch?v=6xdfNvp8CjY](https://www.youtube.com/watch?v=6xdfNvp8CjY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-06-07 00:00:00+00:00

The Last of Us Part II (PS4) is almost here. Here's everything you need to know to be caught up. SPOILER FREE
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 5 GTA V Graphics Mod That Will Compete With GTA 6 [4K Video]
 - [https://www.youtube.com/watch?v=DMHrBJeycHc](https://www.youtube.com/watch?v=DMHrBJeycHc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-06-06 00:00:00+00:00

Grand Theft Auto 5 graphics mods have gotten to an insane level - these examples might even give the inevitable release of GTA 6 a run for its money.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

GTA REALISM - https://www.gta5-mods.com/misc/gta-realism
Visual V - https://www.gta5-mods.com/misc/visualv
2k Water Mod - https://www.gta5-mods.com/misc/2k-water
GTA REDUX - https://gta5redux.com/features/
Natural Vision Evolved Mod - https://www.patreon.com/razedmods

