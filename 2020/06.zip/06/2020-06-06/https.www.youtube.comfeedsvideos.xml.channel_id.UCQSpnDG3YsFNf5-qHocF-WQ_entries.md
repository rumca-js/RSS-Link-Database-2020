# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## 10 Ways You're Using Your Computer WRONG!
 - [https://www.youtube.com/watch?v=IbuKffs7wmg](https://www.youtube.com/watch?v=IbuKffs7wmg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2020-06-06 00:00:00+00:00

So you think you have this whole "computer" thing handled? Think again.

⇒ Become a channel member for exclusive features! Check it out here: https://www.youtube.com/ThioJoe/join

▼ Time Stamps: ▼
0:00 - Intro
0:45 - Restarting Incorrectly
2:05 - Not Reading Installation Options
3:12 - Not Customizing the Start Menu
4:12 - Not Encrypting Your Laptop
5:57 - Never Removing Startup Apps
6:58 - Re-Using Passwords
8:42 - Using an Out-Of-Support OS
10:39 - Using Default OS Settings
11:16 - Not Backing-Up
12:18 - Not Updating Right Away

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

#Computers #Tech #ThioJoe

