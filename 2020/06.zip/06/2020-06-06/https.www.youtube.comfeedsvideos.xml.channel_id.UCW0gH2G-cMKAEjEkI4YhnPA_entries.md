# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Life of Thorin Oakenshield | Tolkien Explained - Dwarves of Erebor
 - [https://www.youtube.com/watch?v=72MP0D4UsMU](https://www.youtube.com/watch?v=72MP0D4UsMU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2020-06-06 00:00:00+00:00

Concluding our series on the Dwarves of The Hobbit is Thorin Oakenshield. - Leader of the Quest of Erebor, friend to Bilbo Baggins, and King Under the Mountain who reclaimed Erebor.  This video covers the life of Thorin II son of Thrain II from his birth in the Lonely Mountain, to his death in the Battle of Five Armies, and his lasting legacy.

"If more of us valued food and cheer and song above hoarded gold, it would be a merrier world."

Hit subscribe - and the bell - so you never miss a video from Nerd of the Rings! 

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner. 

Azog and Nar - Steamey
Azog - WETA
Bard - Paulo Puggion
Bolg, son of Azog - Ozakuya
Death of Smaug - Alan Lee
Gandalf and Thorin at Bree - Ted Nasmith
Last Stand of Thorin Oakenshield - Lucas Graciano
Orcrist - Ted Nasmith
The Dwarves Delve Too Deep - Ted Nasmith
The Arkenstone - Ted Nasmith
The Death of Thorin - John Howe
Thorin King Under the Mountain - gravity-zero, Eleonor Piteira
Thorin Oakenshield - matchack
Thorin and Thranduil - Quelle Elenath
Vengeance - Steamey

#thehobbit #tolkien #thorin

