# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Guerrilla Collective - Black Voices In Gaming
 - [https://www.youtube.com/watch?v=cc9EdUAY57o](https://www.youtube.com/watch?v=cc9EdUAY57o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-07 00:00:00+00:00

The Guerrilla Collective highlights black voices in the gaming industry with an event dedicated exclusively to showcasing games created by Black developers, titles featuring Black protagonists, and conversations with these creators.

## Sea Of Thieves Review (2020)
 - [https://www.youtube.com/watch?v=58IX_G8n3GA](https://www.youtube.com/watch?v=58IX_G8n3GA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-06 00:00:00+00:00

More than two years after its launch, Sea of Thieves has improved in countless ways.

Mike Rougeau is GameSpot's managing editor of entertainment. He played Sea of Thieves for a time at launch, stopped for nearly two years, and picked it up again on PC in April. He's been staying up too late almost nightly ever since, and finally hit Pirate Legend.

