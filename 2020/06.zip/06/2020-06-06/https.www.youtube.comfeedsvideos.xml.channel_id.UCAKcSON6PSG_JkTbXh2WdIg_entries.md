# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## MC Longshot - Interview with Andrea Swensson
 - [https://www.youtube.com/watch?v=t6MjrCxzrkU](https://www.youtube.com/watch?v=t6MjrCxzrkU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-06-07 00:00:00+00:00

Andrea Swensson, host of the Local Show, interviews MC Longshot about his participation in the first night of the protests and demonstrations throughout Minneapolis, and about how he funneled all of his subsequent emotions into a new EP, "I'm Saying."

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

