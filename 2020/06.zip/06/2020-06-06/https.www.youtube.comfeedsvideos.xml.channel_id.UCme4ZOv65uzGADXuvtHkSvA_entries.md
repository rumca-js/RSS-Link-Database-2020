# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Ballady i romanse | Pory roku miłości | WIOSNA
 - [https://www.youtube.com/watch?v=vN9L39LfSz4](https://www.youtube.com/watch?v=vN9L39LfSz4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-06-07 00:00:00+00:00

#Balladyiromanse #Poryrokumiłości #WIOSNA @Langusta na palmie 

Po 2,5-rocznej przerwie wracamy z nowymi odcinkami Ballad i Romansów! 
W miniserii zrealizowany wraz ze STACJĄ7 zatytułowanej „Pory roku miłości” ojciec Adam Szustak daje konkretne porady od „Wujka dobra rada” jak budować piękny i pełny związek. Na początek Wiosna i trzy wskazówki na co zwrócić uwagę, gdy wchodzi się w relację. 
Uwaga! Pod koniec czerwca ukaże się książka „Ballady i romanse” 

________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#184] Dlaczego Bóg jest Trójcą?
 - [https://www.youtube.com/watch?v=prGxAC6Thmo](https://www.youtube.com/watch?v=prGxAC6Thmo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-06-06 00:00:00+00:00

#cnn #kazaniedookienka #UroczystośćNajświętszejTrójcy
 @Langustanapalmie 

Kazanie na Uroczystość Najświętszej Trójcy, Rok A

1. czytanie (Wj 34, 4b-6. 8-9)

Mojżesz, wstawszy rano, wstąpił na górę, jak mu nakazał Pan, i wziął do rąk tablice kamienne. 
A Pan zstąpił w obłoku, i Mojżesz zatrzymał się koło Niego, i wypowiedział imię Pana. Przeszedł Pan przed jego oczyma i wołał: «Pan, Pan, Bóg miłosierny i łagodny, nieskory do gniewu, bogaty w łaskę i wierność». Natychmiast Mojżesz skłonił się aż do ziemi i oddał pokłon, mówiąc: «Jeśli darzysz mnie życzliwością, Panie, to proszę, niech pójdzie Pan pośród nas. Jest to wprawdzie lud o twardym karku, ale przebaczysz nasze winy i nasze grzechy, a uczynisz nas swoim dziedzictwem».

2. czytanie (2 Kor 13, 11-13)

Bracia, radujcie się, dążcie do doskonałości, pokrzepiajcie się na duchu, bądźcie jednomyślni, pokój zachowujcie, a Bóg miłości i pokoju będzie z wami. Pozdrówcie się nawzajem świętym pocałunkiem! Pozdrawiają was wszyscy święci. Łaska Pana Jezusa Chrystusa, miłość Boga i dar jedności w Duchu Świętym niech będą z wami wszystkimi!

Ewangelia (J 3, 16-18)

Jezus powiedział do Nikodema:
«Tak Bóg umiłował świat, że Syna swego Jednorodzonego dał, aby każdy, kto w Niego wierzy, nie zginął, ale miał życie wieczne. Albowiem Bóg nie posłał swego Syna na świat po to, aby świat potępił, ale po to, by świat został przez Niego zbawiony. Kto wierzy w Niego, nie podlega potępieniu; a kto nie wierzy, już został potępiony, bo nie uwierzył w imię Jednorodzonego Syna Bożego».
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Ksiądz gra w grę: Detroit Become Human [#03] Jakie są Twoje ustawienia fabryczne?
 - [https://www.youtube.com/watch?v=NF5OhtvtIt4](https://www.youtube.com/watch?v=NF5OhtvtIt4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-06-06 00:00:00+00:00

@Langustanapalmie  #detroitbecomehuman #ksiądzgrawgrę
________________________________________
Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Miriam [#39] Pocieszycielka strapionych
 - [https://www.youtube.com/watch?v=ZN9Oe-g5NO4](https://www.youtube.com/watch?v=ZN9Oe-g5NO4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-06-06 00:00:00+00:00

#Miriam #litanialoretańska @Langustanapalmie 

Komentarze do wezwań Litanii Loretańskiej. 

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#524] Miejsce
 - [https://www.youtube.com/watch?v=hKjnhCBOlJk](https://www.youtube.com/watch?v=hKjnhCBOlJk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-06-06 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał  

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

