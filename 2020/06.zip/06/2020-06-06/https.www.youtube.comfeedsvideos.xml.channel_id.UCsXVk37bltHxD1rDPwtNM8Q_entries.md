# Source:Kurzgesagt – In a Nutshell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsXVk37bltHxD1rDPwtNM8Q, language:en-US

## Could Solar Storms Destroy Civilization? Solar Flares & Coronal Mass Ejections
 - [https://www.youtube.com/watch?v=oHHSSJDJ4oo](https://www.youtube.com/watch?v=oHHSSJDJ4oo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsXVk37bltHxD1rDPwtNM8Q
 - date published: 2020-06-07 00:00:00+00:00

Get Merch designed with ❤ from https://kgs.link/shop-123  
Join the Patreon Bird Army 🐧 https://kgs.link/patreon  
▼▼ More infos and links are just a click away ▼▼

We have a bunch of new stuff, from the long requested bacteriophage infographic poster to a new Optimistic Nihilism poster that lets you enjoy some existential dread in style. Or join us in our ant obsession and get the new Ant Explorer Notebook, with beautiful infographics and facts about ants and gold lettering on the cover. If you’d rather update your wardrobe, have a look at our beanies or T Shirts. Or you know, all the other stuff! 
We put a lot of love and care into developing our products and only make stuff we want to have ourselves – if you want to support kurzgesagt, getting some merch is the best way to do it while receiving something beautiful in return. Thank you for your support and thank you for watching.

Sources & further reading: 
https://sites.google.com/view/sourcessolarflares

The sun. Smooth and round and peaceful. Except when it suddenly vomits radiation and plasma in random directions. These solar flares and coronal mass ejections, or CMEs can hit earth and have serious consequences for humanity. 

How exactly do they work, how bad could they be and can we prepare for them?

OUR CHANNELS
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
German Channel: https://kgs.link/youtubeDE
Spanish Channel: https://kgs.link/youtubeES


HOW CAN YOU SUPPORT US?
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
This is how we make our living and it would be a pleasure if you support us!

Get Merch designed with ❤ from https://kgs.link/shop-123  
Join the Patreon Bird Army 🐧 https://kgs.link/patreon  


DISCUSSIONS & SOCIAL MEDIA
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
Reddit:            https://kgs.link/reddit
Instagram:     https://kgs.link/instagram
Twitter:           https://kgs.link/twitter
Facebook:      https://kgs.link/facebook
Discord:          https://kgs.link/discord
Newsletter:    https://kgs.link/newsletter


OUR VOICE
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
The Kurzgesagt voice is from 
Steve Taylor:  https://kgs.link/youtube-voice


OUR MUSIC ♬♪
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
700+ minutes of Kurzgesagt Soundtracks by Epic Mountain:

Spotify:            https://kgs.link/music-spotify
Soundcloud:   https://kgs.link/music-soundcloud
Bandcamp:     https://kgs.link/music-bandcamp
Youtube:          https://kgs.link/music-youtube
Facebook:       https://kgs.link/music-facebook

The Soundtrack of this video:

Soundcloud:   https://bit.ly/3gZDPqi
Bandcamp:     https://bit.ly/2MC124a 

🐦🐧🐤 PATREON BIRD ARMY 🐤🐧🐦
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
Many Thanks to our wonderful Patreons from http://kgs.link/patreon who support us every month and made this video possible:

Claire Kim, בועז ברקוביץ, Jordan Kowal, Philip Lightstone, Josh, Henry Thomas, Peer Fromme, Daniel Something-in-chinese, Joerg Fluegge, Mathieu Haverkamp, Pierre-Antoine, Filipe, Sam, Steven wu, Adam Leos, Biniam Jacob, Autumn, TURRONERO, 메타, 4Felix_HB, Bronwen Dickenson, McLen, Gabi Adler, AZHY ROBERTSON, Mikhail Levchenko, Richard Tran, Cooper Nagengast, Alberto Mina, Michele, Jarrod Brodel, Jeff Cooper, Keith McComb, Bryan Lin, FuzzyLogic, Kaden Archibald, Zeeger Scholten, Adam Górecki-Gomoła, Forrest Henry, Sam Starzynski, Ross Anderson, Mark Neal, Sivda, Anatoly Polinsky, Tony Black, Komala Chenna, Lieberson Pang, henry Defelice, Michael Coors, Ben Wallace, Matt McKee, Mikael Muszynski, Franziska Diez, Marius G, Sona, Xander, Walter_Ego, john dietrich, Arian Feigl-Berger, Alejandro Godinez, Lou, Justin Oliver, Chris, Valentin Jay, Andy Miller, Sabrina Wrobel, Jion Wattimury, Peter Neubauer, Rico Oess, Kai, jp888, Coral Amayi, Todd J., Patrick Havercroft, Joshua Milus, Sudipto Bhattacharya, Pius Ladenburger, Gina Curler, Flemming Lauritzen, Ben, Ezio Auditore, Christopher Hines, Elena Kovakina, Shahaf Milshtein, Oliver Sheldon, Liam Clarke, Mette, Adam Kovalovszki, Patrick Zeymer, Adam Wells, aslfhjdfkjlha, Faustus, Virgile Kuhn, Lua ., Markus, Alan, Andrew McKendry, RexL300, Jakub, Paula Patzova, Jan Kropidlowski, liza_worth, Josef Simonson, Andreas Heller, Griffin vlachos, Albert Diserholt, Kirils Bondars, Asahi Ishikawa, Jan Jaeken, Sanat Deshpande, Lambda3, 竹鴻 柯, Jacob Robbins, David Habada, flickers, JusRus, Nicholas Wolf, Zachariah Jackson, Leon Suhm, Marco Johne, Eren Tatar

