# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## How to Stay Safe in 2020 (Most Dangerous Year Ever!)
 - [https://www.youtube.com/watch?v=bEc0wy_mEA8](https://www.youtube.com/watch?v=bEc0wy_mEA8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-06-18 00:00:00+00:00

Check out BLUblox, my favorite evidenced based blue light glasses: https://www.blublox.com/jp
To get 15% off, use the discount code: JP
You'll learn the latest techniques to keep you safe in 2020, the most dangerous year ever. In a year that's aggressively trying to take you out, this video will help you be safer than if you were in prison. If you're not scared of everything, then you can't stay safe from everything. This video will show you how to do both.

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Click Here to join my PATREON - https://awakenwithjp.com/patron
---- Want to be the first to see my new videos with 24 hour early access? Just click this to receive the alerts! - https://m.me/awakenwithjp?ref=w6836464

Listen and Subscribe to my NEW Podcast here: 
https://podcasts.apple.com/ca/podcast/awaken-with-jp-sears-show/id1436938686
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

-Order my new book at: http://HowToBeUltraSpiritual.com/

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

