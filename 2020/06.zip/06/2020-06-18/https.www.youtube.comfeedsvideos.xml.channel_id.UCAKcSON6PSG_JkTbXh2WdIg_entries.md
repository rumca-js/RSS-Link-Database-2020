# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## GRRRL PRTY - two songs at Rock The Garden 2016
 - [https://www.youtube.com/watch?v=lh5sOeq5-9Q](https://www.youtube.com/watch?v=lh5sOeq5-9Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-06-19 00:00:00+00:00

GRRRL PRTY — consisting of Lizzo, Sophia Eris, Manchita and DJ Shannon Blowtorch — played their final show together at Rock the Garden 2016, and they poured everything into that last performance. Watch these two songs from that unforgettable set. 

SONGS PERFORMED
00:00 "Bugg'n"
03:19 "Wegula"

PERSONNEL
Lizzo
Sophia Eris
Manchita
DJ Shannon Blowtorch

CREDITS
Video & Photo: Nate Ryan
Audio: Michael DeMark

FIND MORE:
2014 studio session: https://www.thecurrent.org/feature/2014/03/09/grrrl-prty-live
2015 First Avenue Mainroom show review: https://blog.thecurrent.org/2015/08/first-avenue-reopens-mainroom-for-joyous-grrrl-prty-show/
2016 GRRRL PRTY to say goodbye at Rock The Garden: https://blog.thecurrent.org/2016/06/grrrl-prty-to-say-goodbye-at-rock-the-garden/

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Benjamin Booker - two performances for The Current
 - [https://www.youtube.com/watch?v=4qoocq250jI](https://www.youtube.com/watch?v=4qoocq250jI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-06-18 00:00:00+00:00

We're continuing to spotlight past Rock The Garden performances this week, and today we're sharing Benjamin Booker's blistering performance of "Wicked Waters" from Rock the Garden 2017. Keep watching to see Booker's 2014 performance of "Violent Shiver" recorded in our studio.

SONGS PERFORMED
00:00 "Wicked Waters"
03:40 "Violent Shiver"

CREDITS
Video & Photo: Nate Ryan
Audio: Michael DeMark
Production: Derrick Stevens

FIND MORE:
2017 Rock the Garden set: https://www.thecurrent.org/feature/2017/08/08/pick-yourself-up-with-benjamin-bookers-rock-the-garden-set
2014 studio session: https://www.thecurrent.org/feature/2014/06/30/benjamin-booker-is-living-the-dream-in-a-couple-of-ways
2014 Guitar Collection interview: https://www.thecurrent.org/feature/2014/07/02/the-current-s-guitar-collection-benjamin-booker

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Drive-in shows by Garth Brooks a bright spot in dark times for live music (The Current Music News)
 - [https://www.youtube.com/watch?v=MJhINWHufvE](https://www.youtube.com/watch?v=MJhINWHufvE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-06-18 00:00:00+00:00

June 18, 2020: As music venues continue to fight for their survival during the coronavirus pandemic, artists are getting creative. We talk to the company behind Garth Brooks's upcoming drive-in streaming show, look at what went wrong during the U.K. 'quarantine raves,' and consider the risk Live Nation is now asking artists to assume.
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

