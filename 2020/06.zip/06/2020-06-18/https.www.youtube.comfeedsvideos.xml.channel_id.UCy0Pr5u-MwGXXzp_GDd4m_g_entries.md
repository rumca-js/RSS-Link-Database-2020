# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## A Casual Chit-Chat Attempt During a Pandemic and Revolution
 - [https://www.youtube.com/watch?v=CCsjqD3bJoQ](https://www.youtube.com/watch?v=CCsjqD3bJoQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2020-06-18 00:00:00+00:00

What happens when you try to avoid talking about current events...
Written by: Julie Nolke
Story edited by: Andrew Bushell
Actors: Julie Nolke & Andrew Bushell (imdb: https://www.imdb.com/name/nm4100046/?ref_=nv_sr_srsg_0
ps. I have never enjoyed Gone With The Wind... it just made for a good joke.

