# Source:Roosevelt, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqqY6fzyLY3OmdjYRe2eJAg, language:en-US

## Roosevelt - Sign (Official Video)
 - [https://www.youtube.com/watch?v=BHYeCkcIgV0](https://www.youtube.com/watch?v=BHYeCkcIgV0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqqY6fzyLY3OmdjYRe2eJAg
 - date published: 2020-06-18 00:00:00+00:00

'POLYDANS' - my new album - out now! Stream / Purchase here: https://roosevelt.lnk.to/Polydans

FOLLOW Roosevelt on Facebook, Instagram and more https://roosevelt.lnk.to/follow
Website : https://roosevelt.lnk.to/website 

This is the Official Youtube Channel for Roosevelt. 
SUBSCRIBE NOW to be kept up to date with the latest music, videos, tour dates, behind the scenes footage and more https://roosevelt.lnk.to/subscribe

VIDEO CREDITS
Directed by Ohad Ben-Moshe 
Creative Direction by C/O Magick 
Design by Ohad Ben-Moshe & Roosevelt 

MUSIC CREDITS
Written, Performed, Recorded and Produced by Marius Lauber 
Mastered by Heba Kadry 


LYRICS
you were slowly moving out of sight
we've been lost calling it a night 
if only you could see me now
trying to make it through it all somehow
 
i remember it all like yesterday
looking back, you won't fade away
i know it won't be like the start
just been wondering when you changed your heart
 
so come back 
and give me a sign of your love
come back
and give me a sign of your love
 
so come back 
and give me a sign of your love
come back
and give me a sign of your love
 
so come back 
and give me a sign of your love
come back
and give me a sign of your love
 
you were slowly moving out of sight
we've been lost calling it a night 



℗ & © Greco-Roman / City Slang             

#Roosevelt #Sign #OfficialMusicVideo

