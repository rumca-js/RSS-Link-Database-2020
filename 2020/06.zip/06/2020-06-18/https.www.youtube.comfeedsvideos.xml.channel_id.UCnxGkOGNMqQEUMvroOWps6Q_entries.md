# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## African Dust Storms, The Mayan Calendar, and Doomsday Predictions w/Kyle Dunnigan
 - [https://www.youtube.com/watch?v=vme-PNEi3lM](https://www.youtube.com/watch?v=vme-PNEi3lM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-19 00:00:00+00:00

Taken from JRE #1494 w/Kyle Dunnigan:
https://youtu.be/U_yasKdeo8c

## Kyle Dunnigan Was Surprised by Bill Maher's Reaction to His Impression
 - [https://www.youtube.com/watch?v=rH2Z07he8Y8](https://www.youtube.com/watch?v=rH2Z07he8Y8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-19 00:00:00+00:00

Taken from JRE #1495 w/Kyle Dunnigan: https://youtu.be/U_yasKdeo8c

## Bret Weinstein Argues for an Andrew Yang/William H. McRaven Presidential Ticket
 - [https://www.youtube.com/watch?v=38AVFWepcNo](https://www.youtube.com/watch?v=38AVFWepcNo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-18 00:00:00+00:00

Taken from JRE #1494 w/Bret Weinstein: https://youtu.be/pRCzZp1J0v0

## Bret Weinstein Saw Civil Unrest Coming, Where He Thinks It Will Go | Joe Rogan
 - [https://www.youtube.com/watch?v=NR7gDJGFW5A](https://www.youtube.com/watch?v=NR7gDJGFW5A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-18 00:00:00+00:00

Taken from JRE #1493 w/Bret Weinstein:
https://youtu.be/pRCzZp1J0v0

## Bret Weinstein on the Dangers of #ShutdownSTEM | Joe Rogan
 - [https://www.youtube.com/watch?v=10XYi6E2QpI](https://www.youtube.com/watch?v=10XYi6E2QpI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-18 00:00:00+00:00

Taken from JRE #1493 w/Bret Weinstein:
https://youtu.be/pRCzZp1J0v0

## Bret Weinstein: Why COVID-19 May Have Leaked from a Lab
 - [https://www.youtube.com/watch?v=zQLF4DUSXGs](https://www.youtube.com/watch?v=zQLF4DUSXGs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-18 00:00:00+00:00

Taken from JRE #1494 w/Bret Weinstein: https://youtu.be/pRCzZp1J0v0

## The Problem with America’s Lab Mice and Why it Should Matter to You
 - [https://www.youtube.com/watch?v=ve4q-1D_Ajo](https://www.youtube.com/watch?v=ve4q-1D_Ajo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-18 00:00:00+00:00

Taken from JRE #1494 w/Bret Weinstein: https://youtu.be/pRCzZp1J0v0

