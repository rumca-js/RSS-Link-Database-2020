# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Joe Rogan Experience #1494 - Bret Weinstein
 - [https://www.youtube.com/watch?v=pRCzZp1J0v0](https://www.youtube.com/watch?v=pRCzZp1J0v0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2020-06-18 00:00:00+00:00

Bret Weinstein was a biology professor at Evergreen State College in Olympia, WA. He is now hosting "Bret Weinstein's Dark Horse Podcast" available on Apple Podcasts and YouTube.  @DarkHorsePod

