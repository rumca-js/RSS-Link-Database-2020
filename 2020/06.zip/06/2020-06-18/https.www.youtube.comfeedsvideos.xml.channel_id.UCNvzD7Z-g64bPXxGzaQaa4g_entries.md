# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Last of Us Part 2: 10 Things The Game DOESN'T TELL YOU
 - [https://www.youtube.com/watch?v=GOs2tE9JXAs](https://www.youtube.com/watch?v=GOs2tE9JXAs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-06-19 00:00:00+00:00

(MILD SPOILER WARNING) Looking for tips for playing The Last of Us Park II? We've got you covered here.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## NEW CRASH BANDICOOT 4 LEAKED, CYBERPUNK 2077 PS5/SERIES X UPGRADE DETAILS, & MORE
 - [https://www.youtube.com/watch?v=DWBmec4JuKg](https://www.youtube.com/watch?v=DWBmec4JuKg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-06-19 00:00:00+00:00

Thanks ExpressVPN for sponsoring. Go to https://expressvpn.com/gameranx and find out how you can get 3 months free.

Cyberpunk 2077 is backwards compatible with next-gen consoles, The Last of Us Part II releases, a new Crash Bandicoot is coming soon, EA announces a new Skate (Skate 4?) and much more.

Subscribe for more: https://www.youtube.com/gameranxTV?su...


 Weekly giveaway link: https://goo.gl/forms/a7zCtr1HuTkzWuOo2 


*Jake's other channel: https://bit.ly/2YgTA4Y



 ~~~~STORIES~~~~



New Crash Bandicoot leaked
https://www.techradar.com/in/news/crash-bandicoot-4-its-about-time-has-all-but-been-confirmed

Cyberpunk delayed
https://twitter.com/CyberpunkGame/status/1273647385294626816

Backwards compat: https://www.shacknews.com/article/118768/cyberpunk-2077-will-be-backwards-compatible-on-ps5-in-addition-to-xbox-series-x

EA Play roundup: https://youtu.be/1LKTl1tOtBA

Skate interview: http://www.jenkemmag.com/home/2020/06/18/new-ea-skate-game-coming-real/


Guerilla Collective and PC Games Show
https://www.pcgamesn.com/baldurs-gate-3/guerrilla-collective-schedule-paradox-insider-news-announcements

Baldur’s Gate 3 early access trailer
https://youtu.be/iWtEDCuc4s4

Extra Horizon: 
https://youtu.be/qIyz_7Hz3U4


New Smash character
https://www.polygon.com/2020/6/19/21296806/super-smash-bros-ultimate-arms-fighter-dlc-nintendo-direct-masahiro-sakurai



PS5 UI
https://www.theverge.com/2020/6/15/21291288/sony-ps5-software-user-interface-ui-design-dashboard-teaser-video
Xbox UI
https://twitter.com/tomwarren/status/1271722167680610304


Billy Mitchel record holder news:
https://arstechnica.com/gaming/2020/06/guinness-reinstates-billy-mitchells-donkey-kong-pac-man-records/

## 8 Best Single Player Games Based on TRUE STORIES
 - [https://www.youtube.com/watch?v=R8AfmiBk_GE](https://www.youtube.com/watch?v=R8AfmiBk_GE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-06-18 00:00:00+00:00

Some games take more story elements, characters, locations from real life than you'd expect. Here are some games based on true stories(ish) worth highlighting.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

