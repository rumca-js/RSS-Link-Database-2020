# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Apex Legends Director On Switch Port, Crossplay, And Stance On Skill Based Matchmaking
 - [https://www.youtube.com/watch?v=Kn4cBmafBf0](https://www.youtube.com/watch?v=Kn4cBmafBf0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-19 00:00:00+00:00

Michael Higham sits down with Respawn's Chad Grenier goes in-depth on EA Play announcements explaining Respawn's creative process and endeavours in updating Apex Legends.

## DIRT 5 - EXCLUSIVE Career Mode Gameplay
 - [https://www.youtube.com/watch?v=XnmqWDMwN_Y](https://www.youtube.com/watch?v=XnmqWDMwN_Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-19 00:00:00+00:00

In this exclusive gameplay video, lead designer Michael Moreton takes a spin around one of the Norway circuits and talks about DIRT 5’s Career mode. DIRT 5 is Codemasters’ first title to be confirmed on Xbox Series X and PlayStation 5

## EA Play 2020 Next Gen Games Teaser
 - [https://www.youtube.com/watch?v=jMQ4n2922qI](https://www.youtube.com/watch?v=jMQ4n2922qI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-19 00:00:00+00:00

BioWare, EA Motive, and DICE are working on some big games for the PS5 and Xbox Series X.

## FIFA 21 & Madden 21 - Official PS5 and Xbox Series X Trailer
 - [https://www.youtube.com/watch?v=nm9FGNB4Q3k](https://www.youtube.com/watch?v=nm9FGNB4Q3k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-19 00:00:00+00:00

Feel Next Level in FIFA 21 and Madden NFL 21 on PlayStation®5 and Xbox Series X with new technology that takes football from visual to visceral. Learn more: http://x.ea.com/63539 
#FIFA21 #Madden21 #FeelNextLevel

## FULL EA Play Live 2020 Reveal Event
 - [https://www.youtube.com/watch?v=An56fxfN8pI](https://www.youtube.com/watch?v=An56fxfN8pI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-19 00:00:00+00:00

Check out the full EA Play Live 2020 reveal event featuring Apex Legends, Star Wars Squadrons, Sims, FIFA, Madden 21, and more!




#eaplay
#eaplaylive

## Fire Emblem: Three Houses And Deer Abbey With Joe Zieja (Claude)
 - [https://www.youtube.com/watch?v=cx39SVwb8O8](https://www.youtube.com/watch?v=cx39SVwb8O8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-19 00:00:00+00:00

BLACK LIVES MATTER: http://bit.ly/gs-blm
COVID-19 Direct Relief: http://bit.ly/gs-covid

On today's Play For All charity stream, we're joined by Joe Zieja, the voice of Claude from Fire Emblem: Three Houses, to play the game with us, as well as give out advice as Deer Abbey.

## More Details On Star Wars: Squadrons From Creative Director
 - [https://www.youtube.com/watch?v=0Mc4G0AL_6I](https://www.youtube.com/watch?v=0Mc4G0AL_6I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-19 00:00:00+00:00

Star Wars: Squadrons brings back the classic dogfighting gameplay seen in classics like the X-Wing and TIE Fighter series. In an interview with GameSpot, EA Motive's Ian Frazier talks about the series' roots, how the studio balanced New Republic and Imperial craft, and how team composition can make or break your victory.

The comparisons to the classic Lucasarts series are readily apparent, especially as you're locked to cockpit view and can shift your ship's priorities between weapons, engines, and shields. But that's not the only way Motive drew inspiration. Frazier opened up about how the studio looked back at the strategies from those older games to help the nimble but fragile TIE Fighter feel like a match for the hearty and more full-featured X-Wing.

Whichever side of the conflict you fall on, team composition will make a huge difference. Frazier also detailed how load-outs will be important not just for your own starfighter, but also for coordinating with your teammates. And to avoid what he calls the "death loop" of two pilots simply chasing each other down, Motive has put in a few advanced maneuverability strategies for ace pilots to outgun the competition.

## Pokemon Isle Of Armor DLC First Impressions And Favorite PS5 Reveals - GameSpot After Dark #46
 - [https://www.youtube.com/watch?v=gTZ2KV28law](https://www.youtube.com/watch?v=gTZ2KV28law)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-19 00:00:00+00:00

This week on GameSpot After Dark, Kallie talks about the Pokemon Isle of Armor DLC, Jake is playing Persona 4 Golden on PC, Jean-Luc tried the Ultrakill and System Shock demos, and Lucy revisits Horizon Zero Dawn. We also discuss the New Pokemon Snap announcement, our favorite reveals from the PS5 event, and the nickname for the Eurostar Channel Tunnel.

TIMESTAMPS:
0:00 - Intro
4:30 - Horizon Zero Dawn (What We've Been Playing)
10:30 - Ultrakill (What We've Been Playing)
16:31 - System Shock Alpha Demo (What We've Been Playing)
20:42 - Losing Save Progress In Games
28:45 - Persona 4 Golden On PC (What We've Been Playing)
32:14 - Pokemon Isle Of Armor (What We've Been Playing)
40:20 - Our Favorite News From The PS5 Reveal
52:19 - New Pokemon Snap Announcement
1:00:16 - Secret Chunnel
1:03:33 - Listener Questions
1:19:31 - Outro

## Star Wars Squadrons - Official Gameplay Reveal
 - [https://www.youtube.com/watch?v=eIonDr2OVZs](https://www.youtube.com/watch?v=eIonDr2OVZs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-19 00:00:00+00:00

Take a look at the first gameplay for Star Wars Squadrons as well as some of the modes you and your squad will be able to play.

## 6 Big Changes In Fortnite Season 3's Splashdown
 - [https://www.youtube.com/watch?v=fxj6QPOCuqg](https://www.youtube.com/watch?v=fxj6QPOCuqg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-18 00:00:00+00:00

Chapter 2, Season 3 has officially begun in Fortnite, implementing several changes--some quite noticeable and others less so. Called Splashdown, the new season is water-themed and gives Fortnite an aquatic makeover.

In the video above, Jordan Ramée details the six major changes that are a part of Fortnite Chapter 2, Season 3. The most noticeable change is the new map--Fortnite's battlefield has been completely flooded. To navigate between the landmarks, you'll primarily need to take to the air or the sea in order to get around, and it's via the latter method where you'll encounter Season 3's other major change: loot sharks. Yup, murderous loot sharks.

Like every new season, Splashdown adds a new battle pass to work through, challenges to complete, and cosmetics to unlock. Splashdown adds two new weapons too--one of which, the hunting rifle, is a beloved older weapon that's been freed from its time in the vault. All this and more are detailed in the video above.

GameSpot has officially kicked off Play For All--a celebration of all things gaming. Join us as we bring you the summer's hottest news, previews, interviews, features, and videos, as well as raise money for COVID-19 relief efforts and Black Lives Matter with the help of our friends from around the gaming world. Check out the Play For All schedule for more.

## Apex Legends - FULL Season 5 Presentation | EA Play 2020
 - [https://www.youtube.com/watch?v=Jy8wvrIBW6U](https://www.youtube.com/watch?v=Jy8wvrIBW6U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-18 00:00:00+00:00

Check out Respawn Entertainment's complete Apex Legends presentation at EA Play 2020 including, Lost Treasure, Switch announcement, and more!

## Apex Legends - Official 4K Lost Treasures Collection Event Trailer
 - [https://www.youtube.com/watch?v=i5MixuBRIvg](https://www.youtube.com/watch?v=i5MixuBRIvg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-18 00:00:00+00:00

Take on the “Armed and Dangerous Evolved” limited-time mode, discover the new Crypto Town Takeover, and unlock up to 24 exclusive items! http://x.ea.com/63549


Find what you’re searching for in the Lost Treasures Collection Event. In the new “Armed and Dangerous Evolved” LTM it's snipers, shotguns & Evo Armor only, with no Respawn Beacons. Instead, you'll be able to revive your fallen teammates with a new item: the Mobile Respawn Beacon. You’ll start each match with one in your inventory, so choose wisely when and where to deploy it. Complete challenges and visit the store to unlock up to 24 exclusive items. Journey to the new Crypto Town Takeover to take advantage of the all-seeing Holographic World Map. Complete the collection to call yourself a champ and unlock the new Mirage Heirloom. Happy hunting, Legends! 

Apex Legends™ is a free-to-play battle royale game where legendary characters battle for glory, fame, and fortune on the fringes of the Frontier. Play for free now on Xbox One, PS4, and Origin for PC.

## Apex Legends - Official Lost Treasures Collection Event Trailer
 - [https://www.youtube.com/watch?v=TFl2Ho6YOyU](https://www.youtube.com/watch?v=TFl2Ho6YOyU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-18 00:00:00+00:00

Take on the “Armed and Dangerous Evolved” limited-time mode, discover the new Crypto Town Takeover, and unlock up to 24 exclusive items! http://x.ea.com/63549


Find what you’re searching for in the Lost Treasures Collection Event. In the new “Armed and Dangerous Evolved” LTM it's snipers, shotguns & Evo Armor only, with no Respawn Beacons. Instead, you'll be able to revive your fallen teammates with a new item: the Mobile Respawn Beacon. You’ll start each match with one in your inventory, so choose wisely when and where to deploy it. Complete challenges and visit the store to unlock up to 24 exclusive items. Journey to the new Crypto Town Takeover to take advantage of the all-seeing Holographic World Map. Complete the collection to call yourself a champ and unlock the new Mirage Heirloom. Happy hunting, Legends! 

Apex Legends™ is a free-to-play battle royale game where legendary characters battle for glory, fame, and fortune on the fringes of the Frontier. Play for free now on Xbox One, PS4, and Origin for PC.

## Baldur's Gate 3 Is Far Bigger And Stranger Than We Thought - Larian's Swen Vincke Interview
 - [https://www.youtube.com/watch?v=yecUvbMnkhM](https://www.youtube.com/watch?v=yecUvbMnkhM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-18 00:00:00+00:00

After a short Baldur's Gate 3 demo we sat down with Larian's founder Swen Vincke to talk about the early access plans as well as the huge scope of the game.

Currently the first act of the game that is realising with the early access version is bigger than the entirety of Divinity: Original Sin 2, with more to be added to the locations, classes, spells and races as development on BG3 continues.

While multiplayer will be in the game when Baldur's Gate 3 (maybe) releases in early access in August 2020, there is not currently a Dungeon Master mode in development.

## Cyberpunk 2077 Delayed Again | Save State
 - [https://www.youtube.com/watch?v=_jqhEZzQNlc](https://www.youtube.com/watch?v=_jqhEZzQNlc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-18 00:00:00+00:00

On today's Save State, Persia talks about the delay of Cyberpunk 2077, the scale of Spider-Man: Miles Morales, and Sony's new trademark on the DualSense controller. 

Persia talks about the delay of Cyberpunk 2077 that was announced by the game on Twitter this morning. Cybperpunk 2077 is now set to released on November 19th, 2020. With the additional two months, CD Projekt Red will use the time to properly go through everything, balance game mechanics, and fix a lot of bugs. 

Persia also goes over new details behind Spider-Man: Miles Morales that give us a better idea of how long the game will be. Insomniac said the game will be comparable to Uncharted: The Lost legacy. This means that Spider-Man: Miles Morales will be shorter than the main story but longer than other spin-offs like Infamous: First Light. Even though the main story with Peter Parker isn't over yet, this game will be all about Miles and his journey in learning to be his own Spider-Man. 

Sony has just trademarked it's new slogan for the PS5 DualSense controller. "Heighten Your Senses" likely refers to the haptic feedback feature which will provide another level of immersion through vibrations and varying tension mechanics. This feature will make things like drawing a bow feel more realistic than ever. 

EA Play is this afternoon and we'll be streaming all of the action here on GameSpot during #PlayForAll! The stream will begin at 4PM PST. Play For All is multi-week summer gaming celebration and charity event featuring special guests like Troy Baker, Danny O'Dwyer, and many familiar GameSpot faces. We've already raised thousands of dollars for #BlackLivesMatter and COVID-19 Relief Efforts thanks to all of you! Be sure to tune in every day between 12PM and 2PM PST for interviews, livestreams, and everything in between. 

Play For All schedule:https://www.gamespot.com/play-for-all

Where to donate: BLACK LIVES MATTER: http://bit.ly/gs-blm

COVID-19 Direct Relief: http://bit.ly/gs-covid

#SaveState #GameSpot

## EA Originals Showcase FULL Presentation | EA Play 2020
 - [https://www.youtube.com/watch?v=xGZfbTPXwW8](https://www.youtube.com/watch?v=xGZfbTPXwW8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-18 00:00:00+00:00

Check out three EA Original games announced during the EA Play 2020 livestream.

## EA Play Live 2020 Livestream
 - [https://www.youtube.com/watch?v=NdmSlwn6GjI](https://www.youtube.com/watch?v=NdmSlwn6GjI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-18 00:00:00+00:00

Tune in as EA reveals news, trailers, games, its plans for PS5 and Xbox Series X, and more on June 18, starting at 4 PM PT.

## EA Play Live 2020 Livestream With Pre and Post Show
 - [https://www.youtube.com/watch?v=war7ZFT8g78](https://www.youtube.com/watch?v=war7ZFT8g78)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-18 00:00:00+00:00

Tune in as EA reveals news, trailers, games, its plans for PS5 and Xbox Series X, and more on June 18, starting at 4 PM PT.


For more insights after the event, head to GameSpot.com for extra coverage!
https://www.gamespot.com/articles/ea-play-live-2020-when-and-how-to-watch-todays-dig/1100-6476783/

## Ghostrunner: Exclusive Developer Walkthrough Reveals Cyberspace And New Powers
 - [https://www.youtube.com/watch?v=YJmL2uHcaeE](https://www.youtube.com/watch?v=YJmL2uHcaeE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-18 00:00:00+00:00

The game director of Ghostrunner breaks down what's new in this exclusive walkthrough showing off what's to come in the cyberpunk slash-and-dash game.

## Pokemon Snap Finally Returns | Save State
 - [https://www.youtube.com/watch?v=oHE5o8HZU_4](https://www.youtube.com/watch?v=oHE5o8HZU_4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-18 00:00:00+00:00

The Pokemon Company announces several new games including New Pokemon Snap, and Horizon Forbidden West gets a new in-depth trailer

The Pokemon Company announces several new games including New Pokemon Snap. New Pokemon Snap is coming to the Nintendo Switch, but there's no release date at this time. Pokemon Smile, an app designed to encourage kids to brush their teeth, and Pokemon Cafe Mix, a puzzle game where you play as a cafe owner serving only Pokemon were also announced. To learn about everything that was announced, check out the news story here: https://www.gamespot.com/articles/pokemon-presents-isle-of-armor-launch-new-pokemon-/1100-6478556/

Horizon Forbidden West gets an in-depth trailer which details its setting and new features, with an emphasis on the PS5's SSD, claiming that the game should have "virtually no loading screens." Speaking of PlayStation 5, yes, it can lay horizontally.

For the next five weeks, GameSpot is hosting Play For All, a summer gaming celebration and charity event featuring special guests like Troy Baker, Danny O'Dwyer, and many familiar GameSpot faces. We are all coming together to raise money for Direct Relief in support of those fighting on the frontlines against COVID-19, as well as Black Lives Matter. 

Play For All schedule:https://www.gamespot.com/play-for-all

Where to donate: BLACK LIVES MATTER: http://bit.ly/gs-blm

COVID-19 Direct Relief: http://bit.ly/gs-covid

#SaveState #GameSpot

## Portal 2 With Jake Baldino From Gameranx
 - [https://www.youtube.com/watch?v=YhHVjjImV2Q](https://www.youtube.com/watch?v=YhHVjjImV2Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-18 00:00:00+00:00

Donate to Black Lives Matter: http://bit.ly/gs-blm
Donate to COVID-19 Direct Relief: http://bit.ly/gs-covid

On today's Play For All charity stream, Jake Baldino from Gameranx joins us to play the 2011 classic, Portal 2. Can we escape the nefarious Aperture Laboratories test chambers? Tune in, donate, and find out!

## Rocket Arena Puts Explosive Twist On Hero Shooters
 - [https://www.youtube.com/watch?v=lUMwixymji4](https://www.youtube.com/watch?v=lUMwixymji4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-18 00:00:00+00:00

Rocket Arena is a hero shooter, but with a twist: it’s rockets only. We chatted with Final Strike Games CEO Kevin Franklin on what separates the game from other hero shooters.

As part of Play For All, we chatted with Final Strike Games CEO Kevin Franklin about Rocket Arena, an upcoming hero shooter. As the name suggests, all weapons in Rocket Arena are rocket-based, creating a rather explosive-style of FPS.
 
In the video above, GameSpot host Kurt Indovina and Franklin talk about the process of how Final Strike Games designed Rocket Arena to appeal to a younger audience. Franklin previously worked on shooters like Halo 4, Halo 5: Guardians, and Doom--mechanically solid games, but not exactly approachable to kids in terms of content and the gameplay loop in the multiplayer.
 
That's where Rocket Arena's respawn mechanic comes in. As opposed to dying like in most shooters, you're knocked out of the arena in Rocket Arena. When you're sent flying out, you soar to the top of the arena and get a bird's eye view of the battle below--giving you a chance to forge a strategy and see where all the players are (both enemies and allies) before falling to earth.
 
Rocket Arena is scheduled to release for Xbox One, PS4, and PC. The game will support cross-play between all systems at launch.
 
GameSpot has officially kicked off Play For All--a celebration of all things gaming. Join us as we bring you the summer's hottest news, previews, interviews, features, and videos, as well as raise money for COVID-19 relief efforts and Black Lives Matter with the help of our friends from around the gaming world. Check out the Play For All schedule for more.

## Sims 4 FULL Presentation | EA Play 2020
 - [https://www.youtube.com/watch?v=3mG01GjurcA](https://www.youtube.com/watch?v=3mG01GjurcA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-18 00:00:00+00:00

Check out the latest reveal about The Sims 4 shown off during EA Play 2020.

## Spider-Man: Miles Morales - Official Trailer Recap
 - [https://www.youtube.com/watch?v=DzpyFTzEWwA](https://www.youtube.com/watch?v=DzpyFTzEWwA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-18 00:00:00+00:00

Discover brand-new and explosive powers in Spider-Man: Miles Morales. Coming to PlayStation this Holiday 2020.

## Star Wars: Squadrons - FULL Gameplay Reveal Presentation | EA Play 2020
 - [https://www.youtube.com/watch?v=DDsocY0PowA](https://www.youtube.com/watch?v=DDsocY0PowA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-18 00:00:00+00:00

Watch the full gameplay world premiere presentation of Star Wars: Squadrons at EA Play 2020.

## The Last Of Us Part 2 - 7 Tips To Keep You Alive
 - [https://www.youtube.com/watch?v=Jf0hEj4jwFY](https://www.youtube.com/watch?v=Jf0hEj4jwFY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-18 00:00:00+00:00

Like its predecessor, The Last of Us Part 2 is a brutal game in which you'll have to fight for survival. There are a whole bunch of people who want to kill you in Naughty Dog's post-apocalyptic world, and only some of them are the fungally infected monsters who will rip out your throat and eat you alive. To make it through, you're going to need a lot of skills, both for staying hidden to avoid danger and for killing things and people before they have a chance to kill you.

Check out the video above, where we've put together seven essential tips that will help you get used to the post-apocalypse, make the most of your game, and help Ellie survive to exact her revenge.

If you're a fan of The Last of Us, you might think you have a pretty good handle on how to stay alive as you patrol the area around Jackson or venture into the Seattle QZ. But protagonist Ellie has a bunch of new abilities for you to master this time out, which can have a big impact on the way you play. There are new enemies and challenges to face, as well, and they're out for your blood.

What's more, Naughty Dog has included a bunch of new features for accessibility, allowing you to tune much of The Last of Us Part 2 to be exactly the experience you want, and to offer your ideal challenge. Watch the video above for more on what you'll need to know about The Last of Us Part 2, and stay tuned to GameSpot.com for more The Last of Us Part 2 guides, Easter eggs, and coverage.


For more in-depth guides, tips, and a complete chapter-by-chapter walkthrough, check out our site!
https://www.gamespot.com/articles/ea-play-live-2020-when-and-how-to-watch-todays-dig/1100-6476783/

