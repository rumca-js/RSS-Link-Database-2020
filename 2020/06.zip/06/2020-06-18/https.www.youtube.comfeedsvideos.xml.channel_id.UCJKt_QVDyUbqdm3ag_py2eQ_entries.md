# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## SID music: Jeroen Tel - Cybernoid II (Title) (U64E real 6581 dual mono bx_🎧)
 - [https://www.youtube.com/watch?v=Vus3FXvQzUs](https://www.youtube.com/watch?v=Vus3FXvQzUs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-06-19 00:00:00+00:00

"Cybernoid II: The Revenge" (C64, 1988) title theme by Jeroen Tel.

Ultimate64 Elite real 6581 dual mono setup (identical audio data for both chips, full channel separation):

Left channel: MOS 6581R4AR 0187 14/Hong Kong HH512134 HC-30
Right channel: MOS 6581 3584/Korea AH325137

My 2012 upload, software emulated pure mono Dolbyfied:
https://www.youtube.com/watch?v=ejss7u2hABo

My 2015 upload, software emulated stereo Dolbyfied:
https://www.youtube.com/watch?v=UtoVx8KYdUU

Ultimate64 Elite:
https://ultimate64.com/Ultimate-64-Elite

## SID music: Jeroen Tel - Myth (Title) (FPGASID 6581 dual mono bx_🎧)
 - [https://www.youtube.com/watch?v=FzRDf6BKzOU](https://www.youtube.com/watch?v=FzRDf6BKzOU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-06-19 00:00:00+00:00

"Myth: History in the Making" (C64, 1989) title theme by Jeroen Tel.

Made using FPGASID fw 0A. 2 x 6581 in dual mono. Left bias -3, right bias -4.

My 2012 upload, software emulated pure mono Dolbyfied:
https://www.youtube.com/watch?v=b_p-odkYvrk

My 2014 upload, software emulated stereo Dolbyfied:
https://www.youtube.com/watch?v=CfpOV0_566Q

My 2017 upload, SIDFX 6581 dual mono Dolbyfied:
https://www.youtube.com/watch?v=lrKRga3cEA8

FPGASID:
http://www.fpgasid.de/

## SID music: Michael Hendriks - X-Out (Title) (U64E real 6581 dual mono bx_🎧)
 - [https://www.youtube.com/watch?v=pdsYzIG5g8M](https://www.youtube.com/watch?v=pdsYzIG5g8M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-06-19 00:00:00+00:00

"X-Out" (C64, 1989) title theme arranged for C64 by Michael "F.A.M.E." Hendriks. Original by Chris Hülsbeck for Amiga

Ultimate64 Elite real 6581 dual mono setup (identical audio data for both chips, full channel separation):

Left channel: MOS 6581R4AR 0187 14/Hong Kong HH512134 HC-30
Right channel: MOS 6581 3584/Korea AH325137

My 2012 upload, software emulated pure mono Dolbyfied:
https://www.youtube.com/watch?v=dXPhjetmUsc

My 2017 upload, SIDFX 6581 dual mono Dolbyfied:
https://www.youtube.com/watch?v=JC2h3M6NiWM

Ultimate64 Elite:
https://ultimate64.com/Ultimate-64-Elite

## SID music: Jonathan Dunn - RoboCop (Ingame) (U64E real 6581 dual mono bx_🎧)
 - [https://www.youtube.com/watch?v=Qo8atKQ8U2k](https://www.youtube.com/watch?v=Qo8atKQ8U2k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-06-18 00:00:00+00:00

"RoboCop" (C64, 1989) ingame theme (subtune 2) by Jonathan Dunn.

Ultimate64 Elite real 6581 dual mono setup (identical audio data for both chips, full channel separation):

Left channel: MOS 6581R4AR 0187 14/Hong Kong HH512134 HC-30
Right channel: MOS 6581 3584/Korea AH325137

Ultimate64 Elite:
https://ultimate64.com/Ultimate-64-Elite

