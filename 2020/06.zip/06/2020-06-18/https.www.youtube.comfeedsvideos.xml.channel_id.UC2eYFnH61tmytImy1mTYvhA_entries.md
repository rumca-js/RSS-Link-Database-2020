# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## Set Up a Basic Website! nginx, Certbot & secure login
 - [https://www.youtube.com/watch?v=OWAqilIVNgE](https://www.youtube.com/watch?v=OWAqilIVNgE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-06-19 00:00:00+00:00

Pls don't hack me even though I gave you my root password!

https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://www.vultr.com/?ref=8384069-6G Get a VPS with Vultr and host a website or server for anything else.

In a series of based slightly-off ffmpeg video cuts, I set up a website with all the essentials! After getting a domain, I set up a VPS and direct my domain to it. I then set a secure way to log into with with an ssh key pair. We then install nginx (Engine-X) and set up a super basic web page, and lastly added HTTPS/SSL using Certbot (setting this to try to auto-update every month with a cronjob).

You can easily add more sites to nginx which read different filesystem locations and expect different domains or subdomains.

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE: https://lukesmith.xyz/donate 💰😎👌💯
OR affiliate links to things l use:
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://brave.com/luk005 Get the Brave browser.
https://lbry.tv/$/invite/@Luke View my videos on LBRY.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase.

## Get a Website Now! Don't be a Web Peasant!
 - [https://www.youtube.com/watch?v=bdKZVIGRAKQ](https://www.youtube.com/watch?v=bdKZVIGRAKQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-06-18 00:00:00+00:00

If you don't have your own website, you're just living as a peasant on Reddit or Facebook or Twitter's virtual apartments. Get your own domain name and a VPS to host everything you need. The startup and maintenance costs are pocket change and you get a degree of independence unseen in the modern controlled internet.

To register a domain name, absolutely use Epik (https://www.epik.com/?affid=we2ro7sa6) their prices are as cheap as they get and they have an open commitment to not banning people when asked by media mobs. If you get a domain name from the link above I get some Epik credit so I can continue to keep my domains up after I die lol

To host a website, get a VPS. I use Vultr (https://www.vultr.com/?ref=8384069-6G). That link gives you a free one month credit of $100 to play around with whatever want for then. There are other VPS hosts like Linode and Digital Ocean that are common and good as well. Again, I pay less than $5 for one VPS that handles my three websites, email server, git server, search engine and can be used as a Google Drive file-storage equivalent.

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE: https://lukesmith.xyz/donate 💰😎👌💯
OR affiliate links to things l use:
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://brave.com/luk005 Get the Brave browser.
https://lbry.tv/$/invite/@Luke View my videos on LBRY.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase.

