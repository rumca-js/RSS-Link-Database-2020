# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Słuchawki od Xiaomi wreszcie znośne? Mi Air 2S (Mi AirDots Pro 2S), Mi Air 2SE, Mi AirDots Pro
 - [https://www.youtube.com/watch?v=pBXyuOESbG0](https://www.youtube.com/watch?v=pBXyuOESbG0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-06-18 00:00:00+00:00

Xiaomi Mi Air 2S (Mi AirDots Pro 2S) i Mi Air 2SE. Które lepsze i jak brzmią w porównaniu do Mi AirDots Pro (Mi True Wireless Earphones) ?
Moje sociale: 
insta: http://bit.ly/InstaKlawiatur 
Twitter: http://bit.ly/TTKlawitera
FB: http://bit.ly/FBKlawiatur

Xiaomi Mi Air 2S w Trading Shenzhen: https://bit.ly/3eeIZ02
Xiaomi Mi Air 2SE w Geekbuying: https://bit.ly/2Ya1GMC (PL) https://bit.ly/2UWFlA7 (CN)

00:00 Wstęp
00:16 Nazwy
01:20 Czym różnią się Mi Air 2 od Mi Air 2S
01:56 Podobieństwa Mi Air 2s i Mi Air 2SE
02:09 Różnice między Mi Air 2s i Mi Air 2SE
02:35 Test mikrofonów
04:10 Sterowanie
05:44 Jak grają?
09:36 Jak sprawić, żeby tanie słuchawki grały lepiej?
10:30 Opóźnienie podczas oglądania filmów
10:56 Ceny
12:00 Podsumowanie

