# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Cracker Jack Changes Name To More Politically Correct Caucasian Jack
 - [https://www.youtube.com/watch?v=m3mihK6igcU](https://www.youtube.com/watch?v=m3mihK6igcU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-06-19 00:00:00+00:00

"We are very sorry to all the crack---er, I mean, Caucasians we have hurt over the years," said a spokesperson. "Cracker is an offensive stereotype, and we must make sure that all foods and snack products are culturally sensitive. Think about all the white people who have had to suffer in silence as tens of thousands of baseball fans sang out the hurtful lyrics 'Buy me some peanuts and Cracker Jacks.'"

https://babylonbee.com/news/cracker-jacks-changes-name-to-more-politically-correct-caucasian-jacks

## Podcast: Flashlights And Duct Tape With Brent Mann
 - [https://www.youtube.com/watch?v=62u_IUV8-rk](https://www.youtube.com/watch?v=62u_IUV8-rk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-06-19 00:00:00+00:00

🎙 NEW EPISODE: Today on The Babylon Bee podcast, Kyle and Ethan celebrate the one year anniversary of the show and welcome Kyle’s dad, Brent, for Father’s Day. They talk shop about duct tape, flashlights, initialisms, rocket science, and dad hacks. They also dive into the week's news stories.

Kyle and Ethan enlighten Brent on what CHAZ or CHOP is, and then discuss Elon Musk's quest to occupy Mars, and get into our favorite aerospace engineer’s perspective on seeing God in creation.

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Gain Access to the Exclusive Content and Writing Forum: https://babylonbee.com/plans

The Official Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

