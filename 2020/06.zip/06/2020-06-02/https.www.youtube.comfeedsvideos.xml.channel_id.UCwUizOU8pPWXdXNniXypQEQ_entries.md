# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Why the Lockdown Should Last Longer
 - [https://www.youtube.com/watch?v=oxznGIj8Ja0](https://www.youtube.com/watch?v=oxznGIj8Ja0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-06-03 00:00:00+00:00

Here's why the lockdown should never end. In the global pandemic the lockdown has been used and extended. Many think it should end. Here's why they're wrong and it should potentially never end.

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Click Here to join my PATREON - https://awakenwithjp.com/patron
---- Want to be the first to see my new videos with 24 hour early access? Just click this to receive the alerts! - https://m.me/awakenwithjp?ref=w6836464

Listen and Subscribe to my NEW Podcast here: 
https://podcasts.apple.com/ca/podcast/awaken-with-jp-sears-show/id1436938686
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

-Order my new book at: http://HowToBeUltraSpiritual.com/

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

