# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Joe Rogan Experience #1485 - Krystal & Saagar
 - [https://www.youtube.com/watch?v=eA9Tpf5Uuxs](https://www.youtube.com/watch?v=eA9Tpf5Uuxs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2020-06-03 00:00:00+00:00

Krystal & Saagar are the hosts of Rising, an American daily news and opinion web series produced by Washington, D.C. political newspaper The Hill. @thehill

