# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Becoming a 26 Year Old MILLIONAIRE Hasn't Changed Me At All
 - [https://www.youtube.com/watch?v=D6c4HFtJd3I](https://www.youtube.com/watch?v=D6c4HFtJd3I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-06-02 00:00:00+00:00

I don't mean to FLEX but.............................

## THIS GURU DESTROYS ALBERT EINSTEIN - Laughing Babas Ep. 1
 - [https://www.youtube.com/watch?v=BK5FQAFY8zs](https://www.youtube.com/watch?v=BK5FQAFY8zs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-06-02 00:00:00+00:00

The first episode of Coffeezilla and Amish Patel's new show, Laughing Babas. We cover Nityananda, Joel Olsteen, chairs of many sizes and much, much more. 

Let us know what you think!
Outro Music - 
Get yer Paper - the Defibulators

