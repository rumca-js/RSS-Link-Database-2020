# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Taking on Anti-Abortion "Lies"
 - [https://www.youtube.com/watch?v=Zu60dRT8-5o](https://www.youtube.com/watch?v=Zu60dRT8-5o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-06-03 00:00:00+00:00

Ethan and Kyle try to stump Lila Rose with some common anti-abortion "lies." 

Watch this full podcast episode: https://babylonbee.com/news/save-the-babies-the-lila-rose-interview

## Save The Babies: The Lila Rose Interview
 - [https://www.youtube.com/watch?v=8S2faDXUAII](https://www.youtube.com/watch?v=8S2faDXUAII)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-06-02 00:00:00+00:00

Kyle and Ethan talk to pro-life activist Lila Rose from LiveAction.org about opposition to her organization, politicians gaslighting, and fostering a culture of life. Watch Kyle and Ethan get owned by facts and logic and be told their jokes are bad.

Be sure to check out Lila's new podcast: The Lila Rose Show.

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Gain Access to the Exclusive Content and Writing Forum: https://babylonbee.com/plans

The Official Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

