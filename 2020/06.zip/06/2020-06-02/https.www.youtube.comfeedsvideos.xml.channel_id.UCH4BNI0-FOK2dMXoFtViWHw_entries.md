# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## Why Deadly Viral Pandemics Are Becoming More Common
 - [https://www.youtube.com/watch?v=k8sYqWssKoQ](https://www.youtube.com/watch?v=k8sYqWssKoQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2020-06-03 00:00:00+00:00

PBS Member Stations rely on viewers like you. To support your local station, go to: http://to.pbs.org/DonateOKAY
↓ More info and sources below ↓

We’re on PATREON! Join the community ►► https://www.patreon.com/itsokaytobesmart
SUBSCRIBE so you don’t miss a video! ►► http://bit.ly/iotbs_sub 

Viruses keep jumping out of nature and into humans and getting us very sick in the process. So why do zoonotic spillovers like SARS-CoV-2 happen, and why are they becoming more frequent? We asked an expert. 

#coronavirus #zoonosis #itsokaytobesmart

Special thanks to David Quammen
For more, please read “Spillover: Animal Infections and the Next Human Pandemic” by David Quammen https://amzn.to/2AvxIta

If you doubt the claim about Earth's viruses stretching millions of light-years, then read this Nature paper: https://www.nature.com/articles/nrmicro2644.pdf

Special thanks to our Brain Trust Patrons:
AlecZero
Diego Lombeida
Dustin
Ernesto Silva
George Gladding
Jay Stephens
Marcus Tuepker
Megan K Bradshaw
Peter Ehrnstrom
Ron Kakar
vincbis

Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/

