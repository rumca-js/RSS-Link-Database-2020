# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## The Claypool Lennon Delirium - full session at The Current
 - [https://www.youtube.com/watch?v=7DhRs288uuM](https://www.youtube.com/watch?v=7DhRs288uuM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-06-03 00:00:00+00:00

The Claypool Lennon Delirium, as the name suggests, has as its nucleus Les Claypool and Sean Lennon. Their 2019 album, 'South of Reality,' was recorded at Rancho Relaxo — the name Claypool has given his home studio in Sonoma County, California. Watch this session from April 2019, when the Claypool Lennon Delirium visited The Current to perform three songs off the album.

SONGS PERFORMED
0:00 "Little Fishes"
05:46 "Easily Charmed By Fools"
10:36 "Blood and Rockets"

PERSONNEL
Les Claypool
Sean Lennon
João Nogueira
Paulo Baldi

CREDITS
Video & Photo: Nate Ryan
Audio: Michael DeMark
Production: Derrick Stevens

FIND MORE:
https://www.thecurrent.org/feature/2019/04/25/the-claypool-lennon-delirium-play-songs-chat-with-mary-lucia-in-the-current-studio


Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Brandi Carlile - three songs recorded for The Current
 - [https://www.youtube.com/watch?v=DM0_WhsHJ0g](https://www.youtube.com/watch?v=DM0_WhsHJ0g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-06-02 00:00:00+00:00

June 1 is the birthday of singer-songwriter Brandi Carlile, so in honor of that, we're sharing three performances by Carlile and her band.

SONGS PERFORMED
00:00 "That Wasn't Me"
03:50 "Wherever Is Your Heart"
07:49 "The Joke"

PERSONNEL
Brandi Carlile
Phil Hanseroth
Tim Hanseroth
Josh Neumann

CREDITS
Video & Photo: Nate Ryan
Audio: Michael DeMark
Production: Derrick Stevens

FIND MORE:
2012 studio session: https://www.thecurrent.org/feature/2012/06/27/brandicarlile-live
2014 studio session: https://www.thecurrent.org/feature/2014/12/30/brandi-carlile-performs-in-the-current-studio

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Minnesota music community shows up, helps out, calls for change (The Current Music News)
 - [https://www.youtube.com/watch?v=995Kqh6cLrM](https://www.youtube.com/watch?v=995Kqh6cLrM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-06-02 00:00:00+00:00

June 2, 2020: After a week of protest and pain in the Twin Cities after the death of George Floyd, Jay and Jade look at the Minnesota music scene and its calls for institutional change. Also, Andre Cymone reflects on his experiences with racism in Minneapolis when he was growing up with Prince.
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

