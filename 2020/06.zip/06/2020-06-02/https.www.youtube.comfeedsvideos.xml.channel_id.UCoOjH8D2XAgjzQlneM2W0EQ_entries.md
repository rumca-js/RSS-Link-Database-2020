# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## Lucky Luciano: The Elon Musk of the Mafia & Organized Crime
 - [https://www.youtube.com/watch?v=jf3t83uREtQ](https://www.youtube.com/watch?v=jf3t83uREtQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2020-06-03 00:00:00+00:00

🗣️ Sign up today to get 50% off for limited time only! https://bit.ly/JakeTran

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join 

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

The other mafia video: https://youtu.be/8MjDEuTuRD0
🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
📸 Follow me on IG:@jaketran // http://bit.ly/jt-ig
👨👦👦 Join the Tran Mafia Family here: https://bit.ly/patreon-jt
💬 Join the community Discord: http://discord.gg/BmK8EnQ

Stuff I use & recommend:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
🏠 The real estate investing course I love & recommend: https://jake.yt/RE
🌐 Most flexible, affordable website hosting: https://jake.yt/bhd
🖥️ Website platform I use & love: https://jake.yt/kd
💽 Editing software I've used for 7+ years: https://jake.yt/ccd
📒 Online bookkeeping software I use& love: https://jake.yt/benchd 
🧾 Best affordable bookkeeping software: https://jake.yt/fbd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd
📚 Get 3 free audiobooks for life: https://amzn.to/2v58PSu
🎥 My video gear, setup, tech, books: https://jake.yt/stored

✉️ Email me: jake@jaketran.io

Subscribe to the backup channel on LBRY, use reward code "jake-cast" for free coin: https://bit.ly/LBRY-jt

📰 Sources & visuals: https://bit.ly/3chLuN7

-----------------------
In light of the mafia trilogy remastered remake, I wanted make a mini-documentary on the founder of organized crime and that made the mafia game possible - Charles Lucky Luciano.

It’s 1931, near the end of the very profitable prohibition era in New York, things are pretty lawless in the criminal underground.

You’re Lucky Luciano, a mobster in New York’s largest Italian gang, headed by, aka “Joe the Boss”. You’re part of the rising second generation of Italian mobsters that spoke English and were raised in America. You didn’t care for silly things. You were an entrepreneur and a Scilian. You saw the opportunity to make even more money by expanding operations into new ventures.

Joe the Boss was against the second biggest Italian borgata, headed by Salvatore Maranzano. He was too power hungry and caught up in his giant ego. And you’ve grown a little disenchanted by all this violence. Even if this war were to end right now, war will certainly break out again in the future. After some murders here & there, you end this war and created The Commission.

This war started when your boss, Giuseppe Joe the Boss Masseria, got the idea that he would be able to declare himself as the boss of bosses, and all the other gangs would just submit to his rule.

Eighteen months later, you finally decided to end it. You went to Maranzano and made a deal behind your bosses back. You’ll get to claim victory and get recognized as the new boss of Joe’s family. Maranzano accepted. And boom - the war was over. Maranzano won and recognized you as the boss.

But Maranzano decided to go back on the deal he made with you by making the same arrogant mistake that Joe the Boss made. Maranzano forced all families into the tight chain of command. He brought all the traditional rules from the Sicilian mafia to America. Maranzano betrayed you. If you don’t act fast, you’ll be lying next to your old boss.

Everyone knew Luciano was practically the Boss of all Bosses. The Five Families slowly but surely DESTROYED their competition. Lucky Luciano became the most powerful mobster in New York.

The rise of the ambitious Luciano gave rise to an prosecutor, named Thomas Dewey. Dewey’s goal was to paint the prostitutes as poor that Lucky took advantage of. Luciano was sentenced to 30-50 years in prison. Once he was out of prison, Dewey got him deported back to Italy and never got to see his beloved home of New York ever again until he died of a heart attack at 64.
-----------------------

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2020 Jake Tran. All rights reserved.

DISCLAIMER: These videos are for entertainment purposes only. This is not meant to be financial advice. Please always do your due diligence and never stop learning.

AFFILIATE DISCLOSURE: Some of the links in this video description are affiliate links, meaning, at no additional cost to you, I may earn a commission if you click through and make a purchase and/or opt-in. I only promote products that I 100% believe in.

