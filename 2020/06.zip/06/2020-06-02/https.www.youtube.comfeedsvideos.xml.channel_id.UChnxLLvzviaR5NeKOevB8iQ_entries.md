# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## The Nord Drum 3P (with Digitakt friend!)
 - [https://www.youtube.com/watch?v=tQSN9ZTB0nc](https://www.youtube.com/watch?v=tQSN9ZTB0nc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2020-06-03 00:00:00+00:00

The Nord Drum 3p is a digital percussion modeling synthesizer and powerful performance device. In this video, I show how, from a sequencers perspective, how I would use the 3p to make music.

This demo unit was provided by zzounds.com, who I'm partnering with for loaner gear to feature on the channel. They didn't pay me anything, but I have set up an affiliate program with them, so any videos featuring zzounds gear will have links that, if you buy something from them, will help my channel. Thanks for watching.
Digitakt: https://www.zzounds.com/a--3970449/item--ELKDIGITAKT
Nord Drum 3p: https://www.zzounds.com/a--3970449/item--NORDRUM3P

Here are the MIDI CCs I used: 

7 Level
21 Noise Decay
23 Dist Amount
30 Tone Spectra
50 Tone Decay
53 Tone Dyn Filter
47 Delay Amount
48 Reverb Amount
------------------------------------
Patreon: http://bit.ly/rmrpatreon
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe
T-Shirts: http://bit.ly/rmrshirts
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

