# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## Windows Task Manager Secrets - From the Guy Who Wrote It
 - [https://www.youtube.com/watch?v=_MXFcqnP-R4](https://www.youtube.com/watch?v=_MXFcqnP-R4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2020-06-03 00:00:00+00:00

The original creator of the legendary task manager recently created a thread on reddit where he talked a bit about the history of it's creation, as well as some tips you might not have known. 
• The thread: https://www.reddit.com/r/techsupport/comments/gqb915/i_wrote_task_manager_and_i_just_remembered/
• Dave's Channel: https://www.youtube.com/channel/UCNzszbnvQeFzObW0ghk0Ckw

⇒ Become a channel member for exclusive features! Check it out here: https://www.youtube.com/ThioJoe/join

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe

⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV

My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

#Windows #Tech #ThioJoe

