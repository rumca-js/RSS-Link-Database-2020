# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Making the iPhone Perfect in 2 Minutes  - Unc0ver IOS 13.5 Jailbreak
 - [https://www.youtube.com/watch?v=HGHQ5R3NwrA](https://www.youtube.com/watch?v=HGHQ5R3NwrA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-06-03 00:00:00+00:00

Receive an additional $25 credit for Ting today when you sign up at https://linus.ting.com/

IOS 13.5 just launched, and with about 2 minutes of your time, you can easily jailbreak your iPhone allowing for tons of customization to better your phone experience.

unc0ver Website: https://unc0ver.dev/
AltStore Website: https://altstore.io/
iTunes Download: https://www.apple.com/itunes/download/win64
iCloud Download: https://support.apple.com/en-us/HT204283
Download IOS 13.5 IPSW/File: https://ipsw.me/

Packix Repo: https://repo.packix.com/
SparkDev Repo: https://sparkdev.me/

*Update*: Renew Side-Loaded Apps Without AltServer!: https://www.redmondpie.com/how-to-install-reprovision-to-sign-unc0ver-ios-13.5-jailbreak-no-computer-required/
Reddit Post With Lots of Tweaks: https://www.reddit.com/r/jailbreak/comments/gsta94/discussion_linustechtips_is_asking_for_our/

Discuss on the forum: https://linustechtips.com/main/topic/1204173-make-your-iphone-perfect-in-2-minutes-unc0ver-ios-135-jailbreak/

Buy an iPhone
On Amazon (PAID LINK): https://geni.us/CbEu
On Newegg (PAID LINK): https://geni.us/kgAUeB

Purchases made through some store links may provide some compensation to Linus Media Group.

GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Mech Keyboard: https://geni.us/RecNBTI
NEEDforSEAT Gaming Chairs: https://geni.us/needforseat
Get a Displate Metal Print at https://lmg.gg/displateltt
Use code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Gear on Amazon: https://geni.us/lmgamazon
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0 https://lmg.gg/fxHYK 
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://lmg.gg/Q9yyQ 
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://lmg.gg/8upii

## Will More RAM Make your PC Faster?? (2020)
 - [https://www.youtube.com/watch?v=kUFWalEf31w](https://www.youtube.com/watch?v=kUFWalEf31w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-06-02 00:00:00+00:00

Get 10% Off XSplit VCam with offer code LINUSTECHTIPS at https://xspl.it/lttvcam

How much ram do you really need? 4GB ? 256GB? 1.5TB ?!  Do games like Tomb Raider and Rainbow 6 Siege only need 8GB to run well?   We test a whole bunch of Corsair Vengeance LPX ram so you dont have to. 

Thanks to Flow Joe for the simulation model! 
Also thanks to Neil Parfitt for the info, check out his channel here: https://lmg.gg/TBU7C 

Buy  Corsair Vengeance LPX 8GB
On Amazon (PAID LINK): https://geni.us/QdU9Oe
On Newegg (PAID LINK): https://geni.us/SgcI

Buy  Corsair Vengeance LPX 16GB
On Amazon (PAID LINK): https://geni.us/4GGc2
On Newegg (PAID LINK): https://geni.us/WJTI

Buy  Corsair Vengeance LPX 32GB
On Amazon (PAID LINK): https://geni.us/QoW9IgA
On Newegg (PAID LINK): https://geni.us/42fYk

Buy  Corsair Vengeance LPX 64GB
On Amazon (PAID LINK): https://geni.us/wLtw
On Newegg (PAID LINK): https://geni.us/YYnYQ

Buy  Corsair Vengeance LPX 128GB
On Amazon (PAID LINK): https://geni.us/gznG02I
On Newegg (PAID LINK): https://geni.us/LamDA

Buy  Corsair Vengeance LPX 256GB
On Amazon (PAID LINK): https://geni.us/b7rB3
On Newegg (PAID LINK): https://geni.us/NWfaV

Buy  ASUS ROG Zenith II Extreme
On Amazon (PAID LINK): https://geni.us/L2MC8nG
On Newegg (PAID LINK): https://geni.us/8n8B6

Buy  AMD Ryzen Threadripper 3960X 
On Amazon (PAID LINK): https://geni.us/YSfXIMW
On Newegg (PAID LINK): https://geni.us/HhTLm6

Buy GeForce RTX 2080 SUPER
On Amazon (PAID LINK): https://geni.us/xK17
On Newegg (PAID LINK):https://geni.us/GlhPBl 

Buy Seasonic Prime 1000 Titanium
On Amazon (PAID LINK): https://geni.us/6v9C
On Newegg (PAID LINK): https://geni.us/v3JRr

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://lmg.gg/lheos


GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Mech Keyboard: https://geni.us/RecNBTI
NEEDforSEAT Gaming Chairs: https://geni.us/needforseat
Get a Displate Metal Print at https://lmg.gg/displateltt
Use code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Gear on Amazon: https://geni.us/lmgamazon
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0 https://lmg.gg/fxHYK 
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://lmg.gg/Q9yyQ 
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://lmg.gg/8upii

