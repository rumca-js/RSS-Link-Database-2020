# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Science Fiction: A Complete History
 - [https://www.youtube.com/watch?v=nrm5nCETPXY](https://www.youtube.com/watch?v=nrm5nCETPXY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-06-03 00:00:00+00:00

From Frankenstein to the Three-Body Problem, Science Fiction has a rich and interesting history. Let's talk about that! 
Art Provided By: https://www.instagram.com/yoichi.art/

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## ASSASSIN'S APPRENTICE - REVIEW
 - [https://www.youtube.com/watch?v=Q04w8V9BJKY](https://www.youtube.com/watch?v=Q04w8V9BJKY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-06-02 00:00:00+00:00

My review of Robin Hobb's Assassin's Apprentice! Let me know what you think of the farseer trilogy and you can get the book here: https://amzn.to/3dr87QH

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

