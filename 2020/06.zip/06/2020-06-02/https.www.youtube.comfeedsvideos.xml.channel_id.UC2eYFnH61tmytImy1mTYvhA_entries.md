# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## *Literally* TIME TRAVELING in Vim (and other tips)
 - [https://www.youtube.com/watch?v=X6tvJDc5LpQ](https://www.youtube.com/watch?v=X6tvJDc5LpQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-06-02 00:00:00+00:00

When undo and redo are not enough, we literally time travel in vim---but I also do some other things in the meantime, like universal substitute commands, dot commands and global regex matching for particular commands. All IDE-cux are on sewer-slide watch now and will be posting cope in the comments.

DONATE NOW: https://lukesmith.xyz/donate 💰😎👌💯
WEBSITE: https://lukesmith.xyz 🌐❓🔎

