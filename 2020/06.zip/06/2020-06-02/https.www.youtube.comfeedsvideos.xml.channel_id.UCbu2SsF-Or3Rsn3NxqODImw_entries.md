# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Alanah Pearce Guest Charity Stream | Play For All Day 3
 - [https://www.youtube.com/watch?v=dYQgzo234hI](https://www.youtube.com/watch?v=dYQgzo234hI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-03 00:00:00+00:00

BLACK LIVES MATTER: http://bit.ly/gs-blm

COVID-19 Direct Relief: http://bit.ly/gs-covid

Welcome to Play For All, a new kind of event hosted by GameSpot. It combines all the in-depth gaming news and reveals you’d expect from E3, with a six-week long charity drive. Today we’re playing Minecraft Dungeons with Alanah Pearce, while raising money for Black Lives Matter, and Direct Relief.

## The Last Of Us Part 2 - Official Extended Commercial
 - [https://www.youtube.com/watch?v=aanR55xFzP4](https://www.youtube.com/watch?v=aanR55xFzP4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-03 00:00:00+00:00

Continue Ellie's journey when The Last of Us Part II finally arrives June 19.

## Valorant's Future Agent Plans And Console Prototypes
 - [https://www.youtube.com/watch?v=Wx52iTfkJzc](https://www.youtube.com/watch?v=Wx52iTfkJzc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-03 00:00:00+00:00

Before Valorant's June launch we got to talk with Riot executive producer Anna Donlon as part of GameSpot's Play For All charity event. 

We talked about how Valorant's developer plan to release future agents, following the pattern of games like Overwatch and Rainbow Six: Siege as well as the controversial anti-cheat tools that Valorant first released with and if we will ever see Valorant on the Xbox Series X or PlayStation 5.

Valorant released as a free-to-play title on June 2, along with a new game mode Spike Rush and the new agent Reyna. We will be bringing you the latest news on Riot's free-to-play shooter whenever new content or seasons are released.

## GameSpot Stands With Black Lives Matter
 - [https://www.youtube.com/watch?v=t8-zMsg33GM](https://www.youtube.com/watch?v=t8-zMsg33GM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-02 00:00:00+00:00

In solidarity with Black Lives Matter and as part of Blackout Tuesday, we have made the decision to postpone today's charity stream. Instead, we ask you to consider donating to Black Lives Matter.

Black Lives Matter - http://tinyurl.com/gs-blm

## PS5 Event Delayed For A Good Reason | Save State
 - [https://www.youtube.com/watch?v=KzmLhgBgisk](https://www.youtube.com/watch?v=KzmLhgBgisk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-02 00:00:00+00:00

Sony delays its PlayStation 5 stream until further notice. We'll be getting more details on Pokemon Sword & Shield's DLC Isle of Armor very soon. Sega's got a big announcement lined up later this week coming from Famitsu magazine.

Also, for the next six weeks GameSpot is hosting Play For All, a summer gaming and charity celebration featuring special guests like Alanah Pearce, Troy Baker, Danny O'Dwyer, and many familiar GameSpot faces. All of which are coming together to raise money for Direct Relief in support of those fighting on the frontlines against COVID-19, and Black Lives Matter.

Where to donate:
tinyurl.com/gs-blm
tinyurl.com/gsplayforall

Where to watch:
youtube.com/gamespot 

#SaveState #GameSpot

