# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## VR's BIGGEST problem is SOLVED!
 - [https://www.youtube.com/watch?v=8K1pc9NcVOM](https://www.youtube.com/watch?v=8K1pc9NcVOM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-06-03 00:00:00+00:00

Hello and welcome to, TUESDAY NEWSDAY! your number one resource for the entire weeks worth of VR news. sorry today's video was a day late! My bad. This week I cover a variety of things but the biggest one is by far the standardization of wireless headsets moving forward using WIFI 6e


RIFT S VRCOVER(affiliate)
https://vrcover.com/product/silicone-cover-for-oculus-rift-s/?itm=322&campaign=TS
Quest VRCOVER
https://vrcover.com/product/silicone-sleeve-quest/?itm=322&campaign=TS

My links:

https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill


Today I will cover:
Half life alyx surge stays steady:
https://www.roadtovr.com/half-life-alyx-surge-steam-vr-survey/

Wifi6e and wireless VR is ON ITS WAY!
https://www.roadtovr.com/qualcomm-wifi-6e-fastconnect-vr-streaming-latency/

meme break:
https://www.techradar.com/news/lenovo-unveils-new-standalone-mirage-vr-s3-headset

2klikphilipvideo:

HP reverb G2 details and hype burst:
https://uploadvr.com/?p=95238

