# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Trzy zdjęcia alki
 - [https://www.youtube.com/watch?v=VjJVbukWwm0](https://www.youtube.com/watch?v=VjJVbukWwm0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2020-06-02 00:00:00+00:00

📚 MOJA KSIĄŻKA! Wejdź na https://geny.altenberg.pl i zamów swój „Przepis na człowieka”! Do 8.06.2020 darmowa wysyłka na terenie Polski
#przepisnaczłowieka 

Spotify ► https://open.spotify.com/show/4JsLCUxjmjDnTsaeT7yj1o
Patronite ► https://patronite.pl/NaukowyBelkot 
Mix audio ► http://ratstudios.pl/

Coś, przed czym się powstrzymywałem. Ale nie wiem, czy nie chciałbym jednak tego robić na swoim drugim kanale.

Subskrypcja ► https://youtube.com/c/UwagaNaukowyBelkot
Facebook ► https://facebook.com/UwagaNaukowyBelkot
Twitter ► https://twitter.com/NaukowyBelkot
Instagram ► https://www.instagram.com/NaukowyBelkot/

Wyłącznie Naukowy Bełkot ► https://goo.gl/Do7VCc
Grupa na facebooku ► https://goo.gl/HP8J83

