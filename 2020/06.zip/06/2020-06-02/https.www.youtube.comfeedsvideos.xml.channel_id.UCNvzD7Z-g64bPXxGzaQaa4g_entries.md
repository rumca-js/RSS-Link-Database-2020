# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Best Games Where You Can PLAY AS GOD
 - [https://www.youtube.com/watch?v=MB5mOC3Ngm8](https://www.youtube.com/watch?v=MB5mOC3Ngm8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-06-03 00:00:00+00:00

Some games let you do whatever you want, but only a few games make you actually play as a god. Here are some of our favorite examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## Valorant - Before You Buy
 - [https://www.youtube.com/watch?v=s6o6-9pVOwU](https://www.youtube.com/watch?v=s6o6-9pVOwU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-06-03 00:00:00+00:00

Valorant (PC) is a competitive FPS taking the world by storm. What is it? We're here to break it down.
Subscribe for more: http://youtube.com/gameranxtv

Thumbnail art via: https://twitter.com/qfnfx/status/1249739523145285632

## 10 Best FREE iOS & Android Games of May 2020
 - [https://www.youtube.com/watch?v=sm9UZxfU5UE](https://www.youtube.com/watch?v=sm9UZxfU5UE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-06-02 00:00:00+00:00

Looking for something to play on your iOS or Android device? We've got you covered with these new games from May.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Forza Street
Platform: iOS Android
Price: Free
https://apps.apple.com/us/app/forza-street/id1453783746
https://play.google.com/store/apps/details?id=com.microsoft.gravity&hl=en_IN

BE-A Walker
Android: Free, iOS [Paid] 
https://play.google.com/store/apps/details?id=com.tequilabyte.walker&hl=en
https://apps.apple.com/us/app/be-a-walker/id1499068771

Bullet Echo
Platform: iOS Android
Price: Free
https://apps.apple.com/us/app/bullet-echo/id1500726361
https://play.google.com/store/apps/details?id=com.petukhov.bulletecho.google&hl=en_IN

Vikings II
Platform: iOS Android
Price: Free
https://apps.apple.com/us/app/vikings-ii/id1494471470
https://play.google.com/store/apps/details?id=com.pid.vikings2

Pico Hero
https://apps.apple.com/us/app/pico-hero/id1506713362
https://play.google.com/store/apps/details?id=com.cappy1.picohero

Sonic at the Olympic Games
Platform: iOS Android
Price: Free
https://apps.apple.com/us/app/sonic-at-the-olympic-games/id1484836043
https://play.google.com/store/apps/details?id=com.sega.tokyo&hl=en_IN

KartRider Rush+
Platform: iOS Android
Price: Free
https://apps.apple.com/us/app/kartrider-rush/id1466736988
https://play.google.com/store/apps/details?id=com.nexon.kart&hl=en

SpongeBob: Krusty Cook-Off
Platform: iOS Android
Price: Free
https://apps.apple.com/us/app/spongebob-krusty-cook-off/id1433784188
https://play.google.com/store/apps/details?id=com.tiltingpoint.spongebob&hl=en

Blade & Soul Revolution [Western Release soon]
Platform: iOS Android
Price: Free
https://apps.apple.com/us/app/blade-soul-revolution/id1497279864
https://play.google.com/store/apps/details?id=com.netmarble.bnsmasia&hl=en_IN


Sandship: Crafting Factory
Platform: iOS Android
Price: Free
https://apps.apple.com/us/app/sandship-crafting-factory/id1440385758
https://play.google.com/store/apps/details?id=com.rockbite.sandship


BONUS

Danganronpa: Trigger Happy Hav
Platform: iOS Android
Price: $15.99
https://apps.apple.com/us/app/danganronpa-trigger-happy-hav/id1502232038
https://play.google.com/store/apps/details?id=jp.co.spike_chunsoft.DR1&hl=en 


Juicy Realm
Platform: iOS Android
Price:$2.99
https://apps.apple.com/us/app/juicy-realm/id1453808408
https://play.google.com/store/apps/details?id=net.spacecan.juicyrealm.android&hl=en_IN

