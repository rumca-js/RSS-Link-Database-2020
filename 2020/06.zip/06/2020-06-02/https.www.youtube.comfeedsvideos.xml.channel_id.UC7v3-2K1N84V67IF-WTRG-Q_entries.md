# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## The Rock - Movie Review
 - [https://www.youtube.com/watch?v=9gdzlkG2QTQ](https://www.youtube.com/watch?v=9gdzlkG2QTQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-06-03 00:00:00+00:00

A mid 90's Michael Bay action movie that I always considered his best. Does it hold up? Here's my review for THE ROCK!

