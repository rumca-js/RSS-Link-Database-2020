## US Senators Introduce 'Lawful Access to Encrypted Data Act' - With Backdoor Mandate
 - [https://news.bitcoin.com/lawful-access-to-encrypted-data-act-backdoor/](https://news.bitcoin.com/lawful-access-to-encrypted-data-act-backdoor/)
 - RSS feed: news.bitcoin.com
 - date published: 2020-06-02 12:26:32+00:00



