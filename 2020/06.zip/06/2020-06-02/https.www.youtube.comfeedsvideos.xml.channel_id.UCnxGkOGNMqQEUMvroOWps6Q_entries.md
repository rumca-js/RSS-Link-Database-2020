# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Governor Cuomo's Mishandling of Coronavirus in Nursing Homes w/Krystal and Saagar
 - [https://www.youtube.com/watch?v=0RajcBdN54E](https://www.youtube.com/watch?v=0RajcBdN54E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-03 00:00:00+00:00

Taken from JRE #1485 w/Krystal and Saagar:
https://youtu.be/eA9Tpf5Uuxs

## How the DC Establishment Tripped Up the Trump Presidency
 - [https://www.youtube.com/watch?v=lRJt1GsQ-Ns](https://www.youtube.com/watch?v=lRJt1GsQ-Ns)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-03 00:00:00+00:00

Taken from JRE #1485 w/Krystal and Saagar: https://youtu.be/eA9Tpf5Uuxs

## Joe Rogan on Trump’s “Ill-Conceived” Bible Photo-Op
 - [https://www.youtube.com/watch?v=woHKMPVarsk](https://www.youtube.com/watch?v=woHKMPVarsk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-03 00:00:00+00:00

Taken from JRE #1485 w/Krystal and Saagar: https://youtu.be/eA9Tpf5Uuxs

## Krystal and Saagar on Restoring American Economic Confidence
 - [https://www.youtube.com/watch?v=0_L012XlwLA](https://www.youtube.com/watch?v=0_L012XlwLA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-03 00:00:00+00:00

Taken from JRE #1485 w/Krystal and Saagar: https://youtu.be/eA9Tpf5Uuxs

## Saagar Enjeti on What Trump is Like in Real Life | Joe Rogan
 - [https://www.youtube.com/watch?v=t7k0YHkJTmk](https://www.youtube.com/watch?v=t7k0YHkJTmk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-03 00:00:00+00:00

Taken from JRE #1485 w/Krystal and Saagar:
https://youtu.be/eA9Tpf5Uuxs

## Should We Use the Military to Quell Rioting in America's Cities?
 - [https://www.youtube.com/watch?v=YVgyfIxvb3Y](https://www.youtube.com/watch?v=YVgyfIxvb3Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-03 00:00:00+00:00

Taken from JRE #1485 w/Krystal and Saagar: 
https://youtu.be/eA9Tpf5Uuxs

## The Cable News Response to the George Floyd Riots w/Krystal and Saagar | Joe Rogan
 - [https://www.youtube.com/watch?v=_oksINmrv7E](https://www.youtube.com/watch?v=_oksINmrv7E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-03 00:00:00+00:00

Taken from JRE #1485 w/Krystal and Saagar:
https://youtu.be/eA9Tpf5Uuxs

## Why Are Corporations Really Supporting the George Floyd Protests?
 - [https://www.youtube.com/watch?v=JPAaRsjDkC8](https://www.youtube.com/watch?v=JPAaRsjDkC8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-03 00:00:00+00:00

Taken from JRE #1485 w/Krystal and Saagar: https://youtu.be/eA9Tpf5Uuxs

## Joe Rogan and Reggie Watts on Evolving Human Consciousness
 - [https://www.youtube.com/watch?v=q1YzuOfIbzU](https://www.youtube.com/watch?v=q1YzuOfIbzU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-02 00:00:00+00:00

Taken from JRE #1484 w/Reggie Watts: https://youtu.be/Mcle87Uvh8Y

## Joe Rogan on Agent Provocateurs During George Floyd Protests, Mysterious Pallets of Bricks
 - [https://www.youtube.com/watch?v=a59q6tVHyJ4](https://www.youtube.com/watch?v=a59q6tVHyJ4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-02 00:00:00+00:00

Taken from JRE #1484 w/Reggie Watts:
https://youtu.be/Mcle87Uvh8Y

## Joe Rogan on the George Floyd Protests, Riots w/Reggie Watts
 - [https://www.youtube.com/watch?v=aeqUs3yruo4](https://www.youtube.com/watch?v=aeqUs3yruo4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-02 00:00:00+00:00

Taken from JRE #1484 w/Reggie Watts:
https://youtu.be/Mcle87Uvh8Y

## Joe Talks 2nd Amendment Rights and Gun Safety with Reggie Watts
 - [https://www.youtube.com/watch?v=cFuHeqUx7tg](https://www.youtube.com/watch?v=cFuHeqUx7tg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-02 00:00:00+00:00

Taken from JRE #1484 w/Reggie Watts:
https://youtu.be/Mcle87Uvh8Y

## Joe Talks Monkeys Stealing Coronavirus Viles, Other Monkey Related Topics
 - [https://www.youtube.com/watch?v=KF-9VXnigx4](https://www.youtube.com/watch?v=KF-9VXnigx4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-02 00:00:00+00:00

Taken from JRE #1484 w/Reggie Watts:
https://youtu.be/Mcle87Uvh8Y

## Reggie Watts Has Some Major Problems with Facebook
 - [https://www.youtube.com/watch?v=78gtolQGluM](https://www.youtube.com/watch?v=78gtolQGluM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-02 00:00:00+00:00

Taken from JRE #1484 w/Reggie Watts: https://youtu.be/Mcle87Uvh8Y

