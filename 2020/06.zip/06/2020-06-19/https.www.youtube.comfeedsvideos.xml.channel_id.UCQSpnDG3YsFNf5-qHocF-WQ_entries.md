# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## 9 Totally Unnecessary, Overkill Gadgets & Tools
 - [https://www.youtube.com/watch?v=mNV2sUUkVBE](https://www.youtube.com/watch?v=mNV2sUUkVBE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2020-06-20 00:00:00+00:00

My top purchases that were totally uncalled for!
▼ Links (Affiliate) ▼
• Bosch D-Tect 150: https://geni.us/t8vHYI
• Welch Allyn SureTemp 960: https://geni.us/1t7XjZh
• Lifeloc FC10 Plus: https://www.breathalyzer.net/products/lifeloc-fc10-plus-breath-alcohol-tester
• Capnostream 35: https://www.medtronic.com/covidien/en-us/products/capnography/capnostream-35-portable-respiratory-monitor.html
• Acebeam X80-GT: https://geni.us/OBgRKQq
• Sper Scientific Sound Meter: https://geni.us/n2PG
• Microscope w/ Phase Contrast: https://geni.us/AzTPp4i
• Jamar Dynamometer: https://geni.us/BbOdZPW
• AXIS Gear: https://geni.us/NQEzb

Note: The links above are Amazon affiliate links, which means I'll probably get a small (usually ~1-2%) commission that helps support the channel if you decide to buy the item. The commission does not come out of your pocket, but rather from Amazon's.


⇒ Become a channel member for exclusive features! Check it out here: https://www.youtube.com/ThioJoe/join

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe

⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV

My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

#Gadgets #Tools #Tech #ThioJoe

