# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Writing BELIEVABLE Fantasy Fights!
 - [https://www.youtube.com/watch?v=dE_rAMV9umU](https://www.youtube.com/watch?v=dE_rAMV9umU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-06-20 00:00:00+00:00

Combat in fantasy is not as easy as slamming two character into eachother and saying your hero won. Let's talk about writing believeble action in fantasy. 
Hello Future Me Video: https://www.youtube.com/watch?v=jKkKNKUK_GE&t=1239s

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## MASSIVE Cosmere News⛈️ Wheel of Time To Resume Filming🎬 Cyberpunk 2077 Delayed AGAIN - FANTASY NEWS
 - [https://www.youtube.com/watch?v=6SaxeiBphco](https://www.youtube.com/watch?v=6SaxeiBphco)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-06-19 00:00:00+00:00

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

NEWS: 

#Cyberpunk2077 Delay: https://twitter.com/CyberpunkGame/status/1273647385294626816/photo/1

The Halloween Tree: https://deadline.com/2020/06/warner-bros-ray-bradbury-the-halloween-tree-will-dunn-adapting-1202962588/

Star Trek animated show: https://ew.com/tv/star-trek-lower-decks-next-generation/?utm_campaign=entertainmentweekly_entertainmentweekly&utm_content=new&utm_medium=social&utm_source=twitter.com&utm_term=5eeb89a4b353e80001153178

First Look Zach #SnyderCut: https://twitter.com/UberKryptonian/status/1273643095289204736

Sleeping Beauties: https://ew.com/books/sleeping-beauties-comic-preview-stephen-king-owen-king/?utm_campaign=entertainmentweekly_entertainmentweekly&utm_content=new&utm_medium=social&utm_source=twitter.com&utm_term=5eeb7decb353e8000115313a

Cursed Trailer: https://www.youtube.com/watch?v=6XelS6fQbuo

Superhero scripted podcasts: https://variety.com/2020/digital/news/spotify-warner-bros-dc-superheroes-podcasts-1234641401/

Doom Patrol season 2: https://www.youtube.com/watch?v=I6Fl_Kz-jw8

4k Star Wars showing: https://variety.com/2020/film/global/disney-to-release-4k-version-of-star-wars-the-empire-strikes-back-to-boost-u-k-cinemas-exclusive-1234637839/

Dark One Interview: https://www.comicsbeat.com/interview-creators-dark-one-brandon-sandersons/

Fractalverse: https://twitter.com/paolini/status/1273346533677768704

Avengers Game: https://twitter.com/culturecrave/status/1272970394949976064?s=12

Wheel Of Time Resumes Filming: https://www.praguereporter.com/home/2020/6/16/the-wheel-of-time-carnival-row-to-resume-prague-shoots-in-late-julyearly-august

Way Of Kings Kickstarter: https://www.kickstarter.com/projects/dragonsteel/the-way-of-kings-10th-anniversary-leatherbound-edition


fantasy news,cyberpunk 2077,daniel greene,fractalverse,wheel of time,dc comics,star trek,fantasy books, stormlight archive, mistborn, way of kings, Brandon Sanderson,

