# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Confronting Multi Millionaire Evan Luthra LIVE
 - [https://www.youtube.com/watch?v=rOcKNuCzfWg](https://www.youtube.com/watch?v=rOcKNuCzfWg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-06-19 00:00:00+00:00

finding the TRUTH about Evan Luthra and separating out what is fiction.

