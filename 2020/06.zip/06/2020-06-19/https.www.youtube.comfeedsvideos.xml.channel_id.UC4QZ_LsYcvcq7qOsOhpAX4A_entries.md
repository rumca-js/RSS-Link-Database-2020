# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## Apple’s Next Big Thing: AR Glasses
 - [https://www.youtube.com/watch?v=ilzOWzH-wHo](https://www.youtube.com/watch?v=ilzOWzH-wHo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2020-06-20 00:00:00+00:00

What comes after the iPhone?

AR/VR video: https://www.youtube.com/watch?v=f9MwaH6oGEY

--- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. 

If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- New Thinking Book written by Dagogo Altraide ---
This book was rated the 9th best technology history book by book authority.
In the book you’ll learn the stories of those who invented the things we use everyday and how it all fits together to form our modern world.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

--- ColdFusion Social Media ---
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusionTV

Sources:

http://web.archive.org/web/19980123213614/http://www.research.apple.com/technology/reports/TR125/TR125.html

https://www.macrumors.com/2016/01/29/apple-virtual-reality-headset/

https://www.cnet.com/news/we-could-see-the-apple-ar-headset-next-year-analyst-ming-chi-kuo-says/

https://www.cnet.com/news/apple-glasses-leaks-and-rumors-heres-everything-we-expect-to-see-next-big-product/


https://www.lightreading.com/services/apple-nabs-nextvr-as-details-about-ar-glasses-leak-out-/a/d-id/759772

https://appleinsider.com/articles/20/05/19/apple-glass-details-leaked-will-cost-499-and-work-with-prescriptions

https://www.techradar.com/sg/news/apple-glasses

https://www.macrumors.com/roundup/apple-glasses/

https://www.macrumors.com/2002/03/24/apple-stereoscopic-displays-and-wearable-computers/

https://www.businessinsider.com/apple-glasses-release-2022-iphone-replacement-2020-5?r=AU&IR=T
https://appleinsider.com/inside/apple-glass

https://www.tomsguide.com/news/apple-glass-patent-reveals-killer-feature-for-mass-appeal


//Soundtrack//

4:04 Carbon Based Lifeforms - Betula Pendula 
Check out their music here http://carbonbasedlifeforms.net

» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide

Why are you still reading?

