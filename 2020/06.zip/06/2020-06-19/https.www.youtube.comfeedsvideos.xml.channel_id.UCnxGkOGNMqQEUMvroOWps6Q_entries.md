# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## African Dust Storms, The Mayan Calendar, and Doomsday Predictions w/Kyle Dunnigan
 - [https://www.youtube.com/watch?v=vme-PNEi3lM](https://www.youtube.com/watch?v=vme-PNEi3lM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-19 00:00:00+00:00

Taken from JRE #1494 w/Kyle Dunnigan:
https://youtu.be/U_yasKdeo8c

## Kyle Dunnigan Was Surprised by Bill Maher's Reaction to His Impression
 - [https://www.youtube.com/watch?v=rH2Z07he8Y8](https://www.youtube.com/watch?v=rH2Z07he8Y8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-19 00:00:00+00:00

Taken from JRE #1495 w/Kyle Dunnigan: https://youtu.be/U_yasKdeo8c

