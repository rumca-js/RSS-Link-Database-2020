# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## Virgin Social Media vs. Chad RSS (UNCENSORED!)
 - [https://www.youtube.com/watch?v=hMH9w6pyzvU](https://www.youtube.com/watch?v=hMH9w6pyzvU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-06-20 00:00:00+00:00

RSS feeds are the proper way to consoom product online. Don't get locked into social media, you can always have the best of both worlds.

For how to get RSS feeds from social media sites: https://lukesmith.xyz/blog#a-guide-to-using-rss-to-replace-social-media

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE: https://lukesmith.xyz/donate 💰😎👌💯
OR affiliate links to things l use:
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://brave.com/luk005 Get the Brave browser.
https://lbry.tv/$/invite/@Luke View my videos on LBRY.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase.

## Set Up a Basic Website! nginx, Certbot & secure login
 - [https://www.youtube.com/watch?v=OWAqilIVNgE](https://www.youtube.com/watch?v=OWAqilIVNgE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-06-19 00:00:00+00:00

Pls don't hack me even though I gave you my root password!

https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://www.vultr.com/?ref=8384069-6G Get a VPS with Vultr and host a website or server for anything else.

In a series of based slightly-off ffmpeg video cuts, I set up a website with all the essentials! After getting a domain, I set up a VPS and direct my domain to it. I then set a secure way to log into with with an ssh key pair. We then install nginx (Engine-X) and set up a super basic web page, and lastly added HTTPS/SSL using Certbot (setting this to try to auto-update every month with a cronjob).

You can easily add more sites to nginx which read different filesystem locations and expect different domains or subdomains.

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE: https://lukesmith.xyz/donate 💰😎👌💯
OR affiliate links to things l use:
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://brave.com/luk005 Get the Brave browser.
https://lbry.tv/$/invite/@Luke View my videos on LBRY.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase.

