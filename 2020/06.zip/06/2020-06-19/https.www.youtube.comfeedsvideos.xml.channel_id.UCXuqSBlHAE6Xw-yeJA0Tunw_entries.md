# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Why is EVERYONE Buying this TV?? - TCL 65S425
 - [https://www.youtube.com/watch?v=5yuqcfp1xxI](https://www.youtube.com/watch?v=5yuqcfp1xxI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-06-20 00:00:00+00:00

Get $50 when you open a TradeStation brokerage account using offer code LTTSAFRP at https://www.tradestation.com/promo/ltt/

Get 10% off your order with offer code FUNLINUS10 on Ruggable at https://myruggable.com/LTT15

Why are TVs getting bigger and bigger? In this episode we discuss TV fab generations and the TCL 65S425, on of the best selling – and best value – 65” 4K smart TVs on Amazon.com.

Buy TCL 4K 65" Smart LED TV
On Amazon (PAID LINK): https://geni.us/jvBf
On Newegg (PAID LINK): https://geni.us/Q0aE4
On B&H (PAID LINK): https://geni.us/FQjGvN

Buy LG CX 48-Inch Class 4K OLED TV
On Best Buy (PAID LINK): https://shop-links.co/1722170505452195133
On Amazon (PAID LINK): https://geni.us/BxUq0T3  

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1212076-why-is-everyone-buying-this-tv/

GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Mech Keyboard: https://geni.us/RecNBTI
NEEDforSEAT Gaming Chairs: https://geni.us/needforseat
Get a Displate Metal Print at https://lmg.gg/displateltt
Use code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Gear on Amazon: https://geni.us/lmgamazon
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0 https://lmg.gg/fxHYK 
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://lmg.gg/Q9yyQ 
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://lmg.gg/8upii

## New Graphics Cards to Rain on PS5 Parade - WAN Show June 19, 2020
 - [https://www.youtube.com/watch?v=u5DFBiy1V_I](https://www.youtube.com/watch?v=u5DFBiy1V_I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-06-19 00:00:00+00:00

** Some weird freezing at times. Not sure what happened, but hopefully will have it sorted out for next stream **

Honey automatically applies the best coupon codes to save you money at 
different online checkouts, try it now at https://www.joinhoney.com/linus

Remotely monitor and manage your server or PC at https://lmg.gg/pulsewayteams and get 20% off Pulseway's Teams plan when you sign up.

Save 15% today with offer code WAN on Displate at https://lmg.gg/displatewan

Buy an LTT shirt, hoodie, hat, and even our own water bottle at https://lmg.gg/wanlttstore

Check out Carpool Critics, our new movie podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Podcast Download: TBD

Timestamps: (Courtesy of Aryan Singh)

1:44 Intro
2:46 Nvidia Is going to change ti
18:28 Battlefield V on Intel Xe Gpu         
23:42 Raspberry Pi 4 with Pci    
28:04  Amd Ryzen
32:44 Problem Fixed 
 37:48Amd 5700Xt Compatible with any mother bard 
38:42 Sponsors 
41:42 LTT Store Promotion 
43:22 Boston Dynamics New Robot 
51:25 Superchat 
58:32 Intel makes  Gen2 Optane
 58:16 Tournament of LTT 
57:58 Superchats   
1:07:16 3d Sen released
1:10:12 Superchats
1:14:24 About Cameo

