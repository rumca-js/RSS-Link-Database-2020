# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Rock the Garden - six highlights from years past
 - [https://www.youtube.com/watch?v=4KLPTQib28w](https://www.youtube.com/watch?v=4KLPTQib28w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-06-20 00:00:00+00:00

The year 2020 won’t see a Rock the Garden, but we're still commemorating the festival on air and online. Here's a highlight reel of some amazing past performances that will stir many music memories.

SONGS PERFORMED
00:00 Sharon Jones and the Dap-Kings, "I Learned the Hard Way" (2010)
07:13 Metric, "Youth Without Youth" (2013)
11:32 Flaming Lips, "Race For The Prize" (2016)
17:02 Booker T and the MGs, "Green Onions" (2011)
22:34 Courtney Barnett, "Pedestrian at Best" (2015)

CREDITS
Video & Photo: Nate Ryan; Dan Huiting; Bo Hakala; Eric Schleicher; Chris Hadland; MN Original / TPT
Audio: Michael DeMark, Corey Schreppel, Rob Byers, Cameron Wiley, Johnny Vince Evans, Zach Rose
Production: Derrick Stevens

FIND MORE:
2010 Rock the Garden: https://www.thecurrent.org/feature/2010/06/19/rock-the-garden-2010
2014 Rock the Garden: https://www.thecurrent.org/feature/2014/04/15/rock-the-garden
2013 Rock the Garden:
https://www.thecurrent.org/feature/2013/04/16/rock-the-garden
2016 Rock the Garden:
https://www.thecurrent.org/feature/2016/01/07/rock-the-garden-save-the-date
2011 Rock the Garden:
https://www.thecurrent.org/feature/2010/06/18/rock-the-garden-2011
2015 Rock the Garden:
https://www.thecurrent.org/feature/2015/01/21/rock-the-garden-save-the-date


Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## GRRRL PRTY - two songs at Rock The Garden 2016
 - [https://www.youtube.com/watch?v=lh5sOeq5-9Q](https://www.youtube.com/watch?v=lh5sOeq5-9Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-06-19 00:00:00+00:00

GRRRL PRTY — consisting of Lizzo, Sophia Eris, Manchita and DJ Shannon Blowtorch — played their final show together at Rock the Garden 2016, and they poured everything into that last performance. Watch these two songs from that unforgettable set. 

SONGS PERFORMED
00:00 "Bugg'n"
03:19 "Wegula"

PERSONNEL
Lizzo
Sophia Eris
Manchita
DJ Shannon Blowtorch

CREDITS
Video & Photo: Nate Ryan
Audio: Michael DeMark

FIND MORE:
2014 studio session: https://www.thecurrent.org/feature/2014/03/09/grrrl-prty-live
2015 First Avenue Mainroom show review: https://blog.thecurrent.org/2015/08/first-avenue-reopens-mainroom-for-joyous-grrrl-prty-show/
2016 GRRRL PRTY to say goodbye at Rock The Garden: https://blog.thecurrent.org/2016/06/grrrl-prty-to-say-goodbye-at-rock-the-garden/

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

