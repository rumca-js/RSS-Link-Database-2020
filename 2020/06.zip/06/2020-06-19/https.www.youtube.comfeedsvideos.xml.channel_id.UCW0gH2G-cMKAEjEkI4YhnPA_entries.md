# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Queens of the Valar | Tolkien Explained
 - [https://www.youtube.com/watch?v=0sCpIbIXP6U](https://www.youtube.com/watch?v=0sCpIbIXP6U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2020-06-20 00:00:00+00:00

The Queens of the Valar - today we cover what they are known for and the things they did to help shape the Middle-earth we know and love in The Lord of the Rings.  The Queens of the Valar include:

Varda Elentári, Queen of the Stars, wife of Manwë
Yavanna Kementári, Giver of Fruits, wife of Aulë
Nienna, Lady of Mercy
Estë the Gentle, wife of Irmo
Vairë the Weaver, wife of Mandos
Vána the Ever-young, wife of Oromë
Nessa the Dancer, wife of Tulkas

Hit subscribe - and the bell - so you never miss a video from Nerd of the Rings! 

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner. 

Nienna - Aerankai
Earendil - alystraea
Elbereth - Sedeptra
Nessa - Elena Kukanova
The Ever Young - Elena Kukanova
Este - Dolldivine Azaleasdolls
Feanor and the Silmarils - Bellabergolts
Gandalf and the Balrog - Gonzalo Kenny
Gandalf - John Howe
Nienna - Haru Herlambang
Yavanna' Trees - Jacek Kopalski
Varda of the Stars - Kip Rasmussen
Vaire - Melanie Huillier
Under the Stars - Liga Klavina
Nienna The Lady of Mercy - jankalateckova
Nienna - Edarlein
Nienna - SaMoart
Powers of Arda - skinnyuann
Este the Gentle - Šárka Škorpíková
Vana the Ever-young - Steamey
Varda and Manwe in Valinor - Ted Nasmith
Ilmarin - Ted Nasmith
Vana the ever young - jankal ateckova
Varda Elentari - Kimberly80
Varda Elentari - lelia
Varda - gustavomalek
Yavanna - gustavomalek
Yavanna - jankalateckova
Song of the Ainur - John Pitre
Melkor and Ungoliant before the two trees - John Howe
Ungoliant - Ted Nasmith
Taniquetil - Ted Nasmith
Radagast - Aleksander Karcz
Aule and the seven fathers - Ted Nasmith
Valar - Felix Donadio
Manwe Sulimo - gustavomalek
Aule the destroyer - Ted Nasmith
Ulmo - John Howe

#valar #tolkien #silmarillion

