## Metallica - Nothing Else Matters - Medieval Style - Bardcore
 - [https://www.youtube.com/watch?v=wCUx9nOt9u8](https://www.youtube.com/watch?v=wCUx9nOt9u8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCrwIwCT7vXtJIm3nZiwD7cQ
 - date published: 2020-06-19 00:00:00+00:00

Song composed by James Hetfield & Lars Ulrich
Spotify: https://open.spotify.com/artist/6AU6DQHPVlHvPh175WIXHa
iTunes: https://music.apple.com/us/artist/algal/1529528125
Google Play: https://play.google.com/store/music/artist?id=A27ex3kykbb65ri4gcb5wja5qom
Facebook: http://www.facebook.com/alvarogalanmusic
Twitter: http://twitter.com/Alvariu
Instagram: https://www.instagram.com/alvariu360
Instruments: Lute-guitar, Irish bouzouki, Low whistle (D), Drums.

