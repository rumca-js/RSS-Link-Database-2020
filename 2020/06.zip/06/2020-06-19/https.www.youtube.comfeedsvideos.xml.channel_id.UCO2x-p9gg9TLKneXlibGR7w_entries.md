# Source:Snazzy Labs, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w, language:en-US

## The First iPhone vs The First Android!
 - [https://www.youtube.com/watch?v=gdevNBJZYgI](https://www.youtube.com/watch?v=gdevNBJZYgI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w
 - date published: 2020-06-20 00:00:00+00:00

Both iOS and the Android operating system are used by billions of people every day. But back at the beginning, which was best? iPhone vs Android.

This is Tech Today's Google Sooner video - https://www.youtube.com/watch?v=NMdT8S9WoHI
Subscribe to my podcast Flashback! - http://relay.fm/flashback
Follow me on Twitter - http://twitter.com/snazzyq
Follow me on Instagram - http://instagram.com/snazzyq

The original iPhone released in 2007 was hailed as revolutionary in a world where BlackBerry, Palm, and Microsoft Windows Phone reigned king. Google was working on a competitor to these platforms with the Android team they purchased in 2005. After the iPhone unveiling, Google changed course and the T-Mobile HTC Dream was launched in 2008. How did the two compare and which one was better? iPhone vs Android.

