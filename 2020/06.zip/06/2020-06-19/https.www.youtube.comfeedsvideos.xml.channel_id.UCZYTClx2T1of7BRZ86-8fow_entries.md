# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## Nurseryfish Dads Give Their Young a Headstart… Literally
 - [https://www.youtube.com/watch?v=SCm3aDq_sfA](https://www.youtube.com/watch?v=SCm3aDq_sfA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2020-06-20 00:00:00+00:00

Happy Father's day! Today we're talking about the fintastic Nurseryfish, which is one of the best dads you can fish for.

Thanks to Dr. Tim Berra for teaching us more about these amazing fish as well as providing such awesome pictures!

Hosted by: Hank Green

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Kevin Bealer, Jacob, Katie Marie Magnone, D.A. Noe, Charles Southerland, Eric Jensen, Christopher R Boucher, Alex Hackman, Matt Curls, Adam Brainard, Jeffrey McKishen, Scott Satovsky Jr, James Knight, Sam Buck, Chris Peters, Kevin Carpentier, Patrick D. Ashmore, Piya Shedden, Sam Lutfi, Charles George, Christoph Schwanke, Greg
----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:

https://doi.org/10.1023/A:1020523905635 
https://mansfield.osu.edu/assets/mansfield/tberra/pdf/observationegg.pdf 

https://doi.org/10.1643/CI-15-365 
https://doi.org/10.1093/icb/25.3.807 
https://doi.org/10.1111/evo.13846
https://doi.org/10.1071/ZO16041 
https://pfeil-verlag.de/wp-content/uploads/2015/05/ief14_4_02.pdf
https://doi.org/10.1111/j.0022-1112.2004.00454.x
https://doi.org/10.1071/ZO07033
https://doi.org/10.1643/0045-8511(2003)003[0384:ELHOTN]2.0.CO;2

## Finally, a Drug That Helps With the Worst COVID-19 Infections
 - [https://www.youtube.com/watch?v=tU9V0Wbly78](https://www.youtube.com/watch?v=tU9V0Wbly78)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2020-06-19 00:00:00+00:00

A bit of good news on the COVID-19 front this week: New research reveals a drug that might actually help save severely ill patients, and data suggests that distancing policies may have saved millions of lives over the last few months.

Hosted by: Hank Green

COVID-19 playlist: https://www.youtube.com/playlist?list=PLsNB4peY6C6IQediwz2GzMTNvm_dMzr47

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Kevin Bealer, Jacob, Katie Marie Magnone, D.A. Noe, Charles Southerland, Eric Jensen, Christopher R Boucher, Alex Hackman, Matt Curls, Adam Brainard, Jeffrey McKishen, Scott Satovsky Jr, James Knight, Sam Buck, Chris Peters, Kevin Carpentier, Patrick D. Ashmore, Piya Shedden, Sam Lutfi, Charles George, Christoph Schwanke, Greg
----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
Dexamethasone
https://www.recoverytrial.net/files/recovery_dexamethasone_statement_160620_v2final.pdf
https://apnews.com/89d963958b042cc921e64ab3eff5a74d 
https://doi.org/10.1038/s41577-020-0331-4
https://doi.org/10.3389/fpubh.2020.00189
Non-pharmaceutical interventions
https://doi.org/10.1038/s41586-020-2405-7
https://doi.org/10.1038/s41586-020-2404-8

Image Sources:
https://commons.wikimedia.org/wiki/File:Dexamethasone_structure.svg
https://commons.wikimedia.org/wiki/File:Cortisol2.svg

