# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## The Last Of Us Part II Spoiler Review
 - [https://www.youtube.com/watch?v=houfCEZrFss](https://www.youtube.com/watch?v=houfCEZrFss)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-20 00:00:00+00:00

Here are our more detailed thoughts about The Last of Us Part II.

## Apex Legends Director On Switch Port, Crossplay, And Stance On Skill Based Matchmaking
 - [https://www.youtube.com/watch?v=Kn4cBmafBf0](https://www.youtube.com/watch?v=Kn4cBmafBf0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-19 00:00:00+00:00

Michael Higham sits down with Respawn's Chad Grenier goes in-depth on EA Play announcements explaining Respawn's creative process and endeavours in updating Apex Legends.

## DIRT 5 - EXCLUSIVE Career Mode Gameplay
 - [https://www.youtube.com/watch?v=XnmqWDMwN_Y](https://www.youtube.com/watch?v=XnmqWDMwN_Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-19 00:00:00+00:00

In this exclusive gameplay video, lead designer Michael Moreton takes a spin around one of the Norway circuits and talks about DIRT 5’s Career mode. DIRT 5 is Codemasters’ first title to be confirmed on Xbox Series X and PlayStation 5

## EA Play 2020 Next Gen Games Teaser
 - [https://www.youtube.com/watch?v=jMQ4n2922qI](https://www.youtube.com/watch?v=jMQ4n2922qI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-19 00:00:00+00:00

BioWare, EA Motive, and DICE are working on some big games for the PS5 and Xbox Series X.

## FIFA 21 & Madden 21 - Official PS5 and Xbox Series X Trailer
 - [https://www.youtube.com/watch?v=nm9FGNB4Q3k](https://www.youtube.com/watch?v=nm9FGNB4Q3k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-19 00:00:00+00:00

Feel Next Level in FIFA 21 and Madden NFL 21 on PlayStation®5 and Xbox Series X with new technology that takes football from visual to visceral. Learn more: http://x.ea.com/63539 
#FIFA21 #Madden21 #FeelNextLevel

## FULL EA Play Live 2020 Reveal Event
 - [https://www.youtube.com/watch?v=An56fxfN8pI](https://www.youtube.com/watch?v=An56fxfN8pI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-19 00:00:00+00:00

Check out the full EA Play Live 2020 reveal event featuring Apex Legends, Star Wars Squadrons, Sims, FIFA, Madden 21, and more!




#eaplay
#eaplaylive

## Fire Emblem: Three Houses And Deer Abbey With Joe Zieja (Claude)
 - [https://www.youtube.com/watch?v=cx39SVwb8O8](https://www.youtube.com/watch?v=cx39SVwb8O8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-19 00:00:00+00:00

BLACK LIVES MATTER: http://bit.ly/gs-blm
COVID-19 Direct Relief: http://bit.ly/gs-covid

On today's Play For All charity stream, we're joined by Joe Zieja, the voice of Claude from Fire Emblem: Three Houses, to play the game with us, as well as give out advice as Deer Abbey.

## More Details On Star Wars: Squadrons From Creative Director
 - [https://www.youtube.com/watch?v=0Mc4G0AL_6I](https://www.youtube.com/watch?v=0Mc4G0AL_6I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-19 00:00:00+00:00

Star Wars: Squadrons brings back the classic dogfighting gameplay seen in classics like the X-Wing and TIE Fighter series. In an interview with GameSpot, EA Motive's Ian Frazier talks about the series' roots, how the studio balanced New Republic and Imperial craft, and how team composition can make or break your victory.

The comparisons to the classic Lucasarts series are readily apparent, especially as you're locked to cockpit view and can shift your ship's priorities between weapons, engines, and shields. But that's not the only way Motive drew inspiration. Frazier opened up about how the studio looked back at the strategies from those older games to help the nimble but fragile TIE Fighter feel like a match for the hearty and more full-featured X-Wing.

Whichever side of the conflict you fall on, team composition will make a huge difference. Frazier also detailed how load-outs will be important not just for your own starfighter, but also for coordinating with your teammates. And to avoid what he calls the "death loop" of two pilots simply chasing each other down, Motive has put in a few advanced maneuverability strategies for ace pilots to outgun the competition.

## Pokemon Isle Of Armor DLC First Impressions And Favorite PS5 Reveals - GameSpot After Dark #46
 - [https://www.youtube.com/watch?v=gTZ2KV28law](https://www.youtube.com/watch?v=gTZ2KV28law)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-19 00:00:00+00:00

This week on GameSpot After Dark, Kallie talks about the Pokemon Isle of Armor DLC, Jake is playing Persona 4 Golden on PC, Jean-Luc tried the Ultrakill and System Shock demos, and Lucy revisits Horizon Zero Dawn. We also discuss the New Pokemon Snap announcement, our favorite reveals from the PS5 event, and the nickname for the Eurostar Channel Tunnel.

TIMESTAMPS:
0:00 - Intro
4:30 - Horizon Zero Dawn (What We've Been Playing)
10:30 - Ultrakill (What We've Been Playing)
16:31 - System Shock Alpha Demo (What We've Been Playing)
20:42 - Losing Save Progress In Games
28:45 - Persona 4 Golden On PC (What We've Been Playing)
32:14 - Pokemon Isle Of Armor (What We've Been Playing)
40:20 - Our Favorite News From The PS5 Reveal
52:19 - New Pokemon Snap Announcement
1:00:16 - Secret Chunnel
1:03:33 - Listener Questions
1:19:31 - Outro

## Star Wars Squadrons - Official Gameplay Reveal
 - [https://www.youtube.com/watch?v=eIonDr2OVZs](https://www.youtube.com/watch?v=eIonDr2OVZs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-19 00:00:00+00:00

Take a look at the first gameplay for Star Wars Squadrons as well as some of the modes you and your squad will be able to play.

