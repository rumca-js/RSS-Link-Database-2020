# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Acosta to McEnany: Doesn't sharing fake videos make you fake news?
 - [https://www.cnn.com/videos/politics/2020/06/19/mcenany-fake-news-trump-tweet-coronavirus-mask-tulsa-rally-acosta-tsr-pkg-vpx.cnn](https://www.cnn.com/videos/politics/2020/06/19/mcenany-fake-news-trump-tweet-coronavirus-mask-tulsa-rally-acosta-tsr-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 23:51:00+00:00

CNN's Jim Acosta presses White House Press Secretary Kayleigh McEnany about a video posted by President Donald Trump on Twitter, which the social media site has since labeled "manipulated media."

## Pence refuses to say 'Black lives matter'
 - [https://www.cnn.com/2020/06/19/politics/mike-pence-black-lives-matter-all-lives-matter/index.html](https://www.cnn.com/2020/06/19/politics/mike-pence-black-lives-matter-all-lives-matter/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 23:37:07+00:00

Vice President Mike Pence declined to say the words "Black lives matter" during an interview with an ABC affiliate in Pennsylvania on Friday, instead saying that "all lives matter."

## Van Jones revisits three Trump voters as nation grapples with unrest
 - [https://www.cnn.com/2020/06/19/politics/van-jones-trump-voters/index.html](https://www.cnn.com/2020/06/19/politics/van-jones-trump-voters/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 22:49:35+00:00

In the wake of Donald Trump's surprise election win in 2016, CNN's Van Jones went on a journey of discovery across America to understand why voters sent Trump to Washington.

## Brazil tops 1 million Covid-19 cases. It may pass the US next, becoming the worst-hit country on the planet
 - [https://www.cnn.com/2020/06/19/americas/brazil-one-million-coronavirus-jair-bolsonaro-cases-intl/index.html](https://www.cnn.com/2020/06/19/americas/brazil-one-million-coronavirus-jair-bolsonaro-cases-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 22:24:49+00:00

Brazil has now reported more than 1 million confirmed cases of coronavirus and 48,954 deaths, marking a grim milestone for the South American country.

## Twitter permanently suspends account of Katie Hopkins
 - [https://www.cnn.com/2020/06/19/business/twitter-suspends-katie-hopkins/index.html](https://www.cnn.com/2020/06/19/business/twitter-suspends-katie-hopkins/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 22:07:20+00:00

Twitter has permanently suspended the account of extreme right-wing British columnist Katie Hopkins for violating its hateful conduct policy.

## US Navy will fire USS Theodore Roosevelt captain who warned about Covid-19 on his ship
 - [https://www.cnn.com/2020/06/19/politics/uss-roosevelt-investigation/index.html](https://www.cnn.com/2020/06/19/politics/uss-roosevelt-investigation/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 21:15:12+00:00



## 'Healthy' teenager who took precautions died suddenly of Covid-19
 - [https://www.cnn.com/2020/06/19/health/teen-death-coronavirus-wellness-partner/index.html](https://www.cnn.com/2020/06/19/health/teen-death-coronavirus-wellness-partner/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 19:33:39+00:00

It started as a normal day. Dawn Guest, 54, got up and headed out to her job as a nurse around 5 a.m. She heard her 16-year-old son, Andre, stirring in his room, but he had always been an earlier riser, even when his school was shut for Covid-19. Later that day she would get a call from her husband, telling her there was something wrong with their son.

## Apple is closing some of the stores it reopened because of a spike in coronavirus cases
 - [https://www.cnn.com/2020/06/19/tech/apple-stores-closing-coronavirus/index.html](https://www.cnn.com/2020/06/19/tech/apple-stores-closing-coronavirus/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 19:30:29+00:00

Apple reopened dozens of stores across the United States last month, after shutting them because of the coronavirus. Now, it is closing some of them again.

## Ian Holm, 'Lord of the Rings' star, dead at 88
 - [https://www.cnn.com/2020/06/19/entertainment/ian-holm-death-scli-intl-gbr/index.html](https://www.cnn.com/2020/06/19/entertainment/ian-holm-death-scli-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 18:10:32+00:00

British actor Ian Holm has died at the age of 88, according to a statement from his agent.

## This is what turbo-charged the development of human brains, researchers say
 - [https://www.cnn.com/2020/06/19/world/landscape-clutter-brain-evolution-scn/index.html](https://www.cnn.com/2020/06/19/world/landscape-clutter-brain-evolution-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 16:56:17+00:00

The ways our ancestors adapted to live in patchy landscapes cluttered with obstacles "poured jet fuel" on the evolution of the brains of animals and early human ancestors, according to researchers at Northwestern University.

## Tech CEO quits after $2 billion goes missing and fraud accusations fly
 - [https://www.cnn.com/2020/06/19/tech/wirecard-fraud-tech-accounting/index.html](https://www.cnn.com/2020/06/19/tech/wirecard-fraud-tech-accounting/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 16:36:25+00:00

More than $2 billion has gone missing at one of Europe's most vaunted tech companies. If it's not found quickly, the digital payments firm may never recover.

## Jamie Foxx shows off bulked-up physique as he prepares for Mike Tyson biopic
 - [https://www.cnn.com/2020/06/19/entertainment/jamie-foxx-confirms-role-as-tyson-scli-intl/index.html](https://www.cnn.com/2020/06/19/entertainment/jamie-foxx-confirms-role-as-tyson-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 15:52:09+00:00

Oscar-winning actor Jamie Foxx has confirmed that he will play Mike Tyson in an upcoming biopic about the life of the   American former heavyweight boxer.

## Matt Damon doesn't approve of Jimmy Kimmel's hiatus
 - [https://www.cnn.com/videos/media/2020/06/19/jimmy-kimmel-takes-break-from-show-orig-vstop-bdk.cnn](https://www.cnn.com/videos/media/2020/06/19/jimmy-kimmel-takes-break-from-show-orig-vstop-bdk.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 15:16:44+00:00

Jimmy Kimmel announced that he is taking a break from hosting "Jimmy Kimmel Live!" to spend more time with his family.

## Could this invisible air shield protect fliers from Covid-19?
 - [https://www.cnn.com/collections/intl-health-0619/](https://www.cnn.com/collections/intl-health-0619/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 14:02:32+00:00



## This entry-level Lamborghini offers more fun for a lot less money
 - [https://www.cnn.com/2020/06/19/success/lamborghini-huracan-evo-rwd/index.html](https://www.cnn.com/2020/06/19/success/lamborghini-huracan-evo-rwd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 12:40:26+00:00

Lamborghini's new Huracán Evo RWD is the Italian auto maker's least expensive supercar -- and it is also the most enjoyable one to drive.

## 'That could've been me,' two-time Olympic gold winner Christian Taylor reflects on George Floyd's death
 - [https://www.cnn.com/2020/06/19/sport/christian-taylor-george-floyd-christian-coleman-spt-intl/index.html](https://www.cnn.com/2020/06/19/sport/christian-taylor-george-floyd-christian-coleman-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 12:18:57+00:00

When two-time Olympic gold medal winner Christian Taylor watched the video of George Floyd's death, the first thought that went through his head was: "That could've been me."

## See what Venice is like as tourists return
 - [https://www.cnn.com/videos/travel/2020/06/19/venice-italy-coronavirus-covid-19-pandemic-reopening-tourism-business-wedeman-pkg-intl-ldn-vpx.cnn](https://www.cnn.com/videos/travel/2020/06/19/venice-italy-coronavirus-covid-19-pandemic-reopening-tourism-business-wedeman-pkg-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 11:32:46+00:00

Before coronavirus, Venice was overwhelmed by tourists - a boon for the city's economy but a sometimes inconvenient reality for residents. As the city reopens, some residents tell CNN's Ben Wedeman they hope a new balance can be struck.

## Colgate is still selling 'Black Person Toothpaste' in China. Now that's under review
 - [https://www.cnn.com/2020/06/19/business/colgate-darlie-toothpaste-intl-hnk/index.html](https://www.cnn.com/2020/06/19/business/colgate-darlie-toothpaste-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 10:49:52+00:00

Colgate has announced a review of its toothpaste brand Darlie, which once featured a smiling White man in blackface, as companies around the world reconsider their use of racist stereotypes following the killing of George Floyd.

## Malala Yousafzai finishes Oxford University, says now is time for 'Netflix, reading and sleep'
 - [https://www.cnn.com/2020/06/19/world/malala-completes-oxford-studies-scli-intl-gbr/index.html](https://www.cnn.com/2020/06/19/world/malala-completes-oxford-studies-scli-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 10:42:15+00:00

Malala Yousafzai, the Nobel Peace Prize-winning woman who survived being shot by the Taliban, has completed her degree at Oxford University.

## This drug may be the secret behind Portugal's low Covid-19 death rate
 - [https://www.cnn.com/videos/world/2020/06/19/portugal-coronavirus-covid-19-pandemic-steroids-treatment-pleitgen-pkg-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2020/06/19/portugal-coronavirus-covid-19-pandemic-steroids-treatment-pleitgen-pkg-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 09:46:22+00:00

Portugal has been one of the most successful European countries at beating back Covid-19, despite also being one of the poorest. CNN's Frederik Pleitgen reports on the small Iberian country's response to Covid-19.

## South Africa has the continent's highest Covid-19 cases. Now, it faces another pandemic.
 - [https://www.cnn.com/2020/06/19/africa/south-africa-gender-violence-pandemic-intl/index.html](https://www.cnn.com/2020/06/19/africa/south-africa-gender-violence-pandemic-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 09:43:18+00:00



## America has to face its problem with allyship
 - [https://www.cnn.com/collections/intl-juneteenth/](https://www.cnn.com/collections/intl-juneteenth/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 09:40:09+00:00



## The extreme hotel hygiene awaiting tourists in Spain
 - [https://www.cnn.com/travel/article/spain-covid-19-hotel-hygiene/index.html](https://www.cnn.com/travel/article/spain-covid-19-hotel-hygiene/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 09:29:07+00:00

It's breakfast time, which means I need to get my temperature checked, put on my face mask, smother my hands in alcohol disinfectant and wear a pair of plastic gloves.

## China is promising to write off some loans to Africa. It may just be a drop in the ocean
 - [https://www.cnn.com/2020/06/19/economy/china-xi-jinping-africa-intl-hnk/index.html](https://www.cnn.com/2020/06/19/economy/china-xi-jinping-africa-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 09:17:53+00:00

China has become one of Africa's largest creditors in recent years, lending hundreds of billions of dollars to governments to build roads, railways and ports. Now it's promising to write off a small part of that debt as countries on the continent battle the Covid-19 pandemic.

## Two Canadians held in China have officially been charged with spying
 - [https://www.cnn.com/2020/06/19/asia/china-canada-kovrig-spavor-spying-intl-hnk/index.html](https://www.cnn.com/2020/06/19/asia/china-canada-kovrig-spavor-spying-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 09:13:14+00:00

Michael Kovrig and Michael Spavor, two Canadians detained in China in December 2018, have been formally charged with spying by Chinese prosecutors, in a move that is likely to raise tensions between the two countries.

## What's been happening in China's Xinjiang, home to 11 million Uyghurs?
 - [https://www.cnn.com/2020/06/19/asia/xinjiang-explainer-intl-hnk-scli/index.html](https://www.cnn.com/2020/06/19/asia/xinjiang-explainer-intl-hnk-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 09:06:18+00:00

As US President Donald Trump signed a bill into law Wednesday that aims to punish Beijing for its repression of the Uyghur ethnic minority, he was accused by his former national security adviser of endorsing China's construction of internment camps in its western region of Xinjiang.

## Venezuela's Maduro tightens grip on power, helped by coronavirus lockdown
 - [https://www.cnn.com/2020/06/19/americas/venezuela-maduro-coronavirus-power-intl/index.html](https://www.cnn.com/2020/06/19/americas/venezuela-maduro-coronavirus-power-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 08:47:02+00:00

Venezuela's embattled ruler President Nicolas Maduro has made the most of the coronavirus lockdown to stamp his authority over the country's key political institutions, all in the matter of a week.

## Namibia's last wild horses face a perilous future
 - [https://www.cnn.com/travel/article/namibia-wild-horses-spc-intl/index.html](https://www.cnn.com/travel/article/namibia-wild-horses-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 08:15:37+00:00

After more than a century in the desert, the future of Namibia's wild horses rests on a handful of foals.

## Amy Klobuchar drops out of Biden VP contention and says he should choose a woman of color
 - [https://www.cnn.com/2020/06/18/politics/biden-vice-president-amy-klobuchar/index.html](https://www.cnn.com/2020/06/18/politics/biden-vice-president-amy-klobuchar/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 03:35:04+00:00

Sen. Amy Klobuchar on Thursday night removed herself from consideration to be Joe Biden's running mate, citing the ongoing national discussion about racial injustice and police brutality to suggest the former vice president should choose a woman of color.

## Beijing's new outbreak is a reminder to the world that coronavirus can return at anytime
 - [https://www.cnn.com/2020/06/18/asia/beijing-coronavirus-reminder-intl-hnk/index.html](https://www.cnn.com/2020/06/18/asia/beijing-coronavirus-reminder-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 03:24:38+00:00

Until last week, Beijing seemed to have all but moved on from the coronavirus pandemic.

## A sheriff's deputy saved a baby from choking during a Black Lives Matter protest
 - [https://www.cnn.com/us/live-news/black-lives-matter-protests-06-18-2020/index.html](https://www.cnn.com/us/live-news/black-lives-matter-protests-06-18-2020/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 03:16:39+00:00



## Pompeo calls Bolton 'a traitor' as Trump administration scrambles to halt book release
 - [https://www.cnn.com/2020/06/18/politics/bolton-book-pompeo-the-room-where-it-happened/index.html](https://www.cnn.com/2020/06/18/politics/bolton-book-pompeo-the-room-where-it-happened/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 03:05:09+00:00

Secretary of State Mike Pompeo on Thursday accused former national security adviser John Bolton of being a "traitor" in a forceful rebuke of Bolton's new book.

## New Zealand police officer shot dead in routine traffic stop
 - [https://www.cnn.com/2020/06/18/asia/new-zealand-police-death-intl-hnk/index.html](https://www.cnn.com/2020/06/18/asia/new-zealand-police-death-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 02:48:54+00:00

An unarmed police officer has been shot dead while carrying out a routine traffic stop in the New Zealand city of Auckland -- the first to be killed in the line of duty in the country since 2009.

## Australia says it is experiencing a 'sophisticated' state-based cyber attack
 - [https://www.cnn.com/2020/06/18/tech/australia-cyber-attack-intl-hnk/index.html](https://www.cnn.com/2020/06/18/tech/australia-cyber-attack-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 02:34:59+00:00

The Australian government is grappling with massive cyber attacks from what Prime Minister Scott Morrison has described as a "malicious" and "sophisticated" state-based actor.

## China responds to bombshells in Bolton's book
 - [https://www.cnn.com/videos/world/2020/06/18/china-reaction-to-bolton-book-allegations-vpx.cnn](https://www.cnn.com/videos/world/2020/06/18/china-reaction-to-bolton-book-allegations-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 02:12:30+00:00

A Chinese spokesman responded to explosive claims made in former national security adviser John Bolton's book that President Donald Trump asked China for help to get him reelected. CNN's Ivan Watson reports.

## The 37 most shocking lines from Trump's 'interview' with Sean Hannity
 - [https://www.cnn.com/2020/06/18/politics/sean-hannity-donald-trump-john-bolton/index.html](https://www.cnn.com/2020/06/18/politics/sean-hannity-donald-trump-john-bolton/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 01:54:43+00:00

Faced with faltering poll numbers and a huge furor caused by allegations made in John Bolton's soon-to-be-released memoir of his time in the White House, President Donald Trump retreated to the warm embrace of Fox News on Wednesday night.

## Same-sex couples in Singapore pose in front of traditional marriage portraits
 - [https://www.cnn.com/style/article/charmaine-poh-photography/index.html](https://www.cnn.com/style/article/charmaine-poh-photography/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 01:40:30+00:00

In the intimate seclusion of a studio space, two women sit, arms linked around one another. Illuminated by the pink glow of a projected photograph of a married couple on their wedding day, the two women wear black and white; one of them loosely holds a bouquet.

## Why are China and India fighting over an inhospitable strip of the Himalayas?
 - [https://www.cnn.com/2020/06/17/asia/india-china-aksai-chin-himalayas-intl-hnk/index.html](https://www.cnn.com/2020/06/17/asia/india-china-aksai-chin-himalayas-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 01:26:58+00:00

After over four decades of saber-rattling and minor scuffles, a border dispute between China and India has again turned fatal.

## Renegade priest occupies Russian convent
 - [https://www.cnn.com/2020/06/18/europe/russia-coronavirus-priest-convent-intl/index.html](https://www.cnn.com/2020/06/18/europe/russia-coronavirus-priest-convent-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 01:08:53+00:00

A renegade cleric is occupying a convent outside of Yekaterinburg in the Ural Mountains after falling out with the Russian Orthodox Church because of his coronavirus-denying sermons.

## Kim Jong Un's sister takes center stage amid chaos in the Koreas
 - [https://www.cnn.com/2020/06/18/asia/kim-yo-jong-rise-intl-hnk/index.html](https://www.cnn.com/2020/06/18/asia/kim-yo-jong-rise-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 00:41:04+00:00

On a crisp winter day two years ago, Kim Yo Jong took her first step to becoming the powerful politician her father thought she would be.

## $190 oil sounds crazy. But JPMorgan thinks it's possible, even after the pandemic
 - [https://www.cnn.com/2020/06/18/investing/oil-price-spike-jpmorgan/index.html](https://www.cnn.com/2020/06/18/investing/oil-price-spike-jpmorgan/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 00:33:42+00:00

In a little-noticed report, JPMorgan Chase warned in early March that the oil market could be on the cusp of a "supercycle" that sends Brent crude skyrocketing as high as $190 a barrel in 2025.

## 'Quite the charade': Schiff responds to Bolton's accusation
 - [https://www.cnn.com/videos/politics/2020/06/18/schiff-responds-to-bolton-new-book-impeachment-burnett-intv-sot-ebof-vpx.cnn](https://www.cnn.com/videos/politics/2020/06/18/schiff-responds-to-bolton-new-book-impeachment-burnett-intv-sot-ebof-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-19 00:11:14+00:00

During an interview with CNN's Erin Burnett, lead House impeachment manager Rep. Adam Schiff (D-CA) responds to former national security adviser John Bolton's accusation in his new book that Democrats committed "impeachment malpractice."

