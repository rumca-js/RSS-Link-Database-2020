# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## It's the End of the World as We Know It | Pomplamoose ft. dodie & Maddie Poppe
 - [https://www.youtube.com/watch?v=fbyO9H7LSkQ](https://www.youtube.com/watch?v=fbyO9H7LSkQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2020-06-19 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

A cover of R.E.M.'s "It's the End of the World as We Know It" by Pomplamoose.

DODIE
Spotify: https://open.spotify.com/artist/21TinSsF5ytwsfdyz5VSVS?si=LSZbNREwQLO5MRoQsW44CQ
YouTube: https://www.youtube.com/doddleoddle

MADDIE POPPE
Spotify: https://open.spotify.com/artist/2Wda8QEZK7twazWzqDvOdk?si=H6DPUpa1RTi9C4n7iWWzbA
YouTube: https://www.youtube.com/channel/UCHGFIGEHbHgor6t0lAhk7Wg

CREDITS

Lead Vocals: Nataly Dawn, dodie, & Maddie Poppe
Keys: Jack Conte
Guitar: Brian Green 
Bass: Nick Campbell
Drums: Jordan Rose
Mixing/Mastering: Yianni Anastos-Prastacos
Producer: Ben Rose
Video Editor: Dominic Mercurio

Recorded from our homes around the world!

