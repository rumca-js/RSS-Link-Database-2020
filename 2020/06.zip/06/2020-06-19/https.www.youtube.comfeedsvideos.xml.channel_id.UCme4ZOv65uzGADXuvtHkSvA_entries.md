# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## CNN [#186] Bóg mówi na ucho w ciemności
 - [https://www.youtube.com/watch?v=5l1wP2FiLz8](https://www.youtube.com/watch?v=5l1wP2FiLz8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-06-20 00:00:00+00:00

#cnn #kazaniedookienka @Langusta na palmie 
Kazanie XII Niedzielę zwykłą, Rok A

1. czytanie (Jr 20, 10-13)

Rzekł Jeremiasz: «Słyszałem oszczerstwo wielu: „Trwoga dokoła! Donieście, donieśmy na niego!” Wszyscy zaprzyjaźnieni ze mną wypatrują mojego upadku: „Może on da się zwieść, tak że go zwyciężymy i wywrzemy pomstę na nim!”

Ale Pan jest przy mnie jako potężny mocarz; dlatego moi prześladowcy ustaną i nie zwyciężą. Będą bardzo zawstydzeni swoją porażką, okryci wieczną i niezapomnianą hańbą. Panie Zastępów, Ty, który doświadczasz sprawiedliwego i który patrzysz na nerki i serce, dozwól, bym zobaczył Twoją pomstę na nich. Tobie bowiem powierzyłem swą sprawę.

Śpiewajcie Panu, wysławiajcie Pana! Uratował bowiem życie ubogiego z ręki złoczyńców».


2. czytanie (Rz 5, 12-15)

Bracia: Przez jednego człowieka grzech wszedł do świata, a przez grzech śmierć, i w ten sposób śmierć przeszła na wszystkich ludzi, ponieważ wszyscy zgrzeszyli. Bo i przed Prawem grzech był na świecie, grzechu się jednak nie poczytuje, gdy nie ma Prawa. A przecież śmierć rozpanoszyła się od Adama do Mojżesza nawet nad tymi, którzy nie zgrzeszyli przestępstwem na wzór Adama. On to jest typem Tego, który miał przyjść.
Ale nie tak samo ma się rzecz z przestępstwem, jak z darem łaski. Jeżeli bowiem przestępstwo jednego sprowadziło na wszystkich śmierć, to o ileż obficiej spłynęła na nich wszystkich łaska i dar Boży, łaskawie udzielony przez jednego Człowieka, Jezusa Chrystusa.


Ewangelia (Mt 10, 26-33)

Jezus powiedział do swoich apostołów: «Nie bójcie się ludzi! Nie ma bowiem nic skrytego, co by nie miało być wyjawione, ani nic tajemnego, o czym by się nie miano dowiedzieć. Co mówię wam w ciemności, powtarzajcie w świetle, a co słyszycie na ucho, rozgłaszajcie na dachach.
Nie bójcie się tych, którzy zabijają ciało, lecz duszy zabić nie mogą. Bójcie się raczej Tego, który duszę i ciało może zatracić w piekle. Czyż nie sprzedają dwóch wróbli za asa? A przecież bez woli Ojca waszego żaden z nich nie spadnie na ziemię. U was zaś policzone są nawet wszystkie włosy na głowie. Dlatego nie bójcie się: jesteście ważniejsi niż wiele wróbli.
Do każdego więc, kto się przyzna do Mnie przed ludźmi, przyznam się i Ja przed moim Ojcem, który jest w niebie. Lecz kto się Mnie zaprze przed ludźmi, tego zaprę się i Ja przed moim Ojcem, który jest w niebie».
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Ksiądz gra w grę: Detroit Become Human [#05] Prawo czy miłość?
 - [https://www.youtube.com/watch?v=oFkt7xNwXGs](https://www.youtube.com/watch?v=oFkt7xNwXGs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-06-20 00:00:00+00:00

@Langustanapalmie #detroitbecomehuman #ksiądzgrawgrę
________________________________________
Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Miriam [#41] Królowa
 - [https://www.youtube.com/watch?v=yA8A6Zz1wmI](https://www.youtube.com/watch?v=yA8A6Zz1wmI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-06-20 00:00:00+00:00

#Miriam #litanialoretańska @Langusta na palmie 
________________________________________
Komentarze do wezwań Litanii Loretańskiej. 

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#536] Ataki
 - [https://www.youtube.com/watch?v=Br5lusbjpk0](https://www.youtube.com/watch?v=Br5lusbjpk0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-06-20 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał  

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Ksiądz gra w grę: Uncharted Zaginione Dziedzictwo [#03] Pokorne dojrzewanie
 - [https://www.youtube.com/watch?v=hJRX5EVGYGE](https://www.youtube.com/watch?v=hJRX5EVGYGE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-06-19 00:00:00+00:00

@Langustanapalmie   #ksiądzgrawgrę #uncharted
 ________________________________________
Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Miniaturkę stworzył dla nas: Sebastian Gwóźdź

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#535] Przeciwko
 - [https://www.youtube.com/watch?v=4hLtYXEGXKY](https://www.youtube.com/watch?v=4hLtYXEGXKY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-06-19 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał  

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

