# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## The new HTC phones don't seem terrible...
 - [https://www.youtube.com/watch?v=5mr51JSxRc4](https://www.youtube.com/watch?v=5mr51JSxRc4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2020-06-19 00:00:00+00:00

0:00 - Intro 
0:33 - Huami makes its own chips
2:31 - HTC has new phones
4:17 - Windows apps on ChromeOS


Tech knowledge quiz (updated): https://www.crrowd.com/quiz

Check out Adam's work:
https://soundcloud.com/edemski
https://www.facebook.com/edemskimusic/
https://www.instagram.com/adam_edemski/


[[[ TECHALTAR LINKS ]]]: 

Merch: 
http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 

If you want to support TechAltar directly:
https://flattr.com/@techaltar

My video gear: 
https://kit.co/TechAltar/video-gear

