# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Things WORSE THAN LOSING in Video Games
 - [https://www.youtube.com/watch?v=QyBSH-GjJXs](https://www.youtube.com/watch?v=QyBSH-GjJXs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-06-22 00:00:00+00:00

Losing in video games, singleplayer or multiplayer, never feels good. Sometimes, there are even worse things that can happen in-game. Watch to see what we mean.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## Last of Us Part 2 - Top 10 Secrets & Easter Eggs
 - [https://www.youtube.com/watch?v=d4yDHBNQwf4](https://www.youtube.com/watch?v=d4yDHBNQwf4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-06-21 00:00:00+00:00

The Last of Us Part II (PS4) is filled with small jokes, references, callbacks, and Easter eggs. Here are our favorites.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## The Last of Us Part 2 - Before You Buy
 - [https://www.youtube.com/watch?v=BeI9MeYoka4](https://www.youtube.com/watch?v=BeI9MeYoka4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-06-21 00:00:00+00:00

The Last of Us Part II (PS4) is the sequel to the beloved game, this time focusing on Ellie. How is it? Let's talk.
Subscribe for more: http://youtube.com/gameranxtv ▼▼


Buy TLOU2: https://amzn.to/3fI6XAZ



Watch more 'Before You Buy': https://bit.ly/2kfdxI6

