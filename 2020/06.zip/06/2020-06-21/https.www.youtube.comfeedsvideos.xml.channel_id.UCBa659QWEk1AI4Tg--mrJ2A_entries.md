# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## I Asked 64,182 People About “Jingle Bells, Batman Smells”. Here's What I Found Out.
 - [https://www.youtube.com/watch?v=V5u9JSnAAU4](https://www.youtube.com/watch?v=V5u9JSnAAU4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2020-06-22 00:00:00+00:00

Thanks to Jack from Jacksfilms on piano: https://youtube.com/jacksfilms • And thanks to everyone who answered! Sources and a data download are in the description.

History sources:
https://www.cracked.com/blog/the-secret-true-history-jingle-bells-batman-smells/
https://www.cbr.com/jingle-bells-batman-smells-secret-origin/

Data spreadsheet link:
https://docs.google.com/spreadsheets/d/1bVUdszCBsWn5ez9FPFCioirdyNeZu3ctvNYShExpTQo

Audio mix by Graham Haerther: https://haerther.net

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

