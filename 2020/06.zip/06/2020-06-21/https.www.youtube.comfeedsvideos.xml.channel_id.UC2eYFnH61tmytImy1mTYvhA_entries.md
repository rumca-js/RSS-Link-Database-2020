# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## Gmail's dumb: Just host your own mail server!
 - [https://www.youtube.com/watch?v=9zP7qooM4pY](https://www.youtube.com/watch?v=9zP7qooM4pY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-06-22 00:00:00+00:00

I set up a mail server from scratch. Use Thunderbird, mutt or any other mail client to log in securely, just requires a domain name and a VPS/server. I use this script to help me:
https://github.com/lukesmithxyz/emailwiz

Not only will it automatically set up a Postfix and Dovecot server, but also Spamassassin and use OpenDKIM and SPF to validate and secure your mail domain to ensure that you can send messages to Gmail and other big addresses.

My registrar as used here is Epik: https://www.epik.com/?affid=we2ro7sa6 They are based.
My VPS is with Vultr: https://www.vultr.com/?ref=8384069-6G that affiliate link will give you a $100 credit to test the waters for the first month. A VPS after that can be about $3.50 a month.

By the way, once you do all this, you can also get a command-line based mail system with my mutt-wizard: https://github.com/lukesmithxyz/mutt-wizard

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE: https://lukesmith.xyz/donate 💰😎👌💯
OR affiliate links to things l use:
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://brave.com/luk005 Get the Brave browser.
https://lbry.tv/$/invite/@Luke View my videos on LBRY.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase.

