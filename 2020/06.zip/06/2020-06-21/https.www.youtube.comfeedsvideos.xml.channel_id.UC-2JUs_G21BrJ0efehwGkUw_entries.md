# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Imagine | John Lennon | funk cover ft. India Carney
 - [https://www.youtube.com/watch?v=rs70ff_9BWc](https://www.youtube.com/watch?v=rs70ff_9BWc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2020-06-22 00:00:00+00:00

Patreon: http://modal.scarypocketsfunk.com/patreon
Store: https://www.scarypocketsfunk.com
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A cover of "Imagine" by Scary Pockets.

CREDITS
Lead vocal: India Carney
Keys: Jack Conte
Guitar: Ryan Lerman
Drums: Lemar Carter
Bass: Sam Wilkes
BGVs/Additional Production: Louis Cato
Recording Engineer: Caleb Parker
Mixing/Mastering: Caleb Parker
Cinematography: Ricky Chavez
Video Editor: Adam Kritzberg

Recorded Live at Valentine Studios in Los Angeles, CA.

Watch more videos! 
Scary Pockets: https://youtube.com/playlist?list=PLL3xcB0B80KV06T2lqZhG5zUZuwojwuex&playnext=1 
90s Hits Funkified: https://youtube.com/playlist?list=PLL3xcB0B80KX25RsNBxJeuiO0YuJNWH46&playnext=1 
Scary Goldings: https://youtube.com/playlist?list=PLL3xcB0B80KWCRIVdgwL5ayqAczyccWNW&playnext=1 
Most Popular: https://youtube.com/playlist?list=PLL3xcB0B80KWzWR4-NxRrmRDwAnZfEXXr&playnext=1 

About Scary Pockets 
We are Scary Pockets, a funk band that releases weekly music videos, in pursuit of the funk. Scary Pockets is Ryan Lerman and Jack Conte, with the help and support from a rotating roster of the best session musicians in the LA area. Make sure to subscribe and enable ALL notifications! 

#ScaryPockets #Funk #Imagine #JohnLennon

