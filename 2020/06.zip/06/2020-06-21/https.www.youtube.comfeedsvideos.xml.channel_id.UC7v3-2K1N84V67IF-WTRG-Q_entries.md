# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Hannibal - Series Review
 - [https://www.youtube.com/watch?v=Pjq80xLSZhk](https://www.youtube.com/watch?v=Pjq80xLSZhk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-06-21 00:00:00+00:00

Hannibal was sadly cancelled after just 3 seasons, but all 3 seasons can now be found on Netflix. Here are my thoughts on the series HANNIBAL!

#Hannibal

