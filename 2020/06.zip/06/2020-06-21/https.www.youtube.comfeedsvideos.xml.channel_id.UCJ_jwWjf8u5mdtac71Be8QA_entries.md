## Somebody That I Used To Know (Bardcore | Medieval Style Cover with Vocals)
 - [https://www.youtube.com/watch?v=Ch1aVmjvYTI](https://www.youtube.com/watch?v=Ch1aVmjvYTI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJ_jwWjf8u5mdtac71Be8QA
 - date published: 2020-06-21 00:00:00+00:00

“Somebody That I Used to Know” by Gotye
Arranged and Performed by Hildegard von Blingin, featuring Friar Funk

Well met, strangers, and ever so glad to see you, old friends! Here's a banger from 8 years ago, but like you've never heard it before.

I’m trying my very best to put out a song once a week while your interest in Bardcore continues, and will continue to do so for as long as I can. Your support sustains me, I really mean that. I'm slowly making some moves towards getting this music on Spotify, so hang tight on that front. I'm also hoping to get some instrumental versions up for use as karaoke tracks or background music for gaming. 

The art used is a modified image from the Tacuinum Sanitatis.

Lyrics:
Now and then I think of when we were together
Eros surely hit the apple of mine eye  
I believed thou wert right for me,
but felt so lonely in thy company
But that was love and ‘tis an ache I still remember

One becomes enamoured with a certain kind of sadness
This resignation to the end, ever the end
When we found we could not make amends
Thou declared we would e’er be friends
But I concede that I was fain to be parted

Was there cause to cast me off?
Act as though it never happened and that we were nothing
In sooth I do need thy love
But thou makest me a stranger and that feels so rough
Hadst thou need to stoop so low?
To send a wagon for thy minstrel and refuse my letters
I need no longer write them, though
Now thou art somebody whom I used to know

I lament the many times that thou impugn’d my honour
But maintained it was ever something I had done
No more shall I live that way
Uncertain what thy words bewray 
Thou said that if I were to go
I would not find thee pining for somebody whom thou used to know

Was there cause to cast me off?
Act as if it never happened and that we were nothing
I do not even need thy love
But thou makest me stranger and that feels so rough
Hadst thou need to stoop so low
To send a wagon for thy minstrel and refuse my letters
I need no longer write them, though
For now thou art somebody whom I used to know
Now thou art somebody whom I used to know

