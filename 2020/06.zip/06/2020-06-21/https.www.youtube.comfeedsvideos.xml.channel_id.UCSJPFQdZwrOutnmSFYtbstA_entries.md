# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## The Drinker Recommends... Blade Runner
 - [https://www.youtube.com/watch?v=zdLn5MqER_g](https://www.youtube.com/watch?v=zdLn5MqER_g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-06-22 00:00:00+00:00

So for my latest Drinker Recommends, I'll be tackling one of the most iconic and influential sci-fi movies of all time - Blade Runner.

