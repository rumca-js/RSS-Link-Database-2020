# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Emily King - Already There (Live on KEXP)
 - [https://www.youtube.com/watch?v=a94aSxDVhvk](https://www.youtube.com/watch?v=a94aSxDVhvk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-06-22 00:00:00+00:00

http://KEXP.ORG presents Emily King performing "Already There" live in the KEXP studio. Recorded January 31, 2020.

Host: Stas THEE Boss
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://www.emilykingmusic.com

## Emily King - Distance (Live on KEXP)
 - [https://www.youtube.com/watch?v=gkaNQAeAyuA](https://www.youtube.com/watch?v=gkaNQAeAyuA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-06-22 00:00:00+00:00

http://KEXP.ORG presents Emily King performing "Distance" live in the KEXP studio. Recorded January 31, 2020.

Host: Stas THEE Boss
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://www.emilykingmusic.com

## Emily King - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=NKSLVgWf4Bs](https://www.youtube.com/watch?v=NKSLVgWf4Bs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-06-22 00:00:00+00:00

http://KEXP.ORG presents Emily King performing live in the KEXP studio. Recorded January 31, 2020.

Songs:
Look At Me Now
Already There
Distance
Go Back

Host: Stas THEE Boss
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://www.emilykingmusic.com

## Emily King - Go Back (Live on KEXP)
 - [https://www.youtube.com/watch?v=nhlfFC0vTZA](https://www.youtube.com/watch?v=nhlfFC0vTZA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-06-22 00:00:00+00:00

http://KEXP.ORG presents Emily King performing "Go Back" live in the KEXP studio. Recorded January 31, 2020.

Host: Stas THEE Boss
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://www.emilykingmusic.com

## Emily King - Look At Me Now (Live on KEXP)
 - [https://www.youtube.com/watch?v=l7HwftFcWcU](https://www.youtube.com/watch?v=l7HwftFcWcU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-06-22 00:00:00+00:00

http://KEXP.ORG presents Emily King performing "Look At Me Now" live in the KEXP studio. Recorded January 31, 2020.

Host: Stas THEE Boss
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://www.emilykingmusic.com

