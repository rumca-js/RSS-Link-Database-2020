# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## E-Waste: A Disaster In The Making | Answers With Joe
 - [https://www.youtube.com/watch?v=QTU1F865JJo](https://www.youtube.com/watch?v=QTU1F865JJo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2020-06-22 00:00:00+00:00

Get 20% off your subscription for life if you go to http://www.brilliant.org/answerswithjoe
Every year, the world produces over 40 million tons of e-waste; discarded electronic components that are filled with valuable metals and thousands of harmful toxins. It's quickly becoming a looming disaster.

If you have phones, tablets, laptops, or any other gadgets you need to get rid of, take the extra steps to do so responsibly. Here are some resources to help with that:

http://www.e-stewards.com

http://www.gazelle.com

http://www.apple.com/shop/trade-in

Goodwill's Reconnect Program:
https://www.goodwillsc.org/donate/computers

https://www.cellphonesforsoldiers.com/


Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

http://www.electronicstakeback.com/toxics-in-electronics/

http://www.newmoa.org/prevention/mercury/mercurylake.pdf

https://www.e-cycle.com/cell-phone-toxins-and-the-harmful-effects-on-the-human-body-when-recycled-improperly/

https://www.theguardian.com/global-development/2019/apr/24/rotten-chicken-eggs-e-waste-from-europe-poisons-ghana-food-chain-agbogbloshie-accra

https://www.unenvironment.org/news-and-stories/press-release/nigeria-turns-tide-electronic-waste

https://theconversation.com/electronic-waste-is-recycled-in-appalling-conditions-in-india-110363

https://www.cnet.com/videos/watch-apples-daisy-robot-rip-apart-old-iphones/

https://www.mint.bio/

http://ronin8.com/technology/

