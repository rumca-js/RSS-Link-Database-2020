# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Watch Amazon driver deliver an unusual request
 - [https://www.cnn.com/videos/business-videos/2020/06/21/amazon-delivery-driver-completes-unusual-request-orig-kj.cnn](https://www.cnn.com/videos/business-videos/2020/06/21/amazon-delivery-driver-completes-unusual-request-orig-kj.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-21 23:41:12+00:00

Lynn Staffieri's 13-year-old son Jacob included unusual "additional instructions" for delivery. See how the driver handled it.

## Confederate flag with 'Defund NASCAR' banner flies over Talladega
 - [https://www.cnn.com/videos/us/2020/06/21/nascar-talladega-confederate-flag-ban-scholes-nr-sot-vpx.cnn](https://www.cnn.com/videos/us/2020/06/21/nascar-talladega-confederate-flag-ban-scholes-nr-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-21 21:58:31+00:00

NASCAR fans return to the track for the first time since the organization's ban on displaying the Confederate flag. CNN's Andy Scholes reports from Talladega Superspeedway in Alabama.

## Everton holds up Liverpool's title charge in goalless Merseyside derby
 - [https://www.cnn.com/2020/06/21/football/football-merseyside-derby-liverpool-everton-spt-intl/index.html](https://www.cnn.com/2020/06/21/football/football-merseyside-derby-liverpool-everton-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-21 21:23:50+00:00

Liverpool took a stuttering step towards its first English league title in 30 years as the champion-elect was held to a goalless draw by Everton in the Merseyside derby at Goodison Park on Sunday.

## Lewandowski breaks Bundesliga scoring record as Chelsea-bound Werner draws blank
 - [https://www.cnn.com/2020/06/20/football/bundesliga-lewandowski-record-haaland-werner-arsenal/index.html](https://www.cnn.com/2020/06/20/football/bundesliga-lewandowski-record-haaland-werner-arsenal/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-21 21:21:39+00:00

The records keep tumbling for Bayern Munich striker Robert Lewandowski with a double against Freiburg Saturday seeing him surpass Pierre-Emerick Aubameyang's previous best for the most goals scored by a non-German player in a Bundesliga season.

## On Father's Day, Cuba's Elian Gonzalez announces he's set to become a dad
 - [https://www.cnn.com/2020/06/21/americas/elian-gonzalez-cuba-expecting-baby-trnd/index.html](https://www.cnn.com/2020/06/21/americas/elian-gonzalez-cuba-expecting-baby-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-21 20:34:36+00:00

Elian Gonzalez, the Cuban boy whose custody case sparked diplomatic tensions and attracted intense media coverage, will soon be a father himself, he announced on Facebook on Sunday.

## Belarus strongman faces mass protests after jailing of his main rivals
 - [https://www.cnn.com/2020/06/21/europe/belarus-protests-intl/index.html](https://www.cnn.com/2020/06/21/europe/belarus-protests-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-21 17:01:12+00:00

Mass protests are spreading across Belarus as opposition to the reelection campaign of President Alexander Lukashenko grows, local media and human-rights organizations have reported.

## UK terror suspect identified as Libyan national, security source says
 - [https://www.cnn.com/2020/06/21/uk/reading-terror-incident-intl-gbr/index.html](https://www.cnn.com/2020/06/21/uk/reading-terror-incident-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-21 16:28:27+00:00

A stabbing incident in the English town of Reading that left three people dead on Saturday is being investigated as a "terrorist incident," Thames Valley Police said on Sunday.

## CNN anchor reacts to Trump adviser's claim: Did I hear you wrong?
 - [https://www.cnn.com/videos/politics/2020/06/21/peter-navarro-china-coronavirus-claim-vpx-sotu-vpx.cnn](https://www.cnn.com/videos/politics/2020/06/21/peter-navarro-china-coronavirus-claim-vpx-sotu-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-21 14:40:09+00:00

CNN's Jake Tapper challenges White House trade adviser Peter Navarro's suggestion that China "created" coronavirus.

## Actor-comedian D.L. Hughley tests positive for coronavirus after collapsing onstage in Nashville
 - [https://www.cnn.com/2020/06/20/us/dl-hughley-passes-out-onstage-trnd/index.html](https://www.cnn.com/2020/06/20/us/dl-hughley-passes-out-onstage-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-21 13:50:15+00:00

Actor, comedian and former CNN anchor D.L. Hughley announced he tested positive for coronavirus after collapsing on stage during a show in Nashville.

## Zanardi remains in 'serious' condition after horror bike crash
 - [https://www.cnn.com/2020/06/20/motorsport/alex-zanardi-coma-cycling-accident-paralympics/index.html](https://www.cnn.com/2020/06/20/motorsport/alex-zanardi-coma-cycling-accident-paralympics/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-21 11:19:19+00:00

Ex-Formula One driver and four-time Paralympic gold medalist Alex Zanardi is in an artificial coma after suffering severe head injuries in a horrific cycling race crash.

## How Trump's Tulsa comeback rally flopped
 - [https://www.cnn.com/2020/06/21/politics/trump-campaign-trail-coronavirus/index.html](https://www.cnn.com/2020/06/21/politics/trump-campaign-trail-coronavirus/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-21 11:13:58+00:00

By the time President Donald Trump was gliding in his helicopter toward Joint Base Andrews on Saturday, destined for what he'd once hoped would be a triumphant packed-to-the-rafters return to the campaign trail, things were already looking bad.

## Three activists say they were abducted by security forces after protesting. The government put them in jail
 - [https://www.cnn.com/2020/06/21/africa/zimbabwe-activists-jail-intl/index.html](https://www.cnn.com/2020/06/21/africa/zimbabwe-activists-jail-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-21 09:49:16+00:00

The mood was somber as magistrate Bianca Makwande read her bail ruling to three members of Zimbabwe's main opposition party.

## Kurt Cobain's 'MTV Unplugged' guitar sells for 'record' fee
 - [https://www.cnn.com/style/article/kurt-cobain-guitar-sold-intl-scli/index.html](https://www.cnn.com/style/article/kurt-cobain-guitar-sold-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-21 08:57:41+00:00

The guitar played by Nirvana frontman Kurt Cobain during his 1993 "MTV Unplugged" performance has sold for $6 million at auction.

## China releases blueprint for Hong Kong national security law
 - [https://www.cnn.com/2020/06/21/china/hong-kong-china-national-security-law-details-intl-hnk/index.html](https://www.cnn.com/2020/06/21/china/hong-kong-china-national-security-law-details-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-21 08:33:57+00:00

China revealed a blueprint on Saturday night for a controversial new national security law, which critics say threatens political and civil freedoms in Hong Kong and broadens Beijing's direct control over the semi-autonomous city.

## Fewer Trump fans came than expected. They explain why
 - [https://www.cnn.com/videos/politics/2020/06/21/trump-tulsa-rally-supporters-natpkg-jg-orig.cnn](https://www.cnn.com/videos/politics/2020/06/21/trump-tulsa-rally-supporters-natpkg-jg-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-21 05:15:31+00:00

President Trump's rally in Tulsa, Oklahoma, didn't overflow. But supporters came despite the on-going pandemic. See what it was like downtown this weekend.

## Trump says he wanted testing slowed down, uses racist term for coronavirus
 - [https://www.cnn.com/2020/06/20/politics/tulsa-rally-trump/index.html](https://www.cnn.com/2020/06/20/politics/tulsa-rally-trump/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-21 04:37:19+00:00

In a shocking admission during his Tulsa, Oklahoma, rally on Saturday night, President Donald Trump said he had told officials in his administration to slow down coronavirus testing because of the rising number of cases in America, and used a racist term to describe the coronavirus.

## This 5-minute yoga routine will boost your energy and start the day right
 - [https://www.cnn.com/2020/06/21/health/morning-yoga-in-bed-wellness/index.html](https://www.cnn.com/2020/06/21/health/morning-yoga-in-bed-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-21 04:10:06+00:00

The countless hours that many of us have spent sitting at a makeshift desk in quarantine can be detrimental not only physically but also mentally. Hunched over a computer day in and day out, you're not just wreaking havoc on your posture, but you're likely feeling out of sorts and drained, too.

## Trump calls protesters 'thugs' despite peaceful demonstrations in Tulsa
 - [https://www.cnn.com/2020/06/20/us/nationwide-protests-saturday/index.html](https://www.cnn.com/2020/06/20/us/nationwide-protests-saturday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-21 02:53:50+00:00

A tumultuous spring spilled into summer in America on Saturday with President Donald Trump returning to the campaign trail in Tulsa and protests over racism and police brutality sweeping the country.

## Rapper Hurricane Chris charged with second-degree murder
 - [https://www.cnn.com/2020/06/20/us/hurricane-chris-second-degree-murder/index.html](https://www.cnn.com/2020/06/20/us/hurricane-chris-second-degree-murder/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-21 02:33:54+00:00

Rapper Hurricane Chris, who rose to fame in 2007, is facing a murder charge after a man was fatally shot Friday in Shreveport, Louisiana, according to police.

## Solar eclipse 2020: See June's annular eclipse on Sunday
 - [https://www.cnn.com/2020/06/20/world/solar-eclipse-annular-june-2020-scn-trnd/index.html](https://www.cnn.com/2020/06/20/world/solar-eclipse-annular-june-2020-scn-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-21 02:13:05+00:00

Lucky stargazers in the Eastern Hemisphere will see an annular solar eclipse on the heels of the summer solstice on Sunday. This type of eclipse is characterized by its stunning "ring of fire" since it's not a total eclipse and edges of the sun can still be seen around the moon.

## Three dead in stabbing incident in Reading, England
 - [https://www.cnn.com/2020/06/20/uk/reading-uk-incident/index.html](https://www.cnn.com/2020/06/20/uk/reading-uk-incident/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-21 02:11:29+00:00

A man has been arrested in connection with a stabbing incident Saturday in the English town of Reading that left multiple people with injuries, according to the Thames Valley Police.

## Facebook vowed to investigate horrific abuse by anti-vaxxers. Nine months later, no one was penalized
 - [https://www.cnn.com/2020/06/20/health/facebook-anti-vaxxer-investigation-update/index.html](https://www.cnn.com/2020/06/20/health/facebook-anti-vaxxer-investigation-update/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-21 02:09:58+00:00

Nine months after Facebook vowed to investigate abuse by anti-vaxxers, no users have been penalized.

## Shooting in Seattle protest zone leaves one dead. Police say 'violent crowd' denied them entry
 - [https://www.cnn.com/2020/06/20/us/seattle-capitol-hill-chop-chaz-shooting/index.html](https://www.cnn.com/2020/06/20/us/seattle-capitol-hill-chop-chaz-shooting/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-21 02:07:14+00:00

Seattle police say a "violent crowd" prevented them reaching two shooting victims -- one whom later died -- inside the city's autonomous protest zone Saturday.

## Why this Japan-China island dispute could be Asia's next military flashpoint
 - [https://www.cnn.com/2020/06/20/asia/china-japan-islands-dispute-hnk-intl/index.html](https://www.cnn.com/2020/06/20/asia/china-japan-islands-dispute-hnk-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-21 01:40:55+00:00

While China is engaged in a tense border standoff with India high in the Himalayas, a small group of islands thousands of miles away could be another military tinderbox waiting to explode.

## Early CDC test kits were delayed because of contamination issues, HHS report affirms
 - [https://www.cnn.com/2020/06/20/politics/cdc-test-kits-contamination/index.html](https://www.cnn.com/2020/06/20/politics/cdc-test-kits-contamination/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-21 01:12:47+00:00

One of two types of test kits produced by the US Centers for Disease Control and Prevention in January were likely contaminated, its parent agency confirmed.

## Graphic novel on the Tiananmen Massacre shows medium's power to capture history
 - [https://www.cnn.com/style/article/tiananmen-square-massacre-graphic-novel-comics-journalism-intl-hnk/index.html](https://www.cnn.com/style/article/tiananmen-square-massacre-graphic-novel-comics-journalism-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-21 01:08:17+00:00

As a young man in Beijing in the 1980s, Lun Zhang felt like he was taking part in a new Chinese enlightenment.

## Top US prosecutor is leaving office after standoff with Trump administration
 - [https://www.cnn.com/2020/06/20/politics/trump-fires-berman-barr-says/index.html](https://www.cnn.com/2020/06/20/politics/trump-fires-berman-barr-says/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-21 01:08:12+00:00

Attorney General Bill Barr said in a letter Saturday that President Donald Trump had fired Geoffrey Berman, the powerful prosecutor atop the Manhattan US Attorney's office who has investigated Trump's allies, after Berman refused Barr's effort a day prior to oust him.

## While Trump wages a political war, dangerous conflicts unfold in Asia
 - [https://www.cnn.com/2020/06/20/opinions/trump-china-india-asia-korea-vinograd/index.html](https://www.cnn.com/2020/06/20/opinions/trump-china-india-asia-korea-vinograd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-21 00:27:23+00:00



