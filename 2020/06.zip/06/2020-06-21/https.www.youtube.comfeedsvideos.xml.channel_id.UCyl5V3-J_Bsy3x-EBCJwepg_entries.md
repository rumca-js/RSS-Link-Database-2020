# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Podcast Preview: Dinesh D'Souza
 - [https://www.youtube.com/watch?v=7ip37CoUNaw](https://www.youtube.com/watch?v=7ip37CoUNaw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-06-22 00:00:00+00:00

Tomorrow Dinesh D'Souza joins Kyle and Ethan on the Babylon Bee podcast.

## Kyle's Dad Doesn't Know What A CHAZ Is
 - [https://www.youtube.com/watch?v=6Cz2E_7SC_8](https://www.youtube.com/watch?v=6Cz2E_7SC_8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-06-21 00:00:00+00:00

Kyle and Ethan attempt to explain to Kyle's dad Seattle's new Capitol Hill Autonomous Zone.

FULL ▶️ https://youtu.be/62u_IUV8-rk

