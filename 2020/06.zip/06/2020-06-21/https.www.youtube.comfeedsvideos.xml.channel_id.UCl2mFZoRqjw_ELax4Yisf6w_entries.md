# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## GORGEOUS $659,000 house for sale in Brooklyn, New York City!
 - [https://www.youtube.com/watch?v=mUyubCDxF8M](https://www.youtube.com/watch?v=mUyubCDxF8M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-06-22 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
👉 https://www.realtor.com/realestateandhomes-detail/884-E-12th-St_Brooklyn_NY_11230_M37755-21664?view=qv 
🔴 https://www.nydailynews.com/new-york/nyc-crime/ny-man-fatally-shot-brooklyn-gun-violence-soars-20200620-pp3uqtsenbf63n4aei3tw265ou-story.html#nt=latestnews&rt=chartbeat-flt 
🔴 https://gothamist.com/news/illegal-fireworks-displays-show-no-sign-slowing-down-nyc
👉 Equipment I use to record video:
🔵 LG G8 Cellphone camera: https://amzn.to/2YQoe4g
🔵 Rode cellphone mic: https://amzn.to/314NCpy 
🔵 Sony A5100 home camera: https://amzn.to/315Hi1g
🔵 AT4050 home microphone: https://amzn.to/2Bp8hdg

## An important message from our sponsors at Rossmann Repair Group NYC
 - [https://www.youtube.com/watch?v=hKxIEaiSpvI](https://www.youtube.com/watch?v=hKxIEaiSpvI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-06-21 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545

