# Source:SciFun, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCWTA5Yd0rAkQt5-9etIFoBA, language:pl-PL

## Życie w kropli wody
 - [https://www.youtube.com/watch?v=lSuIuUT4qKs](https://www.youtube.com/watch?v=lSuIuUT4qKs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCWTA5Yd0rAkQt5-9etIFoBA
 - date published: 2020-06-22 00:00:00+00:00

Zakres powiększeń 50-500x. Techniki obserwacyjne: jasne i ciemne pole, polaryzacja, kontrast różnicowo interferencyjny Nomarskiego. Źródła wody do preparatów: duże jezioro, mała rzeka, kałuża na polnej drodze, kran, butelka wody mineralnej.

