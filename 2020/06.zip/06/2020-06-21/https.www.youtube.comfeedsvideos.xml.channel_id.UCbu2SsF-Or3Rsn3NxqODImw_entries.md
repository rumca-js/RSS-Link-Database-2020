# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## 90s & 2000s Movie Trivia With GameSpot Universe
 - [https://www.youtube.com/watch?v=g8CxQC_QIRU](https://www.youtube.com/watch?v=g8CxQC_QIRU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-22 00:00:00+00:00

Where to donate:
BLACK LIVES MATTER: http://bit.ly/gs-blm

COVID-19 Direct Relief: http://bit.ly/gs-covid

Join the GameSpot Universe team for 90s & 2000s Movie Trivia! Quizmaster Chastity will test our entertainment team's knowledge of horror, superhero and action films. Plus, bonus rounds for movie taglines and posters!

## Alex Garland's Favorite Games Include Dark Souls, Animal Crossing
 - [https://www.youtube.com/watch?v=TMdasaWiYD8](https://www.youtube.com/watch?v=TMdasaWiYD8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-22 00:00:00+00:00

Visionary filmmaker Alex Garland (Ex Machina, Annihilation) discusses his favorite games and answers our lingering questions about Annihilation and his first TV series, Devs. 

Where to donate: 
BLACK LIVES MATTER: http://bit.ly/gs-blm
COVID-19 Direct Relief: http://bit.ly/gs-covid


As part of our Play For All charity event, filmmaker Alex Garland joined us for an interview to talk about his favorite games, including Dark Souls, The Last of Us, and Animal Crossing New Horizons - which he has put an impressive amount of time into. Garland is known for writing and directing the films Ex Machina and Annihilation, and for writing the movies 28 Days Later, Dredd, and the game Enslaved: Odyssey to the West. Garland expressed his desire to work on more video games. 



*Spoiler Warning: Spoilers for Devs and Annihilation start at 17:24


Garland recently made his television debut as the creator, executive producer, writer and director of Devs, a sci-fi miniseries on FX on Hulu. Mike Rougeau and Meg Downey broke down every episode of the limited series on GameSpot Universe, and asked Garland some of their lingering questions about the show. Garland also answered some of Meg's burning questions about his film, Annihilation. And yes, we asked about that terrifying bear. Devs is available to stream in its entirety on Hulu, and we highly recommend watching it if you haven't already.

## Borderlands 3 Bounty Of Blood DLC Is A Slightly Serious Revenge Western
 - [https://www.youtube.com/watch?v=SMFpaq5cpkU](https://www.youtube.com/watch?v=SMFpaq5cpkU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-22 00:00:00+00:00

Borderlands 3 Bounty Of Blood DLC sees vault hunters landing on the new planet Gehenna in order to live out a revenge filled western plot. In this interview Gearbox creative director Matt Cox talks about what players will be doing including making some story decisions, riding Jetbeast vehicles, and meeting new characters including Rose and Juno. Bounty Of Blood also adds new weapons including a murderous soap bubble blaster and beast-riding adversaries. Bounty of Blood also adds new mechanics including environmental weapons and hazards including the tailorweed, telezapper, coresploder, and breezer.

Bounty Of Blood is the third DLC for Borderlands 3 and releases on June 25th on PS4, Xbox One, and PC.

## Crash Bandicoot 4 Interview: New Details, Release Date Interview, And More
 - [https://www.youtube.com/watch?v=sHS3ps6gzA8](https://www.youtube.com/watch?v=sHS3ps6gzA8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-22 00:00:00+00:00

We chat with Toys For Bob's design producer Lou Studdert about the new Crash Bandicoot game, discussing the new art style, playing as Crash and Coco, and gameplay changes such as collecting masks that can bend time and gravity.

Crash Bandicoot 4: It’s About Time is the first sequel to the Crash series in more than ten years. The latest game takes place a few years after Crash Bandicoot 3: Warped with some characters banned to the end of time and space. Players will take on the role of Crash or Coco to find four quantum masks in order to fix the universe. These masks allow players to manipulate levels through mechanics like time and gravity. The game expands the scope of levels, includes larger boss battles, and adds movement mechanics including wall-running, rail grinding, and rope swinging. Going between regular and retro mode will also change the way players collect lives. Crash Bandicoot 4: It’s About Time releases on October 9 for PlayStation 4 and Xbox One.

## Crash Bandicoot 4: It's About Time - Official Reveal Trailer
 - [https://www.youtube.com/watch?v=1X70RGPpJyA](https://www.youtube.com/watch?v=1X70RGPpJyA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-22 00:00:00+00:00

Crash Bandicoot returns with all-new powers and worlds to explore, in Crash Bandicoot 4: It's About Time. Coming this October to PlayStation 4 and Xbox One.

## Summer Game Fest Dev Show Case - Crash 4 Announcement, ALF, and Day of Devs Live
 - [https://www.youtube.com/watch?v=3Cr5iKbLrmU](https://www.youtube.com/watch?v=3Cr5iKbLrmU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-22 00:00:00+00:00

Tune in on to see the first developer showcase in collaboration with Day of the Devs and the Game Awards on Monday, June 22, starting at 8:00am PT. Tune in to learn more about Crash 4, ALF, and more.

## The Last Of Us Part 2 Spoiler Chat
 - [https://www.youtube.com/watch?v=PUkfvLdU_dQ](https://www.youtube.com/watch?v=PUkfvLdU_dQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-06-21 00:00:00+00:00

Now that The Last Of Us Part 2 is out, the GameSpot staff sit down to discuss the twists, turns, and surprises of Naughty Dog's latest PlayStation 4 adventure.

The Last of Us Part II is now available on PS4, and a few of us here at GameSpot have had a chance to play through it--some of us multiple times--and even get some Platinums along the way. In the above video, Jake Dekker, Kallie Plagge, Jordan Ramée, and Edmond Tran discuss the game in all its spoilery glory. And yes, we spoil everything. Watch at your own risk!

The crew starts from the very beginning and goes through the highs and lows of The Last of Us Part II's story. Jake shares his experience playing on Survivor difficulty; Kallie explains her review in more detail; Jordan shares his interpretation of the Seraphites; Ed talks about how much he loves Jesse; and more!

