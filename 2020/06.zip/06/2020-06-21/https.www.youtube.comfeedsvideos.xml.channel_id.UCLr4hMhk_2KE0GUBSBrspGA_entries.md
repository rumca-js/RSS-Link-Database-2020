# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week: Pies robot za 300 tysięcy! Boston Dynamics, Sony Xperia 1 II, POCO F2 Pro , Realme X3
 - [https://www.youtube.com/watch?v=3-x4qHilGoQ](https://www.youtube.com/watch?v=3-x4qHilGoQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-06-21 00:00:00+00:00

A Tech Week za free. A wlepki za dychę: https://znosne.pl
Moje sociale: 
insta: http://bit.ly/InstaKlawiatur 
Twitter: http://bit.ly/TTKlawitera
FB: http://bit.ly/FBKlawiatur

00:00 Wstęp
00:30 Pies robot
02:38 Podróba psa robota
03:39 Gaśnica akustyczna
04:19 Prawo jazdy w smartfonie
05:01 Wspólne konto dla par
05:41 Sony Xperia 1 II
06:11 POCO F2 Pro i Realme X3 SuperZoom
06:43 Miesięczny karnet na elektryczną hulajnogę
07:22 Recenzje widzów
10:30 Zmierzch recenzentów
12:19 Recenzja powerbenka z latarką, wiatrakiem i bez słuchawek
13:13 Drony Autel w Polsce
13:56 Wlepy #jeszczedobry
15:12 Pożegnanie

Źródła:
Pies robot kosztuje 300 tysięcy złotych: https://cnet.co/2V5qmnx
Akustyczna gaśnica: https://bit.ly/2AMnRjm
Konto premium dla par: https://bit.ly/2zR2OeN
Karta miesięczna na Lime'a: https://bit.ly/3hOwQ44
Drony Autel (PL): https://bit.ly/314pUtQ (US): https://bit.ly/37PREDJ

