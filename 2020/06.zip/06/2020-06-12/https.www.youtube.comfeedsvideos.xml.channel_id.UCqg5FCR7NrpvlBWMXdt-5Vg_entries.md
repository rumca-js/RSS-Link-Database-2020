# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## The Escapist Indie Showcase (Post-Show) - Day 1
 - [https://www.youtube.com/watch?v=wwcP7aFuWm0](https://www.youtube.com/watch?v=wwcP7aFuWm0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-06-13 00:00:00+00:00

Timestamps
5:20 - 26:53 - FIGMENT CREED VALLEY
31:36 - 53:00 - THE LAST SPELL
59:06 - 1:14:00 - A JUGGLER'S TALE
1:29:00 - 1:51:00 - THE WAY OF WRATH
GO TO PART 2 DUE TO TECH ISSUES


Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Day 1 of The Escapist Indie Showcase! 

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## The Escapist Indie Showcase (Post-Show) Day 2
 - [https://www.youtube.com/watch?v=tIqlxThH9do](https://www.youtube.com/watch?v=tIqlxThH9do)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-06-13 00:00:00+00:00

SCHEDULE
11:00 ET Lost Words: Beyond the Page
11:30 ET Minute of Islands
12:00 ET KeyWe
12:30 ET Paradise Killer
1:00 ET Trifox
1:30 ET Wave Break
2:00 ET Unto the End
2:30 ET We Are the Caretakers
3:00 ET Unbound: Worlds Apart
3:30 Everspace 2
4:00 ET Haven
4:30 ET Hyperbrawl Tournament
5:00 ET Breakpoint
5:30 ET Dreamscaper
6:00 ET Windboud
6:30 ET Bartlow's Dread Machine
7:00 ET Nighthawks
7:30 ET SURPRISE


Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Day 2 of The Escapist Indie Showcase! 

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

