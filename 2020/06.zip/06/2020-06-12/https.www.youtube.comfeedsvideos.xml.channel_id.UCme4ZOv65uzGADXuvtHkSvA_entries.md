# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## CNN [#185] Co dalej z Kościołem?
 - [https://www.youtube.com/watch?v=QML8SJf8qvE](https://www.youtube.com/watch?v=QML8SJf8qvE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-06-13 00:00:00+00:00

#cnn #kazaniedookienka @Langustanapalmie 

Kazanie XIII Niedzielę zwykłą, Rok A

1. czytanie (Wj 19, 2-6a)

Po przybyciu na pustynię Synaj Izraelici rozbili obóz na pustyni. Izrael obozował tam naprzeciw góry. Mojżesz wszedł wtedy na górę do Boga, a Pan zawołał na niego z góry i powiedział: «Tak powiesz domowi Jakuba i to oznajmisz Izraelitom: Wy widzieliście, co uczyniłem Egiptowi, jak niosłem was na skrzydłach orlich i przywiodłem was do Mnie. Teraz, jeśli pilnie słuchać będziecie głosu mego i strzec mojego przymierza, będziecie szczególną moją własnością pośród wszystkich narodów, gdyż do Mnie należy cała ziemia. Lecz wy będziecie Mi królestwem kapłanów i ludem świętym».

2. czytanie (Rz 5, 6-11)

Bracia: Chrystus umarł za nas, jako za grzeszników, w oznaczonym czasie, gdy jeszcze byliśmy bezsilni. A nawet za człowieka sprawiedliwego podejmuje się ktoś umrzeć tylko z największą trudnością. Chociaż może jeszcze za człowieka życzliwego odważyłby się ktoś ponieść śmierć. Bóg zaś okazuje nam swoją miłość właśnie przez to, że Chrystus umarł za nas, gdy byliśmy jeszcze grzesznikami. Tym bardziej więc będziemy przez Niego zachowani od karzącego gniewu, gdy teraz przez krew Jego zostaliśmy usprawiedliwieni. Jeżeli bowiem, będąc nieprzyjaciółmi, zostaliśmy pojednani z Bogiem przez śmierć Jego Syna, to tym bardziej, będąc już pojednanymi, dostąpimy zbawienia przez Jego życie. I nie tylko to – ale i chlubić się możemy w Bogu przez Pana naszego Jezusa Chrystusa, przez którego teraz uzyskaliśmy pojednanie.

Ewangelia (Mt 9, 36 – 10, 8)

Jezus, widząc tłumy, litował się nad nimi, bo byli znękani i porzuceni, jak owce niemające pasterza. Wtedy rzekł do swych uczniów: «Żniwo wprawdzie wielkie, ale robotników mało. Proście Pana żniwa, żeby wyprawił robotników na swoje żniwo».

Wtedy przywołał do siebie dwunastu swoich uczniów i udzielił im władzy nad duchami nieczystymi, aby je wypędzali i leczyli wszystkie choroby i wszelkie słabości.

A oto imiona dwunastu apostołów: pierwszy – Szymon, zwany Piotrem, i brat jego Andrzej, potem Jakub, syn Zebedeusza, i brat jego Jan, Filip i Bartłomiej, Tomasz i celnik Mateusz, Jakub, syn Alfeusza, i Tadeusz, Szymon Gorliwy i Judasz Iskariota, ten, który Go zdradził.

Tych to Dwunastu wysłał Jezus i dał im takie wskazania: «Nie idźcie do pogan i nie wstępujcie do żadnego miasta samarytańskiego. Idźcie raczej do owiec, które poginęły z domu Izraela. Idźcie i głoście: Bliskie już jest królestwo niebieskie. Uzdrawiajcie chorych, wskrzeszajcie umarłych, oczyszczajcie trędowatych, wypędzajcie złe duchy. Darmo otrzymaliście, darmo dawajcie».
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Ksiądz gra w grę: Detroit Become Human [#04] Jak daleko się posuniesz chroniąc bliskich?
 - [https://www.youtube.com/watch?v=eYGgCMUBwI8](https://www.youtube.com/watch?v=eYGgCMUBwI8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-06-13 00:00:00+00:00

@Langustanapalmie   #detroitbecomehuman #ksiądzgrawgrę
________________________________________
Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Miriam [#40] Wspomożenie wiernych
 - [https://www.youtube.com/watch?v=LZQEiQjdWQo](https://www.youtube.com/watch?v=LZQEiQjdWQo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-06-13 00:00:00+00:00

#Miriam #litanialoretańska @Langustanapalmie 
________________________________________
Komentarze do wezwań Litanii Loretańskiej. 

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Targ intencji || czerwiec 2020
 - [https://www.youtube.com/watch?v=VVGs4zoL7kY](https://www.youtube.com/watch?v=VVGs4zoL7kY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-06-13 00:00:00+00:00

Targ intencji na czerwiec 2020.

________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#530] Delikatni
 - [https://www.youtube.com/watch?v=ziC4OPkNqw4](https://www.youtube.com/watch?v=ziC4OPkNqw4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-06-13 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał  

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#529] Pierwszy
 - [https://www.youtube.com/watch?v=Me2NXF17tfU](https://www.youtube.com/watch?v=Me2NXF17tfU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-06-12 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał  

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## [NV#377] Przemoc, uzależnienie, ZUO, czyli granie w gry (Q&A#50)
 - [https://www.youtube.com/watch?v=G1yrjt2JOGU](https://www.youtube.com/watch?v=G1yrjt2JOGU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-06-12 00:00:00+00:00

@Langusta na palmie #bedegralwgre #ksiadzgrawgre
________________________________________
Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Spis wszystkich dotychczasowych pytań, na które ojciec odpowiedział w Q&A: http://spis-qa-langusty-na-palmie.co.place/

W miniaturce wykorzystaliśmy grafikę stworzoną przez Sebastiana Gwoździa. 

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

