# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## IT'S FINALLY DONE! Hack Pro Final Assembly
 - [https://www.youtube.com/watch?v=Xh0bdzeAZ1w](https://www.youtube.com/watch?v=Xh0bdzeAZ1w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-06-13 00:00:00+00:00

Visit https://www.squarespace.com/LTT and use offer code LTT for 10% off

Save 10% and Free Worldwide Shipping at Ridge Wallets by using offer code LINUS at https://www.ridge.com/LINUS

In part 5 of this series we get  our G5 case prepped for paint, finalize any cutouts, and permanently affix our front and rear panels with some binder clips and JB weld. We also fit our massive Aourus C621 Xtreme back into the case for an almost final build. 

Buy EKWB CPU Block
On Amazon (PAID LINK): https://geni.us/0Hep
On Newegg (PAID LINK): https://geni.us/xFYyH

Buy EKWB G 1/4 Fittings
On Amazon (PAID LINK): https://geni.us/toxxAy

Buy EKWB Tubing
On Amazon (PAID LINK): https://geni.us/m7RdmM
On Newegg (PAID LINK): https://geni.us/JSBN6qk

Buy EKWB GPU Blocks
On Amazon (PAID LINK): https://geni.us/mGxqo
On Newegg (PAID LINK): https://geni.us/qybQ7

Buy Aorus C621 Xtreme
On Amazon (PAID LINK): https://geni.us/A62g

Buy Radeon Vii's
On Amazon (PAID LINK): https://geni.us/BXCd07
On Newegg (PAID LINK): https://geni.us/Dcxv

Buy Fenvi FV-T919
On Amazon (PAID LINK): https://geni.us/zQb8Gx
On Newegg (PAID LINK): https://geni.us/VGtt

Buy SilverStone ST1200-PTS
On Amazon (PAID LINK): https://geni.us/LMDRu
On Newegg (PAID LINK): https://geni.us/ZN4IH1K

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://lmg.gg/rnGMj


GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Mech Keyboard: https://geni.us/RecNBTI
NEEDforSEAT Gaming Chairs: https://geni.us/needforseat
Get a Displate Metal Print at https://lmg.gg/displateltt
Use code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Gear on Amazon: https://geni.us/lmgamazon
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0 https://lmg.gg/fxHYK 
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://lmg.gg/Q9yyQ 
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://lmg.gg/8upii

## Sony PlayStation - by Alienware - WAN Show June 12, 2020
 - [https://www.youtube.com/watch?v=AwmJHcx2iHg](https://www.youtube.com/watch?v=AwmJHcx2iHg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-06-12 00:00:00+00:00

Save 10% at Ridge Wallet with offer code LINUS at https://www.ridge.com/Linus

Visit https://www.squarespace.com/WAN and use offer code WAN for 10% off

Save 15% today with offer code WAN on Displate at https://lmg.gg/displatewan

Buy an LTT shirt, hoodie, hat, and even our own water bottle at https://lmg.gg/wanlttstore

Check out Carpool Critics, our new movie podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Podcast Download: https://dts.podtrac.com/redirect.mp3/traffic.libsyn.com/secure/linustechtips/Sony_PlayStation_-_by_Alienware_-_WAN_Show_June_12_2020.mp3

Timestamps: (Courtesy of Kyshakk)

0:55 Topic Summary
1:34 Intro
2:55 Ea titles returned to steam
11:42 Ps5
44:05 Sponsors
47:35 Bathroom stuff
54:40 Chief Engineer Resigns from intel
1:03:05 Intel 5 Core CPU
1:05:57 Ryzen 5700Xt specs leaked by amazon
1:07:35 Leaked RTX 3080
1:14:44 Intel security vulnerability
1:16:12 Twitch
1:24:36 Superchats
1:32:26 Outro

