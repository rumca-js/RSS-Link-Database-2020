# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Joe Rogan Experience #1491 - Bill Burr
 - [https://www.youtube.com/watch?v=GO_rW0Bvy1I](https://www.youtube.com/watch?v=GO_rW0Bvy1I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2020-06-12 00:00:00+00:00

Bill Burr is a standup comedian and also hosts his own podcast called “The Monday Morning Podcast”. Look for him in the new film "The King of Staten Island" available for streaming everywhere, and also on the 4th season of his show "F Is for Family" streaming only on Netflix, both available on June 12. @BillBurrOfficial

