# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Dlaczego Rafał Trzaskowski wstydzi się swojego flagowego postulatu?
 - [https://www.youtube.com/watch?v=Wdwx03IWq7k](https://www.youtube.com/watch?v=Wdwx03IWq7k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2020-06-13 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Mroczne Podcasty: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
👀 Tatusiek: http://bit.ly/3aSCheE
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
🔒 Dołącz do Spółdzielni
https://discord.gg/RSEUaR3
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Zostań mecenasem
PLN / SMS / Blik: http://bit.ly/2ETKSyN
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
------------------------------------------------------------
✅źródła:
https://bit.ly/3flI1PM
https://bit.ly/30yJLku
https://bit.ly/3dZLnHQ
---------------------------------------------------------------
🖼Grafika - wykorzystano elementy ze strony: 
Adrian Grycuk / wikipedia.org / CC BY-SA 3.0 pl 
http://bit.ly/2GVG5kn
-------------------------------------------------------------
💡 Tagi: #Trzaskowski #demokracja
--------------------------------------------------------------

## "Cham Zbuntowany" Ziemkiewicza zablokowany na Allegro.
 - [https://www.youtube.com/watch?v=G4QDP4ZBhFI](https://www.youtube.com/watch?v=G4QDP4ZBhFI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2020-06-12 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Mroczne Podcasty: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
👀 Tatusiek: http://bit.ly/3aSCheE
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
🔒 Dołącz do Spółdzielni
https://discord.gg/RSEUaR3
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Zostań mecenasem
PLN / SMS / Blik: http://bit.ly/2ETKSyN
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
------------------------------------------------------------
✅źródła:
https://bit.ly/3dUSLnX
https://bit.ly/3hmW6y0
https://bit.ly/3dWbyPH
---------------------------------------------------------------
🖼Grafika - wykorzystano elementy ze strony:
wikipedia / Adrian Grycuk 
https://bit.ly/2zqr8Ed
-------------------------------------------------------------
💡 Tagi: #Ziemkiewicz #Allegro
--------------------------------------------------------------

