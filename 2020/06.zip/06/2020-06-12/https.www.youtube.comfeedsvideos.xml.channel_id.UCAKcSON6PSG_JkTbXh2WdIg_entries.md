# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## A Message to All Graduates
 - [https://www.youtube.com/watch?v=qfJHZ9dHtT0](https://www.youtube.com/watch?v=qfJHZ9dHtT0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-06-12 00:00:00+00:00

Here's a special message to the graduates of the Class of 2020 from your friends at The Current.
Visit this link at thecurrent.org to find a special playlist created just for you:
https://www.thecurrent.org/feature/2020/06/13/a-message-to-all-graduates 

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Jack Garratt - two performances for The Current
 - [https://www.youtube.com/watch?v=ASG3s_xuIag](https://www.youtube.com/watch?v=ASG3s_xuIag)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-06-12 00:00:00+00:00

On Friday, June 12, 2020, Jack Garratt releases his second full-length album, 'Love, Death & Dancing.' Marking that occasion, watch these performances that Garratt recorded with The Current back in 2016, one of them right in our studio and the other at a Microshow at the Weisman Museum at the University of Minnesota.

SONGS PERFORMED
00:00 "Worry"
04:02 "Weathered"

CREDITS
Video & Photo: Nate Ryan
Audio: Michael DeMark, Erik Stromstad
Production: Derrick Stevens

FIND MORE:
March 2016 Microshow: https://www.thecurrent.org/feature/2017/03/13/jack-garratt-microshow
October 2016 studio session: https://www.thecurrent.org/feature/2016/10/22/jack-garratt-performs-in-the-current-studio

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

