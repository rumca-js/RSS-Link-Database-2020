# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## What Made DEAD SPACE A Big Deal?
 - [https://www.youtube.com/watch?v=Efean-w_PA8](https://www.youtube.com/watch?v=Efean-w_PA8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-06-13 00:00:00+00:00

Dead Space seemingly came out of nowhere and blew us all away with a unique blend of sci-fi and survival horror gameplay. Let's take a trip down memory lane.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## PS5 & XBOX SERIES X SIZE DIFFERENCE, RTX 3080 LEAKED, & MORE
 - [https://www.youtube.com/watch?v=gNWAEHIBlmw](https://www.youtube.com/watch?v=gNWAEHIBlmw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-06-12 00:00:00+00:00

Go to http://buyraycon.com/gameranx for 15% off your order! Brought to you buy Raycon.

The PS5 gets a full hardware reveal, along with tons of new games, new RTX cards have possibly leaked, Destiny gets a massive update, and more in a week full of gaming news!
Subscribe for more: https://www.youtube.com/gameranxTV?su...


 Weekly giveaway link: https://goo.gl/forms/a7zCtr1HuTkzWuOo2 

Youtube.com/JakeBaldino

 ~~~~STORIES~~~~

PS5 hardware revealed: https://youtu.be/YYlLlnea7q0
All of the new games announced: https://youtu.be/3sSr_2p7KpQ


PS5 size estimation
https://www.eurogamer.net/articles/2020-06-12-playstation-5-is-a-hefty-chonk-of-a-console#:~:text=With%20USBs%20and%20disc%20slots,the%20tallest%20of%20the%20crop.&text=(Alas%2C%20the%20original%20Xbox%20was,301mm%20x%20151mm%20x%20151mm.
https://old.reddit.com/r/XboxSeriesX/comments/h7cmty/updated_console_sizes_compared/
&
https://www.reddit.com/r/xboxone/comments/h78m2x/the_size_difference_between_the_series_x_and_the/

Design explained
https://www.denofgeek.com/games/playstation-5-design-explained-sony/

RTX 3080 leaked
https://www.techradar.com/news/nvidia-geforce-rtx-3080-leaked-pic-hints-at-a-gpu-with-the-mother-of-all-heatsinks

Star Wars Squadrons leaked: https://venturebeat.com/2020/06/12/star-wars-squadrons-tease/



Photo mode video:https://youtu.be/-Gq2S0AXjNw


**Check out Ama’s art:
https://twitter.com/AmAzingDrLama/status/1241348969491562500

Destiny: https://www.youtube.com/watch?v=5tJwLjVfFPc

More on games
https://www.reddit.com/r/pcgaming/comments/h79ffh/list_of_games_confirmed_to_be_also_released_on_pc/

## PS5: Official Console Design, Multiple Versions, Accessories, & MORE
 - [https://www.youtube.com/watch?v=YYlLlnea7q0](https://www.youtube.com/watch?v=YYlLlnea7q0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-06-12 00:00:00+00:00

The PlayStation 5 has officially been revealed. See the PS5 box console design, accessories, details, and more here.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## Top 15 NEW PS5 Games From Sony Event [4K Video]
 - [https://www.youtube.com/watch?v=3sSr_2p7KpQ](https://www.youtube.com/watch?v=3sSr_2p7KpQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-06-12 00:00:00+00:00

The PlayStation 5 event hit HARD and the hype train has left the station. Here are all of the new game announcements for the PS5, releasing holiday season and beyond.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

#15 Returnal [New IP]
Platform: PS5
Release: TBA 

#14 Spiderman Miles Morales 
Platform: PS5
Release: Holiday 2020

#13 Destruction All-Stars
Platform: PS5
Release: TBA 

#12 Ratchet Clank RIFT APART
Platform: PS5
Release: TBA 

#11 Project ATHIA [Square enix]
Platform: PS5
Release: TBA 

#10 Stray 
Platform: PS5
Release: 2021 


#9 KENA Bridge of Spirits
Platform: PS5
Release: TBA 

#8 Solar Ash
Platform: PS5
Release: 2021 

#7 Little Devil Inside
Platform: PS5
Release: TBA 

#6 Pragmata
Platform: PS5
Release: 2022 

#5 Hitman 3
Platform: PS5
Release: Jan 2021 

#4 Demon Souls [remake]
Platform: PS5
Release: TBA 

#3 Gran Turismo 7
Platform: PS5
Release: TBA 

#2 Resident Evil 8
Platform: PS5, Xbox Series X?, PC
Release: TBA 

#1 Horizon 2
Platform: PS5
Release: TBA 

BONUS
Sackboy A Big Adventure
Platform: PS5
Release: TBA 

JETT
Platform: PS5
Release: TBA 

NBA 2k21
Platform: PS5
Release: Fall 2020 

Bugsnax
Platform: PS5
Release: TBA 

GOODBYE VOLCANO HYPE
Platform: PS5
Release: TBA 

Oddworld SoulStorm
Platform: PS5
Release: TBA 

Astro's Playroom
Platform: PS5
Release: TBA

