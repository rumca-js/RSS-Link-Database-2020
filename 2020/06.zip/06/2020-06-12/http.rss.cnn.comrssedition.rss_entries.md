# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Black police officer: I feel torn between my race and my badge
 - [https://www.cnn.com/videos/us/2020/06/12/george-floyd-black-police-officers-galanos-pkg-mxp.hln](https://www.cnn.com/videos/us/2020/06/12/george-floyd-black-police-officers-galanos-pkg-mxp.hln)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 22:15:38+00:00



## America's military leaders move on from Trump on racial inequality
 - [https://www.cnn.com/collections/nascar-intl/](https://www.cnn.com/collections/nascar-intl/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 22:13:15+00:00



## Trainer fired for 'I Can't Breathe' workout
 - [https://www.cnn.com/2020/06/12/us/fitness-trainer-fired-i-cant-breathe-workout/index.html](https://www.cnn.com/2020/06/12/us/fitness-trainer-fired-i-cant-breathe-workout/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 22:03:04+00:00

A fitness trainer who worked for Anytime Fitness in Wauwatosa, Wisconsin, has been fired after promoting an "I Can't Breathe" workout, according to a statement from the franchise.

## The US military -- which Trump often uses to bolster himself as a commander in chief -- is moving on from the President on racial inequality
 - [https://www.cnn.com/2020/06/12/politics/military-leaders-race/index.html](https://www.cnn.com/2020/06/12/politics/military-leaders-race/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 21:53:30+00:00

Last Sunday, four-star Gen. Robert Abrams, who commands all US forces in South Korea, held a town hall with black service members on the subject of race that was then broadcast on Facebook to thousands.

## Face masks are best way to reduce coronavirus transmission, study finds
 - [https://www.cnn.com/2020/06/12/health/coronavirus-mask-wellness-trnd/index.html](https://www.cnn.com/2020/06/12/health/coronavirus-mask-wellness-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 21:20:10+00:00

The new coronavirus spreads mainly via airborne transmission and wearing a mask is the most effective way to stop person-to person spread, according to a new study.

## Trump provides more evidence of his racial myopia
 - [https://www.cnn.com/2020/06/12/politics/trump-tulsa-jacksonville-racism-history/index.html](https://www.cnn.com/2020/06/12/politics/trump-tulsa-jacksonville-racism-history/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 20:34:17+00:00

"We have to work together to confront bigotry and prejudice wherever they appear. But we'll make no progress and heal no wounds by falsely labeling tens of millions of decent Americans as racists or bigots. We have to get everybody together. We have to be on the same path."

## Woman caught on video harassing Filipino American woman exercising in park
 - [https://www.cnn.com/2020/06/12/us/torrance-woman-park-video/index.html](https://www.cnn.com/2020/06/12/us/torrance-woman-park-video/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 19:31:27+00:00

A woman was caught on video harassing a Filipino American woman as she exercised this week at a Southern California park, the latest in a string of racist incidents captured on video and widely shared on social media.

## Ford recalls 2 million vehicles because the doors could open while driving
 - [https://www.cnn.com/2020/06/12/business/ford-recall-faulty-door-latch/index.html](https://www.cnn.com/2020/06/12/business/ford-recall-faulty-door-latch/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 19:04:04+00:00

Ford is recalling more than 2 million vehicles in the US because the doors could open while the vehicle is being driven.

## I covered the Rodney King and Freddie Gray riots. This moment feels different. That's why I'm afraid
 - [https://www.cnn.com/2020/06/12/us/protests-rodney-king-freddie-gray-optimism-blake/index.html](https://www.cnn.com/2020/06/12/us/protests-rodney-king-freddie-gray-optimism-blake/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 18:51:39+00:00

The activist with the salt and pepper goatee who stood before me couldn't contain his euphoria.

## Woman launches racist rant in California park
 - [https://www.cnn.com/videos/us/2020/06/12/woman-harassing-filipino-american-woman-exercising-orig-mg-mb.cnn](https://www.cnn.com/videos/us/2020/06/12/woman-harassing-filipino-american-woman-exercising-orig-mg-mb.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 18:16:32+00:00

A Filipino American woman was exercising in a park in Torrance, California when another woman passing by unleashed a racist tirade.

## This lake just turned pink and experts don't know exactly why
 - [https://www.cnn.com/2020/06/11/asia/lake-lonar-pink-india-intl-hnk-scli/index.html](https://www.cnn.com/2020/06/11/asia/lake-lonar-pink-india-intl-hnk-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 17:23:19+00:00

What caused the lake to turn pink?

## Why Trump clings to the legacy of Confederate failure
 - [https://www.cnn.com/2020/06/12/politics/braxton-bragg-confederate-legacy/index.html](https://www.cnn.com/2020/06/12/politics/braxton-bragg-confederate-legacy/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 17:02:42+00:00

It's head-scratching, really, that the most prominent Army base in America is named for Braxton Bragg.

## Tabloid accused of glorifying domestic abuse after front-page interview with J.K. Rowling's ex-husband
 - [https://www.cnn.com/2020/06/12/uk/jk-rowling-the-sun-front-page-scli-gbr-intl/index.html](https://www.cnn.com/2020/06/12/uk/jk-rowling-the-sun-front-page-scli-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 16:48:26+00:00

Britain's biggest-selling tabloid newspaper, The Sun, has been accused of glorifying domestic violence, after it ran an interview with the ex-husband of author J.K. Rowling on its front page under the headline: "I slapped JK and I'm not sorry."

## US soccer star slams Trump: 'You're supposed to help ... not throw oil onto the fire'
 - [https://www.cnn.com/collections/trump-reax-intl-061220/](https://www.cnn.com/collections/trump-reax-intl-061220/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 16:48:03+00:00



## Starbucks reverses stance on Black Lives Matter apparel
 - [https://www.cnn.com/videos/business/2020/06/12/starbucks-black-lives-matter-tshirt-reversal-vpx.cnn](https://www.cnn.com/videos/business/2020/06/12/starbucks-black-lives-matter-tshirt-reversal-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 16:47:40+00:00

Starbucks has reversed its prohibition on employees wearing Black Lives Matter apparel. CNN's Cristina Alesci explains why.

## If he loses, the next Donald Trump could be ... Donald Trump
 - [https://www.cnn.com/collections/2020-election-intl-061220/](https://www.cnn.com/collections/2020-election-intl-061220/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 16:42:13+00:00



## Poland invaded the Czech Republic last month, but says it was just a big misunderstanding
 - [https://www.cnn.com/2020/06/12/europe/poland-czech-republic-invasion-scli-intl/index.html](https://www.cnn.com/2020/06/12/europe/poland-czech-republic-invasion-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 16:40:32+00:00

The Polish military has admitted it accidentally invaded the Czech Republic last month, but it insists its brief occupation of a small part of the country was simply a "misunderstanding."

## Justice Department to release less-redacted version of the Mueller Report
 - [https://www.cnn.com/2020/06/12/politics/justice-department-mueller-report/index.html](https://www.cnn.com/2020/06/12/politics/justice-department-mueller-report/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 15:32:55+00:00

The Justice Department says it will release a less-redacted version of the Mueller Report no later than next Friday, after being pressed for it in court.

## See how these adorable giant anteaters made their zoo debut
 - [https://www.cnn.com/videos/travel/2020/06/12/giant-anteater-twins-china-lon-orig-eg-tp.cnn](https://www.cnn.com/videos/travel/2020/06/12/giant-anteater-twins-china-lon-orig-eg-tp.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 15:32:44+00:00

The first artificially bred, giant anteater twins in Asia have made their public debut at Chimelong Safari Park in China.

## John Bolton's book to be published later this month despite White House objections
 - [https://www.cnn.com/2020/06/12/politics/bolton-book-publishing-june/index.html](https://www.cnn.com/2020/06/12/politics/bolton-book-publishing-june/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 15:32:21+00:00

President Donald Trump's former national security adviser John Bolton will publish his long-awaited memoir later this month over objections of the White House, Bolton's publisher said Friday.

## Black man pardoned '100 years overdue' in rape case that led to lynchings
 - [https://www.cnn.com/2020/06/12/us/max-mason-posthumous-pardon-minnesota/index.html](https://www.cnn.com/2020/06/12/us/max-mason-posthumous-pardon-minnesota/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 15:31:47+00:00

The Minnesota Board of Pardons posthumously pardoned Max Mason by unanimous vote Friday, 100 years after he was accused in a rape case that led to three other black men being lynched.

## New Melania book says she renegotiated her prenuptial agreement
 - [https://www.cnn.com/2020/06/12/politics/melania-trump-prenuptial-agreement/index.html](https://www.cnn.com/2020/06/12/politics/melania-trump-prenuptial-agreement/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 15:12:46+00:00

Part of the reason first lady Melania Trump delayed her move from New York City to the White House in 2017 was because she was renegotiating her prenuptial agreement with President Donald Trump, according to a book out next week by a Washington Post reporter.

## Elon Musk's tunnel project hit a milestone. But the future is unclear.
 - [https://www.cnn.com/2020/06/12/business/vegas-musk-boring-company/index.html](https://www.cnn.com/2020/06/12/business/vegas-musk-boring-company/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 15:08:57+00:00

Three years ago, Elon Musk pitched a grandiose vision for the future of intracity vehicle travel: layers of tunnels that would efficiently speed vehicles through cities. Drivers would maneuver their own Teslas to street-level elevators, which would lower them to be whisked away on autonomous electric sleds at speeds up to 120 mph. Pedestrians and cyclists would ride in an autonomous electric vehicle that resembled a glass-plated train car.

## Archaeologist gets jail sentence for faking his finds
 - [https://www.cnn.com/2020/06/12/europe/spain-archeologist-sentenced-intl-scli/index.html](https://www.cnn.com/2020/06/12/europe/spain-archeologist-sentenced-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 15:01:41+00:00

A Spanish archaeologist has been sentenced to more than two years in prison and fined €12,490 (over $14,000) for forging some of his most famous findings.

## White House didn't get heads up about top general's apology
 - [https://www.cnn.com/2020/06/11/politics/white-house-milley-apology/index.html](https://www.cnn.com/2020/06/11/politics/white-house-milley-apology/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 14:16:45+00:00

Chairman of the Joint Chiefs Gen. Mark Milley did not give the White House a heads up before he released a recorded video on Thursday admitting it was a "mistake" to appear in a photo-op last week with President Donald Trump, three administration officials told CNN.

## Listen to these artists for Black Music Month
 - [https://www.cnn.com/2020/06/12/entertainment/black-music-month-artists/index.html](https://www.cnn.com/2020/06/12/entertainment/black-music-month-artists/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 14:11:48+00:00

June is Black Music Month and with all that's happening in our culture, the timing feels particularly strong.

## 'Jaws,' the ultimate summer movie, meets the age of coronavirus
 - [https://www.cnn.com/2020/06/12/entertainment/jaws-and-coronavirus-column/index.html](https://www.cnn.com/2020/06/12/entertainment/jaws-and-coronavirus-column/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 13:53:18+00:00

Remember the mayor in "Jaws," coaxing that family to go in the water, before they grab their raft and tentatively wade into the ocean? That image -- introduced 45 years ago this month -- keeps coming to mind as entertainment options, including movie theaters, gradually reopen in the age of coronavirus.

## A wild, pro-Trump conspiracy theory group is about to get its first congresswoman
 - [https://www.cnn.com/2020/06/12/politics/qanon-marjorie-taylor-greene-georgia/index.html](https://www.cnn.com/2020/06/12/politics/qanon-marjorie-taylor-greene-georgia/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 13:38:00+00:00

The Republican primary in Georgia's 14th district on Tuesday didn't draw much national attention. After all, it's an overwhelmingly Republican district that GOP Rep. Tom Graves had held easily for a decade in Congress before announcing his retirement last year.

## Don Lemon reacts to comedian calling him out in Netflix special
 - [https://www.cnn.com/videos/entertainment/2020/06/12/dave-chappelle-don-lemon-reaction-new-day-vpx.cnn](https://www.cnn.com/videos/entertainment/2020/06/12/dave-chappelle-don-lemon-reaction-new-day-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 13:13:53+00:00

CNN's Don Lemon reacts to Dave Chappelle mentioning him in his Netflix special after Lemon called for celebrities to use their platforms to speak out about the death of George Floyd.

## State of emergency declared on rape and gender violence in Nigeria
 - [https://www.cnn.com/2020/06/12/africa/nigeria-state-of-emergency-rape/index.html](https://www.cnn.com/2020/06/12/africa/nigeria-state-of-emergency-rape/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 12:36:09+00:00

State governors in Nigeria have declared a state of emergency on rape following a spate of sexual violence against young women in the nation.

## Astronomers witness the steadfast beating heart of a black hole
 - [https://www.cnn.com/2020/06/12/world/black-hole-beating-heart-scn/index.html](https://www.cnn.com/2020/06/12/world/black-hole-beating-heart-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 12:16:03+00:00

About 600 million light-years away from Earth, the heartbeat of a supermassive black hole can be seen emanating from the center of a galaxy.

## Sedentary lockdowns put kids at risk for obesity. Here's how to help them stay moving
 - [https://www.cnn.com/2020/06/12/health/pandemic-obesity-kids-wellness/index.html](https://www.cnn.com/2020/06/12/health/pandemic-obesity-kids-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 12:08:17+00:00

Canceled soccer practices. Shuttered dance rehearsals.

## Luxury quarantining: Inside the Wyoming resort renting for $175,000 a week
 - [https://www.cnn.com/travel/article/luxury-wyoming-ranch-buyout/index.html](https://www.cnn.com/travel/article/luxury-wyoming-ranch-buyout/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 11:51:52+00:00

Wyoming, with a population density of six people per square mile, may never have been more appealing as a vacation destination as it is now.

## US soccer star slams Trump: 'You're supposed to help ... not throw oil onto the fire'
 - [https://www.cnn.com/2020/06/12/football/weston-mckennie-racism-george-floyd-donald-trump-schalke-bundesliga-spt-intl/index.html](https://www.cnn.com/2020/06/12/football/weston-mckennie-racism-george-floyd-donald-trump-schalke-bundesliga-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 11:42:10+00:00

U.S. Men's National Team midfielder Weston McKennie says he doesn't think President Donald Trump is "... the right president for this time" to address what has unfolded in the wake George Floyd's death.

## Quarantined cruise ship employee creates incredible outfits out of paper bags
 - [https://www.cnn.com/travel/article/cruise-ship-performer-makes-paper-bag-outfits/index.html](https://www.cnn.com/travel/article/cruise-ship-performer-makes-paper-bag-outfits/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 11:25:35+00:00

Australian dancer Ashleigh Perrie was thrilled to start working on board the MS Zaandam. The cruise ship was due to travel through Antarctica -- past penguins and sea lions -- and onward to South America, while Perrie spent her days doing what she loved: performing.

## Stunning images show how virus is overrunning hospitals
 - [https://www.cnn.com/videos/world/2020/06/11/rio-de-janeiro-coronavirus-healthcare-workers-npw-pkg-vpx.cnn](https://www.cnn.com/videos/world/2020/06/11/rio-de-janeiro-coronavirus-healthcare-workers-npw-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 11:11:05+00:00

CNN's Nick Paton Walsh reports from Rio de Janeiro where coronavirus is overwhelming the hospitals and healthcare workers as Brazil nears the peak of its curve.

## Officer charged with killing Floyd still eligible for pension worth more than $1M
 - [https://www.cnn.com/2020/06/12/us/chauvin-minneapolis-police-pension-invs/index.html](https://www.cnn.com/2020/06/12/us/chauvin-minneapolis-police-pension-invs/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 11:11:00+00:00

Former Minneapolis police officer Derek Chauvin could receive more than $1 million in pension benefits during his retirement years even if he is convicted of killing George Floyd.

## He spent over $1M on drugs before getting sober. Today, DJ Fat Tony still provides the soundtrack to London's party scene
 - [https://www.cnn.com/style/article/dj-fat-tony-interview/index.html](https://www.cnn.com/style/article/dj-fat-tony-interview/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 10:37:09+00:00

One of the last parties that DJ Fat Tony played was Brooklyn Beckham's 21st birthday, held in a giant glass marquee at David and Victoria Beckham's family home in the English countryside. After that, he performed at legendary London venue Ministry of Sound. Then, the city went into lockdown.

## Prime Minister apologizes for saying there was 'no slavery' in Australia
 - [https://www.cnn.com/2020/06/12/australia/australia-slavery-scott-morrison-intl-hnk/index.html](https://www.cnn.com/2020/06/12/australia/australia-slavery-scott-morrison-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 08:15:38+00:00

Prime Minister Scott Morrison has apologized for saying earlier this week that there was "no slavery" in Australia, after his comments provoked outrage and accusations that he was ignoring the country's history of forced labor.

## Airport offers 'pretend to go abroad' airport tours amid pandemic
 - [https://www.cnn.com/travel/article/taipei-songshan-airport-coronavirus-intl-hnk/index.html](https://www.cnn.com/travel/article/taipei-songshan-airport-coronavirus-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 07:06:55+00:00

With planes grounded and most tourism on hold during the coronavirus pandemic, one Taiwanese airport has come up with a unique solution to help citizens get their travel fix.

## NBA player reveals he was sexually abused at a young age
 - [https://www.cnn.com/2020/06/12/sport/lonnie-walker-spurs-sexual-abuse/index.html](https://www.cnn.com/2020/06/12/sport/lonnie-walker-spurs-sexual-abuse/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 06:30:21+00:00

Lonnie Walker IV of the San Antonio Spurs had been growing out his hair since the 5th grade until he recently got it cut. But that haircut comes with a sad, shocking back story.

## Remember when the Beckhams went everywhere in matching outfits?
 - [https://www.cnn.com/style/article/beckhams-fashion-matching-outfits/index.html](https://www.cnn.com/style/article/beckhams-fashion-matching-outfits/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 06:20:41+00:00

London's first digital fashion week kicks off today, offering an ideal opportunity to reflect on where British fashion is going -- and how far it has come.

## Death of black female essential worker at center of British BLM movement
 - [https://www.cnn.com/videos/world/2020/06/12/uk-black-lives-matter-belly-mujinga-abdelaziz-pkg-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2020/06/12/uk-black-lives-matter-belly-mujinga-abdelaziz-pkg-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 04:49:35+00:00

Protesters across the UK are chanting for George Floyd as well Belly Mujinga, a black essential worker who died of Covid-19. Galvanized by the Black Lives Matter movement, her case has prompted more people in the UK to call for social justice. CNN's Salma Abdelaziz reports.

## Cuomo: Proof of systemic racism is in Trump's cabinet
 - [https://www.cnn.com/videos/politics/2020/06/12/closing-argument-systemic-racism-us-economy-kudlow-cpt-vpx.cnn](https://www.cnn.com/videos/politics/2020/06/12/closing-argument-systemic-racism-us-economy-kudlow-cpt-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 03:51:54+00:00

Director of the United States National Economic Council, Larry Kudlow denied the existence of systemic racism in the US when asked by a reporter. CNN's Chris Cuomo uses data to prove Kudlow wrong.

## White celebrities take part in antiracism PSA; fans react
 - [https://www.cnn.com/videos/entertainment/2020/06/12/celebrity-anti-racism-psa-orig-mss.cnn](https://www.cnn.com/videos/entertainment/2020/06/12/celebrity-anti-racism-psa-orig-mss.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 01:15:22+00:00

A group of white celebrities participated in a PSA vowing to "Take Responsibility" against racism. The video got mixed reactions on social media.

## She wasn't invited to Trump's meeting in her city. Hear what she has to say about it
 - [https://www.cnn.com/videos/politics/2020/06/11/trump-dallas-sheriff-marian-brown-ebof-sot-vpx.cnn](https://www.cnn.com/videos/politics/2020/06/11/trump-dallas-sheriff-marian-brown-ebof-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-06-12 00:05:34+00:00

CNN's Erin Burnett speaks with Dallas County Sheriff Marian Brown. Brown was one of three key black law enforcement officials in the Dallas area who was not invited to attend an event with President Donald Trump that was promoted as discussing "justice disparities."

