# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## A Cop's Perspective on Defunding the Police
 - [https://www.youtube.com/watch?v=XnljiMOAniM](https://www.youtube.com/watch?v=XnljiMOAniM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-06-13 00:00:00+00:00

Detective Dan of Small Town Dicks joins Kyle and Ethan to talk about all the police issues facing the nation. 

Dan was formerly a K9 handler and Violent Crimes detective at the same Small Town police department as his twin brother Dave, who also hosts the podcast with Yeardlley Smith of the Simpsons. 

Dan regards his years as a K9 handler to be the most rewarding of his career. He is now retired. They discuss misconceptions about the police and discuss changes we need to make to serve and protect everyone.

FULL ▶️ https://babylonbee.com/news/podcast-not-all-cops

## CNN: 'Death Star Destroys Alderaan In Mostly Peaceful Demonstration'
 - [https://www.youtube.com/watch?v=-XGO5ymfF6E](https://www.youtube.com/watch?v=-XGO5ymfF6E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-06-13 00:00:00+00:00

"The demonstration of the superweapon was mostly calm, mostly peaceful," said a CNN reporter on a deck of the Death Star as millions of voices cried out in terror and were suddenly silenced. "Everyone on the bridge here was very orderly. Only a couple of people have been Force-choked. Most are fine."

Full Story: https://babylonbee.com/news/cnn-death-star-blows-up-alderaan-in-mostly-peaceful-demonstration

## Podcast: Not All Cops
 - [https://www.youtube.com/watch?v=D9-wWz7FTMA](https://www.youtube.com/watch?v=D9-wWz7FTMA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-06-12 00:00:00+00:00

Today on The Babylon Bee Podcast, @Kyle and Ethan talk about the biggest stories of the week like how religious gathers and pretending to be protests so they can meet, our recent feud over putting Trump in an AWANA vest, and how all of a sudden defunding the police became a national talking point. Detective Dan from Small Town Dicks joins Kyle and Ethan to talk all about it.

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Gain Access to the Exclusive Content and Writing Forum: https://babylonbee.com/plans

The Official Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

