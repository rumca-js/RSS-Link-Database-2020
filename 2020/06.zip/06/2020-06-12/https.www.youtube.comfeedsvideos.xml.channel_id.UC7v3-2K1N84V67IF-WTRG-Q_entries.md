# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Da 5 Bloods - Movie Review
 - [https://www.youtube.com/watch?v=dKFSGSBplQE](https://www.youtube.com/watch?v=dKFSGSBplQE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-06-13 00:00:00+00:00

Spike Lee brings us a new film about the bonds of friendship, and the destructive nature of hate. Here's my review for DA 5 BLOODS!

