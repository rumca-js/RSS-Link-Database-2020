# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## PJ: Tiny Desk (Home) Concert
 - [https://www.youtube.com/watch?v=EdsmANgmegA](https://www.youtube.com/watch?v=EdsmANgmegA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2020-06-12 00:00:00+00:00

The Tiny Desk is working from home for the foreseeable future. Introducing NPR Music's Tiny Desk (home) concerts, bringing you performances from across the country and the world. It's the same spirit — stripped-down sets, an intimate setting — just a different space.



SET LIST
"Privately"
"Smoke"
"Element"

MUSICIANS
PJ: vocals; Drin Elliot: keys

CREDITS
Videographer: Logan Fields; Audio Engineer: Stanley Springer III; Producers: Bobby Carter, Sidney Madden; Audio Mastering Engineer: Josh Rogosin; Video Producers: Morgan Noelle Smith, Maia Stern; Executive Producer: Lauren Onkey; Senior VP, Programming: Anya Grundmann

