# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Samsung is putting ads on lock screens?
 - [https://www.youtube.com/watch?v=Etd1QXXVoqI](https://www.youtube.com/watch?v=Etd1QXXVoqI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2020-06-12 00:00:00+00:00

- Samsung putting ads into OneUI?
- Apple replacing Intel Chips with A series chips on Macs
- Light leaves phones behind 

Tech quiz (updated): https://www.crrowd.com/quiz

[[[ TECHALTAR LINKS ]]]: 

Merch: 
http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 

If you want to support TechAltar directly:
https://flattr.com/@techaltar

My video gear: 
https://kit.co/TechAltar/video-gear

