# Source:PostmodernJukebox, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg, language:en-US

## PMJ Pop-Up: Sweet Child O' Mine - Guns N' Roses (Cover) ft. Miche Braden
 - [https://www.youtube.com/watch?v=B9CAHT3glTg](https://www.youtube.com/watch?v=B9CAHT3glTg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg
 - date published: 2020-06-12 00:00:00+00:00

Download & Stream Here: https://smarturl.it/pmjtwerk?IQid=yt
Watch without Pop-ups: https://www.youtube.com/watch?v=kJ3BAF_15yQ
Experience PMJ Live: https://pmjlive.com?IQid=yt
Shop PMJ Music/Merch: https://smarturl.it/pmjshop?IQid=yt
Spotify: https://smarturl.it/pmjcomplete?IQid=yt

What if PMJ videos were shown on VH1 in the '90s?? Here's the first "PMJ Pop-Up," featuring our New Orleans blues style cover of Guns N' Roses' "Sweet Child O' Mine," starring the great Miche Braden.  Which PMJ classic should we "Pop-up" next?

FOLLOW THE MUSICIANS:
Miche Braden (Vocals): 
YouTube: https://www.youtube.com/channel/UC6iM5q7TSif9juS0pL9TaHQ
Facebook: https://facebook.com/MsMicheDiva/
Twitter: https://twitter.com/msmichediva

Jason Prover (Trumpet): http://jasonprovermusic.com/
Robert Edward (Trombone): https://robertedwardsmusic.net
Adam Kubota (Bass): https://instagram.com/adamkubota_bass/
Allan Mednard (Drums): https://facebook.com/AllanMednard/
Tom Abbott (Clarinet)

Scott Bradlee (Piano & arrangement):
YouTube: http://youtube.com/scottbradlee
Facebook: http://facebook.com/scottbradleemusic
Instagram: http://instagram.com/scottbradlee
Twitter: http://twitter.com/scottbradlee
Book: http://smarturl.it/outsidethejukebox

#GunsNRoses #SweetChildOMine #PopUp #Cover

