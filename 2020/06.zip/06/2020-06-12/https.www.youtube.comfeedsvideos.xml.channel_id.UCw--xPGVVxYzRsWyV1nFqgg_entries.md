# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## ROYAL ASSASSIN - REVIEW
 - [https://www.youtube.com/watch?v=kwhbUA2v1ZA](https://www.youtube.com/watch?v=kwhbUA2v1ZA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-06-13 00:00:00+00:00

My review of Robin Hobb's Royal Assassin. The follow up to Assassin's Apprentice. The Second book in the Farseer trilogy. Let me know what you think of Royal Assassin and the review! 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## American Education & Black Lives Matter
 - [https://www.youtube.com/watch?v=7PjBXHe6KLs](https://www.youtube.com/watch?v=7PjBXHe6KLs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-06-12 00:00:00+00:00

If you cannot be bothered to read something outside your circle, at least give this speach a listen: https://www.youtube.com/watch?v=NUBh9GqFU3A

## D&D Meme REVIEW!
 - [https://www.youtube.com/watch?v=cmEaEzuXgzo](https://www.youtube.com/watch?v=cmEaEzuXgzo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-06-12 00:00:00+00:00

I wasn't too sure about this, but I had fun as it went along. Let's review dungeon and dragon memes! 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

