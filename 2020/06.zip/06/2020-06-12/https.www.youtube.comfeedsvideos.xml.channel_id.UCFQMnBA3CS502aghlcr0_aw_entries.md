# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Big Pyramid Has Bought Our Politicians
 - [https://www.youtube.com/watch?v=zb3BIfqCGTA](https://www.youtube.com/watch?v=zb3BIfqCGTA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-06-13 00:00:00+00:00

Basically watergate but with big pyramids. 

Multi-Level Marketing, corrupt politics and more. 

Robert Fitzpatrick’s great paper on Pyramid Politics
https://pyramidschemealert.org/wp-content/uploads/2017/12/Pyramid-Politics.pdf

Jon Taylor on the math of pyramid schemes. 
https://www.ftc.gov/sites/default/files/documents/public_comments/trade-regulation-rule-disclosure-requirements-and-prohibitions-concerning-business-opportunities-ftc.r511993-00017%C2%A0/00017-57317.pdf

## James Corden’s Parody of “Start-Up” Scams Actually Came True
 - [https://www.youtube.com/watch?v=UkEHHSdSV9Q](https://www.youtube.com/watch?v=UkEHHSdSV9Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-06-12 00:00:00+00:00

Silicon Valley is beyond parody sometimes. 

To be clear, the idea itself of microbiomes being important is still probably a valuable area of research. The main problem seems to be that uBiome was gathering far too LITTLE data. So I'm not saying this is a terrible idea perse... more that it was horribly executed by the deadly combination of silicon valley hubris and hype.

