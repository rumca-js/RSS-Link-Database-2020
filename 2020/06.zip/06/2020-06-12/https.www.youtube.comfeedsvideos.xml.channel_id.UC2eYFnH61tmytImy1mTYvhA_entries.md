# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## Regular Expressions (Regex): All the Basics
 - [https://www.youtube.com/watch?v=77I4ZkhuHsQ](https://www.youtube.com/watch?v=77I4ZkhuHsQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-06-13 00:00:00+00:00

I go over how to get a lot out of just the fundamentals of regular expressions (regexes). We cover all the basics, but there is an even bigger world out there of possibilities I might cover in coming videos.

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE: https://lukesmith.xyz/donate 💰😎👌💯
OR affiliate links to things l use:
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://brave.com/luk005 Get the Brave browser.
https://lbry.tv/$/invite/@Luke View my videos on LBRY.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase.

## A Custom, Private Search Engine in 10 minutes
 - [https://www.youtube.com/watch?v=oufXi3e-VuA](https://www.youtube.com/watch?v=oufXi3e-VuA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-06-12 00:00:00+00:00

Why whine about Google or meme alternative search engines when you can just make your own with Searx? (https://searx.me). If you don't even trust public instances of Searx (https://searx.space/) you can install it on your own webserver in less than 10 minutes. I use a Debian server running nginx in this video, but it should work on other distros like Ubuntu and on Apache servers as well. You can also customize search settings and do whatever you want.

This is the power of Free/Libre Software!

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE: https://lukesmith.xyz/donate 💰😎👌💯
OR affiliate links to things l use:
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://brave.com/luk005 Get the Brave browser.
https://lbry.tv/$/invite/@Luke View my videos on LBRY.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase.

