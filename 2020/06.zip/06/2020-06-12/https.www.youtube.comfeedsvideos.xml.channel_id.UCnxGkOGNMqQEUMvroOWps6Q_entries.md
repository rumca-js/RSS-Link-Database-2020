# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Bill Burr Gets Introspective About the Origins of His Anger
 - [https://www.youtube.com/watch?v=wznrh9XqIc8](https://www.youtube.com/watch?v=wznrh9XqIc8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-12 00:00:00+00:00

Taken from JRE #1491 w/Bill Burr: https://youtu.be/GO_rW0Bvy1I

## Bill Burr Had a Run-in With a Creepy Yoga Instructor
 - [https://www.youtube.com/watch?v=SUM4KAunTng](https://www.youtube.com/watch?v=SUM4KAunTng)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-12 00:00:00+00:00

Taken from JRE #1491 w/Bill Burr: https://youtu.be/GO_rW0Bvy1I

## Bill Burr on Coronavirus Quarantine, Rants About Mask Wearing
 - [https://www.youtube.com/watch?v=tSKVXl-WnrA](https://www.youtube.com/watch?v=tSKVXl-WnrA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-12 00:00:00+00:00

Taken from JRE #1491 w/Bill Burr:
https://youtu.be/GO_rW0Bvy1I

## Bill Burr on Joe's Spotify Deal, Hollywood Accounting
 - [https://www.youtube.com/watch?v=eGsB7hE_cFo](https://www.youtube.com/watch?v=eGsB7hE_cFo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-12 00:00:00+00:00

Taken from JRE #1491 w/Bill Burr: 
https://youtu.be/GO_rW0Bvy1I

## Joe Rogan & Bill Burr Watch Crazy Bear Videos
 - [https://www.youtube.com/watch?v=tVlKT6YSLRM](https://www.youtube.com/watch?v=tVlKT6YSLRM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-12 00:00:00+00:00

Taken from JRE #1491 w/Bill Burr:
https://youtu.be/GO_rW0Bvy1I

## Joe Rogan Talks Antifa Taking Over 6 Blocks of Seattle w/Bill Burr
 - [https://www.youtube.com/watch?v=DcrMey3XVk4](https://www.youtube.com/watch?v=DcrMey3XVk4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-12 00:00:00+00:00

Taken from JRE #1491 w/Bill Burr:
https://youtu.be/GO_rW0Bvy1I

## Rogan & Burr Tell Old Boston Fight Stories
 - [https://www.youtube.com/watch?v=C4xq0iELalk](https://www.youtube.com/watch?v=C4xq0iELalk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-12 00:00:00+00:00

Taken from JRE #1491 w/Bill Burr:
https://youtu.be/GO_rW0Bvy1I

## Rogan & Burr on News Media, Minneapolis, George Floyd Protests, Defunding the Police
 - [https://www.youtube.com/watch?v=UdKrsk3tet4](https://www.youtube.com/watch?v=UdKrsk3tet4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-06-12 00:00:00+00:00

Taken from JRE #1491 w/Bill Burr:
https://youtu.be/GO_rW0Bvy1I

