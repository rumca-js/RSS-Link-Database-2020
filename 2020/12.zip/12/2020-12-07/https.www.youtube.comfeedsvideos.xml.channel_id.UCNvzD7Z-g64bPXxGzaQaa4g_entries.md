# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## How Scalpers Are RUINING The Series X/PS5 Launch
 - [https://www.youtube.com/watch?v=M3ALcHxv8MY](https://www.youtube.com/watch?v=M3ALcHxv8MY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-12-07 00:00:00+00:00

PS5 and Series X are hot new consoles for the holiday season, and scalpers are making it much worse. With limited inventory and rising prices, can anything be done?
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

