# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Bill Burr's Take on Phone Addiction
 - [https://www.youtube.com/watch?v=oK2nFL_mvZU](https://www.youtube.com/watch?v=oK2nFL_mvZU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2020-12-08 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1575 with Bill Burr. https://open.spotify.com/episode/2RYuGMhdQCk6FFoFJzKUR1?si=A96K_G2ZRJmQLqNq4PQUgA

## Rogan & Burr Discuss the Legendary Steve Martin
 - [https://www.youtube.com/watch?v=RWqGnRfAQU4](https://www.youtube.com/watch?v=RWqGnRfAQU4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2020-12-08 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1575 with Bill Burr. https://open.spotify.com/episode/2RYuGMhdQCk6FFoFJzKUR1?si=A96K_G2ZRJmQLqNq4PQUgA

## What Bill Burr Has Learned from Death Bed Stories
 - [https://www.youtube.com/watch?v=lj5p8oFWtnU](https://www.youtube.com/watch?v=lj5p8oFWtnU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2020-12-08 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1575 with Bill Burr. https://open.spotify.com/episode/2RYuGMhdQCk6FFoFJzKUR1?si=A96K_G2ZRJmQLqNq4PQUgA

