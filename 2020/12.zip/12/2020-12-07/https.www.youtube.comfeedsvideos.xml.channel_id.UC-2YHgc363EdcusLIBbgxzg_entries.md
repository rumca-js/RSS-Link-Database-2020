# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## Could This Plane Save The World? (Hint: No.) | Answers With Joe
 - [https://www.youtube.com/watch?v=v1u0OQc6QwI](https://www.youtube.com/watch?v=v1u0OQc6QwI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2020-12-07 00:00:00+00:00

I've gotten a slew of requests for a video about the Celera 500L from Otto Aviation, a plane that uses a unique design to create laminar flow over the surface, resulting in incredible efficiency. The hype around this plane is through the roof, with many saying it could disrupt the airline industry. While I think it's a really cool plane, I am skeptical of the biggest claims around it, so here's my hot take.

And yes, I know, the price I listed for the 747 was very low. It's actually the avg cost of a used plane, which I got from here: https://www.aircraftcostcalculator.com/AircraftOperatingCosts/380/Boeing+747-400

Check out more links down below.

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:
Mentour Pilot's video: https://www.youtube.com/watch?v=CN4EKZHYVaE 

Smarter Every Day on laminar flow: https://www.youtube.com/watch?v=y7Hyc3MRKno

https://www.forbes.com/sites/erictegler/2020/09/03/otto-aviation-hopes-to-torpedo-the-business-jet-market-with-its-curious-new-design-will-it-sink-or-swim/?sh=3c1abd9ebcca

https://www.forbes.com/sites/quora/2017/05/05/how-much-does-it-cost-per-hour-to-fly-a-747
https://interestingengineering.com/the-celera-500l-can-potentially-shake-up-the-private-aviation-industry

https://epicflightacademy.com/airline-pilot-salary/

https://www.businessinsider.com/how-much-flight-attendants-make-in-major-airlines-2019-5

