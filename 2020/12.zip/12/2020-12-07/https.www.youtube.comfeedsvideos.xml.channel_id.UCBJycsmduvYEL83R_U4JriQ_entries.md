# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## The Portless iPhone: Let's Talk!
 - [https://www.youtube.com/watch?v=Qfmeb2e_kb4](https://www.youtube.com/watch?v=Qfmeb2e_kb4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-12-07 00:00:00+00:00

An iPhone with no ports. We all seem to have accepted it already... but why?
The WVFRM podcast: http://bit.ly/WaveformMKBHD
That shirt: https://bit.ly/2JN2frg

Mark Gurman: https://twitter.com/markgurman

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: On and On Part 2 by Hocus Pocus
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

