# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## If Men Acted Like Pregnant Women
 - [https://www.youtube.com/watch?v=Z1nzvRJKu3Q](https://www.youtube.com/watch?v=Z1nzvRJKu3Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-12-08 00:00:00+00:00

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Grab your LMNT Electrolytes Here - https://drinklmnt.com/jp

What if men acted like pregnant women? With all the emotional swings, meltdowns, and non-consensual baby talk, here’s what their pregnancy would be like.

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

