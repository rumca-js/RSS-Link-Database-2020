# Source:SciFun, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCWTA5Yd0rAkQt5-9etIFoBA, language:pl-PL

## Spadek w Próżni
 - [https://www.youtube.com/watch?v=9vJUkjGQC1g](https://www.youtube.com/watch?v=9vJUkjGQC1g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCWTA5Yd0rAkQt5-9etIFoBA
 - date published: 2020-12-07 00:00:00+00:00

Spadek z tłumieniem i spadek swobodny.
Kupuj prezenty z cashbackiem Letyshops - https://letyshops.app.link/xdX1g5mh1bb
Wtyczka Letyshops - https://bit.ly/39MKQcS
Letykod - SciFun

