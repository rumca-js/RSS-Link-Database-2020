# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Bridget Phetasy Interview: Wasteland of The Center
 - [https://www.youtube.com/watch?v=nziErnmPjwY](https://www.youtube.com/watch?v=nziErnmPjwY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-12-08 00:00:00+00:00

Today on The Babylon Bee Podcast, Kyle and Ethan talk to Bridget Phetasy. Bridget is a well known writer and podcaster. She has a monthly column on the Spectator website and has two Podcast shows: Dumpster Fire and Walk-Ins Welcome. Bridget gained notoriety for making both liberals and conservatives angry through her writing and now has gained an even greater audience making people angry on Twitter. You may even recognize her voiceover work on the Bee Animation, where she has voiced Samantha and many others.  Kyle and Ethan talk to Bridget about how Kanye West wrote a lyric about her, her struggle with addiction, and how she is stuck in the wasteland of being a centrist in a polarized political world. 

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Gain Access to the Exclusive Content and Writing Forum: https://babylonbee.com/plans

The Official Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

## Bridget Phetasy on the Babylon Bee Podcast | Preview
 - [https://www.youtube.com/watch?v=1On9XrGlTYU](https://www.youtube.com/watch?v=1On9XrGlTYU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-12-07 00:00:00+00:00

🎙 Tomorrow Bridget Phetasy joins Kyle and Ethan on The Babylon Bee podcast.

SUBSCRIBE TODAY! ▶️ http://bit.ly/TheBeeYouTube

## Christmas Songs That Make Us Want To Die
 - [https://www.youtube.com/watch?v=9SUXxEMIqeU](https://www.youtube.com/watch?v=9SUXxEMIqeU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-12-07 00:00:00+00:00

Babylon Bee writers Kyle and Ethan complain about Christmas music. From "Little Drummer Boy" to "The Christmas Shoes," retail shops and restaurants torture us with these songs every year. 

Tell us what your least favorite Christmas songs are in the comments!

See the full show here:
https://youtu.be/0Vs-Smu6NBs

Subscribe to the Babylon Bee to keep Chris Tomlin from destroying more Christmas music. 

Hit the bell to get your daily dose of fake news that you can trust.

