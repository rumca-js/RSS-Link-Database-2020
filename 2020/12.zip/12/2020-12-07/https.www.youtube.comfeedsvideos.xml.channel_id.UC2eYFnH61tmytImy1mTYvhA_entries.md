# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## I love classic ThinkPad Keyboards so much, I got another one! (Lenovo ThinkPad Travel Keyboard)
 - [https://www.youtube.com/watch?v=vhAJKW_bhH4](https://www.youtube.com/watch?v=vhAJKW_bhH4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-12-08 00:00:00+00:00

#soyface #consoomproduct

I was gifted a Lenovo ThinkPad travel keyboard which I've been enjoying a lot. Although they're somewhat harder to find nowadays, the build is of that classic ThinkPad caliber and it is extremely light and usable. With the TrackPoint, I can use this thing at the very long length of its cord and still have a keyboard and mouse.

It works out of the box on Linux, but the main issues were the lack of a Windows key (which is easily remapped in my case), but there were also some minor key roll-over problems. Altogether I still like it enough that I might just starting using it as a real-life regular keyboard on my desk.

My website: https://lukesmith.xyz
Please donate: https://lukesmith.xyz/donate

OR affiliate links to things l use:
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://brave.com/luk005 Get the Brave browser.
https://lbry.tv/$/invite/@Luke View my videos on LBRY. Get a bonus for joining.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase. We both get $10 in Bitcoin when you buy or sell $100 in cryptocurrencies.

## Why I don't do Phone Tutorials.......
 - [https://www.youtube.com/watch?v=RsJTxWJfPCY](https://www.youtube.com/watch?v=RsJTxWJfPCY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-12-07 00:00:00+00:00

Cell phones are on the next level of frustration in terms of configuring and really owning. Just being able to root a device, which is never default unless you buy a niche privacy phone often is a huge and painful rigmarole. The "community" of cell phone hackers isn't that helpful because most of them are concerned with making phones look cool rather than removing spyware and "empowering" users. Part of this is just the issues of manufacturers, designers and carriers of phones conspiring to keep phones locked down devices. All this makes using and doing videos on phones very difficult.

My website: https://lukesmith.xyz
Please donate: https://lukesmith.xyz/donate

OR affiliate links to things l use:
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://brave.com/luk005 Get the Brave browser.
https://lbry.tv/$/invite/@Luke View my videos on LBRY. Get a bonus for joining.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase. We both get $10 in Bitcoin when you buy or sell $100 in cryptocurrencies.

