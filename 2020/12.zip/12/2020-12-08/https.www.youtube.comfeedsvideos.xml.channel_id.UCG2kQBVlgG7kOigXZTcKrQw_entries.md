# Source:Kołem się toczy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw, language:pl-PL

## Perły Dolomitów. Tre Cime, Sorapis, Monte Piana i RZYM !
 - [https://www.youtube.com/watch?v=yL0bi193nZE](https://www.youtube.com/watch?v=yL0bi193nZE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw
 - date published: 2020-12-08 00:00:00+00:00

Zachęcam do subskrypcji!
Kurs 🎬 https://www.kursfilmowaniaimontazu.pl/
Opinie o kursie 🎬 https://kolemsietoczy.pl/opinie-o-kursie-filmowo-montazowym-karola-wernera/
Werner masakruje 🎬 https://kolemsietoczy.pl/werner-masakruje-czyli-oceniam-filmy-kursantow-wyzwaniefilmowe/

W drugim docinku z Dolomitów idziemy w kilka równie pięknych miejsc co ostatnio. Niemniej dziś będą znacznie prostsze, jednodniowe trasy. Pierwsza to wycieczka piesza na popularne Jezioro Sorapis (Lago di sorapis), a druga miała być nad kultowe Tre Cime, jednak po zobaczeniu tamtejszych tłumów... poszliśmy na sąsiednią, równie piękną górę Monte Piana.

Niemniej co tu dużo gadać  - zapraszamy na drugi i ostatni film z Dolomitów, a także na film z Rzymu autorstwa Grzegorza (tutaj jego kanał i film przedkursowy https://youtu.be/BlJVEUtSLWY)

Zapraszam też na:
Facebook: http://bit.ly/2flU84f
Instagram: http://bit.ly/2eTrIMc
Blog: http://kolemsietoczy.pl/

Spis Treści:

00:00 - 00:42 Dolomity. Gdzie iść na trekking?
00:43 - 04:00 Trasa do Jeziora Sorapis
04:01 - 04:26 Tre Cime di Lavaredo - nieudany trekking Trzy siostry
04:27 - 06:00 Trekking na Monte Piana
06:01 - 08:08 Walki o Monte Piana
08:09 - 12:38 Zwycięski film Wyzwania Filmowego

