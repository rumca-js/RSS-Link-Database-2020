# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Drinker's Christmas Crackers - Die Hard
 - [https://www.youtube.com/watch?v=TMI6xwM-WcA](https://www.youtube.com/watch?v=TMI6xwM-WcA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-12-08 00:00:00+00:00

Tis the season of drinking and movie watching. And with that in mind, its time to share some of my favourite Christmas movies of all time - starting with the all-time action movie classic Die Hard, starring Bruce Willis and Alan Rickman.

