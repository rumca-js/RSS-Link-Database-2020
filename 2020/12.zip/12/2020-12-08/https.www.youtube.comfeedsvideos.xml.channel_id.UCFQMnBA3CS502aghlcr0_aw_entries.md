# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Coffeezilla's $10,000,000 Studio Tour
 - [https://www.youtube.com/watch?v=2tN0AEWadU8](https://www.youtube.com/watch?v=2tN0AEWadU8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-12-08 00:00:00+00:00

I'm deep in debt now but it was worth it.
Ed's channel (stimulate the Ukrainian economy!): https://www.youtube.com/channel/UCbpjIfPcfm8GaHBWzW7pQTw
^^GO SUBSCRIBE^^

Thank you for getting me here guys. The next season is going to be better than ever. 

twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/

## Raging Bull SLAMMED With $137,000,000 Fraud Accusations
 - [https://www.youtube.com/watch?v=ZGz944Hdqyk](https://www.youtube.com/watch?v=ZGz944Hdqyk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-12-08 00:00:00+00:00

"Company offering pandemic stock tips accused of $137M fraud"
That company is Raging Bull, owned by Jason Bond and Jeff Bishop, let's peel back the layers on this huge $137,000,000 Fraud Accusation
AP article: https://apnews.com/article/pandemics-coronavirus-pandemic-financial-markets-courts-0e28c1c490ebf616264ab401f3c6ceb6
according to guruleaks, they also have a cease and desist against them in new hampshire https://twitter.com/Guruleaks1/status/1336105979159719936
https://www.law360.com/articles/1335222/attachments/0
twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/
this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

