# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## What The COVID Vaccine Does To Your Body
 - [https://www.youtube.com/watch?v=the81FQoAUI](https://www.youtube.com/watch?v=the81FQoAUI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2020-12-08 00:00:00+00:00

Is the coronavirus vaccine safe? Now that the first COVID19 vaccine from Pfizer is being released, how do mRNA vaccines work?
Are Vaccines Causing Magnetism? https://youtu.be/bVi-GlOY9iM
Watch this BRILLIANT live stream on vaccines with Dr. Alex Dainis: https://youtu.be/YP62jFlj41Y
Join our mailing list: https://bit.ly/34fWU27

There’s a lot of excitement right now around the record-speed vaccines for COVID19, some of which are already starting distribution in parts of the world. But given that these are mRNA vaccines - a relatively new technology that has not been widely used before - we wanted to explain how they work, and what happens in your body from the moment the needle touches your skin. 

Written by Gregory Brown and Mitchell Moffit
Editing by Luka Šarlija

FOLLOW US!
AsapSCIENCE
TikTok: @AsapSCIENCE 
Instagram: https://instagram.com/asapscience
Facebook: https://facebook.com/asapscience
Twitter: https://twitter.com/asapscience

Some Extra Resources:

https://www.cdc.gov/coronavirus/2019-ncov/vaccines/different-vaccines/mrna.html
https://www.nature.com/articles/nrd.2017.243
https://www.nature.com/articles/s41541-020-0159-8
https://www.nature.com/articles/d41573-020-00119-8
https://www.frontiersin.org/articles/10.3389/fimmu.2019.00594/full
https://www.phgfoundation.org/briefing/rna-vaccines
https://youtu.be/YP62jFlj41Y

