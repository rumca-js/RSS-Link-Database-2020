# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Mit megadawek witamin - początek
 - [https://www.youtube.com/watch?v=HItFOF7iSn8](https://www.youtube.com/watch?v=HItFOF7iSn8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2020-12-09 00:00:00+00:00

📚 Darmowa dostawa mojego "Przepisu na człowieka" pod tym linkiem
https://geny.altenberg.pl

Film o witaminie C
👉https://youtu.be/9CS4KYxpc4g

Film o długości życia
👉https://www.youtube.com/watch?v=CmRjx2pCS3Y

Patronite ► https://patronite.pl/NaukowyBelkot 
Mix audio ► http://ratstudios.pl/

Delikatnie szturcham temat, do którego zabieram się już od kilku lat w nadziei, że wyjdzie z tego ciekawa miniseria. Póki co - rys historyczny, czyli skąd ta popularność terapii megadawkami witamin się bierze. I tu mały spoiler: nazwisko, które odegrało w tym dużą rolę może niektórych zaskoczyć.

Subskrypcja ► https://youtube.com/c/UwagaNaukowyBelkot
Facebook ► https://facebook.com/UwagaNaukowyBelkot
Twitter ► https://twitter.com/NaukowyBelkot
Instagram ► https://www.instagram.com/NaukowyBelkot/

Wyłącznie Naukowy Bełkot ► https://goo.gl/Do7VCc
Grupa na facebooku ► https://goo.gl/HP8J83

===
0:00 Trochę parodii
3:31 Sylwetka wielkiego naukowca
8:22 Zaraz po odkryciu witamin
13:10 List
18:54 Nieoczekiwane dziedzictwo
21:04 Nie taki nieodosobniony przypadek

===
Źródła:

P. A. Offit - Pandora's Lab: Seven Stories of Science Gone Wrong
M. Shermer - Skepticism 101
[4]
[6]
[7]
[10]
https://pl.wikipedia.org/wiki/Linus_Pauling

===
Wykorzystane grafiki:
https://www.freepik.com/photos/background
Background photo created by sid4rtproduction - www.freepik.com
https://twitter.com/GersonInstitute/status/920715560895131653/photo/3
http://www.organiclifestylemagazine.com/issue/13-dr-max-gerson?utm_source=ReviveOldPost&utm_medium=social&utm_campaign=ReviveOldPost
https://www.alabamaheritage.com/issue-128-spring-2018.html
https://www.thecanadianencyclopedia.ca/en/article/psychedelic-research-in-1950s-saskatchewan
https://commons.wikimedia.org/wiki/File:William_Grigsby_McCormick.jpg
A ogólnie to zdjęcie z tej książki pochodzi: https://books.google.pl/books?id=QC83AAAAMAAJ&pg=PA308-IA4&redir_esc=y
https://www.findagrave.com/memorial/53142190/frederick-robert-klenner/photo#view-photo=176327328
https://www.thecanadianencyclopedia.ca/en/article/psychedelic-research-in-1950s-saskatchewan
https://www.drrogersprize.org/wp/wp-content/uploads/2007/11/2007-Dr.-Rogers-Prize-254.jpg
https://www.drrogersprize.org/video-2007-dr-rogers-prize-winner-dr-abram-hoffer/

