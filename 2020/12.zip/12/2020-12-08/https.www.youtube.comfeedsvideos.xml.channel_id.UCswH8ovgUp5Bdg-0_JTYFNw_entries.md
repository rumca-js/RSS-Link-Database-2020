# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## If You Want To Change The Way You Feel, Try This!
 - [https://www.youtube.com/watch?v=l_BcI2gkoxA](https://www.youtube.com/watch?v=l_BcI2gkoxA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-12-08 00:00:00+00:00

Did you enjoy this meditation? 

Here are some of the guidelines:

MUDRA

Raise hands to heart centre. Curl the fingers into a loose fist. 
Keep thumbs extended and pointed upwards. Top ends of thumbs touch. 
Knuckles not touching.

EYE POSITION

Fix the eyes on the knuckles of the thumbs and narrow the eyelids.

BREATH PATTERN

• Inhale through the nose slowly for 8 seconds.
• Hold in the breath for 8 seconds.
• Release the breath through the nose for 8 equal blasts.
• Hold the breath out for 8 seconds.

TIME

Start with 3-5 minutes of this practice, weekly.

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

