# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Dokładna data i założenia Wielkiego Resetu! Analiza oficjalnego diagramu!
 - [https://www.youtube.com/watch?v=IYZZ-yFvp2k](https://www.youtube.com/watch?v=IYZZ-yFvp2k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2020-12-09 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/2ETKSyN
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
---------------------------------------------------------------
✅źródła:
https://bit.ly/3qHmFCR
https://bit.ly/33WxFmb
https://bit.ly/3qsZ4Wk
https://bit.ly/2Lqfa3b
https://bit.ly/3gz8c7d
-------------------------------------------------------------
💡 Tagi: #DavosAgenda #Schwab
--------------------------------------------------------------

## NBP analizuje ryzyko eliminacji gotówki! Możliwe drugie dno!
 - [https://www.youtube.com/watch?v=guIj8Wzas-c](https://www.youtube.com/watch?v=guIj8Wzas-c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2020-12-09 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/2ETKSyN
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
---------------------------------------------------------------
🖼Grafika - wykorzystano elementy ze stron:
wikipedia / Piotr Małecki - Biuro Prasowe NBP / CC BY-SA 4.0
https://bit.ly/2BXmNcw
---
wikipedia / Andrzej Barabasz (Chepry) / CC BY-SA 3.0
https://bit.ly/3dR7AYE
---------------------------------------------------------------
✅źródła:
https://bit.ly/39ZNdtf
https://bit.ly/3qAygnj
https://bit.ly/3gsFmFN
https://bit.ly/3qGEsKs
-------------------------------------------------------------
💡 Tagi: #NBP #Glapiński
--------------------------------------------------------------

## Michał Dworczyk o wprowadzeniu paszportów zdrowotnych i kodach QR!
 - [https://www.youtube.com/watch?v=rBCAavaeAqo](https://www.youtube.com/watch?v=rBCAavaeAqo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2020-12-08 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/2ETKSyN
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
---------------------------------------------------------------
🖼Grafika - wykorzystano elementy ze stron: 
gov.pl / http://bit.ly/2lVWjQr
---
Department of Defense 
https://bit.ly/3grgFcO
---
G.Fuller / PA Wire 
https://bit.ly/37IAxUP
---------------------------------------------------------------
✅źródła:
https://bit.ly/3mPWSpE
https://bit.ly/3mTyQKo
https://bit.ly/3pnVvAp
https://bit.ly/37Ihxpj
https://bit.ly/2LcFQEm
https://bit.ly/39DaRLR
https://bit.ly/2L5cAza
https://bit.ly/3qwT4Mn
https://bit.ly/2IirPUo
https://bit.ly/3a3OcbV
-------------------------------------------------------------
💡 Tagi: #szczepionka #covid19
--------------------------------------------------------------

