# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## Inside the Lab That Invented the COVID-19 Vaccine
 - [https://www.youtube.com/watch?v=-92HQA0GcI8](https://www.youtube.com/watch?v=-92HQA0GcI8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2020-12-08 00:00:00+00:00

PBS Member Stations rely on viewers like you. To support your local station, go to: http://to.pbs.org/DonateOKAY
↓ More info and sources below ↓

We’re on PATREON! Join the community ►► https://www.patreon.com/itsokaytobesmart
SUBSCRIBE so you don’t miss a video! ►► http://bit.ly/iotbs_sub

Here we are, just a year after the first news of the coronavirus we now call SARS-CoV-2 and the global pandemic known as COVID-19… and scientists have already developed more than one safe & effective vaccine. How did they do that so quickly? I visited the lab whose work directly led to these first COVID vaccines, so you can learn how basic research connects to life-saving medicine. This is how to make a COVID-19 vaccine.

Coronavirus animation courtesy of: Janet Iwasa, University of Utah, with funding from the NSF, the Coronavirus Structural Task Force and the German Federal Ministery of Research

References: 
Wrapp, D. et al. Cryo-EM structure of the 2019-nCoV spike in the prefusion conformation. Science 367, 1260–1263 (2020) doi: 10.1126/science.abb2507

Watanabe, Y., Allen, J. D., Wrapp, D., McLellan, J. S. & Crispin, M. Site-specific glycan analysis of the SARS-CoV-2 spike. Science eabb9983 (2020) doi:10.1126/science.abb9983.

-----------

Special thanks to our Brain Trust Patrons:

AlecZero 
Amory Silva
Amy Sowada
Baerbel Winkler
Benjamin Teinby
Bob Rosset
Brent M.
Denzel Holmes
Diego Lombeida
Dustin
Eric Meer
George gladding
Karen Haskell
Marcus Tuepker
Oliver and Arden Bradshaw
Peter Ehrnstrom
Robert Young
Ron Kakar
Salih Arslan
Vincbis
Zenimal

Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/

