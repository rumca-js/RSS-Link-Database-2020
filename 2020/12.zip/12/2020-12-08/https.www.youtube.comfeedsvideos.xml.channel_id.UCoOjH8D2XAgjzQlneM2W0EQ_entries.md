# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## The Economics of the Russian Mafia (Mini Documentary)
 - [https://www.youtube.com/watch?v=A6Q72R1aYwA](https://www.youtube.com/watch?v=A6Q72R1aYwA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2020-12-09 00:00:00+00:00

Healthy cereal that tastes too good to be true: Get free shipping with code JAKETRAN at https://magicspoon.com/jaketran

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join 

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

The Economics of the Mafia https://youtu.be/8MjDEuTuRD0 
The Economics of the Yakuza https://youtu.be/Rd0sdZySwzw 

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
📸 Follow me on IG:@jaketran // http://bit.ly/jt-ig
👨👦👦 Join the Tran Mafia Family here: https://bit.ly/patreon-jt
💬 Join the community Discord: http://discord.gg/BmK8EnQ

Stuff I use & recommend:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
🏠 The real estate investing course I love & recommend: https://jake.yt/RE
🌐 Most flexible, affordable website hosting: https://jake.yt/bhd
🖥️ Website platform I use & love: https://jake.yt/kd
💽 Editing software I've used for 7+ years: https://jake.yt/ccd
📒 Online bookkeeping software I use& love: https://jake.yt/benchd 
🧾 Best affordable bookkeeping software: https://jake.yt/fbd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd
📚 Get 3 free audiobooks for life: https://amzn.to/2v58PSu
🎥 My video gear, setup, tech, books: https://jake.yt/stored

✉️ Email me: jake@jaketran.io

Subscribe to the backup channel on LBRY, use reward code "jake-cast" for free coin: https://bit.ly/LBRY-jt

📰 Sources & visuals: https://bit.ly/2W1IpLn

-----------------------
You’re a citizen of the Soviet Union in the early-to-mid 1900’s. An average peasant that’s just trying to get by and live your life in a country that has had a very chaotic history recently. The Russian Revolution just happened in 1917. Everyone stole what they could for survival and for their own personal gain.

This is the Economics of the Russian Mafia. One of the most unique organized crime groups in history, forged in the gulags of the Soviet Union.

The Russian Mafia is very much a byproduct of Russia’s history. This is also what makes the Russian Mafia, AKA the Vory different from the Yakuza or Italian Mafia. They were joined together under the banner of being against the government and authority.

Before the Russian Revolution and Communism in 1917, Russia was ruled by monarchs, kings that they called Tsars. Then came the Revolution. That perfect storm of revolution and war led to that explosion of 7m Mafias around Russia.

The government used gulags as both a state-building/economic tool and as a psychological tool. The goal was to use them economically.

Because there were so many prisoners, the guards needed help. They enlisted the most capable mafia members to keep them productive! This new generation of mafiosos would cement the collaboration between the government and the Russian Mafia.

A new breed emerged to supplement the Soviet Economy: Black Market Entrepreneurs - Secret underground capitalist businessmen who smuggled goods into the country and sold them to make money. The Russian Mafia would offer protection to these business people.They created “Enforcement Partnerships” - where the Russian Mafia would offer business owners the protection the government failed to give them.

Russia was in complete economic turmoil in every aspect during the 90’s. They had the great stock market crash, hyperinflation, etc. So the government was in desperate need of money. They started selling the state’s assets. Small businesses, big corporations, supplies, etc. And who was ready cash in hand to buy these assets? It was the corrupt politicians, insiders, black market entrepreneurs that would later be known as the Russian Oligarchs, and of course - the Russian Mafia. And “in 1994, President Yeltsin declared that Russia was the ‘biggest mafia state in the world’”

-----------------------

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2020 Jake Tran. All rights reserved.

DISCLAIMER: These videos are for entertainment purposes only. This is not meant to be financial advice. Please always do your due diligence and never stop learning.

AFFILIATE DISCLOSURE: Some of the links in this video description are affiliate links, meaning, at no additional cost to you, I may earn a commission if you click through and make a purchase and/or opt-in. I only promote products that I 100% believe in.

