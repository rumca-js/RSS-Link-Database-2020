# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Fatman - Movie Review
 - [https://www.youtube.com/watch?v=wm5BW32du00](https://www.youtube.com/watch?v=wm5BW32du00)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-12-08 00:00:00+00:00

Walton Goggins plays a hitman on the hunt for Santa Clause played by Mel Gibson.....Wasn't sure what to expect from this one, but here's my review for FATMAN!

