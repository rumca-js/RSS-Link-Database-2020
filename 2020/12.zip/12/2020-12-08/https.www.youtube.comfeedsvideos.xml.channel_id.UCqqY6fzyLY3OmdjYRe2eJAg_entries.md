# Source:Roosevelt, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqqY6fzyLY3OmdjYRe2eJAg, language:en-US

## Roosevelt - Strangers (Official Audio)
 - [https://www.youtube.com/watch?v=NOdkHf9uJjk](https://www.youtube.com/watch?v=NOdkHf9uJjk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqqY6fzyLY3OmdjYRe2eJAg
 - date published: 2020-12-09 00:00:00+00:00

'POLYDANS' - my new album - out now! Stream / Purchase here: https://roosevelt.lnk.to/Polydans

FOLLOW Roosevelt on Facebook, Instagram and more https://roosevelt.lnk.to/follow
Website : https://roosevelt.lnk.to/website 

This is the Official Youtube Channel for Roosevelt. 
SUBSCRIBE NOW to be kept up to date with the latest music, videos, tour dates, behind the scenes footage and more https://roosevelt.lnk.to/subscribe

MUSIC CREDITS
Written, Performed, Recorded and Produced by Marius Lauber
Strings by Kaiser Quartett
Additional Guitar by Deniz Erarslan 
Additional Backing Vocals by Kat Frankie
Mastered by Heba Kadry 


LYRICS

Mirrors in the sun 
Wanna keep you by my side 
Morning just begun 
Wanna fall into the night 
 
 
Cause you keep the love for yourself 
Can he treat you like no one else 
Did you hear the lies that you tell 
But love will take us back 
Tonight 
 
You are fading away 
We're strangers in the night 
Hold on 

There's no turning back 
We're strangers in the night 
Hold on 

Feel it in your touch 
That things are not the same 
Never needed much 
But don't wanna play the game 
 
Cause you keep the love for yourself 
Can he treat you like no one else
Did you hear the lies that you tell
But love will take us back 
Tonight 
 
You are fading away 
We're strangers in the night 
Hold on 

There's no turning back 
We're strangers in the night 
Hold on 
Hold on 
 
You are fading away 
We're strangers in the night 
Hold on  

There's no turning back  
We're strangers in the night 
Hold on 
 
You are fading away 
We're strangers in the night 
Hold on  
There's no turning back 
We're strangers in the night 
Hold on 
Hold on 
 
℗ & © Greco-Roman / City Slang             

#Roosevelt #Strangers #OfficialAudio

