# Source:The Piano Guys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmKurapML4BF9Bjtj4RbvXw, language:en-US

## What Child Is This (Piano & Electric Cello) The Piano Guys
 - [https://www.youtube.com/watch?v=lJ_o85Byb-g](https://www.youtube.com/watch?v=lJ_o85Byb-g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmKurapML4BF9Bjtj4RbvXw
 - date published: 2020-12-08 00:00:00+00:00

We are SO EXCITED be a part of “The Chosen Christmas Special” December 13th, 2020 at 8pm EST Set a reminder here: https://youtu.be/_7J65DhhEcg
► Listen on AMAZON/SPOTIFY/APPLE music: https://thepianoguys.lnk.to/Christmas
► Get the SHEET MUSIC (now includes CHORD symbols): https://smarturl.it/WCIS_SheetMusic
► NEW ALBUM "10" & Christmas Bundles: https://smarturl.it/TPGmusic
► Learn about our beliefs here: https://smarturl.it/TPG_Beliefs

“The Chosen” is the BEST depiction of Jesus, His stories, and His life we have EVER seen. It is a LIFE CHANGING series that we and our families have enjoyed immensely. So we jumped at the chance to join the Chosen’s Christmas Special that this video will be a part. 
Subscribe to The Chosen Youtube channel: https://www.youtube.com/thechosenseries
HAVE YOU SEEN THE CHOSEN SERIES? You HAVE to see it! Watch it here: https://studios.vidangel.com/the-chosen 

Story:

Have you ever wondered who made the Manger? Was he an average carpenter barely making ends meet? Or was he someone extra special, destined to build the birthplace of Christmas? Did he think he was carving a run-of-the-mill wooden box to hold hay for a few animals to eat? Or did he, or she, somehow know that this particular feeding trough was meant to hold something much more -- to hold Someone who would feed five thousand with five loaves of bread?

This wooden box for a time did hold hay, and must have looked and seemed simple and remarkably ordinary. 

Until God touched it.

For us, this is one of the many messages of this Christmas Hymn we present to you.

“What Child is This?
This, this is Christ the King,
Whom shepherds guard and Angels sing.”

This is Jesus, born in the humblest of circumstances and yet born with the ability to overcome the world. Born under the brightest star ever seen, but so meekly as to ask an obscure carpenter to carve his bed and to share it with animals. This is Jesus, powerful enough to command angels, but so concerned with the worth of every soul, especially those overlooked, that he would ask shepherds instead to guard him as he slept; a King of countless subjects whose birth would change the reckoning of time itself, and yet a homeless teacher who spent all of His time to heal the one.

This is Jesus, who can touch something entirely ordinary and make it extraordinary -- who can touch any willing soul, labeled as worthless by the world, and make it priceless. 

We’ve seen this happen. This is why we believe. And why, despite so many mistakes we’ve made and so many lopsided mangers we’ve attempted to carve, we still strive to follow this advice:

“Men and women who turn their lives over to God will discover that He can make a lot more out of their lives than they can. He can deepen their joys, expand their vision, quicken their minds, strengthen their muscles, lift their spirits, multiply their blessings, increase their opportunities, comfort their souls, and pour out peace.” (Ezra Taft Benson)
While Jesus Christ, His story and His life mean so much to us, we don’t mean for this video to be exclusively “religious” or make anyone feel left out. On the contrary, we hope that this only brings peace, no matter who you are, where you are watching, or what you believe. We hope that the spirit of this music can transcend traditional religious lines and its spirituality can be felt by all who need a little serenity this Christmas Season.

Merry Christmas.

Where is this filmed?

We were especially thrilled to be able to return to the same Jerusalem set where we filmed “O Come O Come Emmanuel,” (https://www.youtube.com/watch?v=iO7ySn-Swwc), hosted by the Church of Jesus Christ of Latter-day Saints, which is now the set of the series The Chosen, a show which we are honored and excited to be able to promote.


Credits

“What Child is This” arrangement written by Jon Schmidt, Al van der Beek & Steven Sharp Nelson
Performed by Jon Schmidt, Piano
Steven Sharp Nelson, Electric cello
Recorded, mixed & mastered by Al van der Beek at TPG Studio in Utah
Piano moving: Frank Nelson & Jeremy Crawford

Executive Producers: Brad Pelo & Joshua Mckinney
Produced by Jacob Schwarz, Willem Kampenhout & Matthew Siemers
Directed by Willem Kampenhout; 1st Assistant Director: David Lidell Thorpe
Director of Photography: Jacob Schwarz
Edited by Evan Carpenter Shaye Scott, Paul Anderson & Steven Sharp Nelson
Camera Operators: Justin Ahlmann & Byron Kirkland; Jib Operator: Josh Contor
Drone Operator: Chris Workman
1st Assistant Camera: Paul Green & Ben Haskin; 2nd Assistant Camera: Jacob Watson
Gaffer: Matt Long; Key grip: Steve Carter; G/E Swing: Cortland Lindsay
Artist Photographer: Scott Jarvie; Hair & Makeup Artist: Ariel Lafontaine
Production Assistants: Archelaus Cristanto, Caden Thompson & Cole Thompson
Set Medic / Covid Compliance: Warren Workman
Catering & Craft Services: Richard Taylor, Fat Boy Catering; Assistant: Eddi Taylor

