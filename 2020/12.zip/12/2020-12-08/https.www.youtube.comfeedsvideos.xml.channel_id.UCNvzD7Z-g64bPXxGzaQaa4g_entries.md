# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Christmas Gifts Gamers DON'T WANT
 - [https://www.youtube.com/watch?v=UQVugmHEXjw](https://www.youtube.com/watch?v=UQVugmHEXjw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-12-09 00:00:00+00:00

Some Christmas gifts are...no so great. For gamers in particular, many mistakes can be made.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 10 HIDDEN Secrets in Video Game Intros
 - [https://www.youtube.com/watch?v=AiIQ4hHazI0](https://www.youtube.com/watch?v=AiIQ4hHazI0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-12-09 00:00:00+00:00

Some intros and starting areas of video games have secrets hidden in plain sight. Here are some cool examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

