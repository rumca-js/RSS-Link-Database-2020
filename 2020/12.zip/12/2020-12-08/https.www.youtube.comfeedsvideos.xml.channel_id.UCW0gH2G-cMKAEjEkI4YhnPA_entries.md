# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Project Northmoor Q&A with Julia Golding
 - [https://www.youtube.com/watch?v=5rTdQ-kuzZY](https://www.youtube.com/watch?v=5rTdQ-kuzZY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2020-12-09 00:00:00+00:00

In a special livestream interview, we will chat with Julia Golding, who is heading up Project Northmoor - the effort to restore JRR Tolkien's old home and convert it into a writing center.

