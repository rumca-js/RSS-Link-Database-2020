# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Jupiter & Okwess - Performance & Interview (And To All A Good Home)
 - [https://www.youtube.com/watch?v=CMQnp6CfHFc](https://www.youtube.com/watch?v=CMQnp6CfHFc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-12-09 00:00:00+00:00

KEXP + Starbucks present And To All A Good Home, a benefit series supporting Mary’s Place and the No Child Sleeps Outside campaign, featuring Jupiter & Okwess.

Songs:
Bakunda Ulu
Ofakombolo
Musonsu
Ekombe
Na Kozonga (Nighttrain cover)

Mary’s Place provides safe, inclusive shelter and services that support women, children and families on their journey out of homelessness. Particularly during this pandemic, the safest place for a family to be is in their own home. Whether in shelter or a car or a tent, Mary’s Place priority is to help families find housing as quickly as possible, and to stay housed through these challenging economic times.

Donate through this video where 100% of your donations go directly to families in need.

https://www.jupiterandokwess.com
http://nochildsleepsoutside.org
http://www.marysplaceseattle.org
http://www.kexp.org

## Bartees Strange - Performance & Interview (And To All A Good Home)
 - [https://www.youtube.com/watch?v=cZYRt1IrO14](https://www.youtube.com/watch?v=cZYRt1IrO14)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-12-08 00:00:00+00:00

KEXP + Starbucks present And To All A Good Home, a benefit series supporting Mary’s Place and the No Child Sleeps Outside campaign, featuring Bartees Strange.

Songs:
Mustang
Boomer
In A Cab
Far
Stone Meadows

Mixed by Nick Rapley
Engineered by John Brooks
Shot by Britain Weyant at 38 North Studios

Mary’s Place provides safe, inclusive shelter and services that support women, children and families on their journey out of homelessness. Particularly during this pandemic, the safest place for a family to be is in their own home. Whether in shelter or a car or a tent, Mary’s Place priority is to help families find housing as quickly as possible, and to stay housed through these challenging economic times.

Donate through this video where 100% of your donations go directly to families in need.

https://barteesstrange.bandcamp.com
http://nochildsleepsoutside.org
http://www.marysplaceseattle.org
http://www.kexp.org

