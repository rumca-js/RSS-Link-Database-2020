# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## 'They left us for dead.' Tigray refugees tell of horrors after Ethiopian troops vowed they'd be safe
 - [https://www.cnn.com/2020/12/08/africa/ethiopia-tigray-refugees-sudan-border-intl/index.html](https://www.cnn.com/2020/12/08/africa/ethiopia-tigray-refugees-sudan-border-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 20:35:36+00:00

Huyeet is limping as he crosses the border, his leg bandaged with dirty gauze.

## Judge dismisses Michael Flynn case after Trump pardon, despite two guilty pleas
 - [https://www.cnn.com/2020/12/08/politics/michael-flynn/index.html](https://www.cnn.com/2020/12/08/politics/michael-flynn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 20:25:44+00:00

Judge Emmet Sullivan of the DC District Court has dismissed Michael Flynn's criminal case as moot, ending a tortured three-year-long proceeding.

## US surpasses 15 million confirmed Covid-19 cases during deadliest week since April
 - [https://www.cnn.com/2020/12/08/health/us-coronavirus-tuesday/index.html](https://www.cnn.com/2020/12/08/health/us-coronavirus-tuesday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 20:18:29+00:00

The US surpassed 15 million total reported Covid-19 infections on Tuesday and daily deaths neared a record level as the nation is mired in an increasingly difficult phase of the pandemic.

## The Arctic is getting hotter, greener and less icy much faster than expected, reports finds
 - [https://www.cnn.com/2020/12/08/weather/noaa-arctic-report-card-2020-climate-change/index.html](https://www.cnn.com/2020/12/08/weather/noaa-arctic-report-card-2020-climate-change/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 20:18:22+00:00

Bitterly cold, frozen and inhospitable to nearly all wildlife apart from polar bears.

## Lori Loughlin's daughter speaks out for first time about college admissions scandal
 - [https://www.cnn.com/2020/12/08/entertainment/olivia-jade-lori-loughlin-scandal/index.html](https://www.cnn.com/2020/12/08/entertainment/olivia-jade-lori-loughlin-scandal/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 19:53:54+00:00

Olivia Jade Giannulli is opening up about the college admissions scandal that landed her parents, actress Lori Loughlin and designer Mossimo Giannulli, in prison.

## House to vote on defense bill as Trump urges GOP to oppose it
 - [https://www.cnn.com/2020/12/08/politics/defense-bill-house-vote-trump-veto-threat/index.html](https://www.cnn.com/2020/12/08/politics/defense-bill-house-vote-trump-veto-threat/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 19:31:17+00:00

President Donald Trump's threat to veto a sweeping defense bill that is set for a vote in the House of Representatives on Tuesday is sharply dividing Republican lawmakers, forcing them to choose between loyalty to the President and legislation that sets defense policy for the country and creating uncertainty over whether enough votes exist to override a veto.

## The major differences between Biden and Trump's leadership will be on full display today
 - [https://www.cnn.com/collections/intl-us-coronavirus-1207/](https://www.cnn.com/collections/intl-us-coronavirus-1207/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 19:25:02+00:00



## 'I've never felt such silence' -- What it's like to work at an airport right now
 - [https://www.cnn.com/collections/intl-coronavirus-1208/](https://www.cnn.com/collections/intl-coronavirus-1208/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 19:23:04+00:00



## Canada crushed Covid-19 curve but complacency fuels deadly second wave
 - [https://www.cnn.com/2020/12/08/world/canada-covid-second-wave/index.html](https://www.cnn.com/2020/12/08/world/canada-covid-second-wave/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 19:06:19+00:00

"At least we're not as bad as the States."

## US Army punishes 14 senior officers after murder and other deaths at Fort Hood
 - [https://www.cnn.com/2020/12/08/politics/fort-hood-investigation/index.html](https://www.cnn.com/2020/12/08/politics/fort-hood-investigation/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 18:56:43+00:00

The Army announced Tuesday that 14 senior officers will be punished following a probe that was initiated after the murder of a soldier and several other deaths at the Amy's Fort Hood base in Texas this year.

## Goya CEO names Alexandria Ocasio-Cortez 'employee of the month'
 - [https://www.cnn.com/2020/12/08/business/goya-aoc-employee-of-the-month/index.html](https://www.cnn.com/2020/12/08/business/goya-aoc-employee-of-the-month/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 18:45:39+00:00

Goya CEO Robert Unanue referred to Rep. Alexandria Ocasio-Cortez as the company's "employee of the month," claiming that the congresswoman's July tweets about making her own adobo boosted sales.

## SpaceX gets almost $900 million in federal subsidies to deliver broadband to rural America
 - [https://www.cnn.com/2020/12/08/tech/spacex-starlink-subsidies-fcc-scn/index.html](https://www.cnn.com/2020/12/08/tech/spacex-starlink-subsidies-fcc-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 18:38:58+00:00

The US government plans to give SpaceX nearly a billion dollars to beam internet from space to people across rural America, where three out of five people say access to broadband is still a pressing issue.

## Climber rescued alive after falling 15 feet into volcanic crevice
 - [https://www.cnn.com/2020/12/08/us/climber-alive-after-falling-mount-hood-trnd/index.html](https://www.cnn.com/2020/12/08/us/climber-alive-after-falling-mount-hood-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 18:34:40+00:00

A climber who had stopped to rest during an expedition on Mount Hood was rescued after falling into a snow-covered volcanic crevice.

## Trump campaign lawyer contracts coronavirus, source says
 - [https://www.cnn.com/2020/12/08/politics/jenna-ellis-coronavirus/index.html](https://www.cnn.com/2020/12/08/politics/jenna-ellis-coronavirus/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 18:18:12+00:00

Jenna Ellis, a lawyer who has been leading the Trump campaign's legal efforts to dispute the results of the 2020 presidential election, has contracted the coronavirus, a source familiar with the situation confirmed to CNN.

## GOP leadership rejects resolution acknowledging Biden as President-elect, even though he won
 - [https://www.cnn.com/collections/biden-1208/](https://www.cnn.com/collections/biden-1208/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 18:01:44+00:00



## Patients hospitalized with mystery illness in India have nickel and lead in blood
 - [https://www.cnn.com/2020/12/08/india/india-illness-nickel-lead-intl-scli/index.html](https://www.cnn.com/2020/12/08/india/india-illness-nickel-lead-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 17:45:49+00:00

Health officials in India have found excessive amounts of lead and nickel in blood samples taken from patients who have been hospitalized in Andhra Pradesh, officials investigating the cases said Tuesday.

## See Indian couple get married in full PPE
 - [https://www.cnn.com/videos/world/2020/12/08/india-covid-19-coronavirus-wedding-ppe-bride-tests-positive-ctw-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2020/12/08/india-covid-19-coronavirus-wedding-ppe-bride-tests-positive-ctw-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 17:42:58+00:00

Traditional Indian wedding finery gave way to hazmat suits and masks in a remote north Indian village, after the bride tested positive for Covid-19 just hours before the marriage, a local health official said.

## Tennis star Carla Suarez Navarro back hitting on court despite cancer treatments
 - [https://www.cnn.com/2020/12/08/tennis/carla-suarez-navarro-tennis-spt-intl/index.html](https://www.cnn.com/2020/12/08/tennis/carla-suarez-navarro-tennis-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 17:16:21+00:00

Carla Suarez Navarro is back hitting on a tennis court as she undergoes cancer treatment.

## The titanic hypocrisy of the 'election fraud' crowd
 - [https://www.cnn.com/2020/12/08/politics/andy-biggs-election-fraud-donald-trump/index.html](https://www.cnn.com/2020/12/08/politics/andy-biggs-election-fraud-donald-trump/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 17:12:17+00:00

Arizona Republican Rep. Andy Biggs is totally certain of two things:

## Man fined $3,500 for breaking Taiwan quarantine for 8 seconds
 - [https://www.cnn.com/videos/world/2020/12/08/taiwan-coronavirus-covid-19-fine-8-seconds-migrant-worker-ctw-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2020/12/08/taiwan-coronavirus-covid-19-fine-8-seconds-migrant-worker-ctw-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 16:47:47+00:00

Taiwanese authorities have slapped a $3,500 fine on a man who broke quarantine regulations for just eight seconds. The man, a migrant worker from the Philippines, was quarantining in a hotel in Kaohsiung City when he briefly stepped out of his room into the hallway, the city's Department of Health told Taiwan's official Central News Agency (CNA).

## Boeing set to deliver first 737 Max since plane's grounding
 - [https://www.cnn.com/2020/12/08/business/boeing-737-max-delivery-united-airlines/index.html](https://www.cnn.com/2020/12/08/business/boeing-737-max-delivery-united-airlines/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 16:34:59+00:00

Boeing is set to deliver a 737 Max to United on Tuesday, the first delivery of the troubled plane since its grounding almost two years ago.

## 'We're injecting hope': Inside a UK Covid-19 vaccination center as historic rollout gets underway
 - [https://www.cnn.com/collections/intl-covid-vaccine-1208/](https://www.cnn.com/collections/intl-covid-vaccine-1208/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 16:05:05+00:00



## 'Unprecedented' high-res image of sunspot captured by new solar telescope
 - [https://www.cnn.com/2020/12/08/world/sunspot-high-res-image-scn-trnd/index.html](https://www.cnn.com/2020/12/08/world/sunspot-high-res-image-scn-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 15:55:40+00:00

Sunspots -- dark areas on the sun -- help scientists track activity on the surface of our solar system's star. These dark spots are the origin point for the explosive flares and ejections that release light, solar material and energy into space.

## Watch the top YouTube videos of the year
 - [https://www.cnn.com/videos/business/2020/12/02/youtube-2020-top-trending-videos-yir-orig.cnn-business](https://www.cnn.com/videos/business/2020/12/02/youtube-2020-top-trending-videos-yir-orig.cnn-business)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 15:35:51+00:00

The 2020 election, Covid-19, and Black Lives Matter became central themes of this year. Here are the top trending videos in a look back at what shaped YouTube in 2020.

## I moved to Mexico during Covid-19
 - [https://www.cnn.com/travel/article/moved-to-mexico-covid-careyes/index.html](https://www.cnn.com/travel/article/moved-to-mexico-covid-careyes/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 15:32:06+00:00

I am a third-generation Angeleno. For most of my adult life living in Los Angeles, as a luxury lifestyle public relations executive and to satisfy my own wanderlust, I would travel as much as possible to tropical parts of the world, with any opportunity that arose. I lived on Maui for three years and truly embraced the Hawaiian culture and loved living by the beach in nature.

## The major differences between President-elect Biden and Trump's leadership will be on full display today
 - [https://www.cnn.com/2020/12/08/politics/trump-biden-vaccine-coronavirus/index.html](https://www.cnn.com/2020/12/08/politics/trump-biden-vaccine-coronavirus/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 15:15:15+00:00

• US sees its deadliest Covid week since April

## 'I've never felt such silence:' What it's like to work at an airport now
 - [https://www.cnn.com/travel/article/airport-workers-covid-experiences/index.html](https://www.cnn.com/travel/article/airport-workers-covid-experiences/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 14:13:30+00:00

Gaëlle Simon, a check-in and boarding agent at Brussels Airport, Belgium, used to feel lucky to work at an airport.

## 'Pushing ludicrous accusations': Avlon on Trump's legal team
 - [https://www.cnn.com/videos/politics/2020/12/08/trump-georgia-election-ballots-republicans-reality-check-avlon-newday-vpx.cnn](https://www.cnn.com/videos/politics/2020/12/08/trump-georgia-election-ballots-republicans-reality-check-avlon-newday-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 13:47:40+00:00

CNN's John Avlon breaks down President Trump's efforts to overturn the 2020 US election results where he continues to perpetuate false allegations of voter fraud.

## Critically endangered Sumatran orangutan born at Belgian animal park
 - [https://www.cnn.com/2020/12/08/europe/orangutan-born-belgium-park-scli-intl/index.html](https://www.cnn.com/2020/12/08/europe/orangutan-born-belgium-park-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 13:47:04+00:00

An animal park in Belgium has welcomed the arrival of a critically endangered Sumatran orangutan.

## Trump's window for election subversion is closing
 - [https://www.cnn.com/2020/12/08/politics/what-matters-december-7/index.html](https://www.cnn.com/2020/12/08/politics/what-matters-december-7/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 13:19:51+00:00

President Donald Trump's legal team for weeks has worked to delay the certification of Joe Biden's election win in a long-shot effort to create an opening for Trump stay in power.

## Houston Rockets coach Stephen Silas describes James Harden as a 'holdout'
 - [https://www.cnn.com/2020/12/08/sport/james-harden-houston-rockets-holdout-spt-intl/index.html](https://www.cnn.com/2020/12/08/sport/james-harden-houston-rockets-holdout-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 13:11:14+00:00

Where's James Harden?

## Bobi Wine wants Ugandan government held to account after he was nearly killed twice
 - [https://www.cnn.com/2020/12/08/africa/bobi-wine-assassination-attempt-amanpour-intvw-intl/index.html](https://www.cnn.com/2020/12/08/africa/bobi-wine-assassination-attempt-amanpour-intvw-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 13:03:13+00:00

Ugandan music star turned presidential candidate Bobi Wine says he was nearly killed twice in recent weeks and called on the international community to hold Uganda's government accountable ahead of elections next month.

## Everest conqueror and mountaineering icon Doug Scott dies aged 79
 - [https://www.cnn.com/2020/12/08/sport/doug-scott-obit-everest-death-spt-intl/index.html](https://www.cnn.com/2020/12/08/sport/doug-scott-obit-everest-death-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 12:52:13+00:00

Mountaineer Doug Scott, who was part of the first UK team to summit Mount Everest via the south-west face, has passed away at the age of 79.

## Real-world locations straight out of a Wes Anderson movie
 - [https://www.cnn.com/style/article/accidentally-wes-anderson-wally-koval/index.html](https://www.cnn.com/style/article/accidentally-wes-anderson-wally-koval/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 12:32:22+00:00

Rounded edges, pastel colors and satisfying symmetry -- there is something unmistakable about a Wes Anderson movie.

## Paul Pogba should leave Manchester United, says agent
 - [https://www.cnn.com/2020/12/08/football/paul-pogba-mino-raiola-manchester-united-spt-intl/index.html](https://www.cnn.com/2020/12/08/football/paul-pogba-mino-raiola-manchester-united-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 12:06:21+00:00

Paul Pogba should leave Manchester United, according to his agent Mino Raiola.

## Tripadvisor's app, and more than 100 others, have just been blocked in China
 - [https://www.cnn.com/2020/12/08/tech/tripadvisor-china-apps-intl-hnk/index.html](https://www.cnn.com/2020/12/08/tech/tripadvisor-china-apps-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 11:28:23+00:00

China says it has pulled Tripadvisor from mobile app stores in the country as the government embarks on a fresh bid to "clean up" the internet.

## Look back on the life of Chuck Yeager, the world's first supersonic pilot
 - [https://www.cnn.com/videos/us/2020/12/08/chuck-yeager-pilot-broke-sound-barrier-death-ldn-vpx.cnn](https://www.cnn.com/videos/us/2020/12/08/chuck-yeager-pilot-broke-sound-barrier-death-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 11:00:17+00:00

US Air Force officer and test pilot Chuck Yeager has died at the age of 97. He was the first person to break the sound barrier when he tested the X-1 in October 1947, although the feat was not announced to the public until 1948. CNN's John Berman looks back at his life.

## Mount Everest's height has changed
 - [https://www.cnn.com/travel/article/mount-everest-height-intl-hnk-scli/index.html](https://www.cnn.com/travel/article/mount-everest-height-intl-hnk-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 10:59:54+00:00

After more than a decade of dispute and controversy, China and Nepal have finally agreed on how tall Mount Everest is.

## Doctor dies of Covid after treating some of Houston's sickest patients
 - [https://www.cnn.com/2020/12/08/us/houston-doctor-covid-dies-trnd/index.html](https://www.cnn.com/2020/12/08/us/houston-doctor-covid-dies-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 08:07:15+00:00

Since the beginning of the pandemic, Dr. Carlos Araujo-Preza spent his days caring for some of the sickest Covid-19 patients in Houston.

## China open to reset in relations with US as Washington announces fresh sanctions over Hong Kong
 - [https://www.cnn.com/2020/12/08/asia/wang-yi-china-us-sanctions-intl-hnk/index.html](https://www.cnn.com/2020/12/08/asia/wang-yi-china-us-sanctions-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 06:19:27+00:00

China's foreign minister says Beijing is open to restarting its relationship with the US, declaring the two countries are at a "critical historical juncture" after a year of escalating tensions.

## Police raid home of former Covid-19 data scientist
 - [https://www.cnn.com/2020/12/07/us/florida-search-warrant-raid-rebekah-jones-invs/index.html](https://www.cnn.com/2020/12/07/us/florida-search-warrant-raid-rebekah-jones-invs/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 05:13:32+00:00

Florida police raided the home of a former state coronavirus data scientist on Monday, escalating a feud between the state government and a data expert who has accused officials of trying to cover up the extent of the pandemic.

## Melania Trump presents new WH tennis pavilion amid pandemic
 - [https://www.cnn.com/videos/politics/2020/12/08/melania-trump-presents-white-house-tennis-pavilion-take-this-ctn-vpx.cnn](https://www.cnn.com/videos/politics/2020/12/08/melania-trump-presents-white-house-tennis-pavilion-take-this-ctn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 04:30:01+00:00

First lady Melania Trump's office announced the finalization of the White House Tennis Pavilion -- a tone deaf accomplishment to trumpet amid the ongoing coronavirus pandemic and as the federal government remains locked on providing further economic relief to millions of suffering Americans.

## Anderson Cooper: Trump didn't have courage to tell the US people the truth
 - [https://www.cnn.com/videos/politics/2020/12/08/donald-trump-coronavirus-handling-2020-election-kth-sot-vpx-ac360.cnn](https://www.cnn.com/videos/politics/2020/12/08/donald-trump-coronavirus-handling-2020-election-kth-sot-vpx-ac360.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 02:50:34+00:00

CNN's Anderson Cooper calls out President Donald Trump's handling of the coronavirus pandemic as it continues to surge across the country.

## Senate runoff candidate skips debate, refuses to speak to CNN reporter
 - [https://www.cnn.com/videos/politics/2020/12/08/ga-senate-race-david-perdue-lah-pkg-ebof-vpx.cnn](https://www.cnn.com/videos/politics/2020/12/08/ga-senate-race-david-perdue-lah-pkg-ebof-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 02:43:16+00:00

Sen. David Perdue (R-GA) skipped the only debate in the Georgia Senate runoff race but continues to campaign across the state on his little publicized bus tour, dodging repeated questions from CNN's Kyung Lah and other media outlets.

## Mario Lopez stars as KFC's Col. Sanders in steamy movie
 - [https://www.cnn.com/videos/business/2020/12/08/mario-lopez-kfc-romance-movie-jeanne-moos-pkg-vpx.cnn](https://www.cnn.com/videos/business/2020/12/08/mario-lopez-kfc-romance-movie-jeanne-moos-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-08 02:17:29+00:00

Internet users roast the steamy KFC movie starring Mario Lopez as Col. Sanders. CNN's Jeanne Moos reports.

