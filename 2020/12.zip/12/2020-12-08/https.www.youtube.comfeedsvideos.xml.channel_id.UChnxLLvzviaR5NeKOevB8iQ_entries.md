# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Self-Playing Patches on the ASM Hydrasynth: Part 2 (Arpeggio)
 - [https://www.youtube.com/watch?v=ohDopJrAHVs](https://www.youtube.com/watch?v=ohDopJrAHVs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2020-12-08 00:00:00+00:00

A self-playing patch is one that you set up to constantly shift, morph, and surprise you. In this video, we'll look at making a self-modulating ambient arpeggiated thing you can just put on in the background and chill to using the ASM Hydrasynth: https://amzn.to/2KLmea1
Watch part one here: https://youtu.be/f2R9X0c-BQM
------------------------------------
Thank you for watching. My name is Jeremy, and this is Red Means Recording. I've been making music for a few decades now, and this channel is a place to make music and to talk about the tools and techniques to make music with. We'll use synths, drum machines, modular gear, and software. 

If you'd like to support the channel, I have a Patreon:  http://bit.ly/rmrpatreon

I have music as "Jeremy Blake" on all the major services: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

I have some merch here: http://bit.ly/rmrshirts

And you can connect with me here: 
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

