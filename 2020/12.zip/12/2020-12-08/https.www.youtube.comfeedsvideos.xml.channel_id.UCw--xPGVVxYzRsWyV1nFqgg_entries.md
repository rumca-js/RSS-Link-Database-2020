# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## THE POPPY WAR TV SHOW CONFIRMED (Darker Avatar?)
 - [https://www.youtube.com/watch?v=vgVPX0YAFHU](https://www.youtube.com/watch?v=vgVPX0YAFHU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-12-09 00:00:00+00:00

It looks like Starlight Media is developing a Poppy War TV Show! Let’s talk about that. 

Link: https://curiositystream.com/Greene
Code: Greene

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

## Viggo Mortensen LotR Comments🧝‍♀️ Dune Could Help Kill Theaters🎭 Oscar Isaac IS Solid Snake!🐍
 - [https://www.youtube.com/watch?v=b3XZ5G77b5A](https://www.youtube.com/watch?v=b3XZ5G77b5A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-12-08 00:00:00+00:00

Let's talk some good old fantasy news! Going to be honest, had to rush this one a bit.
Sign up for Campfire here: http://www.campfireblaze.com/?utm_source=youtube&utm_medium=video&utm_campaign=Greene4.20

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

NEWS
00:00 Intro
00:18 Patrick Rothfuss #DoorsOfStone Comments: https://www.youtube.com/watch?v=XxU-7XiEN30 
01:25 #LotR Casting: https://www.tor.com/2020/12/03/twenty-new-cast-members-amazons-lord-of-the-rings/ 
01:59 Viggo Mortensen Amazon LotR Comments: https://screenrant.com/lord-rings-show-viggo-mortensen-opinion/
03:16 LotR Deleted Scene comments: https://screenrant.com/lord-rings-aragorn-arwen-deleted-scene-viggo-mortensen/ 
05:24 The Girl and the Mountain: https://harpervoyagerbooks.co.uk/2020/12/07/exclusive-christmas-preview-chapter-one-of-the-girl-and-the-mountain-by-mark-lawrence-the-second-book-of-the-ice/ 
05:41 Chrono Odyssey: https://www.youtube.com/watch?v=dEBufqmFOyA&t=51s 
06:31 Oscar Isaac Solid Snack  ( #MetalGearSolid ): https://deadline.com/2020/12/oscar-isaac-solid-snake-sonys-metal-gear-solid-movie-1234650259/ 
07:14 Deadpool Manga: Deadpool… manga?: https://comicbook.com/anime/news/deadpool-samurai-manga-shonen-jump-marvel-comics/ 
07:24 WoT Comment response: https://www.youtube.com/watch?v=W_7nIBstwbk 
08:40 HBO Releases: https://twitter.com/wbpictures/status/1334570201610735617?s=19
Dune Legal Battle: https://deadline.com/2020/12/warnermedia-legendary-challenge-dune-godzilla-vs-kong-streamer-battles-looming-1234651283/

