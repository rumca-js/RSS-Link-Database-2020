# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## The Neighbourhood - live - Middle Of Somewhere & Afraid
 - [https://www.youtube.com/watch?v=7w8hfmpQChc](https://www.youtube.com/watch?v=7w8hfmpQChc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-12-08 00:00:00+00:00

Koncert The Neighbourhood - Middle Of Somewhere i Afraid na żywo.

Nowy album The Neighbourhood – Chip Chrome & The Mono-Tones już dostępny! 

Słuchaj płyty: https://smp.lnk.to/ChipChrome
 
Obserwuj The Neighbourhood:
http://thenbhd.com
http://instagram.com/thenbhd
http://facebook.com/theneighbourhood
http://twitter.com/thenbhd
http://snapchat.com/add/thenbhd
https://www.tiktok.com/@chipchrome
https://www.instagram.com/chipchrome/



Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm

