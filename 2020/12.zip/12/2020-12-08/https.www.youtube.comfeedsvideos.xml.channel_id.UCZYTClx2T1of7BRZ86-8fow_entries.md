# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## Robot Ant Swarms Have Arrived!
 - [https://www.youtube.com/watch?v=_xuAux4lc4o](https://www.youtube.com/watch?v=_xuAux4lc4o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2020-12-08 00:00:00+00:00

Robot design commonly mimics the abilities of their human creators, but some researchers have been inspired by a possibly unexpected creature: an ant.


Hosted by: Michael Aranda

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Marwan Hassoun, Jb Taishoff, Bd_Tmprd, Harrison Mills, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Sam Buck, Christopher R Boucher, Eric Jensen, Lehel Kovacs, Adam Brainard, Greg, Ash, Sam Lutfi, Piya Shedden, KatieMarie Magnone, Scott Satovsky Jr, charles george, Alex Hackman, Chris Peters, Kevin Bealer
----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://www.hansonrobotics.com/sophia/
https://www.softbankrobotics.com/emea/en/company 
https://jeb.biologists.org/content/jexbio/220/17/3062.full.pdf
https://www.nature.com/articles/s41586-019-1388-8
https://ieeexplore.ieee.org/document/8419761
https://www.wevolver.com/wevolver.staff/mini.whegs/master/blob/Overview.wevolver
https://www.nasa.gov/content/meet-the-swarmies-robotics-answer-to-bugs



Image Sources:
https://www.istockphoto.com/vector/green-technology-background-gm450969425-30285888
https://www.istockphoto.com/vector/little-black-ant-small-insect-abstract-logo-symbol-gm1268605465-372416550
https://www.istockphoto.com/vector/blue-circuit-board-pattern-digital-seamless-background-abstract-futuristic-computer-gm1211150092-351122606
https://commons.wikimedia.org/wiki/File:Sophia_(robot)_2.jpg
https://commons.wikimedia.org/wiki/File:Romeo_the_robot_.jpg
https://commons.wikimedia.org/wiki/File:Trap_Jaw_Ant_(40198968482).jpg
https://commons.wikimedia.org/wiki/File:Trap_Jaw_Ant_(40231972791).jpg
https://commons.wikimedia.org/wiki/File:Mandible-Powered-Escape-Jumps-in-Trap-Jaw-Ants-Increase-Survival-Rates-during-Predator-Prey-pone.0124871.s002.ogv
https://www.nature.com/articles/s41586-019-1388-8
https://www.storyblocks.com/video/stock/space-background-loop-animation-s-ninhoswj56kef4m

