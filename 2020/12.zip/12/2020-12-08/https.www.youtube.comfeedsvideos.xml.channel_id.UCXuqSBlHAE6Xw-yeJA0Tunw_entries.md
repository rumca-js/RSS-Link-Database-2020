# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## AMD Enters the Chat... RADEON 6900 XT Review
 - [https://www.youtube.com/watch?v=b9ALYCuqtho](https://www.youtube.com/watch?v=b9ALYCuqtho)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-12-08 00:00:00+00:00

After promising RTX 3090 performance for $500 less, AMD’s Radeon RX 6900 XT has a lot to live up to.. Can it POSSIBLY be that good?

Buy AMD Radeon RX 6900 XT
On Best Buy (PAID LINK): https://geni.us/9Dwg
On Newegg (PAID LINK): https://geni.us/1tDUkY

Buy AMD Radeon RX 6800 XT
On Amazon (PAID LINK): https://geni.us/FhJY
On Best Buy (PAID LINK): https://geni.us/Af0y8Uh
On Newegg (PAID LINK): https://geni.us/uQgdff

Buy AMD Radeon RX 6800
On Amazon (PAID LINK): https://geni.us/IDZW9w
On Best Buy (PAID LINK): https://geni.us/BShFj7m
On Newegg (PAID LINK): https://geni.us/WyVYtPZ

Buy Nvidia RTX 3090
On Amazon (PAID LINK): https://geni.us/3oGSmB2
On B&H (PAID LINK): https://geni.us/MgYQ7Bq

Buy Nvidia RTX 3080
On Amazon (PAID LINK): https://geni.us/mzki98
On Best Buy (PAID LINK): https://geni.us/7slte
On B&H (PAID LINK): https://geni.us/QRJiVqX

Buy Nvidia RTX 3070
On Amazon (PAID LINK): https://geni.us/Nos44u6
On Best Buy (PAID LINK): https://geni.us/jfE6BY
On B&H (PAID LINK): https://geni.us/Np4We

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1278422-amd-enters-the-chat/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Official Game Store: https://www.nexus.gg/ltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

