## SoCal restaurant owners defy orders to close despite regional stay-at-home order - ABC7 Los Angeles
 - [https://abc7.com/california-coronavirus-socal-lockdown-stay-at-home-order-gov-gavin-newsom/8595340/](https://abc7.com/california-coronavirus-socal-lockdown-stay-at-home-order-gov-gavin-newsom/8595340/)
 - RSS feed: https://abc7.com
 - date published: 2020-12-08 20:06:28+00:00

SoCal restaurant owners defy orders to close despite regional stay-at-home order - ABC7 Los Angeles

