# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Inside the Steroid Use in Bodybuilding
 - [https://www.youtube.com/watch?v=YMZ7H10ySVA](https://www.youtube.com/watch?v=YMZ7H10ySVA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2020-12-09 00:00:00+00:00

This clip is taken from the Joe Rogan Experience podcast #1576 with Mariana van Zeller. https://open.spotify.com/episode/1Ldn7iDJ2QPIU7gmxG8m5A?si=02WGNLaARDCU7s2lgzckvA

## Mariana van Zeller Met a Real-Life Walter White Style Drug Chemist
 - [https://www.youtube.com/watch?v=atIEe80Ob-4](https://www.youtube.com/watch?v=atIEe80Ob-4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2020-12-09 00:00:00+00:00

This clip is taken from the Joe Rogan Experience podcast #1576 with Mariana van Zeller. https://open.spotify.com/episode/1Ldn7iDJ2QPIU7gmxG8m5A?si=02WGNLaARDCU7s2lgzckvA

## Marianna van Zeller Infiltrated a South American Cocaine Operation
 - [https://www.youtube.com/watch?v=Q99XZMhMr5M](https://www.youtube.com/watch?v=Q99XZMhMr5M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2020-12-09 00:00:00+00:00

This clip is taken from the Joe Rogan Experience podcast #1576 with Mariana van Zeller. https://open.spotify.com/episode/1Ldn7iDJ2QPIU7gmxG8m5A?si=02WGNLaARDCU7s2lgzckvA

## Bill Burr's Take on Phone Addiction
 - [https://www.youtube.com/watch?v=oK2nFL_mvZU](https://www.youtube.com/watch?v=oK2nFL_mvZU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2020-12-08 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1575 with Bill Burr. https://open.spotify.com/episode/2RYuGMhdQCk6FFoFJzKUR1?si=A96K_G2ZRJmQLqNq4PQUgA

## Rogan & Burr Discuss the Legendary Steve Martin
 - [https://www.youtube.com/watch?v=RWqGnRfAQU4](https://www.youtube.com/watch?v=RWqGnRfAQU4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2020-12-08 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1575 with Bill Burr. https://open.spotify.com/episode/2RYuGMhdQCk6FFoFJzKUR1?si=A96K_G2ZRJmQLqNq4PQUgA

## What Bill Burr Has Learned from Death Bed Stories
 - [https://www.youtube.com/watch?v=lj5p8oFWtnU](https://www.youtube.com/watch?v=lj5p8oFWtnU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2020-12-08 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1575 with Bill Burr. https://open.spotify.com/episode/2RYuGMhdQCk6FFoFJzKUR1?si=A96K_G2ZRJmQLqNq4PQUgA

