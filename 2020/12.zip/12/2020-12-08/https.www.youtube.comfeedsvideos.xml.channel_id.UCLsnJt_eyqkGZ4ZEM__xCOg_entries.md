# Source:Vlog Casha, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg, language:pl-PL

## Stało się. Oszukali mnie w Turcji 😠
 - [https://www.youtube.com/watch?v=OeVRR7JdAX4](https://www.youtube.com/watch?v=OeVRR7JdAX4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg
 - date published: 2020-12-09 00:00:00+00:00

🗺️ Turcja 2020 #18. Ostatnie tygodnie spowodowały, że opuściłem gardę i niestety dałem się nadziać na jedną z pułapek dla turystów z samego rana. Na szczęście przez resztę dnia spotykałem samych fajnych ludzi :)

❗ Zostań Patronem kanału!
https://patronite.pl/vlogcasha

Film Eyupa: https://youtu.be/r6Kur3yKNEw

Vlogi z Turcji (2019-2020): https://bit.ly/31VPCR3
Vlogi z Kolumbii: https://bit.ly/36tqlhH
🌏 Vlogi z Azji Płd-Wsch: https://bit.ly/2wrM9t2
🇦🇺 Vlogi z Australii: https://bit.ly/2OJWYOy
🇺🇸 Vlogi z życia i podróży w USA: https://bit.ly/2ya73NV
🚙Vlogi z autostopu 2018: https://bit.ly/2NbHzos

▸ Instagram: https://www.instagram.com/vlogcasha
▸ Facebook: https://www.facebook.com/vlogcasha/
#PodróżeCasha #CashWTurcji #Turcja

