# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## POCO M3 vs OnePlus Nord N100: baaardzo tanie smartfony
 - [https://www.youtube.com/watch?v=qdFIwA0V7Ko](https://www.youtube.com/watch?v=qdFIwA0V7Ko)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-12-08 00:00:00+00:00

Dziś w odcinku dwa podejrzanie tanie dranie.
POCO M3 (Ceneo): https://bit.ly/3mYyp1B
OnePlus Nord N100 (Proshop, dzieki za wypożyczenie): https://bit.ly/2VRe8iD
Aplikacja ZEN: https://bit.ly/3kWMWc7 (kod przedłużający okres próbny: klawykod)
Moje sociale:
Insta: http://bit.ly/InstaKlawiatur 
Twitter: http://bit.ly/TTKlawitera
FB: http://bit.ly/FBKlawiatur

