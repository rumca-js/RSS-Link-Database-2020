# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## The Oculus Quest 2 just got EVEN BETTER
 - [https://www.youtube.com/watch?v=pNM-Flh49OM](https://www.youtube.com/watch?v=pNM-Flh49OM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-12-08 00:00:00+00:00

Hello and welcome to TUESDAY NEWSDAY! Your number one resource for the entire weeks worth of VR news. hopefully you enjoyed the new intro for the month of December to get into the holiday spirit. Today I will cover some huge Oculus Quest and Quest 2 updates, Google abandoning its VR software, a high school VR eSports league and so much more!

LIMITED EDITION THRILLSEEKER EDITION VRCOVER:
https://int.vrcover.com/products/facial-interface-foam-replacement-set-for-oculus%E2%84%A2-quest-2-thrill-seeker-edition

I will be doing a give away of a signed Thrillseeker edition VRCover on my Twitch stream on Twitch.TV/Thrilluwu but you also have to join the discord server at discord.gg/thrill

My second channel:
https://www.youtube.com/watch?v=Jw2LSc5wzdg
Patreon: https://www.patreon.com/Thrillseeker?fan_landing=true

Links to submit your own school for High School Heroes VR eSports league:
https://www.hsvrleague.com/

outro: Where I belong by Protostar and Emma McGann
https://open.spotify.com/track/6kjl9utzXBGxYGP6FuBDPn?si=-TMWjsNaQnqyylKlxtibjQ

Sources:
https://www.hsvrleague.com/
https://www.roadtovr.com/wacom-unveils-vr-pen-built-next-creative-future/
https://www.roadtovr.com/metro-exodus-arktika-1-4a-games-vr-hiring/
https://uploadvr.com/facebook-phase-sync-quest-latency/
https://uploadvr.com/quest-2-appears-steam-hardware-survey/
https://www.reddit.com/r/VR_memes/comments/k54xfr/vr_at_home/
https://uploadvr.com/google-poly-petition/

