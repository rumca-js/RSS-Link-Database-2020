# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## Glass is Solid… So Why Is It Clear?
 - [https://www.youtube.com/watch?v=FnDP1sjKGfU](https://www.youtube.com/watch?v=FnDP1sjKGfU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2020-12-23 00:00:00+00:00

Thank you to CuriosityStream for supporting PBS! For more information, go to https://curiositystream.com/smart  and USE code SMART.
↓↓↓ More info and sources below ↓↓↓

PBS Member Stations rely on viewers like you. To support your local station, go to: http://to.pbs.org/DonateOKAY

Follow me to Overview on PBS Terra! https://www.youtube.com/watch?v=hjez0W8SPXc 

Glass is made of sand, which is a kind of rock. But glass is transparent, and rocks aren’t transparent. What’s up with that? Why is glass clear? And why can I sit on a chair? And why can we touch anything? Today we zoom down to the weird world of electron clouds and quantum touching to find the answers.

We’re on PATREON! Join the community ►► https://www.patreon.com/itsokaytobesmart
SUBSCRIBE so you don’t miss a video! ►► http://bit.ly/iotbs_sub

-----------

Special thanks to our Brain Trust Patrons:

Ahmed Elkhanany
Emile Edhouse
Zenimal
Salih Arslan
Baerbel Winkler
Denzel Holmes
Robert Young
Amy Sowada
Benjamin Teinby
Eric Meer
Jay Stephens
Peter Ehrnstrom
Oliver and Arden Bradshaw
Dustin
Marcus Tuepker
George gladding
vincbis .
Karen Haskell
AlecZero 
Diego Lombeida
Zenimal

Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/

