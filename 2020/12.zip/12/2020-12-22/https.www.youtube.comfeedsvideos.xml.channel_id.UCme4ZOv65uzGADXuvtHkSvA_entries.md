# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Ewangelia Mateusza ||  Rozdział 25
 - [https://www.youtube.com/watch?v=_l6iqWoQrRA](https://www.youtube.com/watch?v=_l6iqWoQrRA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-12-23 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! 
 
UWAGA WYZWANIE i to życiodajne!
Codziennie razem czytamy 1 rozdział życiodajnego SŁOWA BOGA. 
Dołącz do nas! Razem przeczytamy całe Pismo Święte!

Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.

________________________________________

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Pogromcy potworów [#04] Wilkołak
 - [https://www.youtube.com/watch?v=2i2a2xO2-5g](https://www.youtube.com/watch?v=2i2a2xO2-5g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-12-23 00:00:00+00:00

#rekolekcje #PogromcyPotworów @Langustanapalmie 

Potworami (ogrami, wampirami) możemy nazywać toksyczne postawy, relacje i pragnienia. Ojciec Adam opowiada, jak je w sobie i innych zidentyfikować, pracować nad nimi i naprawić. Podpowiada też, jak zaprosić do tej „pracy” Boga. – Zapraszam cię, byś i ty na ten następny odcinek drogi ku wieczności, którym niewątpliwie będzie kolejny rok twojego życia, wziął Słowo dane nam przez Pana Boga w liturgii. Wierzę, że Ono, jeśli zaczniesz je czytać, rozważać i przykładać do swojego życia, prawdziwie stanie się dla ciebie lampą, która nie tylko oświetla świat wokoło, ale i rozprasza ciemności duszy, żeby nieprzerwanie mogło cię nasycać Boże Światło. Jak zawsze, pozostaje tylko jedno pytanie: czy Mu uwierzysz i otworzysz swoje uszy?
________________________________________

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Roraty [#21]  Nade mną
 - [https://www.youtube.com/watch?v=xCzpiNa4AUQ](https://www.youtube.com/watch?v=xCzpiNa4AUQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-12-23 00:00:00+00:00

#Roraty2020 #Adwent #PrzyjdźPanieJezu

Zamiast WSTAWAKÓW - Roraty na cały ADWENT 2020, czyli trzy i pół tygodnia z Jezusem przyglądającym się Ojcu.

Zapraszamy by włączyć się w Adwentową Akcję Charytatywną Fundacji Malak.

"TROSKA” Adwentowa Akcja Charytatywna rzecz dzieci cierpiących na zaburzenia psychiczne. Do Wigilii będziemy zbierać darowizny na remont i wyposażenie sal pacjentów w Mazowieckim Centrum Neuropsychiatrii. 

“TROSKA” to akcja pełna czułości i delikatności, a przede wszystkim zatroskania.
 
Wszystkie informacje na temat zbiórki będą zamieszczane tutaj:
https://charytatywnie.fundacjamalak.pl/ 

nr konta do wpłat tradycyjnych. 

42 2490 0005 0000 4600 1184 3564 PLN
IBAN: PL 42 2490 0005 0000 4600 1184 3564 
BIC/SWIFT: ALBPPLPW
________________________________________

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Ewangelia Mateusza ||  Rozdział 24
 - [https://www.youtube.com/watch?v=G3NLR0sDKgs](https://www.youtube.com/watch?v=G3NLR0sDKgs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-12-22 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! 
 
UWAGA WYZWANIE i to życiodajne!
Codziennie razem czytamy 1 rozdział życiodajnego SŁOWA BOGA. 
Dołącz do nas! Razem przeczytamy całe Pismo Święte!

Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.

________________________________________

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Roraty [#20] Pociecha
 - [https://www.youtube.com/watch?v=V0l6DQuDeL8](https://www.youtube.com/watch?v=V0l6DQuDeL8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-12-22 00:00:00+00:00

#Roraty2020 #Adwent #PrzyjdźPanieJezu

Zamiast WSTAWAKÓW - Roraty na cały ADWENT 2020, czyli trzy i pół tygodnia z Jezusem przyglądającym się Ojcu.

Zapraszamy by włączyć się w Adwentową Akcję Charytatywną Fundacji Malak.

"TROSKA” Adwentowa Akcja Charytatywna rzecz dzieci cierpiących na zaburzenia psychiczne. Do Wigilii będziemy zbierać darowizny na remont i wyposażenie sal pacjentów w Mazowieckim Centrum Neuropsychiatrii. 

“TROSKA” to akcja pełna czułości i delikatności, a przede wszystkim zatroskania.
 
Wszystkie informacje na temat zbiórki będą zamieszczane tutaj:
https://charytatywnie.fundacjamalak.pl/ 

nr konta do wpłat tradycyjnych. 

42 2490 0005 0000 4600 1184 3564 PLN
IBAN: PL 42 2490 0005 0000 4600 1184 3564 
BIC/SWIFT: ALBPPLPW
________________________________________

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

