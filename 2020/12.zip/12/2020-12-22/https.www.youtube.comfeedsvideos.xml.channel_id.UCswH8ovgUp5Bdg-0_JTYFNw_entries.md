# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Your Cells Are Conscious!!! Awaken This Deep Power
 - [https://www.youtube.com/watch?v=6XmhVB8AIt0](https://www.youtube.com/watch?v=6XmhVB8AIt0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-12-22 00:00:00+00:00

Taken from my Under The Skin podcast with Bruce Lipton! Bruce is a developmental biologist, stem cell biologist, notable for his views on epigenetics. He is the bestselling author of The Biology of Belief.

You can listen to the entire podcast on Luminary: http://luminary.link/russell

www.brucelipton.com
Twitter: @ biologyofbelief
Instagram: @ brucelipton

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

