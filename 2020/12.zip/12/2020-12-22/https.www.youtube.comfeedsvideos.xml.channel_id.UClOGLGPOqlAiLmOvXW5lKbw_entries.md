# Source:Mandalore Gaming, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw, language:en-US

## Battlefleet Gothic: Armada 2 Review
 - [https://www.youtube.com/watch?v=2XbaDEO8IHs](https://www.youtube.com/watch?v=2XbaDEO8IHs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw
 - date published: 2020-12-23 00:00:00+00:00

Battlefleet Gothic Armada 2 is a game about big dumb ships, with a big dumb title to match it. I didn't hear much about it since the first game didn't do so hot on launch.
Support the channel at: https://www.patreon.com/mandaloregaming or https://www.paypal.me/MandaloreGaming
I take video suggestions at mandaloremovies@gmail.com
Twitter: https://twitter.com/Lord_Mandalore
00:00 - Intro
00:39 - Battlefleet Gothic Armada 1
01:52 - Game Premise
02:08 - Visuals
03:38 - Music & Sound Design
06:28 - Battle Gameplay and Mechanics
11:12 - Campaigns & Story
16:27 - Conclusions
17:10 - Credits
18:18 - Stop this

#BattlefleetGothicArmada2 #BattlefleetGothic #BattlefleetGothicGame #Warhammer40K #Warhammer

