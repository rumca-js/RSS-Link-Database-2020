# Source:UpIsNotJump, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFLwN7vRu8M057qJF8TsBaA, language:en-US

## Christmas VR Games Are STILL An Absolute Nightmare - This Is Why
 - [https://www.youtube.com/watch?v=Py9UCdNCwDw](https://www.youtube.com/watch?v=Py9UCdNCwDw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLwN7vRu8M057qJF8TsBaA
 - date published: 2020-12-23 00:00:00+00:00

Go to https://ExpressVPN.com/UpIsNotJump and find out how you can get 3
months free.
IT’S CHRISTMAS AGAIN and 2020 is almost over. SO sit back and relax while we review all the Christmas themed VR games I could find. 

I reviewed almost all the VR games that were about Christmas only last year, and almost no new ones were made, I hope I wasn’t responsible… So instead I looked to all my other VR headsets for Christmas themed VR games. We cover the Oculus Quest 2, the Vive, the Index, The Rift and I played some VR phone games… but they were terrible.

The Rift had a number of Christmas themed VR games that I played but didn’t review in this video, simply because they were terrible.

Anyway. Merry Christmas and happy holidays. Enjoy my Christmas themed VR bonanza.

All my music and sound is from here: https://www.epidemicsound.com/referral/8pficg

Patreon: https://www.patreon.com/UpIsNotJump 
Merch: https://www.pixelempire.com/products/... 
Twittz: https://twitter.com/UpIsNotJump

Edit Workflow by Milo at Speedwagon Productions www.speedwagon.me

Super special thanks to my members!
Corbin Carter
GreenCoatGaming
TheMediaJack

Dance of the Sugar Plum Fairy by Kevin MacLeod is licensed under a Creative Commons Attribution 4.0 licence. https://creativecommons.org/licenses/by/4.0/
Source: http://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100270
Artist: http://incompetech.com/

