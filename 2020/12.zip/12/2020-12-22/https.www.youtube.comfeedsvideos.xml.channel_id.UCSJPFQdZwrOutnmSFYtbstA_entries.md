# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## The Mandalorian Season 2 - Fun But Formulaic
 - [https://www.youtube.com/watch?v=S_J70TgCqV4](https://www.youtube.com/watch?v=S_J70TgCqV4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-12-22 00:00:00+00:00

With Season 2 of The Mandalorian now over, it's time to find out if it was worth the wait.

