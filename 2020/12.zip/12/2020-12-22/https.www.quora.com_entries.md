## Why is Facebook censoring private messages?
 - [https://www.quora.com/Why-is-Facebook-censoring-private-messages?share=1](https://www.quora.com/Why-is-Facebook-censoring-private-messages?share=1)
 - RSS feed: https://www.quora.com
 - date published: 2020-12-22 14:19:18+00:00

Why is Facebook censoring private messages?

