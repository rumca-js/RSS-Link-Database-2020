# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Smartphone Awards 2020!
 - [https://www.youtube.com/watch?v=e6_t26Q9aVM](https://www.youtube.com/watch?v=e6_t26Q9aVM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-12-23 00:00:00+00:00

The Best of Smartphones in 2020!
🏆 Show more for all links/phones 🏆

0:00 Intro
1:42 Best Big Smartphone
4:08 Best Compact Smartphone
6:18 Best Camera Phone
8:28 Best Battery
10:10 The Design Award
14:20 Best Budget Phone
16:56 Bust of the Year
18:44 Most Improved Award
20:52 Phone of the Year

iPhone 12 mini Review: https://youtu.be/Yhze-aRR6o0
iPhone 12 Pro Max Review: https://youtu.be/qrzCLgDplTw
Asus ROG Phone III Review: https://youtu.be/IEwEDTmqCEs
Samsung Galaxy Note 20 Ultra Review: https://youtu.be/R94ntpWVelw
Google Pixel 4A Review: https://youtu.be/dlHnleQU9tQ
Galaxy Note 20 Review: https://youtu.be/Exk34o-MMIE
Galaxy Fold 2 Review: https://youtu.be/G4E2bbAgjXg
Galaxy S20 FE Review: https://youtu.be/azrdcp4yYas

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: http://youtube.com/20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

