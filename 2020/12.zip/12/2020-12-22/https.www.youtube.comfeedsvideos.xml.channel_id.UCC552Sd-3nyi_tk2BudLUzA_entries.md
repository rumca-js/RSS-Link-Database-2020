# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## We Drank Alcohol For 12 Hours And It Changed Our Faces
 - [https://www.youtube.com/watch?v=n-2ZU2HzFt0](https://www.youtube.com/watch?v=n-2ZU2HzFt0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2020-12-23 00:00:00+00:00

We tested the impact of binge drinking on attractiveness.
Sidenote Podcast on Drinking: https://youtu.be/Fr5viO0rAMM

With new lockdowns, quarantine and staying at home orders in place, we started to notice how drinking at home can change your face. Instead of watching the great conjunction, we stayed home and drank (it was cloudy anyways). We explain why you get drunk, how it changes your biochemistry, what impact that has on your face, and finally how hangover essentially make you ... ugly.

FOLLOW US!
Greg
Instagram: https://instagram.com/whalewatchmeplz 
Twitter: https://twitter.com/whalewatchmeplz 

Mitch
Instagram: https://instagram.com/mitchellmoffit
Twitter: https://twitter.com/mitchellmoffit 

ASAPScience
Instagram: https://instagram.com/asapscience 
Facebook: https://facebook.com/asapscience 
Twitter: https://twitter.com/asapscience

References:
https://pubmed.ncbi.nlm.nih.gov/28988577/
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3484320/
https://pubmed.ncbi.nlm.nih.gov/26976505/
https://pubmed.ncbi.nlm.nih.gov/26166661/
https://www.medicaldaily.com/heres-why-you-vomit-after-drinking-alcohol-and-how-feel-better-after-getting-417916
https://pubmed.ncbi.nlm.nih.gov/23101976/
http://onlinelibrary.wiley.com.subzero.lib.uoguelph.ca/doi/10.1111/acer.12698/full 
https://pubmed.ncbi.nlm.nih.gov/29355349/
http://pubs.niaaa.nih.gov/publications/AlcoholOverdoseFactsheet/Overdosefact.htm

