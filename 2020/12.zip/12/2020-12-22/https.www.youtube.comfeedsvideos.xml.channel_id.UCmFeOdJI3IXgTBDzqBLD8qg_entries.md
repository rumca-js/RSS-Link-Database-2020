# Source:Moon, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg, language:en-US

## Why Men Are Weaker Than Ever
 - [https://www.youtube.com/watch?v=PVrjozFHCr4](https://www.youtube.com/watch?v=PVrjozFHCr4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg
 - date published: 2020-12-23 00:00:00+00:00

This was taken from Bdobbinsftw. All credit to Bdobbinsftw for this video: Please check out his channel it’s incredible


Belle Delphine makes over £1 million a month from only fans. Who funds this? Simps. 

This is a product of our modern society making us feel more and more worthless by the year. This is some real education.

***Apologise for the audio issues, half way through recording my mic became faulty***

THANK YOU FOR WATCHING!

