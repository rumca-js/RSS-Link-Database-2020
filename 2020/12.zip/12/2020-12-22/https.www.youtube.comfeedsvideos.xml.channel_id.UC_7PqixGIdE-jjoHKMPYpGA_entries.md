# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Kiedy zwierzęta mówią ludzkim głosem?
 - [https://www.youtube.com/watch?v=5tdhWc6g0Wc](https://www.youtube.com/watch?v=5tdhWc6g0Wc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2020-12-23 00:00:00+00:00

👉 Patronite ► https://patronite.pl/NaukowyBelkot 
👕 Nasze koszulki ► https://naukowybelkot.shoplo.com/
📚 Moja książka ► https://altenberg.pl/geny/
🎧 Mix audio ► http://ratstudios.pl/

Są Święta - jest odcinek w swetrze. Jak zawsze jest też świąteczny temat. Tym razem, konkretnie, wigilijny. Z gościnnym udziałem zwierzątek.

🎞 Film o komunikacji roślin:
https://www.youtube.com/watch?v=tfrpBCtMM9k

🎞 Film o poczuciu winy psów:
https://www.youtube.com/watch?v=7nGj2Z1bnJg

🎞 Film o mruganiu do kota:
https://www.youtube.com/watch?v=f_ZZbp-n3Cg

🎞 Filmy o feromonach (bardzo stare):
https://www.youtube.com/watch?v=dNhDuaNpMbg
https://www.youtube.com/watch?v=KbIoKFHKFm8

🎞 Film o cholerze, z elementem komunikacji bakterii:
https://www.youtube.com/watch?v=BS2vwkhml5g

Subskrypcja ► https://youtube.com/c/UwagaNaukowyBelkot
Facebook ► https://facebook.com/UwagaNaukowyBelkot
Twitter ► https://twitter.com/NaukowyBelkot
Instagram ► https://www.instagram.com/NaukowyBelkot/

Wyłącznie Naukowy Bełkot ► https://goo.gl/Do7VCc
Grupa na facebooku ► https://goo.gl/HP8J83

===
Rozkład jazdy:

0:00 Kluczowa informacja
2:08 Jak i o czym?
9:00 Czy to język?
13:42 Ludzkim głosem?
21:08 Wesołych Świąt!

#święta #sweter #zwierzęta

