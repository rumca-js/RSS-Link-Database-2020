## Coronavirus French Law Would Ban People Who Don’t Get COVID Vaccine From Using Public Transport
 - [https://summit.news/2020/12/22/french-law-would-ban-people-who-dont-get-covid-vaccine-from-using-public-transport/](https://summit.news/2020/12/22/french-law-would-ban-people-who-dont-get-covid-vaccine-from-using-public-transport/)
 - RSS feed: https://summit.news
 - date published: 2020-12-22 22:07:50+00:00

Coronavirus French Law Would Ban People Who Don’t Get COVID Vaccine From Using Public Transport

