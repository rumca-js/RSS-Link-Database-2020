# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Die Hard Christmas Movie BATTLE Settles Debate
 - [https://www.youtube.com/watch?v=cyv68ArwKMI](https://www.youtube.com/watch?v=cyv68ArwKMI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-12-23 00:00:00+00:00

When celestial movie snobs decide to once and for all settle if Die Hard and other movies are or are not Christmas movies by forcing them into a battle to the death, Santa intervenes and they all break into song. 

Featuring all of your favorite "almost Christmas movie" stars including John McClane of Die Hard, Snow White, Riggs and Murtaugh of Lethal Weapon, Jack Skellington, Jack Torrance from The Shining, Gremlins, Judge Dredd, and more. 

Natalie Van - Snow White (vocals)
Instagram: @imnatalievan 
Facebook: https://www.facebook.com/imnatalievan

Record/Mix/Master - Lorenz
Facebook: https://www.facebook.com/delostudio

LYRICS:
This world is full of killjoys who want to murder cheer
They deny Die Hard is a Christmas movies every single year

But Jack Torrance is Christmas chopping then relaxing in the snow 
Three Ninjas is basically a rip off of Home Alone
Gremlins in the blender made a festive green and red
And Martin Riggs bought Christmas trees with a gun up to his head

Every movie is a Christmas movie all it needs is snow
Or a dead terrorist without a machine gun ho ho ho ho
Mean Girls, Gremlins, Lethal Weapon, and Iron Man 3
Batman Returns, The Long Kiss Goodnight, Rent and Jumanji
All have Christmas trees, so they’re all Christmas movies 
Joy to the world

Freddy Kruger wore a Christmas Sweater
Then there’s Kiss Kiss Bang Bang
Every Shane Black movie is more Christmasy than a candy cane
Edward Scissorhands cutting ribbons with his thumb 
Groundhog day is too good for a holiday so dumb
And captain America had that winter soldier, hey that’s good enough

Every movie is a Christmas movie all it needs is snow
Or a dead terrorist without a machine gun ho ho ho ho
Mean Girls, Gremlins, Lethal Weapon, and Iron Man 3
Batman Returns, The Long Kiss Goodnight, Rent and Jumanji
All have Christmas trees, so they’re all Christmas movies 
Joy to the world your opinions are dumb
They’re all Christmas movies!

## The Justin Dyer Interview: Narnian Natural Law
 - [https://www.youtube.com/watch?v=0K09CZU-CQE](https://www.youtube.com/watch?v=0K09CZU-CQE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-12-22 00:00:00+00:00

Today on The Babylon Bee Podcast, Kyle and Ethan talk to professor of political science Justin Dyer, author of C. S. Lewis on Politics and the Natural Law and director of the Kinder Institute on Constitutional Democracy.  Topics range from C.S. Lewis’ view on natural law, being a classical liberal, and how C.S. Lewis wanted all kids off his lawn. 

Watch The Babylon Bee animation on our animation playlist: https://bit.ly/BeeAnimation  

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Submit Your Own Headlines: https://babylonbee.com/plans

The Official The Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

