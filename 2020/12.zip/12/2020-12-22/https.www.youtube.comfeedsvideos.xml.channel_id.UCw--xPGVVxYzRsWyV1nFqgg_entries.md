# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Axiom's End/Heaven's River - REVIEW
 - [https://www.youtube.com/watch?v=oS-zPuTyiFo](https://www.youtube.com/watch?v=oS-zPuTyiFo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-12-23 00:00:00+00:00

My review of both Axiom's End by Lindsay Elis and Heaven's River by Dennis E. Taylor. Let's talk Bobiverse! 

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

## Ready Player Two Movie?🎥 State Of Sanderson 2020!🌌 Halo TV Show First Look🪖 -FANTASY NEWS
 - [https://www.youtube.com/watch?v=NBfO8BQKCro](https://www.youtube.com/watch?v=NBfO8BQKCro)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-12-22 00:00:00+00:00

Let's talk the FANTASY NEWS!

Check out Campfire here: http://www.campfireblaze.com/?utm_source=youtube&utm_medium=video&utm_campaign=Greene4.20 

Use Code: HOLIDAYBLAZE

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/


00:00 Intro
00:34 State Of Sanderson: https://www.brandonsanderson.com/state-of-the-sanderson-2020/ 
03:24 Wizards of the Coast Lawsuit Update: https://twitter.com/WeisMargaret/status/1340350657690292224 
04:18 Ready Player Two Movie: https://www.inverse.com/entertainment/ready-player-two-movie-ernest-cline-interview 
05:20 Pierce Brown Movie: https://www.instagram.com/p/CI1Rlr4F6bA/?igshid=7ltpzj8mepw3
06:42 Shadow and Bone Teaser: https://www.youtube.com/watch?v=Hf91m13vIWo&feature=youtu.be 
06:51 Halo First Look: https://comicbook.com/gaming/news/halo-tv-series-pictures-covenant-cortana/
07:38 Wonder Woman Box Office: https://www.hollywoodreporter.com/amp/news/box-office-wonder-woman-1984-opens-to-woeful-18-8m-in-china-for-38-5m-foreign-start?utm_source=Sailthru&utm_medium=email&utm_campaign=THR%20Box%20Office&utm_term=hollywoodreporter_boxoffice
09:17 Space Race is BACK ON (But boring now): https://news.sky.com/story/russia-seeks-actress-to-send-in-to-space-for-feature-film-shot-on-iss-12124448

