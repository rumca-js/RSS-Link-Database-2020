# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## The Dirty Details of the New $900B Stimulus Bill
 - [https://www.youtube.com/watch?v=VoUD5MDfCEM](https://www.youtube.com/watch?v=VoUD5MDfCEM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-12-23 00:00:00+00:00

the 2020 Stimulus Checks are everything wrong with America. 
read the full bill here: https://www.cnn.com/2020/12/21/politics/new-covid-stimulus-bill-text/index.html
twitter: https://twitter.com/coffeebreak_YT
instagram: https://www.instagram.com/coffeebreak_yt/
this video is an opinion and in no way should be construed as statements of fact. scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napolean Hill pitch.

UPDATE: There's talks of actually getting the $2K stimulus done... will give you a stimulus check update if it happens.

