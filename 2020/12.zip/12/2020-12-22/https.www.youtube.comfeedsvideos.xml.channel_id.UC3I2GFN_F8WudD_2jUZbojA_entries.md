# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Musical Greeting Cards from KEXP
 - [https://www.youtube.com/watch?v=WioV3vyLtWE](https://www.youtube.com/watch?v=WioV3vyLtWE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-12-23 00:00:00+00:00

Happy Holidays from all of us at KEXP to you! This year has brought unbelievable challenges - but thanks to incredible artists, inspiring music, and the support of listeners and viewers like you, we've all made it through. As a thank you for your continued viewership and support, we present Musical Greeting Cards, featuring seasons greetings from KEXP DJs and artists, and live recordings by Deep Sea Diver, Adia Victoria, Calexico, Rufus Wainwright, Patterson Hood of Drive-By Truckers and Black Pumas. 

Gabriel Teodros
Jessica Dobson of Deep Sea Diver - "Have Yourself a Merry Little Christmas"
Beabadoobee
Adia Victoria - "Silent Night"
Cheryl Waters (KEXP)
Joey Burns of Calexico - "Happy Xmas (War Is Over)"
Albina Cabrera (KEXP)
Rufus Wainwright - "Hallelujah"
Nikki Monninger of Silversun Pickups
Patterson Hood of Drive-By Truckers - "Mrs. Claus' Kimono"
Morgan (KEXP)
Black Pumas - "Christmas Will Really Be Christmas"

http://kexp.org

## Rufus Wainwright - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=Wzyq_96F0ZY](https://www.youtube.com/watch?v=Wzyq_96F0ZY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-12-22 00:00:00+00:00

http://KEXP.ORG presents Rufus Wainwright performing songs recorded exclusively for KEXP.

Songs:
Trouble in Paradise 
My Little You
Unfollow the Rules
Alone Time

Piano - Jacob Mann
Audio Engineer - Chris Sorem 
Videographer - Ryan Glatt

https://rufuswainwright.com
http://kexp.org

