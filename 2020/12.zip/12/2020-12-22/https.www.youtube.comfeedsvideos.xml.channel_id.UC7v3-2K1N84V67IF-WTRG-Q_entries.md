# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Wonder Woman 1984 - Movie Review
 - [https://www.youtube.com/watch?v=MxEwMFe7hvc](https://www.youtube.com/watch?v=MxEwMFe7hvc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-12-23 00:00:00+00:00

WONDER WOMAN 1984 is coming to HBO Max soon, so here's my review to get you prepped!

#WonderWoman1984 #WW84

