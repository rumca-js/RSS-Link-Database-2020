# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## The FIRST REAL Ready Player One VR Immersion Rig
 - [https://www.youtube.com/watch?v=yxIkKwMvG2M](https://www.youtube.com/watch?v=yxIkKwMvG2M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-12-22 00:00:00+00:00

Hello and welcome to TUESDAY NEWSDAY! Your number one resource for the entire weeks worth of VR news. Today I have some really wacky news about a VR exoskeleton suit created that reminds me a whole lot of the giant immersion rigs from the book Ready Player One. Some more Oculus, beat saber and AR news as well! Also MAKE SURE YOU CHECK OUT VIRTUAL MARKET 5 while it's around. You won't be disappointed. 

My links:
Twitch Stream TODAY!
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill

Outro Music: Protostar Where I Belong

Sources:
https://www.roadtovr.com/jurassic-world-aftermath-quest-release-date-price-dlc/
https://www.roadtovr.com/leaked-lenovo-ar-glasses-ces-2021/
https://newatlas.com/vr/holotron-virtual-rreality-haptic-exoskeleton/
https://uploadvr.com/beat-saber-ost-4-2021/
https://www.vrfocus.com/2020/11/review-star-wars-tales-from-the-galaxys-edge/

