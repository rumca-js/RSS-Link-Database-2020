# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Xbox is Backwards Compatible with... Everything?? - Dev Mode Emulation
 - [https://www.youtube.com/watch?v=xJ5aqx02QDI](https://www.youtube.com/watch?v=xJ5aqx02QDI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-12-23 00:00:00+00:00

Check out https://myruggable.com/linus10 and use offer code LINUS10 to save 10%

Check out Seasonic products:
On Amazon: https://geni.us/q4lnefC
On Newegg: https://lmg.gg/8KV3S

Do you have a TV stand FULL of old consoles? What if I told you that you can reduce it to ONE machine for around $20, assuming you already have an Xbox? Don’t believe me? Watch and find out how.

Buy Microsoft Xbox Series S
On Amazon (PAID LINK): https://geni.us/I2K9gD
On Newegg (PAID LINK): https://geni.us/42vr3
On B&H (PAID LINK): https://geni.us/gQzAPan

Buy Microsoft Xbox Series X
On Amazon (PAID LINK): https://geni.us/GMRv
On Best Buy (PAID LINK): https://geni.us/KxZvpQA
On Newegg (PAID LINK): https://geni.us/FtIu

Buy Xbox Core Controller
On Amazon (PAID LINK): https://geni.us/FpA7x
On Best Buy (PAID LINK): https://geni.us/yrxrX
On Newegg (PAID LINK): https://geni.us/YAmsX7q

Buy Crucial X8 1TB Portable SSD
On Amazon (PAID LINK): https://geni.us/9cFp
On B&H (PAID LINK): https://geni.us/faUK
On Newegg (PAID LINK): https://geni.us/AFgKz

Buy LG SIGNATURE ZX 88" 8K TV
On Amazon (PAID LINK): https://geni.us/x8oD0pt
On Best Buy (PAID LINK): https://geni.us/ap5neXn
On B&H (PAID LINK): https://geni.us/e8vZlPA

Buy Elgato HD60 S
On Amazon (PAID LINK): https://geni.us/rz3Z
On Best Buy (PAID LINK): https://geni.us/ka7F62
On Newegg (PAID LINK): https://geni.us/tjGYWWb

Buy Playstation Classic Console
On Amazon (PAID LINK): https://geni.us/D17bp
On Newegg (PAID LINK): https://geni.us/moBRM
Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1284701-xbox-is-backwards-compatible-with%E2%80%A6-everything/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Official Game Store: https://www.nexus.gg/ltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

## Can static KILL your PC? (ft. Electroboom)
 - [https://www.youtube.com/watch?v=nXkgbmr3dRA](https://www.youtube.com/watch?v=nXkgbmr3dRA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-12-22 00:00:00+00:00

Thanks to Seasonic for sponsoring this video! Learn more about Seasonic products:
On Amazon (PAID LINK): https://geni.us/q4lnefC
On Newegg (PAID LINK): https://lmg.gg/8KV3S

Just how dangerous is static electricity to your PC? Are ESD wrist bands just a "big tech" scam, or are they a necessity to protect your much-loved gaming rig? Linus and ElectroBOOM investigate. 

Check out ElectroBOOM's video here: https://youtu.be/4SjOv_szzVM 

Buy a ESD Gun
On Amazon (PAID LINK): https://geni.us/ESDgun

Buy Anti-static Wrist Straps
On Amazon (PAID LINK): https://geni.us/ZhcGhN
On Best Buy (PAID LINK): https://geni.us/FnnJQ
On Newegg (PAID LINK): https://geni.us/kMcQ44n

Buy ESD bags
On Amazon (PAID LINK): https://geni.us/d8Nm
On Newegg (PAID LINK): https://geni.us/e2rD4

Buy Tesla Coil Kit
On Amazon (PAID LINK): https://geni.us/73pP
On Newegg (PAID LINK): https://geni.us/HG9Gd

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1284316-can-static-kill-your-pc-ft-electroboom/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Official Game Store: https://www.nexus.gg/ltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

