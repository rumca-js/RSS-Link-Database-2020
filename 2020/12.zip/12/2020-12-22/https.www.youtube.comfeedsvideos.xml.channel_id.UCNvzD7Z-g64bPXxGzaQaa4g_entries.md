# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Cyberpunk 2077: MORE Dumb Yet Hilarious Glitches
 - [https://www.youtube.com/watch?v=wtuKAcooDv0](https://www.youtube.com/watch?v=wtuKAcooDv0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-12-23 00:00:00+00:00

Cyberpunk 2077 is filled with hilarious glitches and bugs, so we asked you to submit anything you encountered. Here are some of the best submissions.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 10 Video Game Things That DIED in 2020
 - [https://www.youtube.com/watch?v=TSWAN8LokoI](https://www.youtube.com/watch?v=TSWAN8LokoI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-12-22 00:00:00+00:00

Video games are always moving forward. Here are some trends, games, and other gaming related things that died off in 2020.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

