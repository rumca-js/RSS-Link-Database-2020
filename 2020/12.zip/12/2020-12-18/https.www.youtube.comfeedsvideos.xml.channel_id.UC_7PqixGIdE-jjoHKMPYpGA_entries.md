# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## O cholera - czyli jak stracić 15 kilogramów w jeden dzień
 - [https://www.youtube.com/watch?v=BS2vwkhml5g](https://www.youtube.com/watch?v=BS2vwkhml5g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2020-12-18 00:00:00+00:00

👉 Patronite ► https://patronite.pl/NaukowyBelkot 
👕 Nasze koszulki ► https://naukowybelkot.shoplo.com/
📚 Moja książka ► https://altenberg.pl/geny/
🎧 Mix audio ► http://ratstudios.pl/

===
🎞 Film o Semmelweisie
https://www.youtube.com/watch?v=Pn2meI8A8KM

===
Timeline:
0:00 Łacińskie sentencje
2:10 Wstęp
5:06 Rozwinięcie
9:27 Zakończenie?
14:41 Lekcja z historii

Subskrypcja ► https://youtube.com/c/UwagaNaukowyBelkot
Facebook ► https://facebook.com/UwagaNaukowyBelkot
Twitter ► https://twitter.com/NaukowyBelkot
Instagram ► https://www.instagram.com/NaukowyBelkot/

Wyłącznie Naukowy Bełkot ► https://goo.gl/Do7VCc
Grupa na facebooku ► https://goo.gl/HP8J83

===
Źródła:

S. Shah - Epidemia,
D. Quamen - Spillover
A. Collen - 10% Human
E. Yong - I Contain Multitudes
A. J. Tatem - Global Transport Networks and Infectious Disease Spread
J. N. Hayes - Epidemics and Pandemics: Their Impacts on Human History
S. Faruque i in. - Vibrio Cholerae: Genomics and Molecular Biology


===
Źródła grafik:

Copyrighted free use, https://commons.wikimedia.org/w/index.php?curid=197609
By Andrei Savitsky - Own work, CC BY-SA 4.0, https://commons.wikimedia.org/w/index.php?curid=78800127
By Ernst Haeckel - Kunstformen der Natur (1904), plate 56: Copepoda (see here, here and here), Public Domain, https://commons.wikimedia.org/w/index.php?curid=596944
By https://wellcomeimages.org/indexplus/obf_images/be/50/8cde076b6565799c79ac7ae9a048.jpgGallery: https://wellcomeimages.org/indexplus/image/V0010489.htmlWellcome Collection gallery (2018-04-01): https://wellcomecollection.org/works/rjdzbsuq CC-BY-4.0, CC BY 4.0, https://commons.wikimedia.org/w/index.php?curid=36452945

