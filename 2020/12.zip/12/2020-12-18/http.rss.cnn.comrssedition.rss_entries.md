# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Keilar calls out GOP hypocrisy over Biden aide swearing
 - [https://www.cnn.com/videos/politics/2020/12/18/jen-o-malley-dillon-biden-republicans-comments-keilar-roll-the-tape-sot-vpx-nr.cnn](https://www.cnn.com/videos/politics/2020/12/18/jen-o-malley-dillon-biden-republicans-comments-keilar-roll-the-tape-sot-vpx-nr.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 21:45:48+00:00

CNN's Brianna Keilar rolls the tape on Republicans' hypocrisy over comments made by Jen O'Malley Dillon, President-elect Joe Biden's campaign manager and incoming White House deputy chief of staff, where she used profanity to refer to congressional Republicans.

## Tension rises between Pentagon and Biden transition team over meetings
 - [https://www.cnn.com/2020/12/18/politics/pentagon-dod-transition-briefings/index.html](https://www.cnn.com/2020/12/18/politics/pentagon-dod-transition-briefings/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 20:43:49+00:00

President-elect Joe Biden's transition team said Friday that they did not agree to a two-week break in critical transfer-of-power discussions with Pentagon officials, despite an assertion from the acting Defense Secretary that both sides had agreed to take such a "holiday pause."

## The restaurant apocalypse is here
 - [https://www.cnn.com/2020/12/18/politics/what-matters-end-of-restaurants/index.html](https://www.cnn.com/2020/12/18/politics/what-matters-end-of-restaurants/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 19:56:29+00:00

American restaurants are dying and Covid is killing them. More than 110,000 US restaurants have closed during the pandemic -- and more are likely to shut, with winter limiting outdoor options, cases surging and states imposing new restrictions.

## The pandemic shut down her chateau. Then she became a YouTube star
 - [https://www.cnn.com/travel/article/french-chateau-owner-pandemic-living/index.html](https://www.cnn.com/travel/article/french-chateau-owner-pandemic-living/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 19:53:54+00:00

"The Chateau Diaries," the unlikely YouTube quarantine hit, has made a star of Stephanie Jarvis and her friends and family. Find out how they've lived in a French chateau during the pandemic.

## No-deal Brexit looms as truck drivers queue for hours at port
 - [https://www.cnn.com/videos/business/2020/12/18/brexit-dover-trade-deal-anna-stewart-pkg-intl-ldn-vpx.cnn](https://www.cnn.com/videos/business/2020/12/18/brexit-dover-trade-deal-anna-stewart-pkg-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 19:39:50+00:00

As the possibility of no Brexit deal continues to loom, UK firms are stockpiling and putting pressure on already pandemic-pressed ports. CNN's Anna Stewart meets some of the truck drivers waiting hours in line as well as a company taking a different approach.

## With evictions ban expiring soon, new housing crisis could threaten minorities most
 - [https://www.cnn.com/2020/12/18/us/minorities-evictions-coronavirus/index.html](https://www.cnn.com/2020/12/18/us/minorities-evictions-coronavirus/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 19:27:44+00:00

A federal ban on evictions expires at the end of the year, and it's sparking fears of a housing crisis that could disproportionately send people of color out of their homes.

## A homeless man sentenced to life in prison for a $20 marijuana sale is freed after 12 years
 - [https://www.cnn.com/2020/12/18/us/fate-winslow-louisiana-release-trnd/index.html](https://www.cnn.com/2020/12/18/us/fate-winslow-louisiana-release-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 19:24:45+00:00

In 2008, Fate Winslow was approached by a plain-clothed undercover police officer in Shreveport, Louisiana, looking for some marijuana.

## Rescued Nigerian schoolboys brought back to families in state capital
 - [https://www.cnn.com/2020/12/18/africa/rescued-nigerian-schoolboys-state-government-intl/index.html](https://www.cnn.com/2020/12/18/africa/rescued-nigerian-schoolboys-state-government-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 18:44:14+00:00

Horrific tales of beatings and endurance emerged on Friday as more than 300 boys rescued from captivity in northwestern Nigeria were brought back to their waiting families in the state capital, ending a week-long ordeal.

## Cops discover an illegal winery operating out of an Alabama town's sewage plant
 - [https://www.cnn.com/2020/12/18/us/alabama-illegal-winery-trnd/index.html](https://www.cnn.com/2020/12/18/us/alabama-illegal-winery-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 18:20:20+00:00

Authorities say they've busted a large illegal winery operating out of a wastewater treatment plant in a small Alabama town.

## Man drops iPhone from plane while it's filming
 - [https://www.cnn.com/videos/business/2020/12/18/iphone-plane-fall-moos-pkg-vpx.cnn](https://www.cnn.com/videos/business/2020/12/18/iphone-plane-fall-moos-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 18:19:50+00:00

An iPhone falls from a plane with the video rolling and survives to tell the tale. CNN's Jeanne Moos reports.

## Here's why McDonald's restaurants are putting cameras in their dumpsters
 - [https://www.cnn.com/2020/12/18/tech/compology-artificial-intelligence/index.html](https://www.cnn.com/2020/12/18/tech/compology-artificial-intelligence/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 17:36:40+00:00

Jason Gates spends a lot of his time thinking about trash, and how we can generate less of it.

## US bans China's top chipmaker from using American technology
 - [https://www.cnn.com/2020/12/18/tech/smic-us-sanctions-intl-hnk/index.html](https://www.cnn.com/2020/12/18/tech/smic-us-sanctions-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 17:14:34+00:00

China's top chipmaker was already having a rough week. Now its problems are getting much worse.

## 'Billie Eilish: The World's A Little Blurry' trailer released by Apple
 - [https://www.cnn.com/2020/12/18/entertainment/billie-eilish-apple-scli-intl/index.html](https://www.cnn.com/2020/12/18/entertainment/billie-eilish-apple-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 16:46:10+00:00

Apple TV+ has released a trailer for its much-anticipated documentary about the American singer and songwriter Billie Eilish.

## Venezuela is quietly quitting socialism
 - [https://www.cnn.com/2020/12/18/americas/venezuela-death-of-socialism-intl/index.html](https://www.cnn.com/2020/12/18/americas/venezuela-death-of-socialism-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 16:41:18+00:00

Shantytowns surround Caracas, Venezuela's capital, like the walls of a bowl. Little houses pile on each other on the steep hills, some reachable only by vertiginous staircases.

## Supreme Court throws out challenge to Trump's plan to exclude undocumented immigrants from census count
 - [https://www.cnn.com/2020/12/18/politics/supreme-court-census-undocumented-immigrants/index.html](https://www.cnn.com/2020/12/18/politics/supreme-court-census-undocumented-immigrants/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 16:23:22+00:00

The Supreme Court on Friday threw out a challenge to President Donald Trump's bid to exclude undocumented immigrants from being counted when seats in Congress are divvied up between the states next year.

## Dr. Gupta gets his Covid-19 vaccine. This feels significant
 - [https://www.cnn.com/videos/health/2020/12/18/dr-sanjay-gupta-receives-coronavirus-vaccine-newday-vpx.cnn](https://www.cnn.com/videos/health/2020/12/18/dr-sanjay-gupta-receives-coronavirus-vaccine-newday-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 16:07:48+00:00

CNN's Dr. Sanjay Gupta takes us behind the scenes with him as he gets the coronavirus vaccine at Grady Memorial Hospital in Atlanta, Georgia.

## Barack Obama lists his favorite books of 2020
 - [https://www.cnn.com/2020/12/18/politics/obama-favorite-books-2020-trnd/index.html](https://www.cnn.com/2020/12/18/politics/obama-favorite-books-2020-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 16:04:52+00:00

In a year that saw many traditions upended, former President Barack Obama is keeping up with one annual custom: sharing his favorite books of the year.

## Tucker Carlson claims vaccine campaign 'feels false, because it is'
 - [https://www.cnn.com/videos/business/2020/12/18/tucker-carlson-vaccine-false-jba-lon-orig.cnn](https://www.cnn.com/videos/business/2020/12/18/tucker-carlson-vaccine-false-jba-lon-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 15:20:25+00:00

Fox News' Tucker Carlson defied scientific consensus to sow doubt about Covid-19 vaccine efforts. In large clinical trials, the vaccine has been determined safe and effective.

## Chadwick Boseman's final 'Ma Rainey's Black Bottom' role could put him in select Oscar company
 - [https://www.cnn.com/2020/12/18/entertainment/chadwick-boseman-posthumous-oscars/index.html](https://www.cnn.com/2020/12/18/entertainment/chadwick-boseman-posthumous-oscars/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 14:31:32+00:00

"Ma Rainey's Black Bottom" premieres on Netflix on Dec. 18, representing Chadwick Boseman's final role, in an adaptation of the August Wilson play. The emotional outpouring that surrounded Boseman's untimely death from cancer has fueled speculation about whether he will join a select club: Those who have received posthumous Academy Awards.

## Alibaba 'dismayed' by reports its software was used to identify Uyghurs
 - [https://www.cnn.com/2020/12/18/tech/alibaba-cloud-ipvm-uyghurs-intl-hnk/index.html](https://www.cnn.com/2020/12/18/tech/alibaba-cloud-ipvm-uyghurs-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 14:09:19+00:00

Alibaba says that it has stopped trying to identify faces by ethnicity after the company was accused this week of creating a facial recognition system meant to detect Uyghurs.

## The world's most famous works -- created with everyday household items
 - [https://www.cnn.com/style/article/getty-museum-challenge-art/index.html](https://www.cnn.com/style/article/getty-museum-challenge-art/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 13:19:40+00:00

Earlier this year, the Covid-19 pandemic brought life as we knew it to a halt. Much of the world retreated to a solitary life at home. Working remotely, we, at the Getty Museum, asked ourselves how art could be a tonic for people through these uncertain times. Our community asked for fun distraction, and education, too -- thus the art challenge was born. The prompt? Pick a favorite artwork, find three objects in your house, re-create the work with those items, and share with us online.

## UK spy agency challenges 'wise men and women' to solve Christmas card puzzle
 - [https://www.cnn.com/2020/12/18/uk/gchq-christmas-card-puzzle-scli-intl-gbr/index.html](https://www.cnn.com/2020/12/18/uk/gchq-christmas-card-puzzle-scli-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 13:17:38+00:00

The UK's largest spy agency GCHQ has sent out its annual Christmas card complete with a brainteaser.

## Regulators turned on Big Tech this week. Now for the good news
 - [https://www.cnn.com/2020/12/18/investing/premarket-stocks-trading/index.html](https://www.cnn.com/2020/12/18/investing/premarket-stocks-trading/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 12:56:51+00:00

It's been a tough week for Big Tech. But there's finally some good news for social media companies.

## Wayne Rooney's son Kai signs for Manchester United's academy
 - [https://www.cnn.com/2020/12/18/football/wayne-rooney-son-kai-signs-manchester-united-spt-intl/index.html](https://www.cnn.com/2020/12/18/football/wayne-rooney-son-kai-signs-manchester-united-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 12:45:25+00:00

Football talent clearly runs in the genes of the Rooney family.

## Exclusive: A $5 billion foundation literally founded on oil money is saying goodbye to fossil fuels
 - [https://www.cnn.com/2020/12/18/investing/rockefeller-foundation-divest-fossil-fuels-oil/index.html](https://www.cnn.com/2020/12/18/investing/rockefeller-foundation-divest-fossil-fuels-oil/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 12:10:15+00:00

The Rockefeller Foundation, a 107-year-old philanthropy built by oil tycoon John D. Rockefeller, is breaking up with fossil fuels in an effort to save the planet.

## The Rockefeller Foundation -- founded on oil money -- is dropping fossil fuels
 - [https://www.cnn.com/videos/business/2020/12/17/rockefeller-foundation-rajiv-shah-fossil-fuels-orig.cnn-business](https://www.cnn.com/videos/business/2020/12/17/rockefeller-foundation-rajiv-shah-fossil-fuels-orig.cnn-business)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 12:00:24+00:00

The Rockefeller Foundation was founded over 100 years ago using money largely made from Standard Oil. In an exclusive interview with CNN Business' Matt Egan, the foundation's current president Dr. Rajiv Shah explains why it's now dropping all fossil fuel assets.

## 'We should be less afraid to be afraid,' says historic El Capitan climber
 - [https://www.cnn.com/2020/12/18/sport/emily-harrington-el-capitan-climb-record-cmd-spt-intl/index.html](https://www.cnn.com/2020/12/18/sport/emily-harrington-el-capitan-climb-record-cmd-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 11:49:26+00:00

As she pulled herself over the summit of El Capitan, Emily Harrington knew she had made history.

## US cybersecurity agency warns suspected Russian hacking campaign broader than previously believed
 - [https://www.cnn.com/2020/12/17/politics/us-government-hack-extends-beyond-solarwinds/index.html](https://www.cnn.com/2020/12/17/politics/us-government-hack-extends-beyond-solarwinds/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 11:04:33+00:00

An alarming new alert issued by the Department of Homeland Security's cyber arm Thursday revealed that Russian hackers suspected of a massive, ongoing intrusion campaign into government agencies, private companies and critical infrastructure entities used a variety of unidentified tactics and not just a single compromised software program.

## Eight nuns died of Covid-19 at a Wisconsin facility within a week
 - [https://www.cnn.com/2020/12/18/us/school-sisters-of-notre-dame-covid-wisconsin/index.html](https://www.cnn.com/2020/12/18/us/school-sisters-of-notre-dame-covid-wisconsin/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 11:03:05+00:00

Within a week, eight nuns living in the Notre Dame of Elm Grove in Wisconsin died from Covid-19, all of whom, in their own ways, were mentors in the community.

## 344 kidnapped Nigerian boys freed, says state official
 - [https://www.cnn.com/2020/12/17/africa/nigerian-schoolboys-released-intl/index.html](https://www.cnn.com/2020/12/17/africa/nigerian-schoolboys-released-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 10:53:29+00:00

Hundreds of schoolboys who were abducted last week in northwestern Nigeria have been freed, according to a state official.

## This startup wants to be the Spotify of Africa
 - [https://www.cnn.com/2020/12/18/business/mdundo-spotify-of-africa-spc-intl/index.html](https://www.cnn.com/2020/12/18/business/mdundo-spotify-of-africa-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 10:38:12+00:00

African music has exploded onto the world stage in recent years, but its streaming platforms lag behind.

## How Europe will vaccinate 448 million people?
 - [https://www.cnn.com/2020/12/18/europe/europe-covid-vaccine-rollout-intl/index.html](https://www.cnn.com/2020/12/18/europe/europe-covid-vaccine-rollout-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 10:34:47+00:00

In the name of "science and solidarity," the European Commission has secured over 2 billion doses of coronavirus vaccines for the bloc since June.

## Trump fights for a job that he's not doing as coronavirus rages
 - [https://www.cnn.com/2020/12/18/politics/donald-trump-absent-covid-stimulus-vaccine/index.html](https://www.cnn.com/2020/12/18/politics/donald-trump-absent-covid-stimulus-vaccine/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 10:24:56+00:00

• Pence will receive coronavirus vaccine Friday morning
• CNN INVESTIGATES: Officials slam DeSantis' leadership in crisis
• Ex-adviser reveals story behind infamous op-ed

## Tiger Woods warms up with his son Charlie, 11, and the similarities are striking
 - [https://www.cnn.com/2020/12/18/golf/tiger-woods-swing-son-pga-spt-intl/index.html](https://www.cnn.com/2020/12/18/golf/tiger-woods-swing-son-pga-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 09:48:29+00:00

He may only be 11, but Tiger Woods' son Charlie is clearly a chip off the old block when it comes to golf.

## Europe fights skepticism ahead of vaccine rollout
 - [https://www.cnn.com/videos/world/2020/12/18/europe-anti-vax-skepticism-france-spain-italy-bell-pkg-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2020/12/18/europe-anti-vax-skepticism-france-spain-italy-bell-pkg-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 09:45:43+00:00

As the European Union prepares to roll out Covid-19 vaccine, leaders are now facing a fresh challenge: convincing people to get vaccinated. CNN's Melissa Bells reports on how European countries are tackling some of the of the strongest vaccine skepticism in the world.

## 1,000 people stuck overnight in Japan traffic jam stretching 9 miles long
 - [https://www.cnn.com/2020/12/18/asia/japan-traffic-jam-intl-hnk-scli/index.html](https://www.cnn.com/2020/12/18/asia/japan-traffic-jam-intl-hnk-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 09:43:06+00:00

More than 1,000 people in Japan spent Thursday night stuck on a highway in their cars, waiting out a traffic jam with little food or water during a heavy snowstorm.

## How these 'sinks' regulate the climate
 - [https://www.cnn.com/videos/world/2020/12/17/carbon-sinks-explained-c2e-intl-lon-orig.cnn](https://www.cnn.com/videos/world/2020/12/17/carbon-sinks-explained-c2e-intl-lon-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 09:31:24+00:00

Carbon sinks are vast ecosystems that absorb CO2. They regulate the climate and stop global warming. As they are exploited, many are releasing their carbon stores.

## Chris Christie: I let my guard down for 4 days and that put me in ICU
 - [https://www.cnn.com/videos/politics/2020/12/18/former-gov-chris-christie-cpt-mask-sot-vpx.cnn](https://www.cnn.com/videos/politics/2020/12/18/former-gov-chris-christie-cpt-mask-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 05:56:51+00:00

Speaking to CNN's Chris Cuomo, former New Jersey Governor Chris Christie opens up about how he got infected with Covid-19 at the White House.

## This 'crazy beast' was a weird early mammal that lived among dinosaurs
 - [https://www.cnn.com/2020/12/18/world/crazy-beast-fossil-mammal-scn-trnd/index.html](https://www.cnn.com/2020/12/18/world/crazy-beast-fossil-mammal-scn-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 05:50:15+00:00

Researchers have uncovered the fossil of an early mammal named the "crazy beast" that lived 66 million years ago alongside dinosaurs and giant crocodiles on Madagascar, and it's unlike any mammal ever known, living or extinct.

## Opinion: Cybersecurity attack is another Trump mess Biden will have to clean up
 - [https://www.cnn.com/2020/12/18/opinions/cyberattack-trump-russia-biden-vinograd/index.html](https://www.cnn.com/2020/12/18/opinions/cyberattack-trump-russia-biden-vinograd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 05:29:25+00:00

President Donald Trump is leaving Joe Biden with a mess. With just weeks to go before the President-elect enters office, Trump administration officials revealed several federal agencies, including the State Department, the Department of Homeland Security, along with parts of the Pentagon, have been compromised in what could be one of the largest cyberattacks in US history.

## Cyclone Yasa rips through Fiji, killing at least 2 people and destroying homes
 - [https://www.cnn.com/2020/12/17/weather/cyclone-yasa-damage-intl-hnk/index.html](https://www.cnn.com/2020/12/17/weather/cyclone-yasa-damage-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 03:30:51+00:00

Hurricane force winds and torrential rain brought by Cyclone Yasa have destroyed scores of houses and flattened crops in Fiji's northern regions, aid agencies said on Friday.

## Key differences between two Covid vaccines
 - [https://www.cnn.com/2020/12/17/health/moderna-vaccine-what-we-know/index.html](https://www.cnn.com/2020/12/17/health/moderna-vaccine-what-we-know/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 03:06:15+00:00

• Your Covid vaccine questions, answered

## Top Trump ally Chris Christie says it's time to accept Biden won the election
 - [https://www.cnn.com/2020/12/17/politics/chris-christie-us-election-cnntv/index.html](https://www.cnn.com/2020/12/17/politics/chris-christie-us-election-cnntv/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 03:04:46+00:00

Former New Jersey Gov. Chris Christie, a staunch ally of President Donald Trump, said Thursday evening it's time to accept that Joe Biden won the 2020 election as the President continues to push baseless conspiracy theories that his second term is being stolen.

## Trump ally has a message after election loss
 - [https://www.cnn.com/videos/politics/2020/12/17/former-gov-chris-christie-cpt-trump-election-sot-vpx.cnn](https://www.cnn.com/videos/politics/2020/12/17/former-gov-chris-christie-cpt-trump-election-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 02:53:04+00:00

Former New Jersey Governor Chris Christie talks to CNN's Chris Cuomo about the election and how President Donald Trump and some Republicans have refused to concede.

## The heart-wrenching hand dealt to Hong Kong's democracy activists
 - [https://www.cnn.com/2020/12/17/asia/hong-kong-exiles-and-inmates-dst-hnk-intl/index.html](https://www.cnn.com/2020/12/17/asia/hong-kong-exiles-and-inmates-dst-hnk-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 02:46:35+00:00

In the dark small hours, two recurring nightmares terrorize the sleep of Eddie Chu. In the first, he is lost overseas and cannot get home to Hong Kong. In the second, the former lawmaker is day tripping with his nine-year-old daughter.

## Microsoft identifies more than 40 organizations targeted in massive cyber breach
 - [https://www.cnn.com/2020/12/17/politics/microsoft-hack-organizations/index.html](https://www.cnn.com/2020/12/17/politics/microsoft-hack-organizations/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 02:11:24+00:00

Microsoft has identified more than 40 of its customers around the world that had problematic versions of a third-party IT management program installed and that were specifically targeted by the suspected Russian hacking campaign disclosed this week, the company said in a blog post Thursday.

## Trump remains silent as massive cyber hack poses 'grave risk' to government
 - [https://www.cnn.com/collections/intl-cyber-attack-us/](https://www.cnn.com/collections/intl-cyber-attack-us/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 01:59:11+00:00



## NASA wants to build a lunar base by 2030. Could 3D printing with moon dust be the answer?
 - [https://www.cnn.com/style/article/3d-print-lunar-base-moon-dust-spc-intl/index.html](https://www.cnn.com/style/article/3d-print-lunar-base-moon-dust-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 01:58:53+00:00

The last time a person stepped foot on the moon was 1972. Now, the moon is back on NASA's space agenda. This time around the agency isn't just visiting -- it's planning to stay.

## The true and unadulterated history of the drop bear, Australia's most deadly -- and most fake -- predator
 - [https://www.cnn.com/travel/article/australia-drop-bears-history-intl-hnk/index.html](https://www.cnn.com/travel/article/australia-drop-bears-history-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 01:18:41+00:00

Ask almost any Australian about a drop bear, and they'll likely recount a close encounter with this carnivorous, fanged cousin of the Australian koala.

## Deb Haaland makes history as Biden's pick to run US Interior Department
 - [https://www.cnn.com/2020/12/17/politics/deb-haaland-makes-history/index.html](https://www.cnn.com/2020/12/17/politics/deb-haaland-makes-history/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 00:56:13+00:00

President-elect Joe Biden's selection of Rep. Deb Haaland to lead the Interior Department marked a historic victory for an alliance of progressives and Indigenous leaders who campaigned relentlessly to elevate one of their own to a powerful federal seat that oversees natural resources, public lands and Indian affairs.

## French modeling agent arrested in Jeffrey Epstein investigation
 - [https://www.cnn.com/2020/12/17/europe/france-jean-luc-brunel-intl/index.html](https://www.cnn.com/2020/12/17/europe/france-jean-luc-brunel-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-18 00:35:17+00:00

A French modeling agent has been arrested in Paris as part of an investigation by the city's prosecutor's office connected to accused sex-trafficker Jeffrey Epstein.

