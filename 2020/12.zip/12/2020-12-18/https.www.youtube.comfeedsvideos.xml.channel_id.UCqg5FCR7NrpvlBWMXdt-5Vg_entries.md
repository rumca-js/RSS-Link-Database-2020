# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Call of the Sea | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=WiVrh9z2q-4](https://www.youtube.com/watch?v=WiVrh9z2q-4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-12-19 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Will Cruz reviews Call of the Sea, developed by Out of the Blue Games.

Call of the Sea on Steam: https://store.steampowered.com/app/1042490/Call_of_the_Sea/

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## El Hijo - A Wild West Tale | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=hb_W9vr9U_E](https://www.youtube.com/watch?v=hb_W9vr9U_E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-12-19 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

KC Nwosu reviews El Hijo, developed by Honig Studios and Quantumfrog.

El Hijo on Steam: https://store.steampowered.com/app/853050/El_Hijo__A_Wild_West_Tale/

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Demon's Souls' Best Boss Fight Paved The Way For FromSoftware's Future
 - [https://www.youtube.com/watch?v=tGikZaB_7K0](https://www.youtube.com/watch?v=tGikZaB_7K0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-12-18 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Bluepoint Games’ Demon’s Souls remake for PlayStation 5 does an amazing job of preserving what was incredible and pure about the 2009 original, while simultaneously updating so many aspects of the game to a tremendous level. The music, lighting, and atmosphere are as impactful as ever, portraying the remnants of the Kingdom of Boletaria in remarkable detail. And the slew of quality-of-life improvements make the inevitable litany of deaths you’ll experience throughout the game all the more manageable.

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

