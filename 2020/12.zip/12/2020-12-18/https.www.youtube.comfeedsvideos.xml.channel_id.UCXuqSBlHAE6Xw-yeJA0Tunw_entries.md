# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Wait THIS is a GAMING PC?? - MinisForum EliteMini H13G
 - [https://www.youtube.com/watch?v=HYtTJgj15dc](https://www.youtube.com/watch?v=HYtTJgj15dc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-12-19 00:00:00+00:00

Visit https://www.squarespace.com/LTT and use offer code LTT for 10% off

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire

Are mini desktops finally starting to make sense? Take a gander at the EliteMini H13G from MinisForum, it’s a whole lotta power for not a lot of space, and it comes at a reasonable price too!

Buy a Micro PC
On Amazon (PAID LINK): https://geni.us/MIMBKxv
On Best Buy (PAID LINK): https://geni.us/h9aB0R
On Newegg (PAID LINK): https://geni.us/XJgARxX

Check out the EliteMini H31G: https://lmg.gg/T79CF 

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://lmg.gg/D24XG


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Official Game Store: https://www.nexus.gg/ltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

## NVIDIA APOLOGIZED (sort of)  - WAN Show December 18, 2020
 - [https://www.youtube.com/watch?v=nZpXZxpzMzw](https://www.youtube.com/watch?v=nZpXZxpzMzw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-12-18 00:00:00+00:00

Save 10% at Ridge Wallet with offer code LINUS at https://www.ridge.com/Linus

If you’re looking for a directory that supports heterogeneous OSs, or you need just SSO, MDM, LDAP, MFA – or all of the above – JumpCloud will make your job easier at https://cloud.jumpcloud.com/l/876401/2020-11-11/gy41fq

Check out Seasonic's PRIME 850W Titanium on Amazon at https://lmg.gg/seasonicprime

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/NVIDIA-APOLOGIZED-sort-of---WAN-Show-December-18--2020-eo34dq

Check out Carpool Critics, our new movie podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Timestamps (Courtesy of Pizza Thyme Pizza FanClub)
1:25 intro
2:02 More on Hardware Unboxed getting denied cards.
 2:40 Nvidia apologies sort of for hardware unboxed ceasing getting cards
 4:43 Luke is unsure if Nvidia is apologizing to save face or is sincere
 6:00 Summary of the "scandal" between hardware unboxed and Nvidia
 8:55 Luke thinks that Nvidia is doing this bc they are saving face.
 12:40 Linus is trying to get someone from Nvidia to talk to him.
 14:30 Linus burning bridges with Nvidia and meme-ing on them.
 16:45 This PR does not make very much sense for Nvidia.
19:00 Cyberpunk 2077 review
 20:22 Cyberpunk pulled from Sony play store
  21:35 CD Project Red reputation has been messed up
        22:42 Sony pulling Cyberpunk from play store
 23:15 Cyberpunk unplayable on last gen consoles
26:40 Devotion Pulled from Good Old Games with pressure from the CCP
 26:52 Contained unflattering references to [Winnie the Pooh] relating to the Taiwan situation
 28:09 GOG/Steam caved to CCP
 29:20 Twitter might not be representative sample of gamers' thoughts
 30:24 Different Mentality in China versus USA
 36:09 A poll of live viewers' opinions finds that opinions have worsened about CD Project RED
37:54 Microsoft might start to make ARM designs?
 38:45 Microsoft may become Microhard if they get into hardware
39:57 Sponsor spots 
 40:11 jumpcloud dot com
 41:08 10% off at ridge dot com slash linus
 41:45 Seasonic has good PSUs
42:45 Antitrust lawsuits
 42:55 Allegedly Google Has a monopoly over ads 
 43:25 Allegedly Facebook has been buying competitors and has a monopoly
 44:01 America Has not exercised the laws in a long time
 45:37 Google and Facebook account for 54% of advertising
 46:35 Linus does not like the privacy violations done by Google et al. and prefers his form of ads
47:12 LTTSTOREDOTCOM
48:10  Linus talking about parenting and children's literacy 
51:10 Superchats
       51:18 Airpods review question
       51:26 Paying for refunded shirts
       51:39 Dual shock "low latency"
52:35 The Mandela Effect
52:55 Outro
53:18 Dell insider follow up

