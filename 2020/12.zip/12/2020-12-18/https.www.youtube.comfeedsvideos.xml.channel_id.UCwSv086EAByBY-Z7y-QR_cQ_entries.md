# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Gołębiewski: Podstawione osoby mogą przejmować firmy, które skorzystały z tarczy antykryzysowej!
 - [https://www.youtube.com/watch?v=DzXOIm8RgCQ](https://www.youtube.com/watch?v=DzXOIm8RgCQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2020-12-19 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/2ETKSyN
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
---------------------------------------------------------------
🖼Grafika - wykorzystano grafikę ze strony: 
golebiewski.pl - https://bit.ly/2J2xXjY
---------------------------------------------------------------
✅źródła:
http://bit.ly/3ragAip
https://s.nikkei.com/3aqt7Z7
https://bit.ly/37vmtip
https://bit.ly/3qosEwh
-------------------------------------------------------------
💡 Tagi: #lockdown #gospodarka
--------------------------------------------------------------

## Trust Stamp - twarz jako login w Nowej Normalności
 - [https://www.youtube.com/watch?v=yo3TA9AM1ow](https://www.youtube.com/watch?v=yo3TA9AM1ow)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2020-12-18 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/2ETKSyN
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
---------------------------------------------------------------
🖼Grafika - wykorzystano elementy ze stron: 
truststamp.re - https://bit.ly/2KDIoLb
---------------------------------------------------------------
✅źródła:
http://bit.ly/34p81Xf
https://bit.ly/38iGnwt
http://bit.ly/38i1rmH
https://bit.ly/34mX0G4
http://bit.ly/3aseapH
http://bit.ly/3nuQogj
-------------------------------------------------------------
💡 Tagi: #TrustStamp
--------------------------------------------------------------

