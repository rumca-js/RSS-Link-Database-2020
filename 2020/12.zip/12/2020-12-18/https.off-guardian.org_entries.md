## WHO (finally) admits PCR tests create false positives
 - [https://off-guardian.org/2020/12/18/who-finally-admits-pcr-tests-create-false-positives/](https://off-guardian.org/2020/12/18/who-finally-admits-pcr-tests-create-false-positives/)
 - RSS feed: https://off-guardian.org
 - date published: 2020-12-18 21:59:35+00:00

WHO (finally) admits PCR tests create false positives

