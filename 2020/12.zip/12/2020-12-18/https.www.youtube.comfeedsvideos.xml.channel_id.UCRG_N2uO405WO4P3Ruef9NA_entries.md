# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Your next Android might get 4 years of updates!
 - [https://www.youtube.com/watch?v=jKUj9ojiEls](https://www.youtube.com/watch?v=jKUj9ojiEls)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2020-12-18 00:00:00+00:00

Sponsored by Curiositystream. Sign up here and get access to Nebula for free with your subscription: https://curiositystream.com/tfc 

You can check out Nebula at http://watchnebula.com but the bundle means you get both services for the same price, and because CuriosityStream is our sponsor it’s a better way to support us. 


This week the EU proposes new laws that might change the internet forever, Google and Qualcomm lay the groundwork for 4 years of Android updates and Facebook shoots themselves in the leg with some ads.

The Friday Checkout - Episode 28

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► Quiz ◄◄◄

Our Weekly Tech Knowledge Quiz is available:

In the Crrowd app: https://play.google.com/store/apps/details?id=com.crrowd
On the web: https://crrowd.com/quiz

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► TechAltar links ◄◄◄

Merch: 
http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 

If you want to support TechAltar directly: 
https://flattr.com/@techaltar 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions ◄◄◄
Music by Edemski: https://soundcloud.com/edemski

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Time stamps ◄◄◄

0:00 Intro
0:41 New EU internet laws
4:23 4 years of Android updates
5:45 Facebook's silly ads

