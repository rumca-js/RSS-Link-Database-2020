# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Top 10 Prophetic Quotes From GK Chesterton
 - [https://www.youtube.com/watch?v=te1-gDhq3DU](https://www.youtube.com/watch?v=te1-gDhq3DU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-12-19 00:00:00+00:00

G.K. Chesterton wrote essays on philosophy, religion, politics, and fiction in the early 20th century. Kyle and Ethan from The Babylon Bee do a deep dive on his most prophetic quotes. Prophecy? FULFILLED!

See the full show here:
https://youtu.be/tRGn9TxlXS0

Subscribe to The Babylon Bee to get more quality Chestertonian content.

Hit the bell to get your daily dose of fake news that you can trust.

## Mike Lindell Interview: The Jesse Ventura of Pillows
 - [https://www.youtube.com/watch?v=bf6Imo-yV4w](https://www.youtube.com/watch?v=bf6Imo-yV4w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-12-18 00:00:00+00:00

Today on The Babylon Bee Podcast, Kyle and Ethan talk to Mike Lindell. Mike Lindell is the founder and current CEO of My Pillow. Mike Lindell first gained fame for starring in the My Pillow infomercials sporting his trademark mustache, periwinkle blue shirt, and cross necklace. He has gained recent notoriety for becoming one of President Trump’s biggest supporters. Mike shows why he is always the best at parties by sharing stories of his crack addiction, becoming a commercial celebrity, and how the media can’t cancel him. 

Subscribe on iTunes: https://podcasts.apple.com/us/podcast...

Gain Access to the Exclusive Content and Writing Forum: https://babylonbee.com/plans

The Official Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

## The Chesterton Prophecies And The Eccentric Elon Musk News Show 12.18.2020
 - [https://www.youtube.com/watch?v=tRGn9TxlXS0](https://www.youtube.com/watch?v=tRGn9TxlXS0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-12-18 00:00:00+00:00

Today on The Babylon Bee Podcast, Kyle and Ethan talk about the week’s biggest stories like Elon Musk noticing our fine journalism, Dr. Jill Biden expertly saving a life with just a podium and a microphone, Disney announcing 7,562 new Star Wars shows. They also discuss how prolific and prophetic G.K. Chesterton was writing over a century ago. 

There’s stuff that’s good, weird news, glorious hate mail, and unintentional rambunctious reindeer.

Watch The Babylon Bee animation on our animation playlist: https://bit.ly/BeeAnimation  

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Submit Your Own Headlines: https://babylonbee.com/plans

The Official The Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

