# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Best Christmas Gifts For Gamers (2020)
 - [https://www.youtube.com/watch?v=-gBx1UjOe3g](https://www.youtube.com/watch?v=-gBx1UjOe3g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-12-20 00:00:00+00:00

The 2020 holiday season is here! We've got some last-minute gift suggestions and tips from cheap to obnoxious.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

#10 Xbox Series X or PS5

------

#9. Random PC Gamer stuff 

https://amzn.to/2WwQGY3

https://amzn.to/34vA8Ei

https://amzn.to/3h4S9OQ

https://amzn.to/3aGViU3

https://amzn.to/3p7w2tS

------

#8. Elgato Stream Deck

https://amzn.to/2KDy8CS

------

#7. 


------

#6. 

https://amzn.to/3reFCwN

------

#5. 

https://amzn.to/3rdP1oz

https://amzn.to/3nBcCNO

------

#4. 

https://amzn.to/3nGWRVu

------
#3. 
Logitech Chair 
https://store.hermanmiller.com/gaming/herman-miller-x-logitech-g-embody-gaming-chair/2517590.html?lang=en_US

------

#2. 
Razer Kishi
https://amzn.to/34uFbVF

------

#1. Random PC Gamer stuff 

https://amzn.to/3aBRl2y

https://amzn.to/34tBsHI

https://amzn.to/34tBpM2

https://amzn.to/34x7jY1

https://amzn.to/34t3umU

------

Extras
https://www.iam8bit.com

https://www.fangamer.com

https://www.etsy.com

https://www.target.com/p/handheld-oregon-trail-game/-/A-52719211

https://amzn.to/3riQ9Ya

https://pocketsprite.com

https://amzn.to/37BfCnB

## Cyberpunk 2077: Dumb Yet Hilarious Glitches
 - [https://www.youtube.com/watch?v=mB6XyErBswg](https://www.youtube.com/watch?v=mB6XyErBswg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-12-19 00:00:00+00:00

Cyberpunk 2077 is filled with hilarious glitches, bugs, and weird graphics problems. You sent us some clips and we reacted. 
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## SONY REMOVES CYBERPUNK 2077 FROM PSN STORE, LEFT 4 DEAD SUCCESSOR RISES, & MORE
 - [https://www.youtube.com/watch?v=ondXmqLyLlk](https://www.youtube.com/watch?v=ondXmqLyLlk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-12-19 00:00:00+00:00

Sponsored by ExpressVPN. Go to https://expressvpn.com/gameranx and find out how you can get 3 months of ExpressVPN free!

Cyberpunk 2077 refund issues ramp up, Nintendo shows off upcoming indies, and more in a week full of gaming news.

Subscribe for more: https://www.youtube.com/gameranxTV?su...

VOTE FOR GAMERANX GAME OF THE YEAR HERE: https://bit.ly/34tukeB


 ~~~~STORIES~~~~


Cyberpunk 
https://www.gamesindustry.biz/articles/2020-12-18-sony-pulls-cyberpunk-2077-from-playstation-store
UPDATE:
https://www.engadget.com/cyberpunk-2077-cd-projekt-red-return-policy-201145944.html

Back 4 Blood
https://www.windowscentral.com/back-4-blood-closed-alpha-goes-live-week-registration-still-open


Nintendo Direct indie showcase
https://youtu.be/GzXyEEQ6L2I

Hilarious Cyberpunk edit
https://www.reddit.com/r/cyberpunkgame/comments/kf57gq/cyberpunk_2077_launch_glitches_trailer_a/?ref=share&ref_source=embed&utm_content=title&utm_medium=post_embed&utm_name=95b7f3f040cf47a086ad8620021f55d3&utm_source=embedly&utm_term=kf57gq

Reading list
https://www.google.com/amp/s/www.polygon.com/platform/amp/2020/11/19/21572072/best-video-game-books-gifts

League of Legends MMO
https://www.pcgamer.com/riot-is-working-on-a-league-of-legends-mmo/


VOTE FOR GAMERANX GAME OF THE YEAR HERE: https://bit.ly/34tukeB

