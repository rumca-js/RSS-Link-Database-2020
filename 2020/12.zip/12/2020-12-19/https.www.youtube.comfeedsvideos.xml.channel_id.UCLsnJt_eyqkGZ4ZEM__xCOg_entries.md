# Source:Vlog Casha, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg, language:pl-PL

## Poznajcie Ahmeda, uchodźcę z Syrii.
 - [https://www.youtube.com/watch?v=n1fy4b7_WpI](https://www.youtube.com/watch?v=n1fy4b7_WpI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg
 - date published: 2020-12-19 00:00:00+00:00

🗺️ Turcja 2020 #21. W dzisiejszym vlogu wybierzemy się do znajdującego się nad rzeką Eufrat Halfeti oraz porozmawiamy z moim kolegą, Ahmedem, który kilka lat temu wraz z rodziną musiał uciec z Syrii do Turcji.

❗ Zostań Patronem kanału!
https://patronite.pl/vlogcasha

Vlogi z Turcji (2019-2020): https://bit.ly/31VPCR3
Vlogi z Kolumbii: https://bit.ly/36tqlhH
🌏 Vlogi z Azji Płd-Wsch: https://bit.ly/2wrM9t2
🇦🇺 Vlogi z Australii: https://bit.ly/2OJWYOy
🇺🇸 Vlogi z życia i podróży w USA: https://bit.ly/2ya73NV
🚙Vlogi z autostopu 2018: https://bit.ly/2NbHzos

▸ Instagram: https://www.instagram.com/vlogcasha
▸ Facebook: https://www.facebook.com/vlogcasha/
#PodróżeCasha #CashWTurcji #Turcja

