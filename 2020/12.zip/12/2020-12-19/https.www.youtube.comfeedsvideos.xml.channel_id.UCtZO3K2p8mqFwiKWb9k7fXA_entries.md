# Source:Techaltar, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA, language:en-US

## The rise & fall of Japanese phone giants
 - [https://www.youtube.com/watch?v=voyuy1rySX4](https://www.youtube.com/watch?v=voyuy1rySX4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA
 - date published: 2020-12-19 00:00:00+00:00

Sponsored by Skillshare. The first 1000 people who click this link will get 2 free months of Skillshare Premium: https://skl.sh/techaltar12201

The Story Behind series - episode 71

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► TechAltar links ◄◄◄

Merch: 
http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 

If you want to support TechAltar directly: 
https://flattr.com/@techaltar 

Check out my app, gadget review app, Crrowd:
https://crrowd.com

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions ◄◄◄

Music by Epidemic Sound: http://epidemicsound.com/creator
Regular music by Edemski: https://soundcloud.com/edemski

