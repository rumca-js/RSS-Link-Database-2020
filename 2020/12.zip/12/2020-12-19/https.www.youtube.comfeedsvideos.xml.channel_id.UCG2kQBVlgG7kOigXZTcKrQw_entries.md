# Source:Kołem się toczy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw, language:pl-PL

## Parenzana - trasa rowerowa po torach dawnej kolei 🚴💨 Kapitalna! 🍁 Chorwacja niepopularna
 - [https://www.youtube.com/watch?v=oawBI6YH6lY](https://www.youtube.com/watch?v=oawBI6YH6lY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw
 - date published: 2020-12-20 00:00:00+00:00

Kurs 🎬 https://www.kursfilmowaniaimontazu.pl/
Opinie o kursie 🎬 https://kolemsietoczy.pl/opinie-o-kursie-filmowo-montazowym-karola-wernera/

PARENZANA! 

Co niektórzy niecierpliwi zaczęli mnie już upominać - kiedy będzie jakiś rower?! :D No to jest. Dzisiaj pojeździmy na rowerach po chyba najpopularniejszej trasie rowerowej na półwyspie Istria. Mimo, że jest to najpopularniejsza trasa, to jestem pewien, że mało kto z Was o niej słyszał, tak samo jak mało kto odwiedza Istrię jadąc do Chorwacji na wakacje. No chyba, że się mylę?

Parenzana to nic innego jak ładnie pociągnięta trasa rowerowa, która prowadzi po trasie dawnej kolei wąskotorowej, która 100 lat temu łączyła pomiędzy sobą 30 małych miasteczek Istrii z włoskim Triestem. Bardzo Parenzanę polecamy na 1-2 dniową wycieczkę rowerową, a jeśli macie pytania to walcie śmiało.

Ps. to, że kanał nazywa się Kołem Się Toczy nie znaczy, że jest to kanał w 100% o turystyce rowerowej i rowerach. I nigdy nie będzie ;) Dajcie żyć! 

►►Zachęcam do subskrypcji: http://bit.ly/2cmWbSO 

Zapraszam też na:
Facebook: http://bit.ly/2flU84f
Instagram: http://bit.ly/2eTrIMc
Blog: http://kolemsietoczy.pl/
muzyka: artlist, nevaeh

Na koniec spis treści odcinka:
00:00 - 00:38 Wstęp, co warto zobaczyć na Istrii?
00:39 - 02:57 Parenzana - historia kolei
02:58 - 03:31 Istria - czy warto tam jechac?
03:31 - 06:36 Trasa rowerowa śladem Parenzany
06:37 - 08:01 Trufle na Istrii
08:02 - 09:19 Grožnjan, język i ludzie na Istrii
09:20 - 10:07 Trudność trasy rowerowej Parenzana
10:08 - 11:41 Zatoka Pirańska - spór terytorialny
11:42 - 14:23 Środkowa Istria na rowerze
14:24 - 16:00 Wodospad na Istrii Zarečki Krov i zakończenie

