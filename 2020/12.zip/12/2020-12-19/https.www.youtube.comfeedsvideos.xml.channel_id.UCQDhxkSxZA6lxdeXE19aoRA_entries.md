# Source:Hugh Jeffreys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA, language:en-US

## $75 Destroyed iPhone 11 Pro Max Restoration
 - [https://www.youtube.com/watch?v=B3SYbbeLmhw](https://www.youtube.com/watch?v=B3SYbbeLmhw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA
 - date published: 2020-12-19 00:00:00+00:00

I never pay full retail price! 
Its time to repair this smashed and bent iPhone 11 Pro Max
--------------------------------------Socials-------------------------------------
Website: https://www.hughjeffreys.com 
Instagram: http://instagram.com/hughjeffreys
Twitter: https://twitter.com/hughjeffreys
---------------------------------------Links---------------------------------------
The tools I use:
https://www.hughjeffreys.com/tools

Get free shipping on the Pro Tech ifixit.com/hughjeffreys 
Free Shipping Code: PROSHIP
US: ifixit.com/hughjeffreys
Australian Store: https://ifix.gd/2FPxhKy
(DISCLAIMER: This description contains affiliate links, which means that if you click on one of the product links, l will receive a small commission.)

