# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## The Mandalorian: Season 2 FINALE! (My Thoughts)
 - [https://www.youtube.com/watch?v=GrJWhy4CsaY](https://www.youtube.com/watch?v=GrJWhy4CsaY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-12-19 00:00:00+00:00

The first 1000 people to use this link will get a free trial of Skillshare Premium Membership: https://skl.sh/jeremyjahns11201 
and thanks to Skillshare for sponsoring this video!

The Mandalorian Season 2 FINALE! No description needed. Here we go!

#Mandalorian #MandalorianSeason2Finale

