# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Poverty in The Pandemic - I volunteered at a food bank
 - [https://www.youtube.com/watch?v=Ua6h9DjnIoM](https://www.youtube.com/watch?v=Ua6h9DjnIoM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-12-20 00:00:00+00:00

I volunteered at the One Can Trust food bank in High Wycombe. 

All ad revnue goes to One Can Trust.

If you're in Buckinghamshire and need food support or if you want to volunteer you can contact One Can Trust on 01494 512277 or office@onecantrust.org.uk 

You can find your local UK food bank and more information here: www.trusselltrust.org

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Gareth Roy

