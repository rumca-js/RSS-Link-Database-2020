# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Shearer unsure 'awful' Arsenal will survive as Arteta admits 'other teams want it more'
 - [https://www.bbc.co.uk/sport/football/55382530](https://www.bbc.co.uk/sport/football/55382530)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 23:59:50+00:00

Former England captain Alan Shearer says he would "not be so sure" about Arsenal surviving in the Premier League at the end of the season.

## Seven goals in a game again - but this time Liverpool show form of champions
 - [https://www.bbc.co.uk/sport/football/55379004](https://www.bbc.co.uk/sport/football/55379004)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 23:17:26+00:00

When Liverpool lost 7-2 to Aston Villa in October, their title credentials were questioned - but few doubts remain as they score seven themselves at Crystal Palace.

## Coronavirus: Trump's Covid vaccine chief admits delivery mistake
 - [https://www.bbc.co.uk/news/world-us-canada-55380288](https://www.bbc.co.uk/news/world-us-canada-55380288)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 22:27:32+00:00

The army general apologises to states who will get fewer Pfizer doses than they were expecting.

## Brexit: No trade deal unless 'substantial shift' from EU, UK says
 - [https://www.bbc.co.uk/news/uk-politics-55381322](https://www.bbc.co.uk/news/uk-politics-55381322)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 22:26:55+00:00

With a decision expected before Christmas, UK sources say it is increasingly likely there will be no deal.

## 'I won't have next summer, let alone next Christmas'
 - [https://www.bbc.co.uk/news/uk-55381945](https://www.bbc.co.uk/news/uk-55381945)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 22:21:22+00:00

Three people tell BBC News how the new Christmas coronavirus rules will affect them.

## Strictly Come Dancing: 7 memorable moments from this series
 - [https://www.bbc.co.uk/news/entertainment-arts-55314693](https://www.bbc.co.uk/news/entertainment-arts-55314693)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 20:32:51+00:00

Bill Bailey, HRVY, Maisie Smith and Jamie Laing will compete for the glitterball trophy on Saturday.

## Strictly Come Dancing: Bill Bailey crowned 2020 winner
 - [https://www.bbc.co.uk/news/entertainment-arts-55345136](https://www.bbc.co.uk/news/entertainment-arts-55345136)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 20:26:56+00:00

Bill Bailey, Maisie Smith, HRVY and Jamie Laing competed to lift the glitterball trophy.

## Covid Christmas: What can you do to stay safe?
 - [https://www.bbc.co.uk/news/uk-55378457](https://www.bbc.co.uk/news/uk-55378457)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 18:41:12+00:00

For those who can meet up on Christmas Day, what can be done to reduce the spread of coronavirus?

## Covid: Cabinet holding talks amid rising infection rates in England
 - [https://www.bbc.co.uk/news/uk-55376727](https://www.bbc.co.uk/news/uk-55376727)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 12:23:15+00:00

There is "concern" about new data for parts of England and the cabinet is summoned for a lunchtime call.

## Covid-19: Explosion kills nine coronavirus patients in Turkey
 - [https://www.bbc.co.uk/news/world-europe-55376008](https://www.bbc.co.uk/news/world-europe-55376008)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 11:49:01+00:00

Nine people are killed as an oxygen ventilator explodes at a coronavirus ward of a private hospital.

## Epstein ex-associate Jean-Luc Brunel placed under formal investigation
 - [https://www.bbc.co.uk/news/world-europe-55376323](https://www.bbc.co.uk/news/world-europe-55376323)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 11:45:01+00:00

Modelling agent Jean-Luc Brunel is accused of rape and sexual harassment by French authorities.

## Brexit: UK-EU trade talks enter critical 48-hour period
 - [https://www.bbc.co.uk/news/uk-politics-55364470](https://www.bbc.co.uk/news/uk-politics-55364470)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 11:00:10+00:00

The EU says the "moment of truth" has arrived as disagreements with the UK over fishing rights continue.

## Caliphate: NY Times loses awards for Islamic State podcast over false reporting
 - [https://www.bbc.co.uk/news/world-us-canada-55375277](https://www.bbc.co.uk/news/world-us-canada-55375277)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 10:33:25+00:00

The paper admits its blockbuster podcast about Islamic State group failed to meet editorial standards.

## Golovkin dominates Szeremeta to make record 21st title defence
 - [https://www.bbc.co.uk/sport/boxing/55375035](https://www.bbc.co.uk/sport/boxing/55375035)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 09:19:10+00:00

Gennady Golovkin knocks down Kamil Szeremeta four times en route to a record 21st defence of his IBF world middleweight title.

## Sports Personality of the Year: Ronnie O'Sullivan on winning sixth world title
 - [https://www.bbc.co.uk/sport/av/sports-personality/55355771](https://www.bbc.co.uk/sport/av/sports-personality/55355771)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 09:00:02+00:00

Speaking in August, Sports Personality of the Year contender Ronnie O'Sullivan says his dreams have become a reality after winning his sixth world snooker title.

## India bowled out for 36 as Australia win first Test by eight wickets
 - [https://www.bbc.co.uk/sport/cricket/55375248](https://www.bbc.co.uk/sport/cricket/55375248)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 08:59:32+00:00

India are bowled out for 36 - their lowest total in Test cricket - as Australia win the first Test in Adelaide by eight wickets.

## Dortmund's Moukoko becomes Bundesliga's youngest scorer, aged 16
 - [https://www.bbc.co.uk/sport/football/55375117](https://www.bbc.co.uk/sport/football/55375117)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 08:27:14+00:00

Borussia Dortmund's Youssoufa Moukoko becomes the youngest player to score in the Bundesliga in his side's 2-1 loss to Union Berlin.

## Dionne Warwick: How 'Auntie' tweeted herself to newfound fame in 2020
 - [https://www.bbc.co.uk/news/newsbeat-55347088](https://www.bbc.co.uk/news/newsbeat-55347088)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 07:02:16+00:00

Turns out, having a career that spans decades and being hilarious are not mutually exclusive.

## 737 Max: Boeing 'inappropriately coached' pilots in test after crashes
 - [https://www.bbc.co.uk/news/world-us-canada-55372499](https://www.bbc.co.uk/news/world-us-canada-55372499)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 06:15:44+00:00

US Senate investigators find problems with tests conducted in the wake of two deadly crashes.

## The Papers: 'Lockdown 3 fear' and Oxford jab 'before new year'
 - [https://www.bbc.co.uk/news/blogs-the-papers-55372241](https://www.bbc.co.uk/news/blogs-the-papers-55372241)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 05:52:46+00:00

Many of Saturday's papers lead with the prospect the UK could enter national restrictions post-Christmas.

## Covid: Italy latest European country to order Christmas lockdown
 - [https://www.bbc.co.uk/news/world-europe-55372491](https://www.bbc.co.uk/news/world-europe-55372491)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 04:37:11+00:00

Non-essential shops will be closed with travel only allowed for work, health and emergency reasons.

## Covid at Christmas: 'Chris Whitty is more popular than Britney Spears'
 - [https://www.bbc.co.uk/news/uk-55333205](https://www.bbc.co.uk/news/uk-55333205)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 01:06:05+00:00

England's chief medical officer and his deputy Jonathan Van-Tam prove popular with shoppers.

## Sir David Attenborough on Joe Biden, Christmas wrapping... and flamingos
 - [https://www.bbc.co.uk/news/entertainment-arts-55042006](https://www.bbc.co.uk/news/entertainment-arts-55042006)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 01:05:02+00:00

Sir David examines how wildlife adapts to the forces of nature, such as volcanoes, in a new series.

## Vanessa Bryant, her mother's lawsuit and the value of childcare
 - [https://www.bbc.co.uk/news/world-55349003](https://www.bbc.co.uk/news/world-55349003)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 01:04:51+00:00

Vanessa Bryant's messy legal dispute with her mother has also got us talking about the value of housework.

## Met Police officer sues over 'sexual and racist' texts
 - [https://www.bbc.co.uk/news/uk-england-london-55364729](https://www.bbc.co.uk/news/uk-england-london-55364729)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 00:55:53+00:00

The ex-officer is suing her former colleague after he used racist and sexual language in his messages.

## Covid-19: Fake 'immunity booster' found on sale in London shops
 - [https://www.bbc.co.uk/news/uk-england-london-55318095](https://www.bbc.co.uk/news/uk-england-london-55318095)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 00:49:16+00:00

Tests carried out for the BBC show herbal remedy Coronil offers no protection from coronavirus.

## Covid: Postie helps those shielding on her round
 - [https://www.bbc.co.uk/news/uk-wales-55369381](https://www.bbc.co.uk/news/uk-wales-55369381)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 00:42:02+00:00

Lucy Garlick's been shopping for people shielding and leaving chocolate for children.

## The 'ghost' silhouettes popping up in a Scottish Borders village
 - [https://www.bbc.co.uk/news/uk-scotland-south-scotland-55266179](https://www.bbc.co.uk/news/uk-scotland-south-scotland-55266179)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 00:16:33+00:00

Residents of West Linton have seen all kinds of creatures appear since the Covid pandemic began.

## Week in pictures: 12-18 December 2020
 - [https://www.bbc.co.uk/news/in-pictures-55367790](https://www.bbc.co.uk/news/in-pictures-55367790)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 00:16:29+00:00

A selection of some of the most powerful images taken around the world this week.

## Covid: The countries worried they won't get the vaccine
 - [https://www.bbc.co.uk/news/world-55325450](https://www.bbc.co.uk/news/world-55325450)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 00:06:25+00:00

Countries such as Zimbabwe, Mexico and Pakistan are likely to have to wait for the coronavirus vaccine.

## Faith and fertility at Bethlehem's Milk Grotto
 - [https://www.bbc.co.uk/news/world-middle-east-55347211](https://www.bbc.co.uk/news/world-middle-east-55347211)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 00:04:13+00:00

Some say the place where Mary is said to have nursed Jesus holds the power to help couples conceive.

## Microplastics, drugs and food - how jellyfish can help us
 - [https://www.bbc.co.uk/news/stories-55360696](https://www.bbc.co.uk/news/stories-55360696)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 00:00:51+00:00

Jellyfish are being used to develop new medicines, filters for microplastics and for food.

## Long Covid: I used to run, now I can walk 200 metres
 - [https://www.bbc.co.uk/news/health-55370489](https://www.bbc.co.uk/news/health-55370489)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 00:00:45+00:00

Dr Nathalie MacDermott, 38, explains how Covid-19 has affected her life.

## North Korea: Potato propaganda is back... but what does it mean?
 - [https://www.bbc.co.uk/news/world-asia-55348575](https://www.bbc.co.uk/news/world-asia-55348575)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 00:00:39+00:00

Why is North Korea promoting the humble spud in movies, culinary shows, and news reports?

## 'There were times when there wasn't any food'
 - [https://www.bbc.co.uk/sport/football/55338104](https://www.bbc.co.uk/sport/football/55338104)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 00:00:37+00:00

In a new film, Marcus Rashford: Feeding Britain's Children, the BBC goes behind the scenes of the footballer's free school meals campaign.

## Blindian Project: Celebrating black and South Asian relationships
 - [https://www.bbc.co.uk/news/world-us-canada-55370482](https://www.bbc.co.uk/news/world-us-canada-55370482)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-12-19 00:00:32+00:00

Blindian Project runs workshops to prepare couples for tricky family introductions.

