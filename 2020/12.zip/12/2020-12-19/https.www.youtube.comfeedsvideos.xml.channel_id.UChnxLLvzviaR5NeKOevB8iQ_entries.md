# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Tripping Hard with the Sleepy Circuits Hypno (Video Synthesis!)
 - [https://www.youtube.com/watch?v=SXUk_2qZLVA](https://www.youtube.com/watch?v=SXUk_2qZLVA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2020-12-19 00:00:00+00:00

The Sleepy Circuits Hypno is a Eurorack-compatible digital video synthesis module. It feeds weird things to your eyeballs. We're gonna dive in deep. Let's get zonked.
Link to Hypno at Sleepy Circuits: http://bit.ly/sleepyhypno

00:00 - intro
02:23 - comparison to lzx
03:40 - walkthrough
12:04 - patch 01
14:52 - video input
16:17 - patch 02
16:59 - patch 03
18:22 - patch 04
16:17 - patch 05
20:54 - patch 06
23:23 - patch 07
24:45 - patch 08
------------------------------------
Thank you for watching. My name is Jeremy, and this is Red Means Recording. I've been making music for a few decades now, and this channel is a place to make music and to talk about the tools and techniques to make music with. We'll use synths, drum machines, modular gear, and software. 

If you'd like to support the channel, I have a Patreon:  http://bit.ly/rmrpatreon

I have music as "Jeremy Blake" on all the major services: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

I have some merch here: http://bit.ly/rmrshirts

And you can connect with me here: 
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

