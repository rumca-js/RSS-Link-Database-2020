# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## My Apology To Facebook
 - [https://www.youtube.com/watch?v=PTPreIUN2g0](https://www.youtube.com/watch?v=PTPreIUN2g0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-12-19 00:00:00+00:00

Check out BLUblox, my favorite evidence based blue light glasses: https://www.blublox.com/jp
To get 15% off, use the discount code: JP

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Here’s my apology video to Facebook after they threatened to ban me for violating their community guidelines. With censorship, fact checkers, and the threat to be deplatformed, I now realize that speaking truth and empowering people is a direct violation of their community guidelines. I couldn’t be more sorry.

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

