# Source:Luetin09, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC8RfCCzWsMgNspTI-GTFenQ, language:en-US

## 40K DARK TOMES , DARK TIDE, DARK IMPERIUM & RANTS | Warhammer 40,0000 Lore/News
 - [https://www.youtube.com/watch?v=CQGtwM0qM7s](https://www.youtube.com/watch?v=CQGtwM0qM7s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC8RfCCzWsMgNspTI-GTFenQ
 - date published: 2020-12-19 00:00:00+00:00

► Subscribe: http://goo.gl/oeZMBS 
► Siege Studios: https://siegestudios.co.uk/
► Goblin Gaming: (Get - 20% off 40K Products) https://tinyurl.com/6vwcayvj
► Premium Storage Solutions: https://www.crystal-fortress.com/
► Patreon: https://www.patreon.com/Luetin 
► Twitch: http://www.twitch.tv/Luetin
► Twitter: http://twitter.com/luetin09

Deathwing clip - playing with https://www.youtube.com/c/QuiteShallow

https://www.warhammer-community.com/2020/12/05/the-warhammer-preview-online-black-library/

https://www.blacklibrary.com/all-products/celestine-ebook-2019.html
https://www.blacklibrary.com/warhammer-40000/novels/dead-sky-black-sun-ebook.html
https://www.blacklibrary.com/Home/Search-Results.html?__csrfToken=SI2O9Kw0IJMfOzIL2Qq3QxIuAv0wxzhMy2W0dOICq0mW&filter_type=6&filter_Action=0&filter_name=SearchTerm&submit=GO&filter_value=eisenhorn

Timestamps:
0:00 Intro
1:08 Dark Tide
5:34 Black Library Releases
7:37 Mortis
9:36 Dark Imperium
10:53 Retcon Rant
16:48 Dark Imperium & Godblight
22:16 Swords of Calth
25:30 Penitent
26:32 Gate of Bones
28:22 Liber Xeno
32:02 THRAKA
33:40 Book of Martyrs
35:48 Audiobook Club 2021

► BGM Credits:
► Kevin MacLeod (Royalty Free Music): http://incompetech.com/music/
► https://epidemicsound.com

This video is an opinion editorial commentary.
Copyright Disclaimer Under Section 107 of the Copyright Act 1976, allowance is made for fair use purposes such as criticism, commentary, parody, news reporting, teaching, scholarship, and research.

All works used in this video (Images, audio etc) belong to their respective authors
(This does not include the audio commentary or licensed BGM).

Games workshop, Warhammer 40,000, Warhammer, 40k, Space Marine Etc are all Trademarks of Games Workshop Ltd. Games Workshop does not endorse or support the 'Lore' videos. All views and opinions expressed in this video belong to Luetin09 and in no way reflect the views or opinions of Games Workshop Ltd.

