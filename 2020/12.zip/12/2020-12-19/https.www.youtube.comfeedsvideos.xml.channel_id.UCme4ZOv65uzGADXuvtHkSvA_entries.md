# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Ewangelia Mateusza ||  Rozdział 22
 - [https://www.youtube.com/watch?v=4_UcDxBNSic](https://www.youtube.com/watch?v=4_UcDxBNSic)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-12-20 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! 
 
UWAGA WYZWANIE i to życiodajne!
Codziennie razem czytamy 1 rozdział życiodajnego SŁOWA BOGA. 
Dołącz do nas! Razem przeczytamy całe Pismo Święte!

Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.

________________________________________

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Mocno stronniczy [#25] Dwóch papieży
 - [https://www.youtube.com/watch?v=2_z13xYghyU](https://www.youtube.com/watch?v=2_z13xYghyU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-12-20 00:00:00+00:00

@STREFAWODZA @Langustanapalmie 

Takich dwóch, jak Ci to nie ma :) Zapraszamy co niedzielę o godz: 10:oo, na premierę zupełnie niesłychanej serii ojców Tomasza Nowaka OP i Adama Szustaka OP.

zdjęcia i montaż: Marcin Jończyk
grafika: Sylwia Smoczyńska
dźwięk: Krzysztof Salawa
________________________________________

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.@Langustanapalmie @STREFAWODZA 

Takich dwóch, jak Ci to nie ma :) Zapraszamy co niedzielę o godz: 10:oo, na premierę zupełnie niesłychanej serii ojców Tomasza Nowaka OP i Adama Szustaka OP.

zdjęcia i montaż: Marcin Jończyk
grafika: Sylwia Smoczyńska
dźwięk: Krzysztof Salawa
________________________________________

Aby nas wesprzeć kliknij tu 
→ @anapalmie
→ @buj_Languste

♡ Historie potłuczone
Anchor → @a-na-palmie
Spreaker → @storie-potluczone
Spotify → @
Apple → @
Google Podcasts → @

♡  Pismo Święte: 
Anchor → @a-na-palmie
Spreaker → @zeczytaj-pismo-swiete-z-langusta
Spotify →  @
Apple →  @
Google Podcasts → @

Zapraszamy na nowy portal :
→ @
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ @anie

Więcej nagrań o. Adama znajdziesz na: 
→ @
Można nas również znaleźć na Facebooku: 
→ @aNaPalmie
Twitterze: 
→ @aPalmowa
Instagramie: 
→ @anapalmie/

Zapraszamy.

## Pogromcy potworów [#03] Zombie
 - [https://www.youtube.com/watch?v=kRera0XEFqk](https://www.youtube.com/watch?v=kRera0XEFqk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-12-20 00:00:00+00:00

#rekolekcje #PogromcyPotworów @Langustanapalmie 

Potworami (ogrami, wampirami) możemy nazywać toksyczne postawy, relacje i pragnienia. Ojciec Adam opowiada, jak je w sobie i innych zidentyfikować, pracować nad nimi i naprawić. Podpowiada też, jak zaprosić do tej „pracy” Boga. – Zapraszam cię, byś i ty na ten następny odcinek drogi ku wieczności, którym niewątpliwie będzie kolejny rok twojego życia, wziął Słowo dane nam przez Pana Boga w liturgii. Wierzę, że Ono, jeśli zaczniesz je czytać, rozważać i przykładać do swojego życia, prawdziwie stanie się dla ciebie lampą, która nie tylko oświetla świat wokoło, ale i rozprasza ciemności duszy, żeby nieprzerwanie mogło cię nasycać Boże Światło. Jak zawsze, pozostaje tylko jedno pytanie: czy Mu uwierzysz i otworzysz swoje uszy?
________________________________________

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#212] Czy żyjesz według woli Bożej?
 - [https://www.youtube.com/watch?v=iOgsGlFZfMg](https://www.youtube.com/watch?v=iOgsGlFZfMg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-12-19 00:00:00+00:00

​@Langustanapalmie #cnn #dobrewiadomości

IV Niedziela Adwentu, Rok B

1. czytanie (2 Sm 7, 1-5. 8b-12. 14a. 16)

Gdy król Dawid zamieszkał w swoim domu, a Pan poskromił dokoła wszystkich jego wrogów, rzekł król do proroka Natana: «Spójrz, ja mieszkam w pałacu cedrowym, a Arka Boża mieszka w namiocie». Natan powiedział do króla: «Uczyń wszystko, co zamierzasz w sercu, gdyż Pan jest z tobą». Lecz tej samej nocy Pan skierował do Natana następujące słowa: «Idź i powiedz mojemu słudze, Dawidowi: To mówi Pan: „Czy ty zbudujesz Mi dom na mieszkanie? Zabrałem cię z pastwiska spośród owiec, abyś był władcą nad ludem moim, nad Izraelem. I byłem z tobą wszędzie, dokąd się udałeś, wytraciłem przed tobą wszystkich twoich nieprzyjaciół.
Dam ci sławę największych ludzi na ziemi. Wyznaczę miejsce mojemu ludowi, Izraelowi, i osadzę go tam, i będzie mieszkał na swoim miejscu, a nie poruszy się więcej i ludzie nikczemni nie będą go już uciskać jak dawniej. Od czasu, kiedy ustanowiłem sędziów nad ludem moim izraelskim, obdarzyłem cię pokojem ze wszystkimi wrogami. Tobie też Pan zapowiedział, że sam Pan dom ci zbuduje.
Kiedy wypełnią się twoje dni i spoczniesz obok swych przodków, wtedy wzbudzę po tobie potomka twojego, który wyjdzie z twoich wnętrzności, i utwierdzę jego królestwo. Ja będę mu ojcem, a on będzie Mi synem. Przede Mną dom twój i twoje królestwo będzie trwać na wieki. Twój tron będzie utwierdzony na wieki”».

2. czytanie (Rz 16, 25-27)

Bracia: Temu, który ma moc utwierdzić was zgodnie z Ewangelią i moim głoszeniem Jezusa Chrystusa, zgodnie z objawioną tajemnicą, dla dawnych wieków ukrytą, teraz jednak ujawnioną, a przez pisma prorockie na rozkaz odwiecznego Boga wszystkim narodom obwieszczoną, dla skłonienia ich do posłuszeństwa wierze, Bogu, który jedynie jest mądry, przez Jezusa Chrystusa, niech będzie chwała na wieki wieków! Amen.

Ewangelia (Łk 1, 26-38)

Bóg posłał anioła Gabriela do miasta w Galilei, zwanego Nazaret, do dziewicy poślubionej mężowi imieniem Józef, z rodu Dawida; a dziewicy było na imię Maryja.
Wszedłszy do Niej, Anioł rzekł: «Bądź pozdrowiona, łaski pełna, Pan z Tobą, błogosławiona jesteś między niewiastami ». Ona zmieszała się na te słowa i rozważała, co by miało znaczyć to pozdrowienie. Lecz anioł rzekł do Niej: «Nie bój się, Maryjo, znalazłaś bowiem łaskę u Boga. Oto poczniesz i porodzisz Syna, któremu nadasz imię Jezus. Będzie on wielki i zostanie nazwany Synem Najwyższego, a Pan Bóg da Mu tron Jego praojca, Dawida. Będzie panował nad domem Jakuba na wieki, a Jego panowaniu nie będzie końca».
Na to Maryja rzekła do anioła: «Jakże się to stanie, skoro nie znam męża?»
Anioł Jej odpowiedział: «Duch Święty zstąpi na Ciebie i moc Najwyższego okryje Cię cieniem. Dlatego też Święte, które się narodzi, będzie nazwane Synem Bożym. a oto również krewna Twoja, Elżbieta, poczęła w swej starości syna i jest już w szóstym miesiącu ta, którą miano za niepłodną. Dla Boga bowiem nie ma nic niemożliwego».
Na to rzekła Maryja: «Oto ja służebnica Pańska, niech mi się stanie według słowa twego».
Wtedy odszedł od Niej Anioł.
________________________________________

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Ewangelia Mateusza ||  Rozdział 21
 - [https://www.youtube.com/watch?v=na2aPnpTB4I](https://www.youtube.com/watch?v=na2aPnpTB4I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-12-19 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! 
 
UWAGA WYZWANIE i to życiodajne!
Codziennie razem czytamy 1 rozdział życiodajnego SŁOWA BOGA. 
Dołącz do nas! Razem przeczytamy całe Pismo Święte!

Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.

________________________________________

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Roraty [#18] W ogniu
 - [https://www.youtube.com/watch?v=MHZUoZsTWxA](https://www.youtube.com/watch?v=MHZUoZsTWxA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-12-19 00:00:00+00:00

#Roraty2020 #Adwent #PrzyjdźPanieJezu

Zamiast WSTAWAKÓW - Roraty na cały ADWENT 2020, czyli trzy i pół tygodnia z Jezusem przyglądającym się Ojcu.

Zapraszamy by włączyć się w Adwentową Akcję Charytatywną Fundacji Malak.

"TROSKA” Adwentowa Akcja Charytatywna rzecz dzieci cierpiących na zaburzenia psychiczne. Do Wigilii będziemy zbierać darowizny na remont i wyposażenie sal pacjentów w Mazowieckim Centrum Neuropsychiatrii. 

“TROSKA” to akcja pełna czułości i delikatności, a przede wszystkim zatroskania.
 
Wszystkie informacje na temat zbiórki będą zamieszczane tutaj:
https://charytatywnie.fundacjamalak.pl/ 

nr konta do wpłat tradycyjnych. 

42 2490 0005 0000 4600 1184 3564 PLN
IBAN: PL 42 2490 0005 0000 4600 1184 3564 
BIC/SWIFT: ALBPPLPW
________________________________________

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

