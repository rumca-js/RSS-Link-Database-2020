# Source:BezPlanu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g, language:pl-PL

## Brakuje benzyny - Wenezuela [4K]
 - [https://www.youtube.com/watch?v=30Qi8TsdiGc](https://www.youtube.com/watch?v=30Qi8TsdiGc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g
 - date published: 2020-12-19 00:00:00+00:00

Wszystkie odcinki chronologicznie: http://bit.ly/2MqAO7Q
(można też klikać w kartę "Następny odcinek" pojawiającą się pod koniec każdego filmu po prawej stronie u góry)

Wsparcie na Patronite: http://bit.ly/2KsFTZk 
Instagram: http://instagram.com/bezplanu_czukesky 
Facebook: https://www.facebook.com/BezPlanu.tv

Czas akcji: czerwiec 2018

Dźwięk: Mateusz Czerniakowski

