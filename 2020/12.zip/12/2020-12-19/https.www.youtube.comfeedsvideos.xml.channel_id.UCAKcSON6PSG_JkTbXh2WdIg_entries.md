# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Dan Auerbach - three live performances (2017; 2018)
 - [https://www.youtube.com/watch?v=YzH3fBl0Srs](https://www.youtube.com/watch?v=YzH3fBl0Srs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-12-19 00:00:00+00:00

On Friday, Dec. 18, the Black Keys released a deluxe 10-year anniversary edition of their breakthrough album, "Brothers." The Black Keys comprise the duo Dan Auerbach and Patrick Carney. Beyond their signature band, both musicians are also involved in other music projects. Auerbach performs as a solo artist, and he's visited our studio to perform with the Easy Eye Revue and with artist Robert Finley. Here are three live performances by Dan Auerbach in honor of the Black Keys' new anniversary album release.

SONGS PERFORMED
0:00 "Stand By My Girl" (Live From Here, 2017)
3:32 "Medicine Woman" (The Current, 2018)
6:22 "Shine On Me" (The Current, 2018)

PERSONNEL
Dan Auerbach – guitar, vocals
Nick Bockrath – guitar (2017 performance)
Gene Chrisman – drums (2017 performance)
Robert Finley – vocals (2018 studio session)
Ray Jacildo – organ, xylophone (2017 performance)
Pat McLaughlin – mandolin, backing vocals 
Russ Pahl – pedal steel; Dobro resonator
Dave Roe – bass 
Dante Schwebel – guitar, backing vocals (2018 studio session)
Bobby Wood – keys (2017 performance)

CREDITS
Video & Photo: Ben Miller; Nate Ryan
Audio: Sam Hudson; Michael DeMark
Production: Jeffy Hnilicka; Tom Campbell; Anna Weggel

FIND MORE:
2017 Live From Here episode: https://www.livefromhere.org/shows/2017/10/28/october-28-2017-broadcast-with-dan-auerbach-hilary-hahn-robert-finley-fiona-apple-and-nick
2018 studio session: https://www.thecurrent.org/feature/2018/04/03/dan-auerbach-and-the-easy-eye-sound-revue-perform-in-the-currents-studio

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#danauerbach

