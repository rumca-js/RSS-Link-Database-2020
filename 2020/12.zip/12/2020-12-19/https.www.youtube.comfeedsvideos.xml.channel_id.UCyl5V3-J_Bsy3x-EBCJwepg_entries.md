# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Top 10 Prophetic Quotes From GK Chesterton
 - [https://www.youtube.com/watch?v=te1-gDhq3DU](https://www.youtube.com/watch?v=te1-gDhq3DU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-12-19 00:00:00+00:00

G.K. Chesterton wrote essays on philosophy, religion, politics, and fiction in the early 20th century. Kyle and Ethan from The Babylon Bee do a deep dive on his most prophetic quotes. Prophecy? FULFILLED!

See the full show here:
https://youtu.be/tRGn9TxlXS0

Subscribe to The Babylon Bee to get more quality Chestertonian content.

Hit the bell to get your daily dose of fake news that you can trust.

