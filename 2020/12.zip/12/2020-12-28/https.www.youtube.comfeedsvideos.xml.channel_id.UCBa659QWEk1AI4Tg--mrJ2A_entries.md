# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## How Weird Is My Audience? I Polled 15,408 People To Find Out
 - [https://www.youtube.com/watch?v=dcuNq3Bw9Xs](https://www.youtube.com/watch?v=dcuNq3Bw9Xs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2020-12-28 00:00:00+00:00

I asked my audience six questions: some sensible, some ridiculous. I compared their results to the public. And the results were... interesting. • Graphics by William Marler: https://wmad.co.uk and his Lungs Podcast: https://lungspodcast.co.uk

Audio mix by Graham Haerther
Owl photo credit: Amol Mende via Pexels https://www.pexels.com/photo/brown-and-white-owl-close-up-photography-2683982/
Distracted Boyfriend photo credit: Antonio Guillem via Shutterstock, used under license,  https://www.shutterstock.com/image-photo/disloyal-man-walking-his-girlfriend-looking-297886754

Chuck Testa is from Rhett and Link's Commercial Kings on IFC: https://www.youtube.com/watch?v=LJP1DphOWPs

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

