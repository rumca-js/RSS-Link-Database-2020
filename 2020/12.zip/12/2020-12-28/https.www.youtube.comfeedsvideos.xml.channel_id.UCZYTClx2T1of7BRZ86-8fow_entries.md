# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## The Fly That Lays Eggs in Toad Nostrils
 - [https://www.youtube.com/watch?v=OvaxW1TqhPY](https://www.youtube.com/watch?v=OvaxW1TqhPY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2020-12-29 00:00:00+00:00

We were probably all told to quit picking our noses at one point, and by most standards, this is good advice. But if you were a toad, it might come in handy to scratch away blowfly eggs.

Hosted by: Rose Bear Don't Walk

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Marwan Hassoun, Jb Taishoff, Bd_Tmprd, Harrison Mills, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Sam Buck, Christopher R Boucher, Eric Jensen, Lehel Kovacs, Adam Brainard, Greg, Ash, Sam Lutfi, Piya Shedden, KatieMarie Magnone, Scott Satovsky Jr, charles george, Alex Hackman, Chris Peters, Kevin Bealer
----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://doi.org/10.1111/mve.12328
https://doi.org/10.1016/j.ijppaw.2019.09.005
https://doi.org/10.1007/s10393-012-0785-3
https://doi.org/10.1007/s00049-014-0157-2 
https://www.nature.com/scitable/knowledge/library/bioindicators-using-organisms-to-measure-environmental-impacts-16821310/

Image Sources:
https://www.istockphoto.com/vector/young-woman-facial-expressions-gm643300604-116614169
https://www.istockphoto.com/vector/pattern-of-creeping-flies-gm849757882-139623555
https://www.istockphoto.com/vector/bluebottle-fly-insect-species-calliphora-vomitoria-bug-animal-nature-macro-gm518585094-90114635
https://commons.wikimedia.org/wiki/File:Lucilia.bufonivora.-.lindsey.jpg (https://creativecommons.org/licenses/by-sa/2.5/legalcode)
https://www.istockphoto.com/photo/lush-green-leaf-with-water-droplets-natural-fresh-background-gm937956538-256513632
https://www.istockphoto.com/photo/common-toad-with-toadfly-larvae-near-its-nostrils-amsterdamse-waterleiding-duinen-gm1127623793-297271322
https://www.istockphoto.com/vector/cute-vector-sitting-green-toad-with-fly-halloween-character-icon-autumn-all-saints-gm1266762441-371445489
https://www.istockphoto.com/vector/marshland-early-morning-gm92733103-9511482
https://commons.wikimedia.org/wiki/File:Crapaud_commun_(Bufo_bufo)_parasit%C3%A9_par_Lucilia_bufonivora_(3)_-_Baie_de_Somme.jpg (Image Modified) (https://creativecommons.org/licenses/by-sa/4.0/legalcode)
https://www.storyblocks.com/video/stock/modern-city-in-the-evening-at-sunset-smoke-comes-out-of-the-pipes-of-power-plants-and-factories-of-the-modern-neighborhood-on-the-outskirts-of-the-metropolis-urbanization-evsnwrxfgijvblz5s

## Doggerland: A Real-Life Atlantis
 - [https://www.youtube.com/watch?v=mDG3CXASWBs](https://www.youtube.com/watch?v=mDG3CXASWBs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2020-12-28 00:00:00+00:00

Though we probably won’t find a literal Atlantis beneath the sea, that doesn’t mean that a human settlement hasn’t ever been lost to the water. Meet Doggerland. 

Go to http://Brilliant.org/SciShow to try their Geometry Fundamentals course. The first 200 subscribers get 20% off an annual Premium subscription.

Hosted by: Michael Aranda

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org

----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Marwan Hassoun, Jb Taishoff, Bd_Tmprd, Harrison Mills, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Sam Buck, Christopher R Boucher, Eric Jensen, Lehel Kovacs, Adam Brainard, Greg, Ash, Sam Lutfi, Piya Shedden, KatieMarie Magnone, Scott Satovsky Jr, charles george, Alex Hackman, Chris Peters, Kevin Bealer
----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://www.sciencedirect.com/science/article/abs/pii/S2352409X16303649 
https://www.sciencedirect.com/science/article/abs/pii/S2352409X16303649 
https://www.nationalgeographic.com/magazine/2012/12/doggerland/ 
https://www.livescience.com/64176-lost-city-atlantis-spain.html 
https://www.pnas.org/content/116/44/22081 
https://www.sciencemag.org/news/2020/01/relics-washed-beaches-reveal-lost-world-beneath-north-sea 
https://www.wired.com/2015/11/hunting-for-dna-in-doggerland-an-ancient-land-beneath-the-north-sea/ 
https://www.researchgate.net/publication/247936451_Mapping_Doggerland_The_Mesolithic_Landscapes_of_the_Southern_North_Sea 
https://science.sciencemag.org/content/347/6225/998.abstract?sid=2b97d7c5-b191-4650-bbe0-b0411377aa6e 
http://journals.cambridge.org/abstract_S0079497X00002176 
https://sp.lyellcollection.org/content/175/1/393 
https://www.researchgate.net/publication/228667700_The_catastrophic_final_flooding_of_Doggerland_by_the_Storegga_Slide_tsunami 
https://www.sciencedirect.com/science/article/pii/S1463500314001164 
https://www.sciencedirect.com/science/article/abs/pii/S0264817204001771 
https://onlinelibrary.wiley.com/doi/epdf/10.2307/4014064 
http://www.bbc.com/earth/story/20160118-the-atlantis-style-myths-of-sunken-lands-that-are-really-true 

Image Sources:
https://www.istockphoto.com/photo/ruins-of-the-atlantis-civilization-underwater-ruins-gm1284403954-381547305
https://www.istockphoto.com/photo/global-warming-gm157562375-11857524
https://www.istockphoto.com/photo/europe-3d-render-topographic-map-color-gm935987224-256052870
https://www.istockphoto.com/vector/germany-country-map-gm470863170-63207419
https://www.istockphoto.com/photo/archaeologist-in-the-field-gm471833521-26608740
https://www.istockphoto.com/vector/loading-an-oil-tanker-gm188059481-29884646
https://www.istockphoto.com/vector/set-of-ships-in-modern-flat-style-gm873960956-244049126
https://www.istockphoto.com/photo/drilled-core-samples-gm175175906-21837660
https://www.istockphoto.com/photo/green-forest-with-bright-sun-gm1179765765-330249344
https://www.istockphoto.com/photo/birch-forest-gm155135758-18245778
https://www.istockphoto.com/photo/norfolk-island-pine-trunk-gm1224055264-359766289
https://www.istockphoto.com/photo/oak-tree-and-acorns-gm649330158-117937983
https://www.istockphoto.com/photo/blooming-hazel-tree-gm496832796-78788187
https://www.istockphoto.com/photo/petrified-wood-gm1168231182-322488916
https://www.istockphoto.com/photo/tribe-of-hunter-gatherers-wearing-animal-skin-live-in-a-cave-leader-brings-animal-gm1194512903-340165489
https://www.istockphoto.com/photo/dyke-salt-marsh-and-coastline-aerial-view-gm867742386-144484635
https://www.istockphoto.com/photo/homegrown-fresh-harvest-of-orange-garden-carrots-gm1138757396-304139314
https://www.istockphoto.com/photo/white-tailed-deer-at-sunrise-gm1071599686-286770605
https://www.istockphoto.com/photo/wild-common-carp-gm519920656-90781689
https://www.storyblocks.com/video/stock/amazing-view-of-sunset-over-the-rocks-and-the-north-sea-on-the-most-southern-point-of-norway-in-lindesnes-south-cape-vest-agder-b58iqfstqjmleblef
https://www.istockphoto.com/photo/watercolor-world-map-gm1209206490-349821409
https://www.istockphoto.com/photo/extreme-huge-wave-breaking-on-the-coast-gm1199712027-343361381

