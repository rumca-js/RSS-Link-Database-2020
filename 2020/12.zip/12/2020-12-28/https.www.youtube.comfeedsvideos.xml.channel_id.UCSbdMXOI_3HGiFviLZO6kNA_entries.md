# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## Reddit Discovers SERIOUS Oculus Quest 2 Manufacturing Flaws
 - [https://www.youtube.com/watch?v=Om_KQkwaKr0](https://www.youtube.com/watch?v=Om_KQkwaKr0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-12-29 00:00:00+00:00

Hello and welcome to TUESDAY NEWSDAY! Your number one resource for the entire weeks worth of VR news. Today I will be covering a number of topics but the most pressing one is a serious manufacturing flaws with certain oculus Quest 2s. this serves as a PSA for all new VR owners that may not know what VR is "supposed" to look like. just sayin, it ain't supposed to be blurry. 

Thanks to ridge wallet for sponsoring this weeks video!
 get yours here or use code Thrill at checkout: ridge.com/THRILL + 10% off.

My links:
Twitch Stream TODAY!
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill

Sources: 

https://www.reddit.com/r/OculusQuest/comments/jqi2ia/what_bad_lenses_look_like/
https://www.reddit.com/r/OculusQuest/comments/jtbysd/visual_differences_between_lenses_made_in_august/?utm_medium=android_app&utm_source=share
https://www.reddit.com/r/OculusQuest/comments/keap9w/on_my_fourth_quest_finally_got_great_lenses_world/?utm_medium=android_app&utm_source=share
https://www.reddit.com/r/OculusQuest/comments/jrxm52/downgrade/
https://www.reddit.com/r/OculusQuest/comments/jn3ped/seeing_more_godrays_on_quest_2s_bought_from/

VirtuallyReal:
https://www.youtube.com/watch?v=5_oRPSdB5OQ
https://www.roadtovr.com/oculus-quest-2-facebook-account-required-age-13-years-old/
https://www.roadtovr.com/half-life-alyx-steam-best-most-rated-game/
https://uploadvr.com/microsoft-flight-sim-vr-players-performance-issues/
https://vrscout.com/news/quantaar-fast-paced-melee-vr-2021-2/
https://uploadvr.com/microsoft-flight-sim-vr-players-performance-issues/
https://twitter.com/TheeBeardedBard/status/1342297616919367680

