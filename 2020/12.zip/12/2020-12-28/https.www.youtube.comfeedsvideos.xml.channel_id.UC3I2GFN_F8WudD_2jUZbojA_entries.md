# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Blu & Exile - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=Xo8H6aS16JM](https://www.youtube.com/watch?v=Xo8H6aS16JM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-12-28 00:00:00+00:00

http://KEXP.ORG presents Blu & Exile sharing a live performance recorded exclusively for KEXP and talking to Gabriel Teodros. Recorded December 17, 2020.

Songs:
Blue As I Can Be
True and Livin'
Miles Davis
The Feeling
Music Is My Everything (ft. Jimetta Rose & Choosey)

Session recorded at Record Box in Long Beach, CA
DP: Joey Lopez
Audio engineer: Jose Jurado

http://smarturl.it/bluandexile
http://thedirtyscience.com
http://recordboxtruck.com
http://kexp.org

