# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Dear Electric Cars!
 - [https://www.youtube.com/watch?v=pJlA2J92Fw4](https://www.youtube.com/watch?v=pJlA2J92Fw4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-12-29 00:00:00+00:00

Amid Apple Project Titan rumors... let's talk about future electric cars!

Porsche Taycan story: https://amp.theguardian.com/money/2020/nov/28/electric-cars-porsche-charging-network

Tesla vs Ford beef: https://electrek.co/2020/12/28/ford-throws-shade-tesla-quality-electric-vehicles-compromise/amp/

Gas vs electric range graph: https://www.energy.gov/eere/vehicles/fact-939-august-22-2016-all-electric-vehicle-ranges-can-exceed-those-some-gasoline

Thumbnail art: https://magictorch.com/macformat-various-projects

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Jordyn Edmonds http://smarturl.it/jordynedmonds 
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

