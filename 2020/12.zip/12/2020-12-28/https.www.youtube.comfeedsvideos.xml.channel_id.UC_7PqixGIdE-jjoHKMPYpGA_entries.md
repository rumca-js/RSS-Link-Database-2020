# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Szczepionka mRNA - czy są naukowe podstawy do obaw?
 - [https://www.youtube.com/watch?v=fHYwxnpH38o](https://www.youtube.com/watch?v=fHYwxnpH38o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2020-12-29 00:00:00+00:00

👉 Patronite ► https://patronite.pl/NaukowyBelkot 
👕 Nasze koszulki ► https://naukowybelkot.shoplo.com/
📚 Moja książka ► https://altenberg.pl/geny/
📚 E-book ► https://tinyurl.com/pnp-ebook
🎧 Mix audio ► http://ratstudios.pl/

W Nature ukazała się praca, z której wynika, że tylko Rosjanie są mniej skłonni do przyjęcia szczepionki przeciw COVID-19 niż Polacy. To nie jest dobry prognostyk - bez szczepionki nie opanujemy pandemii. Stąd zdecydowałem się na krótkie wyjaśnienie czym jest ta zastosowana technologia mRNA i czy jej biologiczne i naukowe podstawy dają nam rzeczywistą okazję do obaw.

🎞 Film o dogmacie centralnym, DNA, RNA itd:
https://www.youtube.com/watch?v=CUb9zKBZ0Ns

🎞 Film Tomka Rożka (Nauka to lubię):
https://www.youtube.com/watch?v=BE0sADYOSZc

🎞 Film Kasi Gandor:
https://www.youtube.com/watch?v=XRW9E5Gq_Ew

Subskrypcja ► https://youtube.com/c/UwagaNaukowyBelkot
Facebook ► https://facebook.com/UwagaNaukowyBelkot
Twitter ► https://twitter.com/NaukowyBelkot
Instagram ► https://www.instagram.com/NaukowyBelkot/

Wyłącznie Naukowy Bełkot ► https://goo.gl/Do7VCc
Grupa na facebooku ► https://goo.gl/HP8J83

===
Rozkład jazdy:

0:00 Wstęp
2:07 Trzy komiksy
7:34 Czwarty scenariusz
9:41 Szybki FAQ

===
Źródła (wybrane):

Gen. Ukryta historia. Siddharta Mukherjee
A History of Molecular Biology. M. Morange
Biochemia. J.M. Berg i in.
Podstawy genetyki dla studentów i lekarzy. G. Drewa i in.
Krótkie wykłady. Genetyka. H. Fletcher i in.
Extrachromosomal DNA in eucaryotes. M. G. Rush i in.
Basic virology. E. K. Wagner i in.
Biologia. E.P. Solomon i in.
RNA-dependent DNA polymerase in virions of Rous sarcoma virus. H. Temin i in.
Cesarz wszystkich chorób. Biografia raka. Siddharta Mukherjee
A History of Cancer Chemotherapy. V. T. DeVita i in.
Immunobiology. C.A. Janneway i in.
https://informacje.pan.pl/index.php/informacje/materialy-dla-prasy/3210-stanowisko-7-zespolu-ds-covid-19-przy-prezesie-pan-szczepienie-jest-jedynym-racjonalnym-wyborem-dzieki-ktoremu-bedziemy-mogli-szybciej-wyjsc-z-pandemii
https://www.nature.com/articles/nrd.2017.243

