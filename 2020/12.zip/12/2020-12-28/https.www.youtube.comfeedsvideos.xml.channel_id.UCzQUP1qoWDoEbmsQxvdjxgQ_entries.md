# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## HBO MAX Removed "Chappelle's Show" after Dave Chappelle's Request
 - [https://www.youtube.com/watch?v=VogZVWPd4CI](https://www.youtube.com/watch?v=VogZVWPd4CI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2020-12-28 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1585 with Michael Kosta. https://open.spotify.com/episode/4XMWyMS0SxoloUWF5hoqdU?si=3nu84-pfRteJujwOAK3DxA

## Joe Rogan on "The Color of Money"
 - [https://www.youtube.com/watch?v=Pf4ag0lve-0](https://www.youtube.com/watch?v=Pf4ag0lve-0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2020-12-28 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1585 with Michael Kosta. https://open.spotify.com/episode/4XMWyMS0SxoloUWF5hoqdU?si=3nu84-pfRteJujwOAK3DxA

## The Shifting Nature of the Coronavirus
 - [https://www.youtube.com/watch?v=R59mzw0iPTY](https://www.youtube.com/watch?v=R59mzw0iPTY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2020-12-28 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1585 with Michael Kosta. https://open.spotify.com/episode/4XMWyMS0SxoloUWF5hoqdU?si=3nu84-pfRteJujwOAK3DxA

