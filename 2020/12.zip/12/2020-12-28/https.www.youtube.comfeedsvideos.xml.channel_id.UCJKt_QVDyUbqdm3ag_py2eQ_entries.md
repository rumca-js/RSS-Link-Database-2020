# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga Paula does XM: Jarre covers by Moog & Awesome (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=Ry-Gdejh_5w](https://www.youtube.com/watch?v=Ry-Gdejh_5w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-12-29 00:00:00+00:00

Two Jean-Michel Jarre Fasttracker covers by Moog and Awesome. Details below. Headphones recommended.

Jumplist:
00:00 Moog - Oxygene 2 (1998), original by Jarre (1976).
Art: Havok/Anthrox - Jesterday title (1992).

04:27 Awesome - Oxygene Part 9, but actually 8 (1998), Original by Jarre (1997).
Art: Seq/Union - Black Jack, 1st at Polish Autumn Party 1993
NOTE: So yes Awesome named this track part 9, but it is a cover of 8 in reality

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Normal mixing with 44336 Hz mixing for Oxygene 2 and 32244 Hz for Oxygene Part 9
- No panning, no 3D and DSP off. Anti-click disabled
- Modules report 20 channels for Oxygene 2 and 32 for Oxygene Part 9
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.

## Amiga music: Muffin - Psychedelic Project (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=SgI7IRjOW5w](https://www.youtube.com/watch?v=SgI7IRjOW5w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-12-28 00:00:00+00:00

"Psychedelic Project" by Muffin/Loff^Ambition (Hans Petter Flaaten), 13th at Kindergarden 1997 4 channels music competition. Art "WomSnake" by Peachy/TRSI^Masque, 1st at The Party 1992 graphics competition. Headphones recommended.

Made using real A1200 Rev. 1D.4 audio.

Visit my channel for more Amiga music.

## Amiga music: Punnik - Kubus [Final] (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=HPJfeOPMblo](https://www.youtube.com/watch?v=HPJfeOPMblo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-12-28 00:00:00+00:00

"Kubus [Final]" (2016) by Punnik/Knip 'n Plak (Richard J. Hof). Art "Up Rough City" by Spot/Up Rough, 4th at Datastorm 2014 graphics competition. Headphones recommended.

Made using real A1200 Rev. 1D.4 audio.

Visit my channel for more Amiga music.

## Amiga music: Some1 & Morrow - Paranoid Main (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=sixRTowwvIc](https://www.youtube.com/watch?v=sixRTowwvIc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-12-28 00:00:00+00:00

"Paranoid Main" (1997) by Some1 & Morrow/Rebels (Mikael Fyrek & Carl Johan Naes). Art "Dragon Title" (1995) by Tom Copper/Animators. Headphones recommended.

Made using Real A1200 Rev. 1D.4 audio.

Visit my channel for more Amiga music.

