# Source:SssethTzeentach, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCD6VugMZKRhSyzWEWA9W2fg, language:en-US

## Pharaoh Review | featuring Caesar 3 from the SPQR Series™
 - [https://www.youtube.com/watch?v=YA2UAeFMWFs](https://www.youtube.com/watch?v=YA2UAeFMWFs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCD6VugMZKRhSyzWEWA9W2fg
 - date published: 2020-12-28 00:17:47+00:00

The best of Trauma-based citybuilding since 1999.

Discounts on everything:
https://www.gog.com/partner/sseth

Useful resources, guides and FAQs:
http://pharaoh.heavengames.com/

Happy new year brothers.
Take care out there.
-----------------------
Send Sseth Shekels: https://www.paypal.me/SsethTzeentachGB
Send Sseth Shekels per video:  https://www.patreon.com/Sseth
Send Sseth Shekels / crypto: https://www.subscribestar.com/ssethtzeentach

Website: https://ssethtzeentach.com/
Twitter: https://twitter.com/SsethTzeentach
FB: https://www.facebook.com/sseth672/

