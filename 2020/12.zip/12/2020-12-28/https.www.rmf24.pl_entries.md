## Prof. Horban: Zaszczepieni na Covid-19 nie będą zarażali, bo nie będą zakażeni - RMF 24
 - [https://www.rmf24.pl/raporty/raport-koronawirus-z-chin/najnowsze-fakty/news-prof-horban-zaszczepieni-na-covid-19-nie-beda-zarazali-bo-ni,nId,4953501#crp_state=1](https://www.rmf24.pl/raporty/raport-koronawirus-z-chin/najnowsze-fakty/news-prof-horban-zaszczepieni-na-covid-19-nie-beda-zarazali-bo-ni,nId,4953501#crp_state=1)
 - RSS feed: https://www.rmf24.pl
 - date published: 2020-12-28 10:51:20+00:00

Prof. Horban: Zaszczepieni na Covid-19 nie będą zarażali, bo nie będą zakażeni - RMF 24

## Opisywała sytuację w Wuhanie na początku pandemii. 37-latka skazana na 4 lata więzienia - RMF 24
 - [https://www.rmf24.pl/raporty/raport-koronawirus-z-chin/najnowsze-fakty/news-opisywala-sytuacje-w-wuhanie-na-poczatku-pandemii-37-latka-s,nId,4953093#crp_state=1](https://www.rmf24.pl/raporty/raport-koronawirus-z-chin/najnowsze-fakty/news-opisywala-sytuacje-w-wuhanie-na-poczatku-pandemii-37-latka-s,nId,4953093#crp_state=1)
 - RSS feed: https://www.rmf24.pl
 - date published: 2020-12-28 06:56:12+00:00

Opisywała sytuację w Wuhanie na początku pandemii. 37-latka skazana na 4 lata więzienia - RMF 24

