# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Cyberpunk 2077 - Review
 - [https://www.youtube.com/watch?v=agvK3eLhHts](https://www.youtube.com/watch?v=agvK3eLhHts)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-12-29 00:00:00+00:00

Whether from a sense of obligation, or just because I enjoy a cyberpunk world; after 100 hours, I now feel qualified to give my thoughts on CYBERPUNK 2077!

#Cyberpunk #Cyberpunk2077

