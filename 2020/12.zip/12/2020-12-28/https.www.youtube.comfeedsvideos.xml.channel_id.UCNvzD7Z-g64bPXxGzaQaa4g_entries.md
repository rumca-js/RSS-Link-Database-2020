# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## The Most UNDERRATED GTA Game Ever
 - [https://www.youtube.com/watch?v=HoJtE_n2QMI](https://www.youtube.com/watch?v=HoJtE_n2QMI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-12-29 00:00:00+00:00

Grand Theft Auto 4 isn't talked about enough. Despite massive success, it still doesn't get enough love.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Johnny scene via:
Johnny scene: https://youtu.be/GHtspf4Xj3c

## 10 Strangely CREEPY Moments in 2020 Games
 - [https://www.youtube.com/watch?v=TSRtAhJyovU](https://www.youtube.com/watch?v=TSRtAhJyovU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-12-28 00:00:00+00:00

Video games often have extremely creepy moments, whether it be intentional or not. Here are some creepy moments from recent games - scary areas, weird characters, and disturbing glitches.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

