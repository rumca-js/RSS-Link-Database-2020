# Source:SciFun, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCWTA5Yd0rAkQt5-9etIFoBA, language:pl-PL

## Test Zabawek Naukowych #4: Lądownik Księżycowy
 - [https://www.youtube.com/watch?v=YINVZ4iWBfk](https://www.youtube.com/watch?v=YINVZ4iWBfk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCWTA5Yd0rAkQt5-9etIFoBA
 - date published: 2020-12-29 00:00:00+00:00

Scifun traci przytomność układając klocki. Tylko u nas.
NordVPN:
https://nordvpn.com/scifun

