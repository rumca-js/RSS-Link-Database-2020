# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Nicholas David - two songs at The Current (2013)
 - [https://www.youtube.com/watch?v=3YJ2HJROhQs](https://www.youtube.com/watch?v=3YJ2HJROhQs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-12-29 00:00:00+00:00

Seven years ago this week, Nicholas David visited The Current studio to play a set of songs ahead of his show at First Avenue. Nationally known for his performances and advancement to the finalist round on NBC's "The Voice," Nicholas David proudly calls Eagan, Minn., home — and this being Minnesota, we were all proud to call Nicholas David our own. Watch two performances by Nicholas David, recorded live in our studio in 2013. 

SONGS PERFORMED
0:00 "Lonely"
3:26 "Say Goodbye"

CREDITS
Video & Photo: Nate Ryan
Audio: Michael DeMark
Production: Derrick Stevens

FIND MORE:
2013 May studio session: 
https://www.thecurrent.org/feature/2013/05/02/nicholas-david
2013 December studio session:
https://www.thecurrent.org/feature/2013/12/27/nicholas-david-in-studio

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#nicholasdavid

