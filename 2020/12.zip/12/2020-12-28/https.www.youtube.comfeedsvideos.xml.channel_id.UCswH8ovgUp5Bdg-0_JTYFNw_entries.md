# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Why are we hypnotised by tech?
 - [https://www.youtube.com/watch?v=m9K93hTyqSA](https://www.youtube.com/watch?v=m9K93hTyqSA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-12-29 00:00:00+00:00

A clip from my Under The Skin podcast with Tristan Harris. Tristan is President and co-founder of Centre for Humane Technology. He is the co-host of the Your Undivided Attention podcast. You might recognise Tristan from the Social Dilemma documentary on Netflix.

You can listen to the rest of this podcast episode over on Luminary: http://luminary.link/russell

Check more episodes of my podcast here: https://www.youtube.com/watch?v=F-OeKV1JZGI&list=PL5BY9veyhGt7eapYiWXyxGuSxTcysPpJ7

More info on Tristan:
www.humanetech.com
www.humanetech.com/podcast
Twitter: @HumaneTech_
Instagram: @tristanharris

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

