# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Wonder Woman 1984 - A Ridiculous Disaster
 - [https://www.youtube.com/watch?v=PeieblTIw7A](https://www.youtube.com/watch?v=PeieblTIw7A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-12-28 00:00:00+00:00

So it turns out Wonder Woman 1984 is an even bigger mess than I expected. Join me as I do my best to make sense of it.

