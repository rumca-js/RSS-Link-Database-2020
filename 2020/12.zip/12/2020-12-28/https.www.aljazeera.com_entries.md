## Citizen journalist jailed for 4 years over Wuhan virus reporting | Coronavirus pandemic News | Al Jazeera
 - [https://www.aljazeera.com/news/2020/12/28/chinese-citizen-journalist-faces-trial-for-wuhan-virus-reporting](https://www.aljazeera.com/news/2020/12/28/chinese-citizen-journalist-faces-trial-for-wuhan-virus-reporting)
 - RSS feed: https://www.aljazeera.com
 - date published: 2020-12-28 06:57:00+00:00

Citizen journalist jailed for 4 years over Wuhan virus reporting | Coronavirus pandemic News | Al Jazeera

