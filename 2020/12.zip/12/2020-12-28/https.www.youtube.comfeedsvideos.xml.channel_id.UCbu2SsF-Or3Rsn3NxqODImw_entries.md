# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## 8 Most Anticipated Games of 2021
 - [https://www.youtube.com/watch?v=ZdZ-Qctc-_U](https://www.youtube.com/watch?v=ZdZ-Qctc-_U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-12-28 00:00:00+00:00

With 2020 coming to a close, it's time to look forward to 2021. Following on the heels of the release of Xbox Series X|S and PlayStation 5, there are a bunch of new games coming to both current- and last-gen hardware in the coming year.

In the video above, Persia goes over the games that we're most anticipating to see more of and get our hands on in 2021. It's a diverse list--from anticipated sequels like the unnamed follow-up to 2018's God of War to remasters of classic titles like Mass Effect: Legendary Edition. There's just a lot to look forward to!

