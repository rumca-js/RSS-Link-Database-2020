# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Cyberpunk 2077 Lawsuit⚖️ NEW Dresden Files Short📚 Thom's... Guitar🎸-FANTASY NEWS
 - [https://www.youtube.com/watch?v=UXyEs4ITVgU](https://www.youtube.com/watch?v=UXyEs4ITVgU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-12-29 00:00:00+00:00

From legal tea to new Dresden we got some Fantasy news. It is a light news week for the fantasy genre, but it is here! 

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

NEWS:
00:00 Intro
00:30 https://www.reddit.com/r/Fantasy/comments/klcips/120_sequels_series_books_and_shared_world_stories/ 
01:53 Dresden Short Story: https://www.jim-butcher.com/the-good-people 
02:45 Thom’s… guitar: https://twitter.com/WOTonPrime/status/1341805779678982149 
04:00 Dungeons and Dragons filming location: https://thewertzone.blogspot.com/2020/12/dungeons-dragons-movie-to-start.html 
04:30 LOTR Wraps Filming: https://comicbook.com/tv-shows/news/amazons-lord-of-the-rings-pilot-wrapped-filming/ 
05:43 Exorcist Director: https://screenrant.com/exorcist-2-movie-sequel-david-gordon-green-director/ 
06:37 Cyberpunk Lawsuit: https://screenrant.com/cyberpunk-2077-cd-projekt-red-lawsuit-bugs-glitches/
09:00 Scotty Got Beamed Up: https://screenrant.com/star-trek-james-doohan-scotty-ashes-space-station/

