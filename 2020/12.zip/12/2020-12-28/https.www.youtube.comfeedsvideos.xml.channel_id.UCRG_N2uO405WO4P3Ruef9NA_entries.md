# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## The biggest trends of 2020!
 - [https://www.youtube.com/watch?v=WaExyl0C2Ek](https://www.youtube.com/watch?v=WaExyl0C2Ek)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2020-12-29 00:00:00+00:00

Let's wrap up the biggest trends of the year and give some predictions for the future! Welcome to the 2020 Checkout.

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Crrowd ◄◄◄

Download the Android app: https://play.google.com/store/apps/details?id=com.crrowd
For iOS users: https://crrowd.com/ios

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► TechAltar links ◄◄◄

Merch: 
http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 

If you want to support TechAltar directly: 
https://flattr.com/@techaltar 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions ◄◄◄

Music by Edemski: https://soundcloud.com/edemski

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Time stamps ◄◄◄

0:00 Intro
0:48 Meta - chips
2:40 Meta - deglobalization
4:26 Meta - regulation intensifies
5:47 Highlight - New Form factors
6:16 Highlight - Bye OnePlus 
6:40 Highlight - Crrowd
7:37 Prediction - MacOS gains
8:38 Prediction - Moar foldables
9:12 Prediction - Moar regulation
9:35 - Outro

