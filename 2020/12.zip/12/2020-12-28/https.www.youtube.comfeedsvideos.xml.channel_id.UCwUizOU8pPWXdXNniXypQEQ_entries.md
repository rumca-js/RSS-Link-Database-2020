# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## When You Believe All The Propaganda
 - [https://www.youtube.com/watch?v=HKsDem1r4_A](https://www.youtube.com/watch?v=HKsDem1r4_A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-12-29 00:00:00+00:00

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

You’ll see what it’s like to believe all the propaganda on the news and mainstream media. You’ll be the smartest person according to you.

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

