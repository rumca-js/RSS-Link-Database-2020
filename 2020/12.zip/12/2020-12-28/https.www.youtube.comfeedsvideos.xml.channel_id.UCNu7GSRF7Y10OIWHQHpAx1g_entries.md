# Source:BezPlanu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g, language:pl-PL

## Pół hamburgera za miesięczną wypłatę
 - [https://www.youtube.com/watch?v=5lDlsy0_14g](https://www.youtube.com/watch?v=5lDlsy0_14g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g
 - date published: 2020-12-29 00:00:00+00:00

To ostatni odcinek BezPlanu w 2020 roku. Do zobaczenia w kolejnym:)

Sklep: https://bezplanu.com

Wszystkie odcinki chronologicznie: http://bit.ly/2MqAO7Q
(można też klikać w kartę "Następny odcinek" pojawiającą się pod koniec każdego filmu po prawej stronie u góry)

Wsparcie na Patronite: http://bit.ly/2KsFTZk 
Instagram: http://instagram.com/bezplanu_czukesky 
Facebook: https://www.facebook.com/BezPlanu.tv

Czas akcji: czerwiec 2018

Dźwięk: Mateusz Czerniakowski
Subtitles by Justyna Obruśnik justyna.obrusnik@gmail.com

