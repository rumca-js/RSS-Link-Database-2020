# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Russian authorities threaten to jail Navalny if he doesn't show up in Moscow by Tuesday morning
 - [https://www.cnn.com/2020/12/28/europe/navalny-russia-jail-threat-intl/index.html](https://www.cnn.com/2020/12/28/europe/navalny-russia-jail-threat-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 22:06:09+00:00

Russian law enforcement is threatening to jail opposition politician Alexey Navalny for failing to comply with the terms of his suspended sentence in a years-old case if he fails to show up for a hearing in Moscow on Tuesday morning, his lawyer and officials said.

## Trump's favorite newspaper has turned against him
 - [https://www.cnn.com/2020/12/28/media/new-york-post-donald-trump-editorial/index.html](https://www.cnn.com/2020/12/28/media/new-york-post-donald-trump-editorial/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 21:32:23+00:00

President Donald Trump's favorite newspaper has turned against him.

## Why Jake Tapper won't have Kayleigh McEnany and others on his shows
 - [https://www.cnn.com/videos/business/2020/12/27/tapper-some-reporters-bought-into-trumps-narrative.cnn](https://www.cnn.com/videos/business/2020/12/27/tapper-some-reporters-bought-into-trumps-narrative.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 20:27:39+00:00

CNN's Jake Tapper reflects on press coverage of President Trump and his administration.

## KISS play concert to 'KISS 2020 Goodbye'
 - [https://www.cnn.com/videos/entertainment/2020/12/28/kiss-play-concert-to-kiss-2020-goodbye.cnn](https://www.cnn.com/videos/entertainment/2020/12/28/kiss-play-concert-to-kiss-2020-goodbye.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 18:43:31+00:00

The legendary rock band is playing and streaming from Dubai on New Year's Eve. Rick Damigella talked with Gene Simmons about the show.

## Hilaria Baldwin responds to claims she has faked her Spanish heritage
 - [https://www.cnn.com/2020/12/28/entertainment/hilaria-baldwin-responds-spanish-trnd/index.html](https://www.cnn.com/2020/12/28/entertainment/hilaria-baldwin-responds-spanish-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 16:59:02+00:00

Hilaria Baldwin is responding to criticism that she has misled the public about her Spanish descent.

## Every investor in Britain's slave trade set to be detailed in new 'dictionary'
 - [https://www.cnn.com/2020/12/28/uk/britain-slave-trade-dictionary-scli-gbr-intl/index.html](https://www.cnn.com/2020/12/28/uk/britain-slave-trade-dictionary-scli-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 16:07:37+00:00

The first ever index of investors in Britain's extensive slave trade is being compiled by academics, after the project received £1 million ($1.4 million) in funding from the UK government.

## Stelter: Notable that Fox News hasn't promoted this
 - [https://www.cnn.com/videos/business/2020/12/28/trump-new-york-post-brian-stelter-nr-vpx.cnn](https://www.cnn.com/videos/business/2020/12/28/trump-new-york-post-brian-stelter-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 15:17:22+00:00

CNN's Brian Stelter explains the significance of a New York Post article calling on Trump to accept his defeat in the 2020 presidential election.

## Forced marriage survivor: My sister was killed because she left her forced marriage
 - [https://www.cnn.com/videos/world/2020/12/28/uk-forced-marriages-coronavirus-pandemic-lockdown-bashir-pkg-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2020/12/28/uk-forced-marriages-coronavirus-pandemic-lockdown-bashir-pkg-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 12:55:11+00:00

Trapped at home, isolated from the outside world, and prevented from returning to school -- this is life under lockdown for forced marriage victims in the United Kingdom. But with lockdown making it even harder for charities to identify victims there are concerns that hundreds of young people could be trapped at home with nowhere to escape. CNN's Nada Bashir reports.

## Hibernating primates like this tiny lemur could unlock cryogenic sleep for deep space missions
 - [https://www.cnn.com/2020/12/28/world/lemur-hibernation-deep-space-mission-scn-partner/index.html](https://www.cnn.com/2020/12/28/world/lemur-hibernation-deep-space-mission-scn-partner/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 12:43:41+00:00

Science fiction is shifting into reality. With humanity's plans to return to the moon this decade and further ambitions to travel to Mars in the next, we need to figure out how to keep astronauts healthy for these years-long missions. One solution long championed by science fiction is suspended animation, or putting humans in a hibernation-like sleep for the duration of travel time.

## Stimulus is here. But there are some big caveats
 - [https://www.cnn.com/2020/12/28/investing/premarket-stocks-trading/index.html](https://www.cnn.com/2020/12/28/investing/premarket-stocks-trading/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 12:19:00+00:00

President Donald Trump reversed course on Sunday, signing into law a massive $2.3 trillion dollar coronavirus relief and government funding bill that he had objected to at the last minute.

## 'Like a chisel going through your head': Greg Norman delivers graphic account of dealing with Covid-19 symptoms
 - [https://www.cnn.com/2020/12/28/golf/greg-norman-covid-19-spt-intl/index.html](https://www.cnn.com/2020/12/28/golf/greg-norman-covid-19-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 11:51:04+00:00

Golf great Greg Norman has graphically described his struggle dealing with Covid-19 symptoms after testing positive for the coronavirus.

## For 26 days in a row, more than 100,000 people have been hospitalized fighting coronavirus in US
 - [https://www.cnn.com/2020/12/28/health/us-coronavirus-monday/index.html](https://www.cnn.com/2020/12/28/health/us-coronavirus-monday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 11:39:12+00:00

As the US prepares to grapple with potential holiday Covid-19 surges, hospitals across the country have reported more than 100,000 patients for the 26th day in a row.

## How to distribute Covid-19 vaccines fairly around the world
 - [https://www.cnn.com/2020/12/28/opinions/covid-19-vaccine-world-distribution-ahmad-cousens/index.html](https://www.cnn.com/2020/12/28/opinions/covid-19-vaccine-world-distribution-ahmad-cousens/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 11:37:34+00:00

As the number of countries that have authorized the use of a Covid-19 vaccine grows, many are sighing with anticipated relief. Yet now comes another challenge: how do we distribute vaccines safely and equitably to those most in need in our own countries and across the world?

## EU begins massive Covid-19 vaccination drive amid new variant
 - [https://www.cnn.com/videos/world/2020/12/28/europe-european-union-coronavirus-vaccines-rollout-vanier-pkg-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2020/12/28/europe-european-union-coronavirus-vaccines-rollout-vanier-pkg-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 11:36:35+00:00

The European Union kicked off its Covid-19 vaccination campaign on December 27, with health care workers and senior citizens among the first groups of people to receive the vaccines. With tens of millions of doses distributed across the continent, the vaccination campaigns bring a measure of hope to a deadly year. CNN's Cyril Vanier reports.

## Investigators are looking at 'any and all possible motives' after identifying Nashville bomber
 - [https://www.cnn.com/2020/12/28/us/nashville-bomb-christmas-monday/index.html](https://www.cnn.com/2020/12/28/us/nashville-bomb-christmas-monday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 11:34:38+00:00

Investigators continue to look at "any and all possible motives" in the Nashville explosion after identifying the bomber as Anthony Quinn Warner.

## Dallas Mavericks blow out LA Clippers by 51 points
 - [https://www.cnn.com/2020/12/28/sport/nba-dallas-mavericks-la-clippers-blow-out-spt-intl/index.html](https://www.cnn.com/2020/12/28/sport/nba-dallas-mavericks-la-clippers-blow-out-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 11:18:50+00:00

Having lost their first two games of the season, the Dallas Mavericks stormed to a statement victory against the Los Angeles Clippers on Sunday, winning 124-73.

## The delay on Covid relief and government funding is the latest example of erratic behavior in the final weeks of the President's term
 - [https://www.cnn.com/2020/12/28/politics/donald-trump-covid-relief-bill/index.html](https://www.cnn.com/2020/12/28/politics/donald-trump-covid-relief-bill/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 11:13:34+00:00

President Donald Trump is driving the country through chaos from behind the wheel of his golf cart.

## The year the world gave up waiting for Big Tech to fix itself
 - [https://www.cnn.com/2020/12/28/tech/big-tech-crackdown-intl-hnk/index.html](https://www.cnn.com/2020/12/28/tech/big-tech-crackdown-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 10:34:44+00:00

The world's biggest tech companies faced a global reckoning in 2020 as the United States, the European Union and even China took dramatic steps to curb their dominance. That pressure won't be going away in the new year.

## Australia is the last Western hold out on the climate crisis. But some states and businesses are calling for change
 - [https://www.cnn.com/2020/12/27/australia/australia-renewable-energy-climate-intl-dst-hnk/index.html](https://www.cnn.com/2020/12/27/australia/australia-renewable-energy-climate-intl-dst-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 10:23:06+00:00

Deep in northeast Australia's outback, underneath grassy eucalypt woodlands and vast grazing lands scattered with cattle stations, lies one of the world's largest known untapped coal reserves.

## 12 wild things that happened in aviation in 2020
 - [https://www.cnn.com/travel/article/wild-aviation-year-2020/index.html](https://www.cnn.com/travel/article/wild-aviation-year-2020/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 10:11:11+00:00

This was a heinous year for the aviation industry. Absolutely horrendous, in fact.

## Pokémon plane takes off in Japan
 - [https://www.cnn.com/travel/article/pokemon-plane-solaseed-airlines-japan-intl-hnk/index.html](https://www.cnn.com/travel/article/pokemon-plane-solaseed-airlines-japan-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 09:55:14+00:00

It's a bird, it's a plane, it's a ... Jigglypuff?

## How the pandemic brought a rising tide of hunger to Europe
 - [https://www.cnn.com/2020/12/28/world/europe-hunger-food-poverty-intl/index.html](https://www.cnn.com/2020/12/28/world/europe-hunger-food-poverty-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 09:42:50+00:00

Life wasn't easy for Patricia, even before the pandemic hit.

## Roger Federer withdraws from 2021 Australian Open
 - [https://www.cnn.com/2020/12/28/tennis/roger-federer-2021-australian-open-spt-intl/index.html](https://www.cnn.com/2020/12/28/tennis/roger-federer-2021-australian-open-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 09:23:17+00:00

Roger Federer has withdrawn from the 2021 Australian Open, the tournament announced on Monday.

## Chinese journalist who documented Wuhan coronavirus outbreak jailed for 4 years
 - [https://www.cnn.com/2020/12/28/asia/china-journalist-zhang-zhan-intl-hnk/index.html](https://www.cnn.com/2020/12/28/asia/china-journalist-zhang-zhan-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 09:19:37+00:00

An independent Chinese journalist who reported from Wuhan at the height of the initial coronavirus outbreak has been jailed for four years by a Shanghai court, her lawyer said Monday.

## China tells Ant Group to quickly overhaul its business
 - [https://www.cnn.com/2020/12/28/tech/ant-group-china-regulators-intl-hnk/index.html](https://www.cnn.com/2020/12/28/tech/ant-group-china-regulators-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 09:05:35+00:00

China has ordered the country's biggest online payments platform to overhaul large swaths of its operations as regulators continue their efforts to rein in some of the most powerful Chinese internet companies.

## One of China's original 'wolf warriors,' Liu Xiaoming is to resign as ambassador to the UK after combative tenure
 - [https://www.cnn.com/2020/12/28/asia/china-uk-ambassador-liu-xiaoming-intl-hnk/index.html](https://www.cnn.com/2020/12/28/asia/china-uk-ambassador-liu-xiaoming-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 06:39:52+00:00

One of China's original "wolf warrior" diplomats is set to resign, ending a combative tenure dominated by controversies over Beijing's policies in Hong Kong and Xinjiang.

## Police identify Anthony Quinn Warner as Nashville bomber
 - [https://www.cnn.com/videos/us/2020/12/28/nashville-bomber-anthony-quinn-warner-zw-orig.cnn](https://www.cnn.com/videos/us/2020/12/28/nashville-bomber-anthony-quinn-warner-zw-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 05:48:45+00:00

Authorities have identified 63-year-old Anthony Quinn Warner from Antioch, Tennessee, as the Nashville bomber.

## 'Trolls' digital release was a first. Inside the decision that's still rattling the movie industry to its core
 - [https://www.cnn.com/videos/business/2020/12/17/universal-donna-langley-trolls-risk-takers-orig.cnn-business](https://www.cnn.com/videos/business/2020/12/17/universal-donna-langley-trolls-risk-takers-orig.cnn-business)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 05:32:13+00:00

When the Covid-19 pandemic began, Universal Pictures' Donna Langley wasted no time in delaying some movie releases and sending others straight to digital. Here's how that decision has changed the industry.

## Uganda's Bobi Wine says his bodyguard was 'deliberately' run over and killed
 - [https://www.cnn.com/2020/12/27/africa/uganda-bobi-wine-bodyguard-intl-hnk/index.html](https://www.cnn.com/2020/12/27/africa/uganda-bobi-wine-bodyguard-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 04:32:01+00:00

Ugandan presidential opposition candidate Bobi Wine said one of his bodyguards was run over and killed Sunday by a military police truck, while taking a journalist to the hospital.

## Derided in the West, spam is so beloved in Asia that one company has invented meat-free version
 - [https://www.cnn.com/2020/12/26/asia/spam-asia-cuisine-omnifoods-dst-intl-hnk/index.html](https://www.cnn.com/2020/12/26/asia/spam-asia-cuisine-omnifoods-dst-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 03:49:58+00:00

In a brightly lit restaurant in downtown Hong Kong, the meaty smell of fried spam fills the air.

## Seven killed in knife attack in northeast China
 - [https://www.cnn.com/2020/12/27/asia/china-liaoning-stabbing-intl-hnk/index.html](https://www.cnn.com/2020/12/27/asia/china-liaoning-stabbing-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 03:16:49+00:00

At least seven people were killed Sunday morning by a knife-wielding attacker in northeast China, according to state media.

## GOP lawmaker on what was happening behind the scenes after Trump delayed bill
 - [https://www.cnn.com/videos/politics/2020/12/28/trump-signs-coronavirus-relief-bill-reed-gottheimer-reaction-nr-vpx.cnn](https://www.cnn.com/videos/politics/2020/12/28/trump-signs-coronavirus-relief-bill-reed-gottheimer-reaction-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 02:11:19+00:00

CNN's Dana Bash talks to Rep. Tom Reed (R-NY) and Rep. Josh Gottheimer (D-NJ), co-chairs of the bipartisan Problem Solvers Caucus, about President Donald Trump signing the coronavirus relief bill after days of delay.

## Japan will ban entry to foreign nationals after Covid-19 variant detected in country
 - [https://www.cnn.com/2020/12/26/asia/japan-ban-foreign-nationals-intl/index.html](https://www.cnn.com/2020/12/26/asia/japan-ban-foreign-nationals-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 02:00:21+00:00

Japan will ban foreign nationals from entering the country from Monday through the end of January after several cases of the new Covid-19 variant were recorded in the country, the Japanese foreign ministry said in a statement on Saturday.

## Group of Alabama protesters places fake body bags on courthouse lawn
 - [https://www.cnn.com/2020/12/27/us/protesters-fake-slave-body-bags-alabama-confederate-trnd/index.html](https://www.cnn.com/2020/12/27/us/protesters-fake-slave-body-bags-alabama-confederate-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 01:43:09+00:00

For months, a group of protesters in Alabama has been fighting for the removal of a  Confederate flag and a Confederate monument that sit in front of the Marshall County Courthouse in Albertville.

## 'Shouldn't be big news': Bash on Trump signing Covid bill
 - [https://www.cnn.com/videos/politics/2020/12/27/trump-signs-coronavirus-relief-bill-vpx.cnn](https://www.cnn.com/videos/politics/2020/12/27/trump-signs-coronavirus-relief-bill-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 01:18:56+00:00

After letting critical benefits lapse for millions of jobless Americans and poising the government for a partial shutdown, President Donald Trump signed the $2.3 trillion dollar coronavirus relief and government funding bill passed by Congress.

## A photographic history of men in love
 - [https://www.cnn.com/style/article/loving-photographs-nini-treadwell/index.html](https://www.cnn.com/style/article/loving-photographs-nini-treadwell/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 01:04:21+00:00

When Hugh Nini and Neal Treadwell came across an old photograph at an antique store in Dallas, Texas, they saw something of themselves reflected in the image.

## Here's what's missing from Biden's Covid-19 plan
 - [https://www.cnn.com/2020/12/27/opinions/joe-biden-covid-19-team-carrillo/index.html](https://www.cnn.com/2020/12/27/opinions/joe-biden-covid-19-team-carrillo/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-12-28 00:59:09+00:00

As we head into the next chapter of an ongoing pandemic — one in which a vaccine will hopefully let us see a light at the end of the tunnel — we must be careful not to ease up on the precautionary measures that will keep us safe while we wait for immunity.

