# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## The KFC Console Ripped Off our Idea!! - WAN Show December 25, 2020
 - [https://www.youtube.com/watch?v=HV29d0Qdjfo](https://www.youtube.com/watch?v=HV29d0Qdjfo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-12-25 00:00:00+00:00

Save 10% at Ridge Wallet with offer code LINUS at https://www.ridge.com/Linus

Honey automatically applies the best coupon codes to save you money at 
different online checkouts, try it now at https://www.joinhoney.com/linus

Sign up for Private Internet Access VPN at https://lmg.gg/piawan

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/The-KFC-Console-Ripped-Off-our-Idea-----WAN-Show-December-25--2020-eoa8gp

Check out Carpool Critics, our new movie podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Timestamps (Courtesy of Blake Rodriguez)
00:00 - Show starts
01:40 - Topic introduction
02:19 - Intro rolls
03:20 - Linus talks about twitch personalities
05:30 - Linus talks about luke's chin over lower third
06:20 - KFConsole 
11:30 - Luke's pizza heating computer video
17:30 - Cat bed PC
19:00 - Simpsons politics
19:30 - "Why no WAN show VODs on floatplane?"
19:50 - Back to the KFConsole
21:30 - Linus 3D printed a stencil for his badminton racket
30:40 - Sponsors (PIA/Ridgewallet/Honey)
33:30 - Tesla/Elon announces full sell driving subscription
41:30 - General car topics (insurance, self driving, car ownership, defensive driving)
49:10 - US ISPs can no longer charge rental feese for equipment customers already own
50:30 - Intel is rumored to be taking back the gaming crown 
51:40 - LTT store boxing day promotion ($5 off storewide)
52:00 - Luke formally introduces his bird Taquito
53:50 - Luke leaves and linus does superchats for the rest of stream

## Our Craziest PC Yet – Pyramid PC Pt. 3
 - [https://www.youtube.com/watch?v=IkELZbTxsHg](https://www.youtube.com/watch?v=IkELZbTxsHg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-12-24 00:00:00+00:00

Get the best prices and best selection at Micro Center: https://rebrand.ly/2q82o
NetGear Nighthawk Pro Gaming XR1000 AX5400 WiFi 6 Gaming Router: https://rebrand.ly/9hnel

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire

Nearly a year in the making... we finally give you the Pyramid PC. But it has a couple quirks.

Pt. 1: https://youtu.be/TCMKqA3lCJg
Pt. 2: https://youtu.be/rFofYc702Mg

All lasering was done with the Trotec Speedy 400, check it out at: https://geni.us/trotec

Buy AMD Threadripper 3990X
On Amazon (PAID LINK): https://geni.us/e2jOF
On Best Buy (PAID LINK): https://geni.us/SmJbE
On Newegg (PAID LINK): https://geni.us/7GQP

Buy ASUS ROG Zenith II Extreme Alpha TRX40
On Amazon (PAID LINK): https://geni.us/JXFI
On B&H (PAID LINK): https://geni.us/oAMGwW
On Newegg (PAID LINK): https://geni.us/qcqQF

Buy G.SKILL Trident Z Neo Series 256GB RAM Kit
On Newegg (PAID LINK): https://geni.us/Tq4hzB

Buy Nvidia Geforce RTX 3090
On Amazon (PAID LINK): https://geni.us/bN4EWM1
On B&H (PAID LINK): https://geni.us/jvBUui
On Newegg (PAID LINK): https://geni.us/NUJTBn

Buy SilverStone DA1650 PSU
On Amazon (PAID LINK): https://geni.us/VZ939qo
On Newegg (PAID LINK): https://geni.us/1WkXH

Buy SAMSUNG 970 EVO Plus NVMe SSD 2TB
On Amazon (PAID LINK): https://geni.us/O1q5Q
On B&H (PAID LINK): https://geni.us/kkLA
On Newegg (PAID LINK): https://geni.us/QTDIF4

Buy Astera Helios Tube Lights
On B&H (PAID LINK): https://geni.us/Hyc4CS

Buy Noctua NF-A12x15 Fans
On Amazon (PAID LINK): https://geni.us/qHso
On Newegg (PAID LINK): https://geni.us/fcYgEyZ

Buy Noctua NH-U14S CPU Cooler
On Amazon (PAID LINK): https://geni.us/9REN4YA
On B&H (PAID LINK): https://geni.us/vo9J
On Newegg (PAID LINK): https://geni.us/U9JQ

Buy Samsung Odyssey CRG9 Monitor
On Amazon (PAID LINK): https://geni.us/LZyU
On B&H (PAID LINK): https://geni.us/iA9X
On Best Buy (PAID LINK): https://geni.us/AAdatc9

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1285070-our-craziest-pc-yet-%E2%80%93-pyramid-pc-pt-3/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Official Game Store: https://www.nexus.gg/ltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

