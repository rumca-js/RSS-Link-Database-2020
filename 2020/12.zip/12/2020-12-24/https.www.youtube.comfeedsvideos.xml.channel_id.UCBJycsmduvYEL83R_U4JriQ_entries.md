# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Giving Away 24 PS5s and XBox Series X!
 - [https://www.youtube.com/watch?v=Lt-fah4spJY](https://www.youtube.com/watch?v=Lt-fah4spJY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-12-25 00:00:00+00:00

Let's be real this is probably your best chance at a PS5 or Xbox Series X right now. Get in on it!
Follow: http://twitter.com/MKBHD
Follow: http://twitter.com/dbrand

Winners: http://dbrand.com/winners

Check out the Matte Black PS5 Faceplates: https://dbrand.com/PS5

The music: https://t.co/Ra6N0EPGJ9?amp=1

