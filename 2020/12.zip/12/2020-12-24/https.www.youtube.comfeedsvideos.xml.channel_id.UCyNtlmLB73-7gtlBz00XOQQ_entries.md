# Source:FoldingIdeas, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyNtlmLB73-7gtlBz00XOQQ, language:en-US

## Let's Argue About Christmas Movies (ft. Movies w/ Mikey)
 - [https://www.youtube.com/watch?v=uU5ZlOAvzAo](https://www.youtube.com/watch?v=uU5ZlOAvzAo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyNtlmLB73-7gtlBz00XOQQ
 - date published: 2020-12-24 20:31:22+00:00

Clickbait Title: Die Hard Isn't A Christmas Movie

The Trial of Christmas Movies: https://youtu.be/68JSod6pIRM

Go watch Mikey's companion video for the other half of the Dan and Mikey Christmas Special. His is way better and he put so much work into it.

We had a proper blizzard a couple days ago, so I just had to dig my car out from under over six inches of snow. And that's not like "oh, we got six inches" but it's kinda spread all around, this was six inches at the shallowest. It actually snapped my car's radio antenna. Anyway my arms feel like noodles from all the digging so I'm just going to wish you all happy New Year.

Written and performed by Dan Olson

Crowdfunding: https://www.patreon.com/foldablehuman
Twitter: https://twitter.com/FoldableHuman

