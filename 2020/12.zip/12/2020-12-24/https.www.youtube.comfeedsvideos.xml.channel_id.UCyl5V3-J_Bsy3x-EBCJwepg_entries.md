# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## The Babylon Bee Christmas Special 2020
 - [https://www.youtube.com/watch?v=6tWCe4g08XE](https://www.youtube.com/watch?v=6tWCe4g08XE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-12-25 00:00:00+00:00

Today on The Babylon Bee Podcast, Kyle and Ethan celebrate Christmas at The Babylon Bee Studio with returning guests Kira Davis, Kellen Erskine, and Greg Koukl. They debate what qualifies as a Christmas movie, wonder how great it would be to have a VeggieTales/Hallmark Movie Universe crossover, and try to rank International Ninja Day and Taylor Swift’s birthday among other venerated December holidays. Merry Christmas!

Watch The Babylon Bee animation on our animation playlist: https://bit.ly/BeeAnimation  

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Submit Your Own Headlines: https://babylonbee.com/plans

The Official The Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

## What Would C.S. Lewis Say About COVID?
 - [https://www.youtube.com/watch?v=57L-RsLI0CY](https://www.youtube.com/watch?v=57L-RsLI0CY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-12-25 00:00:00+00:00

Kyle and Ethan from the Babylon Bee talk to C.S. Lewis expert Justin Dyer about how Lewis might respond to current events if he were still alive. Justin Dyer has some theories about what Lewis would have said about COVID based on lines from some of his essays, including a line that Clint Eastwood may have stolen for one of his movies.

Subscribe to the Babylon Bee so you don’t miss a thing!

Hit the bell button to get your daily dose of fake news that you can trust

## Is Beauty In the Eye Of The Beholder? Here’s What CS Lewis Thought
 - [https://www.youtube.com/watch?v=wjRUYr7_6Bs](https://www.youtube.com/watch?v=wjRUYr7_6Bs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-12-24 00:00:00+00:00

The Babylon Bee Interview show brought in Justin Dyer to talk about his experiences studying C.S. Lewis. Kyle and Ethan find out how an argument about a waterfall led Lewis to write his famous book about objective truth, beauty, and art.

Subscribe to the Babylon Bee today to show your love and support!
Hit the bell to get your daily dose of fake news that you can trust.

