# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## BEST GAMES OF 2020
 - [https://www.youtube.com/watch?v=qYtLcN7J1Mw](https://www.youtube.com/watch?v=qYtLcN7J1Mw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-12-25 00:00:00+00:00

2020 was a wild year for games. We've added up your votes and we're announcing the best games of 2020. Despite all of the ups and downs, it was a good one.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 10 Games That SUCKED in 2020
 - [https://www.youtube.com/watch?v=VfGC2VTYPFQ](https://www.youtube.com/watch?v=VfGC2VTYPFQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-12-24 00:00:00+00:00

2020 was filled with great games, but there were some stinkers too. From boring stories to micro-transactions, to broken console version, we’ve got a bunch of disappointments here.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

