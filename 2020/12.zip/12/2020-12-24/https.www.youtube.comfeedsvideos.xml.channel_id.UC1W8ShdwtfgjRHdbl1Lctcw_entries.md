# Source:NASS, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw, language:en-US

## New York 1930s in Color! [60fps,Remastered] w/sound design added
 - [https://www.youtube.com/watch?v=jsoEjroEC0M](https://www.youtube.com/watch?v=jsoEjroEC0M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw
 - date published: 2020-12-25 00:00:00+00:00

I colorized, restored and created a sound design for this video of New York 1930s, letting you see the Big Apple, Times Square, Central Park, the Brooklyn Bridge–they’re all on display,  Manhattan was full of all those buildings, but New York city was more than that. Five borough constituted the city : Manhattan, Brooklyn, Queens, the Bronx and Staten Island. Each borough was different, with different cultures. during the 1930’s, the most known buildings appeared : the Chrysler Building and the Empire State Building.
1:00 - the Frick Museum on 5th ave and 71st.
1:34 - Sherman statue at Grand Army Plaza, 5th ave and 59th st.
1:59 - Heading south on Broadway, facing east, approaching Times Square
2:32 - Driving south on Park Ave at about 39th street but looking north at Grand Central station, years before the Pan Am building was built. (Thx Ross Rothschild)


Video Restoration Process:
✔ FPS boosted to 60 frames per second 
✔ Image resolution boosted up to HD 
✔ Improved video sharpness and brightness 
✔ Colorized only for the ambiance
✔added sound only for the ambiance
✔restoration:(stabilisation,denoise,deblur) 

Please, be aware that colorization colors are not real and fake, colorization was made only for the ambiance and do not represent real historical data.

- - - - - - - - - - - - - - - - - - - -
For any Copyright issues, please reach out to us first before filing a claim with YouTube. Send us a message or email detailing your concerns and we'll make sure the matter is resolved immediately. All contact details in our channel's "About" page! Please consider "fair use" before filing a claim. Thank You!

