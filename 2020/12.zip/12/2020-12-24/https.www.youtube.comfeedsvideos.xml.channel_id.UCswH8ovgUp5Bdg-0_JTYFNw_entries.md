# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Profit in The Pandemic - how Christmas adverts harness our emotions
 - [https://www.youtube.com/watch?v=9cvIpbQ2CkU](https://www.youtube.com/watch?v=9cvIpbQ2CkU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-12-24 00:00:00+00:00

The 2020 Christmas Coca-Cola UK commercial features a CGI whale – possibly due to all the plastic pollution that Coke cause impacting the number of real ones they could’ve used. Analysis of this, plus the McDonalds and John Lewis / Waitrose commercials 

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

