# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga Paula does XM: DRAX - Tears Of Christmas (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=2kowaTB9bkI](https://www.youtube.com/watch?v=2kowaTB9bkI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-12-24 00:00:00+00:00

"Tears Of Christmas" (1999) by DRAX/Maniacs Of Noise^Vibrants (Thomas Mogensen). C64 Art "Sad Old Santa" (2020) by Honcho/Atlantis^Public Enemies, 3rd at FORNDATA x-MAS 2o2o C64 Graphics Competition. Christopherjam palette used for more saturated colors.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Normal mixing with 38138 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click disabled
- Module reports 24 channels
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.

## Amiga Paula does XM: Revisq - Nahkolorism (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=83Ilb59syvE](https://www.youtube.com/watch?v=83Ilb59syvE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-12-24 00:00:00+00:00

"Nahkolorism" by Revisq (Patryk Gegniewicz). Art "Cityscape" (with mirror effect) (2017) by Jok/Dreamweb, 1st at AmiParty XXI Graphics Competition.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Normal mixing with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- Module reports 10 channels
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.

## Amiga music: Hoffman - Hot Dots (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=0cxD2PA_apc](https://www.youtube.com/watch?v=0cxD2PA_apc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-12-24 00:00:00+00:00

"Hot Dots" (2012) by Hoffman (Ian Ford). Art "Dragon Sun" (1993) by Cougar/Sanity, 1st at The Party 1993 Graphics Competition. Headphones recommended.

Made using Real A1200 Rev. 1D.4 audio.

Visit my channel for more Amiga music.

## SID music: Flex - Walking in the Air (SIDFX 8580 dual mono bx_🎧)
 - [https://www.youtube.com/watch?v=6apK_MV3Obo](https://www.youtube.com/watch?v=6apK_MV3Obo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-12-24 00:00:00+00:00

"Walking in the Air" (2020) C64 cover by Flex (Antti Hannula), original by Howard Blake (1982). Also thrown in are 2 entries from the 2020 C64 Short Music and SFX Loop Competition, details below. Art is using Christopherjam palette for more saturated colors. Headphones recommended as always.

Jumplist:
00:00 Stinsen - Untz (2020), 14th at Short Music and SFX Loop Competition. Art: Joe - Androgena (2009), 5th at LCP 2009 C64 Graphics Competition

00:35 Flex - Walking in the Air (2020), from Hyperborea (2020) demo. Art: by ibux, also from Hyperborea demo

05:18 Jammer - Garry's Glittering Saliva (2020), 6th at Short Music and SFX Loop Competition. Art: Yazoo - Rabbytes Can Dance (2009), 2nd at miniMO 2009 Mixed Competition

Made using real C64 audio in SIDFX dual mono config (identical audio data for both chips):

Left channel: CSG 6582A 2792 25/Philippines NM235N18 1200T
Right channel: CSG 8580R5 0590 25/Hong Kong HH032232 HC-30

Project SIDFX:
http://www.sidfx.dk/

