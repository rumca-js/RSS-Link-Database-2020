# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Caroline Polachek - three songs in The Current studio (2019)
 - [https://www.youtube.com/watch?v=Ezy-c3woyYU](https://www.youtube.com/watch?v=Ezy-c3woyYU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-12-24 00:00:00+00:00

One year ago today — on December 23, 2019 — Caroline Polachek visited our studio to perform solo piano versions of three of her songs. And it was awesome! Here are those three performances.

SONGS PERFORMED
0:00 "Door"
3:28 "So Hot You're Hurting My Feelings"
6:20 "Ocean of Tears"

PERSONNEL
Caroline Polachek – piano and vocals

CREDITS
Video & Photo: Mary Mathis
Audio: Michael DeMark
Production: Derrick Stevens

FIND MORE:
2009 studio session with Chairlift: https://www.thecurrent.org/feature/2009/04/21/chairlift
2019 studio session: https://www.thecurrent.org/feature/2019/12/23/caroline-polachek-performs-in-the-current-studio

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#carolinepolachek

## JD McPherson - three from 'Socks' at The Current (2018)
 - [https://www.youtube.com/watch?v=3XEsZbjutbk](https://www.youtube.com/watch?v=3XEsZbjutbk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-12-24 00:00:00+00:00

In 2018, JD McPherson and his band released "Socks," an album of instant holiday classics. We were lucky enough in December of that year to welcome JD McPherson and the gang into our studio to perform songs off that album. Enjoy these performances — and look for JD to crack up in anticipation of bandmate Doug Corcoran's baritone whisper of the words, "knee high" after JD sings out, "Socks." 

SONGS PERFORMED
0:00 "All The Gifts I Need"
2:40 "Bad Kid"
6:01 "Socks"

PERSONNEL
JD McPherson – vocals, guitar
Doug Corcoran – saxophone, guitar, xylophone, backing vocals
Ray Jacildo – piano, organ, backing vocals
Jason Smay – drums 
Jimmy Sutton – bass, backing vocals

CREDITS
Video & Photo: Nate Ryan
Audio: Michael DeMark
Production: Anna Weggel

FIND MORE:
2012 July studio session: https://www.thecurrent.org/feature/2012/07/06/jd-mcpherson-performs-in-the-current-studios
2012 November studio session:
https://www.thecurrent.org/feature/2012/11/29/jd-mcpherson-live
2014 studio session: https://www.thecurrent.org/feature/2014/09/14/jd-mcpherson-performs-in-the-current-studio
2015 studio session:
https://www.thecurrent.org/feature/2015/02/14/jd-mcpherson-performs-in-the-current-studio
2015 Rock the Garden set:
https://www.thecurrent.org/feature/2015/07/01/jd-mcpherson-live-at-rock-the-garden-2015
2018 studio session:
https://www.thecurrent.org/feature/2018/12/04/jd-mcpherson-and-band-pull-up-their-socks-in-the-current-studio
2021 interview with Bill DeVille:
https://www.thecurrent.org/feature/2021/12/12/jd-mcpherson-talks-joining-robert-plant-and-alison-krauss-band-and-rebuilding-his-own-lineup

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#jdmcpherson

