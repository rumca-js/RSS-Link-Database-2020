# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## Why You Still Can't Vote Online
 - [https://www.youtube.com/watch?v=-bUWVgYz114](https://www.youtube.com/watch?v=-bUWVgYz114)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2020-12-25 00:00:00+00:00

Would you ever vote online even if you knew you couldn't verify your ballot's integrity? Securing online elections is way harder than you might think.
Merch: https://www.youtube.com/c/TheHatedOne/store
Join my channel and become a member to enjoy perks https://www.youtube.com/channel/UCjr2bPAyPV7t35MvcgT3W8Q/join
Support me through Patreon: https://www.patreon.com/thehatedone 

- or donate anonymously:

Monero: 84DYxU8rPzQ88SxQqBF6VBNfPU9c5sjDXfTC1wXkgzWJfVMQ9zjAULL6rd11ASRGpxD1w6jQrMtqAGkkqiid5ef7QDroTPp

Bitcoin: 1HkDxXAVDFhBHSyRjam5WW5uoY88sxn5qz

Sources:
Research on and critique of security models of online voting systems
https://www.darkreading.com/edge/theedge/is-voting-by-mobile-app-a-better-security-option-or-just-a-bad-idea/b/d-id/1336152
https://cacm.acm.org/magazines/2019/9/238963-online-voting/fulltext
https://verifiedvoting.org/publication/if-i-can-shop-and-bank-online-why-cant-i-vote-online/
https://www.fastcompany.com/90249210/online-voting-is-a-security-nightmare-say-experts
https://www.theguardian.com/technology/2015/mar/30/why-electronic-voting-is-not-secure
https://www.csoonline.com/article/3269297/online-voting-is-impossible-to-secure-so-why-are-some-governments-using-it.html
https://www.washingtonpost.com/politics/2020/10/14/cybersecurity-202-ruling-against-expanding-online-voting-is-win-cybersecurity-advocates/
https://observer.com/2020/06/election-security-why-cant-people-vote-online/
NIST report on online election security in the US https://s.wsj.net/public/resources/documents/Final_%20Risk_Management_for_Electronic-Ballot_05082020.pdf?mod=article_inline 
https://www.darkreading.com/edge/theedge/is-voting-by-mobile-app-a-better-security-option-or-just-a-bad-idea/b/d-id/1336152

Security flaws found in voting apps
https://www.cyberscoop.com/online-voting-election-security-voatz-app-risky-business/
https://www.securitymagazine.com/articles/92584-cybersecurity-concerns-with-online-voting-for-2020-presidential-election
https://internetpolicy.mit.edu/wp-content/uploads/2020/06/OmniBallot.pdf
https://www.politico.com/news/2020/05/01/coronavirus-online-voting-229690
https://www.wired.com/story/voatz-voting-app-security-flaws/
https://arstechnica.com/tech-policy/2020/09/online-voting-vendor-voatz-urges-supreme-court-to-limit-security-research/ 
https://thefulcrum.us/voting/online-voting-security-risks
https://www.npr.org/2020/04/28/844581667/states-expand-internet-voting-experiments-amid-pandemic-raising-security-fears

Estonia
https://www.csoonline.com/article/3269297/online-voting-is-impossible-to-secure-so-why-are-some-governments-using-it.html
https://www.comparitech.com/blog/information-security/cryptography-secure-electronic-voting-systems/
https://www.govtech.com/blogs/lohrmann-on-cybersecurity/could-estonia-be-the-model-for-secure-online-voting.html
https://time.com/5541876/estonia-elections-electronic-voting/
https://venturebeat.com/2020/06/11/what-estonia-could-teach-us-about-internet-voting-in-a-post-pandemic-world/
https://e-estonia.com/estonias-i-voting-more-popular-more-secure/

Blockchain
https://blogs.lse.ac.uk/usappblog/2020/09/25/long-read-how-blockchain-can-make-electronic-voting-more-secure/
https://people.csail.mit.edu/rivest/pubs/PSNR20.pdf

NSA router implants and supply chain attacks
https://www.wired.com/2013/09/nsa-router-hacking/
 https://arstechnica.com/tech-policy/2014/05/photos-of-an-nsa-upgrade-factory-show-cisco-router-getting-implant/ 
https://techcrunch.com/2014/05/18/the-nsa-cisco-and-the-issue-of-interdiction/
https://theintercept.com/2019/01/24/computer-supply-chain-attacks/ 

Estonian ID cards vulnerable https://arstechnica.com/information-technology/2017/10/crypto-failure-cripples-millions-of-high-security-keys-750k-estonian-ids/ 


Follow me:
https://twitter.com/The_HatedOne_
https://www.bitchute.com/TheHatedOne/
https://www.reddit.com/r/thehatedone/
https://www.minds.com/The_HatedOne

The footage and images featured in the video were for critical analysis, commentary and parody, which are protected under the Fair Use laws of the United States Copyright act of 1976.

