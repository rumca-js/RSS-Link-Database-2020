# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Alex Berneson Details How Coronavirus Deaths Are Counted
 - [https://www.youtube.com/watch?v=goZQ6iOIFYo](https://www.youtube.com/watch?v=goZQ6iOIFYo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2020-12-24 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1582 with Alex Berenson. https://open.spotify.com/episode/3hjLLalZM7kXtZPxI5057q?si=GFJXS4zPTR68KRKeyLVm7Q

## Alex Berneson Feels COVID Measures Have Been an Overreaction
 - [https://www.youtube.com/watch?v=D-59f2EBCUA](https://www.youtube.com/watch?v=D-59f2EBCUA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2020-12-24 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1582 with Alex Berenson. https://open.spotify.com/episode/3hjLLalZM7kXtZPxI5057q?si=GFJXS4zPTR68KRKeyLVm7Q

## The COVID Relief Bill, Questioning Origins of Coronavirus
 - [https://www.youtube.com/watch?v=Cz6AO391KZM](https://www.youtube.com/watch?v=Cz6AO391KZM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2020-12-24 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1582 with Alex Berenson. https://open.spotify.com/episode/3hjLLalZM7kXtZPxI5057q?si=GFJXS4zPTR68KRKeyLVm7Q

## The Effect LA Shutdowns Have Had on the Restaurant Industry
 - [https://www.youtube.com/watch?v=9DP_KtzRT0k](https://www.youtube.com/watch?v=9DP_KtzRT0k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2020-12-24 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1583 with John Terzian & Craig Susser. https://open.spotify.com/episode/2bwd6wIUrqShlFrHEpwsCJ?si=e24nUxURTb2GwOAv6iXQBQ

## Why Restaurants Keep Getting Shutdown
 - [https://www.youtube.com/watch?v=D6bIF2af1e4](https://www.youtube.com/watch?v=D6bIF2af1e4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2020-12-24 00:00:00+00:00

This clip is taken from the Joe Rogan Experience #1583 with John Terzian & Craig Susser. https://open.spotify.com/episode/2bwd6wIUrqShlFrHEpwsCJ?si=e24nUxURTb2GwOAv6iXQBQ

