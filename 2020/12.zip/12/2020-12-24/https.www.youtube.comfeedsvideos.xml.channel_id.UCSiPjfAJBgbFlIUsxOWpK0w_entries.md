# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Douce France // Charles Trenet // POMPLAMOOSE ft. John Tegmeyer
 - [https://www.youtube.com/watch?v=FbqLa7vNiEY](https://www.youtube.com/watch?v=FbqLa7vNiEY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2020-12-24 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 Et voilà Douce France de Charles Trenet! Here's an old French tune for you - the first track on our album "Impossible à Prononcer" - coming Summer 2021!

Our album ‘Invisible People’ is now available EVERYWHERE! http://pomplamoose.com

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

A cover of Charles Trenet's "Douce France" by Pomplamoose.

MUSICIAN CREDITS
Clarinet: John Tegmeyer
Accordion: Jack Conte
Keys: Ross Garren
Vocals: Nataly Dawn
Drums: Ben Rose
Guitar/Mandolin: John Schroeder
Upright Bass: Eliana Athayde
Acoustic/Resonator Guitar, Trumpet: Erik Miron
Background Vocals: Sarah Dugas

AUDIO CREDITS
Engineer: Tim Sonnefeld
Assistant Engineer: Branko Presley
Mixing/Mastering: Caleb Parker
Producer: John Schroeder

VIDEO CREDITS
Director: George Sloan
DP: Ricky Chavez
Camera Operators: Merlin Showalter, Sammy Rothman, Dijon Herron, Brad Davis
Art Design: Brad Davis, Susannah Honey
Editor: Athena Wheaton

Recorded at The Village in Los Angeles.

LYRICS

Il revient à ma mémoire
Des souvenirs familiers
Je revois ma blouse noire
Lorsque j'étais écolier
Sur le chemin de l'école
Je chantais à pleine voix
Des romances sans paroles
Vieilles chansons d'autrefois

Douce France
Cher pays de mon enfance
Bercée de tendre insouciance
Je t'ai gardée dans mon cœur
Mon village au clocher aux maisons sages
Où les enfants de mon âge
Ont partagé mon bonheur
Oui je t'aime
Et je te donne ce poème
Oui je t'aime
Dans la joie ou la douleur
Douce France
Cher pays de mon enfance
Bercée de tendre insouciance
Je t'ai gardée dans mon cœur

Oui je t'aime
Et je te donne ce poème
Oui je t'aime
Dans la joie ou la douleur
Douce France
Cher pays de mon enfance
Bercée de tendre insouciance
Je t'ai gardée dans mon cœur
Je t'ai gardée dans mon cœur

