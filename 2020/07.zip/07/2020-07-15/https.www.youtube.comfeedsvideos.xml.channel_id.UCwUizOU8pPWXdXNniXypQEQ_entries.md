# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## A Message to All Online Haters
 - [https://www.youtube.com/watch?v=lJ-RVH-V6pc](https://www.youtube.com/watch?v=lJ-RVH-V6pc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-07-16 00:00:00+00:00

Check out BLUblox, my favorite evidenced based blue light glasses: https://www.blublox.com/jp
To get 15% off, use the discount code: JP

The Crazy Cat shirt I was wearing at end - https://amzn.to/2Wt1PcR

Tupac Chopra Shirt - https://awakenwithjp.com/shop

A message to all online haters. Your keyboard combat and social justice warrior mentality has destroyed my life. Haters, I’ve heard you and you’re right.

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

As an Amazon Associate, I earn a small commission from qualifying purchases. Some of the links are affiliate links and if you decide to buy products through them I earn a tiny commission. It costs you nothing but helps support the channel and future videos!

