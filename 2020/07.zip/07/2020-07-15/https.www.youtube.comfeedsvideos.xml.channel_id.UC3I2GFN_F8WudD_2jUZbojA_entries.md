# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## MAITA (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=Ne3rMttHryM](https://www.youtube.com/watch?v=Ne3rMttHryM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-07-16 00:00:00+00:00

Maria Maita-Keppeler, of Portland band MAITA, shares an exclusive set of songs and joins Morgan live on KEXP on Thursday, July 16, at 3pm PT.

