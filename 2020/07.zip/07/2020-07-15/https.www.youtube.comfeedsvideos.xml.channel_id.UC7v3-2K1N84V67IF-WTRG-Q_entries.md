# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## The Old Guard - Movie Review
 - [https://www.youtube.com/watch?v=b57My0jC36g](https://www.youtube.com/watch?v=b57My0jC36g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-07-16 00:00:00+00:00

A group of immortals welcome a new immortal, and get hunted by non immortals. Here's my review for THE OLD GUARD

#TheOldGuard

