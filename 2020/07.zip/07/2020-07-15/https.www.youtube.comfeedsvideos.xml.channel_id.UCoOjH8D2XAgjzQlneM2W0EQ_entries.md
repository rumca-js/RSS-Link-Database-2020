# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## Floating Cities: The Future of Civilization
 - [https://www.youtube.com/watch?v=EotHcLHsAXs](https://www.youtube.com/watch?v=EotHcLHsAXs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2020-07-15 00:00:00+00:00

📚 The first 100 people to go to https://bit.ly/jt-blinkist are going to get unlimited access for 1 week to try it out. You'll also get 25% off if you want the full membership

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join 

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

Check out The Seasteading Institute: https://bit.ly/jt-sea 
Get the Seasteading book: https://amzn.to/3gSvmEO 

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
📸 Follow me on IG:@jaketran // http://bit.ly/jt-ig
👨👦👦 Join the Tran Mafia Family here: https://bit.ly/patreon-jt
💬 Join the community Discord: http://discord.gg/BmK8EnQ

Stuff I use & recommend:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
🏠 The real estate investing course I love & recommend: https://jake.yt/RE
🌐 Most flexible, affordable website hosting: https://jake.yt/bhd
🖥️ Website platform I use & love: https://jake.yt/kd
💽 Editing software I've used for 7+ years: https://jake.yt/ccd
📒 Online bookkeeping software I use& love: https://jake.yt/benchd 
🧾 Best affordable bookkeeping software: https://jake.yt/fbd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd
📚 Get 3 free audiobooks for life: https://amzn.to/2v58PSu
🎥 My video gear, setup, tech, books: https://jake.yt/stored

✉️ Email me: jake@jaketran.io

Subscribe to the backup channel on LBRY, use reward code "jake-cast" for free coin: https://bit.ly/LBRY-jt

📰 Sources & visuals: https://bit.ly/3iYqbFa

-----------------------
Let’s say you’re an idealist that was recently inspired by the ideas of universal basic income, free health care or completely opposite ideas like smaller limited government to let the free market do it’s thing. So you set out to put your plan to change the rules of the game. But you quickly run into inefficient politicians and bureaucrats - the classic problem of monopolies. 

We’ve had the agricultural revolution, the commercial and industrial revolutions, but why not a governance revolution? Enter the sea.

Seasteading or floating cities on the sea, where “aquatic citizens” live in modular pods that can detach and join other cities at any time would be in international waters.

Before you call this impossible, we already have cities and other giant structures on the sea. They’re called cruise ships. Japan’s many giant floating airports,the Netherlands, hundreds of amphibious homes, container ships. Shell’s floating natural gas facility that’s longer than the empire state building, nuclear submarines, nuclear aircraft carriers that can stay at sea for 15 to 20 years before refueling. This is the race for the Aquatic Age.

The basic idea behind seasteads starts with the platform. The floating platform can be built out of steel, concrete, or things like carbon fiber, all of which are already used in water-related projects. Once you have the platforms, you can build anything on top of it. Cruise ships are the perfect example of ocean cities. They have more amenities than the average town. 

What’s the difference between the Koreas? Simple - the rules, the laws, how they govern over their subjects. 

Hong Kong was ruled by the British until they eventually gave it back to China. China was so impressed with the success of Hong Kong that it designated Hong Kong as a special economic zone. Today, Hong Kong has the most expensive real estate in the world and has the second most billionaires in the world behind New York.

Shenzhen, another SEZ in China, has risen to the hardware capital of the world

Singapore doesn’t have many natural resources besides their harbor. They have universal health care yet the government makes more money than it spends. They follow typical English laws yet they dish out death sentences over zoom

Seasteading isn’t the answer to our most complex problems. The answer is more experiments in government. 

-----------------------

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2020 Jake Tran. All rights reserved.

DISCLAIMER: These videos are for entertainment purposes only. This is not meant to be financial advice. Please always do your due diligence and never stop learning.

AFFILIATE DISCLOSURE: Some of the links in this video description are affiliate links, meaning, at no additional cost to you, I may earn a commission if you click through and make a purchase and/or opt-in. I only promote products that I 100% believe in.

