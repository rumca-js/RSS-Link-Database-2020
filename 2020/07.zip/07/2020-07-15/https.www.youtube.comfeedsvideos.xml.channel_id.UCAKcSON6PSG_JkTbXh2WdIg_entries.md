# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Lianne La Havas - live virtual session for The Current
 - [https://www.youtube.com/watch?v=XI8guZzhbp8](https://www.youtube.com/watch?v=XI8guZzhbp8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-07-16 00:00:00+00:00

Lianne La Havas joins The Current's Sean McPherson for a Live Virtual Session. La Havas talks about and plays two songs from her 2020 self-titled release, and she also plays a selection from her 2015 release, 'Blood.'

SONGS PERFORMED:
02:50 "Courage"
12:36 "Bittersweet"
25:02 "Green & Gold"

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Interview outtake: Michael Stipe gets a phone call from his mother
 - [https://www.youtube.com/watch?v=dm-A3VVR6Gs](https://www.youtube.com/watch?v=dm-A3VVR6Gs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-07-15 00:00:00+00:00

When Jade was interviewing Aaron Dessner of the National and Michael Stipe of R.E.M. about their collaborative project with Big Red Machine, the interview was interrupted briefly when Stipe received a phone call from his mother. Here's that truly heartwarming moment.

You can find the complete interview here: https://youtu.be/d3r6Uf96eg8

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Phoenix - three songs at The Current in 2009
 - [https://www.youtube.com/watch?v=xguZFCD0fmY](https://www.youtube.com/watch?v=xguZFCD0fmY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-07-15 00:00:00+00:00

Bonne Fête Nationale ! July 14 is Bastille Day, the national French holiday, so in honor of that, we're featuring three songs recorded in our studio back in 2009 by Phoenix, a band from Versailles, France. Fronted by Thomas Mars, Phoenix were in town to support their hit album, "Wolfgang Amadeus Phoenix." The session in 2009 was actually the second time Phoenix had visited our studio; they first performed at The Current in April 2005, when the station wasn't even three months old.

SONGS PERFORMED
0:00 "Lisztomania"
2:01 "1901"
5:00 "Playground Love"

PERSONNEL
Thomas Mars – vocals 
Christian Mazzalai – guitar
Laurent Brancowitz - guitar
Deck d'Arcy – bass, keyboards, percussion (smartphone)

CREDITS
Video & Photo: Bo Hakala
Audio: Michael DeMark
Production: Derrick Stevens

FIND MORE:
2009 studio session: https://www.thecurrent.org/feature/2009/06/23/phoenix

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Sorry - Live Virtual Session
 - [https://www.youtube.com/watch?v=lGtBSWIWyMo](https://www.youtube.com/watch?v=lGtBSWIWyMo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-07-15 00:00:00+00:00

Asha Lorenz and Louis O’Bryen, the founding members of the British post-punk outfit Sorry, joined Mac Wilson for a virtual 3-song set and interview with The Current. 

Songs Performed:
2:30 "As The Sun Sets"
6:56 "Perfect"
14:34 "Ode To Boy"

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

