# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Blade Runner 2049 - The iPhone of Movie Sequels
 - [https://www.youtube.com/watch?v=aSXyPOvH_ws](https://www.youtube.com/watch?v=aSXyPOvH_ws)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-07-15 00:00:00+00:00

Since people have been asking me to review this film ever since I covered the 1982 original, I decided to oblige. Let's take a look at Blade Runner 2049.

