# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Are You in The Woke Cult?
 - [https://www.youtube.com/watch?v=GGKug2duCSs](https://www.youtube.com/watch?v=GGKug2duCSs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-07-16 00:00:00+00:00

Are you in a woke cult? Kyle and Ethan discuss with James Lindsay how “being woke” looks a lot like being in a cult in 2020.

FULL ▶️  https://youtu.be/5arM0Hk63O0

## Everybody Is A Secret Racist
 - [https://www.youtube.com/watch?v=ORXWEVNoRNo](https://www.youtube.com/watch?v=ORXWEVNoRNo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-07-16 00:00:00+00:00

James Lindsay joins Kyle and Ethan to discuss the differences between white and brown fragility and how everyone is apparently racist.

FULL ▶️  https://youtu.be/5arM0Hk63O0

## The Woke Cult: The James Lindsay Interview
 - [https://www.youtube.com/watch?v=5arM0Hk63O0](https://www.youtube.com/watch?v=5arM0Hk63O0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-07-15 00:00:00+00:00

Today on The Babylon Bee Podcast, Kyle and Ethan talk to James Lindsay about the cult of wokeness, its ideology and its tactics, and also about how the landscape of Christianity is kind of like Narnia to an atheist. 

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Gain Access to the Exclusive Content and Writing Forum: https://babylonbee.com/plans

The Official Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

