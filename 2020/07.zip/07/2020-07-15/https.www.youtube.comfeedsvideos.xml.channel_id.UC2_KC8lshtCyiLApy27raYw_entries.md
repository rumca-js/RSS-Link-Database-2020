# Source:KnowledgeHusk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw, language:en-US

## Super Mario Kart: Life Is Unfair You Wahoo
 - [https://www.youtube.com/watch?v=c7L27zoqmQs](https://www.youtube.com/watch?v=c7L27zoqmQs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw
 - date published: 2020-07-16 00:00:00+00:00

Ya know, sometimes YouTube videos don’t work out like they should. Sometimes you got a plan, and ya gonna do the things to do the plan, and do the plan to do the video, but then sometimes those things don’t do what they should. Sometimes. This time, nothing worked out, so here’s a video about Super Mario Kart.

Twitter: https://twitter.com/KnowledgeHubTy

Soundcloud: https://soundcloud.com/user-503704039

Patreon: https://www.patreon.com/theknowledgehub

Second Channel: https://www.youtube.com/channel/UC-KL04Ra6E1Du0pFawN4pWg

Spotify: https://open.spotify.com/artist/3STpelEilrthF8UxsQTaaw?si=52TH_ZKTQhaKhfnK1Jomfg

Additional footage credit
sriden
Al82: Retrogaming & Computing
Old Classic Retro Gaming
reznoire
hyrulesmasher

