# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Lessons, Mixing, and Mastering Services
 - [https://www.youtube.com/watch?v=kdca8rTk9G0](https://www.youtube.com/watch?v=kdca8rTk9G0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2020-07-15 00:00:00+00:00

https://rmr.media/education
https://rmr.media/audio-services
http://calendly.com/redmeansrecording
https://patreon.com/redmeansrecording
------------------------------------
Patreon: http://bit.ly/rmrpatreon
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe
T-Shirts: http://bit.ly/rmrshirts
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

