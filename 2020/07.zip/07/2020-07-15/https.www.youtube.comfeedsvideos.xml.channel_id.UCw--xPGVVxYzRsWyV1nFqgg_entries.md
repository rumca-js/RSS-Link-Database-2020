# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Kings of the Wyld: BEFORE YOU READ
 - [https://www.youtube.com/watch?v=wcprT_nabx4](https://www.youtube.com/watch?v=wcprT_nabx4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-07-16 00:00:00+00:00

Before you read Nicholas Eames Kings of the Wyld, here are some things you might like to know!
Check out Kings of the Wyld here: https://amzn.to/3j8Eozi
Podcast: https://afictionalconversation.podbean.com/
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## NEW Stormlight Novella⛈️ Good Reads Most Popular SFF🎉 Final Terry Pratchett📕 -FANTASY NEWS
 - [https://www.youtube.com/watch?v=nrgzc5C2lL4](https://www.youtube.com/watch?v=nrgzc5C2lL4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-07-15 00:00:00+00:00

Maybe my favorite Fantasy News every. Let’s just get into it! 

Podcast: https://afictionalconversation.podbean.com/
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

NEWS: 

Neil Gaiman Talks Audio Drama: https://ew.com/books/neil-gaiman-sandman-audible-adaptation-netflix-show/?utm_campaign=entertainmentweekly_entertainmentweekly&utm_content=manual&utm_medium=social&utm_source=twitter.com&utm_term=5f0dacf5a0395b0001fb0071

#MiddleEarth Show: https://www.indiewire.com/2020/07/will-poulter-lord-of-the-rings-tv-series-incredible-1234572992/

Dragon Republic Paperback: https://www.instagram.com/p/CCme4K-gp7w/?utm_source=ig_web_copy_link

Graphic Novel sales: https://www.publishersweekly.com/pw/by-topic/industry-news/comics/article/83842-2019-north-american-comics-sales-hit-record-1-21-billion.html

#StormlightArchive Update: https://www.reddit.com/r/Stormlight_Archive/comments/hquq36/stormlight_book_four_update_9_final_update/

Good reads most popular SFF: https://www.goodreads.com/blog/show/1875-the-100-most-popular-fantasy-books-on-goodreads

https://www.goodreads.com/blog/show/1874-the-100-most-popular-sci-fi-books-on-goodreads

Star Wars #BadBatch: https://twitter.com/DiscussingFilm/status/1282707471598063618?s=19

New Terry Pratchett Stories: https://www.theguardian.com/books/2020/jul/07/terry-prachett-the-time-travelling-caveman-published-september

Star Trek Lower Decks: https://www.youtube.com/watch?v=V3RkBKedKWw

Stormlight book 4 finished: https://twitter.com/brandsanderson/status/1282194268883316736?s=21

New Stormlight Book: https://www.kickstarter.com/projects/dragonsteel/the-way-of-kings-10th-anniversary-leatherbound-edition/posts/2893136?ref=android_update_share

Do Androids dream of electric sheep: https://twitter.com/SkinnerCreative/status/1283034101914767362

Rothfuss Livestreams: https://twitter.com/PatrickRothfuss/status/1282721300482580480?s=20

