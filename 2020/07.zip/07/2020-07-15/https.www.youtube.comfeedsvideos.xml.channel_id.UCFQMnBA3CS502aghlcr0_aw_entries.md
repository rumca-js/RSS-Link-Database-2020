# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## I Accidentally Uncovered a SECRET SERVICE Investigation! | Pat Mazza Fake Guru
 - [https://www.youtube.com/watch?v=DCM3dHi9Sjg](https://www.youtube.com/watch?v=DCM3dHi9Sjg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-07-15 00:00:00+00:00

The most epic scammer investigation of all time, Pat Mazza goes down!

We do a deep dive into Vermont's investigation into fake guru Patrick Mazza - https://dfr.vermont.gov/sites/finreg/files/regbul/dfr-order-docket-20-026-s-mazza-exparte.pdf
Patrick Mazza's website - https://www.doubleyourquota.com/sales-coaching
It's worth noting that part of Mazza's enterprise is shut down right now.
Additionally this is an ongoing investigation so new facts may come to light that reveal new narratives. Ultimately the information we have is incomplete and it'll be interesting to follow this story. 

#secretservice #coffeezilla #scammer

