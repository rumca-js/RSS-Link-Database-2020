# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Igor Herbut - wywiad MUZO.FM
 - [https://www.youtube.com/watch?v=ceZrR0rt8RM](https://www.youtube.com/watch?v=ceZrR0rt8RM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-07-15 00:00:00+00:00

Igor Herbut - wywiad w MUZO.FM. Artysta opowiada o swojej debiutanckiej solowej płycie - Chrust. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Igor Herbut: http://www.facebook.com/igor.ai.1
Instagram Igor Herbut: http://www.instagram.com/aigorek
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm 

#popolsku

