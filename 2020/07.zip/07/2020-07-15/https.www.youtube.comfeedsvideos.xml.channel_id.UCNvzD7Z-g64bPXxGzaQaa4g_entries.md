# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Cyberpunk 2077 vs Code SYN: COMPETITORS?
 - [https://www.youtube.com/watch?v=dUqXRpfhFrg](https://www.youtube.com/watch?v=dUqXRpfhFrg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-07-16 00:00:00+00:00

Cyberpunk 2077 has inspired similar-looking video game projects. Today's example: Code SYN from Tencent.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 7 Gamers Who Got Their REVENGE ON ONLINE CHEATERS
 - [https://www.youtube.com/watch?v=IS3GnkSA_dI](https://www.youtube.com/watch?v=IS3GnkSA_dI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-07-15 00:00:00+00:00

Some cheaters aren't safe from the very players they're scamming. Here are some great examples of cheaters getting caught.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

sources:

https://www.youtube.com/watch?v=eKfZmcvo_2g&feature=emb_title

------

https://www.reddit.com/r/CODWarzone/comments/fn2n64/i_had_two_blatant_cheaters_in_my_game_so_i/
+
https://www.reddit.com/r/CODWarzone/comments/fr37o1/killed_by_a_hacker_joined_his_party_got_revenge/

----------

https://kotaku.com/top-pubg-streamer-stops-playing-with-hackers-and-starts-1828009653

----------


https://www.dexerto.com/call-of-duty/cheater-gives-modern-warfare-devs-tips-to-prevent-hackers-and-aimbotters-1355111

-------

https://www.youtube.com/watch?v=Rs3YS0j0WwE

--------

https://www.reddit.com/r/GlobalOffensive/comments/43edee/how_i_got_3000_hackers_vac_banned/

---------

https://www.eteknix.com/gta-player-hires-cheater-save-another-cheater/

