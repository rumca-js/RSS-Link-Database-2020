# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## On the set of CSI
 - [https://www.youtube.com/watch?v=Cd4bQTEw5mU](https://www.youtube.com/watch?v=Cd4bQTEw5mU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2020-07-16 00:00:00+00:00

It's a thankless job.

