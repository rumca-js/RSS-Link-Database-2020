# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## Who is ColdFusion? - My Story
 - [https://www.youtube.com/watch?v=OaG92TG2skI](https://www.youtube.com/watch?v=OaG92TG2skI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2020-07-16 00:00:00+00:00

A little bit about me.

--- New Thinking Book written by Dagogo Altraide ---
This book was rated the 9th best technology history book by book authority.
In the book you’ll learn the stories of those who invented the things we use everyday and how it all fits together to form our modern world.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

--- ColdFusion Social Media ---
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusionTV

2 hour mix of my music: https://youtu.be/uZ_fkDj-bqQ

Illustrations by : https://www.instagram.com/luciana.v.i.e.i.r.a/

//Soundtrack//

gin$eng - you're high

Middle School - I Wish It Were (You)

Pacific Coliseum - Ocean City.

Childish Gambino - Summertime Magic (Zikomo Instrumental Remix)

Edward Sharpe and the Magnetic Zeros - Life Is Hard (Teen Daze Remix)

ØDYSSEE x Florent Garcia – Calm

Yasper - Move Together

Burn Water – Unreleased

Burn Water – Call to Earth

» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide

