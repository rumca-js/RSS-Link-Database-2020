# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Should Children Experiencing Gender Dysphoria Get Hormone Blockers?
 - [https://www.youtube.com/watch?v=s8YjbzZ7AzE](https://www.youtube.com/watch?v=s8YjbzZ7AzE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-16 00:00:00+00:00

Taken from JRE #1509 w/Abigail Shrier: https://youtu.be/Xagiz8s-h34

## The Dangers of Giving Hormones to Kids with Gender Dysphoria
 - [https://www.youtube.com/watch?v=SUPHqTkL5Nw](https://www.youtube.com/watch?v=SUPHqTkL5Nw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-16 00:00:00+00:00

Taken from JRE #1509 w/Abigail Shrier:
https://youtu.be/CtftWcgXjdg

## Why Abigail Shrier Took on the Transgender Craze Amongst Teenage Girls
 - [https://www.youtube.com/watch?v=6MYb0rBDYvs](https://www.youtube.com/watch?v=6MYb0rBDYvs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-16 00:00:00+00:00

Taken from JRE #1509 w/Abigail Shrier:
https://youtu.be/CtftWcgXjdg

## Libertarian Peter Schiff on How to Fix Troubled Communities
 - [https://www.youtube.com/watch?v=wTu3QGViNvA](https://www.youtube.com/watch?v=wTu3QGViNvA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-15 00:00:00+00:00

Taken from JRE #1508 w/Peter Schiff: https://youtu.be/OK2zgeJLVwU

## Peter Schiff Shares Election Outlook | Joe Rogan
 - [https://www.youtube.com/watch?v=utHmPgOdJBU](https://www.youtube.com/watch?v=utHmPgOdJBU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-15 00:00:00+00:00

Taken from JRE #1508 w/Peter Schiff:
https://youtu.be/OK2zgeJLVwU

## Peter Schiff on How We Got to Today’s Student Loan Crisis
 - [https://www.youtube.com/watch?v=9BvCzt5e5d8](https://www.youtube.com/watch?v=9BvCzt5e5d8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-15 00:00:00+00:00

Taken from JRE #1508 w/Peter Schiff: https://youtu.be/OK2zgeJLVwU

## Peter Schiff on Why He Believes the Minimum Wage Hurts Workers
 - [https://www.youtube.com/watch?v=ugLKRVUqvsw](https://www.youtube.com/watch?v=ugLKRVUqvsw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-15 00:00:00+00:00

Taken from JRE #1508 w/Peter Schiff: https://youtu.be/OK2zgeJLVwU

## Peter Schiff on the Economic Impact of The Coronavirus Shutdowns
 - [https://www.youtube.com/watch?v=6nUtRLSPG_M](https://www.youtube.com/watch?v=6nUtRLSPG_M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-15 00:00:00+00:00

Taken from JRE #1508 w/Peter Schiff:
https://youtu.be/OK2zgeJLVwU

## Peter Schiff's Critiques of Socialism  | Joe Rogan
 - [https://www.youtube.com/watch?v=wptZGgsMGuA](https://www.youtube.com/watch?v=wptZGgsMGuA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-15 00:00:00+00:00

Taken from JRE #1508 w/Peter Schiff:
https://youtu.be/OK2zgeJLVwU

## Peter Schiff: What America is Really About
 - [https://www.youtube.com/watch?v=DvkSzzmp1D8](https://www.youtube.com/watch?v=DvkSzzmp1D8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-15 00:00:00+00:00

Taken from JRE #1508 w/Peter Schiff: https://youtu.be/OK2zgeJLVwU

