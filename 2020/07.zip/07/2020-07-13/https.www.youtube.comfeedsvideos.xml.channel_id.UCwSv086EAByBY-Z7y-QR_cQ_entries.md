# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Rafał Trzaskowski będzie prezydentem na pół etatu!
 - [https://www.youtube.com/watch?v=eNntr6ZmYfI](https://www.youtube.com/watch?v=eNntr6ZmYfI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2020-07-14 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Mroczne Podcasty: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
👀 Tatusiek: http://bit.ly/3aSCheE
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
🔒 Dołącz do Spółdzielni
https://discord.gg/RSEUaR3
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/2ETKSyN
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
---------------------------------------------------------------
🖼Grafika - wykorzystano elementy ze stron: 
Adrian Grycuk / wikipedia.org / CC BY-SA 3.0 pl 
http://bit.ly/2GVG5kn
---
wikipedia.org / Lukas Varhol
https://bit.ly/38UpbgB
---------------------------------------------------------------
✅źródła:
https://bit.ly/2Zu8vtb
https://bit.ly/2AXJxZI
-------------------------------------------------------------
💡 Tagi: #Warszawa #Trzaskowski
--------------------------------------------------------------

## Co po wyborach? Analiza wyniku wyborów i scenariusze polityczne!
 - [https://www.youtube.com/watch?v=GtvjnO0ye_E](https://www.youtube.com/watch?v=GtvjnO0ye_E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2020-07-13 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Mroczne Podcasty: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
👀 Tatusiek: http://bit.ly/3aSCheE
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
🔒 Dołącz do Spółdzielni
https://discord.gg/RSEUaR3
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/2ETKSyN
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
---------------------------------------------------------------
🖼Grafika - wykorzystano elementy ze strony: 
andrzejduda.pl
https://bit.ly/2ZnVXDt
---------------------------------------------------------------
✅źródła:
https://bit.ly/305563d
-------------------------------------------------------------
💡 Tagi: #wybory #prezydent #Duda
--------------------------------------------------------------

