# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Death Stranding PC - Before You Buy [4K 60FPS]
 - [https://www.youtube.com/watch?v=IA5xbNmy6jM](https://www.youtube.com/watch?v=IA5xbNmy6jM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-07-14 00:00:00+00:00

Death Stranding is now on PC. How does the game hold up? Let's take a quick dive in.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## Top 20 Upcoming Games of 2020 [Second Half]
 - [https://www.youtube.com/watch?v=CQKvhoe15M4](https://www.youtube.com/watch?v=CQKvhoe15M4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-07-14 00:00:00+00:00

The remainder of 2020 is shaping up to be exciting with tons of games releasing for PC, PS4, Xbox One, Nintendo Switch, and the next generation Xbox Series X and PS5. Here's what we're looking forward to.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

20 Crusader Kings III 

Platform: PC

Release date: 1 September 2020



19 Star Wars: Squadrons

Platform: PS4, Xbox One, PC

Release date: October 2, 2020



18 Yakuza: Like a Dragon

Platform: Xbox Series X, PS4, Xbox One, PC  

Release date: Holiday 2020



17 Senua's Saga: Hellblade 2

Platfrom:Xbox Series X

Release Date: 2020



16 Outriders

Platform: PC, Xbox One, PS4, PS5, Xbox Series X

Release date: Holiday 2020





15 Godfall

Platform: PS5 PC 

Release date:  Holiday 2020



14 Dirt 5 

Platform: PC PS4 PS5 XBOX ONE Xbox Series X STADIA 

Release date: October 9, 2020



13 Call of Duty 2020

Platform: PC PS4 XBOX ONE

Release date: TBA 2020



12 Paper Mario: The Origami King -

Platform: SWITCH

Release date: July 17, 2020



11 Wasteland 3 

Platform:PC PS4 XBOX ONE Linux

Release date: August 28, 2020



10 Watch Dogs Legion 

Platform: PC, PS4, XBO, Stadia

Release date: October 29



9 Tell Me Why

Platform: PC Xbox One 

Release date: Holiday 2020



8 Assassin's Creed Valhalla 

PC, PS4, XBO, Stadia

Release date: November 17



7 Crash Bandicoot 4: It's About Time 

PS4, XBO

Release date: October 2



6 Flight Simulator 

Platform: PC

Release date: AUG 18



5 Marvel's Avengers 

Platform: PC, PS4, XBO, Stadia 

Release date: September 4



4 Spider-Man: Miles Morales 

Platform: PS5

Release date: Holiday 2020



3 Ghost of Tsushima 

Platform: PS4

Release date: July 17



2 Halo Infinite

Platform: Xbox Series X

Release date: Holiday 2020



1 Cyberpunk 2077 

Platform: PC, PS4, XBO, Stadia

Release date: November 19



BONUS

Destroy All Humans! Remake 

Platform: PC, PS4, XBO

Release date: July 28



Kingdoms of Amalur: Re-Reckoning 

Platform: PC, PS4, XBO

Release date: September 8



Mafia: Definitive Edition 

Platform: PC, PS4, XBO, Stadia

Release date: September 25



Deathloop 

Platform: PS5 PC

Release date: Holiday 2020

## 7 Games Where Your Actions Affect The Open World
 - [https://www.youtube.com/watch?v=eomdIqwNwvk](https://www.youtube.com/watch?v=eomdIqwNwvk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-07-13 00:00:00+00:00

Many games allow you to make your own decisions, but only a few affect the game world around you in meaningful ways. Here are some examples.
Art credit: Charlotte Soileh
https://www.artstation.com/artwork/K3JBX
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## What Made Elder Scrolls IV: Oblivion A Big DEAL?
 - [https://www.youtube.com/watch?v=QR8FjjgLnYw](https://www.youtube.com/watch?v=QR8FjjgLnYw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-07-13 00:00:00+00:00

The Elder Scrolls IV: Oblivion (2006) was a game-changing RPG that introduced many people to Tamriel for the first time. Let's take a trip down memory lane.
Art Credit: Jack McKelvie https://www.artstation.com/jackm
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

