# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## I Caught a Forex Scammer With FORGED Government Documents!
 - [https://www.youtube.com/watch?v=xEG_7A4I8Lk](https://www.youtube.com/watch?v=xEG_7A4I8Lk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-07-14 00:00:00+00:00

Forex scammers are getting worse and worse...
that's why I'm hoping today I can reveal how to do a Coffeezilla cursory background check and evaluate these guys. 

#scammer #scam #coffeezilla

