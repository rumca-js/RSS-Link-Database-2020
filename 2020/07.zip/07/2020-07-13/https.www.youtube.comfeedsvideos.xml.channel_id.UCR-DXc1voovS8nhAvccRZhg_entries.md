# Source:Jeff Gerling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg, language:en-US

## I have Crohn's Disease
 - [https://www.youtube.com/watch?v=Nm0t0MiDcvM](https://www.youtube.com/watch?v=Nm0t0MiDcvM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg
 - date published: 2020-07-13 00:00:00+00:00

Where has Jeff been the past week? In the hospital! I'll get back to my regularly scheduled tech videos soon, but I thought until then I'd tell you a little bit more about my chronic disease:

The Joy of Crohn's: https://www.jeffgeerling.com/blog/2020/joy-crohns
Heaping Helpings of Hospital Humor for Healing: https://www.jeffgeerling.com/blog/2020/heaping-helpings-hospital-humor-healing
On Colon surgery: https://www.jeffgeerling.com/blog/2018/colons-semicolons-and-crohns-surgery-oh-my
On colonoscopies: https://www.jeffgeerling.com/blog/2017/colonoscopy-or-mount-vesuvius-followed-blissful-sleepytime

#IBD #IBDvisible #Crohns

Sponsor me on GitHub: https://github.com/sponsors/geerlingguy
Support me on Patreon: https://www.patreon.com/geerlingguy

