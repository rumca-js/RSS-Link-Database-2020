# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## WHO IS BUYING THIS STUFF?? - Ice Cube Phone Cooler
 - [https://www.youtube.com/watch?v=n4kOeYy6wZs](https://www.youtube.com/watch?v=n4kOeYy6wZs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-07-14 00:00:00+00:00

Maingear Vector 2 (Amazon): https://rebrand.ly/9w2i8h4
Maingear Vector 2 (Micro Center): https://rebrand.ly/8j42qmi
Browse Micro Center’s work and learn from home products: https://rebrand.ly/mg3bawz

Check out their AORUS 15G RTX 2080 SUPER MAX Q Gaming Laptop.
On Gigabyte's Store: https://geni.us/Av0HRO
On Amazon: https://geni.us/tbAWq
On Newegg: https://geni.us/P6do

Thermal throttling on phones can be a very real problem during extended mobile gaming sessions, so today we check out a phone water cooling system that promises to keep your phone cool around the clock.

Buy the MOD X Phone Watercooler: 
On AliExpress: https://lmg.gg/yi7JR

Buy a FLIR Thermal Camera
On Amazon (PAID LINK): https://geni.us/hvRWYFr
On Newegg (PAID LINK): https://geni.us/FCy3PP
On B&H (PAID LINK): https://geni.us/fORA9t

Buy Samsung Smart Phones
On Amazon (PAID LINK): https://geni.us/BI8Z0h
On Newegg (PAID LINK): https://geni.us/Av8b
On B&H (PAID LINK): https://geni.us/jg77

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1222082-this-made-my-phone-faster/

GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Mech Keyboard: https://geni.us/RecNBTI
NEEDforSEAT Gaming Chairs: https://geni.us/needforseat
Get a Displate Metal Print at https://lmg.gg/displateltt
Use code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Gear on Amazon: https://geni.us/lmgamazon
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0 https://lmg.gg/fxHYK 
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://lmg.gg/Q9yyQ 
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://lmg.gg/8upii

## I've never seen ANYTHING like this before... Temple OS
 - [https://www.youtube.com/watch?v=LtlyeDAJR7A](https://www.youtube.com/watch?v=LtlyeDAJR7A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-07-13 00:00:00+00:00

Get 20% OFF + Free Shipping at Manscaped.com with code LTT - https://mnscpd.com/2ML8ni3

Buy the Elgato Wave 1 Streaming Mic at https://geni.us/Ruam880
Buy the Elgato Wave 3 Streaming Mic at https://geni.us/n4c8

Terry Davis may not be as well-known as Linus Torvalds, but his open source operating system may be a legacy that will live on forever. What is it, and how do you use it?

Check out TempleOS: https://templeos.org/
Check out Fredrik Knudsen's TempleOS documentary: https://www.youtube.com/watch?v=UCgoxQCf5Jg

Discuss on the forum: https://linustechtips.com/main/topic/1221613-ive-never-seen-anything-like-this-before/


GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Mech Keyboard: https://geni.us/RecNBTI
NEEDforSEAT Gaming Chairs: https://geni.us/needforseat
Get a Displate Metal Print at https://lmg.gg/displateltt
Use code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Gear on Amazon: https://geni.us/lmgamazon
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0 https://lmg.gg/fxHYK 
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://lmg.gg/Q9yyQ 
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://lmg.gg/8upii

