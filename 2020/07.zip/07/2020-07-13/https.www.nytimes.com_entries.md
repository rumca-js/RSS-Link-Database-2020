## George Soros’s Foundation Pours $220 Million Into Racial Equality Push - The New York Times
 - [https://www.nytimes.com/2020/07/13/us/politics/george-soros-racial-justice-organizations.html](https://www.nytimes.com/2020/07/13/us/politics/george-soros-racial-justice-organizations.html)
 - RSS feed: https://www.nytimes.com
 - date published: 2020-07-13 08:43:45+00:00

George Soros’s Foundation Pours $220 Million Into Racial Equality Push - The New York Times

