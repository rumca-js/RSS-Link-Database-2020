# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## The Drinker Recommends... Jaws
 - [https://www.youtube.com/watch?v=1O9E311Vs9Y](https://www.youtube.com/watch?v=1O9E311Vs9Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-07-13 00:00:00+00:00

For this episode of Drinker Recommends, we're going back 45 years to the small island of Amity, to explore the movie that made everyone afraid to go in the water...

