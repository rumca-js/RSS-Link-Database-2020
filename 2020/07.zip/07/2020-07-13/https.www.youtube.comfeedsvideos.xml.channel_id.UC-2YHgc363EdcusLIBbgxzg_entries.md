# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## So Apparently "Toads Found In Rocks" Is A Thing | Answers With Joe
 - [https://www.youtube.com/watch?v=NTC0gQFYqD4](https://www.youtube.com/watch?v=NTC0gQFYqD4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2020-07-13 00:00:00+00:00

Get 20% off a premium subscription to Brilliant when you go to http://www.brilliant.org/answerswithjoe.
As weird as it sounds, there are dozens of stories of animals, especially toads, found in rocks. Can this really be real? Because nature has developed some amazing survival strategies and there are creatures that can survive being frozen or entombed for long periods.

In this video, we explore the story of Old Rip, the horned frog that survived being locked in a time capsule for 30 years, and examine tardigrades, which might be living on the moon right now.

Music credits:
Frogs Legs Rag by Kevin MacLeodLink
https://incompetech.filmmusic.io/song/5761-frogs-legs-rag License: http://creativecommons.org/licenses/by/4.0/

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS

https://www.dallasnews.com/news/texana/2018/10/05/the-strange-tale-of-old-rip-the-horned-toad-on-display-in-a-texas-courthouse/

https://www.youtube.com/watch?v=A8q8PXoJwVk

https://www.atlasobscura.com/articles/the-ballad-of-ol-rip-the-horny-toad-that-wouldnt-die

https://mysteriousuniverse.org/2018/11/toads-in-rocks-and-other-bizarre-entombed-animals/

https://www.mentalfloss.com/article/56755/16-amazing-facts-about-sea-monkeys

https://mysteriousuniverse.org/2018/11/toads-in-rocks-and-other-bizarre-entombed-animals/

https://skeptoid.com/episodes/4223

