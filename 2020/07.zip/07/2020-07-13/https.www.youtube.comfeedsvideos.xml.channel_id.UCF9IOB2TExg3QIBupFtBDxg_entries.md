# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## US Update
 - [https://www.youtube.com/watch?v=Z-I5piVSGf4](https://www.youtube.com/watch?v=Z-I5piVSGf4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2020-07-14 00:00:00+00:00

US
https://www.youtube.com/watch?v=uYvTftH2rpE

41 states with rising cases

Weeks delay for testing

People sicker, outbreaks bigger

Contact tracers cannot do their job

Athletes tested no problem

NBA player tested 20 times in Florida

Arizona University, saliva test, 2,000 up to 16,000

Florida

Cases, + 15,300 (Sunday) + 12,624 (Monday)

Open for business

Carlos Gimenez, the reason is us, OK

Change behaviour

Younger people after COVID parties

7 hospitals at capacity now

California

Cases, + 63,714 past week

Bars, indoor dining, churches,

Businesses will close, good people unemployed, because people would not wear a mask

Arizona

19% testing positive

Phoenix, over 100% capacity

Dr. Fauci

We haven’t even begun to see the end of it yet

36 years as director of National Institute of Allergy and Infectious Diseases

I don’t think it’s an exaggeration to say we have a serious ongoing problem, right now, as we speak

What worries me is the slope of the curve

It still looks like it’s exponential 

Many states started opening up before their cases got down to a baseline level where new cases could easily be tracked

I think we have to realise that some states jumped ahead of themselves. Other states did it correctly

But the citizenry didn’t listen to the guidelines and they decided they were going to stay in bars and go to congregations of crowds and celebrations

The US has always valued individual rights

This could make it hard to tackle the pandemic

A movement against science and authority

That is very, very problematic right now

Extreme confusion

I have never seen a virus or any pathogen that has such a broad range of manifestations

Even if it doesn’t kill you, even if it doesn’t put you in the hospital, it can make you seriously ill

I have a reputation, as you probably have figured out, of speaking the truth at all times and not sugar-coating things 

And that may be one of the reasons why I haven’t been on television very much lately

## Update, UK
 - [https://www.youtube.com/watch?v=dXUmFmZV8Vw](https://www.youtube.com/watch?v=dXUmFmZV8Vw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2020-07-14 00:00:00+00:00

UK

Prepare now for a winter COVID-19 peak, Academy of Medical Sciences, 14th July

37 excerpts

https://acmedsci.ac.uk/more/news/prepare-now-for-a-winter-covid-19-peak-warns-academy-of-medical-sciences

Preparations to avoid second wave worst-case scenario in NHS hospitals must start now

COVID-19 is more likely to spread in winter

More time indoors

Virus able to survive longer in colder, darker winter conditions.

Problems

Disruption already created

Backlog of patients

Possibility of a flu epidemic

Other infectious diseases

Asthma, heart attack, chronic obstructive pulmonary disease and stroke

Overlapping symptoms of COVID-19, flu and other winter infections

Internal redeployments

Slower with reduced throughput capacity

Risk of the health service being overwhelmed

Actions

Minimising transmission in the community

Public information campaign for all

Tailored to individuals and communities at high risk

Comprehensive, near real-time, population-wide surveillance system

Flu vaccination, concerted effort 

Minimise coronavirus and flu transmission everywhere

Track, trace and isolate programme ready for winter

Shielding

Hospitals and care homes

COVID-19 and COVID-19-free zones

Ensure there is adequate PPE

System-wide infection control, minimise transmission in hospital and other residential care settings

Factors

High degree of uncertainty about how epidemic will evolve 

Rt 1.7 from September 2020 onwards

Peak in hospital admissions and deaths in January and February 2021

September 2020 to June 2021, 119,900 hospital-based deaths (excluding care homes)

Government would act to reduce the transmission rate

Dexamethasone (and heparin)

Need for immediate action

It must be done now

Masks mandated in shops in England from 24th July. Already mandatory in shops in Scotland. 

https://www.theguardian.com/world/2020/jul/13/face-masks-shops-england-24-july-boris-johnson
 
Germany, Spain, Italy and Greece, have already made it compulsory

YouGov poll

UK , 36%
Spain, 86%
Italy, 83%
France, 78%
Germany, 65%

## Update with US concerns
 - [https://www.youtube.com/watch?v=u_Y04ZxJwJY](https://www.youtube.com/watch?v=u_Y04ZxJwJY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2020-07-13 00:00:00+00:00

US

https://www.cdc.gov/covid-data-tracker/index.html#cases

Leadership by example

British PM

https://www.theguardian.com/world/2020/jul/13/boris-johnson-says-face-masks-should-be-worn-in-shops-in-england

The scientific evidence of face coverings, and the importance of stopping aerosol droplets; that’s been growing 

So I do think that in shops it is very important to wear a face covering

Heat wave

White house task force, (Brett Giroir)

Deaths expected to go up

Turning around in the next 2 or 3 weeks 

90% of people in hotspots need to wear masks or we will not get control of the virus

White house Fauci debate

https://www.cdc.gov/covid-data-tracker/index.html#cases

https://rt.live

Florida

Cases, + 15,300

Tests, + 140,000

Masks not always used

Beaches and businesses open

Whitehouse task force, wearing masks is essential

Miami, ITU capacity, 6 full already

Disney world, reduced capacity

Masks over age of 3

Texas

Cases, + 6,000

Refrigerator trucks

https://www.houstonchronicle.com/news/investigations/article/As-COVID-19-continues-to-slam-Houston-the-death-15400462.php?utm_source=newsletter&utm_medium=email&utm_campaign=HC_DailyHeadlines&utm_term=news&utm_content=headlines#photo-19662384

Gregg Abbott

May need a lockdown

Death toll will rise

Reporting inconsistencies between states

Texas is one of 24 states that publicly reports only confirmed COVID-19 deaths, not probables

(19% of deaths reported in New York City, was reported as a probable)

Rampant testing shortages

Many patients likely died without being screened

Surge of cases, health care providers in Houston overwhelmed

12 hours or more for emergency room care or ICU beds with respiratory distress

What we’re seeing now in states like Texas is comparable to what we saw in New York City (CDC) 

Death data lag

Incubation

Symptomatic

Complications

Death collation

Reporting

The steep rise in cases that started about mid-June in many states will likely be seen in rising deaths very soon

It is hard to see how they won’t come

https://www.kff.org/person/jennifer-kates/

Death rates increasing by 50% in past month

Arizona

Texas

Arkansas

Tennessee

South Carolina

Arizona

Refrigerator trucks

Michigan

July 4th Parties

Packed parties made contact tracing impossible

Louisiana

Bars closed

Mandatory mask order

61 Marines 

https://www.businessinsider.com/coronavirus-outbreaks-us-marine-bases-in-japan-anger-authorities-2020-7?r=US&IR=T

It is extremely regrettable that the infections are rapidly spreading among US personnel when we Okinawans are doing our utmost to contain the infections (Okinawa's governor, Denny Tamaki)

Okinawans are shocked by what we were told

We now have strong doubts that the US military has taken adequate disease prevention measures.

Two experimental vaccines

https://www.theguardian.com/world/live/2020/jul/13/coronavirus-live-news-who-reports-record-global-cases-as-south-africa-reinstates-alcohol-ban

German biotech firm BioNTech and Pfizer

Fast track designation from the U.S. drug regulator

Trial with up to 30,000 participants as soon as later this month

100 million doses by the end of this year

1.2 billion doses by 2021-end.

South America
Death toll higher than North America

Japan
I want to host them as a symbol of the world coming together to overcome this tough situation and of strengthened bonds among humankind (Koike)

