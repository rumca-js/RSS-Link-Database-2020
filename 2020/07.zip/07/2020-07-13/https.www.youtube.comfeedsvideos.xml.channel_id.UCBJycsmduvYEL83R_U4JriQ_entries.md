# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## OnePlus Nord Reveal! How Much Do Smartphones Actually Cost?
 - [https://www.youtube.com/watch?v=W-VInHvlrZo](https://www.youtube.com/watch?v=W-VInHvlrZo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-07-14 00:00:00+00:00

Exclusive reveal of the OnePlus Nord design, and a chat on how much smartphone parts cost!

WVFRM Podcast episode: http://bit.ly/WaveformMKBHD

The Budget Smartphone Blueprint: https://youtu.be/u41Zt6z5s7A

Timestamps:
0:00 Intro
1:35 What is Nord?
4:03 NFC Cost
5:23 IP Rating Cost
9:32 Battery Cost
10:24 Display Cost
11:52 Headphone Jack
13:29 OnePlus Nord Design
17:44 Outro

MKBHD Merch: http://shop.MKBHD.com

Video Gear I use: http://kit.co/MKBHD/video-gear#recom...
Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: http://youtube.com/MKBHD
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

