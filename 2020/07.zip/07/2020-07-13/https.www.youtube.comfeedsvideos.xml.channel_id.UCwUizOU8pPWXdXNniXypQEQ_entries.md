# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Astrology Reading - Bad News for Summer 2020
 - [https://www.youtube.com/watch?v=Y5-Kfbo3muY](https://www.youtube.com/watch?v=Y5-Kfbo3muY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-07-14 00:00:00+00:00

Grab your LMNT Electrolytes Here - https://drinklmnt.com/jp

My Salt Lamp - https://amzn.to/38YT532

Astrology is the fine art of understanding why things are happening in life based on the alignment of the stars. There's never been more bad news coming your way than for this summer. Here's what you can expect and what's astrologically going on in the stars and zodiac to make this the hardest summer in human history. 

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

As an Amazon Associate, I earn a small commission from qualifying purchases. Some of the links are affiliate links and if you decide to buy products through them I earn a tiny commission. It costs you nothing but helps support the channel and future videos!

