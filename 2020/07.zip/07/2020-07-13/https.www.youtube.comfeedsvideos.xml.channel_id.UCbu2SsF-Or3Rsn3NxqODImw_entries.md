# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Dead by Daylight - Official 4K Stadia Announcement Trailer
 - [https://www.youtube.com/watch?v=WBoMkNKtJcc](https://www.youtube.com/watch?v=WBoMkNKtJcc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-07-14 00:00:00+00:00

Experience the thrills of Dead by Daylight, one of the most popular multiplayer horror games, on Google Stadia.

Coming September 2020.

Dead by Daylight is an asymmetrical multiplayer horror game where one player takes on the role of a brutal Killer and the other four play as Survivors. As a Killer, your goal is to sacrifice as many Survivors as possible. 
As a Survivor, your goal is to escape and avoid being caught and killed.

## Dead by Daylight - Official Stadia Announcement Trailer
 - [https://www.youtube.com/watch?v=L4wmg6dE3dI](https://www.youtube.com/watch?v=L4wmg6dE3dI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-07-14 00:00:00+00:00

Experience the thrills of Dead by Daylight, one of the most popular multiplayer horror games, on Google Stadia.

Coming September 2020.

Dead by Daylight is an asymmetrical multiplayer horror game where one player takes on the role of a brutal Killer and the other four play as Survivors. As a Killer, your goal is to sacrifice as many Survivors as possible. 
As a Survivor, your goal is to escape and avoid being caught and killed.

## Ghost of Tsushima Review
 - [https://www.youtube.com/watch?v=0UkhlCjR1-w](https://www.youtube.com/watch?v=0UkhlCjR1-w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-07-14 00:00:00+00:00

Ghost of Tsushima has some dull edges, but strikes a lot of highs with its cinematic stylings. Sucker Punch's action-adventure Ghost of Tsushima will be available on PS4 on July 17. You can read the full written Ghost of Tsushima review by Edmond Tran on GameSpot: https://www.gamespot.com/reviews/ghost-of-tsushima-review-chaos-in-the-windy-city/1900-6417501/

## Hitman 3 - Official 4K Stadia Announcement Trailer
 - [https://www.youtube.com/watch?v=P92YOxUghiw](https://www.youtube.com/watch?v=P92YOxUghiw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-07-14 00:00:00+00:00

The World of Assassination Trilogy comes to Stadia. Hitman and Hitman 2 both arrive this September, with Hitman launching into Stadia Pro. Hitman 3, the dramatic conclusion to the trilogy, is set to release January 2021.

## Hitman 3 - Official Stadia Announcement Trailer
 - [https://www.youtube.com/watch?v=p8OPeOWoZNQ](https://www.youtube.com/watch?v=p8OPeOWoZNQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-07-14 00:00:00+00:00

The World of Assassination Trilogy comes to Stadia. Hitman and Hitman 2 both arrive this September, with Hitman launching into Stadia Pro. Hitman 3, the dramatic conclusion to the trilogy, is set to release January 2021.

## Lego Nintendo Entertainment System - Official Reveal Trailer
 - [https://www.youtube.com/watch?v=pfgFWiu3Z7U](https://www.youtube.com/watch?v=pfgFWiu3Z7U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-07-14 00:00:00+00:00

Play with power, and bricks, with this Nintendo Entertainment System made entirely from LEGO! Releasing this August for $229.99.

## Ubisoft Announces A Bunch Of Release Dates | Save State
 - [https://www.youtube.com/watch?v=EQjRx3kanJ8](https://www.youtube.com/watch?v=EQjRx3kanJ8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-07-14 00:00:00+00:00

Ubisoft announces release dates for its upcoming games, Cyberpunk 2077 is not coming to Game Pass, and Microsoft takes a stance on cross-gen games.

Ubisoft Forward may not have had many surprises, but it did have plenty of release dates. Hyper Scape is currently in open beta for PC, Watch Dogs: Legion and Assassin's Creed Valhalla are both coming later this year, and Far Cry 6 is scheduled for February 2021. 

Plenty of games make there debut on Xbox Game Pass, but Cyberpunk 2077 will not be one of them. While there is an exclusive Cyberpunk 2077-themed Xbox One, the partnership doesn't extend to Game Pass, it seems. Microsoft and Sony are taking different approaches to the next generation of consoles. Sony is going the more traditional route with PS5-only games, while Microsoft, however, wants to launch games across both Xbox One and Xbox Series X. 

And hey, while you're here, GameSpot launched its own merch store. Till the end of August, all the proceeds will be split between Black Lives Matter and COVID-19 relief. 

Check it out here: store.gamespot.com

#SaveState #GameSpot

## Death Stranding - Official 4K PC Launch Trailer
 - [https://www.youtube.com/watch?v=c3bEhASd2bw](https://www.youtube.com/watch?v=c3bEhASd2bw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-07-13 00:00:00+00:00

Unite the divided - One more time. From legendary game creator Hideo Kojima and KOJIMA PRODUCTIONS comes DEATH STRANDING, the genre-defying open world action adventure for PC! Launching July 14 on Steam and the Epic Games Store.

## Ghost Of Tsushima – Official PS4 Launch Trailer
 - [https://www.youtube.com/watch?v=SLoQbykVbDc](https://www.youtube.com/watch?v=SLoQbykVbDc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-07-13 00:00:00+00:00

Jin Sakai must set aside his samurai traditions and forge a new path, the path of the Ghost, and wage an unconventional war for the freedom of Tsushima. The hotly anticipated Ghost of Tsushima from Sucker Punch Productions arrives July 17, exclusively on PlayStation 4.

## Ghost of Tsushima – Official 4K Cinematic Launch Trailer
 - [https://www.youtube.com/watch?v=GR0OCg4lsGI](https://www.youtube.com/watch?v=GR0OCg4lsGI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-07-13 00:00:00+00:00

Jin Sakai must set aside his samurai traditions and forge a new path, the path of the Ghost, and wage an unconventional war for the freedom of Tsushima.

The hotly anticipated Ghost of Tsushima from Sucker Punch Productions arrives July 17, exclusively on PlayStation 4.

## Just As Absurd As The Original | Deadly Premonition 2 Let's Play Part 1
 - [https://www.youtube.com/watch?v=UeHO-lU1a94](https://www.youtube.com/watch?v=UeHO-lU1a94)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-07-13 00:00:00+00:00

Deadly Premonition super-fans Ben Janca and Jean-Luc Seipke are here to experience Dead Premonition 2: A Blessing In Disguise for the first time, and they want to take all of you along for the ride.

If you enjoy this and want to see more let us know in the comments and like and share this video!

## Remember When PS3 Almost Lost the Console War?
 - [https://www.youtube.com/watch?v=cTHD22RWGGQ](https://www.youtube.com/watch?v=cTHD22RWGGQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-07-13 00:00:00+00:00

Sony may have flown too close to the sun with the PS3, but its fall from grace is what led to the PS4’s success. 

The PlayStation 3 stumbled out of the gate back in 2006, nearly costing Sony the console war. But through hard lessons learned, paved the way for the PS4’s overwhelming success. So where did Sony go wrong with the PS3, and how exactly did it right its course? 

Join Kurt Indovina for this episode of Remember When as he looks back on the PS3’s rocky launch, its infamous cell technology, and how Sony managed to climb its way back up the food chain. Kurt also invites CNET editor Jeff Bakalar to give some extra insight, and fill some gaps on the PS3’s troublesome launch.

Watch Remember When here: https://www.youtube.com/playlist?list=PLpg6WLs8kxGMLxDSYQgn3jsNCR8qG8tlj

Subscribe to our channel: https://www.youtube.com/gamespot

Follow us!
Twitter: https://twitter.com/GameSpot
Instagram: https://www.instagram.com/gamespot/ 
Facebook: https://www.facebook.com/GameSpot/

#RememberWhen #PS3 #GameSpot

