## LOSE YOURSELF | Medieval Bardcore Version | 8 Mile | Eminem vs Beedle the Bardcore
 - [https://www.youtube.com/watch?v=zg3Ggn3CMgU](https://www.youtube.com/watch?v=zg3Ggn3CMgU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCynijyjqY-u6z8_sGKgCErg
 - date published: 2020-07-13 00:00:00+00:00

#bardcore #medievalmusic #dnd

Eminem - Lose Yourself [Medieval Bardcore Version]
------------------------------------------------------------------------------------
Mine own medieval, fantasy orchestra presents Ready Or Not for the enjoyment of knights, ladies and fine fellows of the realm.
------------------------------------------------------------------------------------
Original Song: “Lose Yourself”
Original Artist: Eminem
Writer: Jeff Bass, Luis Resto, Marshall Mathers.
------------------------------------------------------------------------------------
More Music:
♫ Gangsta’s Paradise | Medieval Bardcore Version ►https://youtu.be/dywM446-vcE
♫ Ready Or Not | Medieval Bardcore Version ►https://youtu.be/_IHo_jobrtk
♫ Hip Hop Medieval Bardcore ►https://www.youtube.com/playlist?list=PLKoMYNoyrWoAHz5OOP6BwcY7SELvawbGx
------------------------------------------------------------------------------------
Supporteth Me:
►Patreon: https://www.patreon.com/beedlethebardcore
------------------------------------------------------------------------------------
Followeth Me:
►Instagram: https://www.instagram.com/beedlethebardcore/
►Twitter: https://twitter.com/BeedleBardcore
------------------------------------------------------------------------------------
If you would like to add your vocals to one of my tracks or use my music in the background of one of your videos please see the about section of the channel!

Please do not re-upload any of my tracks, including 1 hour to 10 hour versions or as part of compilations.

If you do any of the above without speaking to me first you run the risk of your content being removed and action being taken by YouTube!

