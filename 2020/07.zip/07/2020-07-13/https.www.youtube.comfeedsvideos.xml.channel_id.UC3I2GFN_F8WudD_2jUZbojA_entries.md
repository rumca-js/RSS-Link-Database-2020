# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Temples - Atomise (Live on KEXP)
 - [https://www.youtube.com/watch?v=H4qLXxeseik](https://www.youtube.com/watch?v=H4qLXxeseik)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-07-13 00:00:00+00:00

http://KEXP.ORG presents Temples performing “Atomise” live at The Triple Door as part of KEXP’s VIP Club concert series. Recorded February 7, 2020.

Host: Troy Nelson
Audio Engineers: Francios “Mido” Elalfy & Curt Nelson
Audio Mixer: Francios “Mido” Elalfy
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
http://www.templestheband.com

## Temples - Certainty (Live on KEXP)
 - [https://www.youtube.com/watch?v=Y6jQrIiwXt8](https://www.youtube.com/watch?v=Y6jQrIiwXt8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-07-13 00:00:00+00:00

http://KEXP.ORG presents Temples performing “Certainty” live at The Triple Door as part of KEXP’s VIP Club concert series. Recorded February 7, 2020.

Host: Troy Nelson
Audio Engineers: Francios “Mido” Elalfy & Curt Nelson
Audio Mixer: Francios “Mido” Elalfy
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
http://www.templestheband.com

## Temples - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=QrPLH_DdHsw](https://www.youtube.com/watch?v=QrPLH_DdHsw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-07-13 00:00:00+00:00

http://KEXP.ORG presents BAND performing live at The Triple Door as part of KEXP’s VIP Club concert series. Recorded February 7, 2020.

Songs:
The Howl
Certainty
Holy Horses
You're Either On Something
Hot Motion
Atomise
Shelter Song

Host: Troy Nelson
Audio Engineers: Francios “Mido” Elalfy & Curt Nelson
Audio Mixer: Francios “Mido” Elalfy
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
http://www.templestheband.com

## Temples - Holy Horses (Live on KEXP)
 - [https://www.youtube.com/watch?v=3nQGRpmRuEM](https://www.youtube.com/watch?v=3nQGRpmRuEM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-07-13 00:00:00+00:00

http://KEXP.ORG presents Temples performing “Holy Horses” live at The Triple Door as part of KEXP’s VIP Club concert series. Recorded February 7, 2020.

Host: Troy Nelson
Audio Engineers: Francios “Mido” Elalfy & Curt Nelson
Audio Mixer: Francios “Mido” Elalfy
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
http://www.templestheband.com

## Temples - Hot Motion (Live on KEXP)
 - [https://www.youtube.com/watch?v=3Vtb5zxtNFg](https://www.youtube.com/watch?v=3Vtb5zxtNFg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-07-13 00:00:00+00:00

http://KEXP.ORG presents Temples performing “Hot Motion” live at The Triple Door as part of KEXP’s VIP Club concert series. Recorded February 7, 2020.

Host: Troy Nelson
Audio Engineers: Francios “Mido” Elalfy & Curt Nelson
Audio Mixer: Francios “Mido” Elalfy
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
http://www.templestheband.com

## Temples - Shelter Song (Live on KEXP)
 - [https://www.youtube.com/watch?v=LkEDyvlokUc](https://www.youtube.com/watch?v=LkEDyvlokUc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-07-13 00:00:00+00:00

http://KEXP.ORG presents Temples performing “Shelter Song” live at The Triple Door as part of KEXP’s VIP Club concert series. Recorded February 7, 2020.

Host: Troy Nelson
Audio Engineers: Francios “Mido” Elalfy & Curt Nelson
Audio Mixer: Francios “Mido” Elalfy
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
http://www.templestheband.com

## Temples - The Howl (Live on KEXP)
 - [https://www.youtube.com/watch?v=gxIt6Tdl1DQ](https://www.youtube.com/watch?v=gxIt6Tdl1DQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-07-13 00:00:00+00:00

http://KEXP.ORG presents Temples performing "The Howl" live at The Triple Door as part of KEXP’s VIP Club concert series. Recorded February 7, 2020.

Host: Troy Nelson
Audio Engineers: Francios “Mido” Elalfy & Curt Nelson
Audio Mixer: Francios “Mido” Elalfy
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
http://www.templestheband.com

## Temples - You're Either On Something (Live on KEXP)
 - [https://www.youtube.com/watch?v=0dkTg4Q0hdI](https://www.youtube.com/watch?v=0dkTg4Q0hdI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-07-13 00:00:00+00:00

http://KEXP.ORG presents Temples performing “You're Either On Something” live at The Triple Door as part of KEXP’s VIP Club concert series. Recorded February 7, 2020.

Host: Troy Nelson
Audio Engineers: Francios “Mido” Elalfy & Curt Nelson
Audio Mixer: Francios “Mido” Elalfy
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
http://www.templestheband.com

