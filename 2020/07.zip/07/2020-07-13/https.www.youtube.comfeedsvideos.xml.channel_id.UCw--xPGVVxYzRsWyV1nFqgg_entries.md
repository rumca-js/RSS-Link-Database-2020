# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## COSMERE MEME REVIEW
 - [https://www.youtube.com/watch?v=xPWDIolnQPU](https://www.youtube.com/watch?v=xPWDIolnQPU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-07-14 00:00:00+00:00

I sat down and reviewed some spicey cosmere memes with the awesome @XCatherineReads. Be sure to go check out her channel if you enjoy some good old fantasy book tube! 
Catherine's Channel: https://www.youtube.com/channel/UCJqGacjWwoYXUTbCAihyiyQ

Podcast: https://afictionalconversation.podbean.com/
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## PEACE TALKS - Dresden Files Review
 - [https://www.youtube.com/watch?v=Y7Sa5RU39o8](https://www.youtube.com/watch?v=Y7Sa5RU39o8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-07-14 00:00:00+00:00

My review of Peace Talks, the latest entry into the Dresden Files by Jim Butcher. Is it worth the wait? Let's discuss and review Peace Talks! 
Podcast: https://afictionalconversation.podbean.com/
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## Brief Cases and Side Jobs - Dresden Files Ramble
 - [https://www.youtube.com/watch?v=UVIbwvaHYtQ](https://www.youtube.com/watch?v=UVIbwvaHYtQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-07-13 00:00:00+00:00

My rambling thoughts on the Dresden Files short stories from Side Jobs and Brief Case. 
The Podcast (A Fictional Conversation): https://afictionalconversation.podbean.com/
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

