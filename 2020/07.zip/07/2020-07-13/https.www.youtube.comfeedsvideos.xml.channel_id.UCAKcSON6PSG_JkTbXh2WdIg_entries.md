# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Soul Asylum - two songs recorded at The Current in 2012
 - [https://www.youtube.com/watch?v=6AEHvwxyvng](https://www.youtube.com/watch?v=6AEHvwxyvng)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-07-14 00:00:00+00:00

July 12 is the birthday of Dan Murphy, a co-founder and the former lead guitarist of the band Soul Asylum. In honor of Murphy's birthday, we're sharing two performances recorded by Soul Asylum for The Current in MPR's Forum back in 2012 – Murphy's final year in the band.

SONGS PERFORMED
0:00 "Gravity"
4:45 "Black Gold"

PERSONNEL
Dave Pirner – lead vocals, guitar
Dan Murphy – lead guitar
Winston Roye – bass
Michael Bland – drums

CREDITS
Video & Photo: Nate Ryan; Micah Taylor
Audio: Michael DeMark
Production: Derrick Stevens

FIND MORE:
2012 session in the Forum at MPR: https://www.thecurrent.org/feature/2012/07/25/soul-asylum-live

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

