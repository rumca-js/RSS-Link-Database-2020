# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Dreams | Fleetwood Mac | funk cover ft. Elise Trouw
 - [https://www.youtube.com/watch?v=hu1_b6aLtyM](https://www.youtube.com/watch?v=hu1_b6aLtyM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2020-07-13 00:00:00+00:00

Patreon: http://modal.scarypocketsfunk.com/patreon
Store: https://www.scarypocketsfunk.com
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A cover of "Dreams" by Scary Pockets.

CREDITS
Lead vocal/Drums: Elise Trouw
Bass: Nick Campbell
Percussion: Rob Humphreys
Guitar: Horace Bray
Trumpet, Arranging: Jon Lampley
Saxophone, Arranging: Louis Fouché 
Keys: Jack Conte
Guitar: Ryan Lerman

Mixing/Mastering: Craig Polasko
Recording Engineer/Additional Mixing: Caleb Parker
Additional Production/Background Vocals: Louis Cato
Video Production: Ricky Chavez
Camera operator: Sammy Rothman
Video Editor: Adam Kritzberg

Recorded Live at Valentine Studios in Los Angeles, CA.

#ScaryPockets #Funk #FleetwoodMac #Dreams #EliseTrouw

