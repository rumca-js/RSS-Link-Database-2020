# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Governors Reinstate Lockdowns To Combat Recovering Economy
 - [https://www.youtube.com/watch?v=-uScjkffqOM](https://www.youtube.com/watch?v=-uScjkffqOM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-07-13 00:00:00+00:00

Governors across the country have reinstated lockdowns mere weeks after slowly starting to lift them, citing a "concerning spike" in jobs and the economy.

➡️ https://babylonbee.com/news/governors-reinstate-lockdowns-to-combat-recovering-economy

