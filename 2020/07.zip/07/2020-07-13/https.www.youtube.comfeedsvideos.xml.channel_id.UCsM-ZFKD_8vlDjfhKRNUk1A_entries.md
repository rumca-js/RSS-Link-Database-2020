# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Igor Herbut - koncert (MUZO.FM)
 - [https://www.youtube.com/watch?v=Kd4otH9155U](https://www.youtube.com/watch?v=Kd4otH9155U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-07-14 00:00:00+00:00

Igor Herbut na żywo w MUZO.FM. Artysta wykonał specjalne wersje live utworów: Jasny, Tańczmy i Wdzięczność. Piosenki pochodzą z debiutanckiej solowej płyty Igora Herbuta - Chrust. 

0:00 Jasny
5:18 Tańczmy
10:05 Wdzięczność

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Igor Herbut: http://www.facebook.com/igor.ai.1
Instagram Igor Herbut: http://www.instagram.com/aigorek
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm 

#popolsku

## Igor Herbut - Wdzięczność - live MUZO.FM
 - [https://www.youtube.com/watch?v=6RiAgmKTgO4](https://www.youtube.com/watch?v=6RiAgmKTgO4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-07-13 00:00:00+00:00

Igor Herbut Wdzięczność na żywo w MUZO.FM. Piosenka Wdzięczność pochodzi z debiutanckiej solowej płyty Igora Herbuta - Chrust. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Igor Herbut: http://www.facebook.com/igor.ai.1
Instagram Igor Herbut: http://www.instagram.com/aigorek
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm


Igor Herbut Wdzięczność tekst


Chcę Ci życzyć na Twojej ścieżce śmiałych decyzji
Przestań się bać, już w porządku, już dobrze
To wątpliwości niszczą więcej naszych marzeń
Niż małe wielkie katastrofy

Gdy wpatrujesz się w dal, o czym myślisz, co widzisz?
Nie bądź zaskoczony tym, jak szybko odpowiada nasz świat
Gdy zaczynamy żyć, żyć prawdziwie
Czasem tylko jeden krok dzieli na od szczęścia

Nie czekaj z wdzięcznością na nic wielkiego
Bądź wdzięczny, a wszystko stanie się wielkie
Gdy przestałem czekać na coś ważnego
To nagle wszystko stało się ważne
I nagle wszystko stało się ważne

Chcę Ci życzyć na Twojej ścieżce w chwilach zwątpienia
Abyś kroczył nią godnie i szczerość zamieniał
W zwycięstwa, bo wiesz ja codziennie staram się
Tak jak i pewnie Ty być w dobrym miejscu

Nie czekaj z wdzięcznością na nic wielkiego
Bądź wdzięczny, a wszystko stanie się wielkie
Gdy przestałem czekać na coś ważnego
To nagle wszystko stało się ważne
I nagle wszystko stało się ważne

Nie czekaj z wdzięcznością na nic wielkiego
Bądź wdzięczny, a wszystko stanie się wielkie
Gdy przestałem czekać na coś ważnego
To nagle wszystko stało się ważne
I nagle wszystko stało się ważne 

#popolsku

