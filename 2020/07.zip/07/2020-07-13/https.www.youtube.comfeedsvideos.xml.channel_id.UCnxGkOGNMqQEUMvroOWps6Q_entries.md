# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Bob Saget Recounts Stories About Sam Kinison, Bill Hicks, and Rodney Dangerfield | Joe Rogan
 - [https://www.youtube.com/watch?v=i7hW7ApzvrU](https://www.youtube.com/watch?v=i7hW7ApzvrU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-14 00:00:00+00:00

Taken from #1507 w/Bob Saget:
https://youtu.be/BY3CY36WAec

## Bob Saget Witnessed Bill Burr's Infamous Philly Rant | Joe Rogan
 - [https://www.youtube.com/watch?v=F-xFbRsktno](https://www.youtube.com/watch?v=F-xFbRsktno)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-14 00:00:00+00:00

Taken from #1507 w/Bob Saget:
https://youtu.be/BY3CY36WAec

## Bob Saget on Doing Blue Comedy While Having a Squeaky Clean Public Image
 - [https://www.youtube.com/watch?v=Q15PjHWKnyA](https://www.youtube.com/watch?v=Q15PjHWKnyA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-14 00:00:00+00:00

Taken from JRE #1507 w/Bob Saget: https://youtu.be/BY3CY36WAec

## Bob Saget on Working with Richard Pryor | Joe Rogan
 - [https://www.youtube.com/watch?v=jap4YDu_Otk](https://www.youtube.com/watch?v=jap4YDu_Otk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-14 00:00:00+00:00

Taken from #1507 w/Bob Saget:
https://youtu.be/BY3CY36WAec

## Alex Jones Explains the Nature of Conciousness
 - [https://www.youtube.com/watch?v=hvNx6DbVENM](https://www.youtube.com/watch?v=hvNx6DbVENM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-13 00:00:00+00:00

Taken from JRE #911 & #1255:
https://www.youtube.com/watch?v=Df-o5TKv0C0
https://www.youtube.com/watch?v=-5yh2HcIlkU

