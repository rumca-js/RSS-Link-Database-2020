# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Is Modern Man Stupid Enough To Remake The Princess Bride?
 - [https://www.youtube.com/watch?v=Fw39x67rmyQ](https://www.youtube.com/watch?v=Fw39x67rmyQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-07-04 00:00:00+00:00

Kyle and Ethan ask the question we’re all wondering... would modern man *really* be stupid enough to remake the best movie of all time, The Princess Bride?

## How Big Of A Baller Is Benny Hinn?
 - [https://www.youtube.com/watch?v=uv5UBLZR5x4](https://www.youtube.com/watch?v=uv5UBLZR5x4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-07-03 00:00:00+00:00

Kyle and Ethan ask Costi Hinn what normal life looks like for the notorious faith leader, Benny Hinn.

FULL ➡️ https://youtu.be/uFBKUtq2W-U

## Podcast: The Suicide Of Thought
 - [https://www.youtube.com/watch?v=m78Py257Kvg](https://www.youtube.com/watch?v=m78Py257Kvg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-07-03 00:00:00+00:00

Today on The Babylon Bee Podcast, Kyle and Ethan talk about the week’s big stories like a man being fined £450 for provocative intestinal wind, the fallen world we live in where The Princess Bride is possibly being remade, and how doctors are recommending we keep opening up and closing the economy until we all go insane. In the main topic, they read G.K. Chesterton’s ideas on the suicide of thought.

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Gain Access to the Exclusive Content and Writing Forum: https://babylonbee.com/plans

The Official Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

