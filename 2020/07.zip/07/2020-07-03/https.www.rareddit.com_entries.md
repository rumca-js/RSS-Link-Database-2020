## Bill Gates' Sphere of Influence
 - [https://i.redd.it/u0zf525kep851.jpg](https://i.redd.it/u0zf525kep851.jpg)
 - RSS feed: https://www.rareddit.com
 - date published: 2020-07-03 06:23:31+00:00

Bill Gates' Sphere of Influence

