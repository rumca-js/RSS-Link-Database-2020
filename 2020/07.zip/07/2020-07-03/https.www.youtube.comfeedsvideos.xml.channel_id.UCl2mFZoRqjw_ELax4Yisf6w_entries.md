# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Louis Rossmann interviewed by National Review on Right to Repair
 - [https://www.youtube.com/watch?v=oAbOpQJqKmw](https://www.youtube.com/watch?v=oAbOpQJqKmw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-07-03 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
https://www.nationalreview.com/2020/07/a-computer-repair-expert-takes-on-big-tech/

