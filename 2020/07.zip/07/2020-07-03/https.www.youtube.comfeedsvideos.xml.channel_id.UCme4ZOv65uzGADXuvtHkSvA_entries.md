# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## CNN [#188] Jeżeli jesteś za duży, nie wejdziesz do nieba!
 - [https://www.youtube.com/watch?v=ga5oIkOY8E4](https://www.youtube.com/watch?v=ga5oIkOY8E4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-07-04 00:00:00+00:00

#cnn #kazaniedookienka  @Langustanapalmie 

Kazanie XIV Niedzielę zwykłą, Rok A

1. czytanie (Za 9, 9-10)

Tak mówi Pan: «Raduj się wielce, Córo Syjonu, wołaj radośnie, Córo Jeruzalem! Oto Król twój idzie do ciebie, sprawiedliwy i zwycięski. Pokorny – jedzie na osiołku, na oślątku, źrebięciu oślicy. On usunie rydwany z Efraima, a konie z Jeruzalem; łuk wojenny zostanie złamany. Pokój ludom obwieści. Jego władztwo sięgać będzie od morza do morza, od brzegów Rzeki aż po krańce ziemi».

2. czytanie (Rz 8, 9. 11-13)

Bracia: Wy nie żyjecie według ciała, lecz według Ducha, jeśli tylko Duch Boży w was mieszka.

Jeżeli zaś ktoś nie ma Ducha Chrystusowego, ten do Niego nie należy. A jeżeli mieszka w was Duch Tego, który Jezusa wskrzesił z martwych, to Ten, co wskrzesił Chrystusa Jezusa z martwych, przywróci do życia wasze śmiertelne ciała mocą mieszkającego w was swego Ducha.

Jesteśmy więc, bracia, dłużnikami, ale nie ciała, byśmy żyć mieli według ciała. Bo jeżeli będziecie żyli według ciała, czeka was śmierć. Jeżeli zaś przy pomocy Ducha zadawać będziecie śmierć popędom ciała – będziecie żyli.

Ewangelia (Mt 11, 25-30)

W owym czasie Jezus przemówił tymi słowami: «Wysławiam Cię, Ojcze, Panie nieba i ziemi, że zakryłeś te rzeczy przed mądrymi i roztropnymi, a objawiłeś je prostaczkom. Tak, Ojcze, gdyż takie było Twoje upodobanie.

Wszystko przekazał Mi Ojciec mój. Nikt też nie zna Syna, tylko Ojciec, ani Ojca nikt nie zna, tylko Syn i ten, komu Syn zechce objawić.

Przyjdźcie do Mnie wszyscy, którzy utrudzeni i obciążeni jesteście, a Ja was pokrzepię. Weźcie na siebie moje jarzmo i uczcie się ode Mnie, bo jestem cichy i pokornego serca, a znajdziecie ukojenie dla dusz waszych. Albowiem słodkie jest moje jarzmo, a moje brzemię lekkie».
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Ksiądz gra w grę: Detroit Become Human [#07] Tylko miłość zmienia myślenie
 - [https://www.youtube.com/watch?v=yoNJruUiOiU](https://www.youtube.com/watch?v=yoNJruUiOiU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-07-04 00:00:00+00:00

@Langustanapalmie  #detroitbecomehuman #ksiądzgrawgrę
________________________________________
Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Miriam [#43] Królowa wniebowzięta
 - [https://www.youtube.com/watch?v=vMX2vnO8dt8](https://www.youtube.com/watch?v=vMX2vnO8dt8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-07-04 00:00:00+00:00

#Miriam #litanialoretańska  @Langustanapalmie 
________________________________________
Komentarze do wezwań Litanii Loretańskiej. 

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#548] Miara
 - [https://www.youtube.com/watch?v=pOZ2uElaAoE](https://www.youtube.com/watch?v=pOZ2uElaAoE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-07-04 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał  

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Ksiądz gra w grę: Uncharted Zaginione Dziedzictwo [#09] Ostatni będą pierwszymi!
 - [https://www.youtube.com/watch?v=kNlkfUZ0O20](https://www.youtube.com/watch?v=kNlkfUZ0O20)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-07-03 00:00:00+00:00

@Langustanapalmie #ksiądzgrawgrę #uncharted 
________________________________________
Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Miniaturkę stworzył dla nas: Sebastian Gwóźdź

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## NOWA SERIA || Zapowiedź
 - [https://www.youtube.com/watch?v=XN63L-2RVCY](https://www.youtube.com/watch?v=XN63L-2RVCY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-07-03 00:00:00+00:00

@Langustanapalmie @STREFAWODZA #AdamSzustakOP #TomaszNowakOP
________________________________________

Takich dwóch, jak Ci to nie ma :) Zapraszamy już w najbliższą niedzielę o godz: 10:oo na premierę zupełnie niesłychanej serii ojców Tomasza Nowaka OP i Adama Szustaka OP.


Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#547] Niejasno
 - [https://www.youtube.com/watch?v=21u71vkRd8Y](https://www.youtube.com/watch?v=21u71vkRd8Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-07-03 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał  

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

