# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Rebecca Foon - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=qHSpYph-hDY](https://www.youtube.com/watch?v=qHSpYph-hDY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-07-03 00:00:00+00:00

http://KEXP.ORG presents Rebecca Foon performing live in the KEXP studio. Recorded January 24, 2020.

Songs:
ICA
Improvisation
Ocean Song
Waiting Moon
I Only Wish This For You

Host: Alex Ruder
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://www.rebeccafoon.com

## Rebecca Foon - I Only Wish This for You (Live on KEXP)
 - [https://www.youtube.com/watch?v=-GeGfoLumRU](https://www.youtube.com/watch?v=-GeGfoLumRU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-07-03 00:00:00+00:00

http://KEXP.ORG presents Rebecca Foon performing "I Only Wish This for You" live in the KEXP studio. Recorded January 24, 2020.

Host: Alex Ruder
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://www.rebeccafoon.com

## Rebecca Foon - ICA (Live on KEXP)
 - [https://www.youtube.com/watch?v=WHRbnajfOjY](https://www.youtube.com/watch?v=WHRbnajfOjY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-07-03 00:00:00+00:00

http://KEXP.ORG presents Rebecca Foon performing "ICA" live in the KEXP studio. Recorded January 24, 2020.

Host: Alex Ruder
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://www.rebeccafoon.com

## Rebecca Foon - Improvisation / Ocean Song / Waxing Moon (Live on KEXP)
 - [https://www.youtube.com/watch?v=AcmFvYFCDgU](https://www.youtube.com/watch?v=AcmFvYFCDgU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-07-03 00:00:00+00:00

http://KEXP.ORG presents Rebecca Foon performing "Improvisation", "Ocean Song" and "Waxing Moon" live in the KEXP studio. Recorded January 24, 2020.

Host: Alex Ruder
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

http://kexp.org
https://www.rebeccafoon.com

