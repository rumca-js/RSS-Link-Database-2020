# Source:SssethTzeentach, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCD6VugMZKRhSyzWEWA9W2fg, language:en-US

## Recettear Review | Capitalism Ho! | Merchant Edition™
 - [https://www.youtube.com/watch?v=JJd85HFq71c](https://www.youtube.com/watch?v=JJd85HFq71c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCD6VugMZKRhSyzWEWA9W2fg
 - date published: 2020-07-03 00:00:00+00:00

It is not from the benevolence of the butcher, the brewer, or the baker
that we expect our dinner,
but from their regard to their own interest.
-Adam Smith.

BUY / 80% off until July 9th:
https://store.steampowered.com/app/70400/Recettear_An_Item_Shops_Tale/

STREAM: https://dlive.tv/SsethTzeentach
Saturdays 
July 4 / 11 / 18 / 25 
15:00 - 17:00 UTC/GMT
TIMES (convert for your timezone): https://bit.ly/July2020Sseth

Enjoy.
-----------------------
Send Sseth Shekels: https://www.paypal.me/SsethTzeentachGB
Send Sseth Shekels per video:  https://www.patreon.com/Sseth
Send Sseth Shekels / crypto: https://www.subscribestar.com/ssethtzeentach

Website: https://ssethtzeentach.com/
Twitter: https://twitter.com/SsethTzeentach
FB: https://www.facebook.com/sseth672/

