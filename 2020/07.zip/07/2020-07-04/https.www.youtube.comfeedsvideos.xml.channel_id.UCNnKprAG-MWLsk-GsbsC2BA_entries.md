# Source:FlashGitz, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA, language:en-US

## Elon Musk and Joe Rogan get a cartoon
 - [https://www.youtube.com/watch?v=k1kQYlBR0jo](https://www.youtube.com/watch?v=k1kQYlBR0jo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA
 - date published: 2020-07-04 00:00:00+00:00

Get 70% off NordVPN! Only $3.49/mo, plus you get an additional month FREE at https://nordvpn.com/Flashgitz or use coupon Flashgitz

Flashgitz presents "Elon Musk and Joe Rogan get a cartoon" a Rick and Morty parody featuring Elon Musk and Joe Rogan. 

Patreon ►
https://www.patreon.com/flashgitz

Special thanks to our Patron Producers, really going the extra mile to make this possible:

Connor Hill
David Murphy
Andrew Palmer
Albert Hutchins
Adam Knopow
Morgan Collins
Jacob Reeves
Zack Buckland
Jonathon Geach
Brad

Thank you gents, seriously.

Sound ►
Justin Greger

Additional Animation ► 
Redminus

Backgrounds ► 
Cole Jordan 

Joe Rogan VO ► 
Ethan Gallardo

Theme Jingle ► 
Tom Ryan

Instagram ►
https://www.instagram.com/flashgitz/

Twitter ►
https://www.twitter.com/flashgitzanims
https://www.twitter.com/flashgitztom
https://www.twitter.com/flashgitzdon

Discord ►
https://discord.gg/b5ekXbK

