# Source:Joshua Fluke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-91UA-Xy2Cvb98deRXuggA, language:en-US

## Corporate Cringe - INTERNATIONAL TEAM BUILDING | #indonesia #germany #india #uk
 - [https://www.youtube.com/watch?v=VjH9aC7sYro](https://www.youtube.com/watch?v=VjH9aC7sYro)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-91UA-Xy2Cvb98deRXuggA
 - date published: 2020-07-05 00:00:00+00:00

❤️ Support me because corporate sponsors rarely do! 
 https://www.patreon.com/joshuafluke

🔥 Need a resume/cover letter? Check out my templates!  
https://grindreel.com/

👊 Join the community! 
https://discord.gg/Joshuafluke

My Other Socials🤳
https://www.tiktok.com/@joshua_fluke
https://www.instagram.com/joshuafluke/  📸
https://twitter.com/joshuafluke  🐦

📧 Email me directly!: grindreel@gmail.com
📧 Business inquiries: Joshuafluke@thoughtleaders.io  

My Gear ⚙️:  https://kit.co/JoshuaFluke

## real interview questions with subscribers! | #grindreel
 - [https://www.youtube.com/watch?v=Q84PHteJ86U](https://www.youtube.com/watch?v=Q84PHteJ86U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-91UA-Xy2Cvb98deRXuggA
 - date published: 2020-07-04 00:00:00+00:00

❤️ Support me because corporate sponsors rarely do! 
 https://www.patreon.com/joshuafluke

🔥 Need a resume/cover letter? Check out my templates!  
https://grindreel.com/

👊 Join the community! 
https://discord.gg/Joshuafluke

My Other Socials🤳
https://www.tiktok.com/@joshua_fluke
https://www.instagram.com/joshuafluke/  📸
https://twitter.com/joshuafluke  🐦

📧 Email me directly!: grindreel@gmail.com
📧 Business inquiries: Joshuafluke@thoughtleaders.io  

My Gear ⚙️:  https://kit.co/JoshuaFluke

