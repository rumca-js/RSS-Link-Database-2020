# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## How Well Do Masks Work?  (Schlieren Imaging In Slow Motion!)
 - [https://www.youtube.com/watch?v=0Tp0zB904Mc](https://www.youtube.com/watch?v=0Tp0zB904Mc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2020-07-04 00:00:00+00:00

PBS Member Stations rely on viewers like you. To support your local station, go to: http://to.pbs.org/DonateOKAY
↓ More info and sources below ↓

We're on PATREON! Join the community ►► https://www.patreon.com/itsokaytobesmart
SUBSCRIBE so you don't miss a video! ►► http://bit.ly/iotbs_sub 

Wearing a mask is a cheap and easy way to help stop the spread of airborne infections like COVID-19. It's also a sign that you want to help protect other people and have them protect you… that we're all in this together. Here are some awesome slow-motion schlieren imaging experiments to demonstrate why masks work! Share with someone who needs to see this.

References: https://sites.google.com/view/why-masks-work-references/home 

Special thanks:
Matthew Staymates - National Institute of Standards and Technology
Dr. Richard Davis - Providence Sacred Heart Medical Center (https://twitter.com/richdavisphd/status/1276629360212979712)
Derek Muller - @Veritasium  (https://www.youtube.com/watch?v=4tgOyU34D44)
David McRaney - You Are Not So Smart https://youarenotsosmart.com/

Special thanks to our Brain Trust Patrons:
AlecZero
Diego Lombeida
Dustin
Ernesto Silva
George Gladding
Jay Stephens
Marcus Tuepker
Megan K Bradshaw
Peter Ehrnstrom
Ron Kakar
vincbis

Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/

