# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Coronavirus lockdowns: Where is next after Leicester?
 - [https://www.bbc.co.uk/news/health-53280238](https://www.bbc.co.uk/news/health-53280238)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-07-04 23:59:04+00:00

Trends in recent coronavirus infections suggest Leicester is very different from the rest of the UK.

## Coronavirus: Before and after portraits of haircuts as hairdressers reopen
 - [https://www.bbc.co.uk/news/in-pictures-53290746](https://www.bbc.co.uk/news/in-pictures-53290746)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-07-04 23:58:07+00:00

Before and after portraits as the people of Coventry visit the salon for the first time in three months

## The Grand Old Man of India who became Britain's first Asian MP
 - [https://www.bbc.co.uk/news/world-asia-india-52829458](https://www.bbc.co.uk/news/world-asia-india-52829458)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-07-04 23:55:32+00:00

Indian-born Dadabhai Naoroji was the first Asian to sit in the House of Commons.

## 'Why I've used skin-whitening products'
 - [https://www.bbc.co.uk/news/newsbeat-53275734](https://www.bbc.co.uk/news/newsbeat-53275734)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-07-04 23:40:03+00:00

Radio 1 Newsbeat ask people from South Asian backgrounds about using of skin-lightening products.

## Coronavirus: How deportation staff became food bank volunteers
 - [https://www.bbc.co.uk/news/uk-53283350](https://www.bbc.co.uk/news/uk-53283350)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-07-04 23:09:58+00:00

People who usually assist with airport deportations have been helping feed those affected by the Covid-19 lockdown.

## Coronavirus: Why Singapore turned to wearable contact-tracing tech
 - [https://www.bbc.co.uk/news/technology-53146360](https://www.bbc.co.uk/news/technology-53146360)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-07-04 23:01:31+00:00

The TraceTogether Token is designed to make an app more effective, but worries privacy campaigners.

## Coronavirus: The story of a socially distant wedding
 - [https://www.bbc.co.uk/news/uk-53287932](https://www.bbc.co.uk/news/uk-53287932)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-07-04 22:57:12+00:00

Beth Johnson and Phil Hobbs had to scale down their wedding day because of coronavirus restrictions.

## Man Utd: Mason Greenwood, Marcus Rashford and Anthony Martial's rise to form
 - [https://www.bbc.co.uk/sport/football/53294743](https://www.bbc.co.uk/sport/football/53294743)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-07-04 22:24:51+00:00

Manchester United's front three of Anthony Martial, Marcus Rashford and Mason Greenwood have 55 goals between them. How good are they?

## Coronavirus: UK PM's father says he hopes for 'air bridge' with Greece
 - [https://www.bbc.co.uk/news/uk-53292142](https://www.bbc.co.uk/news/uk-53292142)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-07-04 18:47:05+00:00

Boris Johnson's father Stanley has defended his trip to Greece, which critics said broke lockdown rules.

