# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Is Modern Man Stupid Enough To Remake The Princess Bride?
 - [https://www.youtube.com/watch?v=Fw39x67rmyQ](https://www.youtube.com/watch?v=Fw39x67rmyQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-07-04 00:00:00+00:00

Kyle and Ethan ask the question we’re all wondering... would modern man *really* be stupid enough to remake the best movie of all time, The Princess Bride?

