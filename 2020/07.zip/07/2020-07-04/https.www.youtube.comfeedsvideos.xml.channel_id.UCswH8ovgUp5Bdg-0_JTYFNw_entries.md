# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## A Theory On Consciousness That Could Change EVERYTHING!
 - [https://www.youtube.com/watch?v=KELApiVxLhI](https://www.youtube.com/watch?v=KELApiVxLhI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-07-05 00:00:00+00:00

I spoke with Dr. Philip Goff this week on my podcast Under The Skin, he is an expert in Panpyschism.
If you want to listen to it you can on Luminary! It's out right now!  http://luminary.link/russell

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

