# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Interview: Jarvis Cocker
 - [https://www.youtube.com/watch?v=XqbezB0y0S0](https://www.youtube.com/watch?v=XqbezB0y0S0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-07-17 00:00:00+00:00

Jarvis Cocker connects with The Current's Jim McGuinn to talk about the new album from Jarv Is..., entitled "Beyond the Pale."
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Lianne La Havas - live virtual session for The Current
 - [https://www.youtube.com/watch?v=XI8guZzhbp8](https://www.youtube.com/watch?v=XI8guZzhbp8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-07-16 00:00:00+00:00

Lianne La Havas joins The Current's Sean McPherson for a Live Virtual Session. La Havas talks about and plays two songs from her 2020 self-titled release, and she also plays a selection from her 2015 release, 'Blood.'

SONGS PERFORMED:
02:50 "Courage"
12:36 "Bittersweet"
25:02 "Green & Gold"

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

