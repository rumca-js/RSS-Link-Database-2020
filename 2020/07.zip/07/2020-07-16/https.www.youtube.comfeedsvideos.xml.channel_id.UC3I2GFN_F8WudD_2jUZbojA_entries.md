# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Western State Hurricanes - Copernicus (Live on KEXP)
 - [https://www.youtube.com/watch?v=26NcuhkW3BY](https://www.youtube.com/watch?v=26NcuhkW3BY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-07-17 00:00:00+00:00

http://KEXP.ORG presents Western State Hurricanes performing “Copernicus” live in the KEXP studio. Recorded February 6, 2020.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
https://www.facebook.com/WesternStateHurricanes

## Western State Hurricanes - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=SUKy4J6gqvs](https://www.youtube.com/watch?v=SUKy4J6gqvs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-07-17 00:00:00+00:00

http://KEXP.ORG presents Western State Hurricanes performing live in the KEXP studio. Recorded February 6, 2020.

Songs:
Through With Love
Copernicus
Unsalted Butter
Medicine Cabinet Pirate

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
https://www.facebook.com/WesternStateHurricanes

## Western State Hurricanes - Medicine Cabinet Pirate (Live on KEXP)
 - [https://www.youtube.com/watch?v=sDUMj4UqwEg](https://www.youtube.com/watch?v=sDUMj4UqwEg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-07-17 00:00:00+00:00

http://KEXP.ORG presents Western State Hurricanes performing “Medicine Cabinet Pirate” live in the KEXP studio. Recorded February 6, 2020.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
https://www.facebook.com/WesternStateHurricanes

## Western State Hurricanes - Through With Love (Live on KEXP)
 - [https://www.youtube.com/watch?v=ZXRl5vsETwc](https://www.youtube.com/watch?v=ZXRl5vsETwc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-07-17 00:00:00+00:00

http://KEXP.ORG presents Western State Hurricanes performing “Through With Love” live in the KEXP studio. Recorded February 6, 2020.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
https://www.facebook.com/WesternStateHurricanes

## Western State Hurricanes - Unsalted Butter (Live on KEXP)
 - [https://www.youtube.com/watch?v=I0zuYMkoSMA](https://www.youtube.com/watch?v=I0zuYMkoSMA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-07-17 00:00:00+00:00

http://KEXP.ORG presents Western State Hurricanes performing “Unsalted Butter” live in the KEXP studio. Recorded February 6, 2020.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
https://www.facebook.com/WesternStateHurricanes

## MAITA (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=Ne3rMttHryM](https://www.youtube.com/watch?v=Ne3rMttHryM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-07-16 00:00:00+00:00

Maria Maita-Keppeler, of Portland band MAITA, shares an exclusive set of songs and joins Morgan live on KEXP on Thursday, July 16, at 3pm PT.

