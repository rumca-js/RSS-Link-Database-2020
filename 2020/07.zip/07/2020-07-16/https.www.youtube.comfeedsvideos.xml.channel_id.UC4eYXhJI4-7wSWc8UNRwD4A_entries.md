# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## Tiny Desk Contest Top Shelf, Episode 6
 - [https://www.youtube.com/watch?v=YXzWPnf6OP0](https://www.youtube.com/watch?v=YXzWPnf6OP0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2020-07-16 00:00:00+00:00

Tiny Desk Contest judge Gina Chavez joins NPR Music's Bob Boilen to share her favorite entries to the 2020 Tiny Desk Contest, supported by @statefarm. Hear about what made Chavez's favorites stand out from the thousands of entries we received this year. 

Artists featured in this episode include:
- Ada Dyer (@theadadyer), “Blood Sugar” https://youtu.be/QzujjwSWfDw 
- Diana Gameros (@DianaGameros), “Amor A Todo” https://youtu.be/qFB-2NRbsIs 
- Rama Gu (@ramagu4ever), “Good Egg” https://youtu.be/yT9z_iu5CkI 
- Danielle Ponder (@daniellepondermusic!), “Poor Man’s Pain” https://youtu.be/KQDO-Lvo2_Y 
- Mikhala Jené (@MikhalaJene), “The Annunciation” https://youtu.be/6FkpbrMqtUg 

You can learn more about the Tiny Desk Contest and watch thousands of entries: https://npr.org/tinydeskcontest

#tinydesk #tinydeskcontest #tinydeskcontesttopshelf

