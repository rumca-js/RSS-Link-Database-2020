# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## OPPO is the fast charging king again!
 - [https://www.youtube.com/watch?v=tCTid2YdyCQ](https://www.youtube.com/watch?v=tCTid2YdyCQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2020-07-17 00:00:00+00:00

0:00 Intro
0:23 Softbank wants to sell ARM
2:28 OPPO 125W charging
5:14 Twitter meltdown



The Friday Checkout - Ep. 6
by TechAltar


[[[ FROM THE VIDEO ]]]:

QUIZ: https://crrowd.com/quiz
SuperVOOC explainer: https://www.youtube.com/watch?v=ODeImrQs3ME
OPPO blog post: https://www.oppo.com/en/newsroom/press/oppo-launches-125w-flash-charge-65w-airvooc-wireless-flash-charge-and-50w-mini-supervooc-charger/

[[[ TECHALTAR LINKS ]]]:

Merch:
http://enthusiast.store

Social media:
https://twitter.com/TechAltar
https://instagram.com/TechAltar
https://facebook.com/TechAltar

If you want to support TechAltar directly:
https://flattr.com/@techaltar

My video gear:
https://kit.co/TechAltar/video-gear

