# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## FAR CRY 6 SCREENSHOTS SHOW OPEN WORLD, FLIGHT SIMULATOR HAS 10 DISCS, & MORE
 - [https://www.youtube.com/watch?v=k40LV8F_aq4](https://www.youtube.com/watch?v=k40LV8F_aq4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-07-17 00:00:00+00:00

Go to http://buyraycon.com/gameranx for 15% off your order! Brought to you buy Raycon.

Far Cry 6 gets some tasty screenshots, Sony talks PS5 DualSense controller, Xbox discontinues the One X in the buildup to Xbox series X, new trailers, and more in a week full of gaming news.

*Jakes twitter: https://twitter.com/jakebaldino 
*Instagram: https://goo.gl/HH6mTW 


Jake's other channel: https://youtu.be/L-PKinqfrRo



 ~~~~STORIES~~~~

Far Cry 6 screenshots
https://twitter.com/hazzadorgamin/status/1282409640731439105?s=21
Giancarlo interview
https://www.hollywoodreporter.com/heat-vision/far-cry-6-giancarlo-esposito-how-portray-a-villain-audiences-love-hate-1302880

Microsoft Flight Sim is 10 discs
https://www.eurogamer.net/articles/2020-07-15-microsoft-flight-simulator-comes-on-10-discs

Geoff PS5 controller thing
https://www.youtube.com/watch?time_continue=1&v=3nMDnRhqSaA&feature=emb_logo


RIP Xbox One X
https://www.theverge.com/2020/7/16/21327330/microsoft-xbox-one-x-s-digital-edition-discontinued
Gamepass and Xcloud merge
https://www.theverge.com/2020/7/16/21326797/microsoft-xcloud-launch-xbox-game-pass-ultimate-free




Ghost of Tsushima launch trailer
https://youtu.be/Vt-8RG1jxzg

LEGO Nintendo: https://youtu.be/CjWdJBG_jIE

Stadia announcements
https://www.vg247.com/2020/07/14/google-stadia-new-games/

Henry Cavill building a PC
https://www.pcgamer.com/watch-henry-cavill-build-a-pc-very-seductively/

No Man’s Sky
https://youtu.be/m01YfJesEqw

Ooblets
https://youtu.be/OB6qo8wls0k



They’re making a game about being a gamer girl
https://twitter.com/Slasher/status/1284144628661460992

## Cyberpunk 2077 vs Code SYN: COMPETITORS?
 - [https://www.youtube.com/watch?v=dUqXRpfhFrg](https://www.youtube.com/watch?v=dUqXRpfhFrg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-07-16 00:00:00+00:00

Cyberpunk 2077 has inspired similar-looking video game projects. Today's example: Code SYN from Tencent.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

