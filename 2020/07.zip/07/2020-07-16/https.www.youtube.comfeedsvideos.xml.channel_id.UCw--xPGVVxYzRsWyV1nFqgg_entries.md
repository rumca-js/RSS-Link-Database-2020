# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Moiraine Was RIGHT!
 - [https://www.youtube.com/watch?v=T__AtKZKvh4](https://www.youtube.com/watch?v=T__AtKZKvh4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-07-17 00:00:00+00:00

I have noticed a surge in Moiraine criticism, and I want to push back against it. IMO this Aes Sedai is the soul of the wheel of time series early on and sacrificed so much for some farm boys. 
Podcast: https://afictionalconversation.podbean.com/
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## Kings of the Wyld: BEFORE YOU READ
 - [https://www.youtube.com/watch?v=wcprT_nabx4](https://www.youtube.com/watch?v=wcprT_nabx4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-07-16 00:00:00+00:00

Before you read Nicholas Eames Kings of the Wyld, here are some things you might like to know!
Check out Kings of the Wyld here: https://amzn.to/3j8Eozi
Podcast: https://afictionalconversation.podbean.com/
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

