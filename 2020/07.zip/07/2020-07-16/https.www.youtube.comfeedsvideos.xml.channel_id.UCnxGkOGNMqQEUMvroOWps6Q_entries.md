# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Are Humans the Product of Alien Experimentation?
 - [https://www.youtube.com/watch?v=NsuL-FrJJy8](https://www.youtube.com/watch?v=NsuL-FrJJy8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-17 00:00:00+00:00

Taken from JRE #1510 w/Jeremy Corbell and George Knapp: https://youtu.be/Hc6pbG4wICA

## George Knapp Presents Joe Rogan With Government Documents on Alien Life
 - [https://www.youtube.com/watch?v=9okZGlOanc4](https://www.youtube.com/watch?v=9okZGlOanc4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-17 00:00:00+00:00

Taken from JRE #1510 w/Jeremy Corbell and George Knapp: https://youtu.be/Hc6pbG4wICA

## How Bob Lazar's Story Changed George Knapp's Thoughts on UFOs
 - [https://www.youtube.com/watch?v=O3MGxd4DHh0](https://www.youtube.com/watch?v=O3MGxd4DHh0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-17 00:00:00+00:00

Taken from JRE #1510 w/Jeremy Corbell and George Knapp:
https://youtu.be/Hc6pbG4wICA

## Is the US Government Reverse Engineering UFOs?
 - [https://www.youtube.com/watch?v=44VWHc1P6Mk](https://www.youtube.com/watch?v=44VWHc1P6Mk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-17 00:00:00+00:00

Taken from JRE #1510 w/Jeremy Corbell and George Knapp: https://youtu.be/Hc6pbG4wICA

## The Mystery of Skinwalker Ranch
 - [https://www.youtube.com/watch?v=khKYVzLn_9Q](https://www.youtube.com/watch?v=khKYVzLn_9Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-17 00:00:00+00:00

Taken from JRE #1510 w/Jeremy Corbell and George Knapp: https://youtu.be/Hc6pbG4wICA

## The Tic-Tac UFO Incident Made The US Government Address UFOs
 - [https://www.youtube.com/watch?v=wv99DGEdS-g](https://www.youtube.com/watch?v=wv99DGEdS-g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-17 00:00:00+00:00

Taken from JRE #1510 w/Jeremy Corbell and George Knapp: https://youtu.be/Hc6pbG4wICA

## Was Area 51 Home to a Live Extraterrestrial?
 - [https://www.youtube.com/watch?v=8FQnG5pK4nw](https://www.youtube.com/watch?v=8FQnG5pK4nw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-17 00:00:00+00:00

Taken from JRE #1510 w/Jeremy Corbell and George Knapp: https://youtu.be/Hc6pbG4wICA

## Should Children Experiencing Gender Dysphoria Get Hormone Blockers?
 - [https://www.youtube.com/watch?v=s8YjbzZ7AzE](https://www.youtube.com/watch?v=s8YjbzZ7AzE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-16 00:00:00+00:00

Taken from JRE #1509 w/Abigail Shrier: https://youtu.be/Xagiz8s-h34

## The Dangers of Giving Hormones to Kids with Gender Dysphoria
 - [https://www.youtube.com/watch?v=SUPHqTkL5Nw](https://www.youtube.com/watch?v=SUPHqTkL5Nw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-16 00:00:00+00:00

Taken from JRE #1509 w/Abigail Shrier:
https://youtu.be/CtftWcgXjdg

## Why Abigail Shrier Took on the Transgender Craze Amongst Teenage Girls
 - [https://www.youtube.com/watch?v=6MYb0rBDYvs](https://www.youtube.com/watch?v=6MYb0rBDYvs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-16 00:00:00+00:00

Taken from JRE #1509 w/Abigail Shrier:
https://youtu.be/CtftWcgXjdg

