# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Bully Culture, Bible Adventures, And Boogaloo Skunks
 - [https://www.youtube.com/watch?v=AFscgGZhUUs](https://www.youtube.com/watch?v=AFscgGZhUUs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-07-17 00:00:00+00:00

Today on The Babylon Bee Podcast, Kyle and Ethan talk about the week’s big stories like Christian knockoffs of secular products being bad, people on the right side of history who are on the wrong side of God, boogaloo skunks, and how our current culture is just the free market of people's fists meeting other people's faces.

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Gain Access to the Exclusive Content and Writing Forum: https://babylonbee.com/plans

The Official Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

## Democrats Call For Labels Warning Consumers If A Company's CEO Voted For Trump
 - [https://www.youtube.com/watch?v=W6aQK0yp6JI](https://www.youtube.com/watch?v=W6aQK0yp6JI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-07-17 00:00:00+00:00

The new law would force CEOs who voted for Trump to disclose this important nutritional information on all the company's products. 

https://babylonbee.com/news/dems-call-for-labels-warning-consumers-if-a-companys-ceo-voted-for-trump

## Are You in The Woke Cult?
 - [https://www.youtube.com/watch?v=GGKug2duCSs](https://www.youtube.com/watch?v=GGKug2duCSs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-07-16 00:00:00+00:00

Are you in a woke cult? Kyle and Ethan discuss with James Lindsay how “being woke” looks a lot like being in a cult in 2020.

FULL ▶️  https://youtu.be/5arM0Hk63O0

## Everybody Is A Secret Racist
 - [https://www.youtube.com/watch?v=ORXWEVNoRNo](https://www.youtube.com/watch?v=ORXWEVNoRNo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-07-16 00:00:00+00:00

James Lindsay joins Kyle and Ethan to discuss the differences between white and brown fragility and how everyone is apparently racist.

FULL ▶️  https://youtu.be/5arM0Hk63O0

