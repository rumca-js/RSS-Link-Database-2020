# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Whistleblower Reveals Fake Degree Epidemic in the Middle East, India and Dubai
 - [https://www.youtube.com/watch?v=7Y1YIyXEDQc](https://www.youtube.com/watch?v=7Y1YIyXEDQc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-07-17 00:00:00+00:00

Loy Machedo has a crazy story to tell. He found himself in the UAE with not many options and ended up being employed by a massive organization pumping out fake degrees.
Loy Machedo's Youtube Channel - https://www.youtube.com/user/loymachedodotcom

Articles about fake degrees: 
https://gulfnews.com/uae/crime/exposed-vps-ceos-with-fake-degrees-in-uae-1.1522897
https://gulfnews.com/uae/education/143-fake-degrees-detected-last-year-1.61766833
https://gulfnews.com/uae/fake-degree-holders-get-fake-calls-1.2158749
https://gulfnews.com/uae/education/engineer-challenges-degree-verification-1.261127

