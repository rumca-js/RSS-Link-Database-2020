# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## 12K Cameras are COMING... Are you ready?? - WAN Show July 17, 2020
 - [https://www.youtube.com/watch?v=A_1lGkbIx7M](https://www.youtube.com/watch?v=A_1lGkbIx7M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-07-17 00:00:00+00:00

Save 10% at Ridge Wallet with offer code LINUS at https://www.ridge.com/Linus 

Get a 15-day free trial for unlimited backup at https://backblaze.com/WAN

Sign up for Private Internet Access VPN at https://lmg.gg/piawan 

Buy an LTT shirt, hoodie, hat, and even our own water bottle at https://lmg.gg/wanlttstore

Check out Carpool Critics, our new movie podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Podcast Download: https://dts.podtrac.com/redirect.mp3/traffic.libsyn.com/secure/linustechtips/12K_Cameras_are_COMING..._Are_you_ready_-_WAN_Show_July_17_2020.mp3

Timestamps: (Courtesy of TurtleZero)

0:30 Overview of Topics
1:15 New water bottles (lttstore.com)
2:41 thoughts on Product costs/distribution
4:21 Topics Continued
5:28 Headline Topic - 12k cameras
17:35 MSI allegedly paying people to remove bad reviews
30:45 Sponsors
35:05 Linus talks about his headband
37:30 Mr. Beast ran into some  trouble
40:28 New (12pin) power connector on Nvidia Ampere cards
42:50 New 12v only ATX standard coming from Intel 
44:23 Massive Twitter Hack
47:15 Linus shows a card that his daughter made
47:58 Twitch forces the US Army to stop posting fake giveaways
51:02 Henry Cavill builds a PC
52:31 Talking about 'Gamer Girl'
55:07 Super Chats

## We killed it... but then SUCCESS!!! - Die Lapping Adventure
 - [https://www.youtube.com/watch?v=W9pvsDsDi1Y](https://www.youtube.com/watch?v=W9pvsDsDi1Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-07-16 00:00:00+00:00

Maingear Element 3 (Amazon): https://rebrand.ly/glff52q
Maingear Element 3 (Micro Center): https://rebrand.ly/w86lt2p
Browse Micro Center’s work and learn from home products: https://rebrand.ly/x384fcr

Save 10% and Free Worldwide Shipping at Ridge Wallets by using offer code LINUS at https://www.ridge.com/LINUS

We’re taking Intel’s 9900K and going FULL HARDCORE by delidding and lapping the die with NudeCNC’s NLap tools. Will the chip survive? Watch and find out!

Buy Intel 9900K
On Amazon (PAID LINK): https://geni.us/qEpiUW
On Newegg (PAID LINK): https://geni.us/ygZ9njH
On B&H (PAID LINK): https://geni.us/J2il

Buy Granite Surface Plate
On Amazon (PAID LINK): https://geni.us/SR9hUW9
On Newegg (PAID LINK): https://geni.us/EfLndZ

Buy 3M Sandpaper
On Amazon (PAID LINK): https://geni.us/INXHh
On Newegg (PAID LINK): https://geni.us/Jh3P3F

Buy NudeCNC Lapping tools
https://geni.us/Nlap    

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1222956-you-shouldnt-do-this-delidding-and-lapping-die/


GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Mech Keyboard: https://geni.us/RecNBTI
NEEDforSEAT Gaming Chairs: https://geni.us/needforseat
Get a Displate Metal Print at https://lmg.gg/displateltt
Use code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Gear on Amazon: https://geni.us/lmgamazon
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0 https://lmg.gg/fxHYK 
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://lmg.gg/Q9yyQ 
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://lmg.gg/8upii

