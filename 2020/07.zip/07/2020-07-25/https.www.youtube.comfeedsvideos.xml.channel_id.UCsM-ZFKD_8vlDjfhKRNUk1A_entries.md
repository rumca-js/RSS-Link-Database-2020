# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Kasia Lins - Moja wina - live MUZO.FM
 - [https://www.youtube.com/watch?v=xbm1KsLK0TQ](https://www.youtube.com/watch?v=xbm1KsLK0TQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-07-26 00:00:00+00:00

Kasia Lins na żywo w MUZO.FM. Utwór Moja wina pochodzi z najnowszej płyty Kasi Lins - Moja wina.

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Kasia Lins: http://www.facebook.com/kasialinsofficialpage
Instagram Kasia Lins: http://www.instagram.com/kasialins
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm


Kasia Lins Moja wina tekst

Kiedy wstaję w nocy czuję lęk
- wydaje mi się wtedy, że Twoje ciało to tylko Twój cień.
I ja dobrze wiem co nam zrobiłam.
To moja wina, moja wina, ciężka wina.
Teraz modlę się do siebie:
„Proszę daj mi rozgrzeszenie,
pożądane ukojenie, pożądane ukojenie”.

A Ty stałeś tam na końcu drogi
- tam, gdzie nikt już nie przychodzi.
Wtedy obudziło mnie przeczucie,
że jak pójdę, to już do Ciebie nie wrócę.

Kiedy po raz pierwszy usłyszałam Jego myśli
- nasz koniec był już bliski.
Moja młodość Go przeraża i zachwyca.
Trzyma w rękach niewypał
- myśli, że to trotyl, a to dawno wypalony tytoń everythinginitsrightplace

#popolsku

