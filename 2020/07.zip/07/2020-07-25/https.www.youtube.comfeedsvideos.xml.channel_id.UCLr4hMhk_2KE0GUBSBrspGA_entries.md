# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week: Nie tak szybko! OnePlus Nord, Asus ROG 3, iPhone 2022, Surface DUO, Galaxy Buds Live
 - [https://www.youtube.com/watch?v=i7QblSHqMgY](https://www.youtube.com/watch?v=i7QblSHqMgY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-07-26 00:00:00+00:00

Moje sociale:
insta: http://bit.ly/InstaKlawiatur 
Twitter: http://bit.ly/TTKlawitera
FB: http://bit.ly/FBKlawiatur

Muza z filmów: https://spoti.fi/3fgBNRu

Źródła:
Robot fryzjer: https://bit.ly/3hBC7uJ
OnePlus Nord: https://bit.ly/2CH0icJ
Premiera Norda u Unbox Therapy: https://bit.ly/30MrQVX
Słuchawki OnePlus: https://bit.ly/2ZZIbqX
Asus ROG 3: https://bit.ly/39sNpyR
Peryskopowy Zoom w iPhonie 2022: https://bit.ly/2X14wTo
Chińska rakieta w drodze na Marsa: https://bit.ly/30IrijS
Garmin ma problemy: https://bit.ly/32XFqsm
Strategie TikToka na uniknięcie bana w USA: https://bloom.bg/30IroYM
Surface DUO może już niedługo: https://cnet.co/2WUi82r
Słuchawki Samsung Galaxy Buds Live: https://bit.ly/300nE5A
Wirtualne kibicowanie w NBA: https://bit.ly/32UQJkR



Spis treści:
00:00 Wstęp
00:09 Fryzjer robot
00:40 OnePlus Nord
03:57 Asus ROG 3
05:18 Zoom peryskopowy
05:45 Chińska rakieta leci na Marsa
06:12 Problemy Garmina
07:01 TikTok w Stanach próbuje uniknąć bana
07:59 Surface Duo
08:55 Samsung Galaxy Buds Live
09:28 Przyszłość kibicowania
11:34 Mieszko o Skullcandy Sesh
12:08 W przyszłości słuchawki będą zbędne
12:37 Pożegnanie

