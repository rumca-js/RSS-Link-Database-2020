# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Best of the Week - July 19, 2020 - Joe Rogan Experience
 - [https://www.youtube.com/watch?v=uUSGCtRcXfM](https://www.youtube.com/watch?v=uUSGCtRcXfM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-26 00:00:00+00:00

#1511 w/Oliver Stone:
https://www.youtube.com/watch?v=QOrOYUxzX3o

#1512 w/Ben Shapiro:
https://www.youtube.com/watch?v=hl0iNRXcUbE

#1513 w/Andrew Huberman:
https://www.youtube.com/watch?v=gLJowTOkZVo

#1514 w/Joe De Sena:
https://youtu.be/wCSDF0RNuXY

