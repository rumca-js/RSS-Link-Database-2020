# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Słowo na sobotę - o wracaniu do domu.
 - [https://www.youtube.com/watch?v=Ip8GDvQY3Hw](https://www.youtube.com/watch?v=Ip8GDvQY3Hw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2020-07-25 00:00:00+00:00

📚 MOJA KSIĄŻKA! Wejdź na https://geny.altenberg.pl i zamów swój „Przepis na człowieka”!

Patronite ► https://patronite.pl/NaukowyBelkot 
Mix audio ► http://ratstudios.pl/

Jeżeli coś zaczyna się od pewnego formatu, to wracając do niego po latach nie można nie poruszyć samego tematu wracania - stąd Słowo na sobotę przygląda się w tym odcinku temu jakie mechanizmy wykorzystują zwierzęta, by wracać do domu...

I WAŻNE - część animacji wykonał Adam Myśliwiec ale na śmierć zapomniałem go umieścić w napisach końcowych. Publicznie przepraszam i dziękuję za pomoc.

Subskrypcja ► https://youtube.com/c/UwagaNaukowyBelkot
Facebook ► https://facebook.com/UwagaNaukowyBelkot
Twitter ► https://twitter.com/NaukowyBelkot
Instagram ► https://www.instagram.com/NaukowyBelkot/

Wyłącznie Naukowy Bełkot ► https://goo.gl/Do7VCc
Grupa na facebooku ► https://goo.gl/HP8J83

===
Podziękowania dla Uniwersytetu Mikołaja Kopernika w Toruniu za użyczenie lokacji do nagrań

===
Timestamp:

00:00 Pies Bobby
2:29 Burzyki Pana Lockleya
7:34 (nie?)Prawdziwi nawigatorzy
14:38 W stronę (ukrytego) Słońca
26:34 Zmysłowe kompasy zmysłowe
39:19 Jak ryba w wodzie?
44:44 Noc albo ciemna noc
48:12 Zaburzenia i limity
53:35 Dwa słowa o nas

===
Zdjęcia:

By Martin Reith - Praca własna, CC BY-SA 3.0, https://commons.wikimedia.org/w/index.php?curid=32428354
By Arnold Paul / edited by Waugsberg and Buchling - Praca własna, CC BY-SA 2.0 de, https://commons.wikimedia.org/w/index.php?curid=1219867
By Clara Cartier - Praca własna, CC BY-SA 2.5, https://commons.wikimedia.org/w/index.php?curid=1230204
By dave challender, CC BY-SA 2.0, https://commons.wikimedia.org/w/index.php?curid=9288829

===
Źródła (wybrane):

N. Stryker - Rzecz o ptakach
R. Feynman i in. - Feynmana wykłady z fizyki
T. Kimchi i in. - Magnetic compass orientation in the blind mole rat Spalax ehrenbergi
T. Collet i in. - Animal Navigation: Path Integration, Visual Landmarks and Cognitive Maps
M. Dacke i in. - Animal behaviour: Insect orientation to polarized moonligh
M. Dacke i in. -  Dung Beetles Use the Milky Way for Orientation
G. Horvath i in. - First observation of the fourth neutral polarization point in the atmosphere
G. Horvath i in. - Principal Neutral Points of Atmospheric Polarization
N. Blaser i in. - Altered Orientation and Flight Paths of Pigeons Reared on Gravity Anomalies: A GPS Tracking Study
I. Whishaw i in. - Dead reckoning (path integration) requires the hippocampal formation: evidence from spontaneous exploration and spatial learning tasks in light (allothetic) and dark (idiothetic) tests
C. Gould i in. - Nature's Compass: The Mystery of Animal Navigation
F. De Waal - Are We Smart Enough to Know How Smart Animals Are?
K. Knight - Navigation: from animal behaviour to guiding principles
R. Hegedus i in. - Anomalous celestial polarization caused by forest fire smoke: Why do some insects become visually disoriented under smoky skies?

