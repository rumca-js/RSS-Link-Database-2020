# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## TikTok - China's Best Propaganda Machine
 - [https://www.youtube.com/watch?v=5UooWpC4yJs](https://www.youtube.com/watch?v=5UooWpC4yJs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2020-07-25 00:00:00+00:00

TikTok has earned the hearts of millions, but it has a long record of questionable practices. Accusations of Chinese censorship, discrimination of users and misusing of users' data are among the most severe concerns. 

Join my channel and become a member to enjoy perks https://www.youtube.com/channel/UCjr2bPAyPV7t35MvcgT3W8Q/join
Support me through Patreon: https://www.patreon.com/thehatedone 

- or donate anonymously:

Monero: 84DYxU8rPzQ88SxQqBF6VBNfPU9c5sjDXfTC1wXkgzWJfVMQ9zjAULL6rd11ASRGpxD1w6jQrMtqAGkkqiid5ef7QDroTPp

Bitcoin: 1HkDxXAVDFhBHSyRjam5WW5uoY88sxn5qz


Sources

Tiktok moderation rules https://www.theguardian.com/technology/2019/sep/25/revealed-how-tiktok-censors-videos-that-do-not-please-beijing
https://www.washingtonpost.com/technology/2019/09/15/tiktoks-beijing-roots-fuel-censorship-suspicion-it-builds-huge-us-audience/
https://theintercept.com/2020/03/16/tiktok-app-moderators-users-discrimination/
https://netzpolitik.org/2019/discrimination-tiktok-curbed-reach-for-people-with-disabilities/

Bytedance relationship with the Chinese government: https://foreignpolicy.com/2019/01/16/bytedance-cant-outrun-beijings-shadow/ 
https://www.businessinsider.com/tiktok-parent-company-bytedance-spreads-chinese-propaganda-report-2019-11?


US teenager banned from Tiktok over treatment of Uighurs https://www.theguardian.com/technology/2019/nov/28/tiktok-says-sorry-to-us-teenager-blocked-after-sharing-xinjiang-videos

Class-action lawsuit on data harvesting and transfer https://thediplomat.com/2017/06/chinas-cybersecurity-law-what-you-need-to-know/
https://gdpr.report/news/2019/12/04/privacy-tiktok-found-secretly-transferring-user-data-to-china/

Tiktok security https://www.nytimes.com/2020/01/08/technology/tiktok-security-flaws.html
https://research.checkpoint.com/2020/tik-or-tok-is-tiktok-secure-enough/
https://www.nytimes.com/2019/11/01/technology/tiktok-national-security-review.html
https://www.nytimes.com/2020/07/10/technology/tiktok-amazon-security-risk.html

FTC probe into Tiktok children privacy https://www.nytimes.com/2019/02/27/technology/ftc-tiktok-child-privacy-fine.html
https://www.washingtonpost.com/technology/2019/02/27/us-government-fined-app-now-known-tiktok-million-illegally-collecting-childrens-data/
https://www.cnet.com/news/tiktok-accused-of-secretly-gathering-user-data-and-sending-it-to-china/ 

Critical overview https://international.thenewslens.com/article/134846 

Tiktok privacy policy: https://www.tiktok.com/legal/privacy-policy?lang=en

Tiktok behind Facebook apps on the most downloaded apps worldwide https://sensortower.com/blog/top-apps-games-publishers-2018 
Downlaoded over 2 billion times https://www.theverge.com/2020/4/29/21241788/tiktok-app-download-numbers-update-2-billion-users 
Top 10 most valuable startups https://www.valuewalk.com/2020/04/top-10-most-valuable-startups/ 

Credits
Music by: CO.AG music https://www.youtube.com/channel/UCcavSftXHgxLBWwLDm_bNvA

Follow me:
https://twitter.com/The_HatedOne_
https://www.bitchute.com/TheHatedOne/
https://www.reddit.com/r/thehatedone/
https://www.minds.com/The_HatedOne

The footage and images featured in the video were for critical analysis, commentary and parody, which are protected under the Fair Use laws of the United States Copyright act of 1976.

