# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Talaya. & Brandon Marsalis (Live at Refill)
 - [https://www.youtube.com/watch?v=F48GYizJlOY](https://www.youtube.com/watch?v=F48GYizJlOY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-07-26 00:00:00+00:00

Refill (http://www.refill.live) is a community-driven, live-streamed benefit concert to help raise $25,000 for the Seattle Artist Relief Fund (SARF), a Black-led community response to help provide direct financial support to artists who have been affected by COVID-19.
  
With the global pandemic extending further into the future, artists from Seattle recognized a need for renewed focus and funding to support Seattle artists through SARF. In partnership with SARF, LANGSTON, and KEXP, we present this session with Northwest artists Talaya. and Brandon Marsalis. 

Donate through this video where 100% of your donations go directly to artists in need.
 
https://linktr.ee/talaya.music
https://www.facebook.com/brandon.franklin.509
https://www.langstonseattle.org/sarf
https://www.kexp.org
http://www.refill.live

