# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Bill Murray brings baseball back with a giant teddy bear and style
 - [https://www.cnn.com/videos/entertainment/2020/07/25/bill-murray-chicago-cubs-take-me-out-to-the-ball-game-orig-kj.cnn](https://www.cnn.com/videos/entertainment/2020/07/25/bill-murray-chicago-cubs-take-me-out-to-the-ball-game-orig-kj.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-07-25 20:59:18+00:00

The actor, known for his die-hard Chicago Cubs fandom, gave a comedic rendition of "Take Me Out to the Ball Game" for the Cubs' first 7th inning stretch of the 2020 season.

## Why Fox News cut away from a White House press briefing
 - [https://www.cnn.com/videos/media/2020/07/25/kayleigh-mcenany-fox-news-briefing-violence-perception-reality-commentary-smerconish-vpx.cnn](https://www.cnn.com/videos/media/2020/07/25/kayleigh-mcenany-fox-news-briefing-violence-perception-reality-commentary-smerconish-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-07-25 20:28:23+00:00

White House Press Secretary Kayleigh McEnany played a video so violent that Fox News cut away. And a Trump campaign ad attacking Joe Biden warns of more mayhem. CNN's Michael Smerconish asks is this perception based on reality, or is this just another "summer of the shark"?

## Police review reports of anti-Semitic posts from British rapper
 - [https://www.cnn.com/2020/07/25/entertainment/wiley-grime-artist-police-scli-intl-gbr/index.html](https://www.cnn.com/2020/07/25/entertainment/wiley-grime-artist-police-scli-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-07-25 19:22:19+00:00

Police are reviewing a string of anti-Semitic messages allegedly posted by the British grime musician Wiley on social media.

## Huge black bear spotted relaxing in a pool
 - [https://www.cnn.com/2020/07/25/us/huge-black-bear-in-pool-trnd/index.html](https://www.cnn.com/2020/07/25/us/huge-black-bear-in-pool-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-07-25 18:10:16+00:00

A woman in Virginia was delighted when a large black bear decided to take a nap in a kiddie pool she had in her backyard.

## Spanish footballing great Xavi tests positive for coronavirus
 - [https://www.cnn.com/2020/07/25/football/xavi-coronavirus-football-spt-intl/index.html](https://www.cnn.com/2020/07/25/football/xavi-coronavirus-football-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-07-25 15:18:34+00:00

Xavi, considered one of the greatest midfielders of his generation, has tested positive for the coronavirus but says he is "ok."

## Three storms threaten the US and Caribbean this weekend
 - [https://www.cnn.com/2020/07/25/weather/us-caribbean-hurricane-tropical-storm/index.html](https://www.cnn.com/2020/07/25/weather/us-caribbean-hurricane-tropical-storm/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-07-25 14:50:17+00:00

Three separate storm systems are threatening the United States and the Caribbean this weekend.

## The polls show Biden is a clear favorite 100 days out from an unprecedented election
 - [https://www.cnn.com/2020/07/25/politics/2020-election-100-days-analysis/index.html](https://www.cnn.com/2020/07/25/politics/2020-election-100-days-analysis/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-07-25 14:24:55+00:00

Believe it or not, we're now 100 days and 15 hours from the 2020 election. As we enter the final stretch of the campaign, presumptive Democratic nominee Joe Biden continues to hold an advantage over President Donald Trump in the polls.

## Trump's mind-bending logic on school reopenings
 - [https://www.cnn.com/2020/07/25/politics/donald-trump-schools-reopening-coronavirus/index.html](https://www.cnn.com/2020/07/25/politics/donald-trump-schools-reopening-coronavirus/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-07-25 14:15:34+00:00

As he tried to rescue his reelection campaign this week, President Donald Trump seemed to be in full retreat on key coronavirus topics -- from the efficacy of mask-wearing to the risks of holding the GOP convention in Florida. The one exception was school reopenings, which he has insisted must happen in person this fall.

## Manchester United in nearly-$100 million game against Leicester
 - [https://www.cnn.com/2020/07/25/football/premier-league-football-champions-league-manchester-united-spt-intl-gbr/index.html](https://www.cnn.com/2020/07/25/football/premier-league-football-champions-league-manchester-united-spt-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-07-25 13:45:13+00:00

Manchester United, Chelsea and Leicester City would have likely -- to use the expression -- "bitten your hand off" to be in the position they are now in the English Premier League.

## Why a new generation of Black farmers is getting into the business
 - [https://www.cnn.com/2020/07/25/business/young-black-farmers/index.html](https://www.cnn.com/2020/07/25/business/young-black-farmers/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-07-25 13:43:29+00:00

W. Kamau Bell visits Oklahoma to learn how politics and economic disparity has impacted family and independent farmers. Watch "United Shades of America" Sunday at 10 p.m. ET.

## US agents enter Chinese consulate compound after deadline for closure passed
 - [https://www.cnn.com/2020/07/24/politics/us-agents-houston-chinese-consulate/index.html](https://www.cnn.com/2020/07/24/politics/us-agents-houston-chinese-consulate/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-07-25 13:27:08+00:00

• Singaporean man pleads guilty to spying for China in the US
• Out of seven US consulates, why did China choose Chengdu?

## Sculpture at CIA headquarters holds one of world's most famous unsolved mysteries
 - [https://www.cnn.com/2020/07/25/us/kryptos-secret-message-code-trnd/index.html](https://www.cnn.com/2020/07/25/us/kryptos-secret-message-code-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-07-25 13:13:17+00:00

In the middle of CIA headquarters, there sits a sculpture that contains a secret code that has stumped top cryptologists for decades.

## It's been 2 months since George Floyd's death. Here's what has and hasn't changed.
 - [https://www.cnn.com/2020/07/25/politics/what-matters-july-24/index.html](https://www.cnn.com/2020/07/25/politics/what-matters-july-24/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-07-25 12:37:13+00:00

Saturday will mark two months since George Floyd died at the hands of Minneapolis police officers, igniting a national reckoning over racial injustice and police brutality.

## England and Scotland went separate ways on Covid-19. It may lead to a full divorce.
 - [https://www.cnn.com/2020/07/25/uk/boris-johnson-nicola-sturgeon-coronavirus-approach-gbr-intl/index.html](https://www.cnn.com/2020/07/25/uk/boris-johnson-nicola-sturgeon-coronavirus-approach-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-07-25 10:30:29+00:00

• PM's 'Global Britain' dream turns into nightmare

## US states still set new records for infections and deaths
 - [https://www.cnn.com/collections/intl-us-politics-0722/](https://www.cnn.com/collections/intl-us-politics-0722/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-07-25 09:47:34+00:00



## The pandemic's unlikely pet: Chickens
 - [https://www.cnn.com/2020/07/25/us/pet-chicken-sales-coronavirus-trnd/index.html](https://www.cnn.com/2020/07/25/us/pet-chicken-sales-coronavirus-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-07-25 09:00:59+00:00

At the start of the coronavirus pandemic, the food supply in America was in question. Images of barren grocery store shelves, cleared out meat sections and empty freezer aisles littered the internet.

## Scotland's Covid-19 approach is fueling independence movement
 - [https://www.cnn.com/videos/world/2020/07/24/scotland-independence-covid-19-pandemic-boris-johnson-nicola-sturgeon-robertson-pkg-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2020/07/24/scotland-independence-covid-19-pandemic-boris-johnson-nicola-sturgeon-robertson-pkg-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-07-25 08:19:52+00:00

Boris Johnson's first trip to Scotland since becoming prime minister was intended as an effort to shore up Union ties. But many Scots approve of First Minister Nicola Sturgeon's cautious approach to the coronavirus pandemic, which could have implications for Scotland's independence movement. Nic Robertson reports.

## England and Scotland went separate ways on Covid-19. It may lead to a full divorce.
 - [https://www.cnn.com/collections/intl-uk-0724/](https://www.cnn.com/collections/intl-uk-0724/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-07-25 08:09:19+00:00



## These are some of the 91,000 people who've died since the US reopened
 - [https://www.cnn.com/2020/07/25/health/coronavirus-covid-19-victims-memories-us-reopening-trnd/index.html](https://www.cnn.com/2020/07/25/health/coronavirus-covid-19-victims-memories-us-reopening-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-07-25 08:00:21+00:00

Ninety-one thousand.

## A man using a prosthetic mask stole more than $100,000 at casinos, prosecutors say
 - [https://www.cnn.com/2020/07/25/us/michigan-casino-theft-trnd/index.html](https://www.cnn.com/2020/07/25/us/michigan-casino-theft-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-07-25 06:10:59+00:00

A prosthetic mask, counterfeit driver's licenses, and personal information obtained on the internet. That's how federal authorities say a Michigan man allegedly managed to steal more than $100,000 from casino patrons in Michigan and Kansas.

## Traveling while Asian during the pandemic
 - [https://www.cnn.com/travel/article/asian-travelers-pandemic/index.html](https://www.cnn.com/travel/article/asian-travelers-pandemic/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-07-25 02:13:40+00:00

With a spike in anti-Asian incidents worldwide, CNN Travel talks with Asians who travel for a living to learn how they have been affected by the coronavirus pandemic.

## US agents enter Chinese consulate compound in Houston after deadline for closure passes
 - [https://www.cnn.com/collections/intl-0725-us-china-tension/](https://www.cnn.com/collections/intl-0725-us-china-tension/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-07-25 02:07:10+00:00



## Professional poker player's burned body is found
 - [https://www.cnn.com/videos/us/2020/07/25/susie-zhao-poker-player-found-dead-pkg-vpx.wxyz](https://www.cnn.com/videos/us/2020/07/25/susie-zhao-poker-player-found-dead-pkg-vpx.wxyz)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-07-25 01:08:02+00:00

Police in Michigan have identified the woman whose badly burned body was found in a state recreation area as Susie Zhao, a professional poker player. CNN affiliate WXYZ has the story.

## Google is wading into a market that China really wants to own
 - [https://www.cnn.com/2020/07/24/tech/jio-google-india-china-hnk-intl/index.html](https://www.cnn.com/2020/07/24/tech/jio-google-india-china-hnk-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-07-25 00:25:09+00:00

Google is teaming up with India's hottest tech company to win over new smartphone users. That should worry the Chinese firms who have long dominated the market in the world's second most populous nation.

## Why the Netflix show 'Indian Matchmaking' is causing a stir
 - [https://www.cnn.com/videos/media/2020/07/24/indian-matchmaking-netflix-orig-mss.cnn](https://www.cnn.com/videos/media/2020/07/24/indian-matchmaking-netflix-orig-mss.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-07-25 00:06:13+00:00

The new Netflix series "Indian Matchmaking" brings to light an ancient tradition that is still going on today.

