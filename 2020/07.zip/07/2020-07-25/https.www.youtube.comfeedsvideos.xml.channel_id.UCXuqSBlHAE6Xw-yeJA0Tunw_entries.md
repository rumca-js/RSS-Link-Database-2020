# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Are Walmart's $150 Laptops Shockingly Good... or Shockingly Bad?
 - [https://www.youtube.com/watch?v=jyjMlLmlRV8](https://www.youtube.com/watch?v=jyjMlLmlRV8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-07-26 00:00:00+00:00

Learn more about the MSI MPG B550 GAMING CARBON WIFI at https://geni.us/2u9sFQL

Sign up for Private Internet Access VPN at https://lmg.gg/pialinus1

Do you want more for your money? Or are on a super tight budget? Does Walmart’s EVOO house brand compact laptops bring much in the way of value? WE go over them and definitely find out which one to avoid. Are they worth it for just windows 10 and the Office 365 subscription?

Buy EVOO 11.6" Ultra Thin Laptop
On Walmart.com (PAID LINK): https://geni.us/k31N

Buy EVOO 11.6" Convertible Touchscreen Laptop
On Walmart.com (PAID LINK); https://geni.us/xqhJ

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://lmg.gg/ufmht


GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Mech Keyboard: https://geni.us/RecNBTI
Nerd or Die Stream Overlays & Templates: https://geni.us/s8hBAgR
NEEDforSEAT Gaming Chairs: https://geni.us/needforseat
Get a Displate Metal Print at https://lmg.gg/displateltt
Use code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Gear on Amazon: https://geni.us/lmgamazon
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0 https://lmg.gg/fxHYK 
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://lmg.gg/Q9yyQ 
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://lmg.gg/8upii

## Can we build a better bluetooth speaker? - LG XBOOM Go PL Series
 - [https://www.youtube.com/watch?v=H8GptHQ0W2U](https://www.youtube.com/watch?v=H8GptHQ0W2U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-07-25 00:00:00+00:00

Thanks to the LG #XBOOMGo PL series for sponsoring this video! Check out their new LG #XBOOMGo PL series: ☞(Mobile) https://lgxboom.com/LTT   
☞(Desktop) https://lgxboom.com/LinusTechTips

#XBOOMGo #LGBluetoothspeaker

We built our own bluetooth speaker! Watch to find out how Linus and Matthias did.

Parts List
2x Dayton Audio DMA58-8 2" Dual Magnet Aluminum Cone Full-Range Driver 8 Ohm (AMAZON PAID LINK): https://geni.us/btjd2zo

1x Dayton Audio DC28FS-8 1-1/8" Silk Dome Shielded Tweeter (AMAZON PAID LINK): https://geni.us/Alk11J

1x 10W/15W/20W Stereo bluetooth Amplifier Board 12V/24V Digital Power Amplifier Module XY-P15W (AMAZON PAID LINK): https://geni.us/9QSA

8x SAMSUNG INR18650-30Q BATTERY 15A 3000MAH - FLAT TOP - GENUINE AND TESTED: https://geni.us/HtGC

1x 3PCS/lit Type-c USB 5V 1A 18650 Lithium Battery TP4056 Charger Module Charging Board with Protection Dual Functions 1A Li-ion (AMAZON PAID LINK): https://geni.us/T6CBWR0
Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1226616-can-we-do-it-better-than-the-pros/


GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Mech Keyboard: https://geni.us/RecNBTI
NEEDforSEAT Gaming Chairs: https://geni.us/needforseat
Get a Displate Metal Print at https://lmg.gg/displateltt
Use code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Gear on Amazon: https://geni.us/lmgamazon
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

