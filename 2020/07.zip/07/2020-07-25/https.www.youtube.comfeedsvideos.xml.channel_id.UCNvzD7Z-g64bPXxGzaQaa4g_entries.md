# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Top 10 NEW Games of August 2020
 - [https://www.youtube.com/watch?v=5Tr_3Ot9e0c](https://www.youtube.com/watch?v=5Tr_3Ot9e0c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-07-26 00:00:00+00:00

August 2020 may be light on game releases, but there's still *just* enough worth checking out. Here's what you can play on PC, PS4, Xbox One, and Nintendo Switch.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Windbound 

Platform: PC, PS4, XBOX ONE, Switch

Release date: August 28, 2020



Hellbound 

Platform: PC

Release date: August 4, 2020



Immortal Realms: Vampire Wars 

Platform: PC

Release date: August 28, 2020



A Total War Saga: Troy 

Platform: PC

Release date: August 13, 2020



Project Cars 3 

Platform: PC, PS4, XBO

Release date: August 28, 2020



Horizon Zero Dawn Complete Edition 

Platform: PC

Release date: August 7, 2020



UFC 4                              

Platform: PS4, XBO

Release date: August 14, 2020



Serious Sam 4 

Platform: PC, Stadia

Release date: August 2020, 2020



Wasteland 3 

Platform: PC, PS4, XBO

Release date: August 28, 2020



Microsoft Flight Simulator 

Platform: PC

Release date: August 18, 2020







BONUS



Skully 

Platform: PC, PS4, XBO, Switch

Release date: August 4, 2020





RPG Maker MZ 

Platform: PC

Release date: AUG 20, 2020

## Top 10 NEW Zombie Games of 2020
 - [https://www.youtube.com/watch?v=22fqbw3t4tU](https://www.youtube.com/watch?v=22fqbw3t4tU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-07-26 00:00:00+00:00

We all love zombies in video games...here's a list of new and upcoming zombie games for PC, PS4, and Xbox One in 2020.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Disclaimer: Dying Light 2 has probably been delayed to 2021.

#10. The Last Stand: Aftermath

Platform: PC

Release Date: TBA 2020



#9. Walking Dead Onslaught

Platform: PC PS4

Release date: TBA 2020



#8. Rainbow Six Siege Quarantine

Platform: PC PS4 PS5 XBOX ONE Xbox Series X

Release date: TBA 2020



#7 Zombie Army 4: Dead War

Platform: PC PS4 XBOX ONE Stadia

Release date: 4 February 2020



#6 State of Decay 2: Juggernaut Edition 

Platform: PC Xbox One

Release date: 13 Mar, 2020



#5 ZomDay 

Platform: PC

Release date: 27 Mar, 2020



#4 Undying

Platform: PC PS4 XBOX ONE

Release date: Q3 2020



#3 Dead Matter

Platform: PC

Release Date: 2020



#2 Resident Evil 3: Nemesis Remake

Platform: PC PS4 XBOX ONE

Release date: April 3, 2020



#1 The Walking Dead: Saints & Sinners 

Platform: PC January 23, 2020

Release date: PS VR May 5, 2020

## 10 Most EPIC Boss Deaths in Video Games
 - [https://www.youtube.com/watch?v=XVKYboUlMvQ](https://www.youtube.com/watch?v=XVKYboUlMvQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-07-25 00:00:00+00:00

Some video game bosses really go out in style. Here are some of our favorite crazy boss death moments.
 Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1
Thumb:  https://villains.fandom.com/wiki/Yevgeny_Borisovitch_Volgin?file=MGS-Pachislot-Volgin.png

