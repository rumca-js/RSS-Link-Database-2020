# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## it's time to get political...
 - [https://www.youtube.com/watch?v=jZXxCmHsqdY](https://www.youtube.com/watch?v=jZXxCmHsqdY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-07-25 00:00:00+00:00

AND IT'S TIME TO STAND UP FOR SOMETHING THAT MATTERS! 

Poll: 62% of Americans Say They Have Political Views They’re Afraid to Share
https://www.cato.org/publications/survey-reports/poll-62-americans-say-they-have-political-views-theyre-afraid-share?&utm_source=twitter&utm_medium=social-media&utm_campaign=addtoany

Keeping Your Mouth Shut: Spiraling Self-Censorship in the United States
https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3647099

#coffeezilla #courage #standupforsomethingthatmatters

