# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Rhythm Of War Sneak Peek⚔️ r/Fantasy Best SFF Of the Decade🏆 Wheel of Time Casting☸️ - FANTASY NEWS
 - [https://www.youtube.com/watch?v=o2Ja-6OS7RA](https://www.youtube.com/watch?v=o2Ja-6OS7RA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-07-25 00:00:00+00:00

IT’S FANTASY NEWS DAY!
Snobby Tolkien Shirt: https://teespring.com/snobby-tolkien?pid=823&cid=103683

Podcast: https://afictionalconversation.podbean.com/
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

NEWS: 

Wheel of Time Casting: https://twitter.com/wotonprime/status/1285994561588703232?s=12

New Mutants New Footage: https://www.youtube.com/watch?v=e-6FGEOTTeU

New Halo (Open World): https://www.youtube.com/watch?v=HZtc5-syeAk

#RhythmOfWar Chapter 1 and Prologue: https://www.tor.com/2020/07/23/read-rhythm-of-war-by-brandon-sanderson-prologue-and-chapter-one/

The Boys Season 2 Clip: https://www.youtube.com/watch?v=bkZEPgBqAu8
The Bays Season 3: https://twitter.com/therealKripke/status/1286432768113532928

Head Wounds: https://screenrant.com/oscar-isaac-head-wounds-sparrow-graphic-novel/

Star Wars/Avatar Pushed Back: https://variety.com/2020/film/box-office/star-wars-films-avatar-sequels-pushed-back-a-year-in-disney-release-calendar-shakeup-1234715104/

#HIsDarkMarterials: https://www.youtube.com/watch?v=FnFsU7SY0Gk

Everwild: https://www.youtube.com/watch?v=_In3BHb3tdc

Wizards Trailer: https://www.youtube.com/watch?v=6adVDTR79n4

Fable Announcement: https://www.youtube.com/watch?v=oVkSZXPklQ4

Paper Girls: https://variety.com/2020/tv/news/paper-girls-series-series-amazon-1234714594/

Fire Cannot Kill A Dragon: https://ew.com/books/game-of-thrones-fire-cannot-kill-a-dragon-james-hibberd/

Walking Dead Delux Edition: https://www.comingsoon.net/comics/news/1142473-the-walking-dead-comics-to-re-release-in-deluxe-color-edition

Legend of Korra Netflix: https://twitter.com/DiscussingFilm/status/1285606443509481472

GoT Behind the Scenes: https://ew.com/books/game-of-thrones-fire-cannot-kill-a-dragon-james-hibberd/

