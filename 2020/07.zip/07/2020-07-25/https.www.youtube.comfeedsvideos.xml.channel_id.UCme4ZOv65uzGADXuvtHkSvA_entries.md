# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Historie Potłuczone [#04] O Adamie, dwóch Ahmedach i tirowcu zawodowcu
 - [https://www.youtube.com/watch?v=AteDl2YKyU0](https://www.youtube.com/watch?v=AteDl2YKyU0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-07-26 00:00:00+00:00

@Langustanapalmie   #historiepotłuczone #podcast
________________________________________
Historie potłuczone to opowieści o córkach i synach Boga, pięknych i brzydkich, świętych i grzesznych, szczęśliwych i na skraju rozpaczy. To opowieści o drodze, którą idzie się do nieba i o zakrętach i chaszczach, które spychają do piekła. To opowieści o ludziach po prostu. Czyli o nas.

Muzyka: Kai Engel: Brand New World, http://freemusicarchive.org/music/Kai_Engel/

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

♫ Słuchaj jako PODCAST Langusty: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
iTunes → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWHx


Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Mocno Stronniczy [#04] Chcemy mieć dzieci
 - [https://www.youtube.com/watch?v=A_T-Ncgjl1Y](https://www.youtube.com/watch?v=A_T-Ncgjl1Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-07-26 00:00:00+00:00

@STREFAWODZA @Langustanapalmie 

Takich dwóch, jak Ci to nie ma :) Zapraszamy co niedzielę o godz: 10:oo na premierę zupełnie niesłychanej serii ojców Tomasza Nowaka OP i Adama Szustaka OP.
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

♫ Słuchaj jako PODCAST Langusty: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/histori...
Spotify → https://spoti.fi/2NVIRHb
iTunes → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWHx

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#191] Jak zbudować jedność w Kościele?
 - [https://www.youtube.com/watch?v=mbxcIiJ33QQ](https://www.youtube.com/watch?v=mbxcIiJ33QQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-07-25 00:00:00+00:00

#cnn #kazaniedookienka @Langustanapalmie 

Kazanie XVII Niedzielę zwykłą, Rok A

1. czytanie (1 Krl 3, 5. 7-12)

W Gibeonie Pan ukazał się Salomonowi w nocy, we śnie. Wtedy Bóg rzekł: «Proś o to, co mam ci dać». A Salomon odrzekł: «O Panie, Boże mój, Ty ustanowiłeś królem Twego sługę w miejsce Dawida, mego ojca, a ja jestem bardzo młody i nie umiem rządzić. Ponadto Twój sługa jest pośród Twego ludu, który wybrałeś, ludu mnogiego, którego nie da się zliczyć ani też spisać z powodu jego mnóstwa. Racz więc dać Twemu słudze serce rozumne do sądzenia Twego ludu i rozróżniania dobra od zła, bo któż zdoła sądzić ten lud Twój tak liczny?» Spodobało się Panu, że właśnie o to Salomon poprosił. Bóg więc mu powiedział: «Ponieważ poprosiłeś o to, a nie poprosiłeś dla siebie o długie życie ani też o bogactwa, i nie poprosiłeś o zgubę twoich nieprzyjaciół, ale prosiłeś dla siebie o umiejętność rozstrzygania spraw sądowych, oto spełniam twoje pragnienie i daję ci serce mądre i pojętne, takie, że podobnego tobie przed tobą nie było i po tobie nie będzie».

2. czytanie (Rz 8, 28-30)

Bracia: Wiemy, że Bóg z tymi, którzy Go miłują, współdziała we wszystkim dla ich dobra, z tymi, którzy są powołani według Jego zamysłu. Albowiem tych, których przedtem poznał, tych też przeznaczył na to, by się stali na wzór obrazu Jego Syna, aby On był Pierworodnym między wielu braćmi. Tych zaś, których przeznaczył, tych też powołał, a których powołał – tych też usprawiedliwił, a których usprawiedliwił – tych też obdarzył chwałą.

Ewangelia (Mt 13, 44-52)

Jezus opowiedział tłumom taką przypowieść: «Królestwo niebieskie podobne jest do skarbu ukrytego w roli. Znalazł go pewien człowiek i ukrył ponownie. Uradowany poszedł, sprzedał wszystko, co miał, i kupił tę rolę. Dalej, podobne jest królestwo niebieskie do kupca poszukującego pięknych pereł. Gdy znalazł jedną drogocenną perłę, poszedł, sprzedał wszystko, co miał, i kupił ją». «Dalej, podobne jest królestwo niebieskie do sieci, zarzuconej w morze i zagarniającej ryby wszelkiego rodzaju. Gdy się napełniła, wyciągnęli ją na brzeg i usiadłszy, dobre zebrali w naczynia, a złe odrzucili. Tak będzie przy końcu świata: wyjdą aniołowie, wyłączą złych spośród sprawiedliwych i wrzucą ich w piec rozpalony; tam będzie płacz i zgrzytanie zębów. Zrozumieliście to wszystko?» Odpowiedzieli Mu: «Tak». A On rzekł do nich: «Dlatego każdy uczony w Piśmie, który stał się uczniem królestwa niebieskiego, podobny jest do ojca rodziny, który ze swego skarbca wydobywa rzeczy nowe i stare».
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

♫ Słuchaj jako PODCAST Langusty: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
iTunes → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWHx

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Miriam [#46] Królowa pokoju
 - [https://www.youtube.com/watch?v=L8wmyu-lhAA](https://www.youtube.com/watch?v=L8wmyu-lhAA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-07-25 00:00:00+00:00

#Miriam #litanialoretańska @Langustanapalmie 
________________________________________
Komentarze do wezwań Litanii Loretańskiej. 

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#566] Humbaki
 - [https://www.youtube.com/watch?v=5qj_7Ov-trI](https://www.youtube.com/watch?v=5qj_7Ov-trI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-07-25 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał  
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Słuchaj podcastów langusty: 
→ https://anchor.fm/langusta-na-palmie
→ https://www.spreaker.com/show/histori...
→ https://spoti.fi/2NVIRHb
→ https://apple.co/2ZIPQZv

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

