# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Why Tesla Model Y is Their Most Important Car! [Auto Focus Ep 5]
 - [https://www.youtube.com/watch?v=j52nXdQKFD0](https://www.youtube.com/watch?v=j52nXdQKFD0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-07-25 00:00:00+00:00

Tesla Model Y has arrived and it's Tesla's most important car.

Tesla Model 3 Auto Focus: https://youtu.be/9O5PhuW927w
How Teslas Upgrade Over Time! https://youtu.be/_SoviSNZjso

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track:  http://youtube.com/20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Car provided by Tesla for video.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

