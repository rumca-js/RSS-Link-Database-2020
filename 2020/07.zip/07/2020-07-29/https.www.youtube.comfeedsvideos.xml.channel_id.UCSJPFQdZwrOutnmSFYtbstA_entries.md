# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Watchmen (2009) - Was It Really That Bad?
 - [https://www.youtube.com/watch?v=lyocCkQ_99A](https://www.youtube.com/watch?v=lyocCkQ_99A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-07-30 00:00:00+00:00

So it strikes me that Zack Snyder's Watchmen has taken a lot of criticism over the years, and I think it's time I took a look myself.

