# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## Dr. Becky Smethurst On Being An Astrophysicist, English Accents, And the Cosmological Crisis
 - [https://www.youtube.com/watch?v=bxswbD4kSn4](https://www.youtube.com/watch?v=bxswbD4kSn4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2020-07-30 00:00:00+00:00

I recently sat down with Dr. Becky Smethurst where were talked about the Cosmological Crisis for Monday's video, what it's like to be a super-dope scientist, and make fun of each other's accents.

Check out her channel here:
https://www.youtube.com/channel/UCYNbYGl89UUowy8oXkipC-Q

Here's some time stamps:

Intro - 0:00:00
Dr. Becky Introduction - 0:01:42
The Life Of A Scientist - 0:03:30
Accents - 0:05:15
Misconceptions About Academia - 0:08:05
Why She Loves Studying Black Holes - 0:13:30
White Holes - 0:14:00
Smallest Black Holes - 0:20:00
The Cosmological Crisis - 0:23:00
Geometry of the Universe - 0:38:20
Translating Maths to People - 0:45:14
Why Solving The Cosmological Crisis Matters - 0:49:40
Upcoming Telescopes - 0:54:40
Is There An End To Science? - 0:58:15
Conclusion - 1:03:50

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

