# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 WEIRD Gaming Stories of JULY 2020
 - [https://www.youtube.com/watch?v=pbnXIoQXtUY](https://www.youtube.com/watch?v=pbnXIoQXtUY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-07-30 00:00:00+00:00

July 2020 was a wild month for news, ESPECIALLY in the video game world. Here are some of the craziest stories.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## Halo Infinite vs Halo 5: BIGGEST CHANGES [4K VIDEO]
 - [https://www.youtube.com/watch?v=5YdmOfRaJCE](https://www.youtube.com/watch?v=5YdmOfRaJCE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-07-30 00:00:00+00:00

We finally have substantial news and information about Halo Infinite, so we decided to take a look at Halo 5 and figure out what exactly is new.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 10 Old Gaming Hacks That Are NOW EXTINCT
 - [https://www.youtube.com/watch?v=1akzc_Z_eNg](https://www.youtube.com/watch?v=1akzc_Z_eNg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-07-29 00:00:00+00:00

Some fun classic video game hardware/software tricks just don't work anymore. Here's a fun trip down memory lane.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## Destroy All Humans - Before You Buy
 - [https://www.youtube.com/watch?v=rLCsmPxaCCs](https://www.youtube.com/watch?v=rLCsmPxaCCs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-07-29 00:00:00+00:00

Destroy All Humans (2020, PC, PS4, Xbox One) returns with a beautiful new version of the original cult classic. How does this strange game hold up? Let’s talk.
Subscribe for more: http://youtube.com/gameranxtv ▼▼


Buy Destroy All Humans: https://amzn.to/30X1D6Z



Watch more 'Before You Buy': https://bit.ly/2kfdxI6

