# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## WHEN U DON'T USE INTERNET 4 A WEEK!
 - [https://www.youtube.com/watch?v=GxrEW68LGZ8](https://www.youtube.com/watch?v=GxrEW68LGZ8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-07-30 00:00:00+00:00

I went a week without using the internet at all and ascended past the mortal plane.

When I lived without internet for 2 years:
https://www.youtube.com/watch?v=kiMcX3Fa2Us

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE: https://lukesmith.xyz/donate 💰😎👌💯
OR affiliate links to things l use:
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://brave.com/luk005 Get the Brave browser.
https://lbry.tv/$/invite/@Luke View my videos on LBRY.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase.

