## Nigel Farage: The UK is housing 48,000 illegal migrants in hotels
 - [https://www.youtube.com/watch?v=Y_rHVBE1bNk](https://www.youtube.com/watch?v=Y_rHVBE1bNk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCm0yTweyAa0PwEIp0l3N_gA
 - date published: 2020-07-30 00:00:00+00:00

Nigel Farage has claimed the government is housing 48,000 illegal migrants in hotels and private accommodation, costing the taxpayer up to £4 billion over the next 10 years.

Speaking with talkRADIO’s Mike Graham, the Brexit Party leader said: “Nobody, and I mean nobody, in our national broadcasters, in our national newspapers has done anything about this story. They all think it’s too difficult, too awkward, too embarrassing.”

