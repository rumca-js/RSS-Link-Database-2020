# Source:Veritasium, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA, language:en-US

## The Launch of Perseverance to Mars
 - [https://www.youtube.com/watch?v=m85qDk849_o](https://www.youtube.com/watch?v=m85qDk849_o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA
 - date published: 2020-07-30 00:00:00+00:00

This was a pretty extraordinary experience - thanks to NASA for inviting me! The Atlas V 541 rocket took off carrying the Perseverance rover and Ingenuity the Mars helicopter at 7:50 am July 30, 2020. They should arrive in about seven months on February 18, 2021

Thumbnail by Fictionalhead https://www.youtube.com/fictionalhead

