# Source:Snazzy Labs, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w, language:en-US

## I'm SHOCKED! $11,000 Mac Pro vs $11,000 PC!
 - [https://www.youtube.com/watch?v=jzT0-t-7-PA](https://www.youtube.com/watch?v=jzT0-t-7-PA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w
 - date published: 2020-07-30 00:00:00+00:00

Is it possible that PC vs Mac goes deeper than just specs? Let's find out!
Use my special link https://www.privateinternetaccess.com/snazzy to get 77% discount and 30-day money-back guarantee!
Buy a MAINGEAR VYBE PC - https://maingear.com/vybe/
Subscribe to zollotech - https://www.youtube.com/user/zollotech

Subscribe to my podcast Flashback! - http://relay.fm/flashback
Follow me on Twitter - http://twitter.com/snazzyq
Follow me on Instagram - http://instagram.com/snazzyq

Snazzy Labs finally answers the question: which is better dollar for dollar? Mac? Or PC? Seems pretty obvious when you compare the Maingear VYBE sporting a 64-core AMD Threadripper 3990X with NVIDIA RTX 2080 Ti against our Mac Pro with a 12-core Intel Xeon W-3235 and Radeon Vega Pro II; however, all of this hubbub about Apple's optimization isn't just B.S. So, how does a Mac perform against a PC when doing tasks you'd find yourself doing on macOS like using Final Cut Pro? Let's find out!

