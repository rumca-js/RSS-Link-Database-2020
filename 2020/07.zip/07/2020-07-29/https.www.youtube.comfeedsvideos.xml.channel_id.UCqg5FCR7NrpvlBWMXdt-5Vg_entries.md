# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Thousand Threads | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=jxTFfHT-aUc](https://www.youtube.com/watch?v=jxTFfHT-aUc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-07-30 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

KC Nwosu reviews Thousand Threads, developed by Seamount. 

Thousand Threads on Steam: https://store.steampowered.com/app/972770/Thousand_Threads/

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Deadly Premonition 2 (Zero Punctuation)
 - [https://www.youtube.com/watch?v=domLxPxQr3g](https://www.youtube.com/watch?v=domLxPxQr3g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-07-29 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

This week on Zero Punctuation, Yahtzee reviews Deadly Premonition 2.

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

#ZeroPunctuation

## Hellpoint | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=DqBcPOyKFmY](https://www.youtube.com/watch?v=DqBcPOyKFmY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-07-29 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Jesse Galena reviews Hellpoint, developed by Cradle Games.

Hellpoint on Steam: https://store.steampowered.com/app/628670/Hellpoint/

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

