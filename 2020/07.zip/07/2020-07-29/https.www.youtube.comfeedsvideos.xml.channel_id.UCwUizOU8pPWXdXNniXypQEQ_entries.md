# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## How to Be a Woke White Person
 - [https://www.youtube.com/watch?v=gHSVjmO4iJY](https://www.youtube.com/watch?v=gHSVjmO4iJY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-07-30 00:00:00+00:00

Get your Magnesium Here - https://MagnesiumBreakthrough.com/JP

Crazy Cat Shirt I Was Wearing - https://amzn.to/310wfos

Ever wonder how to become a woke white person? In this step by step instructional, you’ll slice through social justice warrior school and emerge with a high level degree in woke-ology. You’ll know not only how to get offended by anything, you’ll understand how to accrue woke social justice warrior points by canceling other white people for not taking enough action to heal racism. As a woke white person, you’ll be serving your country well in your integral role in cancel culture.

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

As an Amazon Associate, I earn a small commission from qualifying purchases. Some of the links are affiliate links and if you decide to buy products through them I earn a tiny commission. It costs you nothing but helps support the channel and future videos!

