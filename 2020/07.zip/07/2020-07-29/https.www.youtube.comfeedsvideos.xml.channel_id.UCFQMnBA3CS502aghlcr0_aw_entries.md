# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Man Spends $4 Million COVID Loan On a Lamborghini - PPP CHRONICLES
 - [https://www.youtube.com/watch?v=afoOdeIruDk](https://www.youtube.com/watch?v=afoOdeIruDk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-07-30 00:00:00+00:00

David Hines is a special kind of fraudster. He ripped off the government stimulus PPP loans and used them to buy a Lamborghini Huracan. 
https://www.tampabay.com/news/health/2020/07/28/he-bought-a-lamborghini-after-getting-a-4-million-ppp-loan-now-he-faces-a-fraud-charge/
#PPP #Lamborghini #DavidHines

## Dan Lok Never Owned This $35,000,000 Mansion, Landlord Suing
 - [https://www.youtube.com/watch?v=o_9LeuN0BLk](https://www.youtube.com/watch?v=o_9LeuN0BLk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-07-29 00:00:00+00:00

dan lok rented this house for $35,000 / month.

https://vancouversun.com/news/entrepreneur-sued-for-alleged-failure-to-pay-rent-on-west-vancouver-home

#danlok #highticketcloser #rental

