# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Update, UK, US and Global
 - [https://www.youtube.com/watch?v=C4otDdciULY](https://www.youtube.com/watch?v=C4otDdciULY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2020-07-30 00:00:00+00:00

Global numbers

Cases, 17, 084,446

Deaths, 668,250

Self-isolation

Quarantine

https://www.gov.uk/government/publications/coronavirus-covid-19-how-to-self-isolate-when-you-travel-to-the-uk/coronavirus-covid-19-how-to-self-isolate-when-you-travel-to-the-uk

14 days

After symptoms begin

https://www.telegraph.co.uk/global-health/science-and-disease/coronavirus-news-leicester-second-wave-lockdown-cases/

Self-isolate for 10 days, up from 7 days (England's deputy chief medical officer Professor Jonathan Van-Tam) 
Low but real possibility of infectivity, 7 – 10 days after onset of first symptoms

UK

https://www.ons.gov.uk/peoplepopulationandcommunity/birthsdeathsandmarriages/deaths/articles/comparisonsofallcausemortalitybetweeneuropeancountriesandregions/januarytojune2020

Deaths, 46,046

ONS
Comparisons of all-cause mortality between European countries and regions: January to June 2020

Analysis of Weeks 8 to 24 (week ending 21 February to week ending 12 June) 

England, highest levels of excess mortality in Europe for the period as a whole. 

US

Cases, 4, 447, 648

Deaths, 151, 077

Congressman Louis Gohmert

Often non-mask wearer

I’m asymptomatic, but apparently, I have the Wuhan virus

‘I can’t help but wonder, if by keeping a mask on, and keeping it in place if I might have put some germs, some of the virus on to the mask and breathed it in’

Was not wearing a mask the day before diagnosis

Nancy now mandating masks on the house floor

Fauci (Re-tweet)

When you have a bunch of people spouting something, that isn’t true, the only recourse you have is to be very very clear in presenting the scientific data that essentially contradicts that

CDC, week 29, W/E 18 July

https://www.cdc.gov/coronavirus/2019-ncov/covid-data/covidview/index.html

Overall weekly hospitalization rates increased for past three consecutive weeks

American Indian or Alaska Native, have an age-adjusted hospitalization rate approximately 5.3 times that of whites

Blacks, x 4.7

Hispanics or Latinos, x 4.6

21 states now red zones

100 new cases per week 100,000 people

Idaho
California
Nevada
Utah
Arizona
North Dakota
Wisconsin
Iowa
Missouri
Kansas
Oklahoma
Texas
Arkansas
Louisiana
Tennessee
North Carolina
South Carolina
Mississippi
Alabama
Georgia
Florida

Fauci, also troubling signs in
Ohio
Indiana
Kentucky
Tennessee

Surge, 2 – 3 weeks down the pike

Florida

Record increase in COVID-19 deaths for third day in a row

Cases, + 9,956 = 461,000

Deaths, + 252 = 6,709

 

University of Florida (refuses to confirm)

https://www.medscape.com/viewarticle/934771?src=wnl_edit_tpal&uac=127834AR&impID=2481959&faf=1

Cluster of COVID-19 infections in 17 + 2

Anesthesiology department

Went to a party earlier in July + 20 – 30 others

All now recovering at home

It is not clear whether the residents and fellow worked while infected

Super-spreader event 

Need for personal responsibility



Hajj

https://www.aljazeera.com/news/2020/07/coronavirus-outbreak-accelerating-brazil-live-updates-200729230051532.html

2.5m last year

Saudi government, 1,000 to 10,000

India
Cases, + 52,123 = 1, 582, 028
Deaths, + 775 = 34, 956 

Infections in rural areas are continuing to rise sharply, alarming experts who fear weak healthcare systems there will be unable to cope.

Russia
Cases, + 5,509 = 834,499
Deaths, + 129 = 13,802

Afghanistan

Cases, 36, 543

Deaths, 1, 271

People crowding into markets

Ignoring distancing orders

Rarely wearing masks

Eid al-Adha in Kabul, Afghanistan


Philippines
Cases, 3,954 = 85,486

Deaths, 1, 962





Sweden

Renewed encouragement to work from home when possible

Reducing crowding on public transport

"if our contacts go up again there is a considerable risk of a new spread during the autumn".

Nepal
Mount Everest and others

HK Data
https://data.gov.hk/en-data/dataset/hk-dh-chpsebcddr-novel-infectious-agent

## Covid- 19, European Second Wave
 - [https://www.youtube.com/watch?v=8pDD1RGXH0I](https://www.youtube.com/watch?v=8pDD1RGXH0I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2020-07-29 00:00:00+00:00

I'm hoping not

