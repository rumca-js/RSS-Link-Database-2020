# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Instant Crush | Daft Punk | Pomplamoose
 - [https://www.youtube.com/watch?v=5GRRsZip6-o](https://www.youtube.com/watch?v=5GRRsZip6-o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2020-07-30 00:00:00+00:00

All of our Daft Punk covers are now on one Daft Pomp album. Also there is vinyl. It’s very exciting. Get your limited edition 😎 vinyl at http://pomplamoose.com

 Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

A cover of Instant Crush by Pomplamoose.

CREDITS

Lead Vocals: Nataly Dawn
Keys: Jack Conte & Dave Mackay
Guitar: John Schroeder 
Bass: Nick Campbell
Drums/Percussion: Ben Rose
Background vocals: Loren Battley
Engineer: Tim Sonnefeld 
Assistant Engineer: Tyler Karmen 
Mixing/Mastering: Yianni AP
Producer: Ben Rose
Video Production/Direction: Ricky Chavez
Camera Operators: Merlin Showalter, Brad Davis
Video Editor: Dominic Mercurio

Recorded at 64 Sound in Los Angeles.

