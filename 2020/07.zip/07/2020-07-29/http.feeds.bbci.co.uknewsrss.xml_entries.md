# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## 'Bay of Piglets': A 'bizarre' plot to capture a president
 - [https://www.bbc.co.uk/news/stories-53557235](https://www.bbc.co.uk/news/stories-53557235)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-07-29 23:30:39+00:00

How did exiled Venezuelans and former US Special Forces end up joining what looked from the outset like a suicide mission?

## Coronavirus: The car boot sale that's back on its feet
 - [https://www.bbc.co.uk/news/uk-england-norfolk-53570108](https://www.bbc.co.uk/news/uk-england-norfolk-53570108)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-07-29 12:02:52+00:00

How does a post-lockdown rummage work and what have people made of the changes?

## Coronavirus: Where can I go on holiday? A guide to destinations
 - [https://www.bbc.co.uk/news/uk-53249747](https://www.bbc.co.uk/news/uk-53249747)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-07-29 09:42:14+00:00

As people in the UK get the green light to go abroad again, here's a look at what's in store for travellers.

## Guinness World Record: Women circumnavigate world on tandem bicycle
 - [https://www.bbc.co.uk/news/uk-england-oxfordshire-53567668](https://www.bbc.co.uk/news/uk-england-oxfordshire-53567668)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-07-29 06:29:33+00:00

Cat Dixon and Raz Marsden achieved it in 263 days, beating the record of 281 days.

## 'Fix your bike' website crashes as scheme launches in England
 - [https://www.bbc.co.uk/news/uk-53576008](https://www.bbc.co.uk/news/uk-53576008)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-07-29 00:56:31+00:00

Social media users complain they can't access the government website to get a £50 bike repair voucher.

## Coronavirus: Trump sticks by revoked hydroxychloroquine
 - [https://www.bbc.co.uk/news/world-us-canada-53575964](https://www.bbc.co.uk/news/world-us-canada-53575964)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-07-29 00:50:00+00:00

The president said the drug is only rejected as a Covid-19 treatment because he suggested it.

## International students turn to food banks in lockdown
 - [https://www.bbc.co.uk/news/education-53552831](https://www.bbc.co.uk/news/education-53552831)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-07-29 00:31:28+00:00

Hundreds of international students are unable afford fees, food or rent as funds dry up due to virus.

## Malta: The island hoping to be 2020's festival hotspot
 - [https://www.bbc.co.uk/news/newsbeat-53395609](https://www.bbc.co.uk/news/newsbeat-53395609)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-07-29 00:30:49+00:00

Malta is set to host four festivals over the coming months after British events were cancelled.

## Coronavirus: Business rescue package has 'delayed the inevitable'
 - [https://www.bbc.co.uk/news/uk-53417948](https://www.bbc.co.uk/news/uk-53417948)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-07-29 00:10:46+00:00

Insolvencies slow during lockdown, but experts say the worst is yet to come.

## More free school meals 'would stop diet disaster'
 - [https://www.bbc.co.uk/news/education-53574164](https://www.bbc.co.uk/news/education-53574164)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-07-29 00:03:29+00:00

A national food strategy for England calls for an extension of the scheme to end childhood hunger.

