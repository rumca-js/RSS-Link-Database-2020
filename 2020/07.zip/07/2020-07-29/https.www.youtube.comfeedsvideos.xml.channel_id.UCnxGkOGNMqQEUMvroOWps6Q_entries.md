# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Forensic Psychologist Nancy Panza on the Mental Pressures Police Face
 - [https://www.youtube.com/watch?v=XkbnkcZyOrc](https://www.youtube.com/watch?v=XkbnkcZyOrc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-30 00:00:00+00:00

Taken from JRE #1517 w/Nancy Panza: https://youtu.be/6adKh-LYk3s

## How Do You Prevent Another George Floyd Incident From Happening? Joe Asks a Police Psychologist
 - [https://www.youtube.com/watch?v=0Yr7PLqU1Tc](https://www.youtube.com/watch?v=0Yr7PLqU1Tc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-30 00:00:00+00:00

Taken from JRE #1517 w/Nancy Panza:
https://youtu.be/6adKh-LYk3s

## How Politicians Defunded Mental Health and Left Police Holding the Bag
 - [https://www.youtube.com/watch?v=T91xdIV0zoo](https://www.youtube.com/watch?v=T91xdIV0zoo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-30 00:00:00+00:00

Taken from JRE #1517 w/Nancy Panza: https://youtu.be/6adKh-LYk3s

## Police Psychologist Nancy Panza on Defunding the Police
 - [https://www.youtube.com/watch?v=ub4INKbmf1A](https://www.youtube.com/watch?v=ub4INKbmf1A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-30 00:00:00+00:00

Taken from JRE #1517 w/Nancy Panza:
https://youtu.be/6adKh-LYk3s

## Joe Rogan & Post Malone Talk Aliens and UFOs
 - [https://www.youtube.com/watch?v=hwpYQ-XEV2Q](https://www.youtube.com/watch?v=hwpYQ-XEV2Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-29 00:00:00+00:00

Taken from JRE #1516 w/Post Malone:
https://youtu.be/G42RJ4mKj1k

## Joe Rogan and Post Malone Respond to The Chainsmokers Concert Investigation
 - [https://www.youtube.com/watch?v=Z_UC9gwQCn8](https://www.youtube.com/watch?v=Z_UC9gwQCn8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-29 00:00:00+00:00

Taken from JRE #1516 w/Post Malone: https://youtu.be/G42RJ4mKj1k

## Joe Rogan and Post Malone Tackle Mandatory Mask Ordinances
 - [https://www.youtube.com/watch?v=R38S9Ht0Gc8](https://www.youtube.com/watch?v=R38S9Ht0Gc8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-29 00:00:00+00:00

Taken from JRE #1516 w/Post Malone: https://youtu.be/G42RJ4mKj1k

## Post Malone Explains Why He Moved to Utah
 - [https://www.youtube.com/watch?v=X_LPpTpTPAI](https://www.youtube.com/watch?v=X_LPpTpTPAI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-29 00:00:00+00:00

Taken from JRE #1516 w/Post Malone: https://youtu.be/G42RJ4mKj1k

## Post Malone on Making Music "All of My Ideas Are Kind of Like Mistakes"
 - [https://www.youtube.com/watch?v=bhY_BRgStTU](https://www.youtube.com/watch?v=bhY_BRgStTU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-29 00:00:00+00:00

Taken from #1516 w/Post Malone:
https://youtu.be/G42RJ4mKj1k

