# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Rothfuss’ Editor’s Comments🤦‍♂️ Witcher Spinoff show🐺 Self Publish August Releases📖 -Fantasy News
 - [https://www.youtube.com/watch?v=pQ072ZESM7Q](https://www.youtube.com/watch?v=pQ072ZESM7Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-07-30 00:00:00+00:00

IT BE FANTASY NEWS DAY MY DUDES!
Podcast: https://afictionalconversation.podbean.com/
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

NEWS: 

—

00:31 - Rothfuss Doors Of Stone Controversy: https://winteriscoming.net/2020/07/28/patrick-rothfuss-editor-never-seen-word-the-doors-of-stone/
Original Post: https://bookriot.com/authors-dont-owe-you-books/

04:56 - World Fantasy Awards Finalists: https://www.tor.com/2020/07/27/announcing-the-2020-world-fantasy-award-finalists/

05:57 - Rhythm Of War Chapter 2&3: https://www.tor.com/2020/07/28/read-rhythm-of-war-by-brandon-sanderson-chapters-two-and-three/

06:33 - Witcher Netflix Spinoff: https://www.theverge.com/2020/7/27/21340050/netflix-the-witcher-blood-origin-live-action-prequel-announced

07:51 - Burning God Questions: https://twitter.com/kuangrf/status/1288235146483765249?s=21

08:11 - Open Letter Opposition: https://locusmag.com/2020/07/open-letter-opposing-saudi-arabia-worldcon-bid/

08:51 - LotR VR: https://uploadvr.com/virtual-tolkien-vr-scene/

9:56 - Narnia Video Project: https://www.youtube.com/watch?v=93YDZ6Zht9M&feature=youtu.be

10:28 - Blade Runner: Black Lotus: https://twitter.com/DiscussingFilm/status/1287418049570770950?s=20

11:13 - Back To The Future Ultra 4k: https://www.backtothefuture.com/news/2020/7/27/back-to-the-future-the-ultimate-trilogy-heads-to-4k-ultra-hd-blu-ray-and-dvd

11:49 - Self Published Releases: http://www.robjhayes.co.uk/self-published-fantasy-releases-august-2020/

—

## MALICE 🗡️- REVIEW
 - [https://www.youtube.com/watch?v=kEGg_9pOqlg](https://www.youtube.com/watch?v=kEGg_9pOqlg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-07-29 00:00:00+00:00

My review of Malice, by John Gwynne. The first book in the Faithfull and the Fallen series. 
Check out the book: https://amzn.to/2COXrhU

Podcast: https://afictionalconversation.podbean.com/
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

