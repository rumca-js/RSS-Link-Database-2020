# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## The first person to see germs in human history
 - [https://www.youtube.com/watch?v=KBFoyVmaddA](https://www.youtube.com/watch?v=KBFoyVmaddA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2020-07-30 00:00:00+00:00

*Not historically accurate

