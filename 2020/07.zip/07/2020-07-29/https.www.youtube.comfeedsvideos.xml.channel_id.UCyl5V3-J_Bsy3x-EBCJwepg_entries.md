# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## The Insanity of Safety Obsession
 - [https://www.youtube.com/watch?v=MCMh4dPT7RA](https://www.youtube.com/watch?v=MCMh4dPT7RA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-07-30 00:00:00+00:00

Representative Dan Crenshaw joins Kyle and Ethan to discuss what can be done about the overreaction of the government in the COVID era.

## Duggars Announce Support For Kanye After He Suggests Giving Americans $1 Million Per Baby
 - [https://www.youtube.com/watch?v=0XxEIWbBrUk](https://www.youtube.com/watch?v=0XxEIWbBrUk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-07-29 00:00:00+00:00

The Duggars were concerned about some of Kanye's wackier statements and antics, but at the end of the day, they decided that the ability to make millions of dollars just by doing what they do best -- making babies -- was worth it. "We already got the TV show, and that's pretty swell," said Jim Bob Duggar. "But man -- maybe we could finally build that giant Jello pool I've always wanted."

FULL: https://babylonbee.com/news/duggars-announce-support-for-kanye-after-he-suggests-1-million-per-baby

## Secret Police Snatching Up Portland Rioters?
 - [https://www.youtube.com/watch?v=xcB3LZQ0QFM](https://www.youtube.com/watch?v=xcB3LZQ0QFM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-07-29 00:00:00+00:00

Ethan and Kyle discuss the current unrest in Portland, Oregon and whether or not there is a super-secret camouflaged police grabing citizens.

FULL: https://youtu.be/liDkhKqDKaw

