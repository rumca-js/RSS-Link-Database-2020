# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Air Force One - Movie Review
 - [https://www.youtube.com/watch?v=c1-Bdzf3Nnc](https://www.youtube.com/watch?v=c1-Bdzf3Nnc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-07-30 00:00:00+00:00

Not sure I can even type the description for this movie here without getting flagged, Anyhow, Here's my review for AIR FORCE ONE

