# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## How to Be More Afraid!
 - [https://www.youtube.com/watch?v=lcX9HBG4L34](https://www.youtube.com/watch?v=lcX9HBG4L34)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-07-28 00:00:00+00:00

Grab your LMNT Electrolytes Here - https://drinklmnt.com/jp

The crazy alien shirt I was wearing - https://amzn.to/30YYu6Z

We all love having fear constantly thrown at us. Being afraid is the number one key to being happy. Fear can hold some people back, but constant fear mongering that leaves you unhappy and stuck is something that will accelerate you forward. But most don't know how to deal with fear and overcome it. The best way to overcome fear is to have more of it. Here's how to be more afraid...

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

As an Amazon Associate, I earn a small commission from qualifying purchases. Some of the links are affiliate links and if you decide to buy products through them I earn a tiny commission. It costs you nothing but helps support the channel and future videos!

