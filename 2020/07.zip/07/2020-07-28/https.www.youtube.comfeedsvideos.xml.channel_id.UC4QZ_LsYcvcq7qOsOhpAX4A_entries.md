# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## Worst Phone Failures in History
 - [https://www.youtube.com/watch?v=fMz0KO_9oeg](https://www.youtube.com/watch?v=fMz0KO_9oeg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2020-07-29 00:00:00+00:00

Lets take a look at some of the wild events and bad/ interesting designs in mobile history. 

Music Video for the Closing Song: https://youtu.be/vomjz_kEn6U

Mr. Mobile Series: https://www.youtube.com/watch?v=YOZi-7V11k8&t=50s

--- New Thinking Book written by Dagogo Altraide ---
This book was rated the 9th best technology history book by book authority.
In the book you’ll learn the stories of those who invented the things we use everyday and how it all fits together to form our modern world.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

--- ColdFusion Social Media ---
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusionTV

Sources:

https://www.digitaltrends.com/mobile/craziest-phone-designs/

https://en.wikipedia.org/wiki/N-Gage_(device)

https://www.engadget.com/2011-04-13-kyocera-echo-review.html

https://www.cbsnews.com/news/how-kin-became-microsofts-worst-failure/

https://en.wikipedia.org/wiki/Freedom_251

https://xphone24.com/nokia-n-gage-manual.php

https://www.pocket-lint.com/phones/news/131841-the-weirdest-and-wackiest-mobile-phones-you-won-t-admit-you-owned

https://www.fastcompany.com/90315742/the-20-worst-phones-of-the-century-and-how-they-got-that-way

https://phandroid.com/worst-android-phones/ 

https://joyofandroid.com/worst-smartphones/

https://www.pocket-lint.com/phones/news/131841-the-weirdest-and-wackiest-mobile-phones-you-won-t-admit-you-owned

https://www.youtube.com/watch?v=wgswd4m4sGs

https://youtu.be/efRoTiScl7s

https://www.youtube.com/watch?v=BZl9esYi2KE

https://www.youtube.com/watch?v=8aNT9o6hlT8

//Soundtrack//

Autograf - Future Soup (Ferdinand Weber Remix)

Liam J Hennessy - Viewpoint

Tom Demac & Real Lies - White Flowers

David Keno - Golden Ticket (Original Mix)

Sleepy Fish - Forgot It Was Monday (Original Mix)

Hyphex - Fading Light

DIALS - Paths

Burn Water - Nostalgia Dreams (Unreleased)

» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide

