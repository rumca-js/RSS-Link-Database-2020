## MacKenzie Scott donates $1.7bn since Amazon boss divorce - BBC News
 - [https://www.bbc.co.uk/news/business-53574954](https://www.bbc.co.uk/news/business-53574954)
 - RSS feed: https://www.bbc.co.uk
 - date published: 2020-07-28 08:41:39+00:00

MacKenzie Scott donates $1.7bn since Amazon boss divorce - BBC News

