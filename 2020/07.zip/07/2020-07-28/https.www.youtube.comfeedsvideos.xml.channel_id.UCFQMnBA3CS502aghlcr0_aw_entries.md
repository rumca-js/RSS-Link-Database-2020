# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Dan Lok Never Owned This $35,000,000 Mansion, Landlord Suing
 - [https://www.youtube.com/watch?v=o_9LeuN0BLk](https://www.youtube.com/watch?v=o_9LeuN0BLk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-07-29 00:00:00+00:00

dan lok rented this house for $35,000 / month.

https://vancouversun.com/news/entrepreneur-sued-for-alleged-failure-to-pay-rent-on-west-vancouver-home

#danlok #highticketcloser #rental

