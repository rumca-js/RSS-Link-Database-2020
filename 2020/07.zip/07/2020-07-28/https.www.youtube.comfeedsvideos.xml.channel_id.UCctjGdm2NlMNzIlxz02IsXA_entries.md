# Source:Chris Ray Gun, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCctjGdm2NlMNzIlxz02IsXA, language:en-US

## I'M EXCITED AND CONCERNED! - Halo Infinite
 - [https://www.youtube.com/watch?v=cYpgYqrdXmQ](https://www.youtube.com/watch?v=cYpgYqrdXmQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCctjGdm2NlMNzIlxz02IsXA
 - date published: 2020-07-28 00:00:00+00:00

Video Sponsored by Ridge Wallet: https://www.ridge.com/CHRISRAYGUN Use Code “CHRISRAYGUN” for 10% off your order” 

Don't worry, this isn't a Halo channel now. Just wanted to get this out so we can move on to other things in the near future. Here's what I liked and didn't like about Halo Infinite now that I've had time to digest what I saw. 

SHIRTS ► https://teespring.com/stores/chris-ray-gun
TWITTER ► https://twitter.com/ChrisRGun
FACEBOOK ► http://on.fb.me/15OyE7z
TWITCH ► http://www.twitch.tv/chrisraygun
PATREON ► https://www.patreon.com/ChrisRay
SUBREDDIT ► https://www.reddit.com/r/ChrisRayGun/
SACRED SYMBOLS  ► https://apple.co/2Rqmklc
SECOND CHANNEL ► https://www.youtube.com/channel/UCiNediqB-JC_TjbsB4hJuHA

