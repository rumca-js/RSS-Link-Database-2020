# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## MALICE 🗡️- REVIEW
 - [https://www.youtube.com/watch?v=kEGg_9pOqlg](https://www.youtube.com/watch?v=kEGg_9pOqlg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-07-29 00:00:00+00:00

My review of Malice, by John Gwynne. The first book in the Faithfull and the Fallen series. 
Check out the book: https://amzn.to/2COXrhU

Podcast: https://afictionalconversation.podbean.com/
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## FONDA LEE Talks Developing Jade🟢, Researching Organized Crime🔬, and Fantasy!
 - [https://www.youtube.com/watch?v=VCOHJIg4t0M](https://www.youtube.com/watch?v=VCOHJIg4t0M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-07-28 00:00:00+00:00

My interview with the awesome Fonda Lee! 
Checkout Jade City Here: https://amzn.to/3hIgPM9

Podcast: https://afictionalconversation.podbean.com/
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

