# Source:Vlog Casha, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg, language:pl-PL

## Co dalej ze mną, z kanałem, podróżami?
 - [https://www.youtube.com/watch?v=9Wn6WcJMODw](https://www.youtube.com/watch?v=9Wn6WcJMODw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg
 - date published: 2020-07-29 00:00:00+00:00

🗺️ Ostatnie miesiące bardzo mocno zweryfikowały moje plany na 2020 rok. W dzisiejszym vlogu opowiem Wam o tym, co dalej ze mną, z kanałem oraz z podrózami oraz powspominamy trochę stare, dobre czasy :)

❗ Zostań Patronem kanału! 
https://patronite.pl/vlogcasha

Shoty z drona dzięki uprzejmości @mowikamera :)

💵 Zniżka 144 zł na nocleg z Airbnb: https://bit.ly/2U7dVqY

Vlogi z Kolumbii: https://bit.ly/36tqlhH
🌏 Vlogi z Azji Płd-Wsch: https://bit.ly/2wrM9t2
🇦🇺 Vlogi z Australii: https://bit.ly/2OJWYOy
🇺🇸 Vlogi z życia i podróży w USA: https://bit.ly/2ya73NV
🚙Vlogi z autostopu 2018: https://bit.ly/2NbHzos

▸ Instagram: https://www.instagram.com/vlogcasha
▸ Facebook: https://www.facebook.com/vlogcasha/
▸ "Grupa Casha" na FB: https://bit.ly/2N1a6wX

