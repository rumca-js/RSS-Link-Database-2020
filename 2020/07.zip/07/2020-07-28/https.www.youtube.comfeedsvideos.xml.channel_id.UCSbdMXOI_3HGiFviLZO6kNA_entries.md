# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## The NEW Oculus VR headset is REAL and coming SOON
 - [https://www.youtube.com/watch?v=b3Odb4S-esU](https://www.youtube.com/watch?v=b3Odb4S-esU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-07-28 00:00:00+00:00

Hello and welcome to Tuesday Newsday! Your number one resource for the entiure weeks worth of VR news. This week we have some HUGE leaks regarding the new Oculus headset coming soon, VERY soon to exact. Rumor has it as soon as September 15th, so If I were you i would hold off on any VR headset purchases. The newest leaks have shown that this new headset is VERY real and there is a functioning unit out there right now. That and so much more this week!

Here are my links-
Twitch Stream TODAY!
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill
Ridge Wallet
ridge.com/THRILL + 10% off

Outro music-
https://open.spotify.com/track/3QifigzYiNKYk39TuwhPhJ?si=-9evdFYNTCKP_y9U6QEDsw

TIMESTAMPS:
00:00 intro
00:44 NEW Oculus headset leaks
04:03 The IPD problem SOLVED?
05:50 Release date?
06:34 What I think this is
08:53 MEME BREAK
09:27 New VR glove creator
10:35 Vertigo Remaster
11:21 Blast World
12:08 QOTW
13:01 TWITCH STREAM TODAY + Discord

