# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## 10 Cool Gadgets Under $10!
 - [https://www.youtube.com/watch?v=1XZqvze2T70](https://www.youtube.com/watch?v=1XZqvze2T70)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2020-07-29 00:00:00+00:00

• Protect your financial identity online with Privacy .com by using virtual cards and get $5 off your first purchase at ⇨ http://privacy.com/thiojoe (Sponsored)
⮟ Product Links (Affiliate): ⮟
• Dimming Sheets ➣ https://amzn.to/2X1Bh2v
• Magnet Viewing Paper ➣ https://amzn.to/2X5VNiH
• Antistatic Project Tray ➣ https://amzn.to/30TMmE9
• AmazonBasics USB Extension ➣ https://amzn.to/307le5l
• Aukey Two-Port Charger ➣ https://amzn.to/2X55cXO
• USB to Barrel Adapters Pack ➣ https://amzn.to/30YtKmf
• Microfiber Cloths ➣ https://amzn.to/2X4P60t
• Blue Blocker Glasses ➣ https://amzn.to/2EuvTPh
• Headphone Stand ➣ https://amzn.to/39AXQQJ
• Hook/Loop Roll ➣ https://amzn.to/39zdKLq
• Logitech Webcam Cover ➣ https://amzn.to/3jIn18R
• Magnetic Stud Finder ➣ https://amzn.to/2P0JX4Y

Note: The links above are Amazon affiliate links, which means I'll probably get a small (usually ~1-2%) commission that helps support the channel if you decide to buy the item. The commission does not come out of your pocket, but rather from Amazon's.

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe

⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV

My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

#Gadgets #Tech #ThioJoe

