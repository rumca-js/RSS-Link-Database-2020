# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## China’s Master Plan for World Domination (Mini Documentary)
 - [https://www.youtube.com/watch?v=RU-Y9SnUEQE](https://www.youtube.com/watch?v=RU-Y9SnUEQE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2020-07-29 00:00:00+00:00

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join
Updated refund policy: Email us within your first month of joining and we'll refund you for your first month. There is no refund if you cancel at a later time. 

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
Book: Stealth War: How China Took Over While America's Elite Slept Stealth War: How China Took Over While America's Elite Slept - Robert Spalding
📸 Follow me on IG for a chance to win $1,000: @jaketran // http://bit.ly/jt-ig
Please watch out for fake accounts. I will never message you asking for money or to invest. As of right now, it's spelled exactly like this: @jaketran
👨👦👦 Join the Tran Mafia Family here: https://bit.ly/patreon-jt
💬 Join the community Discord: http://discord.gg/BmK8EnQ

Stuff I use & recommend:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
🏠 The real estate investing course I love & recommend: https://jake.yt/RE
🌐 Most flexible, affordable website hosting: https://jake.yt/bhd
🖥️ Website platform I use & love: https://jake.yt/kd
💽 Editing software I've used for 7+ years: https://jake.yt/ccd
📒 Online bookkeeping software I use& love: https://jake.yt/benchd 
🧾 Best affordable bookkeeping software: https://jake.yt/fbd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd
📚 Get 3 free audiobooks for life: https://amzn.to/2v58PSu
🎥 My video gear, setup, tech, books: https://jake.yt/stored

✉️ Email me: jake@jaketran.io

Subscribe to the backup channel on LBRY, use reward code "jake-cast" for free coin: https://bit.ly/LBRY-jt

📰 Sources & visuals: https://bit.ly/305AU98

-----------------------
You’re the head of China - once one of the greatest empires in the world. But in the late 1800’s and early 1900’s, China was defeated by the British, French, Japan, Russia and was put to shame on the world stage for over 100 years.

Because of all this shame and disgrace, you’ve grown to resent not just the West, but the rest of the East, the North, the South.

We need a new plan of attack, where we don’t have to go head first into America’s greatest strength and our main weakness. No longer “using force to compel” the enemy to your will, but rather by using all means.

Make the West believe that you support free trade and globalization, while systematically taking advantage of it. You tell other countries like the US to say “no!” to protectionism, tariffs. China’s main strategy and advantage over the US is the ability to think in decades and centuries. The US on the other hand has grown weak and comfortable.

China’s economic power is the glue that holds the house of cards together. China has complete control over the economy. All this economic power allows us to move onto other fronts of this new cold war.

Infrastructure is one of the most important aspects of a society. Within China, we’re focused on making our economy completely independent from the outside world, where we’re not dependent on exports or imports.

While we’re making our infrastructure most robust at home, this is where the Belt and Road Initiative, or BRI, comes in.
-----------------------

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2020 Jake Tran. All rights reserved.

Sound:

No Spirit - Feeling Lazy https://open.spotify.com/track/7dTdQfYo8tRp9FgZhfMDop?si=2nkivSxtTyeHdK0kym_MIQ 

DISCLAIMER: These videos are for entertainment purposes only. This is not meant to be financial advice. Please always do your due diligence and never stop learning.

AFFILIATE DISCLOSURE: Some of the links in this video description are affiliate links, meaning, at no additional cost to you, I may earn a commission if you click through and make a purchase and/or opt-in. I only promote products that I 100% believe in.

