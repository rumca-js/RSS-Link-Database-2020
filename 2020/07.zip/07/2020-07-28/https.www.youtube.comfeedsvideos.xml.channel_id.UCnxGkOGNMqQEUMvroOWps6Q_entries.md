# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Joe Rogan & Post Malone Talk Aliens and UFOs
 - [https://www.youtube.com/watch?v=hwpYQ-XEV2Q](https://www.youtube.com/watch?v=hwpYQ-XEV2Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-29 00:00:00+00:00

Taken from JRE #1516 w/Post Malone:
https://youtu.be/G42RJ4mKj1k

## Joe Rogan and Post Malone Respond to The Chainsmokers Concert Investigation
 - [https://www.youtube.com/watch?v=Z_UC9gwQCn8](https://www.youtube.com/watch?v=Z_UC9gwQCn8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-29 00:00:00+00:00

Taken from JRE #1516 w/Post Malone: https://youtu.be/G42RJ4mKj1k

## Joe Rogan and Post Malone Tackle Mandatory Mask Ordinances
 - [https://www.youtube.com/watch?v=R38S9Ht0Gc8](https://www.youtube.com/watch?v=R38S9Ht0Gc8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-29 00:00:00+00:00

Taken from JRE #1516 w/Post Malone: https://youtu.be/G42RJ4mKj1k

## Post Malone Explains Why He Moved to Utah
 - [https://www.youtube.com/watch?v=X_LPpTpTPAI](https://www.youtube.com/watch?v=X_LPpTpTPAI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-29 00:00:00+00:00

Taken from JRE #1516 w/Post Malone: https://youtu.be/G42RJ4mKj1k

## Post Malone on Making Music "All of My Ideas Are Kind of Like Mistakes"
 - [https://www.youtube.com/watch?v=bhY_BRgStTU](https://www.youtube.com/watch?v=bhY_BRgStTU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-29 00:00:00+00:00

Taken from #1516 w/Post Malone:
https://youtu.be/G42RJ4mKj1k

## Dr. Bradley Garrett Got Busted Exploring London’s Forbidden Underworld
 - [https://www.youtube.com/watch?v=ImCCNtdXwdo](https://www.youtube.com/watch?v=ImCCNtdXwdo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-28 00:00:00+00:00

Taken from JRE #1515 w/Dr. Bradley Garrett: https://youtu.be/_kDKAOncclU

## Jim Bakker's Survival Buckets
 - [https://www.youtube.com/watch?v=ZkjEKwkMaUI](https://www.youtube.com/watch?v=ZkjEKwkMaUI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-28 00:00:00+00:00

Taken from JRE #1515 w/Dr. Bradley Garrett:
https://youtu.be/_kDKAOncclU

## The Psychology of Preppers w/Dr. Bradley Garrett
 - [https://www.youtube.com/watch?v=ZYQT7NSt6G0](https://www.youtube.com/watch?v=ZYQT7NSt6G0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-07-28 00:00:00+00:00

Taken from JRE #1515 w/Dr. Bradley Garrett:
https://youtu.be/_kDKAOncclU

