# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Kasia Lins - Kobiety by Bukowski - live MUZO.FM
 - [https://www.youtube.com/watch?v=WMIZtCDL_VQ](https://www.youtube.com/watch?v=WMIZtCDL_VQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-07-28 00:00:00+00:00

Kasia Lins na żywo w MUZO.FM. Utwór Kobiety by Bukowski pochodzi z najnowszej płyty Kasi Lins - Moja wina.

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Kasia Lins: http://www.facebook.com/kasialinsofficialpage
Instagram Kasia Lins: http://www.instagram.com/kasialins
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm


Kasi Lins Kobiety by Bukowski tekst

Wiem, że czego chcesz
O czym nie wiesz, że ja wiem
Przecież drżysz, kiedy widzisz
Jak szaleję za Philipem Rothem

Wiesz, czego chcę
Ja wiem, że mogę mieć
Przecież drżę, kiedy w ręce
Kobiety by Bukowski

Wiem też dobrze, że Ty wiesz
O czym czytam, kiedy chcę Cię mieć

I unoś mnie
Swoją siłą budzisz nagły dreszcz
I patrzysz jak duszę się
Tak zaspokajam głód i pragnienie na Ciebie
A teraz zgadnij, czy mnie masz
Czy to Twój ulubiony sen?

Wiem, czego chcesz
O czym nie wiesz, że ja wiem
To ostatnie tango chcesz tańczyć
Jak z Marią Marlon Brando

Wiesz, czego chcę
Ja wiem, że mogę mieć
Przecież patrzę, jak Lolita
Nabokova i Kubricka

I unoś mnie
Swoją siłą budzisz nagły dreszcz
I patrzysz jak duszę się
Tak zaspokajam głód i pragnienie na Ciebie
A teraz zgadnij, czy mnie masz
Czy to Twój ulubiony sen?

Wiem, że czego chcesz
O czym nie wiesz, że ja wiem
Przecież drżysz, kiedy widzisz
Jak szaleję za Philipem Rothem

Wiesz, czego chcę
Ja wiem, że mogę mieć
Przecież drżę, kiedy w ręce
Kobiety by Bukowski everythinginitsrightplace

#popolsku

