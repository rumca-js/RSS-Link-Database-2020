# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## "Mały-wielki" restart
 - [https://www.youtube.com/watch?v=NQG1lRg2KI0](https://www.youtube.com/watch?v=NQG1lRg2KI0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2020-07-28 00:00:00+00:00

Patronite ► https://patronite.pl/NaukowyBelkot 
Mix audio ► http://ratstudios.pl/

Taki tam mały-wielki restart tego wszystkiego...

Subskrypcja ► https://youtube.com/c/UwagaNaukowyBelkot
Facebook ► https://facebook.com/UwagaNaukowyBelkot
Twitter ► https://twitter.com/NaukowyBelkot
Instagram ► https://www.instagram.com/NaukowyBelkot/

Wyłącznie Naukowy Bełkot ► https://goo.gl/Do7VCc
Grupa na facebooku ► https://goo.gl/HP8J83

