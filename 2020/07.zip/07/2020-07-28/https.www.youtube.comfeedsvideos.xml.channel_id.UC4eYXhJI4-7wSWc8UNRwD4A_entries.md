# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## Lyric Jones: Tiny Desk (Home) Concert
 - [https://www.youtube.com/watch?v=ZzOKewL7m_M](https://www.youtube.com/watch?v=ZzOKewL7m_M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2020-07-29 00:00:00+00:00

The Tiny Desk is working from home for the foreseeable future. Introducing NPR Music's Tiny Desk (home) concerts, bringing you performances from across the country and the world. It's the same spirit — stripped-down sets, an intimate setting — just a different space.

July 29, 2020 | Abby O'Neill -- Lyric Jones is a culturally authentic and classic Bostonian. It's evident through her music and the insightful words she shares between songs that she's got a signature northeastern demeanor and the "true school" flow and lyrical content to match. With that demeanor also comes an unceasing work ethic, and Lyric makes it abundantly clear that her hustle is nonstop – writing, rapping, singing, drumming, engineering, and grinding it out to make Gas Money (the title of her latest album). This quintuple threat, trained in the Berklee College of Music's City Music program, recorded this Tiny Desk (home) concert from her studio in Los Angeles in May. Her multi-layered prowess is present on "Adulting" a song about the evolutionary growth that happens in your late 20s and early 30s. Lyric uses a TC Helicon vocal processor to create percussive beats, looping her voice as a backdrop and packing a punch with vocal harmonies and ad libs. In grappling with the pandemic, Lyric expresses the deep importance of this moment: "Whatever we put out in this time, in this era is a bookmark in history. Especially as musicians. ... For me, my personal testament, I want to be intentional. ... My children's children are gonna know about this time. And I want to know that I impacted it with intentional music, intentional thoughts, insights and perspectives." She is doing just that.

SET LIST
"All Mine"
"Adulting"
"Lush Lux Life"

MUSICIANS
Lyric Jones: vocals, electronics

CREDITS
Video by: Lyric Jones; Audio by: Lyric Jones; Producer: Abby O'Neill; Audio Mastering Engineer: Josh Rogosin; Video Producer: Morgan Noelle Smith; Associate Producer: Bobby Carter; Executive Producer: Lauren Onkey; Senior VP, Programming: Anya Grundmann

## Thao Nguyen: Tiny Desk (Home) Concert
 - [https://www.youtube.com/watch?v=2ooC7TOr5m0](https://www.youtube.com/watch?v=2ooC7TOr5m0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2020-07-28 00:00:00+00:00

The Tiny Desk is working from home for the foreseeable future. Introducing NPR Music's Tiny Desk (home) concerts, bringing you performances from across the country and the world. It's the same spirit — stripped-down sets, an intimate setting — just a different space.

Bob Boilen | July 28, 2020
For her Tiny Desk (home) concert, Thao Nguyen opens with a somber version of "Temple," the dance-oriented title track from Thao & The Get Down Stay Down's new album. The song is an homage to her parents, who were refugees of the Vietnam War. Thao sings from the perspective of her mother, honoring their hard-fought freedom and their hopes that their daughter is blessed with the ability to pursue her own happiness. She recorded it as a trio with cellists (and neighbors) Elisabeth Reed and Andy Luchansky. It's a powerful rendition that celebrates, in Thao's words, "being queer and being out in my career, something that being out publicly has caused a lot of turmoil and unrest in my own life." Please give a listen to what she has to say in this remarkable video. We also hear "Pure Cinema" from Temple and a mandolin version of "Departure" from her 2016 album, A Man Alive.

SET LIST
"Temple"
"Pure Cinema"
"Departure"

MUSICIANS
Thao Nguyen: vocals, guitar, mandolin; Elisabeth Reed: cello; Andy Luchansky: cello

CREDITS
Video by: Molly Skonieczny; Audio by: Thao Nguyen; Producer: Bob Boilen; Audio Mastering Engineer: Josh Rogosin; Video Producer: Maia Stern; Associate Producer: Bobby Carter; Executive Producer: Lauren Onkey; Senior VP, Programming: Anya Grundmann

