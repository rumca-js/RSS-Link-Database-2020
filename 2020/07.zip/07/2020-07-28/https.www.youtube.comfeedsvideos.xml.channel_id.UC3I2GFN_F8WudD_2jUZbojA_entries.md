# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Claudine Magbag (Live at Refill)
 - [https://www.youtube.com/watch?v=Y-9XMbMI_h4](https://www.youtube.com/watch?v=Y-9XMbMI_h4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-07-29 00:00:00+00:00

Refill (http://www.refill.live) is a community-driven, live-streamed benefit concert to help raise $25,000 for the Seattle Artist Relief Fund (SARF), a Black-led community response to help provide direct financial support to artists who have been affected by COVID-19.
  
With the global pandemic extending further into the future, artists from Seattle recognized a need for renewed focus and funding to support Seattle artists through SARF. In partnership with SARF, LANGSTON, and KEXP, we present this session with Northwest artist Claudine Magbag. 

Donate through this video where 100% of your donations go directly to artists in need.
 
https://www.facebook.com/claudinemagbagmusic
https://www.langstonseattle.org/sarf
https://www.kexp.org
http://www.refill.live

## Lonnie Holley (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=6VV_c3ImINY](https://www.youtube.com/watch?v=6VV_c3ImINY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-07-29 00:00:00+00:00

Self-taught musician and visual artist Lonnie Holley steps into The Roadhouse on KEXP with Greg Vandy to share an exclusive set of songs recorded in his hometown in Georgia. Lonnie joins Greg live on Wednesday, July 29, at 3pm PT.

