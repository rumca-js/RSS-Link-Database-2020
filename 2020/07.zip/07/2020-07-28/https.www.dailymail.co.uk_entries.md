## Paedophile Labour councillor who worked in children's home walks free despite being caught with over one million child porn images including 12-year-old girls being raped
 - [https://www.dailymail.co.uk/news/article-8568833/Paedophile-Labour-councillor-worked-childrens-home-walks-free.html](https://www.dailymail.co.uk/news/article-8568833/Paedophile-Labour-councillor-worked-childrens-home-walks-free.html)
 - RSS feed: https://www.dailymail.co.uk
 - date published: 2020-07-28 21:09:04+00:00

Paedophile Labour councillor who worked in children's home walks free despite being caught with over one million child porn images including 12-year-old girls being raped

