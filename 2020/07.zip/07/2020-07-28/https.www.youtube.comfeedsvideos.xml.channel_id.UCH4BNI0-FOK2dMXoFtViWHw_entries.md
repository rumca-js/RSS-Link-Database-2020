# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## Why Is Our Skeleton On the Inside?
 - [https://www.youtube.com/watch?v=JhOU3FOyApM](https://www.youtube.com/watch?v=JhOU3FOyApM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2020-07-28 00:00:00+00:00

PBS Member Stations rely on viewers like you. To support your local station, go to: http://to.pbs.org/DonateOKAY
↓ More info and sources below ↓

We’re on PATREON! Join the community ►► https://www.patreon.com/itsokaytobesmart
SUBSCRIBE so you don’t miss a video! ►► http://bit.ly/iotbs_sub 

Having bones is pretty cool. They make our blood, let us hear, and keep us from being just a squishy puddle on the floor. But for every species with bones, there are at least 20 species on Earth with exoskeletons instead. And those exoskeleton animals are incredibly tough and strong. So why don’t WE have our skeletons on the outside? This is the story of bones!

References: https://sites.google.com/view/why-our-skeletons-on-inside/home 

Special thanks for research assistance:
Riley Black

Special thanks to our Brain Trust Patrons:
AlecZero
Amory Silva
Amy Sowada
Benjamin Teinby
Diego Lombeida
Dustin
Eric Meer
George Gladding
Jay Stephens
Marcus Tuepker
Megan K Bradshaw
Peter Ehrnstrom
vincbis

Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/

