# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Duggars Announce Support For Kanye After He Suggests Giving Americans $1 Million Per Baby
 - [https://www.youtube.com/watch?v=0XxEIWbBrUk](https://www.youtube.com/watch?v=0XxEIWbBrUk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-07-29 00:00:00+00:00

The Duggars were concerned about some of Kanye's wackier statements and antics, but at the end of the day, they decided that the ability to make millions of dollars just by doing what they do best -- making babies -- was worth it. "We already got the TV show, and that's pretty swell," said Jim Bob Duggar. "But man -- maybe we could finally build that giant Jello pool I've always wanted."

FULL: https://babylonbee.com/news/duggars-announce-support-for-kanye-after-he-suggests-1-million-per-baby

## Secret Police Snatching Up Portland Rioters?
 - [https://www.youtube.com/watch?v=xcB3LZQ0QFM](https://www.youtube.com/watch?v=xcB3LZQ0QFM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-07-29 00:00:00+00:00

Ethan and Kyle discuss the current unrest in Portland, Oregon and whether or not there is a super-secret camouflaged police grabing citizens.

FULL: https://youtu.be/liDkhKqDKaw

## Interview Show: Dan Crenshaw Talks Eyepatches/Mob Democracy/Unscientific Lockdowns
 - [https://www.youtube.com/watch?v=liDkhKqDKaw](https://www.youtube.com/watch?v=liDkhKqDKaw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-07-28 00:00:00+00:00

Today on The Babylon Bee Podcast, Kyle and Ethan talk to Representative Dan Crenshaw. He is the representative for Texas’ second congressional district and the author of Fortitude: American Resilience in the Era of Outrage. They discuss the importance of knowing a good eyepatch guy, the difference between a democracy and a republic, and try to decide what was more chaotic: Afghanistan or CHAZ?

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Gain Access to the Exclusive Content and Writing Forum: https://babylonbee.com/plans

The Official Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

