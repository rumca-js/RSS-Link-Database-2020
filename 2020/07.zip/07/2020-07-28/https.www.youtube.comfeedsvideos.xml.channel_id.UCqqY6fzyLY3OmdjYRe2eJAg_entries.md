# Source:Roosevelt, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqqY6fzyLY3OmdjYRe2eJAg, language:en-US

## Roosevelt - Sign (Alex Metric Remix)
 - [https://www.youtube.com/watch?v=eiQWJUSxVXM](https://www.youtube.com/watch?v=eiQWJUSxVXM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqqY6fzyLY3OmdjYRe2eJAg
 - date published: 2020-07-29 00:00:00+00:00

'POLYDANS' - my new album - out now! Stream / Purchase here: https://roosevelt.lnk.to/Polydans

The Alex Metric Remix of 'Sign' Is Out Now - Stream / Purchase here:  https://roosevelt.lnk.to/SignRemix

You can Stream / Purchase the original of 'Sign' here:  https://roosevelt.lnk.to/sign

FOLLOW Roosevelt on Facebook, Instagram and more https://roosevelt.lnk.to/follow
Website : https://roosevelt.lnk.to/website 

This is the Official Youtube Channel for Roosevelt. 
SUBSCRIBE NOW to be kept up to date with the latest music, videos, tour dates, behind the scenes footage and more https://roosevelt.lnk.to/subscribe

Written, Performed, Recorded and Produced by Marius Lauber 
Remixed by Alex Metric at The Batcave, London 
Mastered by Kevin Grainger at Wired Masters 
Artwork by Ohad Ben-Moshe 
Creative Direction by C/O Magick 
P & C Greco-Roman / City Slang 

Slight change in the lyrics as well:

you were slowly moving out of sight

we've been lost calling it a night 

if only you could see me now

trying to make it through it all somehow

 

so come back 

and give me a sign of your love

come back

and give me a sign of your love

 

i remember it all like yesterday

looking back, you won't fade away

i know it won't be like the start

just been wondering when you changed your heart

 

so come back 

and give me a sign of your love

come back

and give me a sign of your love

 

so come back 

and give me a sign of your love

come back

and give me a sign of your love

