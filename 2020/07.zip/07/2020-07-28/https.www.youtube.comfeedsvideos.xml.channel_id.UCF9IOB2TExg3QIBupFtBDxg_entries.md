# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Covid- 19, European Second Wave
 - [https://www.youtube.com/watch?v=8pDD1RGXH0I](https://www.youtube.com/watch?v=8pDD1RGXH0I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2020-07-29 00:00:00+00:00

I'm hoping not

## Coronavirus, Global Update, 29th July
 - [https://www.youtube.com/watch?v=ahWS5RQBJwE](https://www.youtube.com/watch?v=ahWS5RQBJwE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2020-07-28 00:00:00+00:00

US
Cases, 4,225,687 (CDC)
Cases, 4,294,770 (JH)

Tuesday,  21st   63,028
Wednesday 22nd  70,106
Thursday  23rd  72,219
Friday   24th   74,818
Saturday  25th   64,582
Sunday   26th   61,795

Deaths, 148, 056

1,000 deaths per day for past week

Cases increasing in 40 states

30 states require face covering

Dr Birx

https://www.state.gov/biographies/deborah-l-birx-md/

If every mayor could mandate mask wearing

The virus is there, its spreading, it will hit your nursing homes

Texas

Bars open despite mandated closures by Governor

‘Its not a communist country’

ICUs full, over 100%

NJ

700 people at a house party

California

Large Church gathering on the beech

Long beach island

35 lifeguards tested positive after social events

North Korea

25m people

Defector positive

Therefore, NK has one official case

Health care system

Spain

Cases, 272,421

Deaths, 28,343

Deaths ? 60% higher

https://elpais.com/sociedad/2020-07-25/las-44868-muertes-de-la-pandemia-en-espana.html

After 26 July 14 days self-isolation for returning Brits

Self-isolate for two weeks upon return

Advising "against all but essential travel to the whole of Spain"

UK

New cases, + 1, 884

Deaths, 45,844

ONS 

https://www.ons.gov.uk/peoplepopulationandcommunity/birthsdeathsandmarriages/deaths/bulletins/deathsregisteredweeklyinenglandandwalesprovisional/weekending17july2020

Week ending 17 July 2020 (Week 29) England and Wales

Registered deaths = 8,823

3.0% (270 deaths fewer) below 5 year average

5th consecutive week that deaths have been below the five-year average

295 (3.3%) of the 8,823 deaths mentioned "novel coronavirus (COVID-19)"

Sudan

Cases, 11,424

Deaths, 720

20 % + are going hungry

Conflict, rising food prices, coronavirus 

Yemen

Thousands of possible undetected deaths from cholera

January – April, 2020, 110,000 cases of cholera

80% of the population requiring aid

Russia

US, Brazil, India, Russia

Cases, + 5,395 = 823,515

Deaths, + 150 = 13,504.

Germany

Cases, 206,242

Deaths, 9,122

Widespread early testing

Good health care system

Germany has registered an average of 

New cases, + 557

Early June, + 350 

https://www.theguardian.com/world/live/2020/jul/28/coronavirus-live-news-who-says-covid-19-is-easily-the-most-severe-crisis-it-has-faced

Koch Institute, (Lothar Wieler)

We must prevent that the virus once again spreads rapidly and uncontrollably

The latest developments in the number of COVID-19 cases are of great concern to me and all of us at the RKI, 

It’s in our hands how the pandemic evolves in Germany 

Face masks, outdoors, if the recommended 1.5-metre (5-foot) distancing cannot be maintained

Outbreaks, returning tourists, workplaces, outdoor parties

Recommending against travel to Aragon, Catalonia and Navarra

Philippine

Cases, + 1,678 = 83,673

Over 1,000 per day for last 14 days

Deaths, 1,947

Hong Kong

Cases, + 106 = 2,880

98 that locally transmitted

Deaths, 22

Ban restaurant dining

Restrict gatherings to two people

Mandate masks in outdoor spaces

Taiwan

Cases, 467

Deaths, 7

Borders mostly closed since mid-March

20 active cases

First possible local infection in more than a month

Thai man

180 contacts screened

5 further cases in returnees from the Philippines and Hong Kong.

Vietnam 

Cases, 431

Deaths, 0

Vaccine

Pre-clinical, 142

Phase 1, 17

Phase 2, 13

Phase 3, 5

Approved, 0

Moderna / NIH

https://www.youtube.com/watch?v=7jnBIsL7gE4&t=14s

Phase 3 began yesterday

30,000 volunteers

89 sites in the US

Placebo controlled

Counting cases in both groups with natural exposure

$1 Billion

500m doses per year

