# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Does PS5 Need To AGGRESSIVELY Compete With Xbox Game Pass?
 - [https://www.youtube.com/watch?v=WMTXtipxqZg](https://www.youtube.com/watch?v=WMTXtipxqZg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-09-22 00:00:00+00:00

Xbox and Microsoft are purchasing Bethesda. It's a huge move for Xbox and Game Pass - but does Sony need to directly compete? Can they do their own thing? Let's dive in.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## Xbox Explains EXCLUSIVES After Buying Bethesda For $7.5 Billion
 - [https://www.youtube.com/watch?v=lwsXfYr-OXE](https://www.youtube.com/watch?v=lwsXfYr-OXE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-09-21 00:00:00+00:00

Microsoft Xbox has acquired Zenimax/Bethesda. What does this mean for video games, Game Pass, and games like Fallout and Elder Scrolls? Let's dive in and speculate.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

