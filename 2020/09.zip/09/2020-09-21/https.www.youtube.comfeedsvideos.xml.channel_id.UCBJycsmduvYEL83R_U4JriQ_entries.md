# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Porsche Taycan Turbo: I Almost Switched!  [Auto Focus Ep 6]
 - [https://www.youtube.com/watch?v=BAZX9p2oGOg](https://www.youtube.com/watch?v=BAZX9p2oGOg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-09-22 00:00:00+00:00

Porsche Taycan is an incredible electric sports car. It just needs 1 more thing to get me to switch from Tesla.

Shoutout to Maurice from Porsche of Englewood: mmanente@townmotors.com

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

