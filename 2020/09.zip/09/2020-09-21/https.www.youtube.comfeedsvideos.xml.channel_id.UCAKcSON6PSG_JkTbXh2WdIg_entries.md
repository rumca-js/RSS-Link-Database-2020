# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Andrea Swensson interviews BrownMark of the Revolution
 - [https://www.youtube.com/watch?v=_uSycowYgWA](https://www.youtube.com/watch?v=_uSycowYgWA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-09-22 00:00:00+00:00

BrownMark, bass player for the Revolution, is the author of a new memoir titled "My Life in the Purple Kingdom." Local Show host Andrea Swensson interviewed the artist about the book, his relationship with Prince, and his reflections on the need for racial justice.

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Ron Gallo - Virtual Session
 - [https://www.youtube.com/watch?v=PPQZWGmJ12A](https://www.youtube.com/watch?v=PPQZWGmJ12A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-09-22 00:00:00+00:00

Songs Played:
02:16 Wunday (Crazy After Dark)
04:55 Easter Island
17:45 Hide Myself
21:06 All The Punks Are Domesticated (2020 Version)

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Semisonic - three songs at The Current (2019)
 - [https://www.youtube.com/watch?v=18TnijEqHqQ](https://www.youtube.com/watch?v=18TnijEqHqQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-09-22 00:00:00+00:00

On Friday, Sept. 18, Semisonic released the new EP "You're Not Alone." That reminded us how last July, Semisonic visited our studio to play three as-yet unreleased songs that are out now on the new release, including the song that is the title track. Watch those performances.

SONGS PERFORMED
0:00 "All It Would Take"
2:57 "Basement Tapes"
6:22 "You're Not Alone"

PERSONNEL
Dan Wilson – vocals, guitar
John Munson – bass, vocals
Jake Slichter – drums
Andy Thompson – keys, second guitar
Ken Chastain – percussion

CREDITS
Video & Photo: Mary Mathis; Nate Ryan
Audio: Michael DeMark
Production: Derrick Stevens

FIND MORE:
2019 studio session: 
https://www.thecurrent.org/feature/2019/07/09/semisonic-perform-in-studio

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#semisonic #semisonicband

