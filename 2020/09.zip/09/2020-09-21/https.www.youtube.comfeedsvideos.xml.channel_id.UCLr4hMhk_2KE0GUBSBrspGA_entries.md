# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## GoPro 9 vs Twoja stara GoPro 8
 - [https://www.youtube.com/watch?v=vgO_4Ot6euA](https://www.youtube.com/watch?v=vgO_4Ot6euA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-09-22 00:00:00+00:00

GoPro pożyczyłem do testów ze sklepu https://www.gohero.pl/, dzięki!
Piotrka, który pomagał mi w testach znajdziecie na insta: https://bit.ly/33LBfP0
Moje sociale: 
Insta: http://bit.ly/InstaKlawiatur 
Twitter: http://bit.ly/TTKlawitera
FB: http://bit.ly/FBKlawiatur

