# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Tech Expert Gives Tips On How To Handle Your Use Of Addictive Tech! | Russell Brand
 - [https://www.youtube.com/watch?v=yUG8AGlwe8Y](https://www.youtube.com/watch?v=yUG8AGlwe8Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-09-22 00:00:00+00:00

From my #UnderTheSkin podcast with Adam Alter. You can listen to the full podcast over on Luminary: http://luminary.link/russell

Adam Alter is an Associate Professor of Marketing at New York University’s Stern School of Business and author of Irresistible: The Rise of Addictive Technology and the Business of Keeping Us Hooked - which considers why so many people today are addicted to so many behaviours, from incessant smart phone and internet use to playing video games and online shopping. 

Adam’s book “Irresistible” is available now.

US link: https://www.amazon.com/Irresistible-Adam-Alter-audiobook/dp/B06WGMQBBM/ 
UK link: https://www.amazon.co.uk/Irresistible-addicted-technology-yourself-free/dp/1784701653/#ace-3536363283 

adamalterauthor.com
Twitter: @adamleealter

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

