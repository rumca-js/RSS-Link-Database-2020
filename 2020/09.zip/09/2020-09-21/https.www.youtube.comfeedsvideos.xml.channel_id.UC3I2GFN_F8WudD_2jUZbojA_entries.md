# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Frances Quinlan - Detroit Lake (Live on KEXP)
 - [https://www.youtube.com/watch?v=hpaUlv7uTK0](https://www.youtube.com/watch?v=hpaUlv7uTK0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-09-21 00:00:00+00:00

http://KEXP.ORG presents Frances Quinlan performing “Detroit Lake” live in the KEXP studio. Recorded March 5, 2020.

Host: Cheryl Waters
KEXP Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
https://www.francesquinlan.com

## Frances Quinlan - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=QriPZZ7Pqsk](https://www.youtube.com/watch?v=QriPZZ7Pqsk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-09-21 00:00:00+00:00

http://KEXP.ORG presents Frances Quinlan performing live in the KEXP studio. Recorded March 5, 2020.

Songs:
Detroit Lake
Now That I'm Back
Rare Thing
Went To LA

Host: Cheryl Waters
KEXP Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
https://www.francesquinlan.com

## Frances Quinlan - Now That I'm Back (Live on KEXP)
 - [https://www.youtube.com/watch?v=ZPs6acsUrFk](https://www.youtube.com/watch?v=ZPs6acsUrFk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-09-21 00:00:00+00:00

http://KEXP.ORG presents Frances Quinlan performing “Now That I'm Back” live in the KEXP studio. Recorded March 5, 2020.

Host: Cheryl Waters
KEXP Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
https://www.francesquinlan.com

## Frances Quinlan - Rare Thing (Live on KEXP)
 - [https://www.youtube.com/watch?v=HuOVyWhPpLE](https://www.youtube.com/watch?v=HuOVyWhPpLE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-09-21 00:00:00+00:00

http://KEXP.ORG presents Frances Quinlan performing “Rare Thing” live in the KEXP studio. Recorded March 5, 2020.

Host: Cheryl Waters
KEXP Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
https://www.francesquinlan.com

## Frances Quinlan - Went To LA (Live on KEXP)
 - [https://www.youtube.com/watch?v=iXvFHN5rPpQ](https://www.youtube.com/watch?v=iXvFHN5rPpQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-09-21 00:00:00+00:00

http://KEXP.ORG presents Frances Quinlan performing “Went To LA” live in the KEXP studio. Recorded March 5, 2020.

Host: Cheryl Waters
KEXP Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

http://kexp.org
https://www.francesquinlan.com

