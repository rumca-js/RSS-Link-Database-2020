# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Wars of the Witch-King & Arnor | Hobbit Day 2020
 - [https://www.youtube.com/watch?v=oj9THxVCad0](https://www.youtube.com/watch?v=oj9THxVCad0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2020-09-21 00:00:00+00:00

Check out the full Hobbit Day playlist here!!: https://www.youtube.com/playlist?list=PLLyHBx6FRJC0H9EnNSmkd-cMyTWhcC-aq

This Hobbit Day, we are looking back at the history of the realm of Arnor and its wars with the Witch-King of Angmar.  We find out how The Shire came to be inhabited with hobbits and how the rangers of the North are all that remains of the once mighty kingdom by the time of The Lord of the Rings.

Hit subscribe - and the bell - so you never miss a video from Nerd of the Rings! 

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner. 

Arvedui - Steamey
Lossoth of Forochel -  Arvid Hjorth
Captain of Gondor - Nordheimer
Minas Tirith - Ludovic Bourgeois
Meneldil of Gondor - Matej Cadil
Barrow-wights - John Howe
Umbar vs Minas Tirith - Angus McBride
Wainriders - Stefano Baldo
Various Kings - Dolldivine Azaleasdolls

#HobbitDay #witchking #LordoftheRings

