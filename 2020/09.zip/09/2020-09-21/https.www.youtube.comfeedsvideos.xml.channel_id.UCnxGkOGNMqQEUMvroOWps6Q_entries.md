# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Is a Technological Takeover Inevitable
 - [https://www.youtube.com/watch?v=0LkovwwFu68](https://www.youtube.com/watch?v=0LkovwwFu68)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-09-22 00:00:00+00:00

JRE #1539 w/Jenny Kleeman:
https://open.spotify.com/episode/4JERSlYG6OaJC4OrKYGUTH

## The Implications of Sex Robots
 - [https://www.youtube.com/watch?v=aUAqmjxkmnc](https://www.youtube.com/watch?v=aUAqmjxkmnc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-09-22 00:00:00+00:00

JRE #1539 w/Jenny Kleeman:
https://open.spotify.com/episode/4JERSlYG6OaJC4OrKYGUTH

