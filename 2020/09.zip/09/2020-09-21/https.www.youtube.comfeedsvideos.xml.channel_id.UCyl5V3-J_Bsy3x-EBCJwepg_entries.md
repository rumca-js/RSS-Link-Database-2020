# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Michael Malice Talks Cuties/Conspiracy Theories/Boomercons
 - [https://www.youtube.com/watch?v=PHt-LjJWFU0](https://www.youtube.com/watch?v=PHt-LjJWFU0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-09-22 00:00:00+00:00

In this episode of The Babylon Bee Interview Show, Kyle and Ethan welcome back again The Bee’s favorite anarchist troll: Michael Malice, the author of Dear Reader and The New Right and host of "YOUR WELCOME" and Night Shade. They discuss the new Netflix movie that sexualizes children, which conspiracy theories are aging better than others, and how the depravity and malfeasance of the corporate press is without cessation. You can get more Michael Malice on YouTube, Twitter and Locals.

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Gain Access to the Exclusive Content and Writing Forum: https://babylonbee.com/plans

The Official Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

## Michael Malice on The Babylon Bee Podcast
 - [https://www.youtube.com/watch?v=lUvghD3Edyk](https://www.youtube.com/watch?v=lUvghD3Edyk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-09-21 00:00:00+00:00

🎙 Tomorrow Michael Malice joins Kyle and Ethan on The Babylon Bee podcast.

Subscribe today ▶️  http://bit.ly/TheBeeYouTube

