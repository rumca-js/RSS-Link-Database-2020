## Gates Foundation funds Facebook fact-checkers that defend it from allegations
 - [https://reclaimthenet.org/gates-foundation-funds-facebook-fact-checkers/](https://reclaimthenet.org/gates-foundation-funds-facebook-fact-checkers/)
 - RSS feed: reclaimthenet.org
 - date published: 2020-09-21 07:17:36+00:00



