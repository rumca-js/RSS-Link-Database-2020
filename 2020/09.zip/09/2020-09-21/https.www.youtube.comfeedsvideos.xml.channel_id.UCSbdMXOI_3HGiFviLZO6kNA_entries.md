# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## The Oculus Quest 2 ⁚ The WORST and BEST thing to EVER happen to VR
 - [https://www.youtube.com/watch?v=Xx_V-6mP300](https://www.youtube.com/watch?v=Xx_V-6mP300)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-09-22 00:00:00+00:00

Hello and welcome to TUESDAY NEWSDAY! Your number one resource for the entire weeks worth of VR news. 

So Facebook connect has happened, the Oculus Quest 2 has been announced officially, a ton of new games were announced, and AR has taken a step further towards commercialization. Today however I am focusing on the Quest 2, because really, now the Rift platform is dead, Facebook rules VR, but we have an awesome cheap VR headset that will get millions of new VR users. Its the best and worst thing to ever happen to the industry. 

Affiliate Quest 2 link-
https://amzn.to/3hTjNgG

My Links-
Twitch Stream TODAY!
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill

Sources-
Open Source $200 VR headset 
https://www.relativty.com

TimeStamps-

Outro music-
Protostar Overdrive
https://open.spotify.com/track/3QifigzYiNKYk39TuwhPhJ?si=O_gWSnElTEaY1CtRrYbdgA

