# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## The Quantum Theory That Might Make You Immortal | Answers With Joe
 - [https://www.youtube.com/watch?v=wnfUiiQ68Mc](https://www.youtube.com/watch?v=wnfUiiQ68Mc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2020-09-21 00:00:00+00:00

Get 3 months of ExpressVPN for free when you sign up at http://www.expressvpn.com/joescott
Quantum physics is dominated by the idea that quantum objects remain in superposition until thy are measured, which causes its wave function to collapse.
But there is another interpretation of quantum mechanics, one with mind-blowing implications about the universe and our lives. It's the many worlds interpretation, and some believe it imbues us with a kind of immortality.


Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

My previous video on the Many Worlds interpretation:
https://www.youtube.com/watch?v=xies3jrFGpA

https://thereader.mitpress.mit.edu/the-many-worlds-theory/

https://wtamu.edu/~cbaird/sq/2013/07/30/what-did-schrodingers-cat-experiment-prove/

https://jqi.umd.edu/glossary/quantum-superposition

My video on pilot wave theory:
https://www.youtube.com/watch?v=fc-NcAvqguM

https://www.quantamagazine.org/why-the-many-worlds-interpretation-of-quantum-mechanics-has-many-problems-20181018/

