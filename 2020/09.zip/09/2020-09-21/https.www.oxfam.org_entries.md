## Carbon emissions of richest 1 percent more than double the emissions of the poorest half of humanity
 - [https://www.oxfam.org/en/press-releases/carbon-emissions-richest-1-percent-more-double-emissions-poorest-half-humanity](https://www.oxfam.org/en/press-releases/carbon-emissions-richest-1-percent-more-double-emissions-poorest-half-humanity)
 - RSS feed: https://www.oxfam.org
 - date published: 2020-09-21 07:50:21+00:00

Carbon emissions of richest 1 percent more than double the emissions of the poorest half of humanity

