# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## What It’s Like Living in California Now
 - [https://www.youtube.com/watch?v=ZeCaYaG-ZRM](https://www.youtube.com/watch?v=ZeCaYaG-ZRM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-09-22 00:00:00+00:00

Get your Cacao Bliss Here - https://earthechofoods.com/jpsears
Discount code - JP

What it’s like living in California now is a little bit significantly different than seven months ago. California, now officially the world’s largest prison has the industries of homelessness and lockdowns to bolster its economy. Along with the highest tax rate in the nation, businesses being shutdown is another fantastic strategy that’s sure to improve the economy. Gavin Newsom, Mayor Garcetti, and Nancy Pelosi are spear heading the charge to help make California the zombie apocalypse capital of the world.

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

