# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## WandaVision - Official Trailer (My Thoughts)
 - [https://www.youtube.com/watch?v=vxkaWNzklWE](https://www.youtube.com/watch?v=vxkaWNzklWE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-09-21 00:00:00+00:00

We have an official trailer for the Disney+ series WandaVision. So here are my thoughts on it!

Watch the trailer here: https://www.youtube.com/watch?v=sj9J2ecsSpo&t=4s&ab_channel=MarvelEntertainment

#WandaVision

