# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## just saying hi. I've been busy.
 - [https://www.youtube.com/watch?v=0kOvPjfbCTo](https://www.youtube.com/watch?v=0kOvPjfbCTo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-09-22 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
https://store.rossmanngroup.com/atten-862.html
I love the lack of image stabilization on the moto g.

