# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Android 11 is here and I like it.
 - [https://www.youtube.com/watch?v=XGsBPwRT9Z4](https://www.youtube.com/watch?v=XGsBPwRT9Z4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-09-22 00:00:00+00:00

Receive an additional $50 credit for Ting today when you sign up at https://linus.ting.com/

Get $50 in Ting credit when you visit https://Linus.Ting.com

Android 11 doesn't add a TON of new features, but there's still enough tweaks and optimizations to make diehard Android fans happy. Let's talk about 'em!

Buy: Google Pixel 3
On Amazon (PAID LINK): https://geni.us/CE3lzX2
On Newegg (PAID LINK): https://geni.us/UdrT
On Best Buy (PAID LINK): https://geni.us/fASi2vE

Buy: Google Pixel 4a
On Amazon (PAID LINK): https://geni.us/vXIBk
On Best Buy (PAID LINK): https://geni.us/zAuy

Buy: Microsoft Surface Duo
On Amazon (PAID LINK): https://geni.us/rbQN  
On Best Buy (PAID LINK): https://geni.us/wMZC6G

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1249982-android-11-is-here-and-i-like-it/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Private Internet Access VPN: https://lmg.gg/pialinus2
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

## ULTIMATE Water Cooled Gaming Chair!!
 - [https://www.youtube.com/watch?v=2pXrfHUjzmM](https://www.youtube.com/watch?v=2pXrfHUjzmM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-09-21 00:00:00+00:00

Thanks to Constant Contact for sponsoring a portion of this video! Learn more about their service and try it for yourself at https://www.constantcontact.com

No AC? NO PROBLEM. Who needs to cool the whole room when you can cool just yourself! A handful of parts and a little VHB tape is all it takes to make your own Sweaty-Ass-B-Gone 9000™.

Buy NEEDforSEAT gaming chairs at: https://lmg.gg/DJQYb

Buy: EK-XRES 140 Revo D5
On Amazon (PAID LINK): https://geni.us/XiQOGR
On Newegg (PAID LINK): https://geni.us/BtPiXD5

Buy: Silverstone SX700-LPT
On Amazon (PAID LINK): https://geni.us/MfKr9
On Newegg (PAID LINK): https://geni.us/qm0n
On B&H (PAID LINK): https://geni.us/nHxSrp

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1249653-ultimate-water-cooled-gaming-chair/

Seat Bracket: https://www.prusaprinters.org/prints/40981-cooled-gamer-chair-pump-bracket

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

Follow Constant Contact on social:
https://www.instagram.com/constantcontact/
https://www.facebook.com/constantcontact
https://twitter.com/constantcontact
https://www.pinterest.com/constantcontact/
https://www.youtube.com/constantcontact

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Private Internet Access VPN: https://lmg.gg/pialinus2
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxm...
iTunes Download Link: https://itunes.apple.com/us/album/sup...
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnir...

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

