# Source:Kurzgesagt – In a Nutshell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsXVk37bltHxD1rDPwtNM8Q, language:en-US

## The Largest Star in the Universe – Size Comparison
 - [https://www.youtube.com/watch?v=3mnSDifDSxQ](https://www.youtube.com/watch?v=3mnSDifDSxQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsXVk37bltHxD1rDPwtNM8Q
 - date published: 2020-09-22 00:00:00+00:00

We created our first app ‘Universe in a Nutshell’, together with Tim Urban of Wait but Why!
Appstore: http://kgs.link/universe-app-ios
Google Playstore: http://kgs.link/universe-app-android

Sources & further reading: 
https://sites.google.com/view/sourceslargeststar

Wait But Why: 
https://waitbutwhy.com/

Video on Red Dwarfs: 
https://www.youtube.com/watch?v=LS-VPyLaJFM&vl=pt

What is the largest star in the Universe? And why is it that large? And what ARE stars anyway?

OUR CHANNELS
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
German Channel: https://kgs.link/youtubeDE
Spanish Channel: https://kgs.link/youtubeES


HOW CAN YOU SUPPORT US?
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
This is how we make our living and it would be a pleasure if you support us!

Get Merch designed with ❤ from https://kgs.link/shop-129  
Join the Patreon Bird Army 🐧 https://kgs.link/patreon  


DISCUSSIONS & SOCIAL MEDIA
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
Reddit:            https://kgs.link/reddit
Instagram:     https://kgs.link/instagram
Twitter:           https://kgs.link/twitter
Facebook:      https://kgs.link/facebook
Discord:          https://kgs.link/discord
Newsletter:    https://kgs.link/newsletter


OUR VOICE
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
The Kurzgesagt voice is from 
Steve Taylor:  https://kgs.link/youtube-voice


OUR MUSIC ♬♪
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
700+ minutes of Kurzgesagt Soundtracks by Epic Mountain:

Spotify:            https://kgs.link/music-spotify
Soundcloud:   https://kgs.link/music-soundcloud
Bandcamp:     https://kgs.link/music-bandcamp
Youtube:          https://kgs.link/music-youtube
Facebook:       https://kgs.link/music-facebook

The Soundtrack of this video:

Soundcloud:   https://bit.ly/2RutyqU
Bandcamp:     https://bit.ly/35HmkIa 

🐦🐧🐤 PATREON BIRD ARMY 🐤🐧🐦
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
Many Thanks to our wonderful Patreons from http://kgs.link/patreon who support us every month and made this video possible:

Keanu Vestil, Xavier, Antonio Tavano, Scott James, Camfifty5, Michael, Paul Barth, Christian Puelacher, Katie Barton, Cole Bowden, Andreas Rautner, Sovos, Alejandro Uresti, couchy, Bill Hochberg, John Specht, Lander Verhack, Vlad Mustiață, Oliver Kurtz, Mischa Blazer, Josh Yelavich, Islam Mohamed, Robrecht Cannoodt, Kirsty, Greenleaves, Jayson Lamanca, Nithin Thaha, Tristan Jackson, Even_skjeih, Mo Alawami, Jonas Brandão, Lily McAdams, Alejandro Rodriguez, Isaac Overmyer, Cooper Norton, Biblion, Stephen Zappia, Bodo Nuber, Samhain, Kyle Goff, jota jodra, Marc Bornträger, Filip Leszczyński, Влад Кальченко, NexusValhalla, Aleksandar Zivancevic, Silas Zander, Tijn Flinterman, Shrutika Umralkar, Or Bairey-Sehayek, Terri-Ann dela Cruz, Choltikan Phothong, Collin Carey, Champ, Marcela Oliveira, rbtpzk, Jamie Grall, LAI Oscar, Ralf P., Kuba, Ryan Giles, JoghurtWiesel, Timster Ruu, John Highet, Walmyr Carvalho, Perry Williams, Aldo Vicente, Peter Paj, Vanny Khon, Olga, Theeraphong Gasparini, destroymyarrogance, Martin Pietrowski, Josip Haramija, Champ, Carlos, Davi & Nicholas

