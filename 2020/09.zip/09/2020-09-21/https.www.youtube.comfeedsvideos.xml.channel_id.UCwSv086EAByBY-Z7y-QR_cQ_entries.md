# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Drugi lockdown w Polsce? Dlaczego ilość zakażeń rośnie?
 - [https://www.youtube.com/watch?v=y-rkYuHRpUA](https://www.youtube.com/watch?v=y-rkYuHRpUA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2020-09-22 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Mroczne Podcasty: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
👀 Tatusiek: http://bit.ly/3aSCheE
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
🔒 Dołącz do Spółdzielni
https://discord.gg/RSEUaR3
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/2ETKSyN
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
---------------------------------------------------------------
🖼Grafika - wykorzystano elementy ze stron: 
gov.pl / http://bit.ly/2lVWjQr
---------------------------------------------------------------
✅źródła:
https://bit.ly/33O1ww9
https://bit.ly/2FW6sXE
https://bit.ly/35WV8W0
https://bit.ly/33OZXhB
https://bit.ly/3hb0H5c
-------------------------------------------------------------
💡 Tagi: #lockdown #covid-19
--------------------------------------------------------------

## Córka prezydenta będzie doradzała tacie, czyli ciąg dalszy programu "Rodzina na swoim"
 - [https://www.youtube.com/watch?v=90NdGQ1oIjs](https://www.youtube.com/watch?v=90NdGQ1oIjs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2020-09-21 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Mroczne Podcasty: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
🔒 Dołącz do Spółdzielni
https://discord.gg/RSEUaR3
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/2ETKSyN
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
---------------------------------------------------------------
🖼Grafika - wykorzystano elementy ze stron: 
president.gov.ua / http://bit.ly/3an5tJP
prezydent.pl / https://bit.ly/3iNbT9q
wikipedia.org - Marcin Białek / https://bit.ly/3iRoCIm
---------------------------------------------------------------
✅źródła:
https://bit.ly/3cq8Bac
https://bit.ly/3ckboSa
-------------------------------------------------------------
💡 Tagi: #Duda #polityka
--------------------------------------------------------------

