## Why I Live a Simple Life
 - [https://www.youtube.com/watch?v=7zRGEDBkIMU](https://www.youtube.com/watch?v=7zRGEDBkIMU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq2jigrIGtupbTXiNjq6Wrw
 - date published: 2020-09-20 00:00:00+00:00

Everyone always asks this, or some variation of this, so I figured I'd make a video and answer the question and give a bit of insight into why I do what I do


Twitch.tv/Asmongold
Twitter.com/Asmongold

