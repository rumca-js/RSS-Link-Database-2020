# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Historie potłuczone [#12] O Maćku, co pod pociąg się rzucił
 - [https://www.youtube.com/watch?v=_Rul2Uwvwig](https://www.youtube.com/watch?v=_Rul2Uwvwig)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-09-20 00:00:00+00:00

@Langustanapalmie  #historiepotłuczone #podcast

Historie potłuczone to opowieści o córkach i synach Boga, pięknych i brzydkich, świętych i grzesznych, szczęśliwych i na skraju rozpaczy. To opowieści o drodze, którą idzie się do nieba i o zakrętach i chaszczach, które spychają do piekła. To opowieści o ludziach po prostu. Czyli o nas.

Muzyka: Kai Engel: Brand New World, http://freemusicarchive.org/music/Kai_Engel/
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

♫ Słuchaj jako PODCAST Langusty: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
iTunes → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWHx

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Mocno stronniczy [#12] Potrzymaj mi piwo!
 - [https://www.youtube.com/watch?v=XzJL6vya0o8](https://www.youtube.com/watch?v=XzJL6vya0o8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-09-20 00:00:00+00:00

​@STREFAWODZA @Langustanapalmie 

Takich dwóch, jak Ci to nie ma :) Zapraszamy co niedzielę o godz: 10:oo, na premierę zupełnie niesłychanej serii ojców Tomasza Nowaka OP i Adama Szustaka OP.

________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

♫ Słuchaj jako PODCAST Langusty: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/histori...
Spotify → https://spoti.fi/2NVIRHb
iTunes → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWHx

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#199] Masz popsute serce!
 - [https://www.youtube.com/watch?v=JnZfniTOHRY](https://www.youtube.com/watch?v=JnZfniTOHRY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-09-19 00:00:00+00:00

#cnn #kazaniedookienka  @Langustanapalmie 
Kazanie XXV Niedzielę zwykłą, Rok A 

1. czytanie (Iz 55, 6-9)

Szukajcie Pana, gdy się pozwala znaleźć, wzywajcie Go, dopóki jest blisko! Niechaj bezbożny porzuci swą drogę i człowiek nieprawy swoje knowania. Niech się nawróci do Pana, a Ten się nad nim zmiłuje, do Boga naszego, gdyż hojny jest w przebaczaniu.
Bo myśli moje nie są myślami waszymi ani wasze drogi moimi drogami – mówi Pan. Bo jak niebiosa górują nad ziemią, tak drogi moje – nad waszymi drogami i myśli moje – nad myślami waszymi.

2. czytanie (Flp 1, 20c-24. 27a)

Bracia: Chrystus będzie uwielbiony w moim ciele: czy to przez życie, czy przez śmierć. Dla mnie bowiem żyć – to Chrystus, a umrzeć – to zysk. Jeśli zaś żyć w ciele – to dla mnie owocna praca, cóż mam wybrać? Nie umiem powiedzieć.
Z dwóch stron doznaję nalegania: pragnę odejść, a być z Chrystusem, bo to o wiele lepsze; pozostawać zaś w ciele – to bardziej konieczne ze względu na was. Tylko sprawujcie się w sposób godny Ewangelii Chrystusowej.

Ewangelia (Mt 20, 1-16a)

Jezus opowiedział swoim uczniom następującą przypowieść:
«Królestwo niebieskie podobne jest do gospodarza, który wyszedł wczesnym rankiem, aby nająć robotników do swej winnicy. Umówił się z robotnikami o denara za dzień i posłał ich do winnicy.
Gdy wyszedł około godziny trzeciej, zobaczył innych, stojących na rynku bezczynnie, i rzekł do nich: „Idźcie i wy do mojej winnicy, a co będzie słuszne, dam wam”. Oni poszli. Wyszedłszy ponownie około godziny szóstej i dziewiątej, tak samo uczynił. Gdy wyszedł około godziny jedenastej, spotkał innych stojących i zapytał ich: „Czemu tu stoicie cały dzień bezczynnie?” Odpowiedzieli mu: „Bo nas nikt nie najął”. Rzekł im: „Idźcie i wy do winnicy”. A gdy nadszedł wieczór, rzekł właściciel winnicy do swego rządcy: „Zwołaj robotników i wypłać im należność, począwszy od ostatnich aż do pierwszych”. Przyszli najęci około jedenastej godziny i otrzymali po denarze. Gdy więc przyszli pierwsi, myśleli, że więcej dostaną; lecz i oni otrzymali po denarze.
Wziąwszy go, szemrali przeciw gospodarzowi, mówiąc: „Ci ostatni jedną godzinę pracowali, a zrównałeś ich z nami, którzy znosiliśmy ciężar dnia i spiekotę”. Na to odrzekł jednemu z nich: „Przyjacielu, nie czynię ci krzywdy; czyż nie o denara umówiłeś się ze mną? Weź, co twoje, i odejdź. Chcę też i temu ostatniemu dać tak samo jak tobie. Czy mi nie wolno uczynić ze swoim, co chcę? Czy na to złym okiem patrzysz, że ja jestem dobry?” Tak ostatni będą pierwszymi, a pierwsi ostatnimi».
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

♫ Słuchaj jako PODCAST Langusty: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
iTunes → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWHx

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#614] Biedacy
 - [https://www.youtube.com/watch?v=zo1lo4Hhgc8](https://www.youtube.com/watch?v=zo1lo4Hhgc8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-09-19 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał  
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie


♫ Słuchaj jako PODCAST Langusty: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
iTunes → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWHx

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

