# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga Paula does XM: Falcon - Inmost Sympathy (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=4H4jWFmV2QI](https://www.youtube.com/watch?v=4H4jWFmV2QI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-09-19 00:00:00+00:00

"Inmost Sympathy" (1996) by Falcon/Pulse (Jacek Dojwa). Art "Red Cloud 1881" (1995) by Made/Scoopex^Bomb.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Normal mixing with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- Module reports 22 channels
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.

## Amiga music: Jellybean - 1990 (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=ZTa4kIyzulg](https://www.youtube.com/watch?v=ZTa4kIyzulg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-09-19 00:00:00+00:00

"1990" by Jellybean (P. Anvegard). Art "Amiga" (1990) by 9 Mm & Dre. Headphones recommended.

Made using Real A1200 Rev. 1D.4 audio.

Visit my channel for more Amiga music.

