# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Netflix Movie That Murders Puppies Braver Than ‘Cuties’
 - [https://www.youtube.com/watch?v=E5UKkS0hHxM](https://www.youtube.com/watch?v=E5UKkS0hHxM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-09-20 00:00:00+00:00

Kyle and Ethan discuss Netflix releasing films to show how bad something is… by doing that exact thing. 

FULL ▶️  https://youtu.be/Q-pGA4EeuaQ

## When Octobears Attack And Other Bible Stories
 - [https://www.youtube.com/watch?v=Tvybz7H8JIA](https://www.youtube.com/watch?v=Tvybz7H8JIA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-09-19 00:00:00+00:00

There are a ton of beautiful, inspiring stories in the Bible. We all know about those ones. But there’s also a lot of weird stuff. Kyle and Ethan talk through some of the weirdest.

