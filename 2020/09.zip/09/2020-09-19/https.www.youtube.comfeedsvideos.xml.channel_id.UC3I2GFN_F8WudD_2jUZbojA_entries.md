# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Belafonte Sensacional - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=f736oKybUQI](https://www.youtube.com/watch?v=f736oKybUQI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-09-19 00:00:00+00:00

http://KEXP.ORG presents Belafonte Sensacional sharing songs they recorded live exclusively for KEXP. 

CREDITS:
Recorded by: Febe Esquerra
Recording assistants: Diego Mendoza Cano, Juan Demian Bañuelos, Óscar Vega
Video: Emilio Guerrero Alexander
Mix & master: Hugo Quezada
Special thanks to: Martín Delgado & Aire Libre 105.3 FM

BELAFONTE SENSACIONAL:
Voice: Israel Ramírez aka Patrón
Guitar: Carlos Bergen Dyck aka Perritos Genéricos
Keyboards: Pablo Mendía aka Pablito Remix
Drums: Cristóbal Martínez aka Cristo Rey
Percussions & voice: Enrique Álvarez aka Gobernador
Harmonica, percussions & voice: Alejandro Guerrero aka ElAle
Bass: Israel Pompa-Alcalá aka Tsiki

https://holabelafonte.bandcamp.com
https://airelibre.fm
http://kexp.org

