# Source:Vlog Casha, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg, language:pl-PL

## TRZYDZIESTOLETNI PODRÓŻNIK. CZEGO ŻAŁUJĘ? (Nagranie z moich szóstych urodzin!)
 - [https://www.youtube.com/watch?v=Xmp-3h85xuU](https://www.youtube.com/watch?v=Xmp-3h85xuU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg
 - date published: 2020-09-20 00:00:00+00:00

🗺️ Kończę 30 lat... Udało mi się dokopać do nagrania z moich urodzin w 1996 roku :)

❗ Zostań Patronem kanału! 
https://patronite.pl/vlogcasha

We vlogu gościnnie występują @BezPlanu oraz Ignalin :)

Vlogi z Turcji (2019): https://bit.ly/31VPCR3
Vlogi z Kolumbii: https://bit.ly/36tqlhH
🌏 Vlogi z Azji Płd-Wsch: https://bit.ly/2wrM9t2
🇦🇺 Vlogi z Australii: https://bit.ly/2OJWYOy
🇺🇸 Vlogi z życia i podróży w USA: https://bit.ly/2ya73NV
🚙Vlogi z autostopu 2018: https://bit.ly/2NbHzos

▸ Instagram: https://www.instagram.com/vlogcasha
▸ Facebook: https://www.facebook.com/vlogcasha/
#PodróżeCasha #CashWTurcji #Turcja

## OPUSZCZONY GÓRSKI KLASZTOR - TURCJA
 - [https://www.youtube.com/watch?v=xdeczE6mlU4](https://www.youtube.com/watch?v=xdeczE6mlU4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg
 - date published: 2020-09-19 00:00:00+00:00

🗺️ Turcja 2020 #3. Relacja z pierwszego dnia samotnej podróży po Turcji! Pierwszy autostop, wyjazd w góry :)

❗ Zostań Patronem kanału! 
https://patronite.pl/vlogcasha

Dron DJI MAVIC MINI od DJI ARS: https://dji-ars.pl/
Vlogi z Turcji (2019): https://bit.ly/31VPCR3
Vlogi z Kolumbii: https://bit.ly/36tqlhH
🌏 Vlogi z Azji Płd-Wsch: https://bit.ly/2wrM9t2
🇦🇺 Vlogi z Australii: https://bit.ly/2OJWYOy
🇺🇸 Vlogi z życia i podróży w USA: https://bit.ly/2ya73NV
🚙Vlogi z autostopu 2018: https://bit.ly/2NbHzos

▸ Instagram: https://www.instagram.com/vlogcasha
▸ Facebook: https://www.facebook.com/vlogcasha/
#PodróżeCasha #CashWTurcji #Turcja

