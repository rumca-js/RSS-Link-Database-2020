# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## How a teenager's tragic death became a battle over conspiracy and truth
 - [https://www.cnn.com/2020/09/19/asia/hong-kong-chan-mental-health-conspiracies-intl-hnk/index.html](https://www.cnn.com/2020/09/19/asia/hong-kong-chan-mental-health-conspiracies-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 23:45:19+00:00

The crowd recoiled as tear gas canisters rained down on them and riot police advanced up the street, carrying shields and batons.

## Mexican archaeologists identify the first Mayan slave ship to have ever been discovered
 - [https://www.cnn.com/2020/09/19/americas/mexico-mayan-slave-ship-trnd/index.html](https://www.cnn.com/2020/09/19/americas/mexico-mayan-slave-ship-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 21:55:49+00:00

Archaeologists in Mexico have confirmed that a shipwreck discovered off the coast of the Yucatan peninsula once carried captured Mayans who were sold into slavery.

## 7 continents, 1 wheelchair: Cory Lee's adventures show travel has no boundaries
 - [https://www.cnn.com/2020/09/19/us/cory-lee-wheelchair-travel-blogger-trnd/index.html](https://www.cnn.com/2020/09/19/us/cory-lee-wheelchair-travel-blogger-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 21:53:16+00:00

Going to Antarctica is a bucket list goal for many, but for Cory Lee, it was that and much more.

## NYC restaurants can soon add a Covid-19 surcharge to customers' bills
 - [https://www.cnn.com/2020/09/19/us/nyc-covid-restaurant-surcharge-trnd/index.html](https://www.cnn.com/2020/09/19/us/nyc-covid-restaurant-surcharge-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 19:56:32+00:00

New York City diners may soon see a Covid-19 surcharge on their bills as the restaurant industry continues to hobble due to the coronavirus pandemic.

## Americans living abroad fear their ballots won't make it in time
 - [https://www.cnn.com/2020/09/19/politics/election-2020-americans-voting-abroad/index.html](https://www.cnn.com/2020/09/19/politics/election-2020-americans-voting-abroad/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 19:43:42+00:00

When Keith Silverang went to request his absentee ballot from the local election office in the county where he was last a permanent resident in the US, he followed the same procedure he's followed when voting abroad in every general presidential election since the early 1990s.

## Gareth Bale completes loan move to Tottenham Hotspur from Real Madrid
 - [https://www.cnn.com/2020/09/19/football/gareth-bale-tottenham-hotspur-real-madrid-spt-intl/index.html](https://www.cnn.com/2020/09/19/football/gareth-bale-tottenham-hotspur-real-madrid-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 19:35:29+00:00

Gareth Bale completed a season-long loan move from Real Madrid to Tottenham on Saturday, seven years after leaving the English Premier League club.

## Manchester United sunk by former player Wilfried Zaha in sorry start to EPL season
 - [https://www.cnn.com/2020/09/19/football/premier-league-man-utd-palace-zaha-everton-rodriguez-spt-intl/index.html](https://www.cnn.com/2020/09/19/football/premier-league-man-utd-palace-zaha-everton-rodriguez-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 19:34:30+00:00

Manchester United made a sorry start to its English Premier League campaign on Saturday with a 3-1 home defeat to Crystal Palace as Wilfried Zaha scored twice against his former club.

## A London coffee shop is charging $64 for its premium brew
 - [https://www.cnn.com/travel/article/expensive-coffee-london-gbr-scli-intl/index.html](https://www.cnn.com/travel/article/expensive-coffee-london-gbr-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 19:28:48+00:00

Coffee connoisseurs, assemble!

## 11 people are arrested after a demonstration outside a federal building in Portland
 - [https://www.cnn.com/2020/09/19/us/portland-arrests-federal-building/index.html](https://www.cnn.com/2020/09/19/us/portland-arrests-federal-building/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 18:06:43+00:00

Police arrested 11 people in Portland, Oregon, after a demonstration outside a federal building Friday night, authorities said

## How it all went wrong (again) in Europe as second wave grips continent
 - [https://www.cnn.com/2020/09/19/europe/europe-second-wave-coronavirus-intl/index.html](https://www.cnn.com/2020/09/19/europe/europe-second-wave-coronavirus-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 17:24:00+00:00



## The 'Biden rule' on SCOTUS McConnell cited in 2016
 - [https://www.cnn.com/videos/tv/2020/09/19/the-biden-rule-on-scotus-that-mcconnell-cited-in-2016.cnn](https://www.cnn.com/videos/tv/2020/09/19/the-biden-rule-on-scotus-that-mcconnell-cited-in-2016.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 15:18:41+00:00

When Mitch McConnell refused to hold hearings on Obama nominee Merrick Garland, he cited what he called 'The Biden Rule' about a 1992 speech the then-Senate Judiciary made.

## Brownstein: America 'headed to a crisis of legitimacy for majority rule'
 - [https://www.cnn.com/videos/tv/2020/09/19/brownstein-america-headed-to-a-crisis-of-legitimacy-for-majority-rule.cnn](https://www.cnn.com/videos/tv/2020/09/19/brownstein-america-headed-to-a-crisis-of-legitimacy-for-majority-rule.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 15:14:24+00:00

Ronald Brownstein says the number of SCOTUS justices installed by a party that has rarely won the popular vote portends a 'crisis of legitimacy'

## One big reason why Biden is ahead: Seniors
 - [https://www.cnn.com/collections/intl-2020-election-0919/](https://www.cnn.com/collections/intl-2020-election-0919/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 14:59:12+00:00



## Who is this economy hurting the most? Moms and women of color, according to women's research CEO
 - [https://www.cnn.com/2020/09/19/business/gupta-coronavirus-podcast-women-of-color-mothers-economy/index.html](https://www.cnn.com/2020/09/19/business/gupta-coronavirus-podcast-women-of-color-mothers-economy/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 13:06:56+00:00

The economic recession caused by the Covid-19 pandemic has disproportionately affected women by almost every measure. And, in the United States, the economic downturn is hitting women of color the hardest, according to C. Nicole Mason, president and CEO of the Institute for Women's Policy Research.

## Trump is trying to rewrite history on the coronavirus. Here's the truth
 - [https://www.cnn.com/videos/politics/2020/09/18/trump-rewrites-covid-19-history-facts-first-vf-dp-orig.cnn](https://www.cnn.com/videos/politics/2020/09/18/trump-rewrites-covid-19-history-facts-first-vf-dp-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 11:43:25+00:00

CNN's Daniel Dale fact-checks President Donald Trump on his retelling of how the Covid-19 pandemic unfolded in the US.

## Navalny posts photo of him walking down staircase after poisoning
 - [https://www.cnn.com/2020/09/19/europe/navalny-recovery-staircase-post-intl/index.html](https://www.cnn.com/2020/09/19/europe/navalny-recovery-staircase-post-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 11:04:53+00:00

Russian opposition politician Alexey Navalny says he is still unable to use his phone properly or pour himself a glass of water, but is on a "clear road" towards recovering from his near-fatal poisoning.

## The money part of Breonna Taylor settlement is just a bandage
 - [https://www.cnn.com/2020/09/19/us/breonna-taylor-settlement-trnd/index.html](https://www.cnn.com/2020/09/19/us/breonna-taylor-settlement-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 10:58:48+00:00

For this week, we think about what justice might look like in the Breonna Taylor case, discuss great performances by the music icons Patti LaBelle and Gladys Knight, and revisit the horrifying history of forced sterilizations. Plus, recommendations: Esquire's profile of Michael Kenneth Williams and Hulu's "High Fidelity."

## UK Foreign Secretary's bodyguard 'left gun on plane' after US visit
 - [https://www.cnn.com/2020/09/19/uk/dominic-raab-police-officer-gun-investigation-gbr-intl/index.html](https://www.cnn.com/2020/09/19/uk/dominic-raab-police-officer-gun-investigation-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 10:31:58+00:00

A police officer traveling as part of British Foreign Secretary Dominic Raab's protection detail has been suspended, after they reportedly left their gun on a plane.

## Tiger Woods misses US Open cut at 'brutal' Winged Foot
 - [https://www.cnn.com/2020/09/19/golf/golf-us-open-reed-dechambeau-woods-spt-intl/index.html](https://www.cnn.com/2020/09/19/golf/golf-us-open-reed-dechambeau-woods-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 08:31:03+00:00

Patrick Reed led the 120th US Open as "brutal" Winged Foot lived up to its fearsome reputation and Tiger Woods missed the halfway cut.

## Will a major world event rock the US election?
 - [https://www.cnn.com/2020/09/19/politics/us-election-international-october-surprise-intl/index.html](https://www.cnn.com/2020/09/19/politics/us-election-international-october-surprise-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 08:01:17+00:00

You may be through with 2020 already, but brace yourselves. The next 50 to 120 days could be the most volatile globally for decades.

## Ginsburg made the law fairer for every US woman
 - [https://www.cnn.com/2020/09/19/opinions/ruth-bader-ginsburg-ziegler/index.html](https://www.cnn.com/2020/09/19/opinions/ruth-bader-ginsburg-ziegler/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 04:33:03+00:00

Ruth Bader Ginsburg's passing marks the end of an era in more ways than one. Having repeatedly beaten cancer, Ginsburg had come to almost seem invincible. She was a larger than life figure who became a hero to many young women trying to follow the path she forged in the legal profession. Ginsburg's age and frail health were no secret, but her loss still comes as a shock.

## Canadian Covid-19 gargle test 'one of the first of its kind' in the world, doctor says
 - [https://www.cnn.com/2020/09/19/americas/canadian-gargle-test/index.html](https://www.cnn.com/2020/09/19/americas/canadian-gargle-test/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 04:17:19+00:00

Most children in British Columbia can say goodbye to those icky swabs and uncomfortable Covid-19 tests as the Canadian province launches a new gargle method for students ages 4 to 19.

## US Supreme Court Justice Ruth Bader Ginsburg has died
 - [https://www.cnn.com/collections/ginsburg-091820/](https://www.cnn.com/collections/ginsburg-091820/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 04:16:43+00:00



## Notable names on Trump's list of potential SC nominees
 - [https://www.cnn.com/2020/09/18/politics/trump-supreme-court-list-potential-nominees/index.html](https://www.cnn.com/2020/09/18/politics/trump-supreme-court-list-potential-nominees/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 04:13:29+00:00

President Donald Trump has updated a roster of more than 20 potential Supreme Court nominees in recent weeks, a list that includes prominent and lesser-known conservatives who would undoubtedly tilt the court further rightward if one were appointed.

## Trump lauds RBG but eager to nominate replacement: source
 - [https://www.cnn.com/2020/09/18/politics/trump-ruth-bader-ginsburg/index.html](https://www.cnn.com/2020/09/18/politics/trump-ruth-bader-ginsburg/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 04:13:20+00:00

President Donald Trump hailed Supreme Court Justice Ruth Bader Ginsburg as a "brilliant mind" in a statement Friday evening, praising her for demonstrating "that one can disagree without being disagreeable toward one's colleagues of different points of view."

## Ruth Bader Ginsburg was the second woman on the US Supreme Court. She was 87.
 - [https://www.cnn.com/2020/09/18/politics/ruth-bader-ginsburg-dead/index.html](https://www.cnn.com/2020/09/18/politics/ruth-bader-ginsburg-dead/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 04:10:06+00:00

Ginsburg was appointed in 1993 by President Bill Clinton
She had suffered from five bouts of cancer, most recently a recurrence in early 2020
She was revered for the clarity of her opinions

## McConnell vows Trump's nominee to replace Ginsburg will get Senate vote, setting up historic fight
 - [https://www.cnn.com/2020/09/18/politics/congress-fight-rgb-seat/index.html](https://www.cnn.com/2020/09/18/politics/congress-fight-rgb-seat/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 03:53:28+00:00

The top Democrat in the Senate, Chuck Schumer of New York, said Friday that a Supreme Court vacancy "should not be filled until we have a new president," signaling the looming fight to come in the Senate one the most polarizing issues in American politics following the death of Justice Ruth Bader Ginsburg.

## RBG's death means Republican senators will face the ultimate test of their loyalty to Trump
 - [https://www.cnn.com/2020/09/18/politics/ruth-bader-ginsburg-supreme-court-republican-senators-loyalty-trump/index.html](https://www.cnn.com/2020/09/18/politics/ruth-bader-ginsburg-supreme-court-republican-senators-loyalty-trump/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 03:49:56+00:00

The death of Supreme Court Justice Ruth Bader Ginsburg on Friday -- followed by Senate Majority Leader Mitch McConnell's statement that "Trump's nominee will receive a vote on the floor of the United States Senate" -- creates a stark choice for the 52 GOP senators that boils down to this: Just how loyal are you to President Donald Trump?

## Coronavirus can spread on airline flights, two studies show
 - [https://www.cnn.com/2020/09/18/health/coronavirus-airline-transmission-studies/index.html](https://www.cnn.com/2020/09/18/health/coronavirus-airline-transmission-studies/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 03:46:49+00:00

The young woman and her sister had traveled across Europe just as the coronavirus pandemic was taking off there, visiting Milan and Paris before heading to London.

## Hear RBG's most memorable speeches
 - [https://www.cnn.com/videos/politics/2020/09/18/ruth-bader-ginsburg-most-memorable-speeches-ak-orig.cnn](https://www.cnn.com/videos/politics/2020/09/18/ruth-bader-ginsburg-most-memorable-speeches-ak-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 02:55:36+00:00

Listen to some of Ruth Bader Ginsburg's most remarkable speeches over the years.

## Biden says Ginsburg's replacement should be chosen after the election
 - [https://www.cnn.com/us/live-news/ruth-bader-ginsburg-death-live-updates/index.html](https://www.cnn.com/us/live-news/ruth-bader-ginsburg-death-live-updates/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 02:46:31+00:00



## New revelations in US coronavirus response reinforce concerns about political motivation
 - [https://www.cnn.com/collections/intl-coronavirus-0918/](https://www.cnn.com/collections/intl-coronavirus-0918/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 02:45:17+00:00



## Burnett presses Trump Covid-19 adviser on no masks at rallies
 - [https://www.cnn.com/videos/politics/2020/09/18/dr-scott-atlas-mask-wearing-ebof-vpx.cnn](https://www.cnn.com/videos/politics/2020/09/18/dr-scott-atlas-mask-wearing-ebof-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 02:42:05+00:00

White House coronavirus adviser Dr. Scott Atlas defends President Donald Trump decision on wearing masks during his political rallies.

## Oregon is trying a furry approach to firefighting: goats
 - [https://www.cnn.com/2020/09/18/us/oregon-uses-goats-to-prevent-fires-trnd/index.html](https://www.cnn.com/2020/09/18/us/oregon-uses-goats-to-prevent-fires-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 01:50:21+00:00

An Oregon city has employed a specialized team to reduce the risk of wildfires-- and each member has four hooves.

## Against all the odds, the Forbidden City still stands six centuries later
 - [https://www.cnn.com/style/article/forbidden-city-china-architecture-600-years/index.html](https://www.cnn.com/style/article/forbidden-city-china-architecture-600-years/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 01:03:11+00:00

When the American writer David Kidd arrived in Beijing in 1981, having not seen China's capital for three decades, he found the city almost unrecognizable.

## As Asia's 'travel bubbles' fail to materialize, travelers face prospect of long winter at home
 - [https://www.cnn.com/travel/article/tourism-bubbles-asia-reopening-coronavirus/index.html](https://www.cnn.com/travel/article/tourism-bubbles-asia-reopening-coronavirus/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 00:47:32+00:00

With the end of the year approaching, travelers holding onto hope they may still get to enjoy a quick winter escape in Asia are facing some hard truths right now.

## Once a homeless street vendor, 18-year-old sensation has now been signed in a big-money sports deal
 - [https://www.cnn.com/2020/09/18/sport/yashasvi-jaiswal-ipl-rajasthan-royals-spt-intl/index.html](https://www.cnn.com/2020/09/18/sport/yashasvi-jaiswal-ipl-rajasthan-royals-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 00:46:53+00:00

A typical young adult, donned in a pink and purple club jersey, with long limbs and a sprouting mustache, Yashasvi Jaiswal quickly runs his fingers through his hair. The words of wisdom that follow belie his 18 years.

## Alabama governor on Hurricane Sally damage: 'It's really, really bad'
 - [https://www.cnn.com/2020/09/18/us/alabama-hurricane-sally-damage-really-bad/index.html](https://www.cnn.com/2020/09/18/us/alabama-hurricane-sally-damage-really-bad/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-19 00:32:10+00:00

Alabama Gov. Kay Ivey flew over the coastal areas of the state on Friday to view the destruction left by Hurricane Sally.

