# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Maybe NYC has a chance? The right people are leaving.
 - [https://www.youtube.com/watch?v=Pw9va6gcNhk](https://www.youtube.com/watch?v=Pw9va6gcNhk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-09-19 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
Having a Chase bank branch every 2-3 blocks is, in the opinion of many new Yorkers, excessive. I do not understand how it makes business sense to have a carbon copy of your business every 2-3 blocks & to pay the outrageous rents that make this possible. But they do - and the greed it's inspired in landlords as well as property tax collectors throughout the city is something I doubt many will miss. Alas, it comes a bit too late.

## Things I admire Apple for doing right
 - [https://www.youtube.com/watch?v=McYDFT0MxFE](https://www.youtube.com/watch?v=McYDFT0MxFE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-09-19 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W
1:50 please pet the cat
4:53 a challenger approaches 
6:05 so close. the poor neglected baby is even leaning into it
11:55 YES FINALLY
12:38 poor baby wants more petting
12:52 poor baby crushed under the evil and immoral hand of Louis
13:36 a challenger has departed
13:43 poor baby crushed under the evil and immoral hand of Louis
14:08 again ^
14:20 karate chopping poor cat
15:17 lil bit of face petting
15:58 big strechums
16:25 cat grabs Louis' arm
16:45 again ^

18:25 end of watch

