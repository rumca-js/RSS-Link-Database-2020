# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## The New Mutants - The Sad Final Dribble
 - [https://www.youtube.com/watch?v=J5L6VObgcMQ](https://www.youtube.com/watch?v=J5L6VObgcMQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-09-20 00:00:00+00:00

So I guess The New Mutants finally stumbled out into cinemas after keeping the world waiting for three years. Is it worth the wait? Is it bold new beginning for the X-Men series? You're kidding, right? 



Want to help support this channel? 



Patreon: https://www.patreon.com/TheCriticalDrinker
SubscribeStar: https://www.subscribestar.com/the-critical-drinker
My books on Amazon: https://www.amazon.com/Will-Jordan/e/B00BCO7SA8%3Fref=dbs_a_mng_rwt_scns_share

