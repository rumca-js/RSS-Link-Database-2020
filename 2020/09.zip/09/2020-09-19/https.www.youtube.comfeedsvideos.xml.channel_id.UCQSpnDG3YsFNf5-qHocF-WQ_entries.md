# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## iOS 14 - MAJOR Update: Best New Features
 - [https://www.youtube.com/watch?v=O7vX7PxrsZM](https://www.youtube.com/watch?v=O7vX7PxrsZM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2020-09-19 00:00:00+00:00

What's your favorite new features?
▼ Timestamps ▼
0:00 Intro
0:23 Widgets
1:30 App Library
2:53 Compact Calls & Siri
3:38 Picture-In-Picture
4:35 Messages Features
6:11 Privacy Features
8:34 Change Default Apps
9:07 Apple Mapps Features
9:28 Translation App
9:57 Safari Features
11:20 Airpods
11:37 App Clips
12:18 Hidden Features

⇒ Become a channel member for exclusive features! Check it out here: https://www.youtube.com/ThioJoe/join

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe

⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV

My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

#iOS14 #iPhone #Tech #ThioJoe

