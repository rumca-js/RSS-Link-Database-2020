# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## Future Islands: NPR Music Tiny Desk Concert From The Archives
 - [https://www.youtube.com/watch?v=7IgdpEjO_X8](https://www.youtube.com/watch?v=7IgdpEjO_X8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2020-09-20 00:00:00+00:00

We've been filming Tiny Desk concerts for more than 10 years. While revisiting our archives, we discovered that some of our earliest concerts never made it to YouTube! 
Watch Future Islands' Tiny Desk concert from 2011: https://www.npr.org/2011/05/16/136214794/future-islands-tiny-desk-concert

Frannie Kelley | May 16, 2011

Future Islands' members showed up with the biggest amplifier we've ever squeezed behind Bob Boilen's desk. Then, because they're such nice guys, they tried to keep it down. Tamping down the levels didn't dampen their intensity, though, and by the third song, the band and the crowd were struggling to keep it office-appropriate.

The band's goal, of course, was to make us break (it) down. "I want you to cry," said Sam Herring, who sings and writes all the lyrics. "I want you to feel the way I feel." He said that, in songs like "On the Water," he's using the fewest words possible to communicate most directly. Forget miscommunication, crossed signals, all that mess. "I want to crush," he says.

In case that sounds kind of cruel, Herring reminded us that crying is a good thing. Therapists tell some people to do it more often. What Future Islands is really going for, with the mordant wit in the lyrics, the melodramatic chord progressions and Herring's yowling, scratchy voice, is catharsis. And catharsis can happen in your head and in your heart.

"Some people hear the music and they want to dance. They don't hear the words. And some people hear the words, but they don't understand the other side of it," Herring said. "Those people come together and they share that space. They get the same thing out of it in the end, hopefully."

Future Islands came to our office and played some sad songs. The band did the aforementioned weeper "On the Water," as well as "The Ink Well," a song about saying goodbye to someone. Then they commanded us to move: Just before launching into "Walking Through That Door," a song about missing your hometown, Herring said, "Y'all can dance if you want to."

SET LIST
"On The Water"
"The Ink Well"
"Walking Through That Door"

