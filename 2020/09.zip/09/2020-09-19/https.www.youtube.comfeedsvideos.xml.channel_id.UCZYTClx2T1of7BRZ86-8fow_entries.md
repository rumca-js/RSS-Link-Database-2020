# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## 7 Real-Life Unicorns
 - [https://www.youtube.com/watch?v=73UnqZtknbk](https://www.youtube.com/watch?v=73UnqZtknbk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2020-09-20 00:00:00+00:00

Get your Real-Life Unicorn Stickers here!: https://store.dftba.com/collections/scishow/products/real-life-unicorns-sticker-pack

Unicorns may not exist on this planet, but Earth does have plenty of one-horned creatures that are just as remarkable, if not quite as majestic.

Get your sticker sheet: dftba.com/scishow

Hosted by: Hank Green

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Bd_Tmprd, Harrison Mills, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Sam Buck, Christopher R Boucher, Eric Jensen, Lehel Kovacs, Adam Brainard, Greg, Ash, Sam Lutfi, Piya Shedden, Scott Satovsky Jr, Charles Southerland, charles george, Alex Hackman, Chris Peters, Kevin Bealer
----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://insider.si.edu/2012/04/for-dentist-the-narwhals-smile-is-a-mystery-of-evolution/
https://www.nationalgeographic.com/animals/mammals/n/narwhal/
https://www.lakeviewdentalcare.com/reshape-vampire-fangs-tooth-recontouring/ 
https://www.nationalgeographic.com/news/2014/3/140318-narwhal-tusk-tooth-anatomy-ocean-animal-science/ 
https://magazine.scienceconnected.org/2016/04/search-unicorn-slightly-off-center/2/
https://anatomypubs.onlinelibrary.wiley.com/doi/full/10.1002/ar.22886
https://www.livescience.com/narwhal-facts.html
https://royalsocietypublishing.org/doi/full/10.1098/rsbl.2019.0950
https://sciencing.com/do-rhinos-use-horns-8069360.html
https://www.jstor.org/stable/2386524?seq=1
https://www.sciencedaily.com/releases/2006/11/061106144951.htm 
http://rhinorescueproject.org/wp-content/uploads/2015/03/2006_Hieronymus-Witmer-Ridgely_rhino_horn.pdf 
https://www.nature.com/articles/s41598-019-52527-5?ref=mainstreem-dotcom 
https://medium.com/wwfhk-e/species-for-sale-helmeted-hornbill-c6edec54d4ec 
https://www.aviary.org/animals/rhinoceros-hornbill 
https://bit.ly/30IBYRk
https://zslpublications.onlinelibrary.wiley.com/doi/abs/10.1111/j.1469-7998.1994.tb05262.x
https://www.tandfonline.com/doi/abs/10.1080/08912963.2014.985669 
https://www.nature.com/articles/s41598-019-38780-8 
https://www.upi.com/Science_News/2019/02/14/Scientists-finally-solved-the-mystery-of-the-cassowarys-casque/9671550082270/ 
https://www.nationalgeographic.com/animals/birds/h/horned-screamer/ 
https://sora.unm.edu/sites/default/files/journals/wilson/v098n02/p0243-p0256.pdf 
https://wildfowl.wwt.org.uk/index.php/wildfowl/article/viewFile/737/737 
http://www.theraphosidae.be/en/vogelspinnen/anatomy/ 
https://infinitespider.com/how-spiders-eat/ 
https://www.theraphosidae.be/en/ceratogyrus-marshalli/ 
https://www.georgiaaquarium.org/animal/bluespine-unicornfish/
https://www.waikikiaquarium.org/experience/animal-guide/fishes/surgeonfishes/unicorn-tang/
https://www.dailymail.co.uk/sciencetech/article-2195735/The-bizarre-unicorn-fish-nose-looks-human.html
https://bioone.org/journals/copeia/volume-104/issue-2/CE-15-270/Sexual-Dimorphisms-in-the-Bluespine-Unicornfish-Naso-unicornis-Acanthuridae/10.1643/CE-15-270.short
https://link.springer.com/article/10.1007/s10228-006-0373-z
https://www.sciencedaily.com/releases/2007/05/070530092859.htm
https://www.sciencenewsforstudents.org/article/what-would-it-take-to-make-a-unicorn 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3619469/
https://www.pnas.org/content/104/suppl_1/8661
https://journals.plos.org/plosgenetics/article?id=10.1371/journal.pgen.1007651
https://science.sciencemag.org/content/337/6096/860.abstract

Image Sources:
https://www.istockphoto.com/photo/narwhal-gm928991632-254763745
https://commons.wikimedia.org/wiki/File:Em_-_Monodon_monoceros_-_6.jpg
https://commons.wikimedia.org/wiki/File:Monodon_monoceros_MuMo.jpg 
https://bit.ly/2Hedc3P
https://bit.ly/33ClXvV
https://commons.wikimedia.org/wiki/File:Pod_Monodon_monoceros.jpg
https://www.storyblocks.com/video/stock/icebergs-against-stormy-sky-in-iceland-nvgh_6g1_x
https://www.istockphoto.com/photo/a-white-rhinoceros-in-natural-habitat-gm852494082-140567863
https://www.istockphoto.com/photo/white-rhinocerus-in-sabi-sands-gm172919989-5983378
https://www.istockphoto.com/photo/rhinos-fight-gm118199274-9649933
https://bit.ly/3myDtts
https://bit.ly/32EPOo7
https://bit.ly/2EejfnM
https://bit.ly/3iH4zfI
https://bit.ly/32BrjIy
https://bit.ly/3mxseBC
https://bit.ly/3c8poy7
https://bit.ly/2FJtvok
https://bit.ly/32Cj6DQ
https://bit.ly/2ZMjtKt
https://bit.ly/33F5VBo
https://bit.ly/32JRi0F
https://bit.ly/2EeisTQ
https://bit.ly/33DBxY7
https://bit.ly/2FIq01B
https://bit.ly/32Cfvpn
https://bit.ly/3mt9svf
https://bit.ly/3iFAwVR

## The Northern Hemisphere’s Very Own Giant Penguins (Sort Of)
 - [https://www.youtube.com/watch?v=xshZZKWBNd0](https://www.youtube.com/watch?v=xshZZKWBNd0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2020-09-19 00:00:00+00:00

Today, penguins are found mainly in the Southern Hemisphere.  But fossils have revealed giant lookalikes to these swimming birds further up north, spurring questions of how they evolved and what happened to them.

Hosted by: Stefan Chin

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Bd_Tmprd, Harrison Mills, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Sam Buck, Christopher R Boucher, Eric Jensen, Lehel Kovacs, Adam Brainard, Greg, Ash, Sam Lutfi, Piya Shedden, Scott Satovsky Jr, Charles Southerland, charles george, Alex Hackman, Chris Peters, Kevin Bealer
----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://onlinelibrary.wiley.com/doi/abs/10.1111/jzs.12400
https://www.nature.com/articles/s41467-017-01959-6
https://doi.org/10.1002/9781119990475.ch6
https://onlinelibrary.wiley.com/doi/pdf/10.1111/j.1096-0031.2006.00116.x
https://animaldiversity.org/accounts/Aptenodytes_forsteri/
https://www.nationalgeographic.com/animals/birds/e/emperor-penguin/
https://www.wwf.org.uk/learn/fascinating-facts/emperor-penguins
https://www.eurekalert.org/pub_releases/2020-06/cm-nza062820.php
https://sora.unm.edu/sites/default/files/p00755-p00759.pdf
https://www.youtube.com/watch?v=zzgk__0bezk
https://www.pnas.org/content/113/43/12006
https://www.youtube.com/watch?v=1Cp1n_vPvYY
https://www.sciencedirect.com/science/article/pii/S0031018213003659?casa_token=sfclGSkleGsAAAAA:rVxG5tWIcXA8K1OiAlD1Az6IOraoitAMGzIXla_AvWf-3bHguAyMvkfe83BkDvq1LXM1eNRoY_s

Image Sources:
https://www.eurekalert.org/multimedia/pub/236024.php?from=468991
https://www.istockphoto.com/vector/penguin-distribution-world-map-cartoon-vector-gm937969268-256516089
https://www.istockphoto.com/photo/isolated-emperor-penguin-gm146906245-7196097
https://www.istockphoto.com/vector/city-people-set-gm523895883-52105134
https://commons.wikimedia.org/wiki/File:Copepteryx_hexeris.jpg
https://commons.wikimedia.org/wiki/File:Kairuku.png
https://commons.wikimedia.org/wiki/File:Kumimanu_NT.jpg
https://www.istockphoto.com/photo/conception-of-diving-penguin-plunged-in-blue-water-gm528906860-93135745
https://www.istockphoto.com/photo/gannets-diving-for-fish-gm471959659-30387918
https://www.istockphoto.com/photo/chinstrap-penguins-gm1196653143-341419930
https://www.istockphoto.com/photo/great-shearwater-gm1271602483-374141883
https://www.istockphoto.com/photo/northern-gannet-gm1062506874-284062944
https://www.istockphoto.com/photo/orca-killer-whale-while-jumping-gm498463926-79666863
https://www.istockphoto.com/photo/weddell-seal-in-antarctica-gm684178336-125635327
https://www.istockphoto.com/photo/seal-lion-on-the-rocks-gm1182254766-331908013
https://www.istockphoto.com/photo/king-penguins-and-seals-panorama-south-georgia-antarctic-islands-gm1222212098-358562089
https://www.istockphoto.com/photo/emperor-penguin-isolated-on-white-background-gm841158558-137575621
https://www.istockphoto.com/photo/white-breasted-cormorant-gm503392686-82502703

