## The Patriarchy Paradox
 - [https://www.youtube.com/watch?v=wTHgMxQEoPI](https://www.youtube.com/watch?v=wTHgMxQEoPI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCHDdgIb3r-uK9tF9L2F-KJA
 - date published: 2020-09-19 20:37:21+00:00

The Patriarchy Paradox

