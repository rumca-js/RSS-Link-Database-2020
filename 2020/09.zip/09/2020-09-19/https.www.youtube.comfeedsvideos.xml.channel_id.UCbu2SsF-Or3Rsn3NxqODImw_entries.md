# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Fall Guys - Top 10 Funniest Moments So Far
 - [https://www.youtube.com/watch?v=ThQFjv_HkV0](https://www.youtube.com/watch?v=ThQFjv_HkV0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-09-20 00:00:00+00:00

Fall Guys has had some silly moments from its beginnings, so here are our top 10 picks of it's most hilarious clips.

## Hades Review
 - [https://www.youtube.com/watch?v=kKN4dfNg5kQ](https://www.youtube.com/watch?v=kKN4dfNg5kQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-09-20 00:00:00+00:00

Hades' quick and reactive combat combined with unique and intricate storytelling sets it apart from other roguelikes.

## Call of Duty Cold War VS. Modern Warfare: The Biggest Differences
 - [https://www.youtube.com/watch?v=plyX2t5I15c](https://www.youtube.com/watch?v=plyX2t5I15c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-09-19 00:00:00+00:00

We’re going to take a deep dive into differences between Call Of Duty: Black Ops Cold War and Modern Warfare to figure out which game may be right for you.

## Spelunky 2 Review
 - [https://www.youtube.com/watch?v=cMfYwBV8Feg](https://www.youtube.com/watch?v=cMfYwBV8Feg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-09-19 00:00:00+00:00

Spelunky 2 is a successful evolution of what made the original Spelunky work.

Andrew played 22 hours of Spelunky 2 for this review. The vast majority of that time was spent in Adventure mode, with a few rounds against bots in the multiplayer Arena and two cracks at the Daily Challenge. He left no pug behind and no turkey un-roasted. Code was provided by the publisher.

## What The Hell Happened To Splinter Cell
 - [https://www.youtube.com/watch?v=5zzYSPt0hB8](https://www.youtube.com/watch?v=5zzYSPt0hB8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-09-19 00:00:00+00:00

It kind of feels like Ubisoft is just making fun of us at this point, right? Sam Fisher is now in Ghost Recon, Elite Squad, Rainbow Six, and an upcoming VR game, but he still hasn't been in his own standalone Splinter Cell game since 2013. It's almost like Ubisoft knows that fans like the character but forget that they like him because they enjoy Splinter Cell. 

In the video above, Jake Dekker expresses his exasperation at the lack of Splinter Cell games in recent years, especially in the face of Ubisoft continuing to support its other major tentpole franchises like Ghost Recon, Rainbow Six, Far Cry, The Division, and Assassin's Creed. From a financial standpoint, sure, it makes sense. Splinter Cell doesn't sell as well. That doesn't change the fact that Ubisoft has left Splinter Cell fans thirsty for a drop of content for nearly a decade.

Jake posits a few theories as to why Ubisoft hasn't returned to Splinter Cell for quite some time--namely that, until quite recently, all of Ubisoft games were being developed with an almost singular gameplay philosophy that goes against the Splinter Cell style. Ubisoft CEO Yves Guillemot has also said that Ubisoft felt a bit of fan pressure while constructing 2013's Splinter Cell: Blacklist, which may be another possible influence on the developer's decision to steer clear of the franchise ever since.

As of right now, Ubisoft plans to conclude 2020 with three open world action games releasing back to back. In October, you'll be able to take part in a hacker revolution in Watch Dogs Legion. Then in November, Assassin's Creed Valhalla transports the franchise to the time of Vikings. Finally, December's Immortals Fenyx Rising is a Greek mythology-inspired game that plays awfully similar to The Legend of Zelda: Breath of the Wild. But no Splinter Cell. Not this year, anyway.

