# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Andrea Swensson interviews #MeTooMPLS artists
 - [https://www.youtube.com/watch?v=Suw4KlEWE_I](https://www.youtube.com/watch?v=Suw4KlEWE_I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-09-20 00:00:00+00:00

#MeTooMPLS is a forthcoming compilation of original songs by Minnesota artists, “lovingly crafted in the pursuits of agency and equality.” On Sept. 15, Local Show host Andrea Swensson interviewed a selection of artists contributing to the compilation: Averil Bach, Mary Bue, Elska, Annie Fitzgerald, JØUR, Annie Mack, Mayda, Linnea Mohn, Sarah Morris, r0, Tina Schlieske, Ashleigh Still, and Katy Vernon. (You'll also see producer Jesse Wiza on the call.)

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

