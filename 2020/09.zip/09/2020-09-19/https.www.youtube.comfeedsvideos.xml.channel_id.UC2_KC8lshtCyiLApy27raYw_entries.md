# Source:KnowledgeHusk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw, language:en-US

## Nintendo Just Set A Fun Precedent And We All Suffer
 - [https://www.youtube.com/watch?v=IxrMAGv2u60](https://www.youtube.com/watch?v=IxrMAGv2u60)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw
 - date published: 2020-09-20 00:00:00+00:00

Super Mario, or not so super. Rarely bros. Nintendo has lied to us.. Probably. It’s a video about Mario and stuff what do you want.
Could we be in for the next big “anti-consumer” mess? Will all games be limited releases? Whooooooooo knows?
Well I don’t but I’m gonna talk about it anyway.

Twitter: https://twitter.com/KnowledgeHubTy

Soundcloud: https://soundcloud.com/user-503704039

Patreon: https://www.patreon.com/theknowledgehub

Second Channel: https://www.youtube.com/channel/UC-KL04Ra6E1Du0pFawN4pWg

Spotify: https://open.spotify.com/artist/3STpelEilrthF8UxsQTaaw?si=52TH_ZKTQhaKhfnK1Jomfg

My website: www.borfed.com

