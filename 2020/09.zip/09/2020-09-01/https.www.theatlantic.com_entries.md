## Academics Are Really, Really Worried About Their Freedom
 - [https://www.theatlantic.com/ideas/archive/2020/09/academics-are-really-really-worried-about-their-freedom/615724/](https://www.theatlantic.com/ideas/archive/2020/09/academics-are-really-really-worried-about-their-freedom/615724/)
 - RSS feed: https://www.theatlantic.com
 - date published: 2020-09-01 22:02:49+00:00

Academics Are Really, Really Worried About Their Freedom

