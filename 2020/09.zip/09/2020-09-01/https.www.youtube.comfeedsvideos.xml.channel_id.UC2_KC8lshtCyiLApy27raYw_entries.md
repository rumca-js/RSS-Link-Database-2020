# Source:KnowledgeHusk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw, language:en-US

## 2000s Disney Films: Before the Mouse Bought Everything
 - [https://www.youtube.com/watch?v=-FbVcQXSv2U](https://www.youtube.com/watch?v=-FbVcQXSv2U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw
 - date published: 2020-09-01 00:00:00+00:00

It’s not everyday that  a masterpiece is made. It’s not every month, or every year. But sometimes, just sometimes, a masterpiece is never made. Does that make sense? No. And neither do these movies.

Join me as I venture forth the swamp that is Disney live action films of the 2000s. An era of unprecedented creativity, and uh, failure. A time where animals talked and pirates sailed, but best of all, the country bears.
It’s gonna be a bumpy ride.

Twitter:
https://twitter.com/KnowledgeHubTy

Soundcloud:
https://soundcloud.com/user-503704039

Patreon:
https://www.patreon.com/theknowledgehub

Second Channel:
https://www.youtube.com/channel/UC-KL04Ra6E1Du0pFawN4pWg

Spotify:
https://open.spotify.com/artist/3STpelEilrthF8UxsQTaaw?si=52TH_ZKTQhaKhfnK1Jomfg

My website:
www.borfed.com

Additional footage credits:
LMG Vids
RetroWDW
SoCal Attractions 360
Disney Shopaholic
ThePresidentialTourist
Theme Park Worldwide

