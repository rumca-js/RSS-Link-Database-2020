# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## TENET - Movie Review
 - [https://www.youtube.com/watch?v=i358Rws1SV0](https://www.youtube.com/watch?v=i358Rws1SV0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-09-01 00:00:00+00:00

Christopher Nolan gives us his take on a spy thriller. Here's my review for TENET!

#TENET

