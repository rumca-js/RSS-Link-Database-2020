# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## What It’s Like Getting Censored on YouTube
 - [https://www.youtube.com/watch?v=RGxbaxviRVw](https://www.youtube.com/watch?v=RGxbaxviRVw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-09-02 00:00:00+00:00

Grab your LMNT Electrolytes Here - https://drinklmnt.com/jp

What’s it like getting censored on YouTube? As a content creator, you might be wondering if freedom of speech is right for you. You’ll see what it’s like having the constitutional amendment called community guidelines trump the constitutional right called freedom of speech.

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

## New Revelations on the COVID Death Count
 - [https://www.youtube.com/watch?v=P0y6M-N8wOE](https://www.youtube.com/watch?v=P0y6M-N8wOE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-09-01 00:00:00+00:00

https://www.dropbox.com/sh/8rtiuq0y91s4ezj/AADA7xyRZsYbcze8uFX3vSjWa?dl=0

You’re more than welcome upload this video to any and all of your social platforms. Just download the video from the above dropbox link and then upload it to wherever you’d like! We’ll make the censors work a little harder for their money.

With the stunning information just released by the CDC about the COVID death count, you might be wondering what to do. Should you be living with more fear or should you be living with a lot more fear? Well in this video, your trusted health authority will be telling you exactly what to think and feel.

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

