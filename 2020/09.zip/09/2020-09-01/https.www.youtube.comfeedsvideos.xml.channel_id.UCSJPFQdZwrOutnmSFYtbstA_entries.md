# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Tenet - The Best and Worst of Christopher Nolan
 - [https://www.youtube.com/watch?v=CDMs9TNdG8E](https://www.youtube.com/watch?v=CDMs9TNdG8E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-09-02 00:00:00+00:00

Join me as I try to unravel the mystery of Tenet, starring John David Washington, Robert Pattinson and Kenneth Branagh.

