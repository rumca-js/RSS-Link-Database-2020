# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Trump interjects when pair of Black pastors are asked if police violence is systemic
 - [https://www.cnn.com/2020/09/01/politics/donald-trump-pastors-systemic-racism/index.html](https://www.cnn.com/2020/09/01/politics/donald-trump-pastors-systemic-racism/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 23:49:54+00:00

• Trump backs law enforcement in Kenosha visit
• LIVE: Trump visit 'a lot of talk': Kenosha official

## Lawmaker brought her infant to work after a request to vote by proxy was denied
 - [https://www.cnn.com/2020/09/01/us/buffy-wicks-california-baby-trnd/index.html](https://www.cnn.com/2020/09/01/us/buffy-wicks-california-baby-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 23:29:20+00:00

A California assemblywoman brought her newborn daughter to the senate floor on Monday after her request to vote by proxy was denied, despite her concerns over Covid-19, highlighting the struggle of working mothers during the pandemic.

## Trump interjects when pair of Black pastors are asked if police violence is systemic
 - [https://www.cnn.com/collections/trump-kenosha-0901/](https://www.cnn.com/collections/trump-kenosha-0901/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 22:54:15+00:00



## Deciphering the 'red mirage,' the 'blue shift,' and the uncertainty surrounding US election results
 - [https://www.cnn.com/2020/09/01/politics/2020-election-count-red-mirage-blue-shift/index.html](https://www.cnn.com/2020/09/01/politics/2020-election-count-red-mirage-blue-shift/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 22:49:42+00:00

It's a tried-and-true American tradition to stay up late on Election Night, watch results pouring in, and find out who the next President will be. But with a historic pivot toward mail-in voting due to the coronavirus, this Election Night could mark the beginning, not the end, of the process, and giving voters a false sense of who is winning, according to a wide array of experts.

## US won't join global coronavirus vaccine effort led by WHO
 - [https://www.cnn.com/2020/09/01/politics/coronavirus-vaccine-world-health-organization/index.html](https://www.cnn.com/2020/09/01/politics/coronavirus-vaccine-world-health-organization/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 22:46:49+00:00

The United States will not participate in an international effort to develop and distribute a coronavirus vaccine because the initiative is tied to the World Health Organization, the White House said Tuesday.

## Jill Biden on Trump's America: There is so much chaos
 - [https://www.cnn.com/videos/politics/2020/09/01/jill-biden-schools-reopening-trump-golodryga-intv-lead-vpx.cnn](https://www.cnn.com/videos/politics/2020/09/01/jill-biden-schools-reopening-trump-golodryga-intv-lead-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 21:37:23+00:00

Jill Biden, the wife of Democratic presidential nominee Joe Biden, says President Donald Trump and Education Secretary Betsy DeVos "didn't have a strategy" to reopen schools this fall amid the coronavirus pandemic.

## Ed Sheeran and Cherry Seaborn announce the birth of their first child
 - [https://www.cnn.com/2020/09/01/entertainment/ed-sheeran-cherry-seaborn-baby-scli-intl-gbr/index.html](https://www.cnn.com/2020/09/01/entertainment/ed-sheeran-cherry-seaborn-baby-scli-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 20:36:07+00:00

Ed Sheeran has announced the birth of his first child with his wife Cherry Seaborn.

## Stephen Colbert opens up on loss of his father
 - [https://www.cnn.com/videos/us/2020/09/01/stephen-colbert-grief-acfc-full-episode-vpx.cnn](https://www.cnn.com/videos/us/2020/09/01/stephen-colbert-grief-acfc-full-episode-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 20:17:14+00:00

CNN's Anderson Cooper has an emotional conversation with "The Late Show" host Stephen Colbert about grief, loss and healing. Watch "Full Circle" every Monday, Tuesday and Friday at 6pm E.T.

## Want Samsung's new folding smartphone? It'll set you back $1,999
 - [https://www.cnn.com/2020/09/01/tech/samsung-galaxy-z-fold-2-price/index.html](https://www.cnn.com/2020/09/01/tech/samsung-galaxy-z-fold-2-price/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 19:41:06+00:00

Would you fork over $1,999 for a smartphone? Samsung hopes many people will.

## 'It's blatant racism': Watch CNN anchor's reaction to Fox Host
 - [https://www.cnn.com/videos/politics/2020/09/01/trump-kenosha-portland-falsehoods-keilar-vpx.cnn](https://www.cnn.com/videos/politics/2020/09/01/trump-kenosha-portland-falsehoods-keilar-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 19:37:24+00:00

CNN's Brianna Keilar discusses President Trump's rhetoric about protests and violence in the US following the killing of George Floyd and the shooting of Jacob Blake.

## The White House needs to explain what really happened on Trump's Walter Reed visit
 - [https://www.cnn.com/2020/09/01/politics/trump-walter-reed-white-house-physical/index.html](https://www.cnn.com/2020/09/01/politics/trump-walter-reed-white-house-physical/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 18:17:54+00:00

Days before Thanksgiving 2019, President Donald Trump made an unscheduled visit to Walter Reed hospital, a trip the White House later dismissed as nothing more than a "quick exam and labs" as part of his annual physical.

## Dozens of Black former franchisees sue McDonald's over alleged discrimination
 - [https://www.cnn.com/2020/09/01/business/mcdonalds-black-franchisees-lawsuit/index.html](https://www.cnn.com/2020/09/01/business/mcdonalds-black-franchisees-lawsuit/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 17:28:46+00:00

A group of 52 former Black franchise operators is suing McDonald's over alleged racial discrimination.

## The hospitals where Covid-19 patients wait for others to die before they can be put on a ventilator
 - [https://www.cnn.com/2020/09/01/middleeast/syria-coronavirus-hospitals-intl/index.html](https://www.cnn.com/2020/09/01/middleeast/syria-coronavirus-hospitals-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 16:29:53+00:00

Catastrophic conditions in chaotic ill-equipped hospitals overflowing with Covid-19 patients -- patients forced to wait for others to die so they can be put on ventilators that could save their lives.

## Naomi Osaka wears mask honoring Breonna Taylor before winning US Open match
 - [https://www.cnn.com/2020/09/01/us/naomi-osaka-breonna-taylor-mask-us-open-trnd/index.html](https://www.cnn.com/2020/09/01/us/naomi-osaka-breonna-taylor-mask-us-open-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 15:52:12+00:00

Naomi Osaka may have won her first-round match at the US Open -- but she wanted to ensure people didn't forget about Breonna Taylor.

## In Xi's China, not even the propagandists are safe
 - [https://www.cnn.com/2020/09/01/media/china-cgtn-cheng-lei-rsdl-intl-hnk/index.html](https://www.cnn.com/2020/09/01/media/china-cgtn-cheng-lei-rsdl-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 15:48:37+00:00

In Cheng Lei's last WeChat post before she disappeared, the Chinese state TV host posed in a bright green dress on a Shake Shack-branded rickshaw outside the newly opened Beijing branch of the American restaurant chain.

## Elon Musk is now richer than Mark Zuckerberg
 - [https://www.cnn.com/2020/09/01/investing/musk-richer-than-zuckerberg/index.html](https://www.cnn.com/2020/09/01/investing/musk-richer-than-zuckerberg/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 15:39:41+00:00

Elon Musk's net worth is now $115 billion, pushing him past Facebook CEO Mark Zuckerberg on the list of the world's richest people, according to Bloomberg.

## See the stunning images shortlisted for wildlife photography award
 - [https://www.cnn.com/travel/article/wildlife-photography-awards-2020-scli-intl-gbr-scn/index.html](https://www.cnn.com/travel/article/wildlife-photography-awards-2020-scli-intl-gbr-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 15:38:07+00:00

Possums, primates and disappearing habitats all feature among the first images to be released from the Wildlife Photographer of the Year 2020 awards.

## Mastodons migrated extreme distances due to climate change before going extinct, study says
 - [https://www.cnn.com/2020/09/01/world/mastodon-climate-change-study-scn/index.html](https://www.cnn.com/2020/09/01/world/mastodon-climate-change-study-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 15:21:00+00:00

American mastodons migrated many times across thousands of miles up and down the North American continent over 800,000 years due to climate change, before going extinct 11,000 years ago, according to a new study.

## How Covid-19 misinformation circulates on social media
 - [https://www.cnn.com/videos/health/2020/09/01/coronavirus-misinformation-social-media-intv-ctn-vpx.cnn](https://www.cnn.com/videos/health/2020/09/01/coronavirus-misinformation-social-media-intv-ctn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 15:15:46+00:00

CNN's Don Lemon speaks to medical analyst Dr. Seema Yasmin and Dr. Craig Spencer about the rampant coronavirus misinformation circulating on social media and the negative implications this has.

## The unspoken long-term symptoms of Covid-19
 - [https://www.cnn.com/2020/09/01/health/long-haul-coronavirus-doctor-patient/index.html](https://www.cnn.com/2020/09/01/health/long-haul-coronavirus-doctor-patient/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 15:11:33+00:00

• Why a rushed vaccine is 'colossally stupid'
• LIVE: No evidence to back plasma treatment, expert panel says, despite FDA authorization
• The hospitals where patients wait for others to die in order to secure a ventilator

## CNN fact checker: 'It's almost too stupid to fact-check'
 - [https://www.cnn.com/videos/politics/2020/09/01/trump-disinformation-biden-ingraham-shadow-daniel-dale-nr-vpx.cnn](https://www.cnn.com/videos/politics/2020/09/01/trump-disinformation-biden-ingraham-shadow-daniel-dale-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 15:02:13+00:00

CNN's Daniel Dale fact-checks the disinformation about Vice President Joe Biden spread by President Trump and members of the GOP in interviews and on social media.

## China accuses Indian troops of trespassing as tensions rise
 - [https://www.cnn.com/2020/09/01/asia/india-china-pangong-tso-lake-dispute-intl-hnk/index.html](https://www.cnn.com/2020/09/01/asia/india-china-pangong-tso-lake-dispute-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 14:52:00+00:00

China's government has accused Indian troops of illegally trespassing onto Chinese territory, in comments that could set the stage for a second tense border standoff between the two nuclear powers in just three months.

## Internet loves this 12-year-old skateboarder's comeback moment
 - [https://www.cnn.com/videos/us/2020/08/31/skateboarder-flying-comeback-jeanne-moos-vpx.cnn](https://www.cnn.com/videos/us/2020/08/31/skateboarder-flying-comeback-jeanne-moos-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 13:12:01+00:00

A 12-year-old skateboarder makes a flying comeback after a scary fall. Jeanne Moos reports on a "Sky" with no limits.

## How Macron's visit sent Lebanon back to 1920
 - [https://www.cnn.com/2020/09/01/middleeast/lebanon-macron-beirut-visit-intl/index.html](https://www.cnn.com/2020/09/01/middleeast/lebanon-macron-beirut-visit-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 12:55:13+00:00

On Lebanon's centenary Tuesday, French jets whizzed over the mountains of its former mandate as a French president planted a cedar tree declaring the country's "rebirth."

## The Rolls-Royce Ghost was so eerily quiet inside the engineers had to make it louder
 - [https://www.cnn.com/2020/09/01/success/rolls-royce-ghost-sedan/index.html](https://www.cnn.com/2020/09/01/success/rolls-royce-ghost-sedan/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 12:54:38+00:00

Rolls-Royce unveiled its all new Ghost Tuesday, and it looks strikingly different from any Rolls-Royce that has ever come before. The Ghost is the ultra-luxury automaker's slightly smaller and somewhat less expensive sedan, and the new version is far more understated than its predecessor.

## A 'fake' Rembrandt painting that was stored in a basement for decades might be real
 - [https://www.cnn.com/style/article/rembrandt-oxford-painting-analysis-scli-gbr-intl/index.html](https://www.cnn.com/style/article/rembrandt-oxford-painting-analysis-scli-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 12:40:54+00:00

A Rembrandt painting that was thought to be fake and was stashed in a basement for decades may in fact be genuine, according to experts who believe it was painted on wood from the same tree as other 17th century masterpieces.

## Covid-19 built a 'northern wall' between the US and Canada. It could stay up longer than anyone expected
 - [https://www.cnn.com/travel/article/covid-wall-canada-us-trnd/index.html](https://www.cnn.com/travel/article/covid-wall-canada-us-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 11:47:43+00:00

There were no bricks and mortar, no fencing or cement, no cross-border diplomatic skirmish, just two government orders. And that was enough to essentially shut down the world's longest international border for visitors.

## Two huge snakes fall through man's kitchen ceiling
 - [https://www.cnn.com/2020/09/01/asia/brisbane-carpet-pythons-ceiling-scli-intl/index.html](https://www.cnn.com/2020/09/01/asia/brisbane-carpet-pythons-ceiling-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 11:21:10+00:00

A man in Brisbane, Australia, returned home to find two huge snakes had fallen through his kitchen ceiling on Monday.

## Can these 'living' clothes clean the air?
 - [https://www.cnn.com/collections/intl-fashion-coronavirus/](https://www.cnn.com/collections/intl-fashion-coronavirus/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 10:52:51+00:00



## Samsung heir indicted over controversial merger
 - [https://www.cnn.com/2020/09/01/tech/samsung-jay-y-lee-hnk-intl/index.html](https://www.cnn.com/2020/09/01/tech/samsung-jay-y-lee-hnk-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 10:39:14+00:00

Samsung's de facto leader Lee Jae-yong may be headed back to prison.

## What quarantining around the world really looks like
 - [https://www.cnn.com/travel/article/quarantining-around-the-world-reader-images/index.html](https://www.cnn.com/travel/article/quarantining-around-the-world-reader-images/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 10:31:41+00:00

It's hard to remember a time when quarantine wasn't a regular part of our vocabulary, yet, for most of us, it was only six months ago that we'd rarely heard the word used or spoken it aloud -- outside of describing a scene from an historical novel or a Hulu show.

## Jürgen Schadeberg, the legendary photographer who chronicled Mandela and the apartheid experience
 - [https://www.cnn.com/2020/09/01/africa/jrgen-schadeberg-apartheid-photographer/index.html](https://www.cnn.com/2020/09/01/africa/jrgen-schadeberg-apartheid-photographer/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 09:14:58+00:00

A young Miriam Makeba dancing with her eyes closed. Her future husband Hugh Masekela receiving a trumpet from "Satchmo", the jazz legend better known as Louis Armstrong.

## Massive 14-foot crocodile captured at tourist spot in Australia
 - [https://www.cnn.com/2020/09/01/asia/australia-crocodile-intl-hnk-scli/index.html](https://www.cnn.com/2020/09/01/asia/australia-crocodile-intl-hnk-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 07:39:46+00:00

An enormous saltwater crocodile measuring 14.4 feet (4.3 meters) has been caught at a remote tourist hotspot in Australia's Northern Territory.

## Cracks in Trump's coalition are showing
 - [https://www.cnn.com/2020/09/01/politics/us-election-biden-gop-endorsements/index.html](https://www.cnn.com/2020/09/01/politics/us-election-biden-gop-endorsements/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 04:48:40+00:00

Joe Biden is attracting more crossover endorsements from prominent members of the opposing party than any other presidential candidate from either side in decades. That doesn't guarantee the former vice president victory in November, but history suggests it could signal a lasting break in the Republican coalition that provides new opportunities to Democrats for years to come.

## Michael B. Jordan pens powerful tribute to Chadwick Boseman
 - [https://www.cnn.com/2020/08/31/entertainment/michael-b-jordan-chadwick-boseman-trnd/index.html](https://www.cnn.com/2020/08/31/entertainment/michael-b-jordan-chadwick-boseman-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 01:00:10+00:00

One of the last times Chadwick Boseman and Michael B. Jordan spoke, Boseman said they were forever linked, Jordan wrote on Instagram Monday.

## India accuses China of 'provocative military movements' on border
 - [https://www.cnn.com/2020/08/31/asia/india-china-border-intl-hnk-scli/index.html](https://www.cnn.com/2020/08/31/asia/india-china-border-intl-hnk-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 00:49:41+00:00

India on Monday accused Chinese troops of taking "provocative" actions near a disputed border high in the Himalayas, violating previous deals between the two nuclear-armed rivals intended to ease tensions in the region.

## NATO: Russia's attempt to intercept US bomber 'significant' violation of law
 - [https://www.cnn.com/2020/08/31/politics/russian-jet-nato-b-52/index.html](https://www.cnn.com/2020/08/31/politics/russian-jet-nato-b-52/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 00:39:33+00:00

A Russian military jet violated NATO airspace on Friday while it was attempting to intercept a US Air Force B-52 bomber flying near the Danish island of Bornholm, the alliance said in a statement Monday, calling the incident a "significant violation of international law."

## Some Louisiana residents won't have power for weeks, if not months, after Hurricane Laura
 - [https://www.cnn.com/2020/08/31/us/louisiana-hurricane-laura-damage/index.html](https://www.cnn.com/2020/08/31/us/louisiana-hurricane-laura-damage/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-01 00:00:24+00:00

Fifteen years after Hurricane Katrina devastated Louisiana, the state faces another long, grueling recovery in the wake of Hurricane Laura.

