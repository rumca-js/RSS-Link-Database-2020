# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## Elon Musk’s Neuralink – Ex-Employees Reveal Company Struggles
 - [https://www.youtube.com/watch?v=6eA_JIDzza0](https://www.youtube.com/watch?v=6eA_JIDzza0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2020-09-02 00:00:00+00:00

Limited Edition ColdFusion Merch:
INTERNATIONAL: https://store.coldfusioncollective.com/
AUSTRALIA: https://shop.coldfusioncollective.com/

Previous Neuralink Episode (A Deeper Look): https://youtu.be/9uRK8Delzvk

--- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. 

If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- New Thinking Book written by Dagogo Altraide ---
This book was rated the 9th best technology history book by book authority.
In the book you’ll learn the stories of those who invented the things we use everyday and how it all fits together to form our modern world.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

--- ColdFusion Social Media ---
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusionTV

--- ColdFusion Podcast links ---
Google Podcasts - http://bit.ly/2xo8doR
Apple Podcasts - https://apple.co/2WI2IeU
Spotify - https://spoti.fi/2KT1taB
Stitcher - http://bit.ly/2WI4f4E

//Soundtrack//

Kazukii – Milo

Instupendo – Boy

Kevin MacInnis - Miss the Feeling of Being Missed

Andre Sobota - Concluded (Original Mix)

Relatvty - Until Then

Lemongrass – Heartbreaker

Burn Water - Nostalgia Dreams


» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide

Why are you still reading?

