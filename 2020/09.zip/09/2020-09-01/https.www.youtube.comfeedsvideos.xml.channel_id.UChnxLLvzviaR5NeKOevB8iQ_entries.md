# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## OP-1 08-25-20 (The Devil Deserves Better)
 - [https://www.youtube.com/watch?v=wvATgLQjrl8](https://www.youtube.com/watch?v=wvATgLQjrl8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2020-09-02 00:00:00+00:00

Get the album: https://fanlink.to/rmrhindsight
Let's make a future funk track in the Teenage Engineering OP-1.
I used samples from here: https://op1.fun/users/jjbbllkk/packs/op-1-082320
Patrons get the finished track and op-1 stems: https://www.patreon.com/redmeansrecording
YouTube video in the final visualizer: https://www.youtube.com/watch?v=aH3urXkaDc0&
Visualizer made using: https://videohive.net/item/trapwix-paradox-music-visualizer/22033257
Final track at: 13:23
This will be on Spotify soon!
------------------------------------
Thank you for watching. My name is Jeremy, and this is Red Means Recording. I've been making music for a few decades now, and this channel is a place to make music and to talk about the tools and techniques to make music with. We'll use synths, drum machines, modular gear, and software. 

If you'd like to support the channel, I have a Patreon:  http://bit.ly/rmrpatreon

I have music as "Jeremy Blake" on all the major services: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

I have some merch here: http://bit.ly/rmrshirts

And you can connect with me here: 
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

