# Source:Techaltar, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA, language:en-US

## Revisiting old videos - How wrong was I?
 - [https://www.youtube.com/watch?v=UvtVacoW0Ss](https://www.youtube.com/watch?v=UvtVacoW0Ss)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA
 - date published: 2020-09-02 00:00:00+00:00

Sponsored by Skillshare. The first 1000 people who click this link will get 2 free months of Skillshare Premium: https://skl.sh/techaltar0920


▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► About the video ◄◄◄

We've just reached episode 69 (very nice!) of The Story Behind series. To celebrate, I've decided to take a look back at some of my first videos in the series and see how well they have held up over time!

New operating systems: https://youtu.be/-N80hzTpglQ
Stock Android: https://youtu.be/jGmW_lHRZk4
Pixel: https://youtu.be/br-7RDIcG5Q
Windows 10 Mobile: https://youtu.be/7O_EvSTth-A
European smartphones: https://youtu.be/zjcVPZCG4sM
Xiaomi's miracle: https://youtu.be/yUd7-0RO1bw

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Quiz ◄◄◄

Weekly tech quiz: 
https://crrowd.com/quiz 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► TechAltar links ◄◄◄

Merch: 
http://enthusiast.store 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 

If you want to support TechAltar directly: 
https://flattr.com/@techaltar 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions ◄◄◄

Music: 
Majestic Casual - Kenny Segal - Procrastination: http://bit.ly/29CWdE2

Regular music by Edemski: https://soundcloud.com/edemski

