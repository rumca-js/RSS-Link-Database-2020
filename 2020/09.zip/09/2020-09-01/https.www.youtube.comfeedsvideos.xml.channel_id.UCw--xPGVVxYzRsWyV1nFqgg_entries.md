# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Harrow The Ninth - REVIEW
 - [https://www.youtube.com/watch?v=oUuhfNuRkQo](https://www.youtube.com/watch?v=oUuhfNuRkQo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-09-02 00:00:00+00:00

My review of the sequel to Gideon the Ninth, Harrow the Ninth by Tamsyn Muir! 
Gideon The Ninth: https://amzn.to/2WKa98j
Harrow The Ninth: https://amzn.to/3hKjMw6

Podcast: https://afictionalconversation.podbean.com/
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## BEST Fantasy Novellas🏆 THE STAND Trailer💉 NEW Dune Images🐛 -FANTASY NEWS
 - [https://www.youtube.com/watch?v=WO6divNfWQQ](https://www.youtube.com/watch?v=WO6divNfWQQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-09-01 00:00:00+00:00

let's get into the FANTASY NEWS you caffeinated space apes! 
Podcast: https://afictionalconversation.podbean.com/
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene


NEWS: 

—

00:23 - WoT Resumes Filming: https://www.reddit.com/r/WoT/comments/ii6nzz/looks_like_filming_is_officially_back_on/?utm_medium=android_app&utm_source=share

00:51 - New Wheel of Time Site: https://www.thegreatblight.com/

01:15 - Poppy War Drunk Recap: https://www.instagram.com/tv/CEf2S_dJzXE/?utm_source=ig_web_copy_link

02:18 - Michael Kramer Kate Reading Rhythm of War: https://twitter.com/Kramer_Reading/status/1300275919555366945?s=20

03:06 - Top Fantasy Novellas: https://www.reddit.com/r/Fantasy/comments/ijt3ed/the_2020_rfantasys_top_novellas_voting_results/

04:27 - Top LGBTQA+ Fantasy Books: https://www.reddit.com/r/Fantasy/comments/ifmx04/rfantasys_2020_top_lgbtqa_books_voting_results/

04:54 - Chadwick Boseman Passes from cancer: https://twitter.com/ap/status/1299529112512598017?s=21

07:08 - Self Pub September 2020: http://www.robjhayes.co.uk/self-published-fantasy-releases-september-2020/

07:48 - Dune Images: https://www.empireonline.com/movies/news/empire-dune-world-exclusive-covers-revealed/

09:27 - HDM Trailer: https://www.youtube.com/watch?v=45mJxhNhF54

10:05 - The Stand Trailer: https://www.youtube.com/watch?v=5hO49HF9f9A&

X-File Comedy Spinoff: https://tvline.com/2020/08/28/x-files-albuquerque-animated-spinoff-series-fox/

—

## David Benioff and Dan Weiss To Adapt The Three Body Problem @ Netflix
 - [https://www.youtube.com/watch?v=uo3D9-w2-BM](https://www.youtube.com/watch?v=uo3D9-w2-BM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-09-01 00:00:00+00:00

David Benioff and Dan Weiss are coming back and they are adapting the scifi epic The Three Body Problem. What do YOU think? 
Podcast: https://afictionalconversation.podbean.com/
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

