# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Samsung Galaxy Z Fold 2: bardzo pierwsze wrażenia
 - [https://www.youtube.com/watch?v=b-PMqHIX4Jg](https://www.youtube.com/watch?v=b-PMqHIX4Jg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-09-02 00:00:00+00:00

Ten film nie jest recenzją. Po prostu dorwałem Z Folda 2, miałem okazję się nim trochę pobawić i chciałem się z Wami podzielić wrażeniami. 

Moje sociale: 
Insta: http://bit.ly/InstaKlawiatur 
Twitter: http://bit.ly/TTKlawitera
FB: http://bit.ly/FBKlawiatur

