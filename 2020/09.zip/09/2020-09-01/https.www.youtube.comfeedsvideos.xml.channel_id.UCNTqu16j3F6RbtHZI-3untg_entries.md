# Source:Glink, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNTqu16j3F6RbtHZI-3untg, language:en-US

## Saving Your Father From the Belly of the Whale
 - [https://www.youtube.com/watch?v=u0YclPlwhAI](https://www.youtube.com/watch?v=u0YclPlwhAI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNTqu16j3F6RbtHZI-3untg
 - date published: 2020-09-02 00:00:00+00:00

In dark and uncertain times, people are looking for guidance now more than ever, even if we are often limited to screens and the internet. Online father figures have garnered dedicated followers and large audiences, but with great influence comes great responsibility. Ranging from Commentary Youtubers to Comedians, the father figures and

SPECIAL THANKS: 
VH21 for helping with research
@ikanaide_music for producing the Family Business cover 
Kevin Bessey for producing the Brother Sport cover
Slush for vocals on the cover of Brother Sport
Sam Beros for letting me use music from his EP (found here: https://open.spotify.com/album/5uLoZslmKGLQtL0Mh8NG9D?highlight=spotify:track:1CtxKiDEYYmXlTF9WS4jw7)
Ending art animation created by @vrcade00 on Instagram (https://www.instagram.com/vrcade00/)

SONG CREDITS:
Ez - Epidemic Sound
Reasons - Epidemic Sound
Overdrive - Sam Beros
Electropulse - Sam Beros
Komm, Susser Tod (Pokemon GBA soundfont) - M. V. Shooting
Big Flue - F Zero OST
In The Loopholes - Epidemic Sound
Duke - Epidemic Sound
I Got A Name Jime Croce Cover - Larry L
Ordon Village - Zelda Twilight Princess OST
The Great Ascension - Halo 3 OST
Finish the Fight - Halo 3 OST
Family Business Kanye West Instrumental Cover - Original Production by Ikanide
Brothersport Animal Collective Cover - Original Production by Kevin Bressey, Performed by Slush

My stuff:
Patreon - https://www.patreon.com/Glink
Twitter - https://twitter.com/GlinkLive
Reddit - https://www.reddit.com/r/glink/
Instagram - https://www.instagram.com/glink_between_worlds/
Discord - https://discord.gg/5f3CBA

