# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Miley Cyrus Gets Honest About Drug Use, Sobriety
 - [https://www.youtube.com/watch?v=FptlVRbOPMY](https://www.youtube.com/watch?v=FptlVRbOPMY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-09-02 00:00:00+00:00

JRE #1531 w/Miley Cyrus Now Available on Spotify:
https://open.spotify.com/episode/0ZEDvQuPtAEBnXE37slSoX

## Miley Cyrus on Dealing with the How She's Portrayed in the Media
 - [https://www.youtube.com/watch?v=B6q5ErWU77Y](https://www.youtube.com/watch?v=B6q5ErWU77Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-09-02 00:00:00+00:00

JRE #1531 w/Miley Cyrus Now Available on Spotify:
https://open.spotify.com/episode/0ZEDvQuPtAEBnXE37slSoX

## Joe Rogan on Tent Cities, Defunding the Police
 - [https://www.youtube.com/watch?v=rmMsJbGXQdw](https://www.youtube.com/watch?v=rmMsJbGXQdw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-09-01 00:00:00+00:00

Episode #1530 Now Available on Spotify:
https://open.spotify.com/show/4rOoJ6Egrf8K2IrywzwOMk?si=5f1FSKehS_ijZmgidWjqwg

## What is the Deal with Bohemian Grove?
 - [https://www.youtube.com/watch?v=aJYF6_x18ag](https://www.youtube.com/watch?v=aJYF6_x18ag)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-09-01 00:00:00+00:00

Episode #1530 Now Available on Spotify:
https://open.spotify.com/show/4rOoJ6Egrf8K2IrywzwOMk?si=5f1FSKehS_ijZmgidWjqwg

