# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## LOTR: Gollum Game - Trailer Breakdown
 - [https://www.youtube.com/watch?v=FAxtn-E8CWQ](https://www.youtube.com/watch?v=FAxtn-E8CWQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2020-09-01 00:00:00+00:00

Today we are taking a dive into the new Gollum video game teaser trailer! We are looking for clues embedded within this brief trailer and previously released screenshots.  Did you spot anything I missed?!  If so, let me know in the comments!

Hit subscribe - and the bell - so you never miss a video from Nerd of the Rings! 

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner. 

#gollum #gaming #lordoftherings

