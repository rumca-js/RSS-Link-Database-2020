# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Andrew Klavan Pitches Shocking And Depraved Hollywood Reboots
 - [https://www.youtube.com/watch?v=ADWTPHAZMzs](https://www.youtube.com/watch?v=ADWTPHAZMzs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-09-02 00:00:00+00:00

Kyle and Ethan ask Andrew Klavan how he would reboot forgotten properties like Air Bud, Biker Mice From Mars, and Ghost Dad. Klavan reveals his obsession with promiscuity, cannibalism, and death.

FULL ▶️  https://youtu.be/-cviCDPkxKM

## Andrew Klavan Talks Violence In Storytelling/Becoming Christian/Movies Ruining Movies
 - [https://www.youtube.com/watch?v=-cviCDPkxKM](https://www.youtube.com/watch?v=-cviCDPkxKM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-09-01 00:00:00+00:00

Today on The Babylon Bee Podcast, Kyle and Ethan talk to Andrew Klavan an author, screenwriter, essayist, and host of The Andrew Klavan Show at The Daily Wire. They discuss whether good storytelling requires sex & violence, movies that ruined entire movie genres, and going from secular Jew to Christian at age 49. Kyle and Ethan pitch their best movie remake ideas and they talk shop with a fellow satirist.

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Gain Access to the Exclusive Content and Writing Forum: https://babylonbee.com/plans

The Official Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

