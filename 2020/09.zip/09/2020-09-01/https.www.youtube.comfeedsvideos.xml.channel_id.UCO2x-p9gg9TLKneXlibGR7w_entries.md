# Source:Snazzy Labs, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w, language:en-US

## The Quietest Computer EVER?!
 - [https://www.youtube.com/watch?v=vosgP0yAlE4](https://www.youtube.com/watch?v=vosgP0yAlE4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w
 - date published: 2020-09-01 00:00:00+00:00

Apple fans give PCs a bad rap for being “too loud.” Snazzy Labs strikes back by attempting to make a gaming PC quieter than any Mac before it—it’s not so simple after all.

Intel i5-10600K - https://amzn.to/2QGObiX
GIGABYTE Z490 Vision G - https://amzn.to/3hPIhbh
be quiet! Dark Rock Pro 4 - https://amzn.to/3lDAxLF
ARCTIC Accelero Xtreme IV - https://amzn.to/2ECZOoW
Lian Li O11 Dynamic XL - https://amzn.to/34NoTrT

Subscribe to my podcast Flashback! - http://relay.fm/flashback
Follow me on Twitter - http://twitter.com/snazzyq
Follow me on Instagram - http://instagram.com/snazzyq

Steve Jobs famously disliked the idea of putting fans or cooling vents in any of the products released under his tenure in the early days of Apple. While Apple has been known for keeping some of their most powerful machines fairly quiet—even under full load—with the exception of Mac Pro, this frequently results in thermal throttling, undervolting, fan bearing failure, and more. These are compromises that many Apple fans would take despite the relative decrease in performance as PCs are often (and sometimes fairly) viewed as loud or annoying—even at idle. In this video, Snazzy Labs tries to make the best of both worlds: a powerful gaming PC with an NVIDIA GTX 2080 Ti and an Intel i5-10600K inside of a Lian Li O11 Dynamic XL that puts liquid cooling pumps, fan RPMs, and more to shame.

