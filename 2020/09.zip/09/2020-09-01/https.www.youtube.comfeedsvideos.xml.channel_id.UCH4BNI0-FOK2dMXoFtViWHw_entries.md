# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## How Your Brain Makes Time Pass Fast or Slow
 - [https://www.youtube.com/watch?v=NSy0Z7XCF3E](https://www.youtube.com/watch?v=NSy0Z7XCF3E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2020-09-01 00:00:00+00:00

PBS Member Stations rely on viewers like you. To support your local station, go to: http://to.pbs.org/DonateOKAY
↓ More info and sources below ↓

We’re on PATREON! Join the community ►► https://www.patreon.com/itsokaytobesmart
SUBSCRIBE so you don’t miss a video! ►► http://bit.ly/iotbs_sub 

Time passes for all of us at the same rate of one second per second. But why does it sometimes feel like time is passing so fast, or so slowly? Especially during COVID? Let’s learn about how our brains keep track of and try to make sense of time, and how they get fooled.

Watch our previous video about masks: https://youtu.be/0Tp0zB904Mc 

Our entire COVID-19 playlist: https://www.youtube.com/playlist?list=PLsmqeqKj7M-pvu23aAUn6gtvDZAymnZ0K

References: https://sites.google.com/view/how-perceive-time-references/home

Special thanks to our Brain Trust Patrons:
AlecZero
Amory Silva
Amy Sowada
Baerbel Winkler
Benjamin Teinby
Denzel Holmes
Diego Lombeida
Dustin
Eric Meer
George Gladding
Jay Stephens
Karen Haskell
Marcus Tuepker
Megan K Bradshaw
Peter Ehrnstrom
Robert Young
Salih Arslan
Vincbis
Zenimal


Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/

