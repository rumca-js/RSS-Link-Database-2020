# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## This is the BIGGEST month for VR in 2020
 - [https://www.youtube.com/watch?v=sqbUvPjjlts](https://www.youtube.com/watch?v=sqbUvPjjlts)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-09-01 00:00:00+00:00

Thank you to this video's sponsor, Dashlane.
Go to https://www.dashlane.com/thrillseeker for 50% or use code Thrillseeker. Otherwise, it's completely free. 

Hello and Welcome to TUESDAY NEWSDAY!

There's a ton of stuff happening this month in VR and i would pretty much say this is the biggest month of the entire year, arguably even more important than the launch of Half Life Alyx.

That and SO MUCH MORE!



HUGE swords of gurrah key giveaway today on Twitch.
Twitch.TV/Thrilluwu
Also join the discord!
Discord.gg/Thrill


TIMESTAMPS-

SOURCES-
https://www.roadtovr.com/lynx-mr-headset-compact-redesign-release-date-september/

https://www.oculus.com/blog/an-update-on-oculus-connect-7/

https://tech.fb.com/introducing-the-new-facebook-reality-labs-plus-save-the-date-for-facebook-connect-on-september-16/

https://www.youtube.com/watch?v=O2jSp1YxbVw

https://www.reddit.com/r/VR_memes/comments/iggv69/can_someone_at_least_explain_whats_going_on/

https://uploadvr.com/respawn-medal-of-honor-vr-multiplayer-modes/

