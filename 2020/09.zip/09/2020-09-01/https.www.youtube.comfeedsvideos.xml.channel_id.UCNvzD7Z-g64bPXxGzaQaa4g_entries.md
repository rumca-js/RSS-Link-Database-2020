# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Crusader Kings 3 - Before You Buy
 - [https://www.youtube.com/watch?v=ick-fNVUpYw](https://www.youtube.com/watch?v=ick-fNVUpYw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-09-02 00:00:00+00:00

Crusader Kings III (PC) is the return of a PC gaming series like no other. Does it live up to the name? Let's talk.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 10 WEIRD Gaming Stories of August 2020
 - [https://www.youtube.com/watch?v=sgtPyL_Wgo4](https://www.youtube.com/watch?v=sgtPyL_Wgo4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-09-01 00:00:00+00:00

August 2020 was a wild time for video game news stories. Here are some of the weirdest and most interesting headlines.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

