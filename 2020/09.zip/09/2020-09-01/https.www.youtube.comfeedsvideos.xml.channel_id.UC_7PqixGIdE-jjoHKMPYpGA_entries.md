# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Czy 70 milionów jednozłotówek to naprawdę dużo?
 - [https://www.youtube.com/watch?v=mVvwNATFMzk](https://www.youtube.com/watch?v=mVvwNATFMzk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2020-09-02 00:00:00+00:00

Koszulki ► https://naukowybelkot.shoplo.com/
Moja książka ► https://altenberg.pl/geny/
Patronite ► https://patronite.pl/NaukowyBelkot 
Mix audio ► http://ratstudios.pl/

Gdyby ten film miał nanomol wyświetleń byłbym bardzo bogatym człowiekiem.

Subskrypcja ► https://youtube.com/c/UwagaNaukowyBelkot
Facebook ► https://facebook.com/UwagaNaukowyBelkot
Twitter ► https://twitter.com/NaukowyBelkot
Instagram ► https://www.instagram.com/NaukowyBelkot/

Wyłącznie Naukowy Bełkot ► https://goo.gl/Do7VCc
Grupa na facebooku ► https://goo.gl/HP8J83

0:00 1, 2, 3, 4, dużo
4:50 Co to jest ten cały mol
8:39 Układamy mol ulotek
14:47 Drukujemy mol ulotek
17:42 Mol codzienny
18:50 Mol wody

