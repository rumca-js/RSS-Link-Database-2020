# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## The Ghost Of A Saber Tooth Tiger: NPR Music Tiny Desk Concert From The Archives
 - [https://www.youtube.com/watch?v=DXDwkzM7eMw](https://www.youtube.com/watch?v=DXDwkzM7eMw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2020-09-06 00:00:00+00:00

We've been filming Tiny Desk concerts for more than 10 years. While revisiting our archives, we discovered that some of our earliest concerts never made it to YouTube! 
Watch The Ghost Of A Saber Tooth Tiger’s Tiny Desk concert from 2010: https://www.npr.org/2010/12/08/131291469/the-ghost-of-a-saber-tooth-tiger-tiny-desk-concert

Bob Boilen | November 17, 2010

The Ghost Of A Saber Tooth Tiger consists of two down-to-earth people with their heads in the clouds: Sean Lennon and Charlotte Kemp Muhl. Muhl is a model with a creative ear for music-making, while Lennon is the son of John and Yoko. Together, they write dreamy musings on everything from dark matter to the pedestrian and mundane.

The duo has recorded two albums: The first is called Acoustic Sessions, while the second will be electric. Acoustic Sessions was recorded in the bedroom and kitchen of the pair's New York City apartment, so it wasn't such a stretch for them to play in the cozy confines of the NPR Music offices. You can see their playful humor right from the start — and watch Lennon's mind wander as he looks out our fifth-floor windows.

The attraction for me lies in the whimsy of Muhl and Lennon's music, as well as the charm that oozes from their songs. This Tiny Desk concert offers a perfect introduction to their musical world.

Set List:
"Jardin du Luxembourg"
"Schroedinger's Cat"
"Dark Matter, White Noise"
"The World Was Made For Men"

