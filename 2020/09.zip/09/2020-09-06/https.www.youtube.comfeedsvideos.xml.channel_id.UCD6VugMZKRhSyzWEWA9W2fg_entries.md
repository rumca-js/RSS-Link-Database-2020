# Source:SssethTzeentach, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCD6VugMZKRhSyzWEWA9W2fg, language:en-US

## Endless Space 2 Review | Jingoist Joy™ Edition
 - [https://www.youtube.com/watch?v=VKEawmH-l9c](https://www.youtube.com/watch?v=VKEawmH-l9c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCD6VugMZKRhSyzWEWA9W2fg
 - date published: 2020-09-06 00:00:00+00:00

The academy demands you pay reparations for your damage.


Outro is 'Overcharge' by Crt_head.
https://crthead.bandcamp.com/album/power-up

Enjoy.
-----------------------
Send Sseth Shekels: https://www.paypal.me/SsethTzeentachGB
Send Sseth Shekels per video:  https://www.patreon.com/Sseth
Send Sseth Shekels / crypto: https://www.subscribestar.com/ssethtzeentach

Website: https://ssethtzeentach.com/
Twitter: https://twitter.com/SsethTzeentach
FB: https://www.facebook.com/sseth672/

