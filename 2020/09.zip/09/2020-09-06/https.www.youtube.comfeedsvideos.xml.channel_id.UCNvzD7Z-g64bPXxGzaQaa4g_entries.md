# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Best FREE iOS & Android Games of August 2020
 - [https://www.youtube.com/watch?v=PgYOchNFHjc](https://www.youtube.com/watch?v=PgYOchNFHjc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-09-07 00:00:00+00:00

Looking for some good free games for your iPhone or Android mobile device? Here's a list of some of the best new free games for your phone.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

TauCeti Technology Benchmark
Platform: iOS Android
Price: Free
https://play.google.com/store/apps/details?id=com.badflyinteractive.tauceti
https://apps.apple.com/us/app/id1500860066

FINAL FANTASY CRYSTAL CHRONICLES
Platform: iOS Android
Price: Free
https://apps.apple.com/us/app/finalfantasy-crystalchronicles/id1478870957
https://play.google.com/store/apps/details?id=com.square_enix.android_googleplay.FFCCREww&hl=en_US

Soul of Eden
Platform: iOS Android
Price: Free
https://apps.apple.com/us/app/soul-of-eden/id1046770387
https://play.google.com/store/apps/details?id=com.rayark.rush&hl=en_IN

Sid Meier's Civilization VI
Platform: iOS Android
Price: Free
https://apps.apple.com/us/app/sid-meiers-civilization-vi/id1235863443
https://play.google.com/store/apps/details?id=com.aspyr.civvi&hl=en

Otherworld Legends
Platform: iOS Android
Price: Free
https://play.google.com/store/apps/details?id=com.chillyroom.zhmr.gp&hl=en
https://apps.apple.com/ph/app/otherworld-legends/id1439772060

Monster Dash
Platform: iOS Android
Price: Free
https://apps.apple.com/in/app/monster-dash/id370070561
https://play.google.com/store/apps/details?id=com.halfbrick.monsterdash&hl=en_IN


Baseball Superstars 2020
Platform: iOS Android
Price: Free
https://play.google.com/store/apps/details?id=com.gamevil.basebss.android.google.global.normal1
https://apps.apple.com/us/app/baseball-superstars-2020/id1396381549


Robotics!
Platform: iOS Android
Price: Free
https://apps.apple.com/us/app/robotics/id1476051009
https://play.google.com/store/apps/details?id=com.zeptolab.robotics&hl=en


Madden NFL 21 Mobile Football
Platform: iOS Android
Price: Free
https://apps.apple.com/us/app/madden-nfl-21-mobile-football/id1512265589
https://play.google.com/store/apps/details?id=com.ea.gp.maddennfl21mobile&hl=en


EVE Echoes
Platform: iOS android
Price: Free
https://apps.apple.com/us/app/eve-echoes/id1446384690
https://play.google.com/store/apps/details?id=com.netease.eve.en&hl=en_IN

## TOP 7 NEW Stealth Games of 2020
 - [https://www.youtube.com/watch?v=Ukubeqe5GmQ](https://www.youtube.com/watch?v=Ukubeqe5GmQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-09-06 00:00:00+00:00

There aren't many stealth games in 2020 for PC, PS4, or Xbox One, but thankfully many games have some solid sneaking gameplay elements.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

7- Maid of Sker

Platform: PC PS4 XBOX ONE SWITCH

Release date: July 28, 2020



6- Hello Neighbor 2 Alpha 1       

Platform: PC

Release date: 2020    



5-  Watch Dogs Legion

Platform: PC PS4 XBOX ONE

Release date: October 29, 2020



4- Last of us 2

Platform: PS4

Release date: June 19, 2020



3- Desperados III

Platform: PS4 XBOX ONE PC

Release date: June 16, 2020



2- Ghost of Tsushima

Platform: PS4

Release date: July 17, 2020



1- Assassin's Creed Valhalla

Platform: PC, PS4, XBOX ONE

Release date: November 17, 2020



Bonus: 

Little Nightmares 2

Platform: PC PS4 XBOX ONE SWITCH

Release date: TBA 2020



XIII

Platform: PC

Release date: 10 Nov, 2020

