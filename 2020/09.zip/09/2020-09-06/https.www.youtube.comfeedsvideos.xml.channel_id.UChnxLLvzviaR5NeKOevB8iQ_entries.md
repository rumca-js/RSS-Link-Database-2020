# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## The Funky One (Modular Performance)
 - [https://www.youtube.com/watch?v=SLgyPI-N1hg](https://www.youtube.com/watch?v=SLgyPI-N1hg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2020-09-07 00:00:00+00:00

I wanted to make IDM one night but instead, I made this. 
This appears on "Adam's Fault", an album of music: 
https://soundvision.bandcamp.com/album/adams-fault
https://distrokid.com/hyperfollow/jeremyblake/adams-fault
Video on the Squarp Rample: https://youtu.be/l80yJl3hrTY

Patch notes in video, gear list here: 
Sequencing and modulation
Arturia Keystep Pro: https://reverb.grsm.io/keysteppro
Squarp Hermod: https://reverb.grsm.io/hermod
Maleko Varigate 8+: https://reverb.grsm.io/varigate8
Busy Circuits Pam's New Workout: https://reverb.grsm.io/pams
Intelijel Tetrapad: https://reverb.grsm.io/tetrapad
Abstract Data ADE-32: https://reverb.grsm.io/ade32
After Later Piques: https://reverb.grsm.io/alpiques

Drums and sampling
Squarp Rample: https://reverb.grsm.io/rample
QD Quad Drum Module: https://reverb.grsm.io/vpmeqd

Oscillators
Mutable Instruments Plaits: https://reverb.grsm.io/plaits
IME Piston Honda MKIII: https://reverb.grsm.io/pistonhonda
Erica Synths Pico Voice: https://reverb.grsm.io/espico
Joranalogue Generate 3: https://reverb.grsm.io/generate3

Effects
After Later Monsoon: https://reverb.grsm.io/almonsoon
TipTop Audio z5000: https://reverb.grsm.io/z5000
Erica Black Hole DSP: https://reverb.grsm.io/blackhole8161
Qubit Prism: https://reverb.grsm.io/qubitprism

Other stuff
Happy Nerding VCF: https://reverb.grsm.io/hnvcf
Happy Nerding PanMix (and Jr.): https://reverb.grsm.io/hnpanmix 
Intellijel Quad VCA: https://reverb.grsm.io/intquadvca
Nano Machines Quart: https://reverb.grsm.io/quart
------------------------------------
Hi, my name is Jeremy, and this is Red Means Recording. I make music and do video stuff and this is the place where those things come together. We'll make some music, talk about hardware and software, and just generally have a chill time. Is that ok? Awesome.
If you'd like to support the channel, here are some links: 

Patreon: http://bit.ly/rmrpatreon
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe
T-Shirts: http://bit.ly/rmrshirts
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

