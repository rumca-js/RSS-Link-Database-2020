# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Wstawaki [#603] Trzy serca
 - [https://www.youtube.com/watch?v=trUWwH16v7E](https://www.youtube.com/watch?v=trUWwH16v7E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-09-07 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał  
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie


♫ Słuchaj jako PODCAST Langusty: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
iTunes → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWHx

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Historie potłuczone [#10] O Monice, co się wkręcić dała
 - [https://www.youtube.com/watch?v=28CciidUFvY](https://www.youtube.com/watch?v=28CciidUFvY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-09-06 00:00:00+00:00

​ @Langusta na palmie   #historiepotłuczone #podcast

Historie potłuczone to opowieści o córkach i synach Boga, pięknych i brzydkich, świętych i grzesznych, szczęśliwych i na skraju rozpaczy. To opowieści o drodze, którą idzie się do nieba i o zakrętach i chaszczach, które spychają do piekła. To opowieści o ludziach po prostu. Czyli o nas.

Muzyka: Kai Engel: Brand New World, http://freemusicarchive.org/music/Kai_Engel/
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

♫ Słuchaj jako PODCAST Langusty: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
iTunes → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWHx

Zapraszamy na nowy portal :
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Mocno stronniczy [#10] Dlaczego księża odchodzą?
 - [https://www.youtube.com/watch?v=_nS8PrHOMkI](https://www.youtube.com/watch?v=_nS8PrHOMkI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-09-06 00:00:00+00:00

@STREFAWODZA @Langustanapalmie 
Takich dwóch, jak Ci to nie ma :) Zapraszamy co niedzielę o godz: 10:oo, na premierę zupełnie niesłychanej serii ojców Tomasza Nowaka OP i Adama Szustaka OP.
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

♫ Słuchaj jako PODCAST Langusty: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/histori...
Spotify → https://spoti.fi/2NVIRHb
iTunes → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWHx

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

