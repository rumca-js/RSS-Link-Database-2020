# Source:Paul Joseph Watson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCittVh8imKanO_5KohzDbpg, language:en-US

## Gary Lineker is an Idiot
 - [https://www.youtube.com/watch?v=5RZpVUFIxww](https://www.youtube.com/watch?v=5RZpVUFIxww)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCittVh8imKanO_5KohzDbpg
 - date published: 2020-09-06 00:00:00+00:00

Fish and chips exist therefore mass illegal immigration is good.



INTRO MUSIC: Sagittarius V - Lucidator: http://sagittariusvmusic.bandcamp.com

DONATE: https://www.subscribestar.com/paul-joseph-watson
CASH APP: https://cash.app/£pjw123
SUMMIT NEWS: http://summit.news/newsletter
TURBO FORCE: https://bit.ly/TURBOFORCE 

BITCOIN WALLET: 3EMQG9EhPkoFbX5F19RTGZs8rPqGYm2mp9
BITCOIN CASH WALLET: qrxhqz9ka423v68qwc7nyqc88q3mx9ea5gcpz88a0l
LITECOIN WALLET: MSs2rWgM571WM3zUnL255gccoQAdz9L6CG
ETHEREUM WALLET: 0x21221F5da5e70F46Bbfa755f89e312daDa51f115 

Anything Goes: https://www.youtube.com/channel/UC6x4zJADfr5Z4w-bf8lbrcg
Parler: https://parler.com/profile/PJW/posts
Bitchute: https://www.bitchute.com/pauljosephwatson
Telegram: https://t.me/pjwnews
Twitter: https://twitter.com/PrisonPlanet
Minds: https://www.minds.com/PaulJosephWatson
Gab: https://gab.com/PrisonPlanet

