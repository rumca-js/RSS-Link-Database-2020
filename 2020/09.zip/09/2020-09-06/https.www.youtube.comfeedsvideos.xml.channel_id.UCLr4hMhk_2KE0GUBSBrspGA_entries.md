# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## POCO X3 NFC - smartfon do 1000 zł
 - [https://www.youtube.com/watch?v=EzDLDLxOVM4](https://www.youtube.com/watch?v=EzDLDLxOVM4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-09-07 00:00:00+00:00

W dniu światowej premiery mam dla Was film o najnowszym średniaku od POCO, który moim zdaniem jest całkiem spoco ;)
Poco w OleOle - https://bit.ly/338CNlG

Moje sociale: 
Insta: http://bit.ly/InstaKlawiatur 
Twitter: http://bit.ly/TTKlawitera
FB: http://bit.ly/FBKlawiatur

Centrum Testów: https://centrumtestow.pl

