# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## The 5 Most Earth-Like Planets We've Found (So Far) | Answers With Joe
 - [https://www.youtube.com/watch?v=vqNW1ybwTVk](https://www.youtube.com/watch?v=vqNW1ybwTVk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2020-09-07 00:00:00+00:00

Get 20% off a premium subscription of Brilliant at http://www.brilliant.org/answerswithjoe
The number of known exoplanets seems to grow every day. Most of them are worlds completely unlike our own. But some get pretty close to something resembling home - and may someday become exactly that.

Here's the link to all those different planet-finding methods:
https://www.planetary.org/explore/space-topics/exoplanets/how-to-search-for-exoplanets.html

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

https://www.nationalgeographic.com/science/prehistoric-world/mass-extinction/

https://en.wikipedia.org/wiki/Parker_Solar_Probe

https://www.thoughtco.com/counting-habitable-planets-3072596

https://www.planetary.org/explore/space-topics/exoplanets/how-to-search-for-exoplanets.html

https://astrobiology.nasa.gov/news/introducing-the-habitable-exoplanets-catalog/ 

https://www.sciencealert.com/two-earth-like-planets-found-orbiting-a-star-just-12-light-years-away

https://exoplanets.nasa.gov/exoplanet-catalog/3343/k2-72-e/

https://exoplanets.nasa.gov/exep/technology/technology-overview/

https://roman.gsfc.nasa.gov/

https://www.luvoirtelescope.org/

https://en.wikipedia.org/wiki/Space_Interferometry_Mission

