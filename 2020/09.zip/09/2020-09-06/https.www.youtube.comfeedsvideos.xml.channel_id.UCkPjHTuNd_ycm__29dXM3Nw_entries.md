# Source:G F Darwin, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCkPjHTuNd_ycm__29dXM3Nw, language:en-US

## Byli sobie Ludzie #4 - "Polityka"
 - [https://www.youtube.com/watch?v=W3qIZu7agNc](https://www.youtube.com/watch?v=W3qIZu7agNc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCkPjHTuNd_ycm__29dXM3Nw
 - date published: 2020-09-07 00:00:00+00:00

Byli sobie ludzie i rozmawiali o życiu, szczęściu, piachu i polityce a w międzyczasie budowali piramidy. I tak powstała cywilizacja, jedna z wielu. To było dawno, ale zaskakująco wiele z niej trwa do dziś i Wy możecie to zobaczyć. To już czwarty odcinek serii i… uwaga! Przedostatni! Więc szybko oglądajcie, zanim się skończy! ODCINEK POWSTAŁ DZIĘKI WSPARCIU PATRONÓW! DZIĘKUJEMY! TY TEŻ MOŻESZ NIM ZOSTAĆ!

🔥 Patronite: http://patronite.pl/darwin
🎬 Produkcja: http://darwinstudio.pl
👍 Facebook: http://facebook.com/GrupaFilmowaDarwin
❤ Instagram: http://instagram.com/g.f.darwin
📖 Książka: http://darwin.altenberg.pl
🛒 Gadżety Darwina: http://gfdarwin.teetres.com
🔔 Subskrybuj: http://youtube.com/GFDarwinYT?sub_confirmation=1
📺 Zobacz więcej: http://youtube.com/playlist?list=PLsuXZgkp0aLj9y8YKvqGi7sWZF4-R8Ww8
✉︎ Kontakt: kontakt@gfdarwin.pl

⬇️ SERIE DARWINA ⬇️

✪ SHORTY DARWINA http://youtube.com/playlist?list=PLsuXZgkp0aLjcTOnmQBAEtNnLddTNAWgK
✪ WIELKIE KONFLIKTY http://youtube.com/playlist?list=PLsuXZgkp0aLhss_09rp5y7stE-ai47los
✪ BYLI SOBIE LUDZIE http://youtube.com/playlist?list=PLsuXZgkp0aLhJBk0mCKEFHp1HhRFVxGkO
✪ WIELKIE TEORIE DARWINA http://youtube.com/playlist?list=PLsuXZgkp0aLi3fdQttVaUAbBZhgNyZHGU
✪ ZAKAZANE SPOTY DARWINA http://youtube.com/playlist?list=PLsuXZgkp0aLhMkmBCOB0U1xxnez_qxMsc
✪ DZIENNIK INTERNETOWY http://youtube.com/playlist?list=PLsuXZgkp0aLjifDBNmr7X03BpXWH6HQnY
✪ AGENT 700 http://youtube.com/playlist?list=PLsuXZgkp0aLjcA9SmwOgxNVYkOmepuWkI
✪ GWIEZDNY SZERYF http://youtube.com/playlist?list=PLsuXZgkp0aLjGefv9_WG4JXKBum_nub-O
✪ TROPICIELE PRAWDY http://youtube.com/playlist?list=PLsuXZgkp0aLjtH-yeV77KpDaE0l2SVKEG
✪ PŁACHTA NA BYKA http://youtube.com/playlist?list=PLsuXZgkp0aLg0feVkxtjmK6v-Jl21trKX
✪ RAFAŁ VS SŁAWEK http://youtube.com/playlist?list=PLsuXZgkp0aLiUkPc4itqXRStub8A__WXE
✪ MISJA http://youtube.com/playlist?list=PLsuXZgkp0aLhTX5ov5X5TDv5UNC5_5hLK
✪ WYGRYWASZ CO CHCESZ! http://youtube.com/playlist?list=PLsuXZgkp0aLhHN8nTFGneH-CFwMCC0z7K
✪ GROOVY MOVIE http://youtube.com/playlist?list=PLsuXZgkp0aLi3Cex97XNhTb1Ri4zO0h3r
✪ BAJKI DARWINA http://youtube.com/playlist?list=PLsuXZgkp0aLj0xuqiJ9whcDLxJgNQSv7L
✪ ELFIA TRYLOGIA http://youtube.com/playlist?list=PLsuXZgkp0aLi8CsRg76eeIdSnw47kKRUR
✪ NAUKA? NIE ROZUMIEM! http://youtube.com/playlist?list=PLsuXZgkp0aLhbA-2Gt188w6el573Tn7Fb

✂️ DARWIN EXTRAS (making of) http://youtube.com/GFDarwinEXTRAS

---------------------------------------------------------------------
Copyright © G.F. Darwin. All rights reserved.
---------------------------------------------------------------------

#GFDarwin #ByliSobieLudzie #StarożytnyRzym

