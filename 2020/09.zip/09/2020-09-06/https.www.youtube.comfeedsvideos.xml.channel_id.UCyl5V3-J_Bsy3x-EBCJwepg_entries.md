# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## A.L. Van Den Herik on the Babylon Bee Podcast
 - [https://www.youtube.com/watch?v=C2xb7Vz2fxY](https://www.youtube.com/watch?v=C2xb7Vz2fxY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-09-07 00:00:00+00:00

🎙 Tomorrow A.L. Van Den Herik joins Kyle and Ethan on The Babylon Bee podcast. 

Subscribe today ▶️ http://bit.ly/TheBeeYouTube

## Catholic Lady Throat Chop!
 - [https://www.youtube.com/watch?v=ESDyRVjlvp4](https://www.youtube.com/watch?v=ESDyRVjlvp4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-09-06 00:00:00+00:00

Kyle and Ethan talk about some weird news reported by Not The Bee including a lady getting throat-chopped by another lady during a Catholic Church service and a weird looking sheep that sold for $500,000.

