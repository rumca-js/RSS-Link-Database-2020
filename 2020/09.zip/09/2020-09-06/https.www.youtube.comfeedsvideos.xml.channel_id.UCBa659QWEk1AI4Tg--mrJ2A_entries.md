# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## 1,204,986 Votes Decided: What Is The Best Thing?
 - [https://www.youtube.com/watch?v=ALy6e7GbDRQ](https://www.youtube.com/watch?v=ALy6e7GbDRQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2020-09-07 00:00:00+00:00

Sometimes, you regret asking a question. • Win your Ultimate Tech Bundle by entering Fasthosts’ Techie Test here: https://www.fasthosts.co.uk/tomscott

Thanks to Graham Haerther for the main audio mix, and for recovering the terrible sound in my echo-filled flat!

(For the folks asking: I'm not planning to release the ranked list -- partly because "ranked list of major world religions" sounds like the sort of thing that'll cause trouble, and partly because I can't guarantee there aren't some other nasty things still in the list. Apologies!)

00:00 Introduction
00:38 Every Thing
04:35 How To Rank Everything
05:45 What Is The Best Thing?

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

