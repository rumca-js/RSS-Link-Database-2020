# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Instagram photo filters targeted by model's #filterdrop campaign
 - [https://www.bbc.co.uk/news/uk-england-bristol-53784938](https://www.bbc.co.uk/news/uk-england-bristol-53784938)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-09-06 23:07:16+00:00

Why a make-up artist is campaigning to tackle unrealistic beauty images on social media.

## The women behind one of Gucci's most-liked Insta posts
 - [https://www.bbc.co.uk/news/business-53997790](https://www.bbc.co.uk/news/business-53997790)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-09-06 23:05:58+00:00

Zebedee Management represents disabled models and actors around the world.

## The woman trying to save India's tortured temple elephants
 - [https://www.bbc.co.uk/news/world-asia-india-54026294](https://www.bbc.co.uk/news/world-asia-india-54026294)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-09-06 23:03:59+00:00

Activist Sangita Iyer is on a mission to end the agony of ceremonial elephants.

## War-torn Yemen's Covid-19 struggle
 - [https://www.bbc.co.uk/news/world-middle-east-54034803](https://www.bbc.co.uk/news/world-middle-east-54034803)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-09-06 23:03:44+00:00

Yemen is already facing the world's worst humanitarian crisis and the pandemic has not stopped the fighting.

## The German lake house that saw history up close
 - [https://www.bbc.co.uk/news/world-54034894](https://www.bbc.co.uk/news/world-54034894)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-09-06 23:03:40+00:00

A new illustrated book tells the interconnected stories of a German lake house and the families that called it home during turbulent times.

## Special educational needs families and the fight for education
 - [https://www.bbc.co.uk/news/education-54034802](https://www.bbc.co.uk/news/education-54034802)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-09-06 23:03:34+00:00

Some special educational needs families say they've found it difficult to access support during the pandemic.

## What's behind the unequal threat of Covid
 - [https://www.bbc.co.uk/news/world-us-canada-54021999](https://www.bbc.co.uk/news/world-us-canada-54021999)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-09-06 23:03:23+00:00

Covid-19 is already the third-leading cause of death for African Americans this year. Why?

## Beirut blast: The rowers left with nothing cling to Olympics dream
 - [https://www.bbc.co.uk/news/world-middle-east-54013623](https://www.bbc.co.uk/news/world-middle-east-54013623)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-09-06 23:01:10+00:00

Based at Beirut's port, a small cash-strapped rowing team lost everything - apart from their lives.

## Man blows up part of house while chasing fly
 - [https://www.bbc.co.uk/news/world-europe-54051423](https://www.bbc.co.uk/news/world-europe-54051423)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-09-06 19:57:14+00:00

An electric racket and a gas leak have proved disastrous for one man in France, local media report.

## Manchester Arena attack: The families searching for answers
 - [https://www.bbc.co.uk/news/uk-54033715](https://www.bbc.co.uk/news/uk-54033715)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-09-06 16:03:14+00:00

The parents of the youngest victim of the Manchester Arena attack on their quest for answers.

## Birling Gap danger warning over crumbling cliff edge photo
 - [https://www.bbc.co.uk/news/uk-england-sussex-54049513](https://www.bbc.co.uk/news/uk-england-sussex-54049513)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-09-06 15:49:08+00:00

The woman is seen posing at a section of cliff that has already broken away.

## England v Australia: Jos Buttler makes a terrible review
 - [https://www.bbc.co.uk/sport/av/cricket/54049659](https://www.bbc.co.uk/sport/av/cricket/54049659)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-09-06 14:11:00+00:00

England waste a review for lbw on a ball that hits nothing but the middle of Aaron Finch's bat in the second T20 against Australia in Southampton.

## Tunisia: Policeman and three militants dead after 'terrorist' attack
 - [https://www.bbc.co.uk/news/world-africa-54041569](https://www.bbc.co.uk/news/world-africa-54041569)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-09-06 12:57:27+00:00

The incident happened in Sousse, where 38 people, mostly Britons, were killed in a 2015 attack.

## Birmingham stabbings: Manhunt as one killed and seven hurt
 - [https://www.bbc.co.uk/news/uk-england-birmingham-54045143](https://www.bbc.co.uk/news/uk-england-birmingham-54045143)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-09-06 12:26:12+00:00

Police believe victims were chosen at random and there is no suggestion the attacks are terror related.

## Women's Super League: Kim Little scores for Arsenal against Reading
 - [https://www.bbc.co.uk/sport/av/football/54048753](https://www.bbc.co.uk/sport/av/football/54048753)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-09-06 12:13:06+00:00

Kim Little fires Arsenal into the lead against Reading with a "brilliant" volley in their Women's Super League match at Meadow Park.

## Typhoon Haishen: 200,000 ordered to evacuate as Japan braces for storm
 - [https://www.bbc.co.uk/news/world-asia-54046150](https://www.bbc.co.uk/news/world-asia-54046150)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-09-06 11:34:14+00:00

More than 200,000 people are ordered to shelter from the second storm to hit the region in a week.

## Son sells 28 years of birthday whisky to buy first home
 - [https://www.bbc.co.uk/news/uk-england-somerset-54040307](https://www.bbc.co.uk/news/uk-england-somerset-54040307)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-09-06 11:26:44+00:00

Matthew Robson's quirky collection of presents is now worth £40,000.

## Brexit: Negotiator David Frost says UK not scared of walking away
 - [https://www.bbc.co.uk/news/uk-politics-54045653](https://www.bbc.co.uk/news/uk-politics-54045653)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-09-06 10:56:29+00:00

Britain will leave the transition arrangement in December "come what may", says David Frost.

## Children and obesity: 'Spend time on sport rather than weighing kids'
 - [https://www.bbc.co.uk/news/uk-wales-53892585](https://www.bbc.co.uk/news/uk-wales-53892585)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-09-06 10:42:19+00:00

Olympian Elinor Barker says some people are turned off by team sports like football and rugby.

## Newcastle's £20m bid for Wilson accepted as Villa withdraw offer
 - [https://www.bbc.co.uk/sport/football/54046304](https://www.bbc.co.uk/sport/football/54046304)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-09-06 10:36:50+00:00

Newcastle United have a £20m bid accepted for Bournemouth's England striker Callum Wilson - as Aston Villa withdraw their offer.

## Cold case mystery: Only clue to man's identity is a ring inscription
 - [https://www.bbc.co.uk/news/uk-wales-54025571](https://www.bbc.co.uk/news/uk-wales-54025571)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-09-06 10:28:57+00:00

Can a team of experts finally help to solve the puzzle of a man's body found on a beach?

## John Cage musical work changes chord for first time in seven years
 - [https://www.bbc.co.uk/news/world-europe-54041568](https://www.bbc.co.uk/news/world-europe-54041568)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-09-06 09:47:54+00:00

The John Cage piece, As Slow As Possible, began 19 years ago and is to last 639 years.

## Mystery seeds: Amazon bans foreign plant sales in US
 - [https://www.bbc.co.uk/news/world-us-canada-54046154](https://www.bbc.co.uk/news/world-us-canada-54046154)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-09-06 08:52:17+00:00

Thousands of Americans have received unsolicited packets of seeds this year, mostly from China.

## Young women and suicide: 'I felt like a shell'
 - [https://www.bbc.co.uk/news/newsbeat-54027390](https://www.bbc.co.uk/news/newsbeat-54027390)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-09-06 07:45:43+00:00

New stats show a rise in the number of women taking their own lives in England and Wales last year.

## Creek Fire: Dozens trapped at California reservoir
 - [https://www.bbc.co.uk/news/world-us-canada-54046468](https://www.bbc.co.uk/news/world-us-canada-54046468)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-09-06 07:20:10+00:00

Helicopters are flying out people sheltering at a popular reservoir in the Sierra National Forest.

## Melbourne coronavirus lockdown extended
 - [https://www.bbc.co.uk/news/world-australia-54045102](https://www.bbc.co.uk/news/world-australia-54045102)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-09-06 04:25:34+00:00

The rate of new cases has not dropped enough for restrictions to be eased, officials say.

## Lake Travis: Several boats sink at pro-Trump parade in Texas
 - [https://www.bbc.co.uk/news/election-us-2020-54045115](https://www.bbc.co.uk/news/election-us-2020-54045115)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-09-06 01:50:20+00:00

Reports say people had to be rescued from the water, but no-one has been injured.

