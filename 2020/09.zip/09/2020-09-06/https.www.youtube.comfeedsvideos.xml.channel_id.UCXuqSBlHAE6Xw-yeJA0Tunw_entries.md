# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I should have hired a professional... DIY in-ceiling speaker install
 - [https://www.youtube.com/watch?v=JezVlLdQ2Qc](https://www.youtube.com/watch?v=JezVlLdQ2Qc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-09-07 00:00:00+00:00

The first 100 people to go to https://blinkist.com/linustechtips are going to get unlimited access for 1 week to try it out. You’ll also get 25% off if you want the full membership.

Add Honey for FREE and start saving today at https://joinhoney.com/ltt
Thanks, Honey for sponsoring!

Whole-home audio setups are SO accessible these days... so I decided to get one myself!

Buy: Sonos Amp
On Amazon (PAID LINK): https://geni.us/bl9Ze
On Newegg (PAID LINK): https://geni.us/nFABM
On B&H (PAID LINK): https://geni.us/OyoEdU

Buy: Sonos In-Ceiling Speakers
On Amazon (PAID LINK): https://geni.us/jEYdd
On Newegg (PAID LINK): https://geni.us/fCyw0
On B&H (PAID LINK): https://geni.us/t4obO

Buy: Sonos Connect: Amp
On Amazon (PAID LINK): https://geni.us/VuPczWP

Buy: Sonos Arc
On Amazon (PAID LINK): https://geni.us/RgKeLW
On Newegg (PAID LINK): https://geni.us/h5fn12N
On B&H (PAID LINK): https://geni.us/8MyN

Buy: Polk Audio RC80i
On Amazon (PAID LINK): https://geni.us/GcnUoK
On Newegg (PAID LINK): https://geni.us/DQqe
On B&H (PAID LINK): https://geni.us/sEYMAvZ

Purchases made through some store links may provide some compensation to Linus Media Group.


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Private Internet Access VPN: https://lmg.gg/pialinus2
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

## I can't believe how much I paid for this...
 - [https://www.youtube.com/watch?v=Ngy9TIbREJE](https://www.youtube.com/watch?v=Ngy9TIbREJE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-09-06 00:00:00+00:00

*Free 32GB Flash Drive & 32GB Micro SD Card: https://rebrand.ly/gy7m39z
Get the best prices and best selection at Micro Center: https://rebrand.ly/twi95lc
Join the Micro Center Community: https://rebrand.ly/rw1lcli
Micro Center Custom PC Builder: https://rebrand.ly/uw4g7lf

*Limited Time Offer, Valid In-store only, Limit 1 Coupon Per Customer

Save 10% and Free Worldwide Shipping at Ridge Wallets by using offer code LINUS at https://www.ridge.com/LINUS

We check out the display that took the 2008 tech world by storm. The Ostendo CRVD 43 was the worlds first curved AND ultra-wide monitor. It’s THICC and awesome and we get to unbox one. Who knew Linus running his mouth would get him a piece of history…… for $6000. Thanks to Vojox for sending us this: https://twitter.com/VojoxB & https://www.youtube.com/user/BullOnoob91


Buy Logitech G305: https://geni.us/SuxVC

Buy Logitech G815: https://geni.us/0vt2QuM

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://lmg.gg/IN8pC

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

