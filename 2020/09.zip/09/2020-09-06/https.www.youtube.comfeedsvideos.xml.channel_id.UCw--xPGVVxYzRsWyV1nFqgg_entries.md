# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## John Boyega Disney Criticism🥊 The Boys 1⭐ Review Flood! Octavia Butler NYT FINALLY!🥂-FANTASY NEWS
 - [https://www.youtube.com/watch?v=Q14tZNFtQOM](https://www.youtube.com/watch?v=Q14tZNFtQOM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-09-07 00:00:00+00:00

News happened. We talk. You comment. Much fantasy. YAY
Podcast: https://afictionalconversation.podbean.com/
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

NEWS: 

—
00:26 - Octavia Butler NYT Best Seller: https://twitter.com/MerrileeHeifetz/status/1301275316120297472

01:30 - The Original Sneak Peak: https://www.youtube.com/watch?v=DjJDrjl-G4c

02:30 - Wheel of Time 30th Anniversary: https://www.youtube.com/watch?v=9HjfD-WmLaA

02:40 - Dark Tower Director: https://www.syfy.com/syfywire/fantasia-film-fest-mike-flanagan-bly-manor-stephen-king

05:35 - The Princess Bride Reunite Script Reading: https://deadline.com/2020/09/the-princess-bride-cary-elwes-rob-reiner-wisconsin-democratic-party-2020-presidential-election-1234571226/

06:35 - Wither 3 Next Gen Release: https://twitter.com/witchergame/status/1301826520311369728?

08:05 - John Boyega Swings On Disney: https://www.gq-magazine.co.uk/culture/article/john-boyega-interview-2020

09:29 - Raised By Wolves Full Episode: https://www.youtube.com/watch?v=YIAIiw8UAfA

10:26 - The Boys 1 Star Flood: https://www.amazon.com/Boys-Season-Official-Teaser-Trailer/dp/B08F82VMXW/ref=sr_1_2?dchild=1&keywords=the+boys&qid=1599400013&sr=8-2#customer-review-section

Mandalorian Season 2 Release Date: https://www.radiotimes.com/news/on-demand/2020-09-03/mandalorian-season-2-release-date/

Super Mario Remaster: https://www.dualshockers.com/super-mario-3d-all-stars-resolution-details-revealed/

—

