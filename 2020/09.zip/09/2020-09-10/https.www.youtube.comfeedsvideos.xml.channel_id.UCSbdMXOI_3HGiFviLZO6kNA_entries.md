# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## The most Immersed I have EVER been in VR
 - [https://www.youtube.com/watch?v=wBV9hDNd2ws](https://www.youtube.com/watch?v=wBV9hDNd2ws)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-09-11 00:00:00+00:00

I am back again with another Bhaptics suit video.

A big upgrade happened recently allowing for full body support in VRchat so I can now feel when people touch my feet. It also has Half Life alyx support now, which is ridiculous. If you have ever wondered what a headcrab on the face feels like.. well, its kind like brushing your teeth. BRRRRR

Bhaptics-

https://amzn.to/2Zvwx6K

Twitch Stream TODAY!
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill

