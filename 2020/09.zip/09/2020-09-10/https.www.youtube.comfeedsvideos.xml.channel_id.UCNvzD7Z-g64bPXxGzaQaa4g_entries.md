# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## GAMESTOP IS MAKING BIG CHANGES, 4K SWITCH COMING? & MORE
 - [https://www.youtube.com/watch?v=Cw8m8KXTCZI](https://www.youtube.com/watch?v=Cw8m8KXTCZI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-09-11 00:00:00+00:00

Thanks to Postmates for sponsoring! Use code Gameranx for $110 in delivery credit for new users: https://postmates.com/?shortlink=5670d4c4&pid=mobcrush&c=mobcrush_aff_aff_mobcrush_all_all_cpm_all_c4

Ubisoft reveals new games, Xbox Series x and Series S get price and release date, Nintendo Switch upgrade rumors, and more in a week full of gaming news.
*Jakes twitter: https://twitter.com/jakebaldino 
*Instagram: https://goo.gl/HH6mTW 

*Jake’s other channel: https://youtu.be/c0lnve1rzDY


 discord.gg/gameranx 




 ~~~~STORIES~~~~



More GameStop changes
https://edition.cnn.com/2020/09/10/investing/gamestop-store-closures/index.html

Ubisoft:
Immortals Fenyx Rising Dec 3
https://youtu.be/1fWj0YB0XGc

PoP Sands of Time Remake (Jan 21st)
https://youtu.be/giNZRoRaOBw

Scott Pilgrim returns
https://youtu.be/mYcLi-TOJQE

Watch Dogs Legion
https://youtu.be/KIHmPj3x3A0

Riders Republic
https://youtu.be/rqOJ0xpGl68
Also note: AC release date change to Nov 10 (1 week early)Xbox Series X Series S price and release date: https://www.xbox.com/en-US/consoles/xbox-series-x



4k Switch?
https://www.vg247.com/2020/09/09/nintendo-switch-4k-ready-report/


Left 4 Dead 2 update:
https://youtu.be/aE9XUbvzNOo

Arrekzz Witcher workout
https://youtu.be/tZwD0Omz4MU

Call of Duty MP trailer:
https://youtu.be/rXRQyd6_5j4

Highlight Reel returns: 
https://youtu.be/dx2mgWhkOvU


Possible leaked 3080 benchmarks:
https://www.dsogaming.com/news/first-leaked-nvidia-geforce-rtx-3080-ampere-gpus-gaming-benchmarks/

Tony Hawk Jake
https://youtu.be/c0lnve1rzDY

Hyrule Warriors: Age of Calamity
https://www.theverge.com/2020/9/8/21427031/hyrule-warrriors-age-of-calamity-nintendo-switch-zelda

## Black Ops COLD WAR Multiplayer: Things The Trailer DOESN'T TELL YOU
 - [https://www.youtube.com/watch?v=us3lY4r_Edc](https://www.youtube.com/watch?v=us3lY4r_Edc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-09-10 00:00:00+00:00

Call of Duty Black Ops: Cold War (PC, PS4, Xbox One, PS5, Series X) has new multiplayer details. We're here with some info and some speculation.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

