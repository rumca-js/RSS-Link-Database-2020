# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Joe Rogan Experience #1535 - Tim Kennedy
 - [https://www.youtube.com/watch?v=TDKYSLDq6es](https://www.youtube.com/watch?v=TDKYSLDq6es)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2020-09-11 00:00:00+00:00

Special Forces operator and retired UFC fighter Tim Kennedy is the founder of Sheepdog Response, a training program aimed at giving law enforcement, military, and others the tools they need to quickly and effectively respond to violent threats.

