# Source:Cercle, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ, language:en-US

## Ben Böhmer live above Cappadocia in Turkey for Cercle
 - [https://www.youtube.com/watch?v=RvRhUHTV_8k](https://www.youtube.com/watch?v=RvRhUHTV_8k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ
 - date published: 2020-09-10 00:00:00+00:00

Ben Böhmer playing an exclusive sunrise live show from a hot air balloon above Cappadocia, in Turkey for Cercle.

☞ Support us and get access to exclusive videos & perks: https://Cercle.lnk.to/Patreon
☞ Listen to our playlists, tracks & sets: https://Cercle.lnk.to/Playlists
☞ Subscribe to our newsletter to know about our next shows: https://Cercle.lnk.to/Members
☞ Subscribe to our YouTube channel: https://Cercle.lnk.to/ytcercle

☞ Cercle Records
Ben Böhmer - Cappadocia (feat Romain Garcia): https://cercle.lnk.to/BenBohmerCappadocia

☞ The story behind the video:
https://youtu.be/9SSKZvmB36s

☞ Ben Böhmer
https://www.instagram.com/benbohmermusic/
https://www.facebook.com/benbohmermusic/
https://ffm.to/bbspotify.nir
https://music.apple.com/fr/artist/ben-b%C3%B6hmer/794108530

38º38'33.8''N 34º50'17.7''E

Video credits:

Artists: Ben Böhmer
Venue: Cappadocia, Turkey
Produced by Cercle
Executive producers: Philippe Tuchmann & Derek Barbolla
Film directed by: Pol Souchier & Derek Barbolla
Directors of photography: Mathieu Glissant & Mickaël Fidjili
Drone pilot: Pedrag Vojinovic
FPV drone pilot: Filip Petronijevic
Mix & Mastering : Ben Böhmer 
Technical Manager: Aurélien Moisan
Post-production: Mathieu Glissant (Saison Unique Production)

--
Special thanks to:
Tom Pounsford from Involved Management - Anjunadeep. 

Murat Yavuz from Turquoiz Balloon. 

Also thanks to Jonathan Kubben Quinonez (MomImfine). 

And also thanks to Sinem Özyalçın, Tuğçe Özgen, Seçil Kaplan, Hande Tekin Puttanna,  Mrs Aybala and Aslı Çay from the tourism board of Turkey. 

Galerie Joseph. 

Last but not least, thanks to Embassy of Sound, Anjunadeep, Hungry Music and Dancecode. 

______

This artistic performance has been recorded live. 

Tracklist : 

0:00 Ben Böhmer - Beyond Beliefs
6:20 Ben Böhmer - Fade To Blue 
11:00 Monolink - Father Ocean (Ben Böhmer Remix)
16:40 Ben Böhmer - After Earth 
23:40 Ben Böhmer - Maelstrom 
27:45 Ben Böhmer & Romain Garcia - Cappadocia 
33:06 Ben Böhmer - Strangers 
37:20 Ben Böhmer - Zeit & Raum 
42:15 Spencer Brown & Ben Böhmer - Phases 
47:08 Ben Böhmer & Nils Hoffmann ft. Malou - Breathing
52:27 Worakls ft. Eivør - Red Dressed (Ben Böhmer Remix)
58:10 Ben Böhmer - In Memoriam
1:03:14 Ben Böhmer - Flug & Fall 
1:09:12 Ben Böhmer - Little Lights
1:13:48 Q&A 

______

Follow us on http://www.cercle.io

