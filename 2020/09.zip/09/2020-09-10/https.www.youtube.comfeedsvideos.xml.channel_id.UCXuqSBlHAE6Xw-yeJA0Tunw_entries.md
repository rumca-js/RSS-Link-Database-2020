# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Maybe we should all just buy an Xbox... - WAN Show September 11 , 2020
 - [https://www.youtube.com/watch?v=0CRN5_eOQgc](https://www.youtube.com/watch?v=0CRN5_eOQgc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-09-11 00:00:00+00:00

Sign up for Streamlabs Prime at https://geni.us/cOHCiHh

Honey automatically applies the best coupon codes to save you money at 
different online checkouts, try it now at https://www.joinhoney.com/linus

Visit https://www.squarespace.com/WAN and use offer code WAN for 10% off


Check out Carpool Critics, our new movie podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Podcast Download: https://dts.podtrac.com/redirect.mp3/traffic.libsyn.com/secure/linustechtips/Maybe_we_should_all_just_buy_an_Xbox..._-_WAN_Show_September_11__2020.mp3

Timestamps (Courtesy of Michael O'Brien):
00:00:00 - Stream Start!
 00:00:47 - Topic #2: Xbox Series X & S (Jump to 00:46:28)
 00:01:11 - Topic #4: WD mislabels drives, in the wrong way (Jump to 01:17:06)
 00:01:27 - Topic #3: AMD Event Announcement (Jump to 01:14:32)
 00:01:34 - Topic #1: Linus' rant on missing Ampere (Jump to 00:03:00)
00:02:52 - Intro
 00:03:00 - Topic #1: Linus on Ampere
00:21:33 - Unofficial Topic #1: Watercooled Chair
00:34:29 - Sponsors!
 00:46:28 - Topic #2: Xbox Series X & S
 01:14:32 - Topic #3: AMD Zen 3 & RDNA 2
 01:17:06 - Topic #4: WD Labeling 7200 RPM drive as 5400 RPM
01:21:19 - Unofficial Topic #3: Linus' Tech Bounty program
01:29:50 - Superchats!
01:36:43 - Goodbye!
01:36:49 - Outro!

## This is NOT a Game - LG x IFA Booth 2020
 - [https://www.youtube.com/watch?v=rMIK68vbl8k](https://www.youtube.com/watch?v=rMIK68vbl8k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-09-11 00:00:00+00:00

Check out the LG Virtual Studio x IFA 2020: http://lgoledtv.co/LTT-LGVirtualStudio

Thanks to LG for sponsoring this stream!

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Private Internet Access VPN: https://lmg.gg/pialinus2
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

## We made the perfect couples PC!
 - [https://www.youtube.com/watch?v=-Mgnwn4twZE](https://www.youtube.com/watch?v=-Mgnwn4twZE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-09-10 00:00:00+00:00

Check out the SK hynix Gold P31 1TB NVMe SSD on Amazon at https://lmg.gg/k5okj
Thanks to SK hynix for sponsoring this video!

With a sweet custom paint job from Edzel on the P600s, and some tag team work between Jake and Linus to get Unraid running. We were able to throw together a one of a kind PC AND saved some money by building a single computer for two using virtualization and the SK hynix Gold P31 SSD!

---------------------------------------------------

Buy: Phanteks Eclipse P600S
On Amazon (PAID LINK): https://geni.us/9XfDl
On Newegg (PAID LINK): https://geni.us/vepMlD7

Buy: Fuji Industrial Spray Equipment Q5 Platinum Quiet HVLP Spray System
On Amazon (PAID LINK): https://geni.us/5yjo

Buy: FROGTAPE Multi-Surface Painter's Tape
On Amazon (PAID LINK): https://geni.us/yfnABD
On Newegg (PAID LINK): https://geni.us/gpRr

Buy: Intel Core i9-10900K
On Amazon (PAID LINK): https://geni.us/k9x0YH8
On Newegg (PAID LINK): https://geni.us/fERsB9L
On B&H (PAID LINK): https://geni.us/BM3j

Buy: GIGABYTE Z490 AORUS PRO AX
On Amazon (PAID LINK): https://geni.us/y6oN5
On Newegg (PAID LINK): https://geni.us/uZkdBp1
On B&H (PAID LINK): https://geni.us/DQTXFNZ

Buy: Noctua NH-U12A
On Amazon (PAID LINK): https://geni.us/I9gm
On Newegg (PAID LINK): https://geni.us/WftbnX

Buy: G.SKILL Trident Z RGB
On Amazon (PAID LINK): https://geni.us/4ddNx
On Newegg (PAID LINK): https://geni.us/BkMqJ

Buy: Seasonic FOCUS GX-1000
On Newegg (PAID LINK): https://geni.us/aoeGLS5
On B&H (PAID LINK): https://geni.us/ksm2bTy 

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1245279-we-made-the-perfect-couples-pc/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Private Internet Access VPN: https://lmg.gg/pialinus2
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

