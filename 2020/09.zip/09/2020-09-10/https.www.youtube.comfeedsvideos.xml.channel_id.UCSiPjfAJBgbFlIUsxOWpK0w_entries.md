# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Our new single: Stress Me Out
 - [https://www.youtube.com/watch?v=N4Keb583jf0](https://www.youtube.com/watch?v=N4Keb583jf0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2020-09-10 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 "Stress Me Out," by Pomplamoose
Pre-order your copy of the new album 'Invisible People' on vinyl!! https://qrates.com/projects/20880 
Pre order ends Oct 31st! 

This is the second single released from our album "Invisible People" coming December 2020!

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

An original song by Pomplamoose.

Lyrics for Stress Me Out:

Holding it all in my body
I’m holding it all in my bones
Holding it all in the curves of my neck
In these aching chromosomes
 
I’m old enough to know somebody
Old enough to choose my home
I’m holding it all till it all falls apart
Till I’d rather be alone
 
No matter what you say
I’m taking painkillers all day
 
You stress me out
You stress me the fuck out
I gotta get out
I got to get the fuck out
You stress me out
You stress me the fuck out
I gotta get out
I got to get the fuck out
 
Holding out for no good reason
Holding your love at arm’s length
I told you I wouldn’t be leaving
But I shouldn’t have told you that
 
No matter what you say
I’m takin’ painkillers all day
 
You stress me out
You stress me the fuck out
I gotta get out
I got to get the fuck out
You stress me out
You stress me the fuck out
I gotta get out
I got to get the fuck out

I’m old enough to read the writing
And oh how I’d love to just leave
So don’t hold it against me when I fall apart
Cause I’m at capacity

No matter what you say
There’s just no way I’m gonna stay


CREDITS

Lead Vocals: Nataly Dawn
Keys: Jack Conte
Guitar: Brian Green 
Bass: Ryan Lerman
Drums: Rob Humphreys
Engineers: Chris Sorem & Tim Sonnefeld
Mixing/Mastering: Jack Conte
Producer: Jack Conte

Director: George Sloan
Cinematographer: Dawn Shim
Editor: Dominic Mercurio
1st Assistant Camera: Carlos Lopez
Production Assistant: Cecilia Bellissimo

Filmed on location in Pasadena, California.

