# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## ASK HIGH JULIE - Get to know me Q&A
 - [https://www.youtube.com/watch?v=MRtRRmNRyLE](https://www.youtube.com/watch?v=MRtRRmNRyLE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2020-09-10 00:00:00+00:00

You asked the Q's, I provide the A's.

