# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## How To STOP The Negative Voice In Your Head! | Russell Brand
 - [https://www.youtube.com/watch?v=0yIxrZSBKfc](https://www.youtube.com/watch?v=0yIxrZSBKfc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-09-10 00:00:00+00:00

Do you have negative thoughts? Unkind to yourself? This is how I deal with that voice in your head that tells you you're not good enough.

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

