# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Surface Duo Review: The Good, The Bad & The Ugly!
 - [https://www.youtube.com/watch?v=0fB2cQFp008](https://www.youtube.com/watch?v=0fB2cQFp008)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-09-10 00:00:00+00:00

Surface Duo: The dual screen Microsoft folding phone.

MKBHD Merch: http://shop.MKBHD.com
Surface Duo skins: https://dbrand.com/duo

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: http://youtube.com/20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by Microsoft for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

