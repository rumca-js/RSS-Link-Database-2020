# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## How Spiritual People Make Money
 - [https://www.youtube.com/watch?v=mfk2S4nuQjY](https://www.youtube.com/watch?v=mfk2S4nuQjY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-09-10 00:00:00+00:00

Grab Your Enzymes Here - https://masszymes.com/jp

My Purple Flower Headband - https://amzn.to/3h8i9Y8

Brent's Channel - https://www.youtube.com/c/brentpella/

How spiritual people make money is always based on sharing their abundance with other people. Using very little action and maximum amounts of the law of attraction, spiritual people create maximum abundance while usually staying broke. Learn how to become rich, abundant, and spiritual all while staying broke.

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

As an Amazon Associate, I earn a small commission from qualifying purchases. Some of the links are affiliate links and if you decide to buy products through them I earn a tiny commission. It costs you nothing but helps support the channel and future videos.

