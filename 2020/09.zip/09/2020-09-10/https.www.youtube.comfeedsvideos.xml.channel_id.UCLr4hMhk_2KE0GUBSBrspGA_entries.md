# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Xiaomi Mi 10 Ultra
 - [https://www.youtube.com/watch?v=RMpdoDC3Vpk](https://www.youtube.com/watch?v=RMpdoDC3Vpk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-09-10 00:00:00+00:00

Mi 10 Ultra możecie kupić tu: https://bit.ly/2DNjUMB
A przetestować w Centrum Testów: https://bit.ly/32haLFx
Ładowarka samochodowa: https://bit.ly/2GGuWUX

Moje sociale: 
Insta: http://bit.ly/InstaKlawiatur 
Twitter: http://bit.ly/TTKlawitera
FB: http://bit.ly/FBKlawiatur

