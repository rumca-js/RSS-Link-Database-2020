# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## The Dangers of Protests
 - [https://www.youtube.com/watch?v=j-OfIsmhed0](https://www.youtube.com/watch?v=j-OfIsmhed0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-09-11 00:00:00+00:00

JRE #1535 w/Tim Kennedy Now Available on Spotify:
https://open.spotify.com/episode/6SeHbFUG4TYkVqjoNozas8

