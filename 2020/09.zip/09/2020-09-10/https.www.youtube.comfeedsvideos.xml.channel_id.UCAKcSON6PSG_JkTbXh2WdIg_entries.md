# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Ben Folds - three live performances (2015; 2019)
 - [https://www.youtube.com/watch?v=68ZfU7EWOcM](https://www.youtube.com/watch?v=68ZfU7EWOcM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-09-11 00:00:00+00:00

Saturday, Sept. 12, is the birthday of singer-songwriter Ben Folds, so in honor of that, we're sharing three live performances by Ben Folds. The first two were recorded live in 2015 at The Current's MicroShow at the Turf Club in St. Paul, Minn.; the third performance comes from a June 2019 episode of "Live From Here," recorded live at Tanglewood in western Massachusetts.

SONGS PERFORMED
0:00 "Phone in a Pool"
3:55 "Capable of Anything"
7:27 "The Luckiest"

CREDITS
Video & Photo: Nate Ryan; Will Keeler; Ben Miller
Audio: Michael DeMark; Sam Hudson
Production: Derrick Stevens; Jeffy Hnilicka

FIND MORE:
2015 MicroShow at the Turf Club: https://www.thecurrent.org/feature/2015/12/07/ben-folds-performs-at-the-turf-club-in-st-paul
2019 Live From Here episode: https://www.livefromhere.org/shows/2019/06/15/ben-folds-im-with-her-tig-notaro

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#benfolds

## J. Roddy Walston & the Business - two songs at The Current (2017, 2013)
 - [https://www.youtube.com/watch?v=oUqH_DWGPSw](https://www.youtube.com/watch?v=oUqH_DWGPSw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-09-10 00:00:00+00:00

On September 9, 2013, J. Roddy Walston and the Business performed for the first time in The Current studio. They visited our studio again almost exactly four years later — on Sept. 15, 2017 — with a stop in between to play at First Avenue for The Current's 10th Birthday Party on Jan. 24, 2015. Marking all that, here are a couple performances by J. Roddy Walston and the Business, recorded live in our studio. A great band, they amicably announced their dissolution at the end of 2019.

SONGS PERFORMED
0:00 "Blade of Truth" (2017)
3:51 "Marigold" (2013)

PERSONNEL
J. Roddy Walston – piano, guitar, vocals
Steve Colmus – drums
Logan Davis – bass
Billy Gordon – guitar

CREDITS
Video & Photo: Steel Brooks; Nate Ryan
Audio: Michael DeMark
Production: Derrick Stevens

FIND MORE:
2013 studio session:
https://www.thecurrent.org/feature/2013/09/09/j-roddy-walston-live
2013 Guitar Collection interview:
https://www.thecurrent.org/feature/2013/09/18/the-currents-guitar-collection-j-roddy-walston
2017 studio session:
https://www.thecurrent.org/feature/2017/09/15/j-roddy-walston-and-the-business-songs-forthcoming-album-destroyers-of-the-soft-life

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#jroddywalston #jroddywalstonandthebusiness

