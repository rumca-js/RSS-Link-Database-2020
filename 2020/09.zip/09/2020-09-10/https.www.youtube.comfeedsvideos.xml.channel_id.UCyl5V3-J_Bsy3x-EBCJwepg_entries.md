# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Anonymous Sources/Demon Bread/Weird Christian Videos News Show 9.11.2020
 - [https://www.youtube.com/watch?v=lnKHkvBLuOc](https://www.youtube.com/watch?v=lnKHkvBLuOc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-09-11 00:00:00+00:00

In this episode of The Babylon Bee Podcast, Kyle and Ethan talk about the week’s biggest stories like California’s progressive green energy grid leading the nation in brownouts, anonymous sources totally confirming that Trump punched a baby, and a man blowing up his house in an attempt to swat a fly. Kyle and Ethan also dig into the video archives to find really weird videos from Christian music and educational programming to talk about how weird they are. For example, why is that loaf of bread talking to us?

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Gain Access to the Exclusive Content and Writing Forum: https://babylonbee.com/plans

The Official Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

## Trump Punched A Baby, California Black Outs, And Squirrels — The BNN Week In Review 9-11-2020
 - [https://www.youtube.com/watch?v=H1c69r4xg_0](https://www.youtube.com/watch?v=H1c69r4xg_0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-09-11 00:00:00+00:00

This is your BNN week in review. 

Did Trump punch a baby? According to anonymous sources he did. What's going on with California black outs? Also, scientists say the squirrels are up to something. Babylon Newsroom Journalists Guy Curtis, Samantha Kurlock, and Stuart Stringer report. 

These updates and more in our latest video.

## Bible Causes A Scene On Nude Beach
 - [https://www.youtube.com/watch?v=EboB5gbA3_U](https://www.youtube.com/watch?v=EboB5gbA3_U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-09-10 00:00:00+00:00

A.L. Van Den Herik joins Kyle and Ethan to discuss how Christians come to faith. Is it through reasoned arguments alone or something else?

FULL ▶️  https://youtu.be/-bihkoHXEjw

