# Source:Kołem się toczy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw, language:pl-PL

## Morawy Południowe - najładniejsze miejsce w Czechach? 🚴‍♂️💨 Toskania jest bliżej niż myślisz
 - [https://www.youtube.com/watch?v=RPADuCQTv8Y](https://www.youtube.com/watch?v=RPADuCQTv8Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw
 - date published: 2020-09-10 00:00:00+00:00

Książka "Rower to jest Świat"📙👉 https://rowertojestswiat.pl/

Kolejny raz szukamy ciekawych miejsc w Czechach. Jednak pierwszy raz na Morawach - uznawanych przez wielu za najładniejszy region Czech. Czy słusznie?
Link do bookingu: https://www.booking.com/?aid=1191384

Kanał Anity 👉 https://bit.ly/3m8KVvw
Instagram Anity 👉 https://www.instagram.com/banita_travel/

Strona z fotospotami: https://www.photohound.co/guide/southern-moravia

►►Zachęcam do subskrypcji: http://bit.ly/2cmWbSO 

Wycieczkę w poszukiwaniu atrakcji i ciekawych miejsc na Morawach zaczynamy w Brnie i kierujemy się od razu na południe. Można powiedzieć więc że cała wycieczka będzie miała miejsce dokładniej mówiąc na Morawach Południowych. Wśród licznych winnic przemieścimy się do kapitalnie położonego miasta Znojmo, dalej do Mikulova w poszukiwaniu pięknych ruin zamków, dalej do Zamku w Lednicach no i na sam koniec do ponoć najpiękniejszego regionu Moraw - Czeskiej Toskanii. Miejsca uwielbianego przez fotografów. Zwłaszcza wiosną.

Zapraszam też na:
Facebook: http://bit.ly/2flU84f
Instagram: http://bit.ly/2eTrIMc
Blog: http://kolemsietoczy.pl/

No i spis treści odcinka:

00:00 - 01:25 Wstęp: Brno - szybkie zwiedzanie miasta.
01:26 - 02:40 Morawy - atrakcje, ciekawe miejsca
02:41 - 03:33 Trasa rowerowa przez Morawy Południowe
03:34 - 05:00 Znojmo - ciekawe miejsca, najładniejsze miasto!
05:01 - 08:22 Mikulov i jego winnice
08:22 - 10:56 Pałac Lednice i Valtice...
10:57 - 14:44 Ciekawostki o Morawach
14:45 - 17:27 Najlepsze fotospoty na Morawach

