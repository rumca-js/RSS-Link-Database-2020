# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Dehd - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=txNUN0sPG6Q](https://www.youtube.com/watch?v=txNUN0sPG6Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-09-11 00:00:00+00:00

http://KEXP.ORG presents Dehd performing live in their studio. Recorded exclusively for KEXP.

Filmed by Tom Balla
Assisted by Dan Armentrout
Edited by Jim Beckmann

http://dehd.horse
http://kexp.org

## Dehd - Full Performance w/ Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=q9s808U7tWY](https://www.youtube.com/watch?v=q9s808U7tWY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-09-11 00:00:00+00:00

http://KEXP.ORG presents Dehd sharing songs recorded live in their studio, exclusively for KEXP, and talking to DJ Morgan. Recorded September 10, 2020.

Session filmed by Tom Balla
Assisted by Dan Armentrout
Edited by Jim Beckmann

http://dehd.horse
http://kexp.org

