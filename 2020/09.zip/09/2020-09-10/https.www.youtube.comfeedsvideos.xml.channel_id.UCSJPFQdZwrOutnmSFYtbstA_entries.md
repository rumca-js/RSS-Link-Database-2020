# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Mulan - The Movie Nobody Wants
 - [https://www.youtube.com/watch?v=kIH-eFqBLP4](https://www.youtube.com/watch?v=kIH-eFqBLP4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-09-10 00:00:00+00:00

So between the beer bug and political fallout, it seems Mulan is shaping up to be one of the biggest bombs in cinematic history. Let's take a look and see if it deserves all the hate it's getting. 



Want to help support this channel? 
Patreon: https://www.patreon.com/TheCriticalDrinker
SubscribeStar: https://www.subscribestar.com/the-critical-drinker
My books on Amazon: https://www.amazon.com/Will-Jordan/e/B00BCO7SA8%3Fref=dbs_a_mng_rwt_scns_share

