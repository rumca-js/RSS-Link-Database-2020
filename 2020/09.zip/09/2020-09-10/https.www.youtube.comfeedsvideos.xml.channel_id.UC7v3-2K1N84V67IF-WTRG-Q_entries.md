# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Dune - Official Trailer (My Thoughts)
 - [https://www.youtube.com/watch?v=iq_xi3FlX8E](https://www.youtube.com/watch?v=iq_xi3FlX8E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-09-10 00:00:00+00:00

Ok, so this is pretty much me gushing about all the positives of this trailer, but I'm kinda finding it hard to see any negatives thus far. Anyhow, Here are my thoughts on the first trailer for DUNE!

Watch the trailer here: https://www.youtube.com/watch?v=n9xhJrPXop4&t=1s&ab_channel=WarnerBros.Pictures

