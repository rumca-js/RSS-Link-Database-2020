# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## The new Huawei OS is finally coming to phones!
 - [https://www.youtube.com/watch?v=E9yFiZHXWi4](https://www.youtube.com/watch?v=E9yFiZHXWi4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2020-09-11 00:00:00+00:00

Sponsored by Brilliant. The first 200 people to sign up get 20% off an annual plan at https://brilliant.org/TFC 

This episode on Nebula: https://watchnebula.com/videos/the-friday-checkout-the-new-huawei-os-is-finally-coming-to-phones

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► Quiz ◄◄◄ 

Weekly tech quiz: https://crrowd.com/quiz 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► TechAltar links ◄◄◄ 

Merch: 
https://enthusiast.store 



Crrowd Discord:
https://discord.gg/npKQebe


Social media:
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 
If you want to support TechAltar directly: 
https://flattr.com/@techaltar 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► Attributions ◄◄◄ 

Music by Edemski: 

https://soundcloud.com/edemski


▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► Timestamps ◄◄◄ 


0:00 Intro
0:56 HarmonyOS 2.0
3:05 The App Gallery strategies
4:52 No more screens or chips for Huawei

