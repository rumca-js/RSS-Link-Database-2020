## Netflix Defends ‘Cuties’ as ‘Social Commentary’ Against Sexualization of Young Children
 - [https://variety.com/2020/digital/news/netflix-defends-cuties-against-sexualization-young-girls-1234766347/](https://variety.com/2020/digital/news/netflix-defends-cuties-against-sexualization-young-girls-1234766347/)
 - RSS feed: https://variety.com
 - date published: 2020-09-10 08:25:33+00:00

Netflix Defends ‘Cuties’ as ‘Social Commentary’ Against Sexualization of Young Children

