# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## A Chat With Joe Abercrombie
 - [https://www.youtube.com/watch?v=WNHbYVN6p9o](https://www.youtube.com/watch?v=WNHbYVN6p9o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-09-11 00:00:00+00:00

I got to sit down with the mastermind behind the First Law series, Joe Abercrombie! 
Preorder The Trouble With Peace: https://amzn.to/2DML5am
UK link: https://www.amazon.co.uk/Untitled-Abercrombie-3-4-Joe/dp/0575095911/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1599834301&sr=8-1
Signed copies: https://www.waterstones.com/book/the-trouble-with-peace/joe-abercrombie/9781473232679
Steven Pacey Abercrombie Speaking event: https://www.eventbrite.co.uk/e/joe-abercrombie-steven-pacey-in-conversation-for-the-trouble-with-peace-tickets-118451045265

Podcast: https://afictionalconversation.podbean.com/
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## How Ghibli Screwed Earthsea
 - [https://www.youtube.com/watch?v=s6akqmZmzTk](https://www.youtube.com/watch?v=s6akqmZmzTk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-09-10 00:00:00+00:00

Studio Ghibli made an Earthsea based movie titles Tales From Earthsea. It was... not the greatest adaptation to say the least.
For a limited time, use the link in my description to get a free trial of Skillshare Premium Membership: https://skl.sh/danielgreene09201
Source: https://www.ursulakleguin.com/gedo-senki-1

Podcast: https://afictionalconversation.podbean.com/
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

