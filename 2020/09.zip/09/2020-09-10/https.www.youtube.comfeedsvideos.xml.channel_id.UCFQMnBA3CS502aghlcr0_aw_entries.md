# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Kevin David Created a Plagiarism Pandemic
 - [https://www.youtube.com/watch?v=xcS0awaHYJ4](https://www.youtube.com/watch?v=xcS0awaHYJ4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-09-10 00:00:00+00:00

Kevin David is one of hundreds of Youtubers who's gameplan for content is to farm content from other people, throw it in a word salad machine and spit it out the same, but slightly different. People like Richard Yu, Kevin David, are just ripping off competitors and not coming up with their own ideas. Now bear in mind everything that I say in this video is strictly my opinion but let me also remind everyone that plagiarism is considered by many to be a form of theft, plagiarism is an intellectual form of theft. This is why some have called Kevin David "Copycat Kevin" or "Copyright Kevin" due to his extreme copying behavior. 

If we don't start calling these people out like Kevin David when they blatantly rip off other people's content, we will be incentivizing a generation of 'entrepreneurs' to do the exact same thing and become copies of a copy of a copy...
#kevindavid #coffeezilla #plagiarism

