# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Pandemic Update, US UK Africa
 - [https://www.youtube.com/watch?v=hQ5SUsDSxpY](https://www.youtube.com/watch?v=hQ5SUsDSxpY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2020-09-24 00:00:00+00:00

Looks like 10% in US now exposed

6,934,233 (21%)

Deaths, 201,190

https://www.worldometers.info/coronavirus/country/us/

Serological surveys

Population, 330 million

Infections, 33 million

Dr. Robert Redfield to Senate Committee on Health

https://www.independent.co.uk/news/world/americas/coronavirus-cdc-usa-exposed-covid-19-infections-cases-herd-immunity-b559043.html

The preliminary results in the first round show that a majority of our nation, more than 90% of the population, remains susceptible

Expects there to be about 700 million doses of vaccines available by April

I think that's going to take us April, May, June, possibly July

to get the entire American public completely vaccinated

Companies have begun manufacturing vaccines

Dr. Fauci, expects 50 million doses to be available in November

100 million by the end of December

Cases rising 

North Dakota, Utah, Texas, South Dakota (per capita)

https://rt.live

UK

Exposure notification system app 

Points towards testing for asymptomatic

Self-isolation

Does not collect data

Glasgow university

Contact outside household bubbles

124 tested positive

600 now self-isolating in university accommodation

Students going home for the weekend?

ONS, 4 – 10 September

59,800 people community infections

1 in 900 people

6,000 new cases per day

Clear evidence of an increase in the number of people testing positive for COVID-19 aged 2 to 34 years

Higher infection rates in the North West and London

Wales

1,500 people infected

1 in 2,000 people 

ONS, Deaths, 4 – 10 September

https://www.ons.gov.uk/peoplepopulationandcommunity/birthsdeathsandmarriages/deaths/bulletins/deathsregisteredweeklyinenglandandwalesprovisional/latest

Week 37, 99 mentioned "novel coronavirus (COVID-19)"

1.0% of all deaths in England and Wales
 
Death certificate data: COVID-19 as the underlying cause of death (CEBM 16th September)

https://www.cebm.net/covid-19/death-certificate-data-covid-19-as-the-underlying-cause-of-death/

COVID-19 is the underlying cause of death (Died FROM)

COVID-19 may be present on the death certificate as a significant condition contributing to death but not the underlying cause (Died WITH)

Using, Public health England data

Up to 1st June

Early weeks

COVID -19 was the underlying cause of death in 92.2% of deaths (Died FROM)

i.e. 7.8% did not have the disease as the underlying cause of death (Died WITH)

Last 8 weeks
Up to 28th August, underlying cause in 71.2% of deaths (Died FROM) 

i.e. 28.8% of deaths not directly caused by COVID-19 (Died WITH)

Scotland

Early weeks, up to 1st June

COVID-19 was the underlying cause in 94.6% of death (Died FROM)

i.e. 5.4 % did not have the disease as the underlying cause of death (Died WITH)

31st May to 10th August

76.3% from, main cause of death (Died FROM)

i.e. 23.7% did not have the disease as the underlying cause of death (Died WITH)

Worms and COVID in Africa

https://www.news-medical.net/news/20200519/Do-parasites-protect-against-SARS-CoV-2.aspx

Inflammation in severe clinical cases of COVID-19

Worms reduce inflammation and the immune response

Multiple sclerosis, inflammatory bowel disease, allergic and autoimmune diseases

Immunomodulators in Parasitic Infestation

Infections last for years

Host often does not become very sick

Parasite counts can remain stable

Therefore, parasitic incidence could be responsible for the low number of symptomatic cases and deaths in Africa

Parasites and their protection against COVID-19- Ecology or Immunology?

https://www.medrxiv.org/content/10.1101/2020.05.11.20098053v1

Methods: 

COVID-19 cases in comparison to data on helminths and malaria

Results: 

Africa COVID

0.029 out of 3.3 million (0.88%) cases

1,064 out of 238,628 (0.45%) deaths.

Africa Parasites

213 out of 229 million (93%) of all malaria cases globally

204 out of 229 million (89%) of schistosomiasis cases

271 out of 1068 million (25%) of soil-transmitted helminth cases

Europe COVID

1.5 out of 3.3 million (45%) of global cases

142,667 out of 238,628 (59%) deaths

Europe Parasites

Malaria no cases

Schistosomiasis no cases

5.8 out of 1068 million (0.55%) soil-transmitted helminths cases

Inverse correlation between the incidence of COVID-19 and malaria 

Inverse correlation between the incidence COVID-19 and soil-transmitted helminths

Countries with endemic malaria, soil-transmitted helminths and schistosomiasis had less COVID-19

Populations who migrate from endemic parasitic infestation lose their parasites

Studies to elucidate the relationship between parasitic infections and susceptibility to COVID-19 at an individual level are warranted

## Pandemic, Global Update
 - [https://www.youtube.com/watch?v=deBEJHy8LN0](https://www.youtube.com/watch?v=deBEJHy8LN0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2020-09-23 00:00:00+00:00

The top 10 causes of death

https://www.who.int/news-room/fact-sheets/detail/the-top-10-causes-of-death

56.9 million deaths worldwide in 2016

54% were due to the top 10 causes

Institute for Health Metrics and Evaluation

Independent global health research organization

University of Washington School of Medicine

Rigorous and comparable measurement, world’s health problems, evaluates strategies

http://www.healthdata.org/covid/updates

Global Review

Cases are remaining constant

250,000 per day since August

Approximately one infection in 10 has been detected globally to date 

31, 483,001 = 314, 830, 010

Assuming 1,000,000 deaths

IFR = 0.32

Daily deaths are decline

Just over 5,000 a day in the last week 

Making COVID-19 the sixth-leading cause of global mortality

Progress in Latin America except Argentina

Surging cases in Europe

Continued epidemic expansion in India

Expect 

Decreasing vigilance of the public in many countries

Northern Hemisphere seasonality will lead to a major global surge in daily cases

Deaths increasing late November and December. 

Projections

30,000 deaths a day in December

January 1, 2021, total deaths, 2,667,497

Fourth leading cause of death

Herd immunity strategy

Up to 70% of individuals can get infected in a situation of near-random mixing 

Actual percentage probably less

No further government action when the winter surge begins in the Northern Hemisphere

Deaths by January 1, a total of 3,618,640. 

Mask use can save more than 730,000 lives by January 1

43% of the deaths expected between now and the end of 2020

More on herd immunity

Multiple locations in Latin America are now at over 40%

Ecuador and Mexico City

Indicating percentages increase to at least these levels

With herd immunity at 40% cumulative infection

Highly optimistic

Less than one quarter through the epidemic on January 1

10.4 million deaths

With herd immunity at 50% cumulative infection

13.1 million deaths

Only if we end the pandemic everywhere can we end the pandemic anywhere.

https://ourworldindata.org/coronavirus


Having flu and Covid-19 together

https://www.theguardian.com/world/2020/sep/22/flu-and-covid-19-at-same-time-significantly-increases-risk-of-death#img-1

Prof Jonathan Van-Tam 

Significantly increases risk of death

Double whammy

n = 58 people 

UK, early phase of the pandemic.

Hospitalised

Tested for both viruses

Very ill

Coinfection, deaths, 43%

COVID only, deaths, 26.9%

If you do think you have either flu or Co Vi D stay at home and self-isolate

30, 000, 000 doses of flu vac

50-64 will be offered flu vaccination

Children 2 – 11

Essential workers

