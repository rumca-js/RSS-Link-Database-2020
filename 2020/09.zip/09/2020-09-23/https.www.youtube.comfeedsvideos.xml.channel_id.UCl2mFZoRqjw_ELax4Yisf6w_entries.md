# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## 90% of restaurants not making rent in NYC - leases can't be renegotiated. Businesses are dying.
 - [https://www.youtube.com/watch?v=vt_3OLs_lXE](https://www.youtube.com/watch?v=vt_3OLs_lXE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-09-23 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
https://nypost.com/2020/09/21/almost-90-percent-of-nyc-bars-and-restaurants-couldnt-pay-august-rent/    
http://archive.is/FKACg    
https://www.cnn.com/2020/09/19/us/nyc-covid-restaurant-surcharge-trnd/index.html
👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

