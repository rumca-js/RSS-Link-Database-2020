# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Can You Actually Game in 8K? (RTX 3090 Gameplay!)
 - [https://www.youtube.com/watch?v=kFz9afj8lu0](https://www.youtube.com/watch?v=kFz9afj8lu0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-09-23 00:00:00+00:00

Gaming in 8K with an RTX3090 is surprisingly impressive! Uploaded in 8K. RIP to your GPU.
*8K may or may not take up to a week to process lol

RTX3090 8K gaming: https://nvidia.com/en-us/geforce/technologies/8k/
Maingear F131: http://www.maingear.com/8kgaming
LG 8K TV: http://lgoledtv.co/MKBHD-8K

LinusTechTips Review: https://youtu.be/YjcxrfEVhc8
HardwareCanucks Review: https://youtu.be/OXH1YxzIeW4
Dave2D Review: https://youtu.be/jgLOfZaV3Ac

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: 
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Computer/GPU provided by Maingear for video.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

