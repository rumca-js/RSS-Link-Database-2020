# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Why Is Trump Causing So Many Celebrities To Snap?
 - [https://www.youtube.com/watch?v=jc_28QJ1Avk](https://www.youtube.com/watch?v=jc_28QJ1Avk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-09-24 00:00:00+00:00

Kyle and Ethan discuss Jim Gaffigan’s TDS twitter rant about Trump.

## Will The Government Be Held Accountable For Their Extreme Over-Reaction To COVID?
 - [https://www.youtube.com/watch?v=T3rKLWq8kKE](https://www.youtube.com/watch?v=T3rKLWq8kKE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-09-23 00:00:00+00:00

Michael Malice join Kyle and Ethan to discuss the insanity which is government overreach to solve “problems.”

