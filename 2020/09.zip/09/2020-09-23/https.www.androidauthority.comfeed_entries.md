# Source:Android Authority, URL:https://www.androidauthority.com/feed/, language:en-US

## Sling is the first live streaming TV service to let you video chat with friends
 - [https://www.androidauthority.com/sling-tv-watch-party-video-chat-1161452/](https://www.androidauthority.com/sling-tv-watch-party-video-chat-1161452/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2020-09-23 17:44:32+00:00

Your friends might not even need a subscription to watch.

