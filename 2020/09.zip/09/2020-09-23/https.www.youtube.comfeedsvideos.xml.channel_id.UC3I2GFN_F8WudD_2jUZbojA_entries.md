# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Isolated Tracks Episode 3: Honey by King Gizzard and the Lizard Wizard
 - [https://www.youtube.com/watch?v=5BJn1tgAQfk](https://www.youtube.com/watch?v=5BJn1tgAQfk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-09-24 00:00:00+00:00

In this episode of Isolated Tracks we talk to Stu Mackenzie from King Gizzard and the Lizard Wizard. KEXP Audio Producer Julian Martlew attempts to keep up as he explores the sounds that make up the song "Honey" a single released in 2020. 

To watch the video and hear the full song: https://www.youtube.com/watch?v=ADj2jDqT4uY
 @King Gizzard And The Lizard Wizard 

http://kexp.org

