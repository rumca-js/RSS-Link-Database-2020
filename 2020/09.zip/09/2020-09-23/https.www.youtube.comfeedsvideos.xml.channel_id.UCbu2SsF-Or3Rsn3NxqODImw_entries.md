# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Firearms Expert Reacts To Tommy Gun Clips From Games
 - [https://www.youtube.com/watch?v=6vm-6CJ2zaY](https://www.youtube.com/watch?v=6vm-6CJ2zaY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-09-24 00:00:00+00:00

Jonathan Ferguson, Keeper of Firearms & Artillery at the Royal Armouries, reacts to some Tommy Gun gameplay clips from Call of Duty: WW2, Mafia: Definitive Edition, Medal of Honor: Allied Assault, King Kong, and TimeSplitters 2.

If you're interested in seeing more of Jonathan, you can check out more from the Royal Armouries right here. - https://www.youtube.com/user/RoyalArm…

If you would like to support the Royal Armouries, you can make a charitable donation to the museum here. - https://royalarmouries.org/support-us/donations/ 

And if you would like to become a member of the Royal Armouries, you can get membership here. - https://royalarmouries.org/support-us/membership/

## Mafia: Definitive Edition Review
 - [https://www.youtube.com/watch?v=uUuOxDPbFJk](https://www.youtube.com/watch?v=uUuOxDPbFJk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-09-24 00:00:00+00:00

Dated gameplay drags down this impressive remake of an 18-year-old classic.

Richard played the original Mafia back in 2002 and spent nine hours completing the remake on PC. Code was provided by the publisher.

## Double Your K/D In 1 Week - Can A Game Fix Your Call of Duty Shots In 1 Week?
 - [https://www.youtube.com/watch?v=nnVn45qmGfA](https://www.youtube.com/watch?v=nnVn45qmGfA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-09-23 00:00:00+00:00

Tired of losing loot in Escape From Tarkov, being sent to the Warzone gulag in Call Of Duty: Modern Warfare, or feeling the pressure of his team watching him in Valorant, Dave installed AimLab.

 Did it help his aim? How much did his K/D improve? Do these things even work?

AimLab is a free early access tool that's build to help players improve their aim, reaction times, flick shots and more while using a suite of training tools as well as their own in-game AI to target a player's weaknesses.

## Metal Gear Solid Returning To PC? | Save State
 - [https://www.youtube.com/watch?v=b2QrheLBaLw](https://www.youtube.com/watch?v=b2QrheLBaLw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-09-23 00:00:00+00:00

In today's Save State, Persia talks about Metal Gear Solid favorites possibly coming back to PC, a trademark renewal for Pokemon HeartGold and SoulSilver, and Nintendo accidentally leaking a new Kirby game. 

In this video, Persia talks about recent ratings and images spotted on the Taiwan Digital Rating Committee’s game site that hint at a few Metal Gear Solid favorites returning to PC. There hasn't been any announcement of new Metal Gear Solid PC ports, but Konami has repackaged PC ports in the past and has already re-released Metal Gear Solid titles in past collections. Tokyo Game Show is this weekend and Konami is scheduled for two panels where we might get more details.

Persia also talks about Nintendo renewing its trademarks for Pokemon HeartGold and SoulSilver. Japanese trademarks typically expire after 10 years of being filed, which corresponds with the game's lifespan. The renewal includes various products and services, but there's no mention of games.

And lastly, Persia covers Nintendo accidentally leaking Kirby Fighters 2 on its Game Finder tool. The Game Finder tool is designed to help parents pick Nintendo games for their kids. According to the listing, in Kirby Fighters 2, players will be able to choose from a pool of Kirby’s most iconic copy abilities as they fight to be the last Kirby standing. The now-deleted listing also mentioned new playable characters like Waddle Dee and King Dedede. 

This is your Save State for Wednesday, September 23rd.

