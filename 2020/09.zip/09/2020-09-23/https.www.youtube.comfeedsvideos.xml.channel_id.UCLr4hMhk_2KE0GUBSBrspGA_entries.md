# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Telewizor do instagrama - Samsung The Sero, Zhiyun Smooth XS, Apple Watch 6
 - [https://www.youtube.com/watch?v=iMX-qpC5Eq8](https://www.youtube.com/watch?v=iMX-qpC5Eq8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-09-24 00:00:00+00:00

Telewizor: https://bit.ly/3i2IKWS
Gimbal: https://bit.ly/33TIxjL
Apple Watch'e: https://bit.ly/363QmGc (SE), https://bit.ly/3csmSTD (seria 6)

Moje sociale: 
Insta: http://bit.ly/InstaKlawiatur 
Twitter: http://bit.ly/TTKlawitera
FB: http://bit.ly/FBKlawiatur

Muza z filmów: https://spoti.fi/3fgBNRu

