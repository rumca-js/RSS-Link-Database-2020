# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Admiral Holdo - A Toxic Leader
 - [https://www.youtube.com/watch?v=qD8FHKOFgCg](https://www.youtube.com/watch?v=qD8FHKOFgCg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-09-30 00:00:00+00:00

Join me as I break down the character and command decisions made by Admiral Holdo from The Last Jedi, and why she is a perfect example of toxic leadership.

