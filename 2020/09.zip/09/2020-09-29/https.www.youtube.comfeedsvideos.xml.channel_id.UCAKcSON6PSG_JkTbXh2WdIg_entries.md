# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Listen to Looch: 'Rolling Stone: Life and Death of Brian Jones'
 - [https://www.youtube.com/watch?v=ayDYsO3jGFk](https://www.youtube.com/watch?v=ayDYsO3jGFk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-09-30 00:00:00+00:00

Mary Lucia talks about a documentary, streaming now, that's all about the late Brian Jones, one of the founding members of the Rolling Stones.

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#rollingstones #brianjones #documentary

## Songhoy Blues - Virtual Session
 - [https://www.youtube.com/watch?v=maglwYwhjnM](https://www.youtube.com/watch?v=maglwYwhjnM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-09-30 00:00:00+00:00

Connecting with us from Bamako, Songhoy Blues' Oumar Toure caught up with Jill Riley and performed a few songs from their upcoming record, Optimisme, out October 23.

Songs Played:
03:57 Worry
07:16 Bamako
27:15 Dournia

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Dehd - Virtual Session
 - [https://www.youtube.com/watch?v=1rL8kjgQycg](https://www.youtube.com/watch?v=1rL8kjgQycg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-09-29 00:00:00+00:00

Dehd are a three-piece band out of Chicago comprising bassist and frontwoman Emily Kempf, guitarist Jason Balla and drummer Eric McGrady. In July, the band released "Flower of Devotion," their third full-length release that comes just a year after their preceding album, "Water."

Dehd's Emily Kempf joined The Current's David Safar to talk about "Flower of Devotion," what it's been like to be not touring in 2020, about about how she got into her other career (operating her tattoo business). She also introduces David and all of us to her new Keeshond. Emily's conversation with David is lively and lighthearted — a perfect warmup to the videos of Dehd performing three songs from the new album.

SONGS PERFORMED:
06:45 "Haha"
08:56 "Loner"
12:02 "Nobody"
All songs from Dehd's 2020 album, "Flower of Devotion," available on Fire Talk Records.

CREDITS:
Host: David Safar
Producer: Jesse Wiza
Engineer: Peter Ecklund

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#dehd #dehdband #dehdchicago

