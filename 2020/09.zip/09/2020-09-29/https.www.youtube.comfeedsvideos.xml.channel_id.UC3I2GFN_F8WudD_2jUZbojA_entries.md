# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Ana Tijoux Live on KEXP at Home
 - [https://www.youtube.com/watch?v=7fmCvzWcCbU](https://www.youtube.com/watch?v=7fmCvzWcCbU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-09-30 00:00:00+00:00

http://KEXP.ORG presents Ana Tijoux sharing an exclusive set of songs performed live for KEXP and joining DJ Chilly of KEXP's El Sonido to talk about her career and new music. Recorded September 23, 2020.

https://anatijoux.bandcamp.com
http://kexp.org

## Blimes and Gab - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=Rl52uHMEXYc](https://www.youtube.com/watch?v=Rl52uHMEXYc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-09-29 00:00:00+00:00

http://KEXP.ORG presents Blimes and Gab sharing an exclusive set of songs, featuring originals off of their debut album, Talk About It.

Songs:
Shellys (It's Chill)
Un Deux Trois
Sacred
Baptism
My Way

https://www.blimesandgab.com
http://kexp.org

