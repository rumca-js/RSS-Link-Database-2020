# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## High Score - Documentary (My Thoughts)
 - [https://www.youtube.com/watch?v=0GWIuToUW3A](https://www.youtube.com/watch?v=0GWIuToUW3A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-09-29 00:00:00+00:00

Thanks to Postmates for sponsoring.  For $5 off your first two orders click this link: https://postmates.onelink.me/5uYG/7d8ecbb

Netflix has a documentary chronicling the pivotal moments in gaming history, the game changers, rule breakers, and unsung heroes that would forge the hobby for the millions of us. Here are my thoughts on the series HIGH SCORE!

#HighScore

