# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Katie Melua - The Closest Thing To Crazy - live MUZO.FM
 - [https://www.youtube.com/watch?v=SLTEBySUYEY](https://www.youtube.com/watch?v=SLTEBySUYEY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-09-30 00:00:00+00:00

Katie Melua na żywo w MUZO.FM. Utwór The Closest Thing To Crazy pochodzi z płyty: Katie Melua - Call Off The Search. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Katie Melua: http://www.facebook.com/katiemeluamusic
Instagram Katie Melua: http://www.instagram.com/katiemeluaofficial
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm


Katie Melua - The Closest Thing To Crazy - lyrics

How can I think I'm standing strong,
Yet feel the air beneath my feet?
How can happiness feel so wrong?
How can misery feel so sweet?
How can you let me watch you sleep,
Then break my dreams the way you do?
How can I have got in so deep?
Why did I fall in love with you?

This is the closest thing to crazy I have ever been
Feeling twenty-two, acting seventeen,
This is the nearest thing to crazy I have ever known,
I was never crazy on my own:
And now I know that there's a link between the two,
Being close to craziness and being close to you.

How can you make me fall apart
Then break my fall with loving lies?
It's so easy to break a heart,
It's so easy to close your eyes.
How can you treat me like a child
Yet like a child I yearn from you?
How can anyone feel so wild?
How can anyone feel so blue?

This is the closest thing to crazy I have ever been
Feeling twenty-two, acting seventeen,
This is the nearest thing to crazy I have ever known,
I was never crazy on my own:
And now I know that there's a link between the two,
Being close to craziness and being close to you.

## Krzysztof Zalewski - Oddech - live MUZO.FM
 - [https://www.youtube.com/watch?v=tgeeSx2v904](https://www.youtube.com/watch?v=tgeeSx2v904)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-09-30 00:00:00+00:00

Krzysztof Zalewski na żywo w MUZO.FM. Utwór Oddech pochodzi z najnowszej płyty Krzysztofa Zalewskiego - Zabawa. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Krzysztof Zalewski: http://www.facebook.com/Zalef.Krzysztof
Instagram Krzysztof Zalewski: http://www.instagram.com/zalewskiofficial
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm 

#popolsku

## Swiernalis - koncert (MUZO.FM)
 - [https://www.youtube.com/watch?v=6vuk0y15eYU](https://www.youtube.com/watch?v=6vuk0y15eYU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-09-30 00:00:00+00:00

Swiernalis na żywo w MUZO.FM. Artysta wykonał na żywo utwory: Ogrodnik, Vulgar, Tron i Tango. Piosenki pochodzą z najnowszej płyty Swiernalisa - Psychiczny fitness. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Swiernalis: http://www.facebook.com/Swiernalis
Instagram Swiernalis: http://www.instagram.com/swiernalis
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm 

#popolsku

## Krzysztof Zalewski - wywiad MUZO.FM
 - [https://www.youtube.com/watch?v=c23PV529Bqw](https://www.youtube.com/watch?v=c23PV529Bqw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-09-29 00:00:00+00:00

Krzysztof Zalewski - wywiad MUZO.FM. Artysta opowiada o najnowszej płycie- Zabawa - a także o pisaniu hitów i... spokoju.


Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Krzysztof Zalewski: http://www.facebook.com/Zalef.Krzysztof
Instagram Krzysztof Zalewski: http://www.instagram.com/zalewskiofficial
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm 

#popolsku

