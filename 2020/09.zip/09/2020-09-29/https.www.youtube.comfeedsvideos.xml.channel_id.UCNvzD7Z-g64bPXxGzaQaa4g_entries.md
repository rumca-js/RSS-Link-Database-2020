# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 7 SURPRISES You Got For 100% Completing The Game [PART 2]
 - [https://www.youtube.com/watch?v=UHkafVMOlJM](https://www.youtube.com/watch?v=UHkafVMOlJM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-09-30 00:00:00+00:00

Completing a game 100% can often bring surprises. Some are rewarding, others are terrible. Here are MORE examples in the second part of our series of videos.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 10 WEIRD Gaming Stories of September 2020
 - [https://www.youtube.com/watch?v=VjlbrzBA4Ck](https://www.youtube.com/watch?v=VjlbrzBA4Ck)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-09-29 00:00:00+00:00

September was a weird month for gaming news, from Fall Guys surprises to Xbox Series X pre-order goofs. Here's a list of the craziest.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

