# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## The Connection Psychedelics Have to Early Christianity, Christmas
 - [https://www.youtube.com/watch?v=XS5qjEXS6oM](https://www.youtube.com/watch?v=XS5qjEXS6oM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-09-30 00:00:00+00:00

#1543 w/Brian Muraresku & Graham Hancock:
https://open.spotify.com/episode/0FwCgmkG2Cfb36etijDIho?si=swJOxAN8RCOwdfs7sl3r6A

## The Secrecy Behind the Origins of Psychedelics
 - [https://www.youtube.com/watch?v=Bum8BAIjc6o](https://www.youtube.com/watch?v=Bum8BAIjc6o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-09-30 00:00:00+00:00

#1543 w/Brian Muraresku & Graham Hancock:
https://open.spotify.com/episode/0FwCgmkG2Cfb36etijDIho?si=swJOxAN8RCOwdfs7sl3r6A

## Joe Rogan on Floyd Mayweather vs. Logan Paul
 - [https://www.youtube.com/watch?v=hef85Sni-GU](https://www.youtube.com/watch?v=hef85Sni-GU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-09-29 00:00:00+00:00

#1542 w/Cameron Hanes:
https://open.spotify.com/episode/56lMMfyHKa39Ct83oCv9j6

## Joe Rogan on Trump Saying He'd Debate Biden on the Show
 - [https://www.youtube.com/watch?v=wxcaxQKKs7g](https://www.youtube.com/watch?v=wxcaxQKKs7g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-09-29 00:00:00+00:00

#1542 w/Cameron Hanes:
https://open.spotify.com/episode/56lMMfyHKa39Ct83oCv9j6

