# Source:Laowhy86, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw, language:en-US

## 6 Things We CAN'T Get Used to in the USA
 - [https://www.youtube.com/watch?v=iB_rp2jr-8I](https://www.youtube.com/watch?v=iB_rp2jr-8I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw
 - date published: 2020-09-30 00:00:00+00:00

We've moved from China to the USA, and we've discovered some things we simply cannot get used to. From food, to driving. From people, to language. It's been an interesting adjustment.

Bitcoin - bc1qrvvga0c4kn69rlte47q0tzrhugn9pf426tqhvm
ETH -  0x456E5A9B875d4eF8DCb70eB1F7Fa376C520b206C

◘ Support me on Patreon for early release, and much more! http://www.patreon.com/laowhy86
◘ Or, if you prefer, Subscribestar - https://www.subscribestar.com/laowhy86

Car channel - https://www.youtube.com/worthlesswhips
ADVChina - https://www.youtube.com/advchina
SerpentZA - https://www.youtube.com/serpentza
ADVPodcasts - https://www.youtube.com/advpodcasts

◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

◘ OR Become a Sponsor on YouTube:
https://www.youtube.com/channel/UChvithwOECK5g_19TjldMKw/sponsor

◘ My TV show: Conquering Northern China:
https://vimeo.com/ondemand/conqueringnorthernchina

◘ Conquering Southern China
https://vimeo.com/ondemand/conqueringsouthernchina

◘ Discount code for both shows: laowinning

◘ Join me every week for videos about China! Don't forget to subscribe!
http://www.youtube.com/laowhy86

Be a Laowinner!
Like comment subscribe!

◘ Facebook:
http://www.facebook.com/laowhy86

◘ Instagram: 
http://instagram.com/laowhy86

◘ Music used most of the time - New World Hip Hop
https://soundcloud.com/apollodrivenz
https://www.youtube.com/channel/UCgirAE5d8ufiotRXmBZZbBQ

◘ Thanks so much to Zack P in Jilin for the background footage - 
https://www.youtube.com/channel/UCSDTBKPI4OxylEYLimVz0Fw

