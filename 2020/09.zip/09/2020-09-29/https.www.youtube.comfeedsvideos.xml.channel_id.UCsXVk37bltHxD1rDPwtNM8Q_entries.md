# Source:Kurzgesagt – In a Nutshell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsXVk37bltHxD1rDPwtNM8Q, language:en-US

## Is It Too Late To Stop Climate Change? Well, it's Complicated.
 - [https://www.youtube.com/watch?v=wbR-5mHI6bo](https://www.youtube.com/watch?v=wbR-5mHI6bo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsXVk37bltHxD1rDPwtNM8Q
 - date published: 2020-09-29 00:00:00+00:00

Head over to our shop to get exclusive kurzgesagt merch and sciency products designed with love. 
Getting something from the kurzgesagt shop is the best way to support us and to keep our videos free for everyone. 
►► https://kgs.link/shop-130
(Worldwide Shipping Available)

A special thanks to the team at Our World for helping us out with data and research!
https://ourworldindata.org/

Sources & further reading:
https://sites.google.com/view/sources-climate-solve/

This video is part of a series about climate change supported by Breakthrough Energy – a coalition founded by Bill Gates, that is working to expand clean-energy investment and support the innovations that will lead the world to net-zero carbon emissions. 
https://www.gatesnotes.com/Climate-and-energy?WT.mc_id=20200625100000_ClimateCtr2020_CTRKurt-YT_&WT.tsrc=CTRKurtYT


Climate Change is just too much. There is never any good news. Only graphs that get more and more red and angry. Almost every year breaks some horrible record, from the harshest heat waves to the most rapid Glacier melt. It’s endless and relentless. 

We have known for decades that rapid Climate Change is being caused by the release of Greenhouse Gases. But instead of reducing them, in 2019 the world was emitting 50% more CO2 than in the year 2000. And emissions are still rising. Why is that? Why is it  so hard to just stop emitting these gases?

OUR CHANNELS
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
German Channel: https://kgs.link/youtubeDE 
Spanish Channel: https://kgs.link/youtubeES 


HOW CAN YOU SUPPORT US?
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
This is how we make our living and it would be a pleasure if you support us!

Get Merch designed with ❤ from https://kgs.link/shop-130  
Join the Patreon Bird Army 🐧 https://kgs.link/patreon  


DISCUSSIONS & SOCIAL MEDIA
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
Reddit:            https://kgs.link/reddit
Instagram:     https://kgs.link/instagram
Twitter:           https://kgs.link/twitter
Facebook:      https://kgs.link/facebook
Discord:          https://kgs.link/discord
Newsletter:    https://kgs.link/newsletter


OUR VOICE
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
The Kurzgesagt voice is from 
Steve Taylor:  https://kgs.link/youtube-voice


OUR MUSIC ♬♪
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
700+ minutes of Kurzgesagt Soundtracks by Epic Mountain:

Spotify:            https://kgs.link/music-spotify
Soundcloud:   https://kgs.link/music-soundcloud
Bandcamp:     https://kgs.link/music-bandcamp
Youtube:          https://kgs.link/music-youtube
Facebook:       https://kgs.link/music-facebook

The Soundtrack of this video:

Soundcloud:   https://bit.ly/347oNcH
Bandcamp:     https://bit.ly/3cI1hGN


🐦🐧🐤 PATREON BIRD ARMY 🐤🐧🐦
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
Many Thanks to our wonderful Patreons from http://kgs.link/patreon who support us every month and made this video possible:

Keanu Vestil, Xavier, Antonio Tavano, Scott James, Camfifty5, Michael, Paul Barth, Christian Puelacher, Katie Barton, Cole Bowden, Andreas Rautner, Sovos, Alejandro Uresti, couchy, Bill Hochberg, John Specht, Lander Verhack, Vlad Mustiață, Oliver Kurtz, Mischa Blazer, Josh Yelavich, Islam Mohamed, Robrecht Cannoodt, Kirsty, Greenleaves, Jayson Lamanca, Nithin Thaha, Tristan Jackson, Even_skjeih, Mo Alawami, Jonas Brandão, Lily McAdams, Alejandro Rodriguez, Isaac Overmyer, Cooper Norton, Biblion, Stephen Zappia, Bodo Nuber, Samhain, Kyle Goff, jota jodra, Marc Bornträger, Filip Leszczyński, Влад Кальченко, NexusValhalla, Aleksandar Zivancevic, Silas Zander, Tijn Flinterman, Shrutika Umralkar, Or Bairey-Sehayek, Terri-Ann dela Cruz, Choltikan Phothong, Collin Carey, Champ, Marcela Oliveira, rbtpzk, Jamie Grall, LAI Oscar, Ralf P., Kuba, Ryan Giles, JoghurtWiesel, Timster Ruu, John Highet, Walmyr Carvalho, Perry Williams, Aldo Vicente, Peter Paj, Vanny Khon, Olga, Theeraphong Gasparini, destroymyarrogance, Martin Pietrowski, Josip Haramija, Champ, Carlos, Davi & Nicholas

