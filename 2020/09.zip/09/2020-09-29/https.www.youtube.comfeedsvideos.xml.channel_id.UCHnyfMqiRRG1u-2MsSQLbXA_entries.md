# Source:Veritasium, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA, language:en-US

## The Infinite Pattern That Never Repeats
 - [https://www.youtube.com/watch?v=48sCx-wBs34](https://www.youtube.com/watch?v=48sCx-wBs34)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA
 - date published: 2020-09-30 00:00:00+00:00

Simple rules of geometry meant that 5-fold symmetry was impossible as were crystals without a periodic structure. This turns out to be wrong. Thanks to LastPass for sponsoring a portion of this video. Click here to start using LastPass: https://ve42.co/LPs

Huge thanks to Prof. Paul Steinhardt for the interview on this topic. Check out his book ‘The Second Kind of Impossible’

If you'd like to learn more about Penrose tilings, go check out "Penrose Tiles to Trapdoor Ciphers" by Martin Gardener, which helped my research for this video.

Filmed by Gene Nagata (Potato Jet on YouTube)
Animations by Ivy Tello and Jonny Hyman
Editing, Coloring, Music & Audio mastering by Jonny Hyman

Prague scenes filmed in 2012.
Special thanks to Raquel Nuno for helping with the tilings!

Additional Music from Epidemic Sound

