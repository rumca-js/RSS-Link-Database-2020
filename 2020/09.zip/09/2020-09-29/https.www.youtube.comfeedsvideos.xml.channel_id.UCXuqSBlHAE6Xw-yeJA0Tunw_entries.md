# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I forgot to review this… - Sonos Arc Soundbar Review
 - [https://www.youtube.com/watch?v=XX_YvdgeLs4](https://www.youtube.com/watch?v=XX_YvdgeLs4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-09-30 00:00:00+00:00

Check out the new Drop x Sennheiser PC38X at https://dro.ps/ltt-0920-pc38x

Get 10% off your order with offer code LINUS10 on Ruggable at https://myruggable.com/LINUS10

Soundbars have pretty much replaced the ol' "home theater in a box" solution, but in my experience don't offer a high fidelity sonic experience...until now? The Sonos Arc is the first soundbar that I've been impressed enough with to actually install in my living rooom. Now, should I get the subwoofer?

Buy: Sonos Arc
On Amazon (PAID LINK): https://geni.us/uKFZRxV
On B&H (PAID LINK): https://geni.us/Z3Wp0Am

Buy: JBL Bar 5.1
On Amazon (PAID LINK): https://geni.us/jpN4
On Newegg (PAID LINK): https://geni.us/TNtby
On B&H (PAID LINK): https://geni.us/oVAK91

Buy: LG SN11RG
On Amazon (PAID LINK): https://geni.us/Vabnyz
On B&H (PAID LINK): https://geni.us/tX0zO

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1252899-i-forgot-to-review-this%E2%80%A6-sonos-arc-soundbar-review/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Private Internet Access VPN: https://lmg.gg/pialinus2
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

## This PC SHOULDN'T Be Possible
 - [https://www.youtube.com/watch?v=Z2s-q34FX7c](https://www.youtube.com/watch?v=Z2s-q34FX7c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-09-29 00:00:00+00:00

Thanks to Seasonic for sponsoring this video! Buy Seasonic products:
On Amazon: https://geni.us/q4lnefC
On Newegg: https://lmg.gg/8KV3S

Long has running an ITX system required compromising on expandability. Today that changes!

*Seasonic PSU x Future RTX 3000 OWNERS* Request 12-Pin, 9 A Terminals, Micro-Fit 3.0, 16 AWG VGA Cable: https://seasonic.com/request-12pin-cable

Buy: AMD Ryzen 3900XT
On Amazon (PAID LINK): https://geni.us/AAjB
On Newegg (PAID LINK): https://geni.us/ZU502tL
On B&H (PAID LINK): https://geni.us/fgbFLB

Buy: G.SKILL TridentZ RGB Series 32GB
On Amazon (PAID LINK): https://geni.us/N97g
On Newegg (PAID LINK): https://geni.us/4qHs
On B&H (PAID LINK): https://geni.us/pP6D

Buy: Sabrent 4TB NVMe
On Amazon (PAID LINK): https://geni.us/JzKq3nS
On Newegg (PAID LINK): https://geni.us/AZ1W
On B&H (PAID LINK): https://geni.us/6ziuZE

Buy: ASRock B550 Phantom Gaming
On Amazon (PAID LINK): https://geni.us/lb1b
On Newegg (PAID LINK): https://geni.us/nNZ4d0
On B&H (PAID LINK): https://geni.us/Y6rpAdZ

Buy: NVIDIA RTX 3080
On Amazon (PAID LINK): https://geni.us/w0xEBC
On Newegg (PAID LINK): https://geni.us/cn94yMA
On B&H (PAID LINK): https://geni.us/uIwB

Buy: AVerMedia Live Gamer Duo
On Amazon (PAID LINK): https://geni.us/AN74CFB

Buy: Corsair H115i
On Amazon (PAID LINK): https://geni.us/n3uuN
On Newegg (PAID LINK): https://geni.us/tSt9O

Buy: Sliger SM580 Case
On their site: https://www.sliger.com/products/cases/sm580/

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1252530-this-pc-shouldnt-be-possible-bifurcated-itx-build/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Private Internet Access VPN: https://lmg.gg/pialinus2
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

