# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Battle Ground - REVIEW
 - [https://www.youtube.com/watch?v=NcdqXrEFm7A](https://www.youtube.com/watch?v=NcdqXrEFm7A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-09-30 00:00:00+00:00

My review of Battle Ground by Jim Butcher. The Second book in the Dresden Files. 

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

## Three Body Problem Drama🎭 Mass Effect Remaster?👾 The Boys Spinoff🌪️ -FANTASY NEWS
 - [https://www.youtube.com/watch?v=sPDBvQkP6lQ](https://www.youtube.com/watch?v=sPDBvQkP6lQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-09-29 00:00:00+00:00

We getting intense on todays FANTASY NEWS! 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene
peacock-1202736127/

NEWS: 

--

00:35 - Self Publish October: http://www.robjhayes.co.uk/self-published-fantasy-releases-october-2020/

01:15 - Malazan Cover: https://www.instagram.com/p/CFhgY19AnKS/?utm_source=ig_web_copy_link

01:45 - Egwene Audition Leak: https://www.wotseries.com/2020/09/24/possible-egwene-audition-tape/

02:44 - The Boys Spinnoff Series: https://deadline.com/2020/09/the-boys-spinoff-fast-track-development-amazon-record-season-2-launch-ratings-1234584256/

03:44 - Mass Effect Remaster: https://gamingbolt.com/mass-effect-trilogy-remastered-listed-by-yet-another-retailer

04:45 - Cosmere Adaptations: https://www.youtube.com/watch?v=18NM0006lvs&t=1s

05:10 - Netflix Three Body Problem Drama: https://deadline.com/2020/09/netflix-china-response-senators-republican-liu-cixin-three-body-problem-game-of-thrones-1234585716/

06:34 - Game Of Thrones Baby: https://people.com/parents/rose-leslie-kit-harington-expecting-first-child/?utm_source=facebook&utm_medium=news_tab&utm_content=algorithm  

07:27 - Witcher Recasting: https://deadline.com/2020/09/the-witcher-eskel-recast-basil-eidenbenz-season-2-thue-ersted-rasmussen-exit-replacement-netflix-1234585800/

08:15 - Sandman filming: https://twitter.com/neilhimself/status/1310287777708339201 

08:41 - Transformers Trailer: https://www.youtube.com/watch?v=SoK4_Tng29E&feature=youtu.be 

09:43 - Resident Evil Trailer: https://comicbook.com/gaming/news/resident-evil-infinite-darkness-netflix-trailer-movie-2021/

10:12 - Sandcastle inspired by Adaptation: https://www.indiewire.com/2020/09/m-night-shyamalan-new-movie-graphic-novel-sandcastle-1234589015/ 

11:26 - Avatar DONE: independent.co.uk/arts-entertainment/films/news/avatar-2-james-cameron-sequel-filming-release-date-cinemas-b640901.html?utm_source=reddit.com 


--

