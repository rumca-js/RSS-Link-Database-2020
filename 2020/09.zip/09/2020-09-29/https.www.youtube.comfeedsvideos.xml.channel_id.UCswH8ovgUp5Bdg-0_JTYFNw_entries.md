# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Who Really Won? Trump Or Biden?! | Russell Brand
 - [https://www.youtube.com/watch?v=R-nGgfNiPuM](https://www.youtube.com/watch?v=R-nGgfNiPuM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-09-30 00:00:00+00:00

My analysis of last night's Presidential Debate with Donald Trump and Joe Biden. Who won? Did either of them win?

You might also like this video too: https://youtu.be/YofLsS3vfOU

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

## Can We Have Social Justice Without Environmental Justice? | Russell Brand
 - [https://www.youtube.com/watch?v=n2FkfnQHjzY](https://www.youtube.com/watch?v=n2FkfnQHjzY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-09-29 00:00:00+00:00

A clip from my #UnderTheSkin podcast with activist Satish Kumar.
You can listen to this entire podcast on Luminary: http://luminary.link/russell

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

