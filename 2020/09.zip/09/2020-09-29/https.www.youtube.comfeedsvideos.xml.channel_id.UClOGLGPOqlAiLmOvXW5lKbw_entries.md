# Source:Mandalore Gaming, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw, language:en-US

## Aliens vs Predator Extinction Review
 - [https://www.youtube.com/watch?v=ODupe9mEV68](https://www.youtube.com/watch?v=ODupe9mEV68)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw
 - date published: 2020-09-30 00:00:00+00:00

Aliens versus Predator has had a great run when it comes to FPS games, but did you ever play the RTS one? Hello? Anybody?
Support the channel at: https://www.patreon.com/mandaloregaming or https://www.paypal.me/MandaloreGaming
I take video suggestions at mandaloremovies@gmail.com
Twitter: https://twitter.com/Lord_Mandalore
#AliensvsPredator #AliensvsPredatorExtinction #AVP #AVPRTS #AVPGame #AVPExtinction

Aliens vs Predator vs Brown vs Board of Education is a real song so here's some links to the real band: https://www.facebook.com/ttcmchicago
http://facebook.com/ttcmchicago

00:00 - Intro
1:14 - Game Premise
1:50 - Visuals
3:38 - Music & Sound Design
7:26 - Marines and Basic Mechanics
12:06 - Predator Campaign
15:37 - Alien Campaign
19:40 - Skirmish & Multiplayer
20:11 - Conclusions
21:23 - Credits

