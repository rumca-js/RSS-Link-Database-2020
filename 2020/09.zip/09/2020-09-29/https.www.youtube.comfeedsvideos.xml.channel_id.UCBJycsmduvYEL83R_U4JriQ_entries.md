# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## The Galaxy S20 Fan Edition: Hear Me Out!
 - [https://www.youtube.com/watch?v=azrdcp4yYas](https://www.youtube.com/watch?v=azrdcp4yYas)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-09-29 00:00:00+00:00

All this phone for $699? Midrange is where the action is at!

Shoutout to Honey: http://joinhoney.com/MKBHD
MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: A Mi Chemin by Hocus Pocus
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by Samsung for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

