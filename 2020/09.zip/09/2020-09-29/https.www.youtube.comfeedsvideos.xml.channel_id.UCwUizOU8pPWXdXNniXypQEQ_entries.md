# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Why Everybody Loves Leaf Blowers
 - [https://www.youtube.com/watch?v=0RGY6OW6-3I](https://www.youtube.com/watch?v=0RGY6OW6-3I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-09-29 00:00:00+00:00

For 20% off Sun Warrior go to https://sunwarrior.com/jp and use the coupon code "JP"

Everyone LOVES leaf blowers. They're never frustrating and always the most peaceful sound in the world. The sound of leaf blowers is also never raging outside your window for less than three hours at a time. Enjoy this leaf blower video. 

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

