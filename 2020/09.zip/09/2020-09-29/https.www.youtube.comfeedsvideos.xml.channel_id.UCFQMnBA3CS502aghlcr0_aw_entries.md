# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Confessions of a Copywriter
 - [https://www.youtube.com/watch?v=je8A3La_X6g](https://www.youtube.com/watch?v=je8A3La_X6g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-09-30 00:00:00+00:00

Jim Clair is a Whistleblowing Copywriter unmasking the "gurus" he worked with. He writes at jimclair.com, blogging about copywriting and books. He worked on VenusFactor, Yogaburn and many others and has a decade of experience in the industry and has seen it all. 

Find Jim: 
https://www.jimclair.com

Follow Coffeezilla
Twitter: @coffeebreak_YT
Instagram : @coffeebreak_YT

