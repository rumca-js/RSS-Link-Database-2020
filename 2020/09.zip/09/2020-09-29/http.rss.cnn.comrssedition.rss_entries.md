# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Russian state TV anchor weighs in on US elections
 - [https://www.cnn.com/videos/politics/2020/09/28/donald-trump-dmitry-kiselyov-biden-russia-chance-pkg-vpx-lead.cnn](https://www.cnn.com/videos/politics/2020/09/28/donald-trump-dmitry-kiselyov-biden-russia-chance-pkg-vpx-lead.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-29 02:55:05+00:00

CNN's Matthew Chance speaks with Dmitry Kiselyov, Russia's "propagandist-in-chief" and anchor for Russia 1 news, about President Donald Trump and the upcoming US election.

## Rapper Lil Yachty arrested after driving over 150 mph, police say
 - [https://www.cnn.com/2020/09/28/entertainment/lil-yachty-arrested-speeding-trnd/index.html](https://www.cnn.com/2020/09/28/entertainment/lil-yachty-arrested-speeding-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-29 02:45:23+00:00

Rapper Lil Yachty was arrested and charged with reckless driving and speeding after police say he was driving over 150 mph on an Atlanta highway, according to the Georgia State Patrol.

## A Marine veteran's military medals were stolen from his home. Detectives on the case replaced them
 - [https://www.cnn.com/2020/09/28/us/marine-veteran-medals-stolen-replaced-trnd/index.html](https://www.cnn.com/2020/09/28/us/marine-veteran-medals-stolen-replaced-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-29 02:32:03+00:00

For nearly 25 years, Thomas Faleskie served in the United States Marine Corps before retiring with the rank of lieutenant colonel. During that time he served in Vietnam and was awarded with several medals, including the National Defense Service Medal and Vietnam Service Medal.

## Asian rivers are turning black. And our colorful closets are to blame
 - [https://www.cnn.com/style/article/dyeing-pollution-fashion-intl-hnk-dst-sept/index.html](https://www.cnn.com/style/article/dyeing-pollution-fashion-intl-hnk-dst-sept/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-29 02:22:53+00:00

When Haji Muhammad Abdus Salam looks across the trash-filled river near his home in one of Dhaka's major garment manufacturing districts, he remembers a time before the factories moved in.

## Experts fear Covid-19 toll may double before a vaccine is ready
 - [https://www.cnn.com/2020/09/28/health/coronavirus-million-global-deaths-intl/index.html](https://www.cnn.com/2020/09/28/health/coronavirus-million-global-deaths-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-29 02:08:31+00:00

More than 1 million people have died from the coronavirus worldwide, marking another milestone in the pandemic's brief but devastating history.

## Microsoft 365 suffers outage across the US
 - [https://www.cnn.com/2020/09/28/tech/microsoft-outage/index.html](https://www.cnn.com/2020/09/28/tech/microsoft-outage/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-29 01:58:03+00:00

Microsoft 365 was down across the United States Monday evening, affecting users' access to multiple services including Outlook.

## Big Hit IPO makes BTS millionaires and their producer a billionaire
 - [https://www.cnn.com/2020/09/28/investing/bts-big-hit-entertainment-ipo/index.html](https://www.cnn.com/2020/09/28/investing/bts-big-hit-entertainment-ipo/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-29 01:56:03+00:00

All seven members of boy band BTS have become multimillionaires after their label, Big Hit Entertainment, pulled off South Korea's biggest stock market listing in three years.

## Analysis: Trump looking for 11th-hour reset but mostly shuns debate prep
 - [https://www.cnn.com/2020/09/28/politics/trump-debate-prep/index.html](https://www.cnn.com/2020/09/28/politics/trump-debate-prep/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-29 01:37:02+00:00



## Live like Rajasthani royalty at this 475-year-old palace hotel
 - [https://www.cnn.com/travel/article/samode-palace-hotel-jaipur-india-spc-intl/index.html](https://www.cnn.com/travel/article/samode-palace-hotel-jaipur-india-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-29 01:14:38+00:00

Set in the rugged hills of Rajasthan, the Samode Palace is an architectural gem that dates back nearly five centuries.

## Police broke up party of more than 1,000 people near Florida State University
 - [https://www.cnn.com/2020/09/28/us/florida-state-party-police-trnd/index.html](https://www.cnn.com/2020/09/28/us/florida-state-party-police-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-29 01:14:34+00:00

Florida is opening up and its students are itching to party.

## Doctors reflect on 1 million Covid-19 deaths
 - [https://www.cnn.com/videos/world/2020/09/25/one-million-coronavirus-death-doctors-lon-orig-bks.cnn](https://www.cnn.com/videos/world/2020/09/25/one-million-coronavirus-death-doctors-lon-orig-bks.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-29 00:53:10+00:00

Frontline doctors describe the struggles and challenges they have faced during the months-long fight against Covid-19.

## How does US tax law allow billionaires not to pay?
 - [https://www.cnn.com/2020/09/28/politics/tax-law-101/index.html](https://www.cnn.com/2020/09/28/politics/tax-law-101/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-29 00:44:42+00:00

One of the great frustrations about US tax law for a lot of Americans is that everyday wage earners can often pay a higher tax rate than billionaire real estate investors.

## Body camera video purports to show moments after officers raided Breonna Taylor's apartment
 - [https://www.cnn.com/2020/09/28/us/vice-news-breonna-taylor-body-camera-video/index.html](https://www.cnn.com/2020/09/28/us/vice-news-breonna-taylor-body-camera-video/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-29 00:41:44+00:00

New body camera footage obtained by Vice News purportedly shows what happened on March 13 in the moments after Louisville Metro Police officers raided the home of Breonna Taylor, who was shot and killed.

