# Source:Olden days, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC1gVCrX5uEFc0s_8TIYGqmw, language:en-US

## Living In A Metropolis - New York 1948 - [ 60 FPS - Color - 4K ] - Old footage restoration with AI
 - [https://www.youtube.com/watch?v=1U9V9GqHWzc](https://www.youtube.com/watch?v=1U9V9GqHWzc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1gVCrX5uEFc0s_8TIYGqmw
 - date published: 2020-09-30 00:00:00+00:00

Shows how millions of people live a crowded and hurried New York existence. Gives an Overview of various industrial and cultural activities." Shows the Automat, Empire State and Chrysler Buildings, Garment District, Times Square, Broadway.

IMDB:
https://www.imdb.com/title/tt1240947/

Original video was processed with Deep Learning algorithms to achieve modern look and quality. Here is the process:

1. Footage stabilization and noise/dust/scratches removal with After Effects and Neat Video ✔️
🔗 https://www.neatvideo.com/?linkID=p7845
2. Restoration with DeepRemaster, removing scratches and film damage ✔️
🔗 https://github.com/satoshiiizuka/siggraphasia2019_remastering
3. Frame interpolation to get smooth look using DAIN method. Result is 60 FPS video ✔️
🔗 https://github.com/baowenbo/DAIN
4. Colorization using DeOldify with NoGAN. Colors are not accurate, only for ambient mood ✔️
🔗 https://github.com/jantic/DeOldify
5. Upscaling using Topaz Video Enhance AI, upscale preserving detail and reducing noise ✔️
🔗 https://topazlabs.com/video-enhance-ai/ref/755/
⭐⭐⭐ 15% DISCOUNT CODE: oldendays15
6. Automation with Python scripts and AWS Thinkbox Deadline as queue manager ✔️
🔗 https://www.awsthinkbox.com/deadline
7. RTX 2070 Super 8GB, 32GB RAM, Ryzen 9 3900X 12-core. Approx 48hrs/10min video processing.

📽️ Source video:
https://archive.org/details/LivingInAMetropolis

🎵 Intro Music:
Timelapse by boomopera
https://1.envato.market/om6ao

Social Media:
https://www.facebook.com/oldendayschannel
https://www.twitter.com/OldenDaysYT
https://www.instagram.com/oldendayschannel
https://www.pinterest.ca/OldenDaysYT/old-footage-restoration
https://www.patreon.com/oldendays

#deoldify #colorize #upscale #topazlabs #veai #dain #60fps #4k

## Mechanic 1924 - [ 60 FPS - Color - 4K ] - Old footage restoration with AI and Machine Learning
 - [https://www.youtube.com/watch?v=-KPoWRhZIiU](https://www.youtube.com/watch?v=-KPoWRhZIiU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1gVCrX5uEFc0s_8TIYGqmw
 - date published: 2020-09-29 00:00:00+00:00

Silent comedy taking place in an automobile garage. Directed by Joe Rock. With Jimmy Aubrey. Some scenes on rooftop of garage in Hollywood, Los Angeles, California, and in a vacant lot.

Shrunken film catches in telecine gate at end of file.

IMDB:
https://www.imdb.com/title/tt0820929/

Original video was processed with Deep Learning algorithms to achieve modern look and quality. Here is the process:

1. Footage stabilization and noise/dust/scratches removal with After Effects and Neat Video ✔️
🔗 https://www.neatvideo.com/?linkID=p7845
2. Restoration with DeepRemaster, removing scratches and film damage ✔️
🔗 https://github.com/satoshiiizuka/siggraphasia2019_remastering
3. Frame interpolation to get smooth look using DAIN method. Result is 60 FPS video ✔️
🔗 https://github.com/baowenbo/DAIN
4. Colorization using DeOldify with NoGAN. Colors are not accurate, only for ambient mood ✔️
🔗 https://github.com/jantic/DeOldify
5. Upscaling using Topaz Video Enhance AI, upscale preserving detail and reducing noise ✔️
🔗 https://topazlabs.com/video-enhance-ai/ref/755/
⭐⭐⭐ 15% DISCOUNT CODE: oldendays15
6. Automation with Python scripts and AWS Thinkbox Deadline as queue manager ✔️
🔗 https://www.awsthinkbox.com/deadline
7. RTX 2070 Super 8GB, 32GB RAM, Ryzen 9 3900X 12-core. Approx 48hrs/10min video processing.

🎵 Intro Music:
Timelapse by boomopera
https://1.envato.market/om6ao

📽️ Source video:
https://archive.org/details/AFP-19-OJ_R-2_TheMechanic_A

Social Media:
https://www.facebook.com/oldendayschannel
https://www.twitter.com/OldenDaysYT
https://www.instagram.com/oldendayschannel
https://www.pinterest.ca/OldenDaysYT/old-footage-restoration
https://www.patreon.com/oldendays

#deoldify #colorize #upscale #topazlabs #veai #dain #60fps #4k

