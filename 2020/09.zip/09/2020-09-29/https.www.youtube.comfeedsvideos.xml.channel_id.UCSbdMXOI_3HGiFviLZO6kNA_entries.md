# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## Is the HYPE REAL? Oculus Quest 2 Impressions
 - [https://www.youtube.com/watch?v=LK0JVleNCiQ](https://www.youtube.com/watch?v=LK0JVleNCiQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-09-30 00:00:00+00:00

Thank you to this video's sponsor, Dashlane.
Go to https://www.dashlane.com/thrillseeker for 50% or use code Thrillseeker. Otherwise, it's completely free. 


buy a quest 2 here: (affiliate)
https://amzn.to/34c33wj

Hello!
No Tuesday Newsday this week, its been a slow week for news, but instead I finally got an Oculus Quest 2! I have been using it NON STOP Since I got it. So... is this the best VR headset out there at the moment? Well.. it's kind of a scary thought, but It's getting close. 

MY LINKS-
Twitch Stream TODAY!
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL

