# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Conservatives Need More Cartoons
 - [https://www.youtube.com/watch?v=PAvx-2PxICE](https://www.youtube.com/watch?v=PAvx-2PxICE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-09-30 00:00:00+00:00

Kyle and Ethan talk to the creator of FreedomToons about how he carved out his place on YouTube.

## Seamus Coughlin Talks Shapiro Impressions/Catholicism/Crazy Libertarians
 - [https://www.youtube.com/watch?v=ieNJWXfxv3w](https://www.youtube.com/watch?v=ieNJWXfxv3w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-09-29 00:00:00+00:00

Today on The Babylon Bee Podcast, Kyle and Ethan speak with Seamus Coughlin, who is the man behind FreedomToons and also an animator, writer, director, editor, and uncanny Ben Shapiro impersonator. They talk about arson being bad, punching the Pope, and being as libertarian as the Catholic church allows. 

Today, Seamus produces entertaining animated content for a number of outlets, and a good deal of his work can be found on the FreedomToons YouTube channel and the Foundation for Economic Education series Common Sense Soapbox with Seamus Coughlin.

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Gain Access to the Exclusive Content and Writing Forum: https://babylonbee.com/plans

The Official Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

