# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## When A.I. Becomes Creative
 - [https://www.youtube.com/watch?v=KZ7BnJb30Cc](https://www.youtube.com/watch?v=KZ7BnJb30Cc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2020-09-23 00:00:00+00:00

The first 200 people to click my link https://brilliant.org/COLDFUSION/ will get 20% off their annual Premium subscription!

General Adversarial Networks or GAN's are the new kids on the block, but they're already doing some interesting things.

--- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. 

COLDFUSION MERCH:

INTERNATIONAL: https://store.coldfusioncollective.com/
AUSTRALIA: https://shop.coldfusioncollective.com/

Who invented A.I., find out here: https://youtu.be/IBe2o-cZncU


If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- New Thinking Book written by Dagogo Altraide ---
This book was rated the 9th best technology history book by book authority.
In the book you’ll learn the stories of those who invented the things we use everyday and how it all fits together to form our modern world.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

--- ColdFusion Social Media ---
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusionTV

Sources:

Thanks to Justin for agreeing to chat. Check him out on Twitter: https://twitter.com/Buntworthy

Also credit goes to Doran for coming up with the Pixar concept: https://twitter.com/Norod78

https://en.wikipedia.org/wiki/Generative_adversarial_network

https://machinelearningmastery.com/introduction-to-style-generative-adversarial-network-stylegan/

https://time.com/5774723/ai-music/

https://www.nature.com/articles/s41587-019-0224-x

Nixon Speech: https://www.youtube.com/watch?v=yaq4sWFvnAY&authuser=0

https://www.wired.com/story/molecule-designed-ai-exhibits-druglike-qualities/

https://www.i-programmer.info/news/105-artificial-intelligence/12853-speech2face-give-me-the-voice-and-i-will-give-you-the-face.html

https://www.semanticscholar.org/paper/Deep-learning-enables-rapid-identification-of-DDR1-Zhavoronkov-Ivanenkov/d44ac0a7fd4734187bccafc4a2771027b8bb595e

https://www.cnet.com/news/nvidias-dlss-2-aims-to-upscale-its-low-res-reputation/

https://openai.com/blog/jukebox/

https://arxiv.org/abs/2005.00341

https://www.nvidia.com/en-us/geforce/news/nvidia-dlss-2-0-a-big-leap-in-ai-rendering/

StyleGAN2: https://www.youtube.com/watch?v=BIZg_PPuj_0

https://www.thispersondoesnotexist.com

https://www.thevintagenews.com/2020/09/04/roman-emperors/

Toonify Website is back: https://toonify.justinpinkney.com/

//Soundtrack//

Billboard - Memories (Robotaki Remix)

Catching Flies - The Long Journey Home

Edward Sharpe and the Magnetic Zeros - Life Is Hard (Teen Daze Remix)

Aphex Twin - Stone In Focus

Sean Williams - Fray

Shopan - Woodnot

Blue States - Vision Trail

Burn Water - Circles (Unreleased)

» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV

Producer: Dagogo Altraide

