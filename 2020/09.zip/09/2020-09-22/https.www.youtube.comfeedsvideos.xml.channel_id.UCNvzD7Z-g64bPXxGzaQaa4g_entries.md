# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Games That Bring Out THE WORST IN US
 - [https://www.youtube.com/watch?v=mYZ_pvwdG1Y](https://www.youtube.com/watch?v=mYZ_pvwdG1Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-09-23 00:00:00+00:00

Some games make you mad, deceptive, crazy, or something else entirely. Here are the ones that can make you the worst of the worst.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## Does PS5 Need To AGGRESSIVELY Compete With Xbox Game Pass?
 - [https://www.youtube.com/watch?v=WMTXtipxqZg](https://www.youtube.com/watch?v=WMTXtipxqZg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-09-22 00:00:00+00:00

Xbox and Microsoft are purchasing Bethesda. It's a huge move for Xbox and Game Pass - but does Sony need to directly compete? Can they do their own thing? Let's dive in.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

