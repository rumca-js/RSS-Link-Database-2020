# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## 19 year old 'millionaire' gets called out in his own commercial |   nourtrades
 - [https://www.youtube.com/watch?v=wdlZFxK3ncU](https://www.youtube.com/watch?v=wdlZFxK3ncU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-09-23 00:00:00+00:00

day traders aren't making as much as you think they are 

#nourtrades #lahwf #daytrading

