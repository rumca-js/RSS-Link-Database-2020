# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Rick Astley listens in on weatherman's hilarious blooper
 - [https://www.cnn.com/videos/us/2020/09/22/rick-astley-bbc-weatherman-blooper-moos-pkg-vpx.cnn](https://www.cnn.com/videos/us/2020/09/22/rick-astley-bbc-weatherman-blooper-moos-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-22 23:02:37+00:00

Musician Rick Astley was greeted on BBC's "Breakfast" with an awkward weatherman moment. CNN's Jeanne Moos reports.

## Cutting hair with fire: The last of the Milanese barbers
 - [https://www.cnn.com/videos/world/2020/09/22/milanese-barbers-cut-hair-with-candles-gbs.great-big-story](https://www.cnn.com/videos/world/2020/09/22/milanese-barbers-cut-hair-with-candles-gbs.great-big-story)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-22 15:40:11+00:00

Franco Bompieri owns Antica Barbieria Colla, the last of the traditional barber shops in Milan. There, they cut hair with candles. Why? It makes the hair fuller, and according to Franco, stops it from falling out. Franco admits he is from a different era, but still believes the old ways are the best.

## Designing the apartment in 'Friends'
 - [https://www.cnn.com/videos/great-big-story/2020/09/22/great-big-story-designing-apartment-in-friends-gbs.great-big-story](https://www.cnn.com/videos/great-big-story/2020/09/22/great-big-story-designing-apartment-in-friends-gbs.great-big-story)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-22 15:23:33+00:00

There's no apartment in New York City more famous than Monica's impossible rent-controlled, two-bedroom West Village digs. From the purple walls to the outdoor terrace, the "Friends" apartment became the quintessential ideal of everything New York could be. That's all thanks to John Shaffner, the man responsible for creating the set of "Friends." As a production designer, Shaffner has worked on 44 different series and 68 pilots, including "Dharma and Greg," "The Drew Carey Show," "Two and a Half Men," and "The Big Bang Theory."

## Xi Jinping wants China's private companies to fight alongside the Communist Party
 - [https://www.cnn.com/2020/09/22/business/china-private-sector-intl-hnk/index.html](https://www.cnn.com/2020/09/22/business/china-private-sector-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-22 09:49:42+00:00

President Xi Jinping has sent a message to China's private businesses: You can make money, but only if you follow my rules.

## He fell in love with an octopus and visited her for an entire year
 - [https://www.cnn.com/travel/article/my-octopus-teacher-craig-foster/index.html](https://www.cnn.com/travel/article/my-octopus-teacher-craig-foster/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-22 01:57:46+00:00

Craig Foster was diving, bare-chested, in bitterly cold waters off the southern-most tip of Africa when he saw her -- an octopus hiding under a cloak of shells and stones.

## The pastry chef adding to Japan's 400+ flavors of Kit Kat
 - [https://www.cnn.com/videos/world/2020/09/22/great-big-story-kit-kat-400-varieties-gbs.cnn](https://www.cnn.com/videos/world/2020/09/22/great-big-story-kit-kat-400-varieties-gbs.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-09-22 01:51:46+00:00

Kit Kat is big in Japan. From cheesecake to wasabi to purple sweet potato, the crispy wafer bar is available in more than 400 varieties, according to Yuji Takeuchi, marketing manager for Nestlé Japan. And it's up to Yasumasa Takagi to keep the fresh flavors coming. The classically-trained pastry chef has added over 50 to the Kit Kat canon so far. Takagi invites us into his kitchen in Tokyo to see how he creates yummy new flavor profiles for customers who are always hungry for more.

