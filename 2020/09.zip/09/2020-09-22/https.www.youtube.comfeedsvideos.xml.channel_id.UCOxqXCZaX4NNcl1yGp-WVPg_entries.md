## Izabela Trojanowska -  Iza (Cała płyta 1981 HQ)
 - [https://www.youtube.com/watch?v=9zC862eV4Mc](https://www.youtube.com/watch?v=9zC862eV4Mc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCOxqXCZaX4NNcl1yGp-WVPg
 - date published: 2020-09-23 00:00:00+00:00

Iza – debiutancki album Izabeli Trojanowskiej, wydany w 1981 nakładem wydawnictwa Tonpress[1].Płyta została zamówiona w rekordowym nakładzie blisko miliona egzemplarzy, jednak z przyczyn technicznych na rynek trafiło zaledwie 50 tys. egzemplarzy oraz kaseta magnetofonowa.Nagrań dokonano w System Studio, Lublin w 1980. Realizacja nagrań – Andrzej Poniatowski. Asystent – Włodzimierz Kowalczyk. Projekt graficzny – Rosław Szaybo. Foto – Andrzej Karczewski.Izabela Trojanowska – śpiewJan Borysewicz – gitaraZdzisław Janiak – gitaraRomuald Lipko – instrumenty klawiszoweTomasz Zeliszewski – perkusjaAndrzej Ziółkowski – gitara basowagościnnieZbigniew Namysłowski – saksofon altowy (A 4)1. "Tyle samo prawd ile kłamstw”2. „Nic za nic” 3. „Sobie na złość” 4. „Tydzień łez” 5. „Wszystko czego dziś chcę”6. „Pytanie o siebie” 7. „Komu więcej, komu mniej” 8. „Jestem twoim grzechem”

