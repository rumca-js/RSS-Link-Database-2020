# Source:Ryan George, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ, language:en-US

## How Tools Got Their Names
 - [https://www.youtube.com/watch?v=eZFWDh8ZjFw](https://www.youtube.com/watch?v=eZFWDh8ZjFw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ
 - date published: 2020-09-23 00:00:00+00:00

Hi there hello please click the subscribe button and turn on notifications so I can feed my cats.
Twitter/Instagram: @TheRyanGeorge

