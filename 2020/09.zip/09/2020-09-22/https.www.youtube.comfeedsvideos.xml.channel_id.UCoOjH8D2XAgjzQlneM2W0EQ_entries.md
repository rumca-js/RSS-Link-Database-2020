# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## Here’s How the CIA Assassinates People
 - [https://www.youtube.com/watch?v=vuxsRox7okg](https://www.youtube.com/watch?v=vuxsRox7okg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2020-09-23 00:00:00+00:00

Start listening with a 30-day Audible trial. Choose 1 audiobook absolutely free and you get unlimited monthly Audible Originals. Visit https://audible.com/jaketran or text “jaketran” to 500-500.

😈 Watch exclusive 40+ minute documentaries that are too controversial to ever be released to the public: https://jake.yt/join 

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

Follow the photographer of the thumbnail! https://bit.ly/3cbN4BQ

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
✉ Be the first to watch new videos with email notifications: http://bit.ly/jt-inbox
📸 Follow me on IG:@jaketran // http://bit.ly/jt-ig
👨👦👦 Join the Tran Mafia Family here: https://bit.ly/patreon-jt
💬 Join the community Discord: http://discord.gg/BmK8EnQ

Stuff I use & recommend:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
🏠 The real estate investing course I love & recommend: https://jake.yt/RE
🌐 Most flexible, affordable website hosting: https://jake.yt/bhd
🖥️ Website platform I use & love: https://jake.yt/kd
💽 Editing software I've used for 7+ years: https://jake.yt/ccd
📒 Online bookkeeping software I use& love: https://jake.yt/benchd 
🧾 Best affordable bookkeeping software: https://jake.yt/fbd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd
📚 Get 3 free audiobooks for life: https://amzn.to/2v58PSu
🎥 My video gear, setup, tech, books: https://jake.yt/stored

✉️ Email me: jake@jaketran.io

Subscribe to the backup channel on LBRY, use reward code "jake-cast" for free coin: https://bit.ly/LBRY-jt

📰 Sources & visuals: https://bit.ly/32ROsqn

-----------------------
As the president of the US you run into a lot of problems. To solve these problems, one of the options you can use is diplomacy. However, sometimes diplomacy just won’t cut it. Whatever the reason is, if diplomacy doesn’t work. The President’s third option, or tertia optio as it’s called behind closed doors.

Covert action can be a whole range of things - from drone strikes, to sabotage, to paramilitary operations, snatch and grabs, to funding and training rebels around the world that oppose our enemies.

Let’s learn how you as the President and the CIA can protect the free world, with your third option

The first thing to understand is this is the most extreme measure that should only be used when you’ve tried every other option. The next step is to stop calling it by you know what! The final decision to “eliminate” someone should always be reached in the field where the “neutralization” will be taking place. Once the decision has been reached, how you’re gonna “preemptively neutralize” someone is gonna vary largely based on the situation.

The best “lethal direct actions,” are the ones that aren’t even considered neutralizations in the first place. There are a few different variables we have to account for - the awareness of the subject, the desired outcome of our guy, and concealment. So now that you sorted out the different variables, let’s move onto the neutralizer itself.

Selecting your neutralizer will be based on whether it’s a safe or lost job. For a lost case, the hitman needs to be a genuine fanatic of some sort. If you intend for your neutralizer to escape, the CIA typically recruits former Special Forces operators because they’re pretty much the perfect candidates. And once you have your neutralizer or neutralizers, it’s time to plan out that preemptive neutralization.

The entire point of neutralization is the absolute death of the subject! Blunt objects come in handy since you’ll be able to find one where the target is and it’s less likely to scream “this was a professional job!”  For secret cases like that where you don’t want people knowing it was a hit, accidents are your best bet.

Now you know the origin of these covert action operations. It’s time to get out there, and get to work. 
-----------------------

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2020 Jake Tran. All rights reserved.

DISCLAIMER: These videos are for entertainment purposes only. This is not meant to be financial advice. Please always do your due diligence and never stop learning.

AFFILIATE DISCLOSURE: Some of the links in this video description are affiliate links, meaning, at no additional cost to you, I may earn a commission if you click through and make a purchase and/or opt-in. I only promote products that I 100% believe in.

