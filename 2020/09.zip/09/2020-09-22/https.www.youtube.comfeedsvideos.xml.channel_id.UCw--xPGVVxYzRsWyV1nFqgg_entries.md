# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## A Chat W/ Mary Robinette Kowal!
 - [https://www.youtube.com/watch?v=VSzpUwUZbQk](https://www.youtube.com/watch?v=VSzpUwUZbQk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-09-23 00:00:00+00:00

I had the absolute delight of sitting down with Mary Robinette Kowal to talk about her work and colaborating with Brandon Sanderson.
The Original:https://amzn.to/32RPulX

The Calculating Stars: https://amzn.to/32TrLBX 

Writers Block Post: https://maryrobinettekowal.com/journal/sometimes-writers-block-is-really-depression/

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

## Terry Goodkind Passes || Possible IT Sequel🤡 Elder Scrolls PURCHASED💸 -FANTASY NEWS
 - [https://www.youtube.com/watch?v=NKMvndBf_HU](https://www.youtube.com/watch?v=NKMvndBf_HU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-09-22 00:00:00+00:00

Welcome to another episode of Fantasy News! 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

NEWS: 

—

00:42 - Terry Goodkind Passing: https://www.facebook.com/terrygoodkind/photos/a.10155123537566822/10157300127601822 

01:57 - Indie Call: https://twitter.com/RoboftheHayes 

02:39 - Sanderson 100k subs: https://www.youtube.com/watch?v=R6jwfDxmLL8

03:23 - IT Sequel: https://www.thevulcanreporter.com/exclusives/exclusive-sequel-to-stephen-kings-it-book-in-the-works-could-we-be-getting-a-third-it-movie/

04:43  - Leviathan Falls: https://twitter.com/AndrewLiptak/status/1306298840883040256?s=20 

05:44 - #Dune Excerpt: https://www.torforgeblog.com/2020/09/19/excerpt-dune-the-duke-of-caladan-by-brian-herbert-and-kevin-j-anderson/

06:57 - Dune Pitchbook: https://twitter.com/SecretsOfDune/status/1306938122643689472 

07:22 - Your Name Live Action: https://deadline.com/2020/09/lee-isaac-chung-paramount-and-bad-robot-your-name-1234579603/

08:32 - Lannister AMA: https://www.reddit.com/r/IAmA/comments/ix1ocn/i_am_actor_nikolaj_costerwaldau_you_may_remember/ 

09:03 - Harley Quin Season 3: https://deadline.com/2020/09/harley-quinn-renewed-season-3-hbo-max-dc-universe-transitions-out-of-scripted-originals-1234579520/

09:07 - She Hulk Actress: https://deadline.com/2020/09/she-hulk-tatiana-maslany-marvel-series-1234578701/ 

09:21 - #Mandalorian Trailer: https://www.youtube.com/watch?v=eW7Twd85m2g
Mandalorian Poster: https://twitter.com/lightscamerapod/status/1305870401382346752?s=12 

09:56 - #WandaVision: https://www.youtube.com/watch?v=sj9J2ecsSpo

09:45 - Night City Wire: https://www.youtube.com/watch?v=c_urbl-2gV4&t 

10:37 - Microsoft buying Bethesda: https://www.ign.com/articles/xbox-bethesda-zenimax-aquisition 

—

