# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## Conway The Machine: Tiny Desk (Home) Concert
 - [https://www.youtube.com/watch?v=xctyRJC3bZQ](https://www.youtube.com/watch?v=xctyRJC3bZQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2020-09-23 00:00:00+00:00

For new music, the latest Tiny Desk (home) concerts and more, sign up for the NPR Music newsletter, sent weekly: npr.org/nprmusicnewsletter

Sept. 23, 2020 | Abby O'Neill - Conway the Machine is bringing the heat throughout our bizarre national quarantine with multiple albums and mixtapes, adding to the groundswell of Griselda buzz that's been building the past 12 months. As one third of the gritty rap group, Conway brings a distinctive swag and raw emotion to the Tiny Desk (home) concert series (as did his cousin, Benny The Butcher). Nestled into a booth at a diner in Queens, N.Y., Conway delivers five joints, including three from his 2020 album From King To A GOD. "Front Lines," produced by Beat Butcha, was written after the killing of George Floyd and speaks directly to the racial profiling committed by cops while policing Black communities.

"The Cow" is, as he says in the intro, "one of [the] most personal and transparent records I ever wrote," in which he speaks about losing one of his best friends and getting shot in the head and neck. The injuries led to permanent facial paralysis. This poignant song, which will be featured on Conway's Shady Records debut album, God Don't Make Mistakes, is heart-wrenching and exposes the heavy trauma he endured while ascending in the rap game. The song has brought Conway to tears in the past, and the memories clearly get to him again here. That tenacity in the face of adversity is something we can all aspire to, especially in 2020.

SET LIST
"Lemon" (prod. by Daringer & Beat Butcha)
"Front Lines" (prod. by Beat Butcha)
"OverDose" (prod. by The Alchemist)
"The Cow" (prod. by Daringer)
"Anza" (prod. by Murda Beatz)

MUSICIANS
Conway The Machine: vocals

CREDITS
Video By: Youssef Lehnin; Audio By: Chad "Frig" Kemp; Producer: Abby O'Neill; Audio Mastering Engineer: Josh Rogosin; Video Producer: Morgan Noelle Smith; Associate Producer: Bobby Carter; Executive Producer: Lauren Onkey; Senior VP, Programming: Anya Grundmann

ABOUT THE SERIES
The Tiny Desk is working from home for the foreseeable future. Introducing NPR Music's Tiny Desk (home) concerts, bringing you performances from across the country and the world. It's the same spirit — stripped-down sets, an intimate setting — just a different space.

## Oddisee: Tiny Desk (Home) Concert
 - [https://www.youtube.com/watch?v=HJgyQ47qABI](https://www.youtube.com/watch?v=HJgyQ47qABI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2020-09-22 00:00:00+00:00

For new music, the latest Tiny Desk (home) concerts and more, sign up for the NPR Music newsletter, sent weekly: npr.org/nprmusicnewsletter

Sept. 22, 2020 | Suraya Mohamed – In 2015, Oddisee visited the Tiny Desk with a drummer and a keyboardist. For his Tiny Desk (home) concert, he assembled his full band, Good Company, for the first time since the global pandemic cancelled their tour last spring. They rehearsed the day before this capture at Assorted Studios in York, Penn., the midway point between the members' hometowns of Philadelphia, New York City and Washington D.C. They picked this facility because it felt more like a living room than a studio. And to make it feel as cozy as possible, they brought memorabilia from their own homes. Bass player Dennis Turner brought family photos, Ralph Real (on the Fender Rhodes) brought his son's toy drum set, and Oddisee brought tribal statues from Sudan.

The five captivating songs are from his new EP, Odd Cure, "a record I didn't want to write but needed to," Oddisee said in July. He wrote it in eight weeks, between March and May, while in self-isolation. He had just returned from a performance in Thailand and wanted to protect his family. Oddisee says these songs were inspired by the deluge of news, social media, misinformation and conspiracy theories generated during the first weeks of the pandemic. Relevant and inspiring, his music and its message addresses the uncertainty and anxiety we all live with today.

SET LIST
"The Cure"
"Shoot Your Shot"
"I Thought You Were Fate"
"Still Strange"
"Go To Mars"

MUSICIANS
Oddisee: vocals; Ralph Real: vocals, Rhodes; Olivier St.Louis: vocals, guitar; Jon Laine: drums, vocals; Dennis Turner: bass; DJ Unown: MPC; Saint Ezekiel: guitar: Priya Ragu; vocals

CREDITS
Video by: Keith Charles, Lawrence Miner; Audio by: Delf; Producer: Suraya Mohamed; Audio Mastering Engineer: Josh Rogosin; Video Producer: Morgan Noelle Smith; Associate Producer: Bobby Carter; Executive Producer: Lauren Onkey; Senior VP, Programming: Anya Grundmann


ABOUT THE SERIES

The Tiny Desk is working from home for the foreseeable future. Introducing NPR Music's Tiny Desk (home) concerts, bringing you performances from across the country and the world. It's the same spirit — stripped-down sets, an intimate setting — just a different space.

