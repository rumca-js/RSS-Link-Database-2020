# Source:Jeff Gerling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg, language:en-US

## Ansible 2.10 is here! Your questions, answered
 - [https://www.youtube.com/watch?v=D83Wf0njbyA](https://www.youtube.com/watch?v=D83Wf0njbyA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg
 - date published: 2020-09-23 00:00:00+00:00

Ansible 2.10.0 was released today: https://groups.google.com/g/ansible-project/c/yFnMgbjqYnU

With the advent of collections and ansible-base, what does this mean for your Ansible automation? Do you need to rewrite all your playbooks? Will your favorite modules still be around? How do I even install Ansible anymore? Why did the Ansible team make these Collection changes?

I'll answer all those questions and more in this Q&A session on Ansible 2.10's release! #Ansible #DevOps

Sponsor me on GitHub: https://github.com/sponsors/geerlingguy
Support me on Patreon: https://www.patreon.com/geerlingguy

