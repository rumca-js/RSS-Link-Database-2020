# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## Huawei - Caught Between Two Superpowers (Documentary)
 - [https://www.youtube.com/watch?v=HExhxPDOewE](https://www.youtube.com/watch?v=HExhxPDOewE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2020-11-13 00:00:00+00:00

The Huawei story is one with many twists and turns. In this episode, I aim to tell both sides of the story and leave it up to you to make up your mind on who you think it right.
#huawei

--- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. 

--- ColdFusion Social Media ---
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusionTV

ColdFusion Merch:
INTERNATIONAL: https://store.coldfusioncollective.com/
AUSTRALIA: https://shop.coldfusioncollective.com/

If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- New Thinking Book written by Dagogo Altraide ---
This book was rated the 9th best technology history book by book authority.
In the book you’ll learn the stories of those who invented the things we use everyday and how it all fits together to form our modern world.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

Sources:

https://www.forbes.com/sites/zakdoffman/2019/05/19/u-s-will-lose-credibility-huawei-ceo-says-of-ban-but-we-will-keep-growing/#7677b5372951

https://asiatimes.com/2020/02/why-the-us-is-losing-its-war-against-huawei/  

https://techcrunch.com/2019/06/17/trade-war-costs-huawei-30-billion/

https://thediplomat.com/2020/05/why-the-us-campaign-against-huawei-backfired/

https://foreignpolicy.com/2019/01/31/who-benefits-from-the-u-s-crackdown-on-huawei/

https://www.wired.com/story/uk-huawei-5g-networks-us/

https://www.youtube.com/watch?v=7jiQ46OMcCA

https://www.theguardian.com/technology/2020/jul/14/huawei-decision-may-delay-5g-rollout-by-three-years-and-cost-uk-7bn-

https://cellularnews.com/mobile-operating-systems/harmony-os-by-huawei-everything-you-need-to-know/

https://marketrealist.com/2019/07/huaweis-ceo-talks-us-ban/

https://www.newstatesman.com/spotlight-america/cyber/2019/11/whats-really-behind-uss-huawei-ban

https://www.cnet.com/news/huawei-ban-full-timeline-us-restrictions-china-trump-android-google-ban-collusion-china/

https://www.aljazeera.com/economy/2018/12/07/why-are-countries-banning-huawei/

https://www.forbes.com/sites/zakdoffman/2019/05/19/u-s-will-lose-credibility-huawei-ceo-says-of-ban-but-we-will-keep-growing/#445e94be2951

https://www.youtube.com/watch?v=E9yFiZHXWi4&list=PL0iVR8sl9TiUOR4Bs8KJq2WWOS2soK_sV&index=2&t=1s

https://asiatimes.com/2020/02/why-the-us-is-losing-its-war-against-huawei/

https://asia.nikkei.com/Spotlight/Huawei-crackdown/US-tech-industry-fears-new-Huawei-ban-will-scare-off-customers

https://asia.nikkei.com/Opinion/Anti-Huawei-tech-bans-will-hurt-US-more-than-China

https://www.wired.com/story/uk-huawei-5g-networks-us/

https://techcrunch.com/2019/05/17/trump-huawei-networking-war/

https://www.federalregister.gov/documents/2019/08/21/2019-17921/addition-of-certain-entities-to-the-entity-list-and-revision-of-entries-on-the-entity-list


//Soundtrack//

Kazukii – Changes

Lowercase Noise – The First Glimmer of Wind

Beckwith feat. Catherine Porter – Back to Love

Buck UK // Once

Deccies – Subtle

Mogwai – Take Me Somewhere Nice

No Spirit – Reminiscing

Burn Water – She Shines


» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide

