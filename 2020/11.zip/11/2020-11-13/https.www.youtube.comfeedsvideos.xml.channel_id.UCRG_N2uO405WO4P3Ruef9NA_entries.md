# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## OnePlus, what are you doing???
 - [https://www.youtube.com/watch?v=7UIXh5WGNAA](https://www.youtube.com/watch?v=7UIXh5WGNAA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2020-11-13 00:00:00+00:00

Sponsored by Skillshare. The first 1000 people using this link will get a free trial to Skillshare premium: https://skl.sh/thefridaycheckout11201

The Friday Checkout ep. 23

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► Quiz ◄◄◄

Weekly Tech Knowledge Quiz: https://crrowd.com/quiz

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► TechAltar links ◄◄◄ 

Merch: 
https://enthusiast.store 

Crrowd Discord: 
https://discord.gg/npKQebe 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 

If you want to support TechAltar directly: 
https://flattr.com/@techaltar 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► Attributions ◄◄◄ 
Music by Edemski: 
https://soundcloud.com/edemski 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► Timestamps ◄◄◄ 

0:00 Intro 
0:33 Google Photos no longer free
2:00 Apple M1 looks dope
5:19 OnePlus disappoints

