# Source:Hugh Jeffreys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA, language:en-US

## Destroyed MacBook Pro Retina  - Can it be Restored?
 - [https://www.youtube.com/watch?v=6dPpo1apldM](https://www.youtube.com/watch?v=6dPpo1apldM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA
 - date published: 2020-11-14 00:00:00+00:00

This poor MacBook is completely obliterated with major damage inside and out. This is definitely going to be a challenge.
--------------------------------------Socials-------------------------------------
Website: https://www.hughjeffreys.com 
Instagram: http://instagram.com/hughjeffreys
Twitter: https://twitter.com/hughjeffreys
---------------------------------------Links---------------------------------------
iFixit's holiday tool deals start now! Save up to $50 on iFixit Tools: iFixit.com/hughjeffreys 
Right now you can get the Ultimate iFixit kit for $50 off. Or the Pro Tech + Mag Mat bundle for $10 off. (You can use iFixit.com/hughjeffreys to get to the gift guide.)

John from RDKL inc:
https://www.youtube.com/user/rdklinc
https://www.rdklinc.com/
https://twitter.com/RDKLInc

(DISCLAIMER: This description contains affiliate links, which means that if you click on one of the product links, l will receive a small commission.)

