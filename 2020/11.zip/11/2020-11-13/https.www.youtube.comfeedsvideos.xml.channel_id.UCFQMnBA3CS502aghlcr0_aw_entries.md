# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## The History of MLM and How They Bought Out Our Government
 - [https://www.youtube.com/watch?v=X-p0G4FEMMg](https://www.youtube.com/watch?v=X-p0G4FEMMg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-11-13 00:00:00+00:00

an extended interview with MLM Expert and Critic Robert Fitzpatrick. Robert has over 20 years of experience studying and exposing the MLM industry as fraudulent and indeed, not an industry at all in the typical sense. 

you can sign up to be notified when PONZINOMICS goes live here: https://lp.constantcontactpages.com/su/T1rsucf/ponzinomicsthebook?fbclid=IwAR127DcG_GifnPFdYxNbHt9mtb7my48SDR5pTDp98C4JpvtGgp-HxNFN-Bg

MLM is by all accounts, a pyramid scheme. The entire system is corrupt, down to the politicians playing cover for the industry.

