# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Doug Emhoff: The first 'second dude' in the White House
 - [https://www.bbc.co.uk/news/election-us-2020-54899230](https://www.bbc.co.uk/news/election-us-2020-54899230)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-13 23:13:16+00:00

By way of Kamala Harris's historic candidacy her husband will also be breaking barriers.

## The small shops in battle with the retail giants
 - [https://www.bbc.co.uk/news/business-54873418](https://www.bbc.co.uk/news/business-54873418)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-13 22:53:19+00:00

Efforts to shop local this Christmas could give small businesses a fairy tale end to a grim year.

## Your pictures on the theme of 'autumn landscapes'
 - [https://www.bbc.co.uk/news/in-pictures-54908247](https://www.bbc.co.uk/news/in-pictures-54908247)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-13 14:43:26+00:00

A selection of pictures from our readers on the theme of 'autumn landscapes".

## How can you keep safe at Christmas?
 - [https://www.bbc.co.uk/news/explainers-53917432](https://www.bbc.co.uk/news/explainers-53917432)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-13 12:32:34+00:00

Good ventilation could be key to avoiding coronavirus this winter as people spend more time indoors.

## Yes Sir, I Can Boogie: Why disco hit is now Scotland's unofficial anthem
 - [https://www.bbc.co.uk/news/uk-scotland-54930718](https://www.bbc.co.uk/news/uk-scotland-54930718)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-13 12:02:54+00:00

Dressing room footage of jubilant players boogie-woogieing to a 70s classic has gone viral.

## True crime: Did the right man hang for murder in 1933?
 - [https://www.bbc.co.uk/news/uk-northern-ireland-54918746](https://www.bbc.co.uk/news/uk-northern-ireland-54918746)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-13 06:56:48+00:00

Was Harold Courtney really the killer of a pregnant 23-year-old woman in County Armagh?

## Frome 'Iron Man' makes crisp packet blankets for homeless
 - [https://www.bbc.co.uk/news/uk-england-somerset-54888102](https://www.bbc.co.uk/news/uk-england-somerset-54888102)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-13 01:27:06+00:00

Miley Porritt, who slept rough for five years, seals packets together to make sleeping bag liners.

