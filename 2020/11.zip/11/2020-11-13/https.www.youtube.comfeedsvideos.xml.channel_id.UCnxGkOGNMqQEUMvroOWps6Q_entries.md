# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Is the Pandemic Enabling Phone Addiction?
 - [https://www.youtube.com/watch?v=d4K4oKXAz8I](https://www.youtube.com/watch?v=d4K4oKXAz8I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-11-13 00:00:00+00:00

#1564 w/Adam Alter:
https://open.spotify.com/episode/3olbOHISF2QiU27IwGf2xb?si=jKzVLCBDTvaohuW_cLYddA

## The Ethical Responsibilities of Tech Companies
 - [https://www.youtube.com/watch?v=2rIDRwS_NGI](https://www.youtube.com/watch?v=2rIDRwS_NGI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-11-13 00:00:00+00:00

#1564 w/Adam Alter:
https://open.spotify.com/episode/3olbOHISF2QiU27IwGf2xb?si=jKzVLCBDTvaohuW_cLYddA

## The Next Steps of Immersive Gaming
 - [https://www.youtube.com/watch?v=2lnmNN2zmgU](https://www.youtube.com/watch?v=2lnmNN2zmgU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-11-13 00:00:00+00:00

#1564 w/Adam Alter:
https://open.spotify.com/episode/3olbOHISF2QiU27IwGf2xb?si=jKzVLCBDTvaohuW_cLYddA

