# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Fontaines D.C. - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=tKrKmleb7NI](https://www.youtube.com/watch?v=tKrKmleb7NI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-11-13 00:00:00+00:00

http://KEXP.ORG presents Fontaines D.C. performing live, exclusively for KEXP, at NEKO Trust in Wandsworth,  London.

Songs:
A Hero's Death
Living in America
Love is the Main Thing
Televised Mind
A Lucid Dream

Produced by Double Vision @double_vision_film
Filmed and Directed by Jordan and Jack Martin
Edited by Jim Beckmann at KEXP

Sound Engineer: Chris Butterworth
Mixed by Damian Chennells

https://www.fontainesdc.com
https://www.nekotrust.org
http://www.kexp.org

