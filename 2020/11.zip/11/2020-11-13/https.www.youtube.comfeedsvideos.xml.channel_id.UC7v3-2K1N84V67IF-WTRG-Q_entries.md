# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## The Mandalorian - Season 2: Episode 3 (My Thoughts)
 - [https://www.youtube.com/watch?v=WnsD9yntipE](https://www.youtube.com/watch?v=WnsD9yntipE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-11-14 00:00:00+00:00

Get the best discount of the year on Raycons! Now through the end of November, go to
https://buyraycon.com/jahns to get 20% off your order!

Season 2 of the Mandalorian starts to get real. Here are my thoughts!

#Mandalorian #TheMandalorian

## Freaky - Movie Review
 - [https://www.youtube.com/watch?v=rnm_f7FwlR4](https://www.youtube.com/watch?v=rnm_f7FwlR4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-11-13 00:00:00+00:00

A Blumhouse Freaky Friday-ish body swap with a serial Killer and a Teen. Here's my review for FREAKY!

#Freaky #FreakyFriday

