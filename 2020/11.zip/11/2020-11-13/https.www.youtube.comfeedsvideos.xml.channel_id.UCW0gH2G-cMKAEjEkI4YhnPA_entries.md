# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Complete Travels of Radagast the Brown | Tolkien Explained
 - [https://www.youtube.com/watch?v=LuHheuhzJIE](https://www.youtube.com/watch?v=LuHheuhzJIE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2020-11-14 00:00:00+00:00

Radagast the Brown is one of the greatest mysteries of Middle-earth.  Who was Radagast the Brown?  What happened to him after The Lord of the Rings?  We will answer the former, and venture a guess at the latter.  We will also determine why he was considered not faithful to his mission in Middle-earth

Hit subscribe - and the bell - so you never miss a video from Nerd of the Rings!  

Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings


-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner. 

Radagast - WETA
Radagast - Aleksander Karcz
Mage of Rhosgobel - Jef Murray
Radagast the Brown - Mariusz Migalka
Radagast the Brown - Ekaterina Chesalova
Radagast the Brown - Fabio Leone
https://www.facebook.com/IllustratorFabioLeone
https://www.artstation.com/fabioleone
Radagast the Brown - WangYuxi
Radagast - Dan Pilla
Radagast the Brown - Ralph Damiani
Rhosgobel - Ted Nasmith
Radagast's House - Vincent Lin
Gwaihir and Gandalf - Antonia Jose Manzanedo
Beorn - J Humphries
Beorn - JM Kilpatrick
Beorn - Nick Keller
Gandalf Meets Radagast - Gordon Palmer
Isengard - Only Chasing Safety
On the Shores of Valinor - Ted Nasmith
Radagast the Brown - Ruben Ramos
Saruman and the Palantir - The Brothers Hildebrandt
Orthanc in the Second Age - Ted Nasmith
Gwaihir the Windlord - Ted Nasmith



#radagast #tolkien #lordoftherings

