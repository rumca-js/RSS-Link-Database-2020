# Source:The Guardian, URL:https://www.theguardian.com/rss, language:en-UK

## Philadelphia city council apologises for deadly 1985 Move bombing
 - [https://www.theguardian.com/us-news/2020/nov/13/philadelphia-1985-move-bombing-apology](https://www.theguardian.com/us-news/2020/nov/13/philadelphia-1985-move-bombing-apology)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 23:28:33+00:00

<p>Resolution apologises for ‘enduring harm’ caused by bombing of house occupied by members of black liberation group</p><p>Philadelphia’s governing council has formally apologised for one of the worst atrocities in the long history of racial strife in the city – the aerial bombing on 13 May 1985 of a house occupied by members of the black liberation group Move that left 11 people dead, including five children.</p><p> <span>Related: </span><a href="https://www.theguardian.com/us-news/2020/may/10/move-1985-bombing-reconciliation-philadelphia">The day police bombed a city street: can scars of 1985 Move atrocity be healed?</a> </p> <a href="https://www.theguardian.com/us-news/2020/nov/13/philadelphia-1985-move-bombing-apology">Continue reading...</a>

## Trump comes close to admitting defeat but stops short of formal concession
 - [https://www.theguardian.com/us-news/2020/nov/13/trump-biden-white-house-defeat-election](https://www.theguardian.com/us-news/2020/nov/13/trump-biden-white-house-defeat-election)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 23:26:09+00:00

<ul><li>Trump makes first public remarks since weekend election loss</li><li>Seemed to be on verge of acknowledging Biden’s victory</li></ul><p>Donald Trump has come closer than ever to admitting that he lost the US presidential election, suggesting “time will tell” but stopping short of a formal concession to president-elect Joe Biden.</p><p> <span>Related: </span><a href="https://www.theguardian.com/us-news/2020/nov/13/joe-biden-cabinet-selection-trump-obstruction">Joe Biden ignores Trump obstruction to press ahead with cabinet selection</a> </p> <a href="https://www.theguardian.com/us-news/2020/nov/13/trump-biden-white-house-defeat-election">Continue reading...</a>

## Manchester United’s rapid rise adds new twist to WSL title battle
 - [https://www.theguardian.com/football/2020/nov/13/casey-stoney-aims-to-cap-manchester-uniteds-rise-with-victory-over-city](https://www.theguardian.com/football/2020/nov/13/casey-stoney-aims-to-cap-manchester-uniteds-rise-with-victory-over-city)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 22:30:48+00:00

<p>Two years after relaunch United are unbeaten at the top of WSL and looking to upset triumvirate of City, Arsenal and Chelsea</p><p>Just two years on from their relaunch, Manchester United sit unbeaten at the top of the Women’s Super League and are arguably favourites as they head into Saturday’s Manchester derby, one of the showpiece matches of Women’s Football Weekend.</p><p>The journey has been meteoric and, in many respects, the club are doing their best to make up for lost time. It does not make them immune to criticism, however, with Megan Rapinoe the latest to blast the club’s former disinterest as “disgraceful”, in an interview with the BBC.</p> <a href="https://www.theguardian.com/football/2020/nov/13/casey-stoney-aims-to-cap-manchester-uniteds-rise-with-victory-over-city">Continue reading...</a>

## Quarterback Kane offers England's forward thinking a new dimension | David Hytner
 - [https://www.theguardian.com/football/blog/2020/nov/13/quarterback-kane-offers-englands-forward-thinking-a-new-dimension](https://www.theguardian.com/football/blog/2020/nov/13/quarterback-kane-offers-englands-forward-thinking-a-new-dimension)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 22:30:48+00:00

<p>Prolific captain has added assists to his game and could thrive in a deeper role in Gareth Southgate’s 3-4-3 formation</p><p>It was the second game of Gareth Southgate’s tenure as England Under-21s head coach – away to Finland in 2013 – the team were trailing 1-0 and they needed a creative spark. On the bench was Harry Kane. “Which showed what we know about talent observation,” Southgate says with a smile.</p><p>Southgate brought him on in the 58th minute, he played him as a No 10 and, nine minutes later, he watched him accept a pass in midfield, squeeze in between two challengers and drift away from a third before releasing Wilfried Zaha with a perfect ball around the full-back. Zaha crossed low and Saido Berahino, the centre-forward, <a href="https://www.youtube.com/watch?v=gyrbSjjT4gE" title="">tapped home the equaliser</a>.</p> <a href="https://www.theguardian.com/football/blog/2020/nov/13/quarterback-kane-offers-englands-forward-thinking-a-new-dimension">Continue reading...</a>

## Oregon governor issues sweeping new Covid-19 restrictions
 - [https://www.theguardian.com/us-news/2020/nov/13/oregon-covid-19-restrictions-governor-california](https://www.theguardian.com/us-news/2020/nov/13/oregon-covid-19-restrictions-governor-california)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 22:27:30+00:00

<p>The measures are some of the most aggressive steps in the US to curb the spread of the coronavirus in recent weeks</p><p>The governor of Oregon issued sweeping new coronavirus restrictions, in one of the most aggressive steps in recent weeks to curb the rise in infections in the US.</p> <a href="https://www.theguardian.com/us-news/2020/nov/13/oregon-covid-19-restrictions-governor-california">Continue reading...</a>

## England expect mismatch against a Georgia on a steep learning curve
 - [https://www.theguardian.com/sport/2020/nov/13/england-expect-mismatch-against-a-georgia-on-a-steep-learning-curve](https://www.theguardian.com/sport/2020/nov/13/england-expect-mismatch-against-a-georgia-on-a-steep-learning-curve)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 22:00:47+00:00

<p>The Autumn Nations Cup tie is unlikely to be dazzling, as Jonny May urges England to be consistently brilliant at basics</p><p>Welcome to the Autumn Nations Cup, a tournament conceived in haste as an antidote to the financial impact of Covid-19 and about to be delivered by Amazon Prime, the new kids on rugby’s block. The broadcaster will want its coverage to make an early impact despite the unfortunate <a href="https://www.theguardian.com/sport/2020/nov/13/positive-covid-tests-in-fiji-squad-lead-to-cancellation-of-france-match" title="">cancellation of France v Fiji</a>; so much the better if the TV audience figures are swelled by American golf viewers who see the word “Georgia” and think they are tuning into the Masters from Augusta, GA.</p><p> <span>Related: </span><a href="https://www.theguardian.com/sport/2020/nov/13/joseph-itoje-spotlight-england-world-cup-evolution-georgia">Joseph and Itoje in the spotlight as England begin World Cup evolution | Ugo Monye</a> </p> <a href="https://www.theguardian.com/sport/2020/nov/13/england-expect-mismatch-against-a-georgia-on-a-steep-learning-curve">Continue reading...</a>

## Fleetwood and Willett take route 66 at Masters in search of American dream
 - [https://www.theguardian.com/sport/2020/nov/13/tommy-fleetwood-and-danny-willett-each-take-route-66-at-masters](https://www.theguardian.com/sport/2020/nov/13/tommy-fleetwood-and-danny-willett-each-take-route-66-at-masters)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 21:57:30+00:00

<ul><li>English pair stand two shots off halfway lead at Augusta</li><li>Lead shared by Johnson, Thomas, Ancer and Smith</li></ul><p>A penchant for cardigans and hooped polo shirts – American galleries liken the latter to the Where’s Waldo? series on this side of the Atlantic – means Tommy Fleetwood’s passion for fashion has been the standout element of an otherwise quiet 2020. If the 29-year-old adds a Green Jacket to his wardrobe, sartorial elegance would combine with fulfilment of a childhood dream.</p><p>Fleetwood is seven under par, two from the halfway Masters lead, after rolling in a birdie at the 18th for a second round of 66. More fool anyone who forgot about the Southport man’s propensity to joust with the best in major championships. Form is only temporary.</p> <a href="https://www.theguardian.com/sport/2020/nov/13/tommy-fleetwood-and-danny-willett-each-take-route-66-at-masters">Continue reading...</a>

## Can Trump actually stage a coup and stay in office for a second term?
 - [https://www.theguardian.com/us-news/2020/nov/13/can-donald-trump-stay-in-office-second-term-president-coup](https://www.theguardian.com/us-news/2020/nov/13/can-donald-trump-stay-in-office-second-term-president-coup)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 21:38:55+00:00

<p>Trump refuses to acknowledge Biden’s win, but experts say there isn’t a constitutional path forward for him to remain president</p><p>Joe Biden won the presidential election, a fact that Donald Trump and other Republicans refuse to acknowledge.</p><p>There are worries the president and other Republicans will make every effort to stay in power. “There will be a smooth transition to a second Trump administration,” Mike Pompeo, the secretary of state, <a href="https://www.theguardian.com/us-news/2020/nov/10/mike-pompeo-second-trump-administration-trump-biden">said on Tuesday</a>. William Barr, the attorney general, has <a href="https://www.theguardian.com/us-news/2020/nov/09/william-barr-vote-irregularities-donald-trump-election">also authorized federal prosecutors</a> to begin to investigate election irregularities, a move that prompted the head of the justice department’s election crimes unit to step down from his position and move to another role.</p> <a href="https://www.theguardian.com/us-news/2020/nov/13/can-donald-trump-stay-in-office-second-term-president-coup">Continue reading...</a>

## Ireland pile pressure on Pivac as Wales slip to sixth straight defeat
 - [https://www.theguardian.com/sport/2020/nov/13/ireland-wales-autumn-nations-cup-match-report](https://www.theguardian.com/sport/2020/nov/13/ireland-wales-autumn-nations-cup-match-report)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 21:16:20+00:00

<ul><li>Ireland 32-9 Wales</li><li>Wales slump to sixth successive defeat in game of 31 penalties</li></ul><p>A contest pockmarked by penalties and a lack of composure will have caused group rivals England few concerns. Ireland again showed an inability to react to the unexpected and were wasteful in possession in the Autumn Nations Cup opener while Wales, who slumped to a sixth successive defeat, showed spirit but still lacked an identity.</p><p>It was a mess of a game, blighted by 31 penalties. Wales at least recovered from an anonymous opening 40 minutes when they did little other than tackle, but the problems mount for their head coach, Wayne Pivac, for whom the old is dying but the new is still to be born. They showed a response after their <a href="https://www.theguardian.com/sport/2020/oct/31/wales-scotland-six-nations-match-report" title="">passive display against Scotland</a> at the end of the Six Nations, but a year after <a href="https://www.theguardian.com/sport/2019/mar/16/wales-crush-ireland-win-grand-slam-six-nations-match-report" title="">winning the grand slam</a> and reaching the semi-finals of the World Cup they are reacting rather than setting the agenda.</p> <a href="https://www.theguardian.com/sport/2020/nov/13/ireland-wales-autumn-nations-cup-match-report">Continue reading...</a>

## Who would have believed it would take 22 years for Scotland to be back? | John Collins
 - [https://www.theguardian.com/football/2020/nov/13/who-would-have-believed-it-would-take-22-years-for-scotland-to-be-back](https://www.theguardian.com/football/2020/nov/13/who-would-have-believed-it-would-take-22-years-for-scotland-to-be-back)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 20:00:45+00:00

<p>John Collins scored a penalty against Brazil in the 1998 World Cup’s opening game. He explains what it means to see Scotland back at a major tournament</p><p>I’ll never forget when we played Brazil in the opening game of the 1998 World Cup. I knew I was the penalty taker so, like most athletes, you visualise and think about what you would do in certain positions and I picked my spot the night before. My secret was never to change my mind and thankfully for me it hit the back of the net. It was a special feeling to equalise against the mighty Brazil and get our team back into the game in front of all our fans. Wonderful memories.</p><p> <span>Related: </span><a href="https://www.theguardian.com/football/2020/nov/12/serbia-scotland-european-championship-qualifying-play-off-finals">Marshall save ends Scotland's long wait as they pip Serbia to Euro 2020 finals</a> </p> <a href="https://www.theguardian.com/football/2020/nov/13/who-would-have-believed-it-would-take-22-years-for-scotland-to-be-back">Continue reading...</a>

## Classical highlights for the week ahead: 13-20 November
 - [https://www.theguardian.com/music/2020/nov/13/classical-highlights-for-the-week-ahead-13-20-november](https://www.theguardian.com/music/2020/nov/13/classical-highlights-for-the-week-ahead-13-20-november)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 19:57:56+00:00

<p>Despite lockdown, there’s still plenty of new music-making across the UK available to an online audience. Here’s our pick of next week’s live-streamed and pre-recorded concerts<br /></p><p><strong>Mozart’s Requiem</strong></p><p>The performance that should have marked English National Opera’s return to the Coliseum is now a TV event. Mark Wigglesworth conducts the ENO orchestra and chorus in <a href="https://www.theguardian.com/music/2020/nov/13/mozart-requiem-choral-work-english-national-opera-coliseum-london-covid">Mozart’s final, unfinished masterpiec</a>e; Elizabeth Llewellyn, Sarah Connolly, Ed Lyon and Gerald Finley are the soloists.<br />• <a href="https://www.bbc.co.uk/programmes/m000pjfg">14 November, on BBC2 and then iPlayer until 13 December</a></p> <a href="https://www.theguardian.com/music/2020/nov/13/classical-highlights-for-the-week-ahead-13-20-november">Continue reading...</a>

## Scientists warn of Christmas Covid surge if tier system returns
 - [https://www.theguardian.com/world/2020/nov/13/scientists-warn-of-christmas-covid-surge-if-tier-system-returns-in-england](https://www.theguardian.com/world/2020/nov/13/scientists-warn-of-christmas-covid-surge-if-tier-system-returns-in-england)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 19:16:26+00:00

<p>Three-tier restrictions in England ‘may not be enough’ to suppress virus after lockdown</p><ul><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>England will face a resurgence of coronavirus cases before Christmas if the country returns to the tiering restrictions in place last month when the latest lockdown is over, government science advisers have warned.</p><p>The concern was raised in a consensus statement released on Friday in a batch of documents prepared by the outbreak modelling subgroup of Sage, the government’s expert advisory committee.</p> <a href="https://www.theguardian.com/world/2020/nov/13/scientists-warn-of-christmas-covid-surge-if-tier-system-returns-in-england">Continue reading...</a>

## Boris Johnson boots out top adviser Dominic Cummings
 - [https://www.theguardian.com/politics/2020/nov/13/dominic-cummings-has-already-left-job-at-no-10-reports](https://www.theguardian.com/politics/2020/nov/13/dominic-cummings-has-already-left-job-at-no-10-reports)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 19:06:23+00:00

<p>Source says aide’s instant departure came after he was accused of briefing against PM</p><ul><li><a href="https://www.theguardian.com/politics/live/2020/nov/13/dominic-cummings-boris-johnson-coronavirus-covid-19-latest-updates-live">PM’s chief adviser leaves Downing Street role – live</a><br /></li></ul><p>Boris Johnson has ordered Dominic Cummings to leave Downing Street with immediate effect, in a dramatic end to a tumultuous era which leaves a void at the heart of Downing Street.</p><p>Cummings and his ally Lee Cain – both ardent Brexiters blamed by MPs for a <a href="https://www.theguardian.com/politics/2020/nov/13/end-of-the-macho-era-what-to-expect-now-dominic-cummings-has-gone">macho culture</a> and a series of communications crises – were asked to step down on Friday instead of staying in place until Christmas.</p> <a href="https://www.theguardian.com/politics/2020/nov/13/dominic-cummings-has-already-left-job-at-no-10-reports">Continue reading...</a>

## 'Big cat' country? New Zealand's obsession with giant feline sightings
 - [https://www.theguardian.com/world/2020/nov/14/big-cat-country-new-zealands-obsession-with-giant-feline-sightings](https://www.theguardian.com/world/2020/nov/14/big-cat-country-new-zealands-obsession-with-giant-feline-sightings)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 19:00:46+00:00

<p>Is there a pleasure in not knowing if the decades-old mystery about a cat prowling the country’s South Island is fact or fiction?</p><p>The photograph is disappointing. Blurry, as they all are. It shows a dark blob striding up a leafy trail in the distance. The size of the creature is hard to deduce, though the witness, an osteopath named Mark Orr who was out mountain-biking with friends in Hanmer Springs, <a href="https://www.rnz.co.nz/national/programmes/checkpoint/audio/2018770151/another-glimpse-of-the-mysterious-south-island-giant-cat">said the animal was “about knee-height”, looked “very strong and quite stocky”,</a> and “<a href="https://www.nzherald.co.nz/nz/big-cat-mystery-very-daunting-fresh-sighting-in-canterburys-hanmer-springs/U5G3RH3FYBP2B3KL6WRXEFB6P4/">just had an aura about it”</a>.</p><p>An aura. Almost all animals have auras, don’t they? Even feral cats, goats, wild pigs. While the mention of the aura seemed strange, it was also compelling. I want to believe.</p> <a href="https://www.theguardian.com/world/2020/nov/14/big-cat-country-new-zealands-obsession-with-giant-feline-sightings">Continue reading...</a>

## 'They just slaughter them': how sorcery violence spreads fear across Papua New Guinea
 - [https://www.theguardian.com/world/2020/nov/14/they-just-slaughter-them-how-sorcery-violence-spreads-fear-across-papua-new-guinea](https://www.theguardian.com/world/2020/nov/14/they-just-slaughter-them-how-sorcery-violence-spreads-fear-across-papua-new-guinea)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 19:00:46+00:00

<p>Five alleged sorcery-related deaths – including the hanging of a 13-year-old boy - in a single week in one Papua New Guinea province, has revived a nationwide angst over the persistent crime of alleged witchcraft killings.</p><p>In the highland villages and the lowland towns of Papua New Guinea, it is the crime that everybody knows about, that many see, but that few can, or do, anything to stop.</p><p>Those who survive it are left disfigured: limbs shattered and missing, faces scarred and swollen, souls forever damaged.</p> <a href="https://www.theguardian.com/world/2020/nov/14/they-just-slaughter-them-how-sorcery-violence-spreads-fear-across-papua-new-guinea">Continue reading...</a>

## Stingless sugarbags: the joys of keeping native bees
 - [https://www.theguardian.com/lifeandstyle/2020/nov/14/stingless-sugarbags-the-joys-of-keeping-native-bees](https://www.theguardian.com/lifeandstyle/2020/nov/14/stingless-sugarbags-the-joys-of-keeping-native-bees)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 19:00:46+00:00

<p>If you’re imagining bees that are fat, striped and yellow, you’ll be sorely misled – but native bees are just as enchanting</p><p>There are few things in an eastern, coastal Australian garden that delight me more than the bumbling of Lilliputian-winged, stingless sugarbag bees.</p><p>You might not spot them straightaway, but as the weather warms up they are certainly out and about. Look closely at your flowers and you may notice hover flies, ladybugs, butterflies and these pint-sized black bees.</p> <a href="https://www.theguardian.com/lifeandstyle/2020/nov/14/stingless-sugarbags-the-joys-of-keeping-native-bees">Continue reading...</a>

## Streaming platforms aren't helping musicians – and things are only getting worse
 - [https://www.theguardian.com/culture/2020/nov/14/streaming-platforms-arent-helping-musicians-and-things-are-only-getting-worse](https://www.theguardian.com/culture/2020/nov/14/streaming-platforms-arent-helping-musicians-and-things-are-only-getting-worse)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 19:00:46+00:00

<p>Spotify has announced it’s cutting royalties in exchange for an algorithm boost. It’s the latest in a series of moves damaging an industry already on its knees</p><p>When I worked as an artist manager, there was one nerve-wracking question I was asked repeatedly: “Should I tweet this?”</p><p>It wasn’t just from unhappy musicians. It came from disillusioned label managers, miffed agents and even the odd publicist, and the subject matter of the Tweet was always the same: a firm critique of streaming platforms and the damage they are doing to the career of musicians and the industry.</p> <a href="https://www.theguardian.com/culture/2020/nov/14/streaming-platforms-arent-helping-musicians-and-things-are-only-getting-worse">Continue reading...</a>

## Green giants: the massive projects that could make Australia a clean energy superpower
 - [https://www.theguardian.com/environment/2020/nov/14/green-giants-the-massive-projects-that-could-make-australia-a-clean-energy-superpower](https://www.theguardian.com/environment/2020/nov/14/green-giants-the-massive-projects-that-could-make-australia-a-clean-energy-superpower)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 19:00:44+00:00

<p>The Asian Renewable Energy Hub would have an energy content equivalent to 40% of Australia’s overall electricity generation</p><p>The world’s largest power station is planned for a vast piece of desert about half the size of greater suburban Sydney in Australia’s remote north-west.</p><p>Called the <a href="https://asianrehub.com/">Asian Renewable Energy Hub</a>, its size is difficult to conceptualise. If built in full, there will be 1,600 giant wind turbines and a 78 sq km array of solar panels a couple of hundred kilometres east of Port Hedland in the Pilbara.</p> <a href="https://www.theguardian.com/environment/2020/nov/14/green-giants-the-massive-projects-that-could-make-australia-a-clean-energy-superpower">Continue reading...</a>

## Brazil: congresswoman and friend of slain politician Marielle Franco flees following death threats
 - [https://www.theguardian.com/world/2020/nov/13/congresswoman-taliria-petrone-flees-brazil-following-alleged-plot-kill-marielle-franco](https://www.theguardian.com/world/2020/nov/13/congresswoman-taliria-petrone-flees-brazil-following-alleged-plot-kill-marielle-franco)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 18:45:42+00:00

<p>Talíria Petrone goes into hiding after claims members of Rio’s paramilitary underworld want her dead</p><p>A Brazilian congresswoman who was friends with the <a href="https://www.theguardian.com/world/2018/mar/15/marielle-franco-shot-dead-targeted-killing-rio">slain politician Marielle Franco</a> has fled Rio de Janeiro after an alleged plot to kill her was uncovered.</p><p>Talíria Petrone, a black feminist activist who is one of the new faces of the Brazilian left, said she had gone into hiding after claims members of Rio’s paramilitary underworld wanted her dead.</p> <a href="https://www.theguardian.com/world/2020/nov/13/congresswoman-taliria-petrone-flees-brazil-following-alleged-plot-kill-marielle-franco">Continue reading...</a>

## How Black Lives Matter has inspired a generation of new UK activists
 - [https://www.theguardian.com/world/2020/nov/13/how-black-lives-matter-has-inspired-a-generation-of-new-uk-activists](https://www.theguardian.com/world/2020/nov/13/how-black-lives-matter-has-inspired-a-generation-of-new-uk-activists)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 18:37:41+00:00

<p>If anyone thought this summer’s protests would be the end of the movement these five young protesters have different ideas</p><p>The killing of <a href="https://www.theguardian.com/us-news/george-floyd">George Floyd</a> by a white police officer was the catalyst for widespread anti-racist protests in the US this summer. Though Floyd’s death took place thousands of miles away, the cry for racial justice was felt deeply in the UK. Britons stood up against racism, declaring support in their thousands for the <a href="https://www.theguardian.com/world/black-lives-matter-movement">Black Lives Matter</a> movement via a succession of passionate protests.</p><p>More than <a href="https://www.theguardian.com/uk-news/2020/jul/29/george-floyd-death-fuelled-anti-racism-protests-britain">260 towns and cities held protests in June and July</a> – from Monmouth in south Wales to Shetland in Scotland. British historians described them as the largest anti-racism rallies since the slavery era and at the heart of many of these protests was a new generation of young black Britons.</p> <a href="https://www.theguardian.com/world/2020/nov/13/how-black-lives-matter-has-inspired-a-generation-of-new-uk-activists">Continue reading...</a>

## The Guardian view on Dominic Cummings: voting to leave | Editorial
 - [https://www.theguardian.com/commentisfree/2020/nov/13/the-guardian-view-on-dominic-cummings-voting-to-leave](https://www.theguardian.com/commentisfree/2020/nov/13/the-guardian-view-on-dominic-cummings-voting-to-leave)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 18:28:40+00:00

<p>A departure from Downing Street caps a week of Tory infighting that has dominated the news at a time of national emergency</p><p>Boris Johnson should have asked his chief adviser, Dominic Cummings, to <a href="https://www.theguardian.com/politics/2020/nov/13/dominic-cummings-should-have-resigned-in-may-say-barnard-castle-witnesses" title="">resign months ago</a> when he broke the first coronavirus lockdown and showed no regret afterwards. Perhaps Mr Johnson thought he could not do without the architect of his election victory and his ally in pursuing a hardline Brexit. But the damage was done. <a href="https://www.theguardian.com/politics/2020/aug/06/the-cummings-effect-study-finds-public-faith-was-lost-after-aides-trip" title="">Public confidence</a> in the government’s handling of coronavirus fell and has not stopping falling since.</p><p>Mr Cummings walked out of Downing Street, in an act of theatrical defiance, on Friday. It is a mark of the tragicomic nature of Mr Johnson’s government that a week of infighting within No 10 dominates the news at a time of national emergency when hundreds are dying every day from a dangerous disease. Mr Cummings gets to walk away while Britain is stuck with the damage he has wrought.</p> <a href="https://www.theguardian.com/commentisfree/2020/nov/13/the-guardian-view-on-dominic-cummings-voting-to-leave">Continue reading...</a>

## The Guardian view on the care system: stop this cruelty to children | Editorial
 - [https://www.theguardian.com/commentisfree/2020/nov/13/the-guardian-view-on-the-care-system-stop-this-cruelty-to-children](https://www.theguardian.com/commentisfree/2020/nov/13/the-guardian-view-on-the-care-system-stop-this-cruelty-to-children)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 18:27:52+00:00

<p>Ministers and councils are failing to provide the care that vulnerable young people need. Change must start now </p><p>What kind of a country are we, in which the most vulnerable children cannot rely on ministers and councils to treat them well? New research published by the children’s commissioner for England, Anne Longfield, is far from the first time that the system used by local authorities to provide residential care for children has faced <a href="https://www.theguardian.com/society/2020/nov/11/government-accused-of-deep-ambivalence-to-plight-of-englands-children-in-care" title="">strong criticism</a>. The use of <a href="https://www.theguardian.com/commentisfree/2020/mar/12/the-guardian-view-on-unregulated-childrens-homes-a-national-scandal" title="">unregulated placements</a>, the disruption caused by frequent moves and the damage done to those forced to relocate many miles from their homes, schools and families, have all featured in court judgments and parliamentary and National Audit Office reports as well as in <a href="https://www.theguardian.com/society/2019/dec/25/revealed-thousands-children-care-unregulated-homes#:~:text=Thousands%20of%20children%20in%20care%20are%20increasingly%20being%20placed%20in,a%20Guardian%20investigation%20has%20found.&amp;text=The%20number%20of%20times%20children%20were%20placed%20in%20unregistered%20homes,212%20in%20the%20same%20period." title="">journalism by the Guardian</a> and others.</p><p>More extreme cases of abuse and criminality, of a kind which most people hoped belonged to a distant past, recur with disturbing frequency. A children’s home owned by a private equity firm was at the centre of the Rochdale child grooming scandal. This week it was revealed that <a href="https://www.mirror.co.uk/news/uk-news/drug-dealers-work-care-homes-22989648" title="">allegations of drug-dealing</a> at a home run by Care 4 Children in Lancashire has led to arrests. But Ms Longfield’s conclusion, in the piece of work that she has chosen as the finale to her four years in the job, is still startling: the government is guilty of “deep-rooted institutional ambivalence” to the 78,150 children that it is morally and legally obliged to look after.</p> <a href="https://www.theguardian.com/commentisfree/2020/nov/13/the-guardian-view-on-the-care-system-stop-this-cruelty-to-children">Continue reading...</a>

## End of macho era: what to expect now Dominic Cummings has gone
 - [https://www.theguardian.com/politics/2020/nov/13/end-of-the-macho-era-what-to-expect-now-dominic-cummings-has-gone](https://www.theguardian.com/politics/2020/nov/13/end-of-the-macho-era-what-to-expect-now-dominic-cummings-has-gone)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 18:27:05+00:00

<p>Out goes centralised power and hostility to the press; in comes meaningful contact with MPs</p><p>Out will go open hostility towards journalists, centralised power around Boris Johnson’s office and the ruthless dispatch of those who oppose the prime minister.</p><p>In, or so it is suggested, will come an attempt to win over the media, a collegiate approach to government and meaningful contact with the parliamentary party.</p> <a href="https://www.theguardian.com/politics/2020/nov/13/end-of-the-macho-era-what-to-expect-now-dominic-cummings-has-gone">Continue reading...</a>

## The week in wildlife – in pictures
 - [https://www.theguardian.com/environment/gallery/2020/nov/13/the-week-in-wildlife-in-pictures](https://www.theguardian.com/environment/gallery/2020/nov/13/the-week-in-wildlife-in-pictures)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 18:26:47+00:00

<p>The pick of the world’s best flora and fauna photos, including Exmoor ponies and mongoose wars</p> <a href="https://www.theguardian.com/environment/gallery/2020/nov/13/the-week-in-wildlife-in-pictures">Continue reading...</a>

## Tech companies under pressure to ban far-right forum used for militia organizing
 - [https://www.theguardian.com/world/2020/nov/13/mymilitia-ban-violence-threats-godaddy-cloudflare](https://www.theguardian.com/world/2020/nov/13/mymilitia-ban-violence-threats-godaddy-cloudflare)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 18:26:30+00:00

<p>MyMilitia users have posted threats against protesters and lawmakers, and experts say it’s a dangerous recruitment tool</p><p>Pressure is mounting on tech companies to ban MyMilitia, a website used by far-right extremists and armed groups to organize, after it was linked to threats of violence against US protesters and lawmakers this week.</p> <a href="https://www.theguardian.com/world/2020/nov/13/mymilitia-ban-violence-threats-godaddy-cloudflare">Continue reading...</a>

## Equalities campaigners criticise senior EHRC appointment
 - [https://www.theguardian.com/society/2020/nov/13/campaigners-criticise-senior-ehrc-appointment-david-goodhart](https://www.theguardian.com/society/2020/nov/13/campaigners-criticise-senior-ehrc-appointment-david-goodhart)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 18:15:35+00:00

<p>Journalist David Goodhart has defended ‘hostile environment’ measures and ‘white self-interest’</p><p>The government’s appointment of a supporter of the Home Office’s “hostile environment” policy to the equalities watchdog has prompted a fierce backlash among equalities campaigners.</p><p>The writer and journalist David Goodhart, who is head of immigration and integration at the right-leaning Policy Exchange thinktank, has been selected as a commissioner at the Equality and Human Rights Commission (EHRC), which is currently <a href="https://www.equalityhumanrights.com/en/our-work/news/progress-hostile-environment-legal-assessment">investigating</a> the Home Office’s implementation of its hostile environment immigration policies.</p> <a href="https://www.theguardian.com/society/2020/nov/13/campaigners-criticise-senior-ehrc-appointment-david-goodhart">Continue reading...</a>

## Kylie Minogue becomes first woman to top album chart across five decades
 - [https://www.theguardian.com/music/2020/nov/13/kylie-minogue-becomes-first-woman-to-top-album-chart-across-five-decades](https://www.theguardian.com/music/2020/nov/13/kylie-minogue-becomes-first-woman-to-top-album-chart-across-five-decades)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 18:00:43+00:00

<p>No 1 for 15th album Disco continues a run started in 1988, while Shirley Bassey returns to the Top 5, becoming the first woman with Top 40 albums across seven consecutive decades</p><p>Kylie Minogue has become the first woman to top the album chart in each of five consecutive decades.</p><p>Her <a href="https://www.theguardian.com/music/2020/nov/07/kylie-minogue-disco-review">15th studio album, Disco</a>, reaches No 1 this week, beating <a href="https://www.theguardian.com/music/2020/nov/05/little-mix-confetti-review">Little Mix’s Confetti</a> in one of the hottest chart battles of 2020. Disco earned the biggest opening week sales of the year, with 55,000 sales units drawn from streaming, downloads, CDs, vinyl and even a cassette release.</p> <a href="https://www.theguardian.com/music/2020/nov/13/kylie-minogue-becomes-first-woman-to-top-album-chart-across-five-decades">Continue reading...</a>

## Fears of 'isolation fatigue' if students quarantine before and after Christmas
 - [https://www.theguardian.com/education/2020/nov/13/fears-of-isolation-fatigue-if-students-quarantine-before-and-after-christmas](https://www.theguardian.com/education/2020/nov/13/fears-of-isolation-fatigue-if-students-quarantine-before-and-after-christmas)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 17:51:17+00:00

<p>Vice-chancellor of York calls for ‘hard thinking’ on government support for self-isolating young people</p><ul><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>Students are at risk of “self-isolation fatigue” after Christmas as they face spending time quarantining both before and after their break, a university vice-chancellor has said.</p><p>The warning came as universities that have applied for rapid-testing kits to <a href="https://www.theguardian.com/education/2020/nov/11/mass-covid-testing-will-allow-students-to-return-in-january-says-minister">mass-test students</a> - as part of a government plan to allow a <a href="https://www.theguardian.com/world/2020/nov/11/england-students-to-get-six-day-window-to-get-home-before-christmas">six-day “travel window”</a> for students in England - wait to hear what they will be given.</p> <a href="https://www.theguardian.com/education/2020/nov/13/fears-of-isolation-fatigue-if-students-quarantine-before-and-after-christmas">Continue reading...</a>

## BBC finds Princess Diana's lost note that it says clears Martin Bashir
 - [https://www.theguardian.com/media/2020/nov/13/bbc-finds-princess-diana-note-clearing-martin-bashir-wrongdoing](https://www.theguardian.com/media/2020/nov/13/bbc-finds-princess-diana-note-clearing-martin-bashir-wrongdoing)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 17:50:08+00:00

<p>Broadcaster claimed document proved royal was not coerced into doing 1995 interview</p><p>The BBC says it has found the handwritten note from Princess Diana that it claimed clears Martin Bashir of wrongdoing in relation to his landmark 1995 interview with the royal.</p><p>The broadcaster had previously said it had lost the crucial piece of paper, which it used to explain away Bashir’s use of fake bank statements to gain an introduction to Diana.</p> <a href="https://www.theguardian.com/media/2020/nov/13/bbc-finds-princess-diana-note-clearing-martin-bashir-wrongdoing">Continue reading...</a>

## Seven Irish republicans sentenced after MI5 bugging operation
 - [https://www.theguardian.com/uk-news/2020/nov/13/seven-irish-republicans-jailed-for-combined-33-years-after-mi5-bugging](https://www.theguardian.com/uk-news/2020/nov/13/seven-irish-republicans-jailed-for-combined-33-years-after-mi5-bugging)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 17:48:55+00:00

<p>Investigation aimed at Continuity IRA involved man named in connection with Omagh bombing</p><p>Seven leading Irish republican dissidents have been jailed following an MI5 bugging operation aimed at the Continuity IRA.</p><p>The seven CIRA hardline republicans include Patrick “Mooch” Blair, who was named in the House of Commons in 2002 as the man who built the bomb that caused the Omagh massacre – the largest single atrocity of Northern Ireland’s Troubles.</p> <a href="https://www.theguardian.com/uk-news/2020/nov/13/seven-irish-republicans-jailed-for-combined-33-years-after-mi5-bugging">Continue reading...</a>

## Premier League confirms scrapping of controversial pay-per-view model
 - [https://www.theguardian.com/football/2020/nov/13/premier-league-confirms-scrapping-of-controversial-pay-per-view-model](https://www.theguardian.com/football/2020/nov/13/premier-league-confirms-scrapping-of-controversial-pay-per-view-model)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 17:47:49+00:00

<ul><li>Fans will not be charged £14.95 to watch games for rest of year</li><li>Matches back on Sky, BT Sport, Amazon and free-to-air on BBC</li></ul><p>The Premier League will show every fixture live on TV until the new year, with no pay-per-view matches in sight.</p><p><a href="https://www.theguardian.com/football/2020/nov/05/premier-leagues-pay-per-view-model-likely-to-be-scrapped-after-this-weekend">As expected</a>, the top flight has abandoned the controversial format that led to fans being charged £14.95 to watch a single game. Instead, it has reverted to the model used after football returned in June following the first national lockdown; most games will be shown live on Sky and BT Sport, with additional fixtures on Amazon Prime and free to air on the BBC.</p> <a href="https://www.theguardian.com/football/2020/nov/13/premier-league-confirms-scrapping-of-controversial-pay-per-view-model">Continue reading...</a>

## Travel industry pays tribute after death of John Hays
 - [https://www.theguardian.com/business/2020/nov/13/travel-industry-pays-tribute-death-of-john-hays-thomas-cook](https://www.theguardian.com/business/2020/nov/13/travel-industry-pays-tribute-death-of-john-hays-thomas-cook)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 17:43:34+00:00

<p>Hays started eponymous firm in 1980, and with wife rescued thousands of Thomas Cook jobs</p><p>The founder of Hays Travel, the family-owned business that <a href="https://www.theguardian.com/business/2019/oct/16/hays-travel-offer-jobs-tthomas-cook-staff">rescued thousands of jobs</a> at Thomas Cook, has died.</p><p>John Hays, who started the travel firm in 1980, collapsed on Friday while working at its head office in Sunderland. The 71-year-old was married to the co-owner, Irene Hays.</p> <a href="https://www.theguardian.com/business/2020/nov/13/travel-industry-pays-tribute-death-of-john-hays-thomas-cook">Continue reading...</a>

## Priti Patel not following her own anti-trafficking policy, judge rules
 - [https://www.theguardian.com/uk-news/2020/nov/13/priti-patel-departing-from-her-own-anti-trafficking-policy](https://www.theguardian.com/uk-news/2020/nov/13/priti-patel-departing-from-her-own-anti-trafficking-policy)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 17:36:08+00:00

<p>Ruling could halt deportation of hundreds of asylum seekers who arrived in UK during pandemic</p><p>The deportation of hundreds of asylum seekers who arrived in the UK on small boats could be halted after a judge ruled that the home secretary was departing from her own policy on identifying victims of trafficking.</p><p>The high court case was brought by three potential victims of trafficking – one from Eritrea and two from Sudan – who recently arrived in the UK on small boats. Trafficking in Libya is well-documented, and there is a particular risk that asylum seekers who have passed through the country have been trafficked.</p> <a href="https://www.theguardian.com/uk-news/2020/nov/13/priti-patel-departing-from-her-own-anti-trafficking-policy">Continue reading...</a>

## First Met police spy operation involved sex with Vietnam activist, inquiry told
 - [https://www.theguardian.com/uk-news/2020/nov/13/first-met-police-spy-operation-involved-sex-with-vietnam-activist-inquiry-told](https://www.theguardian.com/uk-news/2020/nov/13/first-met-police-spy-operation-involved-sex-with-vietnam-activist-inquiry-told)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 17:33:33+00:00

<p>Undercover officers allegedly had sex with their surveillance targets as long ago as 1968 </p><p>Scotland Yard’s very first operation to spy on leftwing campaigners began in the 1960s with an undercover police officer who is now accused of having an intimate relationship with an activist, a public inquiry has heard.</p><p>The undercover officer, whose real name was Helen Crampton, is now dead. It is alleged that she had a relationship in 1968 with George Cochrane, a prominent campaigner against the Vietnam war.</p> <a href="https://www.theguardian.com/uk-news/2020/nov/13/first-met-police-spy-operation-involved-sex-with-vietnam-activist-inquiry-told">Continue reading...</a>

## Covering Peter Sutcliffe’s crimes, I saw that women weren't listened to – and they still aren't  | Joan Smith
 - [https://www.theguardian.com/commentisfree/2020/nov/13/peter-sutcliffe-crimes-women-police-investigation-murders-misogny](https://www.theguardian.com/commentisfree/2020/nov/13/peter-sutcliffe-crimes-women-police-investigation-murders-misogny)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 17:27:05+00:00

<p>The police investigation into the murders of 13 women opened my eyes to a vein of misogyny that remains just as lethal today</p><p>I am so angry, all these years later. When I heard that this <a href="https://www.theguardian.com/uk-news/2020/nov/13/yorkshire-ripper-peter-sutcliffe-dies-aged-74">insignificant little man had died</a>, more than four decades after he ruined the lives of so many women, the anger and hurt came rushing back. I remember it as though it were yesterday: the fear we lived with in the north of England, the suspicion about neighbours and colleagues, the sense that we couldn’t rely on the police to protect us.</p><p>We couldn’t even rely on them to catch him, even though Peter Sutcliffe was hardly anyone’s idea of a criminal mastermind. He spoke to the women he targeted, letting them hear his Yorkshire accent and see his face. Detectives visited him at home on nine occasions but didn’t bother to search his garage, where he kept the weapons he used to <a href="https://www.theguardian.com/uk-news/2020/nov/13/death-of-peter-sutcliffe-brings-some-kind-of-closure-for-victims-families">kill at least 13 women</a>.</p> <a href="https://www.theguardian.com/commentisfree/2020/nov/13/peter-sutcliffe-crimes-women-police-investigation-murders-misogny">Continue reading...</a>

## Deal or no-deal Brexit, Cummings’ departure turns up the heat on Johnson | Anand Menon
 - [https://www.theguardian.com/commentisfree/2020/nov/13/no-deal-brexit-cummings-johnson-vote-leave](https://www.theguardian.com/commentisfree/2020/nov/13/no-deal-brexit-cummings-johnson-vote-leave)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 17:19:58+00:00

<p>Big decisions have to be made, but the key architects of Vote Leave will not be around to deal with the consequences</p><p>A <a href="https://www.theguardian.com/politics/2020/nov/13/what-has-dominic-cummings-actually-achieved-in-no-10">hard rain</a> has fallen in Downing Street, and the <a href="https://www.theguardian.com/politics/2020/jul/01/predictive-text-why-superforecasting-is-top-of-dominic-cummings-reading-list">superforecaster </a>forgot his umbrella. Above and beyond the guilty pleasure we all take from such political pantomime, <a href="https://www.theguardian.com/politics/2020/nov/13/dominic-cummings-has-already-left-job-at-no-10-reports">Dominic Cummings’ departure</a> has implications for how we are governed. The prime minister will have to make a big decision on our relationship with the European Union in the next few weeks, so will the changes in No 10 make a difference <a href="https://www.theguardian.com/politics/2020/nov/13/brexit-standoff-blamed-on-no-10-infighting-over-cummings-departure">when it comes to Brexit</a>?</p><p>There is, in fact, very little room for manoeuvre – no time to negotiate anything substantially different to the deal already under discussion. Being more ambitious, for instance on security cooperation, would mean the UK and EU signing a “mixed agreement” which, in turn, would require individual ratification by national and regional parliaments in member states. The European commission has reportedly been telling member states that there is simply not enough time for this.</p> <a href="https://www.theguardian.com/commentisfree/2020/nov/13/no-deal-brexit-cummings-johnson-vote-leave">Continue reading...</a>

## Officials condemn Trump's false claims and say election 'most secure in US history'
 - [https://www.theguardian.com/us-news/2020/nov/13/us-election-most-secure-history-voter-fraud-false-claims](https://www.theguardian.com/us-news/2020/nov/13/us-election-most-secure-history-voter-fraud-false-claims)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 17:11:44+00:00

<ul><li>State and federal officials confirm no evidence of voter fraud</li><li>Trump continues to refuse to accept defeat by Joe Biden</li></ul><p>The presidential election was the “most secure in American history” with no evidence that votes were compromised or altered, a coalition of federal and state officials has said, offering the clearest repudiation yet of Donald Trump’s false claims of fraud.</p><p> <span>Related: </span><a href="https://www.theguardian.com/us-news/live/2020/nov/13/joe-biden-donald-trump-election-result-coronavirus-latest-updates">US election officials dismiss 'unfounded claims' about result – live updates</a> </p> <a href="https://www.theguardian.com/us-news/2020/nov/13/us-election-most-secure-history-voter-fraud-false-claims">Continue reading...</a>

## Italian farmworker given hospital order for strangling Devon writer
 - [https://www.theguardian.com/uk-news/2020/nov/13/italian-farmworker-given-hospital-order-for-strangling-devon-writer](https://www.theguardian.com/uk-news/2020/nov/13/italian-farmworker-given-hospital-order-for-strangling-devon-writer)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 17:10:47+00:00

<p>Luigi Palmas admits killing Katherine Bevan and leaving her body in cattle pen</p><p>An Italian farmworker with paranoid schizophrenia who strangled an animal-loving writer and left her body in a cattle pen on a Devon farm has been <a href="https://www.devon-cornwall.police.uk/News/NewsArticle.aspx?id=c6d9d222-9ada-4d08-821e-afbbb41791b9">given a hospital order</a> at Exeter crown court after admitting manslaughter by reason of diminished responsibility.</p><p>Luigi Palmas, 27, waited in the shadows at Combe Farm in Gittisham and attacked Katherine Bevan, 53, as she tended the <a href="https://www.theguardian.com/uk-news/2020/jan/22/man-charged-with-of-woman-at-devon-stud-farm-luigi-palmas-katherine-bevan">cows she adored and which she had written about</a>.</p> <a href="https://www.theguardian.com/uk-news/2020/nov/13/italian-farmworker-given-hospital-order-for-strangling-devon-writer">Continue reading...</a>

## 'It was toxic': how sexism threw police off the trail of the Yorkshire Ripper
 - [https://www.theguardian.com/uk-news/2020/nov/13/it-was-toxic-how-sexism-threw-police-off-the-trail-of-the-yorkshire-ripper](https://www.theguardian.com/uk-news/2020/nov/13/it-was-toxic-how-sexism-threw-police-off-the-trail-of-the-yorkshire-ripper)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 17:09:10+00:00

<p>Sex-worker victims were seen as dispensible, survivors’ accounts ignored, and women blamed for drinking or going out alone</p><p>Every woman old enough to remember the 1970s recalls nights in the north of England during Peter Sutcliffe’s decade of terror.</p><p>“Leeds was really in a state of almost lockdown and women were afraid to go out,” remembered Mo Lea, who was a student in the city at the time.</p> <a href="https://www.theguardian.com/uk-news/2020/nov/13/it-was-toxic-how-sexism-threw-police-off-the-trail-of-the-yorkshire-ripper">Continue reading...</a>

## Daily Mail pays £25,000 to professor it falsely accused of inciting race war
 - [https://www.theguardian.com/media/2020/nov/13/daily-mail-pays-25000-to-professor-it-falsely-accused-of-inciting-race-war-priyamvada-gopal-fake-tweets](https://www.theguardian.com/media/2020/nov/13/daily-mail-pays-25000-to-professor-it-falsely-accused-of-inciting-race-war-priyamvada-gopal-fake-tweets)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 16:53:42+00:00

<p>Priyamvada Gopal reaches settlement over Amanda Platell column that was based on fake tweets </p><p>The Daily Mail has paid £25,000 to a Cambridge academic after the newspaper falsely accused her of inciting a race war.</p><p>Priyamvada Gopal reached the settlement with the news outlet and its sister website MailOnline after they published a column by Amanda Platell in which the journalist attributed a series of inflammatory quotes to the English professor.</p> <a href="https://www.theguardian.com/media/2020/nov/13/daily-mail-pays-25000-to-professor-it-falsely-accused-of-inciting-race-war-priyamvada-gopal-fake-tweets">Continue reading...</a>

## At least 40 in Trump inner circle have contracted Covid – who are the newest cases?
 - [https://www.theguardian.com/us-news/2020/nov/13/trump-advisers-administration-coronavirus-cases-who-are-they](https://www.theguardian.com/us-news/2020/nov/13/trump-advisers-administration-coronavirus-cases-who-are-they)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 16:45:37+00:00

<p>Another cluster was identified this week – and several infected people had attended the White House’s election night party</p><p>Another cluster of coronavirus cases has been identified in Donald Trump’s inner circle this week, adding to the dozens of cases tied to his administration.</p><p>At least 40 people in Trump’s orbit – including his family and White House aides and staff – have tested positive since early September, <a href="https://www.nytimes.com/interactive/2020/11/11/us/politics/white-house-covid-outbreak.html">according to the New York Times.</a></p> <a href="https://www.theguardian.com/us-news/2020/nov/13/trump-advisers-administration-coronavirus-cases-who-are-they">Continue reading...</a>

## Police offer 'heartfelt apology' to families of Peter Sutcliffe victims
 - [https://www.theguardian.com/uk-news/2020/nov/13/police-offer-heartfelt-apology-to-families-of-yorkshire-ripper-peter-sutcliffe-victims](https://www.theguardian.com/uk-news/2020/nov/13/police-offer-heartfelt-apology-to-families-of-yorkshire-ripper-peter-sutcliffe-victims)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 16:36:33+00:00

<p>West Yorkshire chief constable apologises for failings in serial killer investigation</p><p>West Yorkshire police has offered a “heartfelt apology” to the surviving victims and families of Peter Sutcliffe, the serial killer known as the Yorkshire Ripper, <a href="https://www.theguardian.com/uk-news/2020/nov/13/yorkshire-ripper-peter-sutcliffe-dies-aged-74">who has died</a>.</p><p>Sutcliffe, once one of the most feared criminals in the country, died aged 74 after reportedly refusing treatment for coronavirus. His killing rampage across Yorkshire and Manchester from 1975 to 1980 terrified northern England and sparked a huge manhunt and a botched police inquiry.</p> <a href="https://www.theguardian.com/uk-news/2020/nov/13/police-offer-heartfelt-apology-to-families-of-yorkshire-ripper-peter-sutcliffe-victims">Continue reading...</a>

## This is no conventional coup. Trump is paving the way for a 'virtual Confederacy' | Jonathan Freedland
 - [https://www.theguardian.com/commentisfree/2020/nov/13/trump-coup-virtual-confederacy-race-legal-trumpian](https://www.theguardian.com/commentisfree/2020/nov/13/trump-coup-virtual-confederacy-race-legal-trumpian)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 16:22:28+00:00

<p>Race is the message behind his supporters’ legal shenanigans, and a keystone for a Trumpian government in exile</p><p>Not for the first time, Donald Trump’s unhinged behaviour prompts an <a href="https://www.theguardian.com/commentisfree/2019/jul/05/donald-trump-dictator-not-enough-laugh">uncomfortable question</a>: should we be laughing in derision or trembling with fear? Is he playing out his last days as nothing more than a sore loser pathetically kidding himself that he might yet score the winning run, even after the crowd’s gone home and the stadium is empty – or is his insistence that last week’s election was stolen an attempt to cling on to power, to stage a coup against his democratically elected successor?</p><p>The case for laughter is strong, as Trump’s allegations crumble to dust. On Thursday, a wing of the department of homeland security – part of the government that Trump still heads – <a href="https://www.nytimes.com/2020/11/12/us/politics/election-officials-contradict-trump.html">declared</a> that last week’s election “was the most secure in American history”, and that there was “no evidence” of any malpractice, still less of the mass-scale fraud that Trump has groundlessly alleged.</p> <a href="https://www.theguardian.com/commentisfree/2020/nov/13/trump-coup-virtual-confederacy-race-legal-trumpian">Continue reading...</a>

## Making America grrr-eat again: Major and Champ, the Bidens' 'first dogs'
 - [https://www.theguardian.com/us-news/2020/nov/13/first-dogs-major-champ-joe-biden-white-house](https://www.theguardian.com/us-news/2020/nov/13/first-dogs-major-champ-joe-biden-white-house)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 16:21:31+00:00

<p>Joe Biden’s election victory draws to an end to a Trump presidency considered hostile to man’s best friend<br /></p><p>With Joe Biden’s election, dignity has been restored to the US presidency: after four years marked by perverse priorities and conspicuous inhumanity, a dog will finally be back in the White House.</p><p>When Biden takes office in January, he and his wife Jill will be accompanied by their two German shepherds: Champ, 12, and Major, 2. They are the first dogs to occupy the Oval Office since the departure of Bo and Sunny, the Obamas’ Portuguese water dogs, in 2016.</p> <a href="https://www.theguardian.com/us-news/2020/nov/13/first-dogs-major-champ-joe-biden-white-house">Continue reading...</a>

## US officials warn of tens of thousands more Covid deaths in coming weeks
 - [https://www.theguardian.com/world/2020/nov/13/us-coronavirus-covid-deaths-cdc-warning](https://www.theguardian.com/world/2020/nov/13/us-coronavirus-covid-deaths-cdc-warning)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 16:14:12+00:00

<ul><li>CDC warning comes amid threat of PPE and bed shortages</li><li>New coronavirus cases increase with 150,000 on Thursday</li></ul><p>Government health officials have warned that tens of thousands of Americans will die in the coming weeks as coronavirus continued to surge across the country, shattering more daily records.</p><p> <span>Related: </span><a href="https://www.theguardian.com/world/live/2020/nov/13/coronavirus-live-news-quarter-of-deaths-in-france-linked-to-covid-as-us-tops-140000-daily-cases">Coronavirus live news: Germany, Sweden and Russia all report record rises in daily cases</a> </p> <a href="https://www.theguardian.com/world/2020/nov/13/us-coronavirus-covid-deaths-cdc-warning">Continue reading...</a>

## Violent extremism linked to failure of migrants to integrate, EU says
 - [https://www.theguardian.com/world/2020/nov/13/violent-extremism-migrants-failure-to-integrate-eu](https://www.theguardian.com/world/2020/nov/13/violent-extremism-migrants-failure-to-integrate-eu)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 16:00:34+00:00

<p>Reference to Islam removed from EU governments’ declaration after disagreements</p><p>The rise of violent extremism in Europe has been linked to the failure of migrants to integrate, in a hard-debated joint declaration by EU governments on the recent terror attacks.</p><p>The statement by EU home affairs ministers was described by Horst Seehofer, Germany’s interior minister, as a “great sign of solidarity” when delivered on Friday but it had been heavily watered down from a controversial initial draft.</p> <a href="https://www.theguardian.com/world/2020/nov/13/violent-extremism-migrants-failure-to-integrate-eu">Continue reading...</a>

## Corrie McKeague died after getting into waste bin, UK inquest hears
 - [https://www.theguardian.com/uk-news/2020/nov/13/corrie-mckeague-died-after-getting-into-waste-bin-uk-inquest-hears](https://www.theguardian.com/uk-news/2020/nov/13/corrie-mckeague-died-after-getting-into-waste-bin-uk-inquest-hears)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 15:51:09+00:00

<p>Missing airman is believed to have died after night out in Bury St Edmunds in 2016<br /></p><p>A missing airman is believed to have died after he climbed into an industrial waste bin while drunk on a night out and it was then emptied into a lorry, an inquest has heard.</p><p>Corrie McKeague, of Dunfermline, Fife, was 23 when he vanished in the early hours of 24 September 2016 after a night out in Bury St Edmunds, Suffolk.</p> <a href="https://www.theguardian.com/uk-news/2020/nov/13/corrie-mckeague-died-after-getting-into-waste-bin-uk-inquest-hears">Continue reading...</a>

## Man arrested over murder of Met police officer Matt Ratana
 - [https://www.theguardian.com/uk-news/2020/nov/13/man-arrested-over-of-met-police-officer-matt-ratana](https://www.theguardian.com/uk-news/2020/nov/13/man-arrested-over-of-met-police-officer-matt-ratana)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 15:48:49+00:00

<p>Suspect has been in critical care with gunshot injury since sergeant was shot in September</p><p>The prime suspect for the killing of Sergeant Matt Ratana has been formally arrested on suspicion of murder, with detectives now waiting to question him under criminal caution.</p><p>Louis de Zoysa, 23, had been too ill to be arrested after the incident, having received gunshot wounds, which are believed to have been self-inflicted.</p> <a href="https://www.theguardian.com/uk-news/2020/nov/13/man-arrested-over-of-met-police-officer-matt-ratana">Continue reading...</a>

## Leaders at a loss as coronavirus catches up with central Europe
 - [https://www.theguardian.com/world/2020/nov/13/leaders-at-a-loss-as-coronavirus-catches-up-with-central-europe](https://www.theguardian.com/world/2020/nov/13/leaders-at-a-loss-as-coronavirus-catches-up-with-central-europe)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 15:46:43+00:00

<p>Politicians struggle to explain why a region so much less affected in spring is so badly hit now<br /></p><p>In the countries of central Europe, which <a href="https://www.theguardian.com/world/2020/may/05/why-has-eastern-europe-suffered-less-from-coronavirus-than-the-west">during spring seemed to provide a best-practice model</a> for keeping coronavirus at bay, case numbers have risen sharply, and governments in the region fear that their health systems are close to capacity and may struggle to cope. Central Europe is now just as badly hit as countries further west, and by some parameters is doing worse.</p><p>The Visegrad Four group of nations – Czech Republic, Poland, Hungary and Slovakia – were all notable for their success in keeping case numbers low earlier in the year, even as gruesome statistics of deaths and hospitalisations came out of western Europe on a daily basis.</p> <a href="https://www.theguardian.com/world/2020/nov/13/leaders-at-a-loss-as-coronavirus-catches-up-with-central-europe">Continue reading...</a>

## A vaccine? Trump going? A bit of good news and my optimism has gone bananas
 - [https://www.theguardian.com/uk-news/2020/nov/13/a-vaccine-trump-going-a-bit-of-good-news-and-my-optimism-has-gone-bananas](https://www.theguardian.com/uk-news/2020/nov/13/a-vaccine-trump-going-a-bit-of-good-news-and-my-optimism-has-gone-bananas)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 15:46:34+00:00

<p>The doom spiral has been interrupted. Could it be that, by the spring, things will actually be better than they are now?</p><p>After five years of wanting to move, about two years of having to move and eight months of really urgently needing to move, the kids being so large and teen now that we could all smell each other across two floors of our titchy house, we finally moved. The sheer number of small, troublesome questions this prompted – have we traumatised the rabbit? Will the dog definitely die if he runs on to the A3, and will the resulting pile-up be legally my fault? What’s at the bottom of this pan we packed, oh God no, it’s curdled milk, who moves house without washing up first? Me, that’s who – completely clouded my vision. It was days before I realised something good had happened.</p><p>The <a href="https://www.theguardian.com/us-news/ng-interactive/2020/nov/12/us-election-results-2020-joe-biden-donald-trump-presidential-electoral-college-votes">US elections unfolded at the same time</a>, following the same pattern. Lots of facts, and counting, and more facts, and revised counting, and nebulous fretting, until finally, wait … this is actually good. Something good has happened. This would have been a really fortuitous day to buy a lottery ticket, I thought on Saturday evening; with so much improbable good fortune, the chances of me winning a million quid are probably pretty high. I didn’t follow that up because I was too busy drinking and whatnot. Then two days later, <a href="https://www.theguardian.com/commentisfree/2020/nov/10/the-guardian-view-on-the-covid-vaccine-breakthrough-making-it-work">a vaccine</a>.</p> <a href="https://www.theguardian.com/uk-news/2020/nov/13/a-vaccine-trump-going-a-bit-of-good-news-and-my-optimism-has-gone-bananas">Continue reading...</a>

## Education experts counter government attack on critical race theory
 - [https://www.theguardian.com/education/2020/nov/13/education-experts-counter-government-attack-on-critical-race-theory](https://www.theguardian.com/education/2020/nov/13/education-experts-counter-government-attack-on-critical-race-theory)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 15:34:24+00:00

<p>Academics speak out amid controversial crackdown on teaching materials in schools</p><p>More than 80 leading academics specialising in the field of <a href="https://www.theguardian.com/education">education</a> and social sciences have accused the government of misrepresenting critical race theory in a controversial crackdown on teaching materials in schools.</p><p>In <a href="https://www.theguardian.com/education/2020/nov/13/diversity-of-thought-is-vital-in-education">a letter to the Guardian</a>, senior figures from University College London’s Institute of Education said they were concerned about a pattern of statements and <a href="https://www.gov.uk/guidance/plan-your-relationships-sex-and-health-curriculum">guidance</a> from politicians “proscribing” certain resources and bodies of work from classrooms.</p> <a href="https://www.theguardian.com/education/2020/nov/13/education-experts-counter-government-attack-on-critical-race-theory">Continue reading...</a>

## Matrix party ‘disguised as film shoot’ to bypass German Covid rules
 - [https://www.theguardian.com/world/2020/nov/13/matrix-party-disguised-film-shoot-bypass-german-covid-rules-keanu-reeves](https://www.theguardian.com/world/2020/nov/13/matrix-party-disguised-film-shoot-bypass-german-covid-rules-keanu-reeves)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 15:23:16+00:00

<p>Keanu Reeves among 200 people at studio party where guests came as extras, says report</p><ul><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>German health authorities say they plan to speak to the studio where the latest Matrix film was shot after a party allegedly attended by the Hollywood actor Keanu Reeves was held to mark the end of filming, despite coronavirus restrictions.</p><p>About 200 people were at the party disguised as a film shoot, with the guests invited to come as extras in an apparent attempt to bypass health regulations, according to the German tabloid Bild.</p> <a href="https://www.theguardian.com/world/2020/nov/13/matrix-party-disguised-film-shoot-bypass-german-covid-rules-keanu-reeves">Continue reading...</a>

## Is the vaccine safe? Do I need it if I've had Covid? Readers' questions answered
 - [https://www.theguardian.com/world/2020/nov/13/is-the-vaccine-safe-do-i-need-it-if-ive-had-covid-readers-questions-answered](https://www.theguardian.com/world/2020/nov/13/is-the-vaccine-safe-do-i-need-it-if-ive-had-covid-readers-questions-answered)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 15:20:43+00:00

<p>‘Zero chance’ mRNA can alter genes, says expert, adding that vaccine can ‘top up’ immune response from infection</p><ul><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p><em>“The concerted efforts put into developing a vaccine are wonderful but they can’t possibly know about long-term adverse effects. I’ll have it if it’s offered to me, and at my age long-term effects are irrelevant. I just hope it doesn’t turn out to be a latter-day thalidomide.” Jenny Walters, retired teacher, Ashburton</em></p> <a href="https://www.theguardian.com/world/2020/nov/13/is-the-vaccine-safe-do-i-need-it-if-ive-had-covid-readers-questions-answered">Continue reading...</a>

## The Mandalorian recap: season two, episode three – steer clear of the seafood
 - [https://www.theguardian.com/tv-and-radio/2020/nov/13/the-mandalorian-recap-season-two-episode-three-recap-disney](https://www.theguardian.com/tv-and-radio/2020/nov/13/the-mandalorian-recap-season-two-episode-three-recap-disney)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 15:15:03+00:00

<p>From squid-like Quarrens to prawn-looking Mon Calamari, there is an aquatic theme this week as our hero takes to the sea, while a would-be power-player reveals her true colours</p><p><em>Spoiler alert: this blog is published after The Mandalorian airs on <a href="https://www.disneyplus.com/en-gb/series/the-mandalorian/3jLIGMDYINqD">Disney+</a>. Do not read unless you have watched season two, episode three<br /></em></p><p>There is something I need if I am to rule Mandalore … something that was once mine” – Bo-Katan</p> <a href="https://www.theguardian.com/tv-and-radio/2020/nov/13/the-mandalorian-recap-season-two-episode-three-recap-disney">Continue reading...</a>

## What has Dominic Cummings actually achieved in No 10?
 - [https://www.theguardian.com/politics/2020/nov/13/what-has-dominic-cummings-actually-achieved-in-no-10](https://www.theguardian.com/politics/2020/nov/13/what-has-dominic-cummings-actually-achieved-in-no-10)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 15:08:46+00:00

<p>Divisive Boris Johnson’s chief adviser is leaving Downing Street</p><p>Dominic Cummings arrived in Downing Street with big plans, and the stated intention to only stay long enough to get them rolling. So what has Boris Johnson’s chief adviser and policy touchstone actually achieved?</p> <a href="https://www.theguardian.com/politics/2020/nov/13/what-has-dominic-cummings-actually-achieved-in-no-10">Continue reading...</a>

## FCA to censure Carillion for 'recklessly misleading' investors
 - [https://www.theguardian.com/business/2020/nov/13/fca-to-censure-carillion-bosses-for-misleading-markets-and-investors-collapse](https://www.theguardian.com/business/2020/nov/13/fca-to-censure-carillion-bosses-for-misleading-markets-and-investors-collapse)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 15:02:14+00:00

<p>Watchdog criticised for failing to impose financial penalties two years after firm’s collapse </p><p>The City watchdog has said that Carillion and some of its executive directors “recklessly misled” markets and investors over the deteriorating state of its finances before the company <a href="https://www.theguardian.com/business/carillion">collapsed into liquidation two years ago.</a></p><p>Carillion was one of the government’s biggest contractors, with work spanning the construction of roads and rail infrastructure to running school canteens. Its collapse was the biggest corporate failure in the UK in a decade and prompted criticism of its executives, auditors and the handling of public sector contracts by private companies.</p> <a href="https://www.theguardian.com/business/2020/nov/13/fca-to-censure-carillion-bosses-for-misleading-markets-and-investors-collapse">Continue reading...</a>

## Boris Johnson faces bumpy path back to respectability in the White House
 - [https://www.theguardian.com/politics/2020/nov/13/boris-johnson-faces-bumpy-path-back-to-respectability-in-white-house-joe-biden](https://www.theguardian.com/politics/2020/nov/13/boris-johnson-faces-bumpy-path-back-to-respectability-in-white-house-joe-biden)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 15:00:34+00:00

<p>Joe Biden has called UK PM a Trump clone, and his Irish links make Brexit a sensitive subject</p><p>Tommy Vietor, a feisty former spokesman for Barack Obama, made a little news last weekend by describing Boris Johnson as a <a href="https://twitter.com/tvietor08/status/1325137653851828230">“shapeshifting creep”</a>. It added fuel to the fire of those who say the UK prime minister is likely to struggle to charm himself into Joe Biden’s inner circle, leaving a shunned UK bobbing uneasily in the mid-Atlantic</p><p>The global reaction to his remark, Vietor said, was a timely reminder that dumb tweets by washed-up ex-Obama staffers – his own description – can carry greater significance now that Obama’s vice-president is set to move into the White House.</p> <a href="https://www.theguardian.com/politics/2020/nov/13/boris-johnson-faces-bumpy-path-back-to-respectability-in-white-house-joe-biden">Continue reading...</a>

## I am not attractive to others. Would life be better if I made more effort?
 - [https://www.theguardian.com/lifeandstyle/2020/nov/13/not-attractive-to-others-would-life-be-better-if-i-made-more-effort](https://www.theguardian.com/lifeandstyle/2020/nov/13/not-attractive-to-others-would-life-be-better-if-i-made-more-effort)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 15:00:19+00:00

<p>Looking stylish is a smokescreen, says Annalisa Barbieri, where and why did you learn to be quiet and invisible?</p><p><strong>I am a 63-year-old woman</strong><strong> </strong><strong>who, a</strong><strong>bout 10 years ago, </strong><strong>realised </strong><strong> I am not seen as physically attractive by others. I have had a few partners in my life, though I didn’t settle </strong><strong> with any of them. Recently, I concluded that I would be unlikely to make another close relationship and have </strong><strong>focused</strong><strong> on making a good life for myself</strong><strong>.</strong></p><p><strong>I have since looked back over my life and re-evaluated many seemingly small experiences that </strong><strong>affected me badly</strong><strong>, such as a singing course on which one girl received a huge amount of attention from the leader. </strong><strong>Late in the course, he was shocked to find </strong><strong>that I have a good singing voice. </strong><strong>As a not-attractive woman, it is </strong><strong>harder to be heard. I </strong><strong>wonder</strong><strong> how different my life might have been if I had been better looking.</strong></p> <a href="https://www.theguardian.com/lifeandstyle/2020/nov/13/not-attractive-to-others-would-life-be-better-if-i-made-more-effort">Continue reading...</a>

## 'Charles is very stylish': how The Crown's costume designer brought 1980s to life
 - [https://www.theguardian.com/tv-and-radio/2020/nov/13/the-crown-netflix-costumes-outfits-1980s](https://www.theguardian.com/tv-and-radio/2020/nov/13/the-crown-netflix-costumes-outfits-1980s)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 14:38:52+00:00

<p>Season 4’s wardrobe includes Diana’s Cinderella dress and Thatcher’s power shoulders</p><p>With its power bouffants, sweetie-wrapper party dresses and alarming shoulder pads, some call the 1980s the time that fashion forgot. But in the fourth season of The Crown, which starts on TV tomorrow night, the era’s extraordinary clothing plays a pivotal role in bringing the decade’s stories back to vivid life. Some looks were faithfully recreated, while others were more loosely inspired by the actual wardrobes of the royal family, as the show’s costume designer, Amy Roberts, explains below.</p> <a href="https://www.theguardian.com/tv-and-radio/2020/nov/13/the-crown-netflix-costumes-outfits-1980s">Continue reading...</a>

## France marks five years since Paris attacks with silent ceremonies
 - [https://www.theguardian.com/world/2020/nov/13/france-marks-five-years-since-paris-terrorist-attacks-bataclan](https://www.theguardian.com/world/2020/nov/13/france-marks-five-years-since-paris-terrorist-attacks-bataclan)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 14:38:43+00:00

<p>French PM and mayor of Paris attend events held at Bataclan and other sites targeted by gunmen and suicide bombers</p><p>France has marked five years to the day since terrorists carried out a series of coordinated terrorist attacks across Paris, killing 130 people.</p><p>The prime minister, Jean Castex, and the mayor of Paris, Anne Hidalgo, carried out a series of silent ceremonies at each of the sites where the gunmen and suicide bombers loyal to Islamic State struck on 13 November 2015.</p> <a href="https://www.theguardian.com/world/2020/nov/13/france-marks-five-years-since-paris-terrorist-attacks-bataclan">Continue reading...</a>

## So goodbye, Barnard Castle Spice. Looking forward to your solo material | Marina Hyde
 - [https://www.theguardian.com/commentisfree/2020/nov/13/dominic-cummings-barnard-castle-brexit](https://www.theguardian.com/commentisfree/2020/nov/13/dominic-cummings-barnard-castle-brexit)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 14:26:32+00:00

<p>Dominic Cummings is leaving the band. But that was always the plan – nothing to do with the impending Brexit endgame<br /></p><p>Is it bigger than Geri leaving the Spice Girls? Don’t be ridiculous. There are, however, similarities with the scheduled <a href="https://www.theguardian.com/politics/2020/nov/13/tory-mps-hail-dominic-cummings-departure-and-look-for-reset">departure of Dominic Cummings</a> from Downing Street. <a href="https://www.nme.com/news/music/i-was-being-a-brat-spice-girls-geri-horner-sorry-for-quitting-the-band-in-1998-2509633">As Geri put it</a> in an address to fans 21 years after the event: “I need to say something I should have said a long time ago: I’m sorry – I was just being a brat.”</p><p> <span>Related: </span><a href="https://www.theguardian.com/politics/2020/nov/13/tory-mps-hail-dominic-cummings-departure-and-look-for-reset">Tory MPs hail Dominic Cummings' departure and look for 'reset'</a> </p> <a href="https://www.theguardian.com/commentisfree/2020/nov/13/dominic-cummings-barnard-castle-brexit">Continue reading...</a>

## Viral video of ballerina with Alzheimer's shows vital role of music in memory
 - [https://www.theguardian.com/stage/2020/nov/13/viral-video-of-ballerina-with-alzheimers-shows-vital-role-of-music-in-memory](https://www.theguardian.com/stage/2020/nov/13/viral-video-of-ballerina-with-alzheimers-shows-vital-role-of-music-in-memory)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 14:19:32+00:00

<p>Music’s primal power for those living with dementia has inspired thousands of YouTube views for a clip of a former dancer</p><p>We see a frail and elderly woman in a chair, her eyes downcast. She motions for the music to be turned up, a swelling melody from Tchaikovsky’s Swan Lake, and with a little encouragement her hands begin to flutter. Then suddenly her eyes flash and she’s Odette the swan queen at the misty lakeside, arms raised. She leans forward, wrists crossed in classic swan pose; her chin lifts as if she’s commanding the stage once more, her face lost in reverie.</p><p>The woman in the film is Marta Cinta González Saldaña, a former ballet dancer who died in 2019, the year the video was shot. But the clip has gone viral since being posted recently by Spanish organisation <a href="https://www.musicaparadespertar.com/">Música Para Despertar</a> (Music to Awaken), which promotes the value of music for those living with Alzheimer’s. Many of the details accompanying the video on its journey around the internet have been erroneous. Marta Cinta was not a member of the “New York Ballet” (there’s no such company) or the actual New York City Ballet, but seems to have run her own dance company in the city; the ballerina performing in the intercut video is not her but Ulyana Lopatkina, who is not even dancing Swan Lake but Mikhail Fokine’s The Dying Swan. Yet none of that takes away the impact of watching someone seemingly light up and have their memories unlocked by the power of melody. It’s as if you’re seeing Saldaña inhabit her true self.</p> <a href="https://www.theguardian.com/stage/2020/nov/13/viral-video-of-ballerina-with-alzheimers-shows-vital-role-of-music-in-memory">Continue reading...</a>

## Covent Garden comeback: the Royal Ballet on stage – in pictures
 - [https://www.theguardian.com/stage/gallery/2020/nov/13/the-royal-ballet-live-within-the-golden-hour-in-pictures](https://www.theguardian.com/stage/gallery/2020/nov/13/the-royal-ballet-live-within-the-golden-hour-in-pictures)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 14:01:55+00:00

<p>England’s theatres are closed but ballet is back at the Royal Opera House for online audiences with a new <a href="https://stream.roh.org.uk/packages/the-royal-ballet-live-within-the-golden-hour/videos/the-royal-ballet-live-within-the-golden-hour?_ga=2.226035929.278599030.1605271329-787393456.1587373663">streamed performance</a>, Live – Within the Golden Hour. Tristram Kenton was granted access</p> <a href="https://www.theguardian.com/stage/gallery/2020/nov/13/the-royal-ballet-live-within-the-golden-hour-in-pictures">Continue reading...</a>

## The long game: the race for a vaccine against all coronaviruses
 - [https://www.theguardian.com/world/2020/nov/13/the-mutation-game-the-race-for-a-vaccine-against-all-coronaviruses](https://www.theguardian.com/world/2020/nov/13/the-mutation-game-the-race-for-a-vaccine-against-all-coronaviruses)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 13:43:40+00:00

<p>There is hope that Covid-19 immunisation might soon be a reality, but some scientists are aiming for a broader solution</p><ul><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>Hopes have been raised worldwide this week that a Covid-19 vaccine is getting closer, after one version was shown to be 90% effective in reducing disease symptoms, but a handful of scientists are working on an ambitious plan for a different sort of vaccine.</p><p>Their project, which is fraught with technical and financial challenges, is to find a vaccine that could protect against not just Covid, but other viruses in the same family that cause Sars, Mers and the common cold.</p> <a href="https://www.theguardian.com/world/2020/nov/13/the-mutation-game-the-race-for-a-vaccine-against-all-coronaviruses">Continue reading...</a>

## Mince pies to Boxing Day curry: 10 Christmas dishes that butter makes better
 - [https://www.theguardian.com/for-the-love-of-butter/2020/nov/13/mince-pies-to-boxing-day-curry-10-christmas-dishes-that-butter-makes-better](https://www.theguardian.com/for-the-love-of-butter/2020/nov/13/mince-pies-to-boxing-day-curry-10-christmas-dishes-that-butter-makes-better)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 13:41:03+00:00

<p>Want your turkey to be tastefully tender and your hot spiced rum sublime? All you need is a dollop of butter to make your festive dishes shine</p><p>The American TV cook Julia Child adored cooking with butter and once told viewers: “With enough butter, anything is good.” Today, how many of us would venture to disagree? There really are few foods, sweet or savoury, that aren’t vastly improved by a dollop, a dash or a swirl, and watching this most luscious of ingredients melt into a pool of gold atop your Christmas Day veg is one of the most satisfying sights on Earth.</p><p>The festive season is the perfect time to ramp up your cooking efforts, and adding just the right amount of butter to some of your most mouthwatering treats can elevate them to perfection. We’ve discovered 10 Christmas favourites that can be made even more delicious with a bit more butter, so grab a napkin and tuck in ...</p> <a href="https://www.theguardian.com/for-the-love-of-butter/2020/nov/13/mince-pies-to-boxing-day-curry-10-christmas-dishes-that-butter-makes-better">Continue reading...</a>

## A shadow pyramid and 6,000 geese: Friday's best photos
 - [https://www.theguardian.com/news/gallery/2020/nov/13/a-shadow-pyramid-and-six-thousand-geese-fridays-best-photos](https://www.theguardian.com/news/gallery/2020/nov/13/a-shadow-pyramid-and-six-thousand-geese-fridays-best-photos)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 13:19:13+00:00

<p>The Guardian’s picture editors select highlights from around the world</p> <a href="https://www.theguardian.com/news/gallery/2020/nov/13/a-shadow-pyramid-and-six-thousand-geese-fridays-best-photos">Continue reading...</a>

## ‘I'm always falling in love with fabulous women’: Sandi Toksvig's forgotten heroines
 - [https://www.theguardian.com/lifeandstyle/2020/nov/13/im-always-falling-in-love-with-fabulous-women-sandi-toksvigs-forgotten-heroines](https://www.theguardian.com/lifeandstyle/2020/nov/13/im-always-falling-in-love-with-fabulous-women-sandi-toksvigs-forgotten-heroines)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 13:04:09+00:00

<p>From Madame Ching, a 19th-century pirate who ruled the South China Sea, to Anna Hedgeman, who helped to organise 1963’s Great March on Washington, it’s time to celebrate these often-overlooked yet awesome characters</p><p>My desk is littered with dead women, which makes me sound like the world’s untidiest serial killer. Let me start again. I collect women. OK, that may be worse – it makes them sound like ceramic thimbles. Let’s see … I read a lot – mostly history – and every time I find a fabulous woman from the past whose story was hitherto unknown to me, I gather her up to keep in scribbled notes. I do this selflessly, because the risk to my health is enormous.</p><p>In 1791, the German theologian Karl Gottfried Bauer wrote: <em>“</em>The lack of all physical movement while reading, combined with the forcible alternation of imagination and emotion [leads to] slackness, mucous congestion, flatulence and constipation of the inner organs, which, as is well known, particularly in the female sex, actually affects the sexual parts.”</p> <a href="https://www.theguardian.com/lifeandstyle/2020/nov/13/im-always-falling-in-love-with-fabulous-women-sandi-toksvigs-forgotten-heroines">Continue reading...</a>

## Igniting girls' interest in chess may be great legacy of The Queen's Gambit
 - [https://www.theguardian.com/sport/2020/nov/13/igniting-girls-interest-in-chess-may-be-great-legacy-of-the-queens-gambit](https://www.theguardian.com/sport/2020/nov/13/igniting-girls-interest-in-chess-may-be-great-legacy-of-the-queens-gambit)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 13:00:17+00:00

<p>Female chess champions say Netflix series captures the feeling of the male-dominated sport </p><p>For Jovanka Houska, chess professional and Britain’s reigning women’s champion, the emotion reflected in the new Nexflix drama <a href="https://www.theguardian.com/tv-and-radio/2020/oct/23/the-queens-gambit-review-chess-anya-taylor-joy-walter-tevis-netflix">The Queen’s Gambit</a> perfectly captures the international world of the game.</p><p>Houska, 40, an international master, female grandmaster, nine-times winner of the British Women’s Chess Championship, and who was a child prodigy growing up in south London, believes “the emotion of how a player feels has been done brilliantly”, those moments “when someone outclasses you, and you really feel the pain.” She adds the settings chime too, “from the most glamorous location in one tournament to a school gymnasium in another”.</p> <a href="https://www.theguardian.com/sport/2020/nov/13/igniting-girls-interest-in-chess-may-be-great-legacy-of-the-queens-gambit">Continue reading...</a>

## Return of a ramen pioneer gives boost to Japan's Covid-hit restaurant sector
 - [https://www.theguardian.com/world/2020/nov/13/return-of-a-ramen-pioneer-gives-boost-to-japans-covid-hit-restaurant-sector](https://www.theguardian.com/world/2020/nov/13/return-of-a-ramen-pioneer-gives-boost-to-japans-covid-hit-restaurant-sector)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 12:55:36+00:00

<p>Rai Rai Ken is back in business in Tokyo but pandemic has taken a heavy toll on ramen shops</p><ul><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>More than a century after it welcomed its first ravenous customers in downtown Tokyo, Rai Rai Ken is back in business. On a recent afternoon, diners at its new premises in the bowels of the <a href="https://www.raumen.co.jp/english/">Shin-Yokohama Ramen Museum</a> barely looked up as they demolished servings of noodles made according to the restaurant’s original recipe.</p><p>Rai Rai Ken is unlikely to recapture its heyday, when specially hired Chinese chefs served up to 3,000 customers a day in Tokyo’s Asakusa district. But its reappearance last month, albeit away from the cut and thrust of the high street, was a rare piece of good news for Japan’s Covid-hit restaurant sector.</p> <a href="https://www.theguardian.com/world/2020/nov/13/return-of-a-ramen-pioneer-gives-boost-to-japans-covid-hit-restaurant-sector">Continue reading...</a>

## Joe Wicks completes 24-hour workout for BBC Children in Need
 - [https://www.theguardian.com/tv-and-radio/2020/nov/13/joe-wicks-completes-24-hour-workout-for-bbc-children-in-need](https://www.theguardian.com/tv-and-radio/2020/nov/13/joe-wicks-completes-24-hour-workout-for-bbc-children-in-need)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 12:53:35+00:00

<p>Fitness coach raised more than £1.5m in live event featuring celebrities and schoolchildren</p><p>The fitness coach <a href="https://www.theguardian.com/lifeandstyle/2016/jun/18/joe-wicks-meet-body-coach-million-dollar-muscles">Joe Wicks</a> completed a 24-hour live workout accompanied virtually by celebrities and schoolchildren to raise more than £1.5m for BBC Children in Need, completing his marathon by saying he was now “off to bed”.</p><p>His interactive <a href="https://www.bbc.co.uk/events/ebn84f/live/cg3g9r">Joe Wicks 24-hour PE Challenge</a> saw stars including <a href="https://www.theguardian.com/tv-and-radio/louis-theroux">Louis Theroux</a>, <a href="https://www.theguardian.com/music/melanie-c">Melanie C</a>, <a href="https://www.theguardian.com/music/sam-smith">Sam Smith</a> and <a href="https://www.theguardian.com/sport/kelly-holmes">Dame Kelly Holmes</a> join in as Wicks, AKA The Body Coach, completed a range of activities, from cycling to yoga, boxing to rowing and his signature HIIT (high intensity) workouts.</p> <a href="https://www.theguardian.com/tv-and-radio/2020/nov/13/joe-wicks-completes-24-hour-workout-for-bbc-children-in-need">Continue reading...</a>

## FTSE 100 records best week since April as Covid vaccine triggers hopes for economy
 - [https://www.theguardian.com/business/2020/nov/13/ftse-100-set-for-best-week-since-april-amid-hopes-covid-vaccine](https://www.theguardian.com/business/2020/nov/13/ftse-100-set-for-best-week-since-april-amid-hopes-covid-vaccine)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 12:50:09+00:00

<p>Index of leading UK companies ends week 7% up after Pfizer/BioNTech announcement</p><ul><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>The FTSE 100 has recorded its strongest week since April amid rising hopes that a coronavirus vaccine can trigger a faster economic revival from the pandemic than first anticipated.</p><p>The index of leading UK company shares ended the week more than 300 points higher at 6,316, a rise of about 7%, despite a modest dip on Friday as City investors bet it would still take time to deploy the vaccine and for Britain’s economy to stage a full recovery.</p> <a href="https://www.theguardian.com/business/2020/nov/13/ftse-100-set-for-best-week-since-april-amid-hopes-covid-vaccine">Continue reading...</a>

## Covid cases in prisons in England and Wales double in October
 - [https://www.theguardian.com/society/2020/nov/13/covid-cases-in-prisons-in-england-and-wales-double-in-october](https://www.theguardian.com/society/2020/nov/13/covid-cases-in-prisons-in-england-and-wales-double-in-october)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 12:43:06+00:00

<p>MoJ figures show rise of 883 in a month, compared with increase of 80 in September</p><ul><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>The number of prisoners who have tested positive for coronavirus in England and Wales since the start of the pandemic more than doubled in the space of a month in October, figures reveal.</p><p>At the end of October, 1,529 prisoners had tested positive for Covid-19 since March, an increase of 883 on the September figure, Ministry of Justice (MoJ) figures show. The MoJ has been testing all symptomatic prisoners since April.</p> <a href="https://www.theguardian.com/society/2020/nov/13/covid-cases-in-prisons-in-england-and-wales-double-in-october">Continue reading...</a>

## Tesco says sorry over online Christmas delivery queues
 - [https://www.theguardian.com/business/2020/nov/13/tesco-says-sorry-over-online-christmas-delivery-queues](https://www.theguardian.com/business/2020/nov/13/tesco-says-sorry-over-online-christmas-delivery-queues)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 12:37:10+00:00

<p>Huge demand for delivery pass service forced shoppers to wait for hours to secure festive slot</p><p><a href="https://www.theguardian.com/business/tesco">Tesco </a>has apologised after its grocery website was overwhelmed with shoppers trying to book delivery slots for Christmas.</p><p>Customers complained they had been forced to join an online queue for hours on Friday morning after Tesco opened bookings for Christmas week for shoppers who had signed up to the supermarket’s delivery subscription service.</p> <a href="https://www.theguardian.com/business/2020/nov/13/tesco-says-sorry-over-online-christmas-delivery-queues">Continue reading...</a>

## 'I can't fail Mary': the bereaved man fighting for pregnant women threatened by Covid
 - [https://www.theguardian.com/world/2020/nov/13/mary-agyeiwaa-agyapong-bereaved-ernest-boateng-pregnant-women-covid](https://www.theguardian.com/world/2020/nov/13/mary-agyeiwaa-agyapong-bereaved-ernest-boateng-pregnant-women-covid)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 12:01:56+00:00

<p>Ernest Boateng’s wife, Mary Agyeiwaa Agyapong, died shortly after the birth of their second child</p><ul><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>Before the pandemic struck, Ernest Boateng and his wife, Mary Agyeiwaa Agyapong, were planning for the future. She was expecting their second child and – after her maternity leave – wanted to become a specialist diabetes nurse; he hoped to join the RAF.</p><p>But as the coronavirus tore through the UK, Agyeiwaa Agyapong became ill. On 7 April she was admitted to Luton and Dunstable university hospital, where she had been working as a nurse until signed off with shortness of breath. She tested positive for coronavirus and was taken to theatre for an emergency caesarean. Her baby, five weeks early, was born alive. But after five days in intensive care, the 28-year-old died. Boateng was alone, with a premature daughter and two-year-old son to look after.</p> <a href="https://www.theguardian.com/world/2020/nov/13/mary-agyeiwaa-agyapong-bereaved-ernest-boateng-pregnant-women-covid">Continue reading...</a>

## What does it mean to be a man? Guardian readers respond
 - [https://www.theguardian.com/lifeandstyle/2020/nov/13/what-does-it-mean-to-be-a-man-reader-responses](https://www.theguardian.com/lifeandstyle/2020/nov/13/what-does-it-mean-to-be-a-man-reader-responses)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 12:00:16+00:00

<p>Our series <a href="https://www.theguardian.com/us-news/series/the-state-of-men">The State Of Men</a> asked hard questions about modern masculinity. Our readers pitch in with their own analysis</p><p>My identity as a man is centered around my family. I have done my best to love, support and provide for them and feel that I did a pretty good job even when faced with hardships. I believe that respecting others, doing the right thing, and a hint of altruism is essential to being a decent man.</p><p> <span>Related: </span><a href="https://www.theguardian.com/us-news/2020/oct/20/leaving-my-perfect-male-body-in-the-past">I had the best body I've ever had – so why did I feel so much shame?</a> </p> <a href="https://www.theguardian.com/lifeandstyle/2020/nov/13/what-does-it-mean-to-be-a-man-reader-responses">Continue reading...</a>

## Pause and breathe: how I learned to meditate with TikTok
 - [https://www.theguardian.com/fast-master/2020/nov/13/pause-and-breathe-how-i-learned-to-meditate-with-tiktok](https://www.theguardian.com/fast-master/2020/nov/13/pause-and-breathe-how-i-learned-to-meditate-with-tiktok)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 11:12:05+00:00

<p>Are you finding it hard to switch off and relax? Short and snappy mindfulness videos were just the thing to help me refocus</p><p>Things I’m good at: multitasking, overcommitting, starting things and not finishing them. Watching Netflix while listening to a podcast while cooking dinner while messaging a friend, while skim-reading an important article.</p><p>Things I’m not good at: silence, boredom, focusing on the present, being alone with my thoughts. And so, by extension, meditation.</p> <a href="https://www.theguardian.com/fast-master/2020/nov/13/pause-and-breathe-how-i-learned-to-meditate-with-tiktok">Continue reading...</a>

## Can TikTok help me teach old cats new tricks?
 - [https://www.theguardian.com/fast-master/2020/nov/13/can-tiktok-help-me-teach-old-cats-new-tricks](https://www.theguardian.com/fast-master/2020/nov/13/can-tiktok-help-me-teach-old-cats-new-tricks)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 11:09:21+00:00

<p>After attempting to train my stubborn moggies to no avail, these 20-second tutorials had my pets following my orders in no time</p><p>People think that cats can’t be trained. They’re wrong. Through careful coaxing and iron patience, I have drilled my cats to stop taking bites out of my mashed potato. They no longer wake me up at the crack of dawn by leaping on to my face. And thanks to my persistence, they are regular, enthusiastic users of the cat flap. Particularly at night when it’s locked and they bash their paws against it like amateur feline bongoists.</p><p>But this is where my cat-training prowess plateaued – I couldn’t manage to take things to the next level. I did buy a tedious 700-page book that promised feats such as teaching your moggy to sit. I tried random websites’ impressive-sounding tutorials on high-fiving, vaulting and convincing cats to happily don a harness and be walked like a dog. But, invariably, my cats would stray from the plan and I’d be left scouring 800 words of text for a solution. What did my efforts actually teach them? That there’s no better time to steal snacks than when your confuddled owner is staring at his or her phone or into a book. So I gave up.</p> <a href="https://www.theguardian.com/fast-master/2020/nov/13/can-tiktok-help-me-teach-old-cats-new-tricks">Continue reading...</a>

## Tiny Atlantic island takes giant leap towards protecting world's oceans
 - [https://www.theguardian.com/environment/2020/nov/13/tiny-atlantic-island-takes-giant-leap-towards-protecting-worlds-oceans](https://www.theguardian.com/environment/2020/nov/13/tiny-atlantic-island-takes-giant-leap-towards-protecting-worlds-oceans)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 11:03:01+00:00

<p>UK overseas territory Tristan da Cunha’s new marine protected area will be fourth largest sanctuary of its kind</p><p>A community of 250 people on one of the most remote inhabited islands on Earth has made a significant contribution to marine wildlife conservation by banning bottom-trawling fishing, deep-sea mining and other harmful activities from its waters.</p><p>The government of Tristan da Cunha, a volcanic archipelago in the south Atlantic and part of the UK’s overseas territories, has announced that almost 700,000 sq km of its waters will become a marine protected area (MPA), the fourth largest such sanctuary in the world.</p> <a href="https://www.theguardian.com/environment/2020/nov/13/tiny-atlantic-island-takes-giant-leap-towards-protecting-worlds-oceans">Continue reading...</a>

## Rishi Sunak urges Hindus to stick to lockdown rules at Diwali
 - [https://www.theguardian.com/lifeandstyle/2020/nov/13/rishi-sunak-hindus-lockdown-rules-diwali](https://www.theguardian.com/lifeandstyle/2020/nov/13/rishi-sunak-hindus-lockdown-rules-diwali)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 10:32:45+00:00

<p>UK chancellor says celebration will be difficult as he lights oil lamps outside No 11</p><ul><li><a href="https://www.theguardian.com/world/series/coronavirus-live/latest">Coronavirus – latest updates</a></li><li><a href="https://www.theguardian.com/world/coronavirus-outbreak">See all our coronavirus coverage</a></li></ul><p>The UK chancellor, <a href="https://www.theguardian.com/politics/2020/nov/06/rishi-sunak-recession-fears-and-rivalries-take-the-shine-off">Rishi Sunak</a>, has urged fellow Hindus to “follow the rules” during Diwali as he lit small clay oil lamps on the doorstep of his official residence at 11 Downing Street to mark the beginning of the five-day festival of lights.</p><p>Diwali, which began on Thursday, is celebrated by millions of Hindus, Sikhs and Jains across the world. Lamps and candles are lit in doors and windows of homes and temples, and the holiday usually features firework displays. The main day of the festival is Saturday.</p> <a href="https://www.theguardian.com/lifeandstyle/2020/nov/13/rishi-sunak-hindus-lockdown-rules-diwali">Continue reading...</a>

## Is the new Covid vaccine our way back to normality? - video explainer
 - [https://www.theguardian.com/society/video/2020/nov/13/is-the-new-covid-vaccine-our-way-back-to-normality-video-explainer](https://www.theguardian.com/society/video/2020/nov/13/is-the-new-covid-vaccine-our-way-back-to-normality-video-explainer)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 10:09:02+00:00

<p>The news this week that the Pfizer/BioNTech Covid-19 vaccine was effective on&nbsp;<a href="https://www.theguardian.com/world/2020/nov/09/covid-19-vaccine-candidate-effective-pfizer-biontech">more than 90%</a>&nbsp;of trial recipients is of huge importance. The efficacy is significantly higher than hoped for and so far there appear to be no safety concerns.</p><p>The Guardian's health editor, Sarah Boseley, explains that, while this is a major breakthrough, there are still several hurdles to overcome, and restrictions, such as wearing masks, social distancing and remote working, must remain in place for the time being</p><ul><li><a href="https://www.theguardian.com/world/ng-interactive/2020/nov/10/covid-vaccine-tracker-when-will-a-coronavirus-vaccine-be-ready">Covid vaccine tracker: when will a treatment be ready?<br /></a></li><li><a href="https://www.theguardian.com/world/video/2020/oct/16/coronavirus-what-has-changed-covid-19-video-explainer">Coronavirus: what has changed about what we know? –&nbsp;video explainer</a><br /></li></ul> <a href="https://www.theguardian.com/society/video/2020/nov/13/is-the-new-covid-vaccine-our-way-back-to-normality-video-explainer">Continue reading...</a>

## 'Sex is not a crime': the women protesting Poland's new abortion law
 - [https://www.theguardian.com/world/video/2020/nov/13/sex-is-not-a-the-women-protesting-polands-new-abortion-law](https://www.theguardian.com/world/video/2020/nov/13/sex-is-not-a-the-women-protesting-polands-new-abortion-law)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 10:08:48+00:00

<p>As Poland attempts to pass a new abortion law that amounts to a near-total ban on terminations, including in cases where a baby is sure to die soon after birth, the country's biggest protests in four decades have erupted, with Polish women challenging church as well as state. Karolina Więckiewicz is a lawyer with the charity Abortion Without Borders, which advises Polish women on abortions and helps them to avail of safe, legal procedures overseas. We follow her on to the streets as women of all ages rise up to demand rights over their own bodies, and an end to social stigma around sex and abortion</p> <a href="https://www.theguardian.com/world/video/2020/nov/13/sex-is-not-a-the-women-protesting-polands-new-abortion-law">Continue reading...</a>

## At-home meal kits: the gift of your favourite restaurant during lockdown | Grace Dent
 - [https://www.theguardian.com/food/2020/nov/13/the-gift-of-your-favourite-restaurant-grace-dent-finish-at-home-meal-kits](https://www.theguardian.com/food/2020/nov/13/the-gift-of-your-favourite-restaurant-grace-dent-finish-at-home-meal-kits)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 10:00:14+00:00

<p>‘These boxes are like an emergency delivery of happiness’</p><p>Left completely to my own culinary devices during Lockdown 1.0, I forlornly accepted that, despite my collection of recipe books that threatens one day to topple and half-kill me, my kitchen routine revolves around the same four or so recipes, two of them featuring pasta bow-ties in some sort of slippery sauce. I may once have been a ferocious screen-grabber of recipes, saved to make “when there’s more time”, but what March-August 2020 taught me was that no amount of languorous house arrest would see me acquiring, scraping and braising my own artichokes, or fashioning a beurre noisette at 6pm, after I’d spent the day waving a Wi-Fi router in the air and mooing like a cow.</p> <a href="https://www.theguardian.com/food/2020/nov/13/the-gift-of-your-favourite-restaurant-grace-dent-finish-at-home-meal-kits">Continue reading...</a>

## Experience: my parachute failed
 - [https://www.theguardian.com/lifeandstyle/2020/nov/13/experience-my-parachute-failed](https://www.theguardian.com/lifeandstyle/2020/nov/13/experience-my-parachute-failed)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 10:00:14+00:00

<p>The ground was getting closer; we were meant to be slowing down, but still we hurtled at full speed</p><p>Standing on the edge of the plane’s cabin, looking out at the ground below, my tandem skydiving instructor, Bill, turned to face me. He had a GoPro strapped to him, there to capture every moment for the souvenir DVD. “Do you have any last words?” he asked. “Yes,” I said, joking. “I hope my parachute opens.”</p><p>We’d taken off from Lilydale airfield on the edge of Melbourne only 15 minutes earlier. It was 25C, not a cloud in the sky: the conditions for jumping from a plane at 15,000ft could not have been better. I got butterflies as I prepared to throw myself into thin air (it was my first skydive, given to me as a 22nd birthday present in 2013) but I had no regrets. I’d never felt more alive as Bill and I, strapped together, stepped out and started our freefall.</p> <a href="https://www.theguardian.com/lifeandstyle/2020/nov/13/experience-my-parachute-failed">Continue reading...</a>

## World heritage status for Scottish peat bogs could help UK hit net zero goals
 - [https://www.theguardian.com/environment/2020/nov/13/world-heritage-status-for-scottish-peat-bogs-could-help-uk-hit-net-zero-goals](https://www.theguardian.com/environment/2020/nov/13/world-heritage-status-for-scottish-peat-bogs-could-help-uk-hit-net-zero-goals)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 10:00:13+00:00

<p>Hopes rise that the Flow Country, the world’s largest carbon store, could become first peatland to win the status</p><p>Andrew Coupar has crouched down by a small pool, its surface peppered with the small stalks of bogbean. In autumn its dark green oval leaves echo the muted browns, greens and ochres of the surrounding peatland.</p><p>In spring, however, the bogbean’s pink-fringed white flowers put on a remarkable display, carpeting the cluster of pools that mirror the blue skies and light clouds above and, along the horizon to west, the mountains of Sutherland.</p> <a href="https://www.theguardian.com/environment/2020/nov/13/world-heritage-status-for-scottish-peat-bogs-could-help-uk-hit-net-zero-goals">Continue reading...</a>

## New Order frontman Bernard Sumner recovering from coronavirus
 - [https://www.theguardian.com/music/2020/nov/13/new-order-frontman-bernard-sumner-recovering-from-coronavirus](https://www.theguardian.com/music/2020/nov/13/new-order-frontman-bernard-sumner-recovering-from-coronavirus)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 09:32:37+00:00

<p>Singer says he is still experiencing mild symptoms after contracting virus three weeks ago</p><p>New Order frontman Bernard Sumner has said he is recovering from coronavirus. <a href="https://youtu.be/rkUMRw-dg2o">Speaking to Minnesota radio station The Current</a>, he said he caught it three weeks ago, and was still experiencing mild symptoms, including a loss of sense of smell. “I was one of the lucky ones, I didn’t get it too bad,” he said, adding:</p><p>I felt I had a little bit of a temperature, but not much. I had it for four days, it went away for four days, and then it came back for four days. When it came back, it was more severe, but still not too bad. I just felt extreme fatigue, like a really bad hangover. Then it went away, and I’m OK. But I’ve heard horror stories over here [in the UK] about it. A couple of people know people who’ve died from it … It seems like Russian roulette. Like, you can get light symptoms, like me, or it can kill you. It’s crazy.</p> <a href="https://www.theguardian.com/music/2020/nov/13/new-order-frontman-bernard-sumner-recovering-from-coronavirus">Continue reading...</a>

## Tangled sharks and reefs under nets – 2020's most powerful ocean photos
 - [https://www.theguardian.com/environment/gallery/2020/nov/13/tangled-sharks-and-reefs-under-nets-2020s-most-powerful-ocean-photos](https://www.theguardian.com/environment/gallery/2020/nov/13/tangled-sharks-and-reefs-under-nets-2020s-most-powerful-ocean-photos)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 09:30:13+00:00

<p>From fishing gear to shrinking ice – finalists in the conservation category of the inaugural <a href="http://www.oceanphotographyawards.com">Ocean Photography Awards</a> focused on the destructive impact of humans on the sea. The winner will be announced on 19 November</p> <a href="https://www.theguardian.com/environment/gallery/2020/nov/13/tangled-sharks-and-reefs-under-nets-2020s-most-powerful-ocean-photos">Continue reading...</a>

## UKRI funded students: how have you been affected by Covid-19?
 - [https://www.theguardian.com/education/2020/nov/13/ukri-funded-students-how-have-you-been-affected-by-covid-19](https://www.theguardian.com/education/2020/nov/13/ukri-funded-students-how-have-you-been-affected-by-covid-19)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 08:53:27+00:00

<p>We would like to hear from doctoral students funded by UK Research and Innovation on their experiences</p><p>Doctoral students who are funded by UK Research and Innovation have been told to <a href="https://www.ukri.org/news/doctoral-students-advised-to-adjust-projects-for-covid-19/">“adjust their projects”</a> to complete their research within the original time-frame, despite some calling for extensions or additional funding.</p><p>We would like to hear from those whose research has been affected due to the pandemic, and what their plans are for the future. </p> <a href="https://www.theguardian.com/education/2020/nov/13/ukri-funded-students-how-have-you-been-affected-by-covid-19">Continue reading...</a>

## Before they were famous, part two: stars' early stage roles – in pictures
 - [https://www.theguardian.com/stage/gallery/2020/nov/13/stars-before-they-were-famous-in-pictures-rachel-weisz-damian-lewis-daniel-kaluuya](https://www.theguardian.com/stage/gallery/2020/nov/13/stars-before-they-were-famous-in-pictures-rachel-weisz-damian-lewis-daniel-kaluuya)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 08:33:28+00:00

<p>Tristram Kenton’s archive reveals more performers heading for the big time, including Rachel Weisz, Idris Elba, Daniel Kaluuya and Felicity Jones</p><p><a href="https://www.theguardian.com/stage/gallery/2020/nov/11/before-they-were-famous-stars-tristram-kenton-at-the-guardian-in-pictures">Part one: Andrew Scott, John Boyega, Emily Blunt and many more</a></p> <a href="https://www.theguardian.com/stage/gallery/2020/nov/13/stars-before-they-were-famous-in-pictures-rachel-weisz-damian-lewis-daniel-kaluuya">Continue reading...</a>

## Special adviser sacked by Dominic Cummings to receive payoff
 - [https://www.theguardian.com/politics/2020/nov/13/special-adviser-sacked-by-dominic-cummings-to-receive-payoff](https://www.theguardian.com/politics/2020/nov/13/special-adviser-sacked-by-dominic-cummings-to-receive-payoff)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 06:52:29+00:00

<p>Sonia Khan’s claim of unfair dismissal settled shortly before hearing in move that will be seen as protecting PM’s adviser<br /></p><p>A special adviser who was escorted out of Downing Street by police on the orders of Dominic Cummings has been given a five-figure payoff by the government.</p><p><a href="https://www.theguardian.com/politics/2019/sep/01/adviser-sacked-by-cummings-may-have-case-for-unfair-dismissal-expert">Sonia Khan</a>, a former adviser to the then chancellor, Sajid Javid, is expected to receive the substantial sum after arguing in legal papers that the behaviour of Boris Johnson’s most senior aide was pivotal to her claim of sex discrimination.</p> <a href="https://www.theguardian.com/politics/2020/nov/13/special-adviser-sacked-by-dominic-cummings-to-receive-payoff">Continue reading...</a>

## Met police told 40% of recruits must be from BAME backgrounds
 - [https://www.theguardian.com/uk-news/2020/nov/13/met-police-told-40-of-recruits-must-be-from-bame-backgrounds](https://www.theguardian.com/uk-news/2020/nov/13/met-police-told-40-of-recruits-must-be-from-bame-backgrounds)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 06:00:09+00:00

<p>London mayor Sadiq Khan and police force agree target as part of major race action plan</p><p>Britain’s biggest police force must hire 40% of new recruits from ethnic minority backgrounds, while officers will have to justify stop and search to community panels under new plans designed to quell the race crisis engulfing Scotland Yard.</p><p>The Guardian has learned details of the new initiative on race and policing hammered out by London’s mayor and the Metropolitan police after months of negotiations.</p> <a href="https://www.theguardian.com/uk-news/2020/nov/13/met-police-told-40-of-recruits-must-be-from-bame-backgrounds">Continue reading...</a>

## 'It came in a locked box': UK Covid vaccine volunteers – in pictures
 - [https://www.theguardian.com/society/gallery/2020/nov/13/it-came-in-a-locked-box-uk-covid-vaccine-volunteers-in-pictures](https://www.theguardian.com/society/gallery/2020/nov/13/it-came-in-a-locked-box-uk-covid-vaccine-volunteers-in-pictures)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 06:00:08+00:00

<p>Thousands of ordinary people around Britain volunteered to take part in the Imperial College London coronavirus vaccine trial. Who are they, what motivated them to take part, and what’s it been like?<br /></p><ul><li>These portraits were taken for <a href="https://teamhalo.org/">Team Halo</a>, an initiative that goes behind the scenes with the scientists trying to develop a Covid vaccine</li></ul> <a href="https://www.theguardian.com/society/gallery/2020/nov/13/it-came-in-a-locked-box-uk-covid-vaccine-volunteers-in-pictures">Continue reading...</a>

## Ma Jun: China has started to 'walk the walk' on climate crisis
 - [https://www.theguardian.com/environment/2020/nov/13/ma-jun-china-is-beginning-to-walk-the-walk-on-climate-crisis-action-aoe](https://www.theguardian.com/environment/2020/nov/13/ma-jun-china-is-beginning-to-walk-the-walk-on-climate-crisis-action-aoe)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 05:00:08+00:00

<p>US dropped the environmental ball under Trump, but Biden victory means the two countries can work together for a green recovery, says campaigner</p><p>Ma Jun experienced a strange role reversal during Donald Trump’s presidency. Over more than two decades as one of China’s top environmental campaigners, American encouragement for Beijing to cut carbon emissions and temper the damage of rapid industrialisation had been part of the background music. Ma never imagined he would see the US renege on environmental commitments while China began to face up to the challenge.</p><p>“It’s been frustrating,” says Ma of the past four years as we speak on the phone, the bustle of Beijing audible in the background. “When it comes to environmental collaboration between the governments, it has been hard to do anything.”</p> <a href="https://www.theguardian.com/environment/2020/nov/13/ma-jun-china-is-beginning-to-walk-the-walk-on-climate-crisis-action-aoe">Continue reading...</a>

## Adrian Chiles on being diagnosed with ADD as an adult
 - [https://www.theguardian.com/news/audio/2020/nov/13/adrian-chiles-on-being-diagnosed-with-add-in-his-fifties](https://www.theguardian.com/news/audio/2020/nov/13/adrian-chiles-on-being-diagnosed-with-add-in-his-fifties)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2020-11-13 03:00:05+00:00

<p>A year ago, the broadcaster Adrian Chiles opened a book on attention deficit disorder (ADD). Suddenly the good, the bad and the mad bits of his life started to make sense. He describes the impact the diagnosis has had on his life</p><p>Four years ago, the broadcaster<strong> A</strong><strong>drian Chiles</strong> went to see a psychiatrist specialising in adult attention deficit hyperactivity disorder (ADHD), who concluded he probably had ADD – ADHD without the hyperactivity aspect. But it was only when he read a book about the condition three years later, and recognised so much of his behaviour on the pages - the inability to focus, the surges of adrenaline, the procrastination - that he went and got an official diagnosis. Chiles talks to <strong>Anushka Asthana </strong>about the impact the diagnosis has had on his life, and how it has made him reevaluate aspects of it. </p><p>Asthana also talks to <strong>Prof Susan Young, </strong>an expert in<strong> </strong>ADHD, which is defined as a clinically distinct neurobiological condition that is caused by an imbalance of chemicals affecting specific parts of the brain responsible for behaviour. She discusses how it manifests differently in children to adults, ways it can be treated and why it is so over-represented in the prison population. </p> <a href="https://www.theguardian.com/news/audio/2020/nov/13/adrian-chiles-on-being-diagnosed-with-add-in-his-fifties">Continue reading...</a>

