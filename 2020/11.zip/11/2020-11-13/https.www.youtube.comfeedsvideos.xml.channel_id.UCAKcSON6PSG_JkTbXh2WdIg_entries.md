# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Valerie June - three songs at The Current (2013; 2017)
 - [https://www.youtube.com/watch?v=aPtIXxCqDSQ](https://www.youtube.com/watch?v=aPtIXxCqDSQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-11-14 00:00:00+00:00

On Friday, Nov. 13, singer-songwriter Valerie June released a new three-song suite of music. Valerie June has visited our studio twice, and she opened Rock the Garden 2014. Watch three performances by Valerie June, recorded live in our studio in 2013 and in 2017. (The first video is in black and white at the artist's request.)

SONGS PERFORMED
0:00 "You Can't Be Told" (2013)
2:56 "Just In Time" (2017)
5:42 "Astral Plane" (2017)

PERSONNEL
Valerie June – guitar and vocals

CREDITS
Video & Photo: Nate Ryan; Leah Garaas
Audio: Craig Thorson; Michael DeMark
Production: Derrick Stevens; Anna Weggel

FIND MORE:
2013 studio session: https://www.thecurrent.org/feature/2013/08/11/valerie-june-performs-live-in-the-current-studios
2013 Guitar Collection interview: https://www.thecurrent.org/feature/2013/08/28/the-currents-guitar-collection-valerie-june
2017 studio session:
https://www.thecurrent.org/feature/2017/03/03/valerie-june-plays-songs-from-her-upcoming-album-the-order-of-time
2020 virtual session:
https://www.thecurrent.org/feature/2020/04/08/live-virtual-session-valerie-june
2020 new music from Valerie June:
https://www.thecurrent.org/feature/2020/11/13/listen-to-new-music-from-valerie-june 

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#valeriejune

