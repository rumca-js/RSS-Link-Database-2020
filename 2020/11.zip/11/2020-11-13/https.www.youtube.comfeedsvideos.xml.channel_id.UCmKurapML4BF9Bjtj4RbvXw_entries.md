# Source:The Piano Guys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmKurapML4BF9Bjtj4RbvXw, language:en-US

## Ed Sheeran - Thinking Out Loud - A.I. Learns to Play The Piano Guys in "AR PIANIST" APP
 - [https://www.youtube.com/watch?v=BIP_YvZe6IM](https://www.youtube.com/watch?v=BIP_YvZe6IM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmKurapML4BF9Bjtj4RbvXw
 - date published: 2020-11-13 00:00:00+00:00

► Listen on SPOTIFY: https://spoti.fi/2K455bn
► Listen on APPLE MUSIC: https://apple.co/36r4TdK
► Listen on AMAZON: https://amzn.to/3ltKyuq
► DOWNLOAD “AR Pianist” (For iOS & Android) https://shor.by/ThePianoGuys

► Get the SHEET MUSIC (now includes CHORD symbols): https://smarturl.it/TPG10_SheetMusic
► Get our NEWEST ALBUM "10" here: https://smarturl.it/TPG-Album-10

► Learn about our beliefs here: https://smarturl.it/TPG_Beliefs

Check out our Top 10 videos!
____________________________
A Thousand Years (Christina Perri) https://youtu.be/QgaTQ5-XfMM
Disney's Let It Go / Vivaldi's Winter (Frozen / Four Seasons)  https://youtu.be/6Dakd7EIgBE
Beethoven's 5 Secrets (5th Symphony / OneRepublic) https://youtu.be/mJ_fkw5j-t0
Titanium / Pavane (David Guetta / Faure) https://youtu.be/fz4MzJTeL0c
What Makes You Beautiful (One Direction) https://youtu.be/0VqTwnAuHws
Peponi / Paradise African Version (Coldplay) https://youtu.be/Cgovv8jWETM
Cello Wars (Star Wars) https://youtu.be/BgAlQuqzl8o
Fight Song / Amazing Grace - Scotland Castle Eilean Donan (Rachel Platten / John Newton) https://youtu.be/mOO5qRjVFLw
Story of My Life (One Direction) https://youtu.be/yET4p-r2TI8

Watch us play atop the Wonders of the World!
____________________________
Great Wall of China: https://youtu.be/NCaH-qqTWpk
Christ Redeemer: https://youtu.be/CHV6BjuQOZQ
Chichen Itza: https://youtu.be/O3cBZ5X-eGw
Petra: https://youtu.be/u2Yk1CEgc4g
(MORE to come)

Who are The Piano Guys?
https://thepianoguys.com/pages/about

