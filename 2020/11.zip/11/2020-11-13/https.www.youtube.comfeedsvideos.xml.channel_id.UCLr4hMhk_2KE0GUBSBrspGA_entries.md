# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Xbox w oparach - dymiący Xbox Series X
 - [https://www.youtube.com/watch?v=-HiAih9x5qU](https://www.youtube.com/watch?v=-HiAih9x5qU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-11-13 00:00:00+00:00

This vid has English subs. W związku z zadziwiająco jednostronnym przedstawieniem sprawy w przestrzeni publicznej, oddaję dziś głos Arkowi, którego dymiący Xbox przysporzył mu w ostatnich dniach zdecydowanie więcej przykrości niż radości z grania.
Wyłączyłem reklamy w tym filmie, żeby nie pozostawiać wątpliwości co do moich motywacji :)

