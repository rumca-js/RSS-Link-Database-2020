# Source:PostmodernJukebox, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg, language:en-US

## PMJ Pop-Up: Umbrella - Rihanna (Cover) ft. Casey Abrams
 - [https://www.youtube.com/watch?v=X944BcEFJ98](https://www.youtube.com/watch?v=X944BcEFJ98)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg
 - date published: 2020-11-13 00:00:00+00:00

Download & Stream: https://smarturl.it/pmjonfleek
Watch without Pop-ups: https://www.youtube.com/watch?v=OBmlCZTF4Xs
Experience PMJ Live: https://pmjlive.com?IQid=yt
Shop PMJ Music/Merch: https://smarturl.it/pmjshop?IQid=yt
Spotify: https://smarturl.it/pmjcomplete?IQid=yt

In the latest PMJ POP-UP (a nod to '90s era VH1), we're revisiting our 'Singin' In The Rain' style remake of Rihanna's "Umbrella," starring Casey Abrams and tap dancing "Sole Sisters" Sarah Reich and Melinda Sullivan!  Enjoy!
____________________________________________

Follow The Musicians:

Casey Abrams (Vocals):  http://caseybassy.com
Sarah Reich (Tap Dance): http://www.instagram.com/sourtaps
Melinda Sullivan (Tap): http://www.instagram.com/realmelsully
Jacob Scesney (clarinet): https://www.instagram.com/antijacobclub/
Martin Diller (drums): http://www.twitter.com/martindiller
Alex Boneham (bass)

Scott Bradlee (Piano):
YouTube: http://youtube.com/scottbradlee
Facebook: http://facebook.com/scottbradleemusic
Instagram: http://instagram.com/scottbradlee
Twitter: http://twitter.com/scottbradlee

Scott Bradlee - piano & arrangement
YouTube: http://youtube.com/scottbradlee
Facebook: http://facebook.com/scottbradleemusic
Instagram: http://instagram.com/scottbradlee
Twitter: http://twitter.com/scottbradlee
Scott's Book:  http://smarturl.it/outsidethejukebox

_________________________________________________
#Rihanna #Umbrella #PopUp #Cover

