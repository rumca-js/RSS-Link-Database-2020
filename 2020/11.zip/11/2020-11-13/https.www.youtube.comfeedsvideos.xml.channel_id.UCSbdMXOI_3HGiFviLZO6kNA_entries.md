# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## Valve Index Killer? HP REVERB G2 Impressions
 - [https://www.youtube.com/watch?v=-KNk_wovPXo](https://www.youtube.com/watch?v=-KNk_wovPXo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-11-14 00:00:00+00:00

Here are my first impressions on the HP Reverb G2. SO far I have been enjoying it, but that's not without running into a few issues. This is not a full review just yet, but I think you'll have a pretty clear idea of whether or not you should go for this headset at this point.

I will be streaming with the G2 on twitch here:
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill

