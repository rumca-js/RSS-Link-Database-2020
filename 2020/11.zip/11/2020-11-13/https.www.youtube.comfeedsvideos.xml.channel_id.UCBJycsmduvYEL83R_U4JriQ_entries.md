# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## PlayStation 5 Review: Next Gen Gaming!
 - [https://www.youtube.com/watch?v=MepGo2xmVJw](https://www.youtube.com/watch?v=MepGo2xmVJw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-11-14 00:00:00+00:00

PS5 review from a casual gamer.
PS5 Accessories: https://youtu.be/Sye31IVjiss
The Controller: https://youtu.be/imx_-6tHjhw
PC Gaming in 8K: https://youtu.be/kFz9afj8lu0

0:00 Intro
0:45 Design Thoughts
2:42 What's New
5:01 Next Gen Gaming
7:12 Ray Tracing
9:52 NBA 2K21
11:07 The Controller
14:23 Final Thoughts

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Intertia by 20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Console provided by Sony for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

