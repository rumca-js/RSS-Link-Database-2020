# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Austin Petersen, The Secular Dudebro, On Why He’s Pro-Life
 - [https://www.youtube.com/watch?v=neYaB4ckbyU](https://www.youtube.com/watch?v=neYaB4ckbyU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-11-13 00:00:00+00:00

Austin Petersen shares his Pro-Life stance from a secular perspective to the Babylon Bee writers. While explaining how Christians can share ways even Atheists can be Pro-Life, Austin shares on how capitalism has helped create more human life in the past.  

See the full show here:
https://youtu.be/gURSeC52k1U

Subscribe to the Babylon Bee to get the best non biased dude bro perspectives

Hit the Bell to get your daily dose of fake news that you can trust.

## The Left Makes Enemies List/Pandemic Is Over/The Sacred Texts News Show 11.13.2020
 - [https://www.youtube.com/watch?v=kienRburY9g](https://www.youtube.com/watch?v=kienRburY9g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-11-13 00:00:00+00:00

Today on The Babylon Bee Podcast, Kyle and Ethan talk about the week’s biggest stories like the pandemic being officially over now that Biden is President-elect, Biden’s secret list of cabinet picks getting leaked by The Babylon Bee, and the party against fascism, the Democrats, are creating a giant list of enemies because that always ends well. Also, The Bee’s big ‘covfefe’ table book The Sacred Texts of The Babylon Bee Volume 1 is finally hitting the streets and we have weird news and glorious hate mail!

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Gain Access to the Exclusive Content and Writing Forum: https://babylonbee.com/plans

The Official Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

