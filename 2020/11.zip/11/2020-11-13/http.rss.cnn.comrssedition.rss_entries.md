# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Trump threatens to deny New Yorkers vaccine. See governor's response
 - [https://www.cnn.com/videos/politics/2020/11/13/cuomo-reacts-trump-vaccine-new-york-vpx.cnn](https://www.cnn.com/videos/politics/2020/11/13/cuomo-reacts-trump-vaccine-new-york-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 23:45:22+00:00

New York Governor Andrew Cuomo reacts to President Trump's remarks in the Rose Garden threatening to deny his state a vaccine for coronavirus.

## Trudeau threatens to cancel Christmas for Canadians
 - [https://www.cnn.com/2020/11/13/world/canada-covid-thanksgiving-surge-trnd/index.html](https://www.cnn.com/2020/11/13/world/canada-covid-thanksgiving-surge-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 21:17:41+00:00

Canadian Thanksgiving was just last month, and the country has seen consequences as Covid-19 cases reach record highs. Now, Canadian leaders say Christmas celebrations are in jeopardy.

## Grandfather serving 505-year sentence ordered to be released 'without delay'
 - [https://www.cnn.com/2020/11/13/us/505-year-drug-war-sentence-seresi-freed-invs/index.html](https://www.cnn.com/2020/11/13/us/505-year-drug-war-sentence-seresi-freed-invs/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 20:47:03+00:00

In a stunning reprieve for a man sentenced to more than five centuries behind bars for a nonviolent offense, a judge in Los Angeles on Thursday summarily slashed his sentence to time served and ordered his immediate release.

## Giant alligator spotted on a stroll through Florida golf course
 - [https://www.cnn.com/videos/us/2020/11/13/giant-alligator-florida-golf-course-orig-jk.cnn](https://www.cnn.com/videos/us/2020/11/13/giant-alligator-florida-golf-course-orig-jk.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 20:37:10+00:00

A golf pro working at a course in Naples, Florida captured this video of a huge alligator on a stroll through the green.

## Biden turns Georgia blue for first time in 28 years
 - [https://www.cnn.com/2020/11/13/politics/joe-biden-wins-georgia/index.html](https://www.cnn.com/2020/11/13/politics/joe-biden-wins-georgia/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 20:21:28+00:00

Joe Biden will win Georgia, CNN projected Friday, striking at the heart of what has been a Republican presidential stronghold for nearly three decades. The former vice president is the first Democratic nominee to triumph in Georgia since Bill Clinton did it in 1992.

## 'The Crown' pulls off a Season 4 red carpet premiere from home
 - [https://www.cnn.com/2020/11/13/entertainment/the-crown-season-4-premiere/index.html](https://www.cnn.com/2020/11/13/entertainment/the-crown-season-4-premiere/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 19:17:40+00:00

The stars of "The Crown" ushered in Season 4 from their respective homes this year due to the coronavirus pandemic.

## Zuckerberg: Bannon saying Fauci and Wray should be beheaded not enough for Facebook ban
 - [https://www.cnn.com/2020/11/13/tech/facebook-steve-bannon/index.html](https://www.cnn.com/2020/11/13/tech/facebook-steve-bannon/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 19:08:10+00:00

Facebook CEO Mark Zuckerberg told staff at a company meeting on Thursday that Steve Bannon suggesting that Dr. Anthony Fauci and FBI Director Christopher Wray should be beheaded was not enough of a violation of Facebook's rules to permanently suspend the former White House chief strategist from the platform, according to a Facebook employee.

## UK PM's chief adviser Dominic Cummings resigns, says source
 - [https://www.cnn.com/2020/11/13/uk/dominic-cummings-leaves-downing-street-gbr-intl/index.html](https://www.cnn.com/2020/11/13/uk/dominic-cummings-leaves-downing-street-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 19:00:25+00:00

Amid the UK's grave second wave of Covid-19 and its final act of Brexit, British Prime Minister Boris Johnson's chief adviser, Dominic Cummings, has resigned, a source at Downing Street told CNN on Friday.

## Marlins hire MLB's first female general manager
 - [https://www.cnn.com/2020/11/13/us/kim-ng-miami-marlins-gm-mlb-spt-trnd/index.html](https://www.cnn.com/2020/11/13/us/kim-ng-miami-marlins-gm-mlb-spt-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 18:55:27+00:00

The Miami Marlins have hired Kim Ng to be the team's new general manager, making her the first woman GM and first Asian American GM in Major League Baseball history.

## Law firm attempting to block Biden's win in Pennsylvania leaves controversial Trump campaign case
 - [https://www.cnn.com/collections/trump-lawsuits-intl-111320/](https://www.cnn.com/collections/trump-lawsuits-intl-111320/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 18:38:54+00:00



## This has never happened in US Congress before
 - [https://www.cnn.com/2020/11/13/politics/election-2020-record-women-in-congress/index.html](https://www.cnn.com/2020/11/13/politics/election-2020-record-women-in-congress/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 18:12:23+00:00

The day after South Carolina's longtime Republican 1st District flipped blue in 2018, Nancy Mace's 9-year-old daughter had a question.

## Law firm attempting to block Biden's win in Pennsylvania leaves controversial Trump campaign case
 - [https://www.cnn.com/2020/11/13/politics/law-firm-biden-trump-pennsylvania/index.html](https://www.cnn.com/2020/11/13/politics/law-firm-biden-trump-pennsylvania/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 18:01:35+00:00

A law firm representing the President's campaign in a controversial and long-shot attempt to block Pennsylvania's popular vote for Joe Biden is leaving the case.

## TikTok granted two more weeks to reach a deal for US business
 - [https://www.cnn.com/2020/11/13/tech/tiktok-november-deadline-extension/index.html](https://www.cnn.com/2020/11/13/tech/tiktok-november-deadline-extension/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 17:43:42+00:00

After seemingly blowing past the Trump administration's deadline for TikTok to find a new owner, the US government has quietly given the embattled social media platform a reprieve.

## Medical journal editor shares his key concern for Covid-19 vaccines
 - [https://www.cnn.com/videos/health/2020/11/13/coronavirus-covid-19-vaccine-pfizer-lancet-richard-horton-anderson-intv-ctw-intl-ldn-vpx.cnn](https://www.cnn.com/videos/health/2020/11/13/coronavirus-covid-19-vaccine-pfizer-lancet-richard-horton-anderson-intv-ctw-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 17:31:40+00:00

CNN's Becky Anderson speaks with Richard Horton, editor-in-chief of The Lancet, about the development of vaccines for the novel coronavirus.

## Princess Diana's 'black sheep' sweater is back on sale -- four decades after she made it famous
 - [https://www.cnn.com/style/article/diana-sheep-sweater-scli-intl-gbr/index.html](https://www.cnn.com/style/article/diana-sheep-sweater-scli-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 17:05:57+00:00

A sweater made famous by Princess Diana has been reissued by the designers, four decades after she sported the bold red knit, which features dozens of white sheep and one black sheep on the front.

## Harry Styles becomes Vogue's first-ever solo male cover star
 - [https://www.cnn.com/style/article/harry-styles-vogue-cover-trnd/index.html](https://www.cnn.com/style/article/harry-styles-vogue-cover-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 16:45:13+00:00

Harry Styles just added another accolade to his growing list of achievements. Starring on the cover of US Vogue's December 2020 issue, he is the first man to front the fashion title solo.

## Peter Sutcliffe, UK killer known as the Yorkshire Ripper, dies with coronavirus
 - [https://www.cnn.com/2020/11/13/uk/peter-sutcliffe-yorkshire-ripper-dead-gbr-intl/index.html](https://www.cnn.com/2020/11/13/uk/peter-sutcliffe-yorkshire-ripper-dead-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 15:58:36+00:00

British serial killer Peter Sutcliffe has died in hospital aged 74 after contracting Covid-19, the UK Ministry of Justice said Friday.

## Dolly Parton talks aging with Oprah Winfrey: 'I ain't got time to be old'
 - [https://www.cnn.com/2020/11/13/entertainment/dolly-parton-oprah-winfrey/index.html](https://www.cnn.com/2020/11/13/entertainment/dolly-parton-oprah-winfrey/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 15:43:14+00:00

Dolly Parton will remain ageless, she tells Oprah Winfrey.

## The world's largest wetlands are on fire. That's a disaster for all of us
 - [https://www.cnn.com/2020/11/13/americas/pantanal-fires-climate-change-intl/index.html](https://www.cnn.com/2020/11/13/americas/pantanal-fires-climate-change-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 15:33:58+00:00

The world watched as California and the Amazon went up in flames this year, but the largest tropical wetland on earth has been ablaze for months, largely unnoticed by the outside world.

## Anderson Cooper says his baby is a CNN Heroes fan
 - [https://www.cnn.com/videos/us/2020/11/13/cnn-heroes-announcement-cooper-vpx.cnn](https://www.cnn.com/videos/us/2020/11/13/cnn-heroes-announcement-cooper-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 14:36:24+00:00

Anderson Cooper announces when and how voting will take place for CNN Heroes, a series featuring everyday people doing extraordinary things to change the world.

## A Japanese robotics startup has invented a smart mask that translates into eight languages
 - [https://www.cnn.com/2020/08/03/business/japanese-robotics-smart-face-mask-spc-intl/index.html](https://www.cnn.com/2020/08/03/business/japanese-robotics-smart-face-mask-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 14:13:09+00:00

When the Covid-19 pandemic made face masks an everyday essential, Japanese startup Donut Robotics spotted an opportunity. They created a smart mask — a high-tech upgrade to standard face coverings, designed to make communication and social distancing easier.

## What the 737 MAX's return to the sky will mean for passengers
 - [https://www.cnn.com/travel/article/737-max-return-passenger-impact/index.html](https://www.cnn.com/travel/article/737-max-return-passenger-impact/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 13:26:17+00:00

Would you fly on the Boeing 737 MAX? That question is going to become all too real for passengers in the near future when the aircraft that's been grounded for some 600 days returns to service.

## Analysis: Republicans breaking with Trump see security risk
 - [https://www.cnn.com/2020/11/13/politics/donald-trump-joe-biden-republicans-transition/index.html](https://www.cnn.com/2020/11/13/politics/donald-trump-joe-biden-republicans-transition/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 12:30:37+00:00

As President Donald Trump's lawyers cling to their far-fetched schemes to overturn the presidential election, it was increasingly clear Thursday that cracks are forming in Trump's Republican wall of support, as more GOP members stepped forward to say that President-elect Joe Biden should receive national intelligence briefings and others began to acknowledge the long-shot nature of the President's quest.

## Don't worry, Santa -- the Covid rules don't apply to you, Belgian minister tells St. Nick
 - [https://www.cnn.com/travel/article/santa-covid-exempt-intl-scli/index.html](https://www.cnn.com/travel/article/santa-covid-exempt-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 12:13:08+00:00

Millions of people across Europe are living under restrictions as the continent battles a second wave of coronavirus -- but in Belgium, authorities have decreed that one jolly worker is exempt from the rules: Santa Claus.

## These Trump supporters say Fox News is too liberal
 - [https://www.cnn.com/videos/business/2020/11/12/trump-supporters-and-fox-news-orig-jm.cnn](https://www.cnn.com/videos/business/2020/11/12/trump-supporters-and-fox-news-orig-jm.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 11:05:05+00:00

President Trump is at war with Fox News over its election predictions. These Trump supporters tell CNN they're done with the conservative network.

## This building on wheels could be the future of architecture
 - [https://www.cnn.com/videos/tv/2020/11/06/charles-renfro-spc-intl.cnn](https://www.cnn.com/videos/tv/2020/11/06/charles-renfro-spc-intl.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 10:51:42+00:00

The Shed is a 200,000-square-foot arts center in New York that can roll back and forth to increase its size. One of the architects behind its design says it's time to rethink the way buildings are made.

## Lewis Hamilton is 'much prouder' of his push for equality than his fight for a seventh F1 title
 - [https://www.cnn.com/2020/11/13/motorsport/lewis-hamilton-equality-record-title-pride-spt-intl/index.html](https://www.cnn.com/2020/11/13/motorsport/lewis-hamilton-equality-record-title-pride-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 10:39:52+00:00

Formula One driver Lewis Hamilton says campaigning for equal rights has made him "much prouder" than possibly clinching a seventh world title this season.

## Supermarket in China apologizes for chart that labels women who wear larger sizes 'rotten' and 'terrible'
 - [https://www.cnn.com/2020/11/13/business/china-department-store-clothing-size-intl-hnk/index.html](https://www.cnn.com/2020/11/13/business/china-department-store-clothing-size-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 09:37:03+00:00

A supermarket chain in China has apologized for apparently featuring a chart in one of its stores that used disparaging language to refer to women who wear larger-sized clothes as "rotten" and "terrible."

## Turkmenistan's authoritarian leader unveils huge golden dog statue in the capital
 - [https://www.cnn.com/2020/11/13/asia/turkmenistan-dog-statue-intl-hnk-scli/index.html](https://www.cnn.com/2020/11/13/asia/turkmenistan-dog-statue-intl-hnk-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 08:33:47+00:00

Turkmenistan's longtime leader has unveiled a giant gilded statue of a dog on a busy traffic circle in the capital Ashgabat.

## Van Jones: Trump is strapping the country onto his own kamikaze plane
 - [https://www.cnn.com/videos/politics/2020/11/13/trump-refusal-to-concede-van-jones-kamikaze-mission-anderson-cooper-ac360-vpx.cnn](https://www.cnn.com/videos/politics/2020/11/13/trump-refusal-to-concede-van-jones-kamikaze-mission-anderson-cooper-ac360-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 08:13:14+00:00

CNN's Van Jones hit out at President Donald Trump for his refusal to concede the 2020 presidential election by comparing his move to the "kamikaze" mission during World War II.

## Mary Trump weighs in on Trump's possible 2024 presidential run
 - [https://www.cnn.com/videos/politics/2020/11/13/mary-trump-niece-donald-2024-presidential-run-cpt-vpx.cnn](https://www.cnn.com/videos/politics/2020/11/13/mary-trump-niece-donald-2024-presidential-run-cpt-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 06:28:25+00:00

President Trump's niece, Mary Trump, explains to CNN's Chris Cuomo why she does not believe her uncle will make another run at the presidency in 2024.

## Maldives resort offers $30K 'all-you-can-stay' package
 - [https://www.cnn.com/travel/article/anantara-maldives-annual-pass-intl-hnk/index.html](https://www.cnn.com/travel/article/anantara-maldives-annual-pass-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 02:57:32+00:00

Move over, all-you-can-eat buffet: the all-you-can-stay resort package has entered the party.

## Building for a flooded future: Architects are designing for the new climate reality
 - [https://www.cnn.com/style/article/flooding-architecture-projects-spc-intl-c2e/index.html](https://www.cnn.com/style/article/flooding-architecture-projects-spc-intl-c2e/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 02:45:55+00:00

Climate change is making cities more susceptible to flooding. According to a 2019 study, global sea levels are expected to rise between two and seven feet over the course of the century; by 2100, at least 190 million people could be living in areas below the projected high-tide line.

## Trump's eldest children split on his path forward
 - [https://www.cnn.com/2020/11/12/politics/trump-ivanka-jared-kushner-donald-jr-eric/index.html](https://www.cnn.com/2020/11/12/politics/trump-ivanka-jared-kushner-donald-jr-eric/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 02:39:41+00:00

President Donald Trump has long sought advice from different perspectives throughout his career, but at a pivotal moment in defining his legacy as President, he is receiving conflicting advice from his closest and most trusted advisers -- his eldest children -- as he strategizes his next move in the wake of his election loss.

## Cooper shocked by White House press secretary's Fox News answer
 - [https://www.cnn.com/videos/politics/2020/11/13/kth-america-first-me-first-trump-kayleigh-mcenany-ac360-vpx.cnn](https://www.cnn.com/videos/politics/2020/11/13/kth-america-first-me-first-trump-kayleigh-mcenany-ac360-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 01:41:49+00:00

CNN's Anderson Cooper discusses the lack of action from President Donald Trump and his White House administration days after the election results.

## GOP lawmakers defend CIA Director Gina Haspel as Trump weighs firing her
 - [https://www.cnn.com/collections/intl-washington-hot-stove-11122020/](https://www.cnn.com/collections/intl-washington-hot-stove-11122020/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 01:28:57+00:00



## 'Dejected' Trump waffles over waging baseless election fight
 - [https://www.cnn.com/2020/11/12/politics/trump-election-future-white-house/index.html](https://www.cnn.com/2020/11/12/politics/trump-election-future-white-house/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 01:06:04+00:00

How much longer President Donald Trump continues waging battle over an election he lost remained in question Thursday as more of his advisers voiced doubt his gambit to contest the results would succeed. One person who spoke to him called him "dejected" over the ordeal.

## Nurse dying of Covid-19 sends family message in final moments
 - [https://www.cnn.com/videos/health/2020/11/12/nurse-sends-final-words-to-family-coronavirus-anderson-cooper-acfc-vpx.cnn](https://www.cnn.com/videos/health/2020/11/12/nurse-sends-final-words-to-family-coronavirus-anderson-cooper-acfc-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 01:03:59+00:00

Sergio Hernandez sent a final video message to his family hours before dying from coronavirus. Hernandez's cousin Adalberto Hernandez joins Anderson Cooper to talk about his life. Watch "Full Circle" every Monday, Tuesday and Friday at 6pm E.T.

## 'Most secure ever:' Trump officials contradict his election claims
 - [https://www.cnn.com/videos/politics/2020/11/13/dhs-election-most-secure-history-trump-biden-burnett-opening-ebof-vpx.cnn](https://www.cnn.com/videos/politics/2020/11/13/dhs-election-most-secure-history-trump-biden-burnett-opening-ebof-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 01:02:47+00:00

The Department of Homeland Security issued a statement saying the November 3rd, 2020, election was the most secure election in history. President Donald Trump continues to deny the results.

## Republicans see President's efforts as likely to fail and hope key vote certification deadlines bail them out
 - [https://www.cnn.com/2020/11/12/politics/gop-strategy-trump-transition/index.html](https://www.cnn.com/2020/11/12/politics/gop-strategy-trump-transition/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 00:45:17+00:00

Cracks are growing in the GOP defense of President Donald Trump's long-shot effort to overturn the 2020 election outcome, with many top Republicans contending that Joe Biden should immediately get national security briefings, some calling for the official transition process to begin and others are acknowledging that Trump stands little chance at reversing results clearly showing he lost.

## Obama memoir confronts role his presidency played in Republican obstructionism and Trump's rise
 - [https://www.cnn.com/collections/intl-obama-memoir/](https://www.cnn.com/collections/intl-obama-memoir/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 00:17:28+00:00



## Many have tried, but nobody has ever reached the top of this Pakistan mountain
 - [https://www.cnn.com/travel/article/muchu-chhish-world-highest-unclimbed-mountain-pakistan/index.html](https://www.cnn.com/travel/article/muchu-chhish-world-highest-unclimbed-mountain-pakistan/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 00:11:04+00:00

It's not the world's highest mountain, nor is it the hardest one to climb, presumably.

## Trump bans US investments that would aid China's military
 - [https://www.cnn.com/2020/11/12/investing/trump-bans-us-investments-china-military/index.html](https://www.cnn.com/2020/11/12/investing/trump-bans-us-investments-china-military/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 00:09:38+00:00

President Donald Trump signed an executive order banning Americans from investing in Chinese firms that the administration says are owned or controlled by the Chinese military.

## Covid-19 in the US is a 'humanitarian disaster,' and the pandemic is only accelerating, health experts say
 - [https://www.cnn.com/collections/intl-covid-1110/](https://www.cnn.com/collections/intl-covid-1110/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-13 00:00:03+00:00



