# Source:Mandalore Gaming, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw, language:en-US

## Unfortunate Spacemen Review
 - [https://www.youtube.com/watch?v=oZS56i7U6FY](https://www.youtube.com/watch?v=oZS56i7U6FY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw
 - date published: 2020-11-13 00:00:00+00:00

Unfortunate Spacemen is a multiplayer hidden role horror game heavily inspired by The Thing. Naturally this translates to WOWZERS 3D Among Us FPS with guns?!?!
Support the channel at: https://www.patreon.com/mandaloregaming or https://www.paypal.me/MandaloreGaming
I take video suggestions at mandaloremovies@gmail.com
Twitter: https://twitter.com/Lord_Mandalore
Thumbnail Help and Game Key Art by @tat2kid714
#UnfortunateSpacemen #UnfortunateSpacemenReview #UnfortunateSpacemenGame #UnfortunateSpacemenPC

00:00 - Intro
00:10 - Game Premise
00:50 - Visuals & Audio
03:36 - Gameplay Mechanics
10:34 - The Perk System (THIS WAS OVERHAULED IN 1.3)
12:06 - Conclusions
12:30 - Credits
13:36 - He Returns

