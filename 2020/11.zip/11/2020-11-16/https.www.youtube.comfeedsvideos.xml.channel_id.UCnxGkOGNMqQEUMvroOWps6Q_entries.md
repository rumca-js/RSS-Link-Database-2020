# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Professor Gary Laderman's Issues with Tenure System
 - [https://www.youtube.com/watch?v=6l2-pCXqjo4](https://www.youtube.com/watch?v=6l2-pCXqjo4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-11-17 00:00:00+00:00

#1565 w/Gary Laderman:
https://open.spotify.com/episode/0qMDZGFzU4RsEdjICSUiWg?si=uV4iB2YYSH2rT2wNeseJjw

## The Problem with Celebrity Pastors
 - [https://www.youtube.com/watch?v=xnsZueuiZH0](https://www.youtube.com/watch?v=xnsZueuiZH0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-11-17 00:00:00+00:00

#1565 w/Gary Laderman:
https://open.spotify.com/episode/0qMDZGFzU4RsEdjICSUiWg?si=uV4iB2YYSH2rT2wNeseJjw

## The Religious Qualities of Celebrity Worship, Pop Culture
 - [https://www.youtube.com/watch?v=d9LlFB4Tx-Y](https://www.youtube.com/watch?v=d9LlFB4Tx-Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-11-17 00:00:00+00:00

#1565 w/Gary Laderman:
https://open.spotify.com/episode/0qMDZGFzU4RsEdjICSUiWg?si=uV4iB2YYSH2rT2wNeseJjw

## Santino & the Shrew Moment - JRE Toons
 - [https://www.youtube.com/watch?v=6yzVtlUI02w](https://www.youtube.com/watch?v=6yzVtlUI02w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-11-16 00:00:00+00:00

Another hilarious moment animated by PaulyToon from the Joe Rogan Experience #1293 with Andrew Santino (https://youtu.be/3Dp4RrpbWqo)

