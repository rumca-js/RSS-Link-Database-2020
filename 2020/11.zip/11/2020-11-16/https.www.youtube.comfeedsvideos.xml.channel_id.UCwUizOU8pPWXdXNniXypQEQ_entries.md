# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## If Football Games Were Called Like the Election
 - [https://www.youtube.com/watch?v=PLdu_BLWV4w](https://www.youtube.com/watch?v=PLdu_BLWV4w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-11-17 00:00:00+00:00

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Grab your Primally Pure Deodorant Here - https://primallypure.com/jp
Use the discount code "JP" for 10% Off!

Check out Brent's Channel - https://www.youtube.com/c/brentpella/

Here is what it would be like if football games were called like the election. The 2020 presidential election between Joe Biden and Donald Trump was decided by the media. Here’s what that would look like if it happened in football.

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

