# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Brandon Sanderson Talks Rhythm of War🥁 YouTube Success📸  & The Industry🛠️
 - [https://www.youtube.com/watch?v=viLSKpppa1A](https://www.youtube.com/watch?v=viLSKpppa1A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-11-17 00:00:00+00:00

An interview with the creator of Mistborn, The Stormlight Archive, and of course, the entire Cosmere, Brandon Sanderson! 

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

00:00 Intro 
06:30 Biggest Hurdles writing Rhythm of War
15:27 Narrative Momentum 
20:26 Conceptualizing The Stormlight Archive
25:08 Will Sanderson ever write classic style fantasy?
28:18 YouTube success 
30:52 Writing Stormlight VS smaller stories
35:11 Advice for using new media as an author

## Halo Show Cortana RECAST!💎 KingKiller Show not “Cracked”?⛏️ Last Dangerous Visions👁️-FANTASY NEWS
 - [https://www.youtube.com/watch?v=LDTlWUoblpc](https://www.youtube.com/watch?v=LDTlWUoblpc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-11-17 00:00:00+00:00

We got King Killer show comments and LONG awaited releases. Let’s get some fantasy news!
The first 1000 people to use the link in my description will get a free trial of Skillshare Premium Membership: https://skl.sh/danielgreene11201

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

00:00 Intro 

00:30 The Last Dangerous Visions: https://www.theguardian.com/books/2020/nov/16/harlan-ellison-the-last-dangerous-visions-anthology-may-be-published 

05:20 #ThePoppyWar Spin off: https://twitter.com/kuangrf/status/1325977815209140225?s=12 

05:38 #KingKiller Show not “Cracked”: https://ew.com/tv/his-dark-materials-lin-manuel-miranda-the-kingkiller-chronicle/ 

07:01 The Girl And The Mountain: https://thatthornguy.com/2020/11/11/the-girl-and-the-mountain-us-cover-reveal/ 

07:13 She Who Became The Sun: https://www.tor.com/2020/11/16/cover-reveals-she-who-became-the-sun-by-shelley-parker-chan/

07:41 The Outsider “Shopping”: https://deadline.com/2020/11/the-outsider-canceled-hbo-mrc-shopping-season-2-1234611885/ 

09:07 Alien Worlds: https://www.youtube.com/watch?v=2YTYleNFaPE 

09:41 Black Panther 2 Update: https://www.highsnobiety.com/p/chadwick-boseman-black-panther-2/ 

11:12 Cortana #Halo Actress: https://www.theverge.com/2020/11/11/21561137/halo-tv-show-cortana-recast-jen-taylor

