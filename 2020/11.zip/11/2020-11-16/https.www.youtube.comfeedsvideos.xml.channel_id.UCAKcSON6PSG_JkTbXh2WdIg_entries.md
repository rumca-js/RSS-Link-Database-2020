# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## CAAMP - three songs at The Current (2019)
 - [https://www.youtube.com/watch?v=x-q2f0rkbrg](https://www.youtube.com/watch?v=x-q2f0rkbrg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-11-17 00:00:00+00:00

One year ago today — on Nov. 16, 2019 — Ohio band Caamp visited our studio to play three songs off their album, "By and By." Watch that three-song set above.

SONGS PERFORMED
0:00 "Peach Fuzz"
2:10 "Wolf Song"
5:39 "Wunderbar"

PERSONNEL
Taylor Meier – guitar, vocals
Evan Westfall – banjo 
Matt Vinson – bass
Joe Kavalec – keys

CREDITS
Video & Photo: Nate Ryan
Audio: Michael DeMark
Production: Derrick Stevens

FIND MORE:
2019 studio session: https://www.thecurrent.org/feature/2019/11/16/caamp-perform-in-the-current-studio

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#caamp #caampband

