# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Ethan Hawke learned a valuable lesson from River Phoenix's death
 - [https://www.cnn.com/2020/11/16/entertainment/ethan-hawke-river-phoenix-trnd/index.html](https://www.cnn.com/2020/11/16/entertainment/ethan-hawke-river-phoenix-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 23:51:34+00:00

Ethan Hawke says River Phoenix's death is one of the reasons he never moved to Los Angeles.

## Oreo is finally releasing gluten-free cookies
 - [https://www.cnn.com/2020/11/16/business/gluten-free-oreos/index.html](https://www.cnn.com/2020/11/16/business/gluten-free-oreos/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 23:45:33+00:00

If you're gluten-intolerant, traditional Oreos have been on the no-no list. But that's about to change.

## Michelle Obama reflects on how she put her anger aside for a peaceful transition
 - [https://www.cnn.com/2020/11/16/politics/michelle-obama-transition-first-lady-melania-trump/index.html](https://www.cnn.com/2020/11/16/politics/michelle-obama-transition-first-lady-melania-trump/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 23:44:43+00:00

Michelle Obama has weighed in on the refusal of President Donald Trump and first lady Melania Trump to move forward with a transition of power to the incoming administration, reflecting on where she was four years ago and how -- though the process of ceding responsibility to the Trumps was difficult -- she persisted.

## Virgin Galactic delays key test flight after pandemic causes shutdowns
 - [https://www.cnn.com/2020/11/16/tech/virgin-galactic-stock-test-flight-scn/index.html](https://www.cnn.com/2020/11/16/tech/virgin-galactic-stock-test-flight-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 23:16:43+00:00

Virgin Galactic said Monday that it no longer plans to conduct a key test flight of its spacecraft this week because of a surge in new Covid-19 cases and resulting related restrictions in New Mexico, home to the company's glitzy spaceport.

## Trump expected to order troop withdrawals from Afghanistan and Iraq
 - [https://www.cnn.com/collections/us-troop-withdrawals-intl-111620/](https://www.cnn.com/collections/us-troop-withdrawals-intl-111620/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 22:44:03+00:00



## Trump expected to order troop withdrawals from Afghanistan and Iraq
 - [https://www.cnn.com/2020/11/16/politics/trump-afghanistan-iraq-troop-drawdown-order/index.html](https://www.cnn.com/2020/11/16/politics/trump-afghanistan-iraq-troop-drawdown-order/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 22:35:04+00:00

• Fired defense chief's memo warned conditions not met for Afghanistan withdrawal

## Biden: More may die if Trump doesn't cooperate with transition
 - [https://www.cnn.com/2020/11/16/politics/biden-economic-speech/index.html](https://www.cnn.com/2020/11/16/politics/biden-economic-speech/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 22:31:43+00:00

• Analysis: GOP governor plays politics while Covid-19 burns through her state
• Over 1 million US children have been diagnosed with Covid-19, pediatricians say

## Ryan Reynolds and Rob McElhenney set to complete takeover of Welsh soccer team
 - [https://www.cnn.com/2020/11/16/football/ryan-reynolds-rob-mcelhenney-wrexham-takeover-approved-spt-intl/index.html](https://www.cnn.com/2020/11/16/football/ryan-reynolds-rob-mcelhenney-wrexham-takeover-approved-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 21:37:42+00:00

The gang has bought a football club.

## Akon wants to literally build a new future in Africa
 - [https://www.cnn.com/videos/world/2020/11/12/akon-build-new-future-africa-spc.cnn](https://www.cnn.com/videos/world/2020/11/12/akon-build-new-future-africa-spc.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 19:13:51+00:00

Akon has plans to build a $6 billion city in Senegal. He shows us how his life as a pop star and a father prepared him for this moment.

## Archaeologists find 100 ancient Egyptian coffins, some with mummies, at burial complex
 - [https://www.cnn.com/style/article/100-coffins-mummies-saqqara-scli-intl-scn/index.html](https://www.cnn.com/style/article/100-coffins-mummies-saqqara-scli-intl-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 18:16:06+00:00

Archaeologists in Egypt have uncovered at least 100 perfectly preserved ancient coffins, some containing mummies, and 40 statues in a vast Pharaonic necropolis south of the capital, Cairo.

## The National Book Awards named their first undocumented finalist. Here's how she sees America
 - [https://www.cnn.com/2020/11/16/us/undocumented-americans-karla-cornejo-villavicencio/index.html](https://www.cnn.com/2020/11/16/us/undocumented-americans-karla-cornejo-villavicencio/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 15:19:32+00:00

Karla Cornejo Villavicencio says she's suffering from survivor's guilt.

## Pepsi unveils first 2-liter bottle redesign in nearly 30 years
 - [https://www.cnn.com/2020/11/16/business/pepsi-bottle-redesign/index.html](https://www.cnn.com/2020/11/16/business/pepsi-bottle-redesign/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 15:14:01+00:00

PepsiCo's line of chubby plastic 2-liter bottles are getting a slimmer redesign — the first in about three decades.

## Boris Johnson is trapped at home at the worst time
 - [https://www.cnn.com/2020/11/16/uk/boris-johnson-covid-brexit-week-analysis-gbr-intl/index.html](https://www.cnn.com/2020/11/16/uk/boris-johnson-covid-brexit-week-analysis-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 14:46:18+00:00



## 'My heart's ripped out:' Kelly Slater pays tribute to former world tour surfer
 - [https://www.cnn.com/2020/11/16/sport/john-shimooka-death-surfing-spt-intl/index.html](https://www.cnn.com/2020/11/16/sport/john-shimooka-death-surfing-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 13:19:05+00:00

The world of surfing is mourning the death of John Shimooka at the age of 51.

## Fat, flightless parrot named Bird of the Year after a campaign tainted by voter fraud
 - [https://www.cnn.com/2020/11/16/asia/kakapo-new-zealand-bird-vote-scli-intl-scn/index.html](https://www.cnn.com/2020/11/16/asia/kakapo-new-zealand-bird-vote-scli-intl-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 12:50:24+00:00

A lengthy and bitter election campaign that dragged in competing interest groups and was sullied by a voter fraud scandal came to an unlikely end on Monday, when a fat, flightless and nocturnal parrot stunned pundits to claim an upset victory.

## The ancient building still being used after 2,000 years
 - [https://www.cnn.com/style/article/pantheon-history-test-of-time/index.html](https://www.cnn.com/style/article/pantheon-history-test-of-time/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 11:18:09+00:00

When visitors walk into the Pantheon in Rome and encounter its colossal dome, they may experience the same theatricality as its guests nearly 2,000 years ago.

## The story behind Italy's most visited cultural site
 - [https://www.cnn.com/videos/architecture/2020/11/13/pantheon-rome-italy-history-design-test-of-time-lon-orig.cnn](https://www.cnn.com/videos/architecture/2020/11/13/pantheon-rome-italy-history-design-test-of-time-lon-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 11:14:29+00:00

If Rome is the Eternal City, the Pantheon is its eternal building, still in use after 2,000 years and attracting six million visitors a year. CNN delves into the history behind this ancient landmark to discover why it's still so influential.

## Hear Boris Johnson's message after possible Covid-19 exposure
 - [https://www.cnn.com/videos/world/2020/11/16/boris-johson-coronavirus-covid-19-foster-newsroom-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2020/11/16/boris-johson-coronavirus-covid-19-foster-newsroom-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 11:01:52+00:00

British Prime Minister Boris Johnson is self-quarantining after coming into contact with someone who tested positive for Covid-19. He said he doesn't have any symptoms. CNN's Max Foster reports.

## Ethiopia says it has seized another Tigray town as conflict embroils Eritrea
 - [https://www.cnn.com/2020/11/16/africa/ethiopia-seized-town-tigray-embroils-eritrea-intl/index.html](https://www.cnn.com/2020/11/16/africa/ethiopia-seized-town-tigray-embroils-eritrea-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 10:57:24+00:00

Ethiopian Prime Minister Abiy Ahmed's government said on Monday it had captured another town in the northern Tigray region after nearly two weeks of fighting in a conflict already spilling into Eritrea and destabilizing the wider Horn of Africa.

## Video shows Belarus police beating protesters inside supermarket
 - [https://www.cnn.com/videos/world/2020/11/16/minsk-belarus-protests-arrests-lukashenko-newsroom-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2020/11/16/minsk-belarus-protests-arrests-lukashenko-newsroom-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 09:55:13+00:00

At least 1,000 people were detained across Belarus on November 15, according to local human rights watchdog Viasna, amid mass demonstrations against longstanding leader Alexander Lukashenko. The protests began after the results of an August election that protesters say was rigged.

## Trump's failure to work with Biden is becoming more urgent as Covid spreads
 - [https://www.cnn.com/2020/11/16/politics/election-2020-donald-trump-joe-biden-transition-coronavirus/index.html](https://www.cnn.com/2020/11/16/politics/election-2020-donald-trump-joe-biden-transition-coronavirus/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 05:00:13+00:00

President Donald Trump is facing a barrage of calls to permit potentially life-saving transition talks between his health officials and incoming President-elect Joe Biden's aides on a fast-worsening pandemic he is continuing to ignore in his obsessive effort to discredit an election that he clearly lost.

## China looms as Biden's biggest foreign policy challenge. Here's where he stands
 - [https://www.cnn.com/collections/biden-china-app-intl-1116/](https://www.cnn.com/collections/biden-china-app-intl-1116/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 04:53:20+00:00



## Top federal information security officer also member of private group investigating voter fraud
 - [https://www.cnn.com/2020/11/15/politics/camilo-sandoval-voter-integrity-fund/index.html](https://www.cnn.com/2020/11/15/politics/camilo-sandoval-voter-integrity-fund/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 04:41:00+00:00

The federal government's chief information security officer, Camilo Sandoval, says he has taken leave from his day job to help the private voter fraud investigation group, "Voter Integrity Fund."

## At least 1,000 people detained in Belarus in a single day following protester's death
 - [https://www.cnn.com/2020/11/15/europe/belarus-protests-death-election-intl/index.html](https://www.cnn.com/2020/11/15/europe/belarus-protests-death-election-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 04:15:53+00:00

At least 1,000 people were detained across Belarus on Sunday, according to local human rights watchdog Viasna, amid mass demonstrations against longstanding leader Alexander Lukashenko, which were prompted by the results of an August election that protesters say was rigged.

## Australian airline Qantas celebrates its 100th anniversary
 - [https://www.cnn.com/travel/article/qantas-centennial-australia-intl-hnk/index.html](https://www.cnn.com/travel/article/qantas-centennial-australia-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 03:57:42+00:00

Australian airline Qantas is celebrating its 100th anniversary on November 16, a rare piece of upbeat news for an aviation industry hobbled by the coronavirus pandemic.

## Biden will take power at a crossroads in US-China relations. Here's what we know so far of where he stands on the major issues
 - [https://www.cnn.com/2020/11/15/asia/biden-china-policy-trump-us-intl-hnk/index.html](https://www.cnn.com/2020/11/15/asia/biden-china-policy-trump-us-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 03:26:37+00:00

As United States President-elect Joe Biden faces an ugly, potentially contested transition, foreign policy may be the last thing on his mind.

## Coronavirus spread across the US pushes Colorado to ramp up emergency response
 - [https://www.cnn.com/2020/11/15/health/us-coronavirus-sunday/index.html](https://www.cnn.com/2020/11/15/health/us-coronavirus-sunday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 03:23:12+00:00

As the United States grapples with a steep surge in Covid-19 cases, states such as Colorado are enacting emergency measures.

## Meet Rebekah Mercer, the deep-pocketed co-founder of Parler, a controversial conservative social network
 - [https://www.cnn.com/2020/11/15/media/rebekah-mercer-parler/index.html](https://www.cnn.com/2020/11/15/media/rebekah-mercer-parler/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 01:52:14+00:00

Rebekah Mercer, a prominent conservative donor, revealed Saturday that she is helping to bankroll Parler, the rapidly growing but controversial conservative social media platform that was at the top of App Store charts last week.

## Georgia Sen. declines to debate opponent ahead of January 5 runoff
 - [https://www.cnn.com/2020/11/15/politics/david-perdue-jon-ossoff-debate-georgia-runoff-election/index.html](https://www.cnn.com/2020/11/15/politics/david-perdue-jon-ossoff-debate-georgia-runoff-election/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 01:35:19+00:00

• Opinion: The damage Trump is doing

## SpaceX launch: Four astronauts take off aboard Crew Dragon bound for ISS
 - [https://www.cnn.com/2020/11/15/tech/spacex-nasa-launch-crew-dragon/index.html](https://www.cnn.com/2020/11/15/tech/spacex-nasa-launch-crew-dragon/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 01:26:02+00:00

A SpaceX spacecraft carrying four astronauts soared into outer space Sunday — marking the kick off of what NASA hopes will be years of the company helping to keep the International Space Station fully staffed.

## Obama says election results show nation is deeply divided
 - [https://www.cnn.com/2020/11/15/politics/barack-obama-donald-trump-concede-divided-nation/index.html](https://www.cnn.com/2020/11/15/politics/barack-obama-donald-trump-concede-divided-nation/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 01:00:22+00:00

Former President Barack Obama said the election results, in which each candidates received more than 70 million votes, show the nation remains bitterly split.

## Iota forecast to hit storm-ravaged Central America as a major hurricane early next week
 - [https://www.cnn.com/2020/11/15/weather/iota-storm-sunday/index.html](https://www.cnn.com/2020/11/15/weather/iota-storm-sunday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-16 00:48:26+00:00

The storm known as Iota strengthened into a hurricane early Sunday and is expected to slam into Central America early next week -- the very region already devastated by Hurricane Eta earlier this month -- forecasters say.

