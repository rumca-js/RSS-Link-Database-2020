# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Mini recenzja iPhone'a 12 mini
 - [https://www.youtube.com/watch?v=zH0bqu3Hg2k](https://www.youtube.com/watch?v=zH0bqu3Hg2k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-11-16 00:00:00+00:00

Moje sociale:
Insta: http://bit.ly/InstaKlawiatur 
Twitter: http://bit.ly/TTKlawitera
FB: http://bit.ly/FBKlawiatur
iPhone mini: https://bit.ly/3ntZvgM

