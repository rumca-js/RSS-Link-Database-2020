# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## The Drinker Recommends... Fight Club
 - [https://www.youtube.com/watch?v=-IyJGImfcvs](https://www.youtube.com/watch?v=-IyJGImfcvs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-11-16 00:00:00+00:00

So I'm about to break the first rule of Fight Club, because it's an awesome movie that I've been waiting to talk about for ages. Join me as I break down one of the most influential thrillers of the past 20 years. 


Also, link to Something to Die For: https://www.amazon.com/Something-Die-Ryan-Drake-Book-ebook/dp/B08H7YBTYF

