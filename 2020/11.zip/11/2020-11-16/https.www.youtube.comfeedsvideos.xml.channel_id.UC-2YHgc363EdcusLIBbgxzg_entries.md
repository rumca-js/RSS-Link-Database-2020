# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## Why You Will Never Have Zoom Calls With Mars | Answers With Joe
 - [https://www.youtube.com/watch?v=YWKWkuJwHj4](https://www.youtube.com/watch?v=YWKWkuJwHj4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2020-11-16 00:00:00+00:00

Mars is far away. So far, it takes light anywhere from 3 to 22 minutes to travel there. This means the way we communicate is going to be very, very different - and will have long-term effects we can't really know right now.


Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

 https://www.forbes.com/sites/kionasmith/2019/02/06/astronaut-alan-shepards-out-of-this-world-round-of-golf-on-the-moon/#52b4afe72500 

https://medium.com/@ikokki/moon-base-landing-on-mars-nasas-rejected-plans-from-the-1960s-and-1970s-fafc706cf1f9

https://www.forbes.com/sites/quora/2016/09/26/is-there-a-fortune-to-be-made-on-mars/#57fbe41a6e28

https://www.space.com/nasa-3d-printed-habitat-competition-winners.html

https://www.pbs.org/benfranklin/l3_world_letters.html

https://eyes.nasa.gov/dsn/dsn.html

https://www.universetoday.com/148524/new-receiver-will-boost-interplanetary-communication/amp/

https://www.forbes.com/sites/startswithabang/2020/01/02/no-we-still-cant-use-quantum-entanglement-to-communicate-faster-than-light/?sh=3a80a9c74d5d

https://www.livescience.com/building-a-wormhole-with-cosmic-strings.html

