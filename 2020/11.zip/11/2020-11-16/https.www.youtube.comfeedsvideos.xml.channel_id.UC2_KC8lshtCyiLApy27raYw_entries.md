# Source:KnowledgeHusk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw, language:en-US

## Cloud Gaming Will Replace Your Console
 - [https://www.youtube.com/watch?v=6UDiIBwekXI](https://www.youtube.com/watch?v=6UDiIBwekXI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw
 - date published: 2020-11-16 00:00:00+00:00

Clouds are fun, fluffy and nice
They’re vapid stare, how do entice?
But heed its call for coming soon,
The cloud is me, the cloud is you

Watch the video it’s about stuff I won’t spoil it here. 
Twitter: https://twitter.com/KnowledgeHubTy
Soundcloud: https://soundcloud.com/user-503704039
Patreon: https://www.patreon.com/theknowledgehub
Second Channel: https://www.youtube.com/channel/UC-KL04Ra6E1Du0pFawN4pWg
Spotify: https://open.spotify.com/artist/3STpelEilrthF8UxsQTaaw?si=52TH_ZKTQhaKhfnK1Jomfg
My rss website: www.borfed.com

Footage Credits
Digital foundry
TechLipton

