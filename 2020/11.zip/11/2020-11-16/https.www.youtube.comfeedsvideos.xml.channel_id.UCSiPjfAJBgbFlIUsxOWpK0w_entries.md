# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## The thing about...hot tub
 - [https://www.youtube.com/watch?v=JxBmSuAeX68](https://www.youtube.com/watch?v=JxBmSuAeX68)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2020-11-16 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 Watch the "Hot Tub" music video: https://www.youtube.com/playlist?list=PLiJey_76CkNRnt5NrZrtWifPvejfEiu5V
Watch "Letting go of the past..." https://youtu.be/FS11NXfnndM

Listen to the song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

