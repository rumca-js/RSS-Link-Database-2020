# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Alisa Childers: The Dangers of Progressive Christianity
 - [https://www.youtube.com/watch?v=PI-zuOhptpU](https://www.youtube.com/watch?v=PI-zuOhptpU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-11-17 00:00:00+00:00

Today on The Babylon Bee Podcast, Kyle and Ethan talk to Alisa Childers, who first gained fame by being in the Christian Pop band, ZOEgirl. Alisa has since moved on from music into becoming a Christian Apologist with her own podcast and her debut book, Another Gospel?, available wherever you find books. 

Alisa’s apologist story began when she discovered her Pastor was a self proclaimed “Hopeful Agnostic” thus leading her on a journey of discovering historic Christianity and the true meaning of rap core. Ethan and Kyle receive all the CCM back stories including that of the mysterious Carman. 

Subscribe on iTunes: https://podcasts.apple.com/us/podcast/the-babylon-bee/id1468715531

Gain Access to the Exclusive Content and Writing Forum: https://babylonbee.com/plans

The Official Babylon Bee Store: https://shop.babylonbee.com

Follow The Babylon Bee:
Website: https://babylonbee.com
Twitter: http://twitter.com/thebabylonbee
Facebook: http://facebook.com/thebabylonbee
Instagram: http://instagram.com/thebabylonbee

## Parents Conflicted On Letting Daughter Go To Satan Concert
 - [https://www.youtube.com/watch?v=FqH3tB0qCOk](https://www.youtube.com/watch?v=FqH3tB0qCOk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-11-17 00:00:00+00:00

Peter and Martha are caught off guard when their teenager daughter desperately wants to go to a big pop music concert with her friend Stephanie. The headliner? Satan himself. What do they decide? Can Satan drop a sick beat? Watch to find out.

FULL SONG: https://youtu.be/GzzXRVkwnEk

## SATAN: KYP FULL SONG
 - [https://www.youtube.com/watch?v=GzzXRVkwnEk](https://www.youtube.com/watch?v=GzzXRVkwnEk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-11-17 00:00:00+00:00

This is a companion video to this original video: https://youtu.be/FqH3tB0qCOk

## The New Babylon Bee Best-Of Collection Has Finally Arrived!
 - [https://www.youtube.com/watch?v=FQlZxZcSS3s](https://www.youtube.com/watch?v=FQlZxZcSS3s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-11-17 00:00:00+00:00

Kyle and Ethan crack open their new book: The Sacred Texts of the Babylon Bee. This is an exclusive look at the Bee's first best-of collection, which contains all-new content, redone Photoshops, bonus sidebars and infographics, and more. It's all packaged in a beautiful, Bible-like cover on glossy pages with glorious, gilded edges. Enjoy.

See the full show here:
https://youtu.be/kienRburY9g

Subscribe to the Babylon Bee to watch the Bee writers laugh at their own jokes some more.

Hit the bell to get your daily dose of fake news that you can trust.

## Alisa Childers on The Babylon Bee Podcast | Preview
 - [https://www.youtube.com/watch?v=QGTsa9SNZJY](https://www.youtube.com/watch?v=QGTsa9SNZJY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-11-16 00:00:00+00:00

🎙 Tomorrow Alisa Childers joins Kyle and Ethan on The Babylon Bee podcast.

SUBSCRIBE TODAY! ▶️ http://bit.ly/TheBeeYouTube

