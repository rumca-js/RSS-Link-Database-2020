# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Who are you REALLY?! | Russell Brand
 - [https://www.youtube.com/watch?v=oAG6cX_nPKc](https://www.youtube.com/watch?v=oAG6cX_nPKc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-11-17 00:00:00+00:00

A clip from my Under The Skin podcast with Gabrielle Bernstein, discussing the Internal Family Systems therapy she has benefitted from greatly. 
You can listen to the rest of this podcast on Luminary: http://luminary.link/russell

Check out more of my podcast videos here: https://www.youtube.com/playlist?list=PL5BY9veyhGt7eapYiWXyxGuSxTcysPpJ7

This week’s guest is Gabrielle Bernstein! Gabrielle is an American motivational speaker, life coach and New York Times best-selling author of The Universe Has Your Back: Transform Fear to Faith and Super Attractor: Methods for Manifesting a Life Beyond Your Wildest Dreams.

On January 1st, Gabby will be leading a 21 day manifesting challenge. A step-by-step how to feel good while you turn what you want into the life you live using the manifesting methods Gabby uses everyday. You’ll discover how to act in alignment with the energy of the Universe, allowing good things to flow to you easily and naturally. 

Link to waitlist: gabbybernstein.com/manifestingchallenge-waitlist/

gabbybernstein.com
Twitter: @gabbybernstein
Instagram: @gabbybernstein

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

