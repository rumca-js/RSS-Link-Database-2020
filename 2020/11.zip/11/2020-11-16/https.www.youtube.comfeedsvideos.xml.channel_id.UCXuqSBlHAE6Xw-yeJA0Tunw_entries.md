# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Can you GAME on a Cheap Wireless Keyboard?
 - [https://www.youtube.com/watch?v=QonFAjANnxU](https://www.youtube.com/watch?v=QonFAjANnxU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-11-17 00:00:00+00:00

Visit https://www.squarespace.com/LTT and use offer code LTT for 10% off

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire

Is it time to cut the cord? This roundup of Amazon’s best selling cheap wireless keyboards should give you all the info you need to make the call.

Buy Goose Enterprises LagMeter
On Amazon (PAID LINK): https://geni.us/Lagmeter

Buy Logitech MK345 Wireless Combo
On Amazon (PAID LINK): https://geni.us/PNLG9xc
On Newegg (PAID LINK): https://geni.us/6CNL4y0
On B&H (PAID LINK): https://geni.us/cBlK
On Best Buy (PAID LINK): https://geni.us/sHFW6

Buy Logitech K350 Wireless Wave
On Amazon (PAID LINK): https://geni.us/PqszWi
On Newegg (PAID LINK): https://geni.us/ABMhKtN
On B&H (PAID LINK): https://geni.us/8LlkY4g
On Best Buy (PAID LINK): https://geni.us/evTV7Rz

Buy Arteck 2.4G Wireless Keyboard
On Amazon (PAID LINK): https://geni.us/eqJAI
On Newegg (PAID LINK): https://geni.us/hV40

Buy KLIM Chroma Wireless
On Amazon (PAID LINK): https://geni.us/cw5pq
On Newegg (PAID LINK): https://geni.us/KYrh

Buy DREVO Calibur 71-Key
On Amazon (PAID LINK): https://geni.us/A22KFlv
On Newegg (PAID LINK): https://geni.us/J7YEp

Buy FELICON Wireless Keyboard and Mouse Combo
On Amazon (PAID LINK): https://geni.us/rzwOo
On Newegg (PAID LINK): https://geni.us/CipIA

Buy Soke-Six Waterproof Multimedia Keyboard
On Amazon (PAID LINK): https://geni.us/56nW

Buy F1 Wireless Keyboard Mouse Combo
On Amazon (PAID LINK): https://geni.us/rVx8Lm

Buy LexonElec Wireless Keyboard Mouse Combo Gamer HK1600
On Amazon (PAID LINK): https://geni.us/Qodm8fJ

Buy Langtu LT600 Combo
On Amazon (PAID LINK): https://geni.us/BEincm

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1270242-can-you-game-on-a-cheap-wireless-keyboard/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Official Game Store: https://www.nexus.gg/ltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

## The Fastest Gaming PC is now AMD!
 - [https://www.youtube.com/watch?v=Qa0jZnrQrIA](https://www.youtube.com/watch?v=Qa0jZnrQrIA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-11-16 00:00:00+00:00

Thanks to Bitdefender for sponsoring this video! 
Keep your devices secure and learn more about Bitdefender at:
https://lmg.gg/4GFYy

With AMD's release of the 5000 series of CPUs, it was only a matter of time our cryo cooled  Intel system would be dwarfed. But we WERE NOT expecting this system From Digital Storm to grace us. It is glorious. 


Buy AMD Ryzen 5950X: https://geni.us/N9gsulv

Buy MSI MEG Godlike x570: https://geni.us/NOUd

Buy Corsair Dominator 3200MHz 64GB: https://geni.us/ryS24M

Buy Nvidia RTX 3090: https://geni.us/Crq7O

Buy Ironwolf 10TB HDD: https://geni.us/YC9eXyh

Buy AlphaCool Watercooling Fittings: https://geni.us/w1p1YQ

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://lmg.gg/dQKYh

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

