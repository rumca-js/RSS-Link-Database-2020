## Mac certificate check stokes fears that Apple logs every app you run
 - [https://arstechnica.com/gadgets/2020/11/mac-certificate-check-stokes-fears-apple-logs-every-app-you-run/](https://arstechnica.com/gadgets/2020/11/mac-certificate-check-stokes-fears-apple-logs-every-app-you-run/)
 - RSS feed: https://arstechnica.com
 - date published: 2020-11-16 20:12:04+00:00

Mac certificate check stokes fears that Apple logs every app you run

