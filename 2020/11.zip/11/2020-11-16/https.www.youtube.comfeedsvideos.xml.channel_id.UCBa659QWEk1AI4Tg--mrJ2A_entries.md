# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## I Almost Learned To Fly A Jetpack
 - [https://www.youtube.com/watch?v=IsWJKyR664s](https://www.youtube.com/watch?v=IsWJKyR664s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2020-11-16 00:00:00+00:00

Gravity Industries make jetpacks. They're not practical. They're not meant for mass use. But they are a lot of fun. They asked if I wanted to try flying one. Thanks to https://gravity.co/ - this is not sponsored but, obviously, they did give me a flight in a jetpack.

Gravity's YouTube channel: https://www.youtube.com/channel/UCkHr2Z0JWH8KGmQNDp4QXLw
Pilot Sam landing on my hand: https://www.youtube.com/watch?v=-Ch2vHah_Os

Filmed safely: https://www.tomscott.com/safe/

Camera by Simon Temple http://templefreelance.co.uk/
Edited by Michelle Martin @mrsmmartin
Audio mix by Graham Haerther

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

