# Source:Roosevelt, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqqY6fzyLY3OmdjYRe2eJAg, language:en-US

## Roosevelt - Feels Right (Gerd Janson Remix)
 - [https://www.youtube.com/watch?v=syiG3Df8unQ](https://www.youtube.com/watch?v=syiG3Df8unQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqqY6fzyLY3OmdjYRe2eJAg
 - date published: 2020-11-17 00:00:00+00:00

'POLYDANS' - my new album - out now! Stream / Purchase here: https://roosevelt.lnk.to/Polydans

The Gerd Janson Remix of 'Feels Right' Is Out Now - Stream / Purchase here:  https://roosevelt.lnk.to/FeelsRightRemix

FOLLOW Roosevelt on Facebook, Instagram and more https://roosevelt.lnk.to/follow
Website : https://roosevelt.lnk.to/website 

This is the Official Youtube Channel for Roosevelt. 
SUBSCRIBE NOW to be kept up to date with the latest music, videos, tour dates, behind the scenes footage and more https://roosevelt.lnk.to/subscribe

MUSIC CREDITS
Written, Performed, Recorded and Produced by Marius Lauber 
Additional Production by Gerd Janson
Mixed and Mastered by Lopazz

LYRICS

all of the lights
will fade into the dark of night
but all that aside
we'll be the ones who come alive

let's do it again
we can run into the dusk of dawn
time to pretend
it ain't that hard to carry on

there's nothing i can say
tonight
all i really know
it feels right

nothing i can do
so hold tight
all i really know
it feels right
it feels right
it feels right
it feels right

we're late for the show
yeah now the race is almost run
cause before you know
we'll set into the morning sun
let's do it again
we can run into the dusk of dawn
time to pretend
it ain't that hard to carry on

there's nothing i can say
tonight
all i really know
it feels right

nothing i can do
so hold tight
all i really know
it feels right
it feels right
it feels right
it feels right

there's nothing i can say
all i really know
nothing i can do
all i really know
it feels right, it feels right

there's nothing i can say
tonight
all i really know
it feels right

nothing i can do
so hold tight
all i really know
it feels right
it feels right

℗ & © Greco-Roman / City Slang

