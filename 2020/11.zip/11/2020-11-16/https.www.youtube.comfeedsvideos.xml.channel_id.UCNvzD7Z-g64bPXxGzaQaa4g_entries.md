# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## COD: Black Ops Cold War - Top 10 Secrets & Easter Eggs
 - [https://www.youtube.com/watch?v=5tYP_cwoyeg](https://www.youtube.com/watch?v=5tYP_cwoyeg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-11-16 00:00:00+00:00

Call of Duty Black Ops: Cold War is filled with tons of awesome secrets, Easter Eggs, and references. Here are some of the best.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Sources:
https://www.reddit.com/r/blackopscoldwar/comments/jgxpc2/took_a_closer_look_at_the_backgrounds_of_the_main/

https://www.youtube.com/watch?v=0qvPiUTbevo

