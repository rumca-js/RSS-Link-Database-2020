# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## The FUTURE of VR Gloves is coming
 - [https://www.youtube.com/watch?v=kcGGPIvWOXM](https://www.youtube.com/watch?v=kcGGPIvWOXM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-11-17 00:00:00+00:00

Hello and welcome to TUESDAY NEWSDAY! Your number one resource for the entire weeks worth of VR news. Today I have a bunch of really exciting topics to cover from the newest Oculus Quest 2 update unlocking some awesome features to a new set of VR gloves that are being built for extremely cheap. Hope you enjoy this weeks of VR NEWS!

My links:
2nd Channel:
https://youtu.be/Xp-p5RGoGpM
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker
GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill

Big thanks to Ridge for supporting the channel! Here’s the site if you
want to check them out!  ridge.com/THRILL + 10% off.

Sources:
https://www.engadget.com/cornell-stretchable-skin-sensor-for-vr-robots-155317989.html
https://futurism.com/stretchable-sensor-vr-touch
https://www.roadtovr.com/leaked-capcom-resident-evil-4-vr-oculus/
https://www.theverge.com/2020/11/16/21570662/the-void-disney-star-wars-vr-arcade-loan-default
https://www.roadtovr.com/oculus-quest-2-90hz-oculus-link/
https://news.cornell.edu/stories/2020/11/stretchable-sensor-gives-robots-and-vr-human-touch
https://uploadvr.com/vr-ears-delay-2021/
https://uploadvr.com/half-life-alyx-vr-awards/
https://www.reddit.com/r/VR_memes/comments/jum96e/looking_through_the_bottom_of_the_headset_be_like/

Smarter Every Day video: https://www.youtube.com/watch?v=OK2y4Z5IkZ0&t=3s

