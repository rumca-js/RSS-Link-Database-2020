# Source:Olden days, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC1gVCrX5uEFc0s_8TIYGqmw, language:en-US

## Itto Ryu Demonstration in Kyoto 1897 - [ 60 FPS - Color - 4K ] - Old footage restoration with AI
 - [https://www.youtube.com/watch?v=nmYIdHKjKlM](https://www.youtube.com/watch?v=nmYIdHKjKlM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1gVCrX5uEFc0s_8TIYGqmw
 - date published: 2020-11-17 00:00:00+00:00

Kata Training from Ono ha Itto Ryu Kenjutsu style.
Shot by Constant Girel

Ittō-ryū (一刀流), meaning "one-sword school", is the ancestor school of several Japanese Koryū kenjutsu styles. Ono-ha Ittō-ryū (小野派一刀流) is the oldest of the many Ittō-ryū styles which branched off from Ittosai Kagehisa's original art. It continues to be one of the most influential of the traditional kenjutsu styles today, exerting a major influence, along with Hokushin branch, upon modern kendo's kata, tactics, and aesthetic.

Thank you to all who commented below and pointed out that this is not Kendo training. Unfortunately I cannot change text on the video itself, but title and description has been updated.

Wikipedia:
🔗 https://en.wikipedia.org/wiki/Itt%C5%8D-ry%C5%AB

Original video was processed with Deep Learning algorithms to achieve modern look and quality. Here is the process:

1. Footage stabilization and noise/dust/scratches removal with After Effects and Neat Video ✔️
🔗 https://www.neatvideo.com/?linkID=p7845
2. Restoration with DeepRemaster, removing scratches and film damage ✔️
🔗 https://github.com/satoshiiizuka/siggraphasia2019_remastering
3. Frame interpolation to get smooth look using DAIN method. Result is 60 FPS video ✔️
🔗 https://github.com/baowenbo/DAIN
4. Colorization using DeOldify with NoGAN. Colors are not accurate, only for ambient mood ✔️
🔗 https://github.com/jantic/DeOldify
5. Upscaling using Topaz Video Enhance AI, upscale preserving detail and reducing noise ✔️
🔗 https://topazlabs.com/video-enhance-ai/ref/755/
⭐⭐⭐ 15% DISCOUNT CODE: oldendays15
6. Automation with Python scripts and AWS Thinkbox Deadline as queue manager ✔️
🔗 https://www.awsthinkbox.com/deadline
7. RTX 2070 Super 8GB, 32GB RAM, Ryzen 9 3900X 12-core. Approx 48hrs/10min video processing.

🎵 Intro Music:
Timelapse by boomopera
https://1.envato.market/om6ao

Social Media:
https://www.facebook.com/oldendayschannel
https://www.twitter.com/OldenDaysYT
https://www.instagram.com/oldendayschannel
https://www.pinterest.ca/OldenDaysYT/old-footage-restoration
https://www.patreon.com/oldendays

#deoldify #colorize #upscale #topazlabs #veai #dain #60fps #4k

## Alpine Hunters funny Boxing Training- [ 60 FPS - Color - 4K ] - Old footage restoration with AI
 - [https://www.youtube.com/watch?v=KFOxniYnU0M](https://www.youtube.com/watch?v=KFOxniYnU0M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1gVCrX5uEFc0s_8TIYGqmw
 - date published: 2020-11-16 00:00:00+00:00

The alpine hunters are the elite mountain infantry force of the French Army. They are trained to operate in mountainous terrain and in urban warfare. First corps were created in 1888.

This particular boxing is called Savate, a French kickboxing combat sport that uses the hands and feet as weapons combining elements of English boxing with graceful kicking techniques.

Wikipedia:
🔗 https://en.wikipedia.org/wiki/Chasseurs_Alpins
🔗 https://en.wikipedia.org/wiki/Savate

Original video was processed with Deep Learning algorithms to achieve modern look and quality. Here is the process:

1. Footage stabilization and noise/dust/scratches removal with After Effects and Neat Video ✔️
🔗 https://www.neatvideo.com/?linkID=p7845
2. Restoration with DeepRemaster, removing scratches and film damage ✔️
🔗 https://github.com/satoshiiizuka/siggraphasia2019_remastering
3. Frame interpolation to get smooth look using DAIN method. Result is 60 FPS video ✔️
🔗 https://github.com/baowenbo/DAIN
4. Colorization using DeOldify with NoGAN. Colors are not accurate, only for ambient mood ✔️
🔗 https://github.com/jantic/DeOldify
5. Upscaling using Topaz Video Enhance AI, upscale preserving detail and reducing noise ✔️
🔗 https://topazlabs.com/video-enhance-ai/ref/755/
⭐⭐⭐ 15% DISCOUNT CODE: oldendays15
6. Automation with Python scripts and AWS Thinkbox Deadline as queue manager ✔️
🔗 https://www.awsthinkbox.com/deadline
7. RTX 2070 Super 8GB, 32GB RAM, Ryzen 9 3900X 12-core. Approx 48hrs/10min video processing.

🎵 Intro Music:
Timelapse by boomopera
https://1.envato.market/om6ao

Social Media:
https://www.facebook.com/oldendayschannel
https://www.twitter.com/OldenDaysYT
https://www.instagram.com/oldendayschannel
https://www.pinterest.ca/OldenDaysYT/old-footage-restoration
https://www.patreon.com/oldendays

#deoldify #colorize #upscale #topazlabs #veai #dain #60fps #4k

