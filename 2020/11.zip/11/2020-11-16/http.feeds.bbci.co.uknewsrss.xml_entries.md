# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## ECB accused by two former umpires of 'institutionalised racism'
 - [https://www.bbc.co.uk/sport/cricket/54955330](https://www.bbc.co.uk/sport/cricket/54955330)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-16 23:44:54+00:00

The England and Wales Cricket Board is accused by two former umpires of "institutionalised racism".

## The Crown: Charles and Diana actors speak to BBC Breakfast about series four
 - [https://www.bbc.co.uk/news/entertainment-arts-54964918](https://www.bbc.co.uk/news/entertainment-arts-54964918)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-16 16:17:33+00:00

The hotly anticipated new series The Crown is now on Netflix and its stars have been on BBC Breakfast to talk about the emerging storyline of Charles and Diana's 'love story'

## Moderna: Covid vaccine shows nearly 95% protection
 - [https://www.bbc.co.uk/news/health-54902908](https://www.bbc.co.uk/news/health-54902908)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-16 12:44:44+00:00

The results add to growing confidence that vaccination can end the pandemic.

## I'm A Celebrity: How Hollie Arnold got her MBE
 - [https://www.bbc.co.uk/news/newsbeat-54959671](https://www.bbc.co.uk/news/newsbeat-54959671)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-16 12:44:19+00:00

The athlete introduced herself with her full title last night. Here's all you need to know about her.

## Coronavirus: Germany hails couch potatoes in new videos
 - [https://www.bbc.co.uk/news/world-europe-54959871](https://www.bbc.co.uk/news/world-europe-54959871)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-16 12:44:12+00:00

One advert depicts an elderly man looking back on the winter of 2020, while saying "we did nothing".

## Covid 19: Boris Johnson feeling 'great' as self-isolation begins
 - [https://www.bbc.co.uk/news/uk-54956076](https://www.bbc.co.uk/news/uk-54956076)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-16 12:21:08+00:00

The PM and five Tory MPs have been told to self-isolate by Test and Trace after a No 10 meeting.

## 'Millions of dental treatments missed' in pandemic
 - [https://www.bbc.co.uk/news/health-54933313](https://www.bbc.co.uk/news/health-54933313)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-16 12:12:40+00:00

The British Dental Association warns there will be "an oral health crisis” without government support.

## Baccara would re-record Yes Sir, I Can Boogie as Scotland anthem
 - [https://www.bbc.co.uk/news/uk-scotland-54951970](https://www.bbc.co.uk/news/uk-scotland-54951970)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-16 11:54:59+00:00

The disco classic's singers say they would be happy to make a new version after it was adopted by the Scotland team.

## The Masters 2020: Rory McIlroy, Patrick Reed & Jon Rahm - shots of the tournament
 - [https://www.bbc.co.uk/sport/av/golf/54954535](https://www.bbc.co.uk/sport/av/golf/54954535)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-16 11:54:26+00:00

Rory McIlroy, Patrick Reed and Jon Rahm produced some of the most memorable moments of the 2020 Masters - watch the best shots of the tournament.

## Capcom hack: Up to 350,000 people's information stolen
 - [https://www.bbc.co.uk/news/technology-54958782](https://www.bbc.co.uk/news/technology-54958782)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-16 11:54:18+00:00

Up to 350,000 customers and staff could have had their information stolen in a ransomware attack.

## Des O'Connor: Tributes paid to 'gentle' entertainer
 - [https://www.bbc.co.uk/news/entertainment-arts-54958323](https://www.bbc.co.uk/news/entertainment-arts-54958323)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-16 11:53:30+00:00

Ant and Dec are among the stars to have praised the much-loved TV show host, who has died aged 88.

## Brexit: PM confident UK 'will prosper' without EU trade deal
 - [https://www.bbc.co.uk/news/uk-politics-54958343](https://www.bbc.co.uk/news/uk-politics-54958343)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-16 11:18:41+00:00

Boris Johnson's comments come ahead of another week of negotiations for a post-Brexit trade deal.

## Further NI Covid restrictions 'needed mid-December'
 - [https://www.bbc.co.uk/news/uk-northern-ireland-54958483](https://www.bbc.co.uk/news/uk-northern-ireland-54958483)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-16 11:00:05+00:00

NI's chief scientific adviser says it is "more likely than not" that measures will be recommended.

## Turnip Prize 2020: Finalists for spoof art award unveiled
 - [https://www.bbc.co.uk/news/uk-england-somerset-54959423](https://www.bbc.co.uk/news/uk-england-somerset-54959423)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-16 10:57:47+00:00

Entries for the competition that pokes fun at the Turner Prize include a bundle of fur.

## Covid: Visitor tests in all care homes in England 'by Christmas'
 - [https://www.bbc.co.uk/news/uk-54959012](https://www.bbc.co.uk/news/uk-54959012)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-16 10:27:41+00:00

The government says it's working closely with the social care sector to roll out testing across the country.

## Clintons boss: Supermarkets selling greeting cards 'grossly unfair'
 - [https://www.bbc.co.uk/news/business-54958189](https://www.bbc.co.uk/news/business-54958189)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-16 10:05:12+00:00

Supermarkets should not be able to sell non-essential goods in lockdown, says boss of Clintons cards.

## Autumn Nations Cup: Sexton and Henshaw out of Ireland's England game
 - [https://www.bbc.co.uk/sport/rugby-union/54959434](https://www.bbc.co.uk/sport/rugby-union/54959434)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-16 10:04:53+00:00

Johnny Sexton and Robbie Henshaw will miss Ireland's Autumn Nations Cup game against England on Saturday because of injury.

## New Zealand crowns chubby cute parrot bird of the year
 - [https://www.bbc.co.uk/news/world-asia-54957834](https://www.bbc.co.uk/news/world-asia-54957834)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-16 07:52:42+00:00

All eyes on the US election? Well, here's another vote, equally contested, though a lot cuter.

## Newspaper headlines: 'No 10 reset in disarray' as PM self-isolates
 - [https://www.bbc.co.uk/news/blogs-the-papers-54954833](https://www.bbc.co.uk/news/blogs-the-papers-54954833)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-16 05:59:02+00:00

Monday's papers lead with news that Boris Johnson is self-isolating ahead of a "crucial" week at No 10.

## Manchester University student 'traumatised' by 'racial profiling' incident
 - [https://www.bbc.co.uk/news/uk-54954602](https://www.bbc.co.uk/news/uk-54954602)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-16 01:16:26+00:00

The University of Manchester says it has suspended security guards who stopped Zac Adan on campus.

## Nasa SpaceX launch: Astronaut crew heads to orbit
 - [https://www.bbc.co.uk/news/science-environment-54938444](https://www.bbc.co.uk/news/science-environment-54938444)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-16 00:44:12+00:00

A team of four leaves Florida on a SpaceX rocket and capsule, bound for the orbiting laboratory.

## Inventors design high-tech helmets for Covid protection
 - [https://www.bbc.co.uk/news/business-54916159](https://www.bbc.co.uk/news/business-54916159)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-16 00:03:26+00:00

For two months, Yezin Al-Qaysi has been riding the Toronto subway wearing a huge black "mad helmet".

## Covid-19: 'My pandemic work with dangerous prison leavers'
 - [https://www.bbc.co.uk/news/uk-wales-54795465](https://www.bbc.co.uk/news/uk-wales-54795465)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-16 00:01:42+00:00

Covid-19 has forced the probation service to change how it monitors high-risk offenders.

## The story of Britain's Black Power movement
 - [https://www.bbc.co.uk/news/uk-54953249](https://www.bbc.co.uk/news/uk-54953249)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-16 00:00:44+00:00

Two former activists describe how they looked to America for inspiration.

## Photographer Rankin hopes his new exhibition will spark conversations about death
 - [https://www.bbc.co.uk/news/entertainment-arts-54933747](https://www.bbc.co.uk/news/entertainment-arts-54933747)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-16 00:00:35+00:00

Famed photographer Rankin hopes his latest exhibition, Lost For Words, will encourage conversations about death

## Devon village create 'safari trail' for local children
 - [https://www.bbc.co.uk/news/uk-54910626](https://www.bbc.co.uk/news/uk-54910626)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-16 00:00:28+00:00

A Devon village has come up with a creative way to fundraise for their local primary school.

## Hampshire doctor claims Mars ownership using lasers
 - [https://www.bbc.co.uk/news/uk-england-hampshire-54930207](https://www.bbc.co.uk/news/uk-england-hampshire-54930207)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-16 00:00:22+00:00

Phil Davies leads a global campaign to claim ownership of the planet by improving its atmosphere.

