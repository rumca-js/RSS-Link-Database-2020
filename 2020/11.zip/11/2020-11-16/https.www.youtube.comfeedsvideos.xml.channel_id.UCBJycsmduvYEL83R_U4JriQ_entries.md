# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Apple M1 Mac Review: Time to Recalibrate!
 - [https://www.youtube.com/watch?v=f4g2nPY-VZc](https://www.youtube.com/watch?v=f4g2nPY-VZc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-11-17 00:00:00+00:00

The Macbook with M1 chip is... different. Time to think a little different about laptops.

That shirt: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Equilibre by Hocus Pocus
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Laptop provided by Apple for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

