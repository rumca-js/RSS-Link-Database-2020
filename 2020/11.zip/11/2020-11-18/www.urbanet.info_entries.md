## Why Smart Cities Threaten Citizens’ Right to Privacy
 - [https://www.urbanet.info/why-smart-city-data-treatens-citizens-right-to-privacy/](https://www.urbanet.info/why-smart-city-data-treatens-citizens-right-to-privacy/)
 - RSS feed: www.urbanet.info
 - date published: 2020-11-18 12:04:50+00:00



