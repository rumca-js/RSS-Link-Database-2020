# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## 11 lat piekła
 - [https://tvn24.pl/go/programy,7/za-zamknietymi-drzwiami--odcinki,390008/odcinek-1,S00E01,401815?source=rss](https://tvn24.pl/go/programy,7/za-zamknietymi-drzwiami--odcinki,390008/odcinek-1,S00E01,401815?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2020-11-18 07:02:00+00:00

<img alt="11 lat piekła" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qttlr0-przemoc-4762888/alternates/LANDSCAPE_1280" />
    Reportaż Darii Górki.

