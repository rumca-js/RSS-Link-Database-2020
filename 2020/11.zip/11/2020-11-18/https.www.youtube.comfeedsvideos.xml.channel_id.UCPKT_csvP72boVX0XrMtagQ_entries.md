# Source:Cercle, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ, language:en-US

## Joris Delacroix - Aiguilhe | Cercle Stories
 - [https://www.youtube.com/watch?v=isRRJOpF4Co](https://www.youtube.com/watch?v=isRRJOpF4Co)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ
 - date published: 2020-11-19 00:00:00+00:00

Joris Delacroix for a Cercle Stories in Aiguilhe at Rocher Saint-Michel, France.  
Cercle Stories is our new short video concept, it's a one track live session for our Cercle Records releases. 

☞ Cercle Records: 
Joris Delacroix - Aiguilhe: The track is part of the limited edition vinyl compilation available NOW! More info here: https://Cercle.lnk.to/vinyls

https://Cercle.lnk.to/Aiguilhejorisdelacroix

☞ Support us and get access to exclusive videos & perks: https://Cercle.lnk.to/Patreon
☞ Listen to our playlists, tracks & sets: https://Cercle.lnk.to/Playlists
☞ Subscribe to our newsletter to know about our next shows: https://Cercle.lnk.to/Members
☞ Subscribe to our YouTube channel: Cercle.lnk.to/ytcercle

☞ Joris Delacroix
https://www.instagram.com/joris_delacroix/
https://www.facebook.com/jorisdelacroix
https://open.spotify.com/artist/3HRRzIZNQFus3xlUx2xKy1?si=-OBLhVWyTXuOAOa8tkeZcQ
https://music.apple.com/fr/artist/joris-delacroix/292956083?l=en

Video credits:

Artist: Joris Delacroix
Location: Aiguilhe, Rocher Saint-Michel, France
Producer: Derek Barbolla
Artistic director: Philippe Tuchmann
Director: Pol Souchier
DOP, Editing & Post-production: Mathieu Glissant (Saison Unique Production)
Cameraman: Mathieu Glissant
Drone pilot: Simon Bourrat (Wild Air Pictures) 
Production team: Anaïs de Framond, Dan Aufseesser, Armand Prouhèze
Technical Manager: Aurélien Moisan
Communication: Anaëlle Rouquette


--
Special thanks to:
Sébastien Falcon from Aiguilhe. 
Galerie Joseph. 


______

Follow us on http://www.cercle.io

