# Source:Vlog Casha, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg, language:pl-PL

## PODWODNE MIASTO W TURCJI - HASANKEYF
 - [https://www.youtube.com/watch?v=g_Ayf-c0jgs](https://www.youtube.com/watch?v=g_Ayf-c0jgs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg
 - date published: 2020-11-19 00:00:00+00:00

🗺️ Turcja 2020 #13. Podczas swojej podróży po wschodniej Turcji natrafiłem na miasto, które zaledwie kilka miesięcy temu zostało całkowicie zalane.
Wejdź na https://surfshark.deals/CASH i użyj kodu "Cash" aby zyskać 84% zniżki i 4 miesiące za darmo!

❗ Zostań Patronem kanału! 
https://patronite.pl/vlogcasha

💵 Zniżka do 250 zł na nocleg z Airbnb: https://bit.ly/2U7dVqY

Materiały z drona dzięki uprzejmości:
- @MuharremKARAKAS 
- Ercan Alan

Vlogi z Turcji (2019-2020): https://bit.ly/31VPCR3
Vlogi z Kolumbii: https://bit.ly/36tqlhH
🌏 Vlogi z Azji Płd-Wsch: https://bit.ly/2wrM9t2
🇦🇺 Vlogi z Australii: https://bit.ly/2OJWYOy
🇺🇸 Vlogi z życia i podróży w USA: https://bit.ly/2ya73NV
🚙Vlogi z autostopu 2018: https://bit.ly/2NbHzos

▸ Instagram: https://www.instagram.com/vlogcasha
▸ Facebook: https://www.facebook.com/vlogcasha/
▸ "Grupa Casha" na FB: https://bit.ly/2N1a6wX

#PodróżeCasha #CashWTurcji #Turcja

