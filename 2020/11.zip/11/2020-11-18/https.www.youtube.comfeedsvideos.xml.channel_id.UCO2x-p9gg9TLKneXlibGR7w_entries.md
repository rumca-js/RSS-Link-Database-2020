# Source:Snazzy Labs, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w, language:en-US

## The Problem with iPhone MagSafe...
 - [https://www.youtube.com/watch?v=eMRdlpJX2KQ](https://www.youtube.com/watch?v=eMRdlpJX2KQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w
 - date published: 2020-11-18 00:00:00+00:00

The iPhone 12’s MagSafe is nice quality-of-life improvement, but it’s not as perfect as Apple wants us to believe it is.
Check out the RAVPower 65W GaN 4-Port Charger - https://amzn.to/2TwckKJ
Use the on-page coupon and my promo code RF8D4I23 to reduce the price to just $34.99 until 11/22/2020!

Subscribe to my podcast Flashback! - http://relay.fm/flashback
Follow me on Twitter - http://twitter.com/snazzyq
Follow me on Instagram - http://instagram.com/snazzyq

The iPhone 12 released to much fanfare with a new form factor in the iPhone 12 mini and iPhone 12 Pro Max. Along with a new squared-edge design, one of the headlining features was the return of Apple’s famous MagSafe brand; however, rather than being the MacBook-friendly charge port that would prevent your computer from falling off of a countertop, this new iPhone MagSafe design permits the usage of handy magnetic accessories like the iPhone MagSafe charger and MagSafe cases, MagSafe car mounts, and other MagSafe accessories. But there’s a problem with MagSafe. It’s just... well... it’s limited by physics. How has Apple tried to combat some of these hurdles and how has their selection in magnet chemistry, placement, surface area, and depth affected how strong these magnets attach? Let’s find out today as we learn about magnets, shear force, pull force, plating, and what that means for the best iPhone MagSafe accessories!

