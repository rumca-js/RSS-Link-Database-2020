# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## iPhone 12 Pro Max nagrywa tak! Fasolki Samsung Buds Live, nowe mikrofony Shure MV7, MV5C i Super 73
 - [https://www.youtube.com/watch?v=xHQv1S_SYV8](https://www.youtube.com/watch?v=xHQv1S_SYV8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-11-18 00:00:00+00:00

Jeżeli ten film nie jest w 4K to dlatego, że jestem niecierpliwi i udostępniłem go Wam zanim się do końca przetworzył. iPhone'a do testów pożyczył mi OleOle (https://bit.ly/36F31Os), dzięki!
Błąd w 6:09 zostawiłem z pełną premedytacją, ponieważ powtarzał się przy eksporcie. Niech zostanie dla potomnych :)

Dziś w odcinku: 
Samsung Buds Live (ceneo): https://bit.ly/3pI4AEj
Shure MV7 (ceneo): https://bit.ly/3faeidu
Shure MV5C (strona producenta): https://bit.ly/38WfpN8
Super 73: https://super73.com

Pliki dźwiękowe, które oceniał Mieszko: https://mab.to/AuuhekooG

Mieszko: https://www.instagram.com/mahboob/
Maciek: https://bit.ly/3lJ4Ikd

