# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## The Crown - What Does It Tell Us About Truth? | Russell Brand
 - [https://www.youtube.com/watch?v=1Yky7ykK558](https://www.youtube.com/watch?v=1Yky7ykK558)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-11-19 00:00:00+00:00

Have you been watching #TheCrown? What do you think about it?
It has received some criticism that not everything portrayed is factual...but does that matter? Tell me what you think!

Here is the link to my article on Margaret Thatcher: https://www.theguardian.com/politics/2013/apr/09/russell-brand-margaret-thatcher

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

