# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Dry Cleaning - Conversation (Live on KEXP)
 - [https://www.youtube.com/watch?v=xEOpxiTsiXo](https://www.youtube.com/watch?v=xEOpxiTsiXo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-11-19 00:00:00+00:00

http://KEXP.ORG presents Dry Cleaning performing “Conversation” live in the KEXP studio. Recorded March 10, 2020.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Justin Wilmore & Scott Holpainen
Editor: Jim Beckmann

http://kexp.org
https://drycleaning.bandcamp.com

## Dry Cleaning - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=rLppqLxALfQ](https://www.youtube.com/watch?v=rLppqLxALfQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-11-19 00:00:00+00:00

http://KEXP.ORG presents Dry Cleaning performing live in the KEXP studio. Recorded March 10, 2020.

Songs:
Scratchcard Lanyard
Viking Hair
Magic Of Meghan
Conversation

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Justin Wilmore & Scott Holpainen
Editor: Jim Beckmann

http://kexp.org
https://drycleaning.bandcamp.com

## Dry Cleaning - Magic Of Meghan (Live on KEXP)
 - [https://www.youtube.com/watch?v=pCakuHhlgck](https://www.youtube.com/watch?v=pCakuHhlgck)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-11-19 00:00:00+00:00

http://KEXP.ORG presents Dry Cleaning performing “Magic Of Meghan” live in the KEXP studio. Recorded March 10, 2020.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Justin Wilmore & Scott Holpainen
Editor: Jim Beckmann

http://kexp.org
https://drycleaning.bandcamp.com

## Dry Cleaning - Scratchcard Lanyard (Live on KEXP)
 - [https://www.youtube.com/watch?v=zyjuJ6jLsxA](https://www.youtube.com/watch?v=zyjuJ6jLsxA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-11-19 00:00:00+00:00

http://KEXP.ORG presents Dry Cleaning performing “Scratchcard Lanyard” live in the KEXP studio. Recorded March 10, 2020.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Justin Wilmore & Scott Holpainen
Editor: Jim Beckmann

http://kexp.org
https://drycleaning.bandcamp.com

## Dry Cleaning - Viking Hair (Live on KEXP)
 - [https://www.youtube.com/watch?v=a2dQzZSaPHY](https://www.youtube.com/watch?v=a2dQzZSaPHY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-11-19 00:00:00+00:00

http://KEXP.ORG presents Dry Cleaning performing “Viking Hair” live in the KEXP studio. Recorded March 10, 2020.

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Justin Wilmore & Scott Holpainen
Editor: Jim Beckmann

http://kexp.org
https://drycleaning.bandcamp.com

## Marilina Bertoldi - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=5lDkcP31dwM](https://www.youtube.com/watch?v=5lDkcP31dwM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-11-19 00:00:00+00:00

http://KEXP.ORG and the Ministry of Culture of Argentina present Marilina Bertoldi sharing a live set of songs recorded exclusively for KEXP, at the Kirchner Cultural Center in Buenos Aires, Argentina. Recorded November 9, 2020. 

http://KEXP.ORG en alianzia con el Ministerio de Cultura Argentina presente  un set en vivo de canciones de Marilina Bertoldi grabadas exclusivamente para KEXP, en el Centro Cultural Kirchner en Buenos Aires, Argentina. Grabado el 9 de noviembre de 2020.

Songs / Canciones:
Amuleto
Fumar De Dia
Mas Y Mas
Remis

Audio and video production by the Kirchner Cultural Center (CCK), Argentina

https://www.facebook.com/marilina.bertoldi
https://www.cck.gob.ar
http://kexp.org

## Marilina Bertoldi - Full Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=qOC1afP89XE](https://www.youtube.com/watch?v=qOC1afP89XE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-11-18 00:00:00+00:00

http://KEXP.ORG and the Ministry of Culture of Argentina present Marilina Bertoldi sharing a live set of songs recorded exclusively for KEXP, at the Kirchner Cultural Center in Buenos Aires, Argentina, and talking to El Sonido's Albina Cabrera. Recorded November 9, 2020. 

http://KEXP.ORG en alianzia con el Ministerio de Cultura Argentina presente  un set en vivo de canciones de Marilina Bertoldi grabadas exclusivamente para KEXP, en el Centro Cultural Kirchner en Buenos Aires, Argentina. Marilina habla con Albina Cabrera de El Sonido de KEXP. Grabado el 9 de noviembre de 2020.

Songs / Canciones:
Amuleto
Fumar De Dia
Mas Y Mas
Remis

Audio and video production by the Kirchner Cultural Center (CCK), Argentina

https://www.facebook.com/marilina.bertoldi
https://www.cck.gob.ar
http://kexp.org

