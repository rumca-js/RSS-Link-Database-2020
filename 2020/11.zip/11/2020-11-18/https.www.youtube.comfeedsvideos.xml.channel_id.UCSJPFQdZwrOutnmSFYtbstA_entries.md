# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Looks Like Wonder Woman 1984 Is Going To Flop
 - [https://www.youtube.com/watch?v=jZWM7l_nZCA](https://www.youtube.com/watch?v=jZWM7l_nZCA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-11-19 00:00:00+00:00

With the latest news that Wonder Woman 1984 is getting released onto HBO Max this Christmas instead of getting a proper theatrical release, it looks like this movie is going to do a Mulan and flop hard.

