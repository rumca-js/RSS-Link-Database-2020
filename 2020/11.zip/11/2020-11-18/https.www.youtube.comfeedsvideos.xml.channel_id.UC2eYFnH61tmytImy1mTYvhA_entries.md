# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## Top 5 Reasons my Email System is Superior!
 - [https://www.youtube.com/watch?v=ZFgCRKX8_f0](https://www.youtube.com/watch?v=ZFgCRKX8_f0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-11-19 00:00:00+00:00

My email system is the best. Get it all here:
https://github.com/lukesmithxyz/mutt-wizard

My website: https://lukesmith.xyz
Please donate!: https://lukesmith.xyz/donate

OR affiliate links to things l use:
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://brave.com/luk005 Get the Brave browser.
https://lbry.tv/$/invite/@Luke View my videos on LBRY. Get a bonus for joining.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase. We both get $10 in Bitcoin when you buy or sell $100 in cryptocurrencies.

## Resisting Temptation...
 - [https://www.youtube.com/watch?v=BsvYEkTzmGQ](https://www.youtube.com/watch?v=BsvYEkTzmGQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-11-18 00:00:00+00:00

I can't stand it when people pretend to be victim of their on behavior, as if they aren't the ones in control. Don't "resist" temptation, just don't do it, or flee if you have to.

A lot of people pretend to be battling "temptations" that they still privately enjoy falling for. Then they pretend to be devoid of agency and claim they "couldn't help themselves." In truth, this is mostly a way of having your degenerate cake and sanctimoniously throwing it away at the same time.

I also talk about at least to heuristics/rules of thumb to behaviorally avoid temptation.

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE: https://lukesmith.xyz/donate 💰😎👌💯
OR affiliate links to things l use:
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://brave.com/luk005 Get the Brave browser.
https://lbry.tv/$/invite/@Luke View my videos on LBRY. Get a bonus for joining.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase. We both get $10 in Bitcoin when you buy or sell $100 in cryptocurrencies.

