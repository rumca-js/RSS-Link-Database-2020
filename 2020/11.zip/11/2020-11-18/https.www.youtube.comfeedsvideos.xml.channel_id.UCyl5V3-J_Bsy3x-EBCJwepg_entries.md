# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Alisa Childers On The Moment She Realized Her Pastor Might Not Have Believed In God
 - [https://www.youtube.com/watch?v=QlJQ28Ml0uM](https://www.youtube.com/watch?v=QlJQ28Ml0uM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-11-19 00:00:00+00:00

Alisa Childers thought she had found a great church until her pastor came out as a "hopeful agnostic." This led her down a rabbit hole of learning to defend her faith and eventually becoming an apologist herself.

See the full show here:
https://youtu.be/PI-zuOhptpU

Subscribe to the Babylon Bee to revel in stories that are crazier than any satire out there. 

Hit the Bell to get your daily dose of fake news that you can trust.Breakout Video

## How a Kazoo Player Living in A Tree House Helped Create ZOEgirl
 - [https://www.youtube.com/watch?v=Y2iKu0DGyHE](https://www.youtube.com/watch?v=Y2iKu0DGyHE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-11-18 00:00:00+00:00

Kyle and Ethan discover the true origin of ZOEgirl from Alisa Childers. Before Alisa Childers was a Christian apologist, she was one of the members of the CCM band ZOEgirl. Learn how a kazoo player who lived in a tree house and even a connection with the pop star Pink eventually led to the formation of the band.

See the full show here:
https://youtu.be/PI-zuOhptpU

Subscribe to the Babylon Bee to learn more bizarre stories about Christian pop culture.

Hit the bell to get your daily dose of fake news that you can trust.

## We Got An Exclusive Sneak Peek At Joe Biden's Cabinet Selections
 - [https://www.youtube.com/watch?v=EhCsS-fCUVs](https://www.youtube.com/watch?v=EhCsS-fCUVs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-11-18 00:00:00+00:00

Kyle and Ethan bring you an exclusive look into Joe Biden's selections for various cabinet positions. They discuss the choices ranging from AOC being chosen as Secretary of Math to Trump being the Secretary of choosing brutal nicknames for people. This list is 100% top secret, never before seen, and completely made up.

See the full show here:
https://youtu.be/kienRburY9g

Subscribe to the Babylon Bee to hear more exclusive top secret news that the Babylon Bee writers made up. 

Hit the bell to get your daily dose of fake news that you can trust.

