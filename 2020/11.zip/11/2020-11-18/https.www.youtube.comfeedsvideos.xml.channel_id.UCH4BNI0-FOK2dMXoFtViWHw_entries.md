# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## The TRUE Story of Ben Franklin & His Kite
 - [https://www.youtube.com/watch?v=f0oc4gUCOQI](https://www.youtube.com/watch?v=f0oc4gUCOQI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2020-11-18 00:00:00+00:00

PBS Member Stations rely on viewers like you. To support your local station, go to: http://to.pbs.org/DonateOKAY
↓ More info and sources below ↓

Thank you to Target for supporting PBS. You can learn more at: ​https://target.com/community
Share your story today: ​https://to.pbs.org/3izZeXh 

You’ve probably heard of Ben Franklin and the kite. But do you know the TRUE story of how his famous experiment changed the world? Here’s the tale of how one person’s quest for scientific knowledge altered the direction of history.

References: 

Dray, Philip. “Stealing God's Thunder: Benjamin Franklin's Lightning Rod and the Invention of America.” Random House, 2005.

Franklin, Benjamin. “Experiments and observations on electricity, made at Philadelphia in America” 1769. https://archive.org/details/experimentsobser00fran/ 

-----------
We’re on PATREON! Join the community ►► https://www.patreon.com/itsokaytobesmart
SUBSCRIBE so you don’t miss a video! ►► http://bit.ly/iotbs_sub

Special thanks to our Brain Trust Patrons:

AlecZero
Amy Sowada
Baerbel Winkler
Benjamin Teinby
Denzel Holmes
Diego Lombeida
Dustin
Eric Meer
George Gladding
Jay Stephens
Karen Haskell
Marcus Tuepker
Oliver and Arden Bradshaw
Peter Ehrnstrom
Robert Young
Salih Arslan
Vincbis
Zenimal

Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/

