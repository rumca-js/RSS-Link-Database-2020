# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Motion City Soundtrack - two live performances (2015; 2014)
 - [https://www.youtube.com/watch?v=ZhmFzGgaSWo](https://www.youtube.com/watch?v=ZhmFzGgaSWo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-11-27 00:00:00+00:00

November 26 is Thanksgiving this year, but every year, it's the birthday of Matthew Taylor, bassist for Motion City Soundtrack. In honor of that, here are two performances by Motion City Soundtrack, one recorded in studio at The Current; the other recorded onstage at the Fitzgerald Theater in St. Paul, Minn., in 2014, a song written in tribute to actor Steven Yeun's character Glenn on "The Walking Dead."

SONGS PERFORMED
0:00 "TKO" (2015)
3:23 "Glenn's Song" (2014)

PERSONNEL
Justin Pierre – guitar, lead vocals 
Josh Cain – guitar
Jesse Johnson – keys
Matthew Taylor – bass 
Claudio Rivera – drums 

CREDITS
Video & Photo: Leah Garaas; Trent Waterman
Audio: Michael DeMark; Corey Schreppel
Production: David Campbell; Larissa Anderson

FIND MORE:
2015 studio session: https://www.thecurrent.org/feature/2015/07/13/motion-city-soundtrack-perform-in-the-current-studio

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#motioncitysoundtrack

