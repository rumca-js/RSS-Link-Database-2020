# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Ranking EVERY Cosmere Leather-bound || Way Of Kings LB Giveaway
 - [https://www.youtube.com/watch?v=e8U0hyhYMYk](https://www.youtube.com/watch?v=e8U0hyhYMYk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-11-27 00:00:00+00:00

Let's look at some Cosmere leather bound books! Way of Kings, Mistborn, Warbreaker, and Elantris. This is going to be a good one! 
Cosmere Leather Bounds: So… They are all sold out. My bad! 

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

