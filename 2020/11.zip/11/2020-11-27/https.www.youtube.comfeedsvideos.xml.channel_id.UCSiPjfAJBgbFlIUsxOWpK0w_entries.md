# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## POMPLAMOOSE // Invisible People // animated music video
 - [https://www.youtube.com/watch?v=xIyFHwD9X3I](https://www.youtube.com/watch?v=xIyFHwD9X3I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2020-11-27 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 Watch the behind the scenes of this video: https://youtu.be/Ry-ZymxsvZc
Watch the original version of this video: https://youtu.be/rO8Q6vLKzzo

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

CREDITS

Lead Vocals: Nataly Dawn
Drums: Ben Rose
Trumpet: Gabe Steiner
Alto Sax: Morgan Jones
Trombone: Erik Hughes
Tenor Sax: Dan Reckard 
Everything else: Jack Conte
Engineer: Chris Sorem
Mixing/Mastering: Jack Conte
Art/Direction: Hannah Clair
Animation: David Kessler

Illustrations by Hannah Clair:
https://www.hannahclair.co.uk
https://www.instagram.com/hannahclairillustration/
https://thebrightagency.com/uk/illustration/artists/hannah-clair

Animation by David Kessler: 
https://www.davidskessler.work
https://www.studioscopic.com
https://www.youtube.com/c/davidskessler
https://www.instagram.com/dskessler/

LYRICS

Invisible people
Yeah they’re invisible
They are invisible people
Yeah they’re invisible

Talk to them when you’re in the car
In the shower they like to argue argue argue argue argue with you
Know exactly what you would say
Then they’ll see what you’re made of are you are you seeing me too

Dealing with invisible people
Dealing with the hole in our chest
Some of them are good, some are evil
All of them are just in our heads
 
Invisible people
Yeah they’re invisible
They are invisible people
Yeah they’re invisible
  
I’ll convince you that I was right
In my pillow where are you hiding hiding hiding hiding I can hear
All your whispers and your white lies
Walk straight through me you knew me why did why did why did you just disappear

