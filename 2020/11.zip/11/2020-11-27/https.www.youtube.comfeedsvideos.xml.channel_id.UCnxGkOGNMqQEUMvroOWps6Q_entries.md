# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Climber Emily Harrington Recalls Scary Fall Stories
 - [https://www.youtube.com/watch?v=A03tppqAxGY](https://www.youtube.com/watch?v=A03tppqAxGY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-11-27 00:00:00+00:00

#1571 w/Emily Harrington:
https://open.spotify.com/episode/1P6wgzkVhfUBt0T0qCBhqv?si=BSB3n1kdRZW6tE57x5oN_w

## Emily Harrington Free Climbed El Capitan's Golden Gate in One Day
 - [https://www.youtube.com/watch?v=EBkh2S66DE4](https://www.youtube.com/watch?v=EBkh2S66DE4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-11-27 00:00:00+00:00

#1571 w/Emily Harrington:
https://open.spotify.com/episode/1P6wgzkVhfUBt0T0qCBhqv?si=BSB3n1kdRZW6tE57x5oN_w

## Free Climber Emily Harrington Talks About Alex Honnold
 - [https://www.youtube.com/watch?v=Sv4jq8t-7us](https://www.youtube.com/watch?v=Sv4jq8t-7us)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-11-27 00:00:00+00:00

#1571 w/Emily Harrington:
https://open.spotify.com/episode/1P6wgzkVhfUBt0T0qCBhqv?si=BSB3n1kdRZW6tE57x5oN_w

