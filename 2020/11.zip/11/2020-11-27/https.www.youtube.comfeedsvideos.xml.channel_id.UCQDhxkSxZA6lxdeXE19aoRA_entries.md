# Source:Hugh Jeffreys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA, language:en-US

## Is Samsung locking down 3rd party repairs? Galaxy S20 Teardown and Repair Assessment
 - [https://www.youtube.com/watch?v=U0nRGFZRM2s](https://www.youtube.com/watch?v=U0nRGFZRM2s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA
 - date published: 2020-11-28 00:00:00+00:00

How does Samsungs latest flagship hold up to repairs?
--------------------------------------Socials-------------------------------------
Website: https://www.hughjeffreys.com 
Instagram: http://instagram.com/hughjeffreys
Twitter: https://twitter.com/hughjeffreys
---------------------------------------Links---------------------------------------
Fixit's holiday tool deals start now! Save up to $50 on iFixit Tools: iFixit.com/hughjeffreys 
Right now you can get the Ultimate iFixit kit for $50 off. Or the Pro Tech + Mag Mat bundle for $10 off. (You can use iFixit.com/hughjeffreys to get to the gift guide.)

(DISCLAIMER: This description contains affiliate links, which means that if you click on one of the product links, l will receive a small commission.)

