# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Black Friday in a Pandemic! Is This A Joke?!?
 - [https://www.youtube.com/watch?v=dPppAAf3enY](https://www.youtube.com/watch?v=dPppAAf3enY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-11-27 00:00:00+00:00

It's #BlackFriday today! What do you think of this intense day of hyped consumerism? Should we be encouraging people to go to shops during a pandemic and spend money when many have now lost their jobs or have been furloughed? What are the consequences of prioritising the economy over everything else?

More videos like this: https://www.youtube.com/watch?v=Lkzp5sAE-34&list=PL5BY9veyhGt4_ysy1teRGQ8hl_WDdgTzS

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

