# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Firearms Expert Reacts To Call Of Duty: Modern Warfare’s Guns
 - [https://www.youtube.com/watch?v=-BeJdQfEp40](https://www.youtube.com/watch?v=-BeJdQfEp40)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-11-28 00:00:00+00:00

Jonathan Ferguson, a weapons expert and Keeper of Firearms & Artillery at the Royal Armouries, breaks down the iconic weaponry of Call of Duty: Modern Warfare 2019, including the SIG MCX assault rifle, the Uzi submachine gun, the Dragunov sniper rifle, and a silenced Desert Eagle. Yes, you read that right.

Call of Duty: Modern Warfare saw the COD franchise return to a more gritty, realistic shooter experience, which was full to the brim with contemporary weapons like the SIG MCX assault rifle, the DP-12 shotgun, and the Russian ASh 12.7 battle rifle.

In the above video, Jonathan Ferguson, a weapons expert and Keeper of Firearms & Artillery at the Royal Armouries, breaks down the weapons of Call of Duty: Modern Warfare, including the Dragunov sniper rifle, the Uzi submachine gun, and silenced versions of the Colt 1911 and the Desert Eagle. Across the video, Jonathan breaks down the weapons and their in-game functionality, and compares them to their real-world counterparts.

If you're interested in seeing more of Jonathan, you can check out more from the Royal Armouries right here. - https://www.youtube.com/user/RoyalArm…

If you would like to support the Royal Armouries, you can make a charitable donation to the museum here. - https://royalarmouries.org/support-us/donations/ 

And if you would like to become a member of the Royal Armouries, you can get membership here. - https://royalarmouries.org/support-us/membership/

## 10 Minutes of Immortals: Fenyx Rising Gameplay
 - [https://www.youtube.com/watch?v=EhgCjIx3bjE](https://www.youtube.com/watch?v=EhgCjIx3bjE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-11-27 00:00:00+00:00

Check out 10 minutes of brand new Immortals: Fenyx Rising gameplay, where we  fight the legendary Lieutenant Briareos before embarking on the Life & Death Quest line.

0:00 - Introduction
0:10 - Lieutenant Briareos Boss Fight
0:59 - Overworld Exploration
3:51 - Rift Platforming
7:16 - Axe Combat
9:09 - Returning to Overworld

