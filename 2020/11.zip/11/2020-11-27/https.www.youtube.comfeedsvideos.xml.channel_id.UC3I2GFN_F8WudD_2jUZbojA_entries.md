# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Isolated Tracks Episode 4: Impossible Weight by Deep Sea Diver
 - [https://www.youtube.com/watch?v=MCIX5zEbud4](https://www.youtube.com/watch?v=MCIX5zEbud4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-11-28 00:00:00+00:00

In this episode of Isolated Tracks we talk to Jessica Dobson from Deep Sea Diver. KEXP Audio Producer Julian Martlew dissects the sounds that make up the song "Impossible Weight" from the album Impossible Weight out on ATO Records. 

To watch the video and hear the full song: https://www.youtube.com/watch?v=xzkr2i6Szy8
 @thisisdeepseadiver 

http://kexp.org

## This Is The Kit - Full Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=x0kQldZV9nA](https://www.youtube.com/watch?v=x0kQldZV9nA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-11-28 00:00:00+00:00

http://KEXP.ORG presents This Is The Kit sharing songs recorded exclusively for KEXP. Recorded November 19, 2020.

Songs:
This is What You did
No Such Thing
Off Off On
Lemon World (The National cover)

Band:
Guitar: Jesse Vernon
Bass: Romain Vasset
Drums: Lucien Chatin
Flugel Horn: Julien Bertrand
Trombone: Anthony Bonniere
Sax: Boris Pokora

Production:
Cameras: Anne-Laure Etienne, Pierre Paturel
Editor: Marisa Gesualdi
Audio Engineer: Matteo Fabbri
Assistant Engineer: Giles Davenport

https://thisisthekit.co.uk
http://kexp.org

## This Is The Kit - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=dZac6v2af0M](https://www.youtube.com/watch?v=dZac6v2af0M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-11-27 00:00:00+00:00

http://KEXP.ORG presents This Is The Kit sharing songs recorded exclusively for KEXP.  This Is The Kit's Kate Stables talks live with DJ Morgan. Recorded November 19, 2020.

Songs:
This is What You did
No Such Thing
Off Off On
Lemon World (The National cover)

Band:
Guitar: Jesse Vernon
Bass: Romain Vasset
Drums: Lucien Chatin
Flugel Horn: Julien Bertrand
Trombone: Anthony Bonniere
Sax: Boris Pokora

Production:
Cameras: Anne-Laure Etienne, Pierre Paturel
Editor: Marisa Gesualdi
Audio Engineer: Matteo Fabbri
Assistant Engineer: Giles Davenport

https://thisisthekit.co.uk
http://kexp.org

