# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Breaking News! The Cure for Divisiveness Is Found
 - [https://www.youtube.com/watch?v=PiM1BDJVsPk](https://www.youtube.com/watch?v=PiM1BDJVsPk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-11-27 00:00:00+00:00

Grab your Supernatural Starter Set Here! -  https://supernatural.com/jp

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Breaking news! The Cure For Divisiveness is Found. Researchers discovery of a miracle cure now gives us hope to end the pandemic of divisiveness. Will the cure be mandatory? Tune in to find out!

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

