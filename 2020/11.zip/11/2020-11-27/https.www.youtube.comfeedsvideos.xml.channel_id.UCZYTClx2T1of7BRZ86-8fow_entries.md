# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## Why Do Razor Blades Dull so Quickly?
 - [https://www.youtube.com/watch?v=f3mdcqGjevU](https://www.youtube.com/watch?v=f3mdcqGjevU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2020-11-28 00:00:00+00:00

If you shave regularly, you may have noticed your razor blades don’t cut as well after just a few uses. But why do razors get dull so quickly? 

Hosted by: Rose Bear Don't Walk

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Jb Taishoff, Bd_Tmprd, Harrison Mills, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Sam Buck, Christopher R Boucher, Eric Jensen, Lehel Kovacs, Adam Brainard, Greg, Ash, Sam Lutfi, Piya Shedden, KatieMarie Magnone, Scott Satovsky Jr, Charles Southerland, charles george, Alex Hackman, Chris Peters, Kevin Bealer
----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://www.smithsonianmag.com/smart-news/why-razors-are-dull-within-weeks-according-science-180975534/
https://science.sciencemag.org/content/369/6504/689
https://patentimages.storage.googleapis.com/2f/be/f7/9b2f41b2511bff/US7531052.pdf 
https://patents.google.com/patent/US5701788A/en 
https://patentimages.storage.googleapis.com/f5/e5/f1/301c27fa150690/US5701788.pdf 
https://www.britannica.com/technology/steel 
https://www.britannica.com/technology/scanning-electron-microscope 

Image Sources: 
https://www.istockphoto.com/photo/man-hating-razor-gm490611056-75289363
https://www.storyblocks.com/video/stock/chef-cuts-the-red-onion-by-the-sharp-knife-on-the-wooden-board-at-the-kitchen-close-up-video-of-cooking-the-vegetable-salad-slicing-the-vegetables-bxt_7hznsjzaze5sw
https://news.mit.edu/2020/why-shaving-dulls-razors-0806
https://www.istockphoto.com/photo/shaving-razor-gm587506114-100828395
https://www.istockphoto.com/photo/hairs-under-the-microscope-gm187337569-27926324
https://www.istockphoto.com/vector/hair-structure-gm1137739272-303501477

## Thank Goodness for Chlamydia(e)
 - [https://www.youtube.com/watch?v=m2jVc_ACpaE](https://www.youtube.com/watch?v=m2jVc_ACpaE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2020-11-27 00:00:00+00:00

The group of bacteria known as Chlamydiae doesn't do much to endear itself to us since these bacteria can cause a variety of illnesses. But it turns out that we may have Chlamydiae to thank for life as we know it!

Hosted by: Stefan Chin

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Jb Taishoff, Bd_Tmprd, Harrison Mills, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Sam Buck, Christopher R Boucher, Eric Jensen, Lehel Kovacs, Adam Brainard, Greg, Ash, Sam Lutfi, Piya Shedden, KatieMarie Magnone, Scott Satovsky Jr, Charles Southerland, charles george, Alex Hackman, Chris Peters, Kevin Bealer
----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:
https://bio.libretexts.org/Bookshelves/Microbiology/Book%3A_Microbiology_(Boundless)/8%3A_Microbial_Evolution_Phylogeny_and_Diversity/8.10%3A_Irregular_Bacterial_cells/8.10A%3A_Chlamydiae
https://www.nature.com/articles/nature21377
https://www.chemistryworld.com/features/hydrothermal-vents-and-the-origins-of-life/3007088.article?adredir=1
https://www.nature.com/articles/nmicrobiol2016116.epdf?referrer_access_token=PfG0EY2Uab8BETC5TxWs59RgN0jAjWel9jnR3ZoTv0MUGiEHcCbkW0uWqU-Z8_VoVX7xGnFSz9mbM_GrJrqWbXBZLrtZdT1IaZwkuWEhpXLvYTGIg8ND3tMg26W_cfxaU-s0Lo-W7DJw55dT3k9-F61B5Qt4zkBbc2VwE36dB6j
http://eprints.whiterose.ac.uk/112179/1/ppnature21377_Dodd_for%20Symplectic.pdf
https://pubs.geoscienceworld.org/gsa/geology/article-abstract/47/11/1039/573756/Nano-porous-pyrite-and-organic-matter-in-3-5?redirectedFrom=fulltext
https://www.nature.com/articles/nature21377
https://www.sciencemag.org/news/2017/12/life-may-have-originated-earth-4-billion-years-ago-study-controversial-fossils-suggests
https://astrobiology.nasa.gov/news/how-did-multicellular-life-evolve/#:~:text=The%20first%20known%20single%2Dcelled,about%20600%20million%20years%20ago.
https://www.sciencedaily.com/releases/2019/11/191104112437.htm
https://micro.magnet.fsu.edu/cells/mitochondria/mitochondria.html
https://www.nature.com/scitable/topicpage/eukaryotic-cells-14023963/
https://www.nature.com/scitable/topicpage/the-origin-of-mitochondria-14232356/
https://www.nature.com/scitable/topicpage/the-origin-of-mitochondria-14232356/
https://advances.sciencemag.org/content/6/35/eabb7258
https://www.nature.com/scitable/knowledge/library/bacteria-that-synthesize-nano-sized-compasses-to-15669190/
https://www.sciencedaily.com/releases/2008/07/080724153941.htm
https://www.nationalgeographic.com/science/phenomena/2015/05/06/new-loki-microbe-is-closest-relative-to-all-complex-life/
https://academic.oup.com/femsre/article/38/4/779/758958
https://www.nature.com/articles/nature14447

Images:
https://commons.wikimedia.org/wiki/File:ChlamydiaTrachomatisEinschlussk%C3%B6rperchen.jpg
https://commons.wikimedia.org/wiki/File:Mitochondria,_mammalian_lung_-_TEM.jpg
https://www.eurekalert.org/multimedia/pub/102460.php?from=310661
https://www.eurekalert.org/multimedia/pub/91200.php
https://www.eurekalert.org/multimedia/pub/91201.php?from=295373
https://www.istockphoto.com/photo/chlamydia-bacteria-gm643089926-116591205
https://www.istockphoto.com/vector/set-of-the-ribbons-and-badges-gm1227399056-361985660
https://www.istockphoto.com/vector/eukaryotic-vs-prokaryotic-cells-educational-biology-vector-illustration-diagram-gm1201105509-344307561
https://www.istockphoto.com/photo/bear-raising-paw-gm149070679-12733044
https://www.istockphoto.com/photo/happy-young-man-waving-gm185224058-19997141
https://www.istockphoto.com/vector/diagram-showing-cellular-respiration-gm921594084-253077359
https://www.istockphoto.com/vector/realistic-bacteria-gm1281004882-379155723
https://www.istockphoto.com/vector/chemical-formula-and-molecule-model-of-hydrogen-water-ammonia-methane-school-gm849391982-139794961
https://www.istockphoto.com/photo/chlamydia-bacteria-gm1168007937-322335940
https://www.istockphoto.com/photo/the-ocean-floor-gm688016104-126501935
https://www.istockphoto.com/vector/dna-test-infographic-vector-illustration-genome-sequence-map-template-for-your-gm1155935470-314878899
https://www.istockphoto.com/vector/microorganism-and-virus-vector-filled-icon-set-gm1211932100-351648867
https://www.istockphoto.com/vector/wrench-icon-gm845292864-138369307
https://www.istockphoto.com/vector/friendship-thin-line-icons-editable-stroke-gm1218055101-355791061
https://www.istockphoto.com/vector/animal-cell-anatomy-vector-cartoon-illustration-isolated-on-background-gm1158423706-316430335

