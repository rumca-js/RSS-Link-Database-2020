# Source:Vlog Casha, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg, language:pl-PL

## Turyści się tu nie zapuszczają - Wschodnia Turcja
 - [https://www.youtube.com/watch?v=jOX8R36a9po](https://www.youtube.com/watch?v=jOX8R36a9po)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg
 - date published: 2020-11-28 00:00:00+00:00

🗺️ Turcja 2020 #15. W Mardin istnieje mnóstwo zakamarków, w które z reguły nie zapuszczają się przypadkowi turyści. Dziś odwiedzimy lokalną łaźnię, bazar oraz golibrodę!

❗ Zostań Patronem kanału!
https://patronite.pl/vlogcasha


Pokoje Sabriego: https://www.airbnb.pl/users/show/300966482

Vlogi z Turcji (2019-2020): https://bit.ly/31VPCR3
Vlogi z Kolumbii: https://bit.ly/36tqlhH
🌏 Vlogi z Azji Płd-Wsch: https://bit.ly/2wrM9t2
🇦🇺 Vlogi z Australii: https://bit.ly/2OJWYOy
🇺🇸 Vlogi z życia i podróży w USA: https://bit.ly/2ya73NV
🚙Vlogi z autostopu 2018: https://bit.ly/2NbHzos

▸ Instagram: https://www.instagram.com/vlogcasha
▸ Facebook: https://www.facebook.com/vlogcasha/
#PodróżeCasha #CashWTurcji #Turcja

