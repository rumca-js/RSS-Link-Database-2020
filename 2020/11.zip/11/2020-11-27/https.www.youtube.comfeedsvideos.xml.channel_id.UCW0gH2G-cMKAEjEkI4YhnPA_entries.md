# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Complete Travels of Thranduil | Tolkien Explained
 - [https://www.youtube.com/watch?v=03l0R0iyd58](https://www.youtube.com/watch?v=03l0R0iyd58)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2020-11-28 00:00:00+00:00

Where was Thranduil from? What was he doing before The Hobbit?  We answer this and more!  His beginnings in Doriath during the first age, coming to Greenwood, fighting Sauron in the Last Alliance, and his rule as King of the Woodland Realm.  We cover it all, with helpful animated maps so we can track all of his travels!

Hit subscribe - and the bell - so you never miss a video from Nerd of the Rings!  

Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings


-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner. 

The Crack of Doom - Dmitry Prosvirnin
Captured by the Spiders - Alan Lee
The Passage of the Marshes - Alan Lee
The Burial of Thorin Oakenshield - Daniel Govar
The Death of Thingol - Steamey
The Battle of Five Armies - Capucine Mazille
On the Doorstep - Chris Rahn
The Death of Thorin Oakenshield - Darrell Sweet
Thorin and Thranduil - Evan Jarvinen
Gildor, Sam, Pippin, Frodo, and Elves - Steamey
The Dead Marshes - Steamey
Oropher - Kimberly80
Woodland Elf - WETA
Thranduil - Ultra Marine and White
The Nauglamir - Ted Nasmith
Mirkwood - Ilyza Nazarov
The Fellowship - JB Casacop
Smaug - John Howe
Legolas and Gimli - John Howe
Minas Tirith - Ludovic Bourgeois
A Feast in Mirkwood - Lída Holubová
Legolas and Gimli - Nathalie Kranich
Thranduil - Nick Keller
Celeborn and Thranduil - Steamey
The Arkenstone - Ted Nasmith
The Woodland Realm - Saiga Tokihito
Thranduil at Thorin's Tomb - Quelle Elenath
Thranduil - Yu Xinhe


#thranduil #tolkien #thehobbit

