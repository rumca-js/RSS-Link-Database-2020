# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## Pulseaudio on Linux: Bloat, Based or Both? (Or Bneither)
 - [https://www.youtube.com/watch?v=wzX6Y6kFehE](https://www.youtube.com/watch?v=wzX6Y6kFehE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-11-28 00:00:00+00:00

I constantly find myself at odds with people who choose and recommend software based on memes. Pulseaudio is totally """bloated""", but using ALSA alone isn't a viable alternative for 99.9999% of people who want a functioning audio system. Pulse is a """bloated""" front-end for ALSA, but before you whine about it, try to configure ALSA yourself for something beyond watching anime and YouTube. Yeah, yeah I know there are things like jack and such too. I've never really used it and documentation is just as scarce as for ALSA. Anyway, this is a video on why I use Pulseaudio and I'm not convinced that there are people who don't who do it for non-meme reasons.

My website: https://lukesmith.xyz
Please donate: https://lukesmith.xyz/donate

OR affiliate links to things l use:
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://brave.com/luk005 Get the Brave browser.
https://lbry.tv/$/invite/@Luke View my videos on LBRY. Get a bonus for joining.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase. We both get $10 in Bitcoin when you buy or sell $100 in cryptocurrencies.

