# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## Things You MUST Do When You Get a Computer (Or Just Now)
 - [https://www.youtube.com/watch?v=L14fTu6dsCo](https://www.youtube.com/watch?v=L14fTu6dsCo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2020-11-27 00:00:00+00:00

• Check out Bitdefender Total Security 2020 here  ⇨ https://www.bitdefender.com/media/html/consumer/new/TJ-get-4-months-bitdefender-total-security/?cid=inf%7Cc%7cyt%7Cdectj  (sponsored)

⇒ Become a channel member for exclusive features! Check it out here: https://www.youtube.com/ThioJoe/join

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

#Computers #Tech #ThioJoe

