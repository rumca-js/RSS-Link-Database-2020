# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## China is running out of processors?
 - [https://www.youtube.com/watch?v=2BzQE-U2aJw](https://www.youtube.com/watch?v=2BzQE-U2aJw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2020-11-27 00:00:00+00:00

Download the Crrowd app: https://play.google.com/store/apps/details?id=com.crrowd

Quiz/giveaway instructions:
- Download the app
- Open the quiz (under the hamburger menu)
- Complete the quiz and get at least 15 points
- Leave an email address if you would like to join either the giveaway or Crrowd.

Terms & Conditions: https://www.crrowd.com/black-friday-tc

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► TechAltar links ◄◄◄ 

Merch: 
https://enthusiast.store 

Crrowd Discord: 
https://discord.gg/npKQebe 

Social media: 
https://twitter.com/TechAltar 
https://instagram.com/TechAltar 
https://facebook.com/TechAltar 

If you want to support TechAltar directly: 
https://flattr.com/@techaltar 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► Attributions ◄◄◄ 
Music by Edemski: 
https://soundcloud.com/edemski 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

►►► Timestamps ◄◄◄ 


0:00 Intro
0:33 Phone makers stop making phones
3:17 Slack gets bought by Salesforce
4:41 China runs out of chips.

