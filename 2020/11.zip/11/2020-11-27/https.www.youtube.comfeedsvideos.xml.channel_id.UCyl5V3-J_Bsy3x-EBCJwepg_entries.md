# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Is TikTok Melting Everybody's Brains?
 - [https://www.youtube.com/watch?v=eMwVnLgZ0p8](https://www.youtube.com/watch?v=eMwVnLgZ0p8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-11-27 00:00:00+00:00

Stand-up Comedian Kellen Erskine talks to the Babylon Bee about why he has disdain for TikTok and will never go on it again. He dives in deep into why it creates a toxic environment and gives nothing back to its creators. Kyle and Ethan talk about similar experiences and how the nicest hate mail comes from the LDS community. 

See the full show here:
https://youtu.be/cKgZpQiar-Y

Subscribe to the Babylon Bee to help Kellen be known for more than a voice on TikTok

Hit the bell to get your daily dose of fake news that you can trust.

## Reading The Berenstain Bears As An Adult Is Torture
 - [https://www.youtube.com/watch?v=U_Slw7xmHbs](https://www.youtube.com/watch?v=U_Slw7xmHbs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-11-27 00:00:00+00:00

Ethan and Kyle, from the Babylon Bee, talk to comedian Kellen Erskine about the tortuous experiences reading the Berenstain Bears as a father. Kellen is a writer on the upcoming show the Tuttle Twins and describes how he wants to do everything differently than what the Berenstain Bears does, including giving actual good lessons. 

See the full show here:
https://youtu.be/cKgZpQiar-Y

Subscribe to the Babylon Bee to help rid the world of torturous children books

Hit the bell to get your daily dose of fake news that you can trust.

