# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## How do I choose? - PS5 vs Xbox Series X
 - [https://www.youtube.com/watch?v=J0jvE4D5mtY](https://www.youtube.com/watch?v=J0jvE4D5mtY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-11-28 00:00:00+00:00

Protect your money online and go to www.privacy.com/linus to get $5 off your first purchase! Or if you're a new 1Password user, go to https://start.1password.com/sign-up/plan?c=linus to also receive $5 when signing up.

Check out ORIGIN PC gaming laptops and desktops today at https://bit.ly/2Swgjq6

We compare the Xbox Series X and Playstation 5 in terms of boot times, load times, and picture quality....but is it fair to mention the DualSense controller because that thing's rad!

Buy Sony Playstation 5
On Amazon (PAID LINK): https://geni.us/slHifS
On Best Buy (PAID LINK): https://geni.us/a3JF00s
On Newegg (PAID LINK): https://geni.us/olrxpXK

Buy Microsoft Xbox Series X
On Amazon (PAID LINK): https://geni.us/GMRv
On Best Buy (PAID LINK): https://geni.us/KxZvpQA
On Newegg (PAID LINK): https://geni.us/FtIu
On B&H (PAID LINK): https://geni.us/zABF

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1274401-how-do-i-choose-ps5-vs-xbox-series-x/

►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Official Game Store: https://www.nexus.gg/ltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

## NVIDIA Shortage due to CRYPTO MINERS??  - WAN Show November 27 , 2020
 - [https://www.youtube.com/watch?v=MiZ4yY2N3x8](https://www.youtube.com/watch?v=MiZ4yY2N3x8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-11-27 00:00:00+00:00

Check out the latest Bitdefender deals at https://lmg.gg/bitdefenderwan

Keep your feet dry and get $25 off each pair at Vessi with offer code WANSHOW at https://www.vessi.com/wanshow

Honey automatically applies the best coupon codes to save you money at 
different online checkouts, try it now at https://www.joinhoney.com/linus

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/NVIDIA-Shortage-due-to-CRYPTO-MINERS-----WAN-Show-November-27---2020-en5red

Check out Carpool Critics, our new movie podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Timestamps (Courtesy of Prasoon Tiwari)
0:00:00 - Welcome to Wan Show 
0:00:10 - [Headline Topic] Nvidia sold RTX 30 GPUs to Miners [Jump to 0:03:37]
0:00:36 - [Headline Topic] Intel spreads FUD on Ryzen 4000 Battery Performance [Jump to 0:13:31]
0:00:57 - [Headline Topic] Scalping Group snapped up 3500 PS5 [Jump to 0:27:09]
0:01:10 - [Headline Topic] Alexa Devices turning to "Opt Out" Public Mesh Wi-Fi Network [Jump to 0:56:59]
0:01:44 - Intro 
0:03:24 - [Headline Topic] Windows running on Apple Silicon [Jump to 0:38:44]
0:03:37 - Nvidia sold RTX 30 GPUs to Miners
0:13:31 - Intel spreads FUD on Ryzen 4000 Battery Performance

0:24:40 - [SPONSOR] BitDefender 
0:25:28 - [SPONSOR] Honey
0:26:20 - [SPONSOR] Vessi Shoes

0:27:09 - Scalping Group snapped up 3500 PS5
0:35:49 - LTT Store Ad - The ABCs of Gaming
0:38:44 - Windows running on Apple Silicon
0:43:16 - Discussion on LTT Store's "The ABCs of Gaming" 
0:56:59 - Alexa Devices turning to "opt Out" Public Mesh WiFi Network
1:02:59 - EU votes for Standardize Lifetime & Reparability Rating on Products
1:05:38 - Apple M1x Silicon Leaks
1:07:45 - Superchats
1:17:05 - WAN Show Outro

