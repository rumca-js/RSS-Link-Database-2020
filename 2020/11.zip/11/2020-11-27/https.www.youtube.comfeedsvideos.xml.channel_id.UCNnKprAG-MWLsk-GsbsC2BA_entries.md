# Source:FlashGitz, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA, language:en-US

## The Furry Disease
 - [https://www.youtube.com/watch?v=afpn6skCDhA](https://www.youtube.com/watch?v=afpn6skCDhA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA
 - date published: 2020-11-27 00:00:00+00:00

FURRY APOCALYPSE SHIRT:
https://crowdmade.com/flashgitz

Patreon ►
https://www.patreon.com/flashgitz

Special thanks to our Patron Producers, really going the extra mile to make this possible:

Albert Hutchins
David Murphy
Andrew Palmer
Adam Knopow
Connor Hill
Sam Husmann

Thank you gents, seriously.

Additional Animation ► 
Ollie Kremer
Arislaretis
Taterman NG

Backgrounds ►
Javier Navarro https://www.instagram.com/naav_draws/

Sound ►
Justin Greger

Music ►
Tom Ryan

VO ► 

Templar 1 - Tim Plewman

Templar 2 - Jacob Kilner

Don - Furry

Instagram ►
https://www.instagram.com/flashgitz/

Twitter ►
https://www.twitter.com/flashgitzanims
https://www.twitter.com/flashgitztom
https://www.twitter.com/flashgitzdon

Discord ►
https://discord.gg/nJCcJj6

