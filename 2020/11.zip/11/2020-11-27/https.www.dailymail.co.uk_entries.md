## New Jersey Starbucks barista claims she was fired for refusing to wear a Pride T-shirt because of her religious beliefs
 - [https://www.dailymail.co.uk/news/article-8993007/New-Jersey-Starbucks-barista-claims-fired-refusing-wear-Pride-T-shirt.html](https://www.dailymail.co.uk/news/article-8993007/New-Jersey-Starbucks-barista-claims-fired-refusing-wear-Pride-T-shirt.html)
 - RSS feed: https://www.dailymail.co.uk
 - date published: 2020-11-27 22:05:08+00:00

New Jersey Starbucks barista claims she was fired for refusing to wear a Pride T-shirt because of her religious beliefs

