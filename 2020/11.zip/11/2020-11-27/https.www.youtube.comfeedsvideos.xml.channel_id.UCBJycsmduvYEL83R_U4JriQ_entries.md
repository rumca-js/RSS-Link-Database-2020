# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## The FIRST MKBHD Product: ICONS!
 - [https://www.youtube.com/watch?v=l4bNwGCx1FA](https://www.youtube.com/watch?v=l4bNwGCx1FA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-11-27 00:00:00+00:00

ICONS: https://dbrand.com/shop/ICONS

