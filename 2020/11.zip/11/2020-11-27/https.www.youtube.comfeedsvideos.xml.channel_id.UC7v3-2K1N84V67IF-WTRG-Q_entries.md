# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## The Mandalorian - Season 2: Episode 5 (My Thoughts)
 - [https://www.youtube.com/watch?v=owadH2SUZ0M](https://www.youtube.com/watch?v=owadH2SUZ0M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-11-27 00:00:00+00:00

Thank you Vincero for sponsoring this video! Now through December 2nd: Go to https://vincerowatches.com/JeremySale and save up to 25% and get free shipping on your order.

Ok...so Mando meets a familiar face (and fan favorite) from the Star Wars mythos. Here are my thoughts on THE MANDALORIAN: CHAPTER 13 - THE JEDI

#Mandalorian #TheJedi #Ahsoka

