# Source:PostmodernJukebox, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg, language:en-US

## Black Hole Sun (Soundgarden) - New POSTMODERN JUKEBOX AT THE PIANO Album ft. Scott Bradlee
 - [https://www.youtube.com/watch?v=EWtFtB0Z-AQ](https://www.youtube.com/watch?v=EWtFtB0Z-AQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg
 - date published: 2020-11-27 00:00:00+00:00

NEW POSTMODERN JUKEBOX AT THE PIANO ALBUM: https://pmjlive.com/pmj-at-the-piano
Hear PMJ founder Scott Bradlee's solo piano interpretations of 16 classic PMJ remakes in the new POSTMODERN JUKEBOX AT THE PIANO album -- available on all platforms and at our online shop at http://www.shoppmj.com

Scott's PIANO REQUEST LIVE! channel:
http://youtube.com/scottbradlee
Sign Up For Scott's Substack Newsletter: https://scottbradlee.substack.com
Sign up to get Scott's piano tracks on Patreon: http://www.patreon.com/scottbradleemusic
Read Scott's book, "Outside The Jukebox: How I Turned My Vintage Music Obsession Into My Dream Gig": http://smarturl.it/outsidethejukebox

