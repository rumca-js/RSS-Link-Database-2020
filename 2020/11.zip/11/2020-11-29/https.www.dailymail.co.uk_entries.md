## Time's Up charities set up by celebrities as part of Me Too movement spent $1.4m on salaries including $157k on conferences at luxury resorts
 - [https://www.dailymail.co.uk/news/article-8997707/Times-organization-raised-3-6m-2018-cash-went-salaries-not-victims.html](https://www.dailymail.co.uk/news/article-8997707/Times-organization-raised-3-6m-2018-cash-went-salaries-not-victims.html)
 - RSS feed: https://www.dailymail.co.uk
 - date published: 2020-11-29 20:26:43+00:00

Time's Up charities set up by celebrities as part of Me Too movement spent $1.4m on salaries including $157k on conferences at luxury resorts

