# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Socially-distanced Santa's Grottos can open for Christmas
 - [https://www.bbc.co.uk/news/uk-55123490](https://www.bbc.co.uk/news/uk-55123490)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 20:41:25+00:00

Carol singing is also allowed - but people will not be able to go to school nativity plays in some areas.

## Cher and the rescue of a lonely elephant in Pakistan
 - [https://www.bbc.co.uk/news/55122863](https://www.bbc.co.uk/news/55122863)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 14:15:32+00:00

Singer Cher was one of those who campaigned for a better life for Kavaan the elephant who is now heading to a new home.

## Covid: Boris Johnson writes to MPs to quell anger over new tiers
 - [https://www.bbc.co.uk/news/uk-55118467](https://www.bbc.co.uk/news/uk-55118467)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 12:29:00+00:00

Facing a rebellion in his party, Boris Johnson tells MPs that England's new rules could end in nine weeks.

## Covid in Scotland: Sturgeon defends handling of pandemic
 - [https://www.bbc.co.uk/news/uk-scotland-scotland-politics-55120734](https://www.bbc.co.uk/news/uk-scotland-scotland-politics-55120734)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 12:27:12+00:00

Scotland's first minister says it is too soon to be comparing Scotland's record with England.

## Dave Prowse: Darth Vader actor dies aged 85
 - [https://www.bbc.co.uk/news/entertainment-arts-55117704](https://www.bbc.co.uk/news/entertainment-arts-55117704)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 12:07:56+00:00

The former bodybuilder was also given an MBE for his long-running role as the Green Cross Code Man.

## Smith scores second century as Australia wrap up ODI series win over India
 - [https://www.bbc.co.uk/sport/cricket/55121752](https://www.bbc.co.uk/sport/cricket/55121752)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 12:04:09+00:00

Steve Smith scores his second century in as many games as Australia beat India by 51 runs in the second one-day international to win the series.

## Brexit: UK in 'last leg' of trade talks with EU, says Raab
 - [https://www.bbc.co.uk/news/uk-politics-55120814](https://www.bbc.co.uk/news/uk-politics-55120814)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 12:02:21+00:00

The foreign secretary said a deal was possible if the EU side showed "pragmatism" in the coming days.

## Turkey cull after bird flu discovered at Northallerton farm
 - [https://www.bbc.co.uk/news/uk-england-york-north-yorkshire-55121445](https://www.bbc.co.uk/news/uk-england-york-north-yorkshire-55121445)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 12:01:57+00:00

All 10,500 turkeys will be culled after a strain of avian influenza was found in North Yorkshire.

## 'Fireball' dazzles in the sky in Japan
 - [https://www.bbc.co.uk/news/world-asia-55121824](https://www.bbc.co.uk/news/world-asia-55121824)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 11:54:07+00:00

The meteor was seen descending towards earth for a few seconds, before emitting a powerful light.

## Arcadia: Sir Philip Green 'must plug Arcadia pension hole'
 - [https://www.bbc.co.uk/news/business-55089327](https://www.bbc.co.uk/news/business-55089327)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 11:52:56+00:00

His retail empire, including Topshop and Dorothy Perkins, is understood to be on the brink of collapse.

## 'The Big Bash is the best competition in the world - The Hundred can a learn a lot'
 - [https://www.bbc.co.uk/sport/cricket/55114553](https://www.bbc.co.uk/sport/cricket/55114553)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 11:39:24+00:00

The Big Bash League in Australia sets the standard in women's cricket. How will The Hundred compare next summer?

## 'Rugby needs to change its laws to keep kids watching'
 - [https://www.bbc.co.uk/sport/rugby-union/55120613](https://www.bbc.co.uk/sport/rugby-union/55120613)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 11:24:56+00:00

Former England scrum-half Matt Dawson says rugby needs to change its laws to keep it entertaining for all fans.

## Utah monolith: Has the mysterious metal object disappeared?
 - [https://www.bbc.co.uk/news/world-us-canada-55119940](https://www.bbc.co.uk/news/world-us-canada-55119940)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 11:24:05+00:00

Utah officials and images on social media suggest the shiny desert structure has been taken down.

## Farm workers killed in 'insane' Nigeria attack
 - [https://www.bbc.co.uk/news/world-africa-55120638](https://www.bbc.co.uk/news/world-africa-55120638)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 10:55:08+00:00

Nigeria's president condemns an attack in which 43 labourers were "slaughtered" near Maiduguri.

## Adam King: Six-year-old Irish boy's space ambition 'inspires' Nasa
 - [https://www.bbc.co.uk/news/world-europe-55120209](https://www.bbc.co.uk/news/world-europe-55120209)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 09:53:41+00:00

Adam King from County Cork captured the hearts of TV viewers with dreams of joining a space mission.

## Liverpool: How one city took on the Covid-19 crisis
 - [https://www.bbc.co.uk/news/uk-politics-55106567](https://www.bbc.co.uk/news/uk-politics-55106567)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 09:51:55+00:00

The inside story of how Liverpool got to grips with soaring infection rates and pioneered mass testing.

## Sydney records hottest November night on record
 - [https://www.bbc.co.uk/news/world-australia-55118406](https://www.bbc.co.uk/news/world-australia-55118406)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 08:59:40+00:00

The Australian city recorded a minimum overnight temperature of 25.4C.

## 'Stop celebrity boxing, someone will get really hurt'
 - [https://www.bbc.co.uk/sport/boxing/55118880](https://www.bbc.co.uk/sport/boxing/55118880)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 08:45:12+00:00

Boxers are quick to question how former NBA basketball player Nate Robinson was allowed to be knocked out by YouTube star Jake Paul.

## Lorde on Antarctica: Thrilling and intense... but eerie
 - [https://www.bbc.co.uk/news/newsbeat-55085725](https://www.bbc.co.uk/news/newsbeat-55085725)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 08:03:16+00:00

The singer says she found inspiration for her next album during a visit to the bottom of the world.

## 'Like two of my uncles fighting at a barbecue' - Tyson and Jones draw exhibition bout
 - [https://www.bbc.co.uk/sport/boxing/55118877](https://www.bbc.co.uk/sport/boxing/55118877)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 07:25:06+00:00

Mike Tyson ends 15 years of inactivity and shares an entertaining draw with Roy Jones Jr in Los Angeles.

## Canada bans mass exports of prescription drugs
 - [https://www.bbc.co.uk/news/world-us-canada-55119428](https://www.bbc.co.uk/news/world-us-canada-55119428)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 06:06:08+00:00

The new policy comes in response to a US plan to import drugs from Canada.

## The Papers: Tory MPs' hospital anger, and PM 'in retreat'
 - [https://www.bbc.co.uk/news/blogs-the-papers-55118347](https://www.bbc.co.uk/news/blogs-the-papers-55118347)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 05:21:01+00:00

Sunday's papers are dominated by the new tier system, which has divided the Conservative party.

## The 'Robin Hood' policemen who stole from the Nazis
 - [https://www.bbc.co.uk/news/world-europe-guernsey-54106579](https://www.bbc.co.uk/news/world-europe-guernsey-54106579)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 00:20:26+00:00

How did 16 policemen come to be deported from the British Isles to Nazi-occupied Europe?

## Gary Barlow: 'I'm not as confident as I was at 21'
 - [https://www.bbc.co.uk/news/entertainment-arts-55091170](https://www.bbc.co.uk/news/entertainment-arts-55091170)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 00:17:17+00:00

The star discusses writing Back For Good in 15 minutes, and how Morecambe and Wise inspired a new song.

## Covid-19: What’s the harm of ‘funny’ anti-vaccine memes?
 - [https://www.bbc.co.uk/news/55101238](https://www.bbc.co.uk/news/55101238)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 00:17:10+00:00

Spreading jokes about vaccines can stoke unnecessary fears.

## Covid and schools: 'Children know things aren't right'
 - [https://www.bbc.co.uk/news/uk-55105275](https://www.bbc.co.uk/news/uk-55105275)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 00:15:39+00:00

Students have lost hundreds of days of education to Covid and self-isolation. How are they coping?

## London Bridge attack: 'I think about it every single day'
 - [https://www.bbc.co.uk/news/uk-55084126](https://www.bbc.co.uk/news/uk-55084126)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 00:14:27+00:00

Former prisoner Marc Conway remembers the London Bridge attack one year on.

## Serbia coronavirus: The Church losing its leaders to the pandemic
 - [https://www.bbc.co.uk/news/world-europe-55098412](https://www.bbc.co.uk/news/world-europe-55098412)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 00:08:50+00:00

Few organisations have taken a bigger hit from coronavirus than the Serbian Orthodox Church

## Rosamund Adoo-Kissi-Debrah: 'Did air pollution kill my daughter?'
 - [https://www.bbc.co.uk/news/stories-55106501](https://www.bbc.co.uk/news/stories-55106501)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 00:06:39+00:00

A new inquest into the death of Ella Adoo-Kissi-Debrah could list air pollution as a cause of her death.

## In pictures: Hurricanes leave Hondurans homeless and destitute
 - [https://www.bbc.co.uk/news/world-latin-america-55064560](https://www.bbc.co.uk/news/world-latin-america-55064560)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 00:05:39+00:00

Hurricanes Eta and Iota left more than 150,000 people in Honduras homeless and many lost everything.

## Khachaturyan sisters: A murder trial that shocked Russia
 - [https://www.bbc.co.uk/news/world-europe-55108072](https://www.bbc.co.uk/news/world-europe-55108072)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 00:02:10+00:00

The case of the three Khachaturyan sisters accused of killing their father sent shockwaves through Russia.

## TikTok: 'I didn’t know other LGBT Muslims existed'
 - [https://www.bbc.co.uk/news/uk-55079954](https://www.bbc.co.uk/news/uk-55079954)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 00:01:00+00:00

Until she found her social media "safe space", Shaz says she didn't know there were others like her.

## Ethiopia's Tigray crisis: What does it mean for the east Africa region?
 - [https://www.bbc.co.uk/news/world-africa-55108079](https://www.bbc.co.uk/news/world-africa-55108079)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 00:00:50+00:00

BBC correspondents across the east Africa region explain the impact for Ethiopia and its neighbours.

## Leroy Logan: Who is the Met Police officer in Steve McQueen's Red, White and Blue?
 - [https://www.bbc.co.uk/news/uk-55109363](https://www.bbc.co.uk/news/uk-55109363)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-29 00:00:10+00:00

Star Wars' John Boyega is set to star in the true story of a black police officer in 1980s London.

