# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## So Apparently Skyquakes Are A Thing | Answers With Joe
 - [https://www.youtube.com/watch?v=YWXESGggpLY](https://www.youtube.com/watch?v=YWXESGggpLY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2020-11-30 00:00:00+00:00

Unexplained noises from the sky have been reported for centuries, and while most can be explained by human actions today, many remain a bit of a mystery. So let's take a look at the mysterious phenomenon of skyquakes.

Quick note: Yes, this video had focus issues. There's a setting on the camera that doesn't jibe with the reflection on my glasses.

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

https://www.wect.com/story/13966313/whats-causing-the-booms-a-special-report/

https://portcitydaily.com/story/2017/10/06/operation-bumblebee-how-the-cold-war-and-space-race-got-their-start-on-topsail-our-ht/

https://www.democratandchronicle.com/story/rochester-magazine/finger-lakes/2016/03/22/seneca-guns-phenomenon/81978860/

https://www.livescience.com/59705-oozing-methane-blasts-craters-in-siberian-tundra.html

https://www.nbcnews.com/science/weird-science/conspiracy-theories-abound-u-s-military-closes-haarp-n112576

https://www.adn.com/alaska-news/2016/11/01/2-men-arrested-in-georgia-planned-to-attack-alaska-aurora-research-facility-investigators-say/

https://www.vanityfair.com/news/2019/01/the-real-story-behind-the-havana-embassy-mystery

https://www.atlasobscura.com/articles/the-persistent-mystery-of-the-kokomo-hum

https://www.sciencealert.com/earth-s-hum-recorded-bottom-of-the-ocean-permanent-free-oscillations

