# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## What's in my Tech Bag! [2020]
 - [https://www.youtube.com/watch?v=il9SZU_nsVc](https://www.youtube.com/watch?v=il9SZU_nsVc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-11-30 00:00:00+00:00

My tech everyday carry right now!
Giveaway details: https://dbrand.com/winners/giveaway-025
Twitter: http://twitter.com/MKBHD

That shirt! http://shop.MKBHD.com
Affiliate links included below:
Peak Design Everyday Backpack v2: https://amzn.to/36s3wwN
M1 13" MacBook Pro: https://amzn.to/36ly6rC
11" iPad Pro (2018): https://amzn.to/2VqqoWN
Apple Pencil: https://amzn.to/37j4SZW
MKBHD Microfiber: http://shop.MKBHD.com
AirPods Pro: https://amzn.to/37n7Egt
Vanja SD card reader: https://amzn.to/3fPj6FJ
Sony WH1000XM4: https://amzn.to/33uWrJM
Herschel Network Pouch [OLD]
Canon EOS R5: https://amzn.to/3fTfLoR
Canon 15-35 f/2.8 RF: https://amzn.to/36mUcdc
The pen: https://amzn.to/3fPi8cz
OnePlus Warp Charger: https://oneplus.com/product/oneplus-warp-charge-65-power-adapter
OnePlus 8 Pro: https://amzn.to/2HSia6M
iPhone 12 Pro Max: https://amzn.to/33rjR2E

