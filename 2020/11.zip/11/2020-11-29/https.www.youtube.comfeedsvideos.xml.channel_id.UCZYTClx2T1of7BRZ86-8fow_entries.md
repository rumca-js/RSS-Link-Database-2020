# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## 5 Tiny Animals With BIG Migrations
 - [https://www.youtube.com/watch?v=pacodnSWTqg](https://www.youtube.com/watch?v=pacodnSWTqg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2020-11-29 00:00:00+00:00

These little fliers may be small, but pound for pound, they go farther than just about anyone else.

Hosted by: Stefan Chin

SciShow has a spinoff podcast! It's called SciShow Tangents. Check it out at http://www.scishowtangents.org
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Jb Taishoff, Bd_Tmprd, Harrison Mills, Jeffrey Mckishen, James Knight, Christoph Schwanke, Jacob, Matt Curls, Sam Buck, Christopher R Boucher, Eric Jensen, Lehel Kovacs, Adam Brainard, Greg, Ash, Sam Lutfi, Piya Shedden, KatieMarie Magnone, Scott Satovsky Jr, Charles Southerland, charles george, Alex Hackman, Chris Peters, Kevin Bealer
----------
Looking for SciShow elsewhere on the internet?
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Tumblr: http://scishow.tumblr.com
Instagram: http://instagram.com/thescishow
----------
Sources:

https://www.nature.com/scitable/knowledge/library/animal-migration-13259533/
https://academic.oup.com/auk/article/133/2/237/5149176
https://www.britannica.com/topic/Homo-sapiens

https://www.fws.gov/pollinators/Features/Rufous.html
https://academic.oup.com/auk/article/133/2/237/5149176
https://link.springer.com/article/10.1186/1475-2891-4-36
http://www.bbc.com/earth/story/20150910-the-fattest-animal-on-earth 
https://academic.oup.com/jmammal/article/83/4/1020/2373111 

https://www.sciencemag.org/news/2016/12/radar-spots-trillions-unseen-insects-migrating-above-us
https://imagine.gsfc.nasa.gov/features/cosmic/earth_info.html
https://www.sciencedirect.com/science/article/abs/pii/S0960982219306050
https://www.sciencemag.org/news/2016/12/radar-spots-trillions-unseen-insects-migrating-above-us
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6502382/

https://www.fs.fed.us/wildflowers/pollinators/Monarch_Butterfly/migration/index.shtml
https://www.sciencedirect.com/science/article/pii/S0960982218302537
https://books.google.com/books?id=bBSws5_UMysC&lpg=PP26&ots=PD189Jhdwc&dq=monarch%20%22body%20length%22&pg=PP26#v=onepage&q=monarch%20%22body%20length%22&f=false
https://www.researchgate.net/profile/Tonya_Van_Hook/publication/241753822_Comparative_success_of_monarch_butterfly_migration_to_overwintering_sites_in_Mexico_from_inland_and_coastal_sites_in_Virginia/links/5446f4fa0cf22b3c14e0b87c.pdf
https://www.annualreviews.org/ento/doi/10.1146/annurev-ento-010814-020855
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3302836/

http://entnemdept.ufl.edu/walker/ufbir/chapters/chapter_11.shtml 
http://www.fao.org/ag/locusts/oldsite/LOCFAQ.htm 
https://link.springer.com/article/10.1023/A:1007529617032
https://www.nationalgeographic.com/animals/invertebrates/group/locusts/

https://royalsocietypublishing.org/doi/10.1098/rstb.1951.0003
https://www.healthline.com/nutrition/carb-loading
https://www.sciencedirect.com/science/article/abs/pii/0305049181903205
https://www.pnas.org/content/98/7/3895

https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3527571/
https://www.sciencemag.org/news/2016/03/tiny-dragonfly-shatters-insect-migration-record#
https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0148949

