## Lekarz: Strategia testowania i izolowania jest samobójcza
 - [https://tarnogorski.info/pilne-kierownik-oddzia/](https://tarnogorski.info/pilne-kierownik-oddzia/)
 - RSS feed: tarnogorski.info
 - date published: 2020-11-29 07:28:13+00:00

Lekarz: Strategia testowania i izolowania jest samobójcza

