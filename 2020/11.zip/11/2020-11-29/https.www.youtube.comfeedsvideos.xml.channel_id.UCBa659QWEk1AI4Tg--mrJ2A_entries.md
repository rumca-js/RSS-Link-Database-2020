# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## We walked the most dangerous path in Britain
 - [https://www.youtube.com/watch?v=mM7C_Pw7OL8](https://www.youtube.com/watch?v=mM7C_Pw7OL8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2020-11-30 00:00:00+00:00

The Broomway is surrounded on both sides by quicksand and deep, sucking mud. It has no markers and no guideposts. And if you mistime your walk, you won't outrun the tide. Oh, and it's in the middle of a Ministry of Defence firing range. But most of the time, if you want to visit Foulness Island, it's the only way.

Thanks to Tom Bennett: https://www.tombennettoutdoors.co.uk/

Filmed safely: https://www.tomscott.com/safe/

Edited by Michelle Martin https://twitter.com/mrsmmartin
Audio mix by Graham Haerther

REFERENCES:
Christy (1922): "A high road in the sea", The Windsor Magazine, volume 56, p556
MoD Shoeburyness Public Access Leaflet [PDF]: https://www.qinetiq.com/shoeburyness/-/media/3153cda9b4544222aaaa224ba88192a4.ashx


I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

