# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I'm Never Doing This Again.
 - [https://www.youtube.com/watch?v=SFUrdc8CEoo](https://www.youtube.com/watch?v=SFUrdc8CEoo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-11-30 00:00:00+00:00

Thanks to MSI for sponsoring this video (GIVEAWAY CLOSED)! Check out the products we featured in this video, below:
Buy MSI MPG GUNGNIR 110R
On Amazon (PAID LINK): https://geni.us/pMwkA
On Newegg (PAID LINK): https://geni.us/APk1xh6

Buy MSI Optix MAG27CQ
On Amazon (PAID LINK): https://geni.us/b7Ewdc
On Newegg (PAID LINK): https://geni.us/nqAdblI
On B&H (PAID LINK): https://geni.us/jQYsu7

Buy MSI MPG Z490 Gaming Carbon
On Amazon (PAID LINK): https://geni.us/gdPskZ
On Newegg (PAID LINK): https://geni.us/uuFC06
On B&H (PAID LINK): https://geni.us/EtyepE

Buy G.SKILL TridentZ RGB Series 16GB
On Amazon (PAID LINK): https://geni.us/BWw6P
On Newegg (PAID LINK): https://geni.us/2YC73C
On B&H (PAID LINK): https://geni.us/QBtBD

Buy Intel Core i7-10700K
On Amazon (PAID LINK): https://geni.us/9pIggtA
On Newegg (PAID LINK): https://geni.us/YZ5BAyy
On B&H (PAID LINK): https://geni.us/yKJTi

Buy Corsair RM850x
On Amazon (PAID LINK): https://geni.us/G5Dhl
On Newegg (PAID LINK): https://geni.us/W5wG

Buy Nvidia RTX 3070
On Amazon (PAID LINK): https://geni.us/eyZw75
On Newegg (PAID LINK): https://geni.us/PKbAj4
On B&H (PAID LINK): https://geni.us/h7P9

Buy Sabrent Rocket 1TB M.2 NVMe SSD
On Amazon (PAID LINK): https://geni.us/f6WusK
On Newegg (PAID LINK): https://geni.us/1NfWq
On B&H (PAID LINK): https://geni.us/upycY3

Buy MSI MAG CORELIQUID 240R AIO
On Amazon (PAID LINK): https://geni.us/C2WHXJ
On Newegg (PAID LINK): https://geni.us/u3jCt
On B&H (PAID LINK): https://geni.us/OWoRY

Buy MSI Clutch GM30
On Amazon (PAID LINK): https://geni.us/wY1VB
On Newegg (PAID LINK): https://geni.us/gt4wyP
On B&H (PAID LINK): https://geni.us/umRs

Buy MSI Vigor GK50 Elite LL
On Amazon (PAID LINK): https://geni.us/8mlB
On Newegg (PAID LINK): https://geni.us/RIKr3Dk
On B&H (PAID LINK): https://geni.us/EezRD

Buy MSI Immerse GH50
On Amazon (PAID LINK): https://geni.us/YoQsf
On Newegg (PAID LINK): https://geni.us/8GHK0
On B&H (PAID LINK): https://geni.us/beMu

Buy MSI VIGOR WR01
On Amazon (PAID LINK): https://geni.us/fd9j
On Newegg (PAID LINK): https://geni.us/bXA283Check out the products we featured in this video, below:

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1275471-im-never-doing-this-again/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Official Game Store: https://www.nexus.gg/ltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

## Apple Destroyed my Expectations. - M1 Mac Mini Review
 - [https://www.youtube.com/watch?v=4MkrEMjPk24](https://www.youtube.com/watch?v=4MkrEMjPk24)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-11-29 00:00:00+00:00

The first 100 people to go to https://blinkist.com/linustechtips are going to get unlimited access for 1 week to try it out. You’ll also get 25% off if you want the full membership.

Save 10% and Free Worldwide Shipping at Ridge Wallets by using offer code LINUS at https://www.ridge.com/LINUS

We finally got our hands on Apple Silicon and put it through its paces to answer the question on everyone’s mind: Can it really replace Intel and provide a smooth desktop experience?

Buy Apple Mac Mini M1
On Amazon (PAID LINK): https://geni.us/JEzh
On Best Buy (PAID LINK): https://geni.us/mmRBV
On B&H (PAID LINK): https://geni.us/b8lWK1

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1274718-apple-destroyed-my-expectations/


►GET MERCH: http://www.LTTStore.com/
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Nerd or Die Stream Overlays: https://lmg.gg/avLlO
►NEEDforSEAT Gaming Chairs: https://lmg.gg/DJQYb
►Displate Metal Prints: https://lmg.gg/displateltt
►Official Game Store: https://www.nexus.gg/ltt
►Epic Games Store (LINUSMEDIAGROUP): https://lmg.gg/kRTpY
►Amazon Prime: https://lmg.gg/8KV1v
►Audible Free Trial: https://lmg.gg/8242J
►Streamlabs Prime: https://geni.us/cOHCiHh
►Our Gear on Amazon: https://geni.us/OhmF

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

