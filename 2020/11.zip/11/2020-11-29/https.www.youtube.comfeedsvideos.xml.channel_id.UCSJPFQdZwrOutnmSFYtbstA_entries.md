# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## The Lighthouse - Glorious Insanity
 - [https://www.youtube.com/watch?v=b1s-7EuKvn4](https://www.youtube.com/watch?v=b1s-7EuKvn4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-11-30 00:00:00+00:00

The Lighthouse is one of the most bonkers movies I've seen in years, but it's also awesome. Grab several stiff drinks and join me as I try to make sense of it. 


Want to help support this channel? 



Check out my books on Amazon: https://www.amazon.com/Will-Jordan/e/B00BCO7SA8%3Fref=dbs_a_mng_rwt_scns_share
Subscribe on Patreon: https://www.patreon.com/TheCriticalDrinker
Subscribe on SubscribeStar: https://www.subscribestar.com/the-critical-drinker

