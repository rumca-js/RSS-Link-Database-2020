# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## The Best Boss Fight in Dark Souls Discussion | Slightly Post-War Podcast
 - [https://www.youtube.com/watch?v=VC6KJREJqBQ](https://www.youtube.com/watch?v=VC6KJREJqBQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-11-30 00:00:00+00:00

Watch the animated episode: https://www.escapistmagazine.com/v2/which-is-the-best-boss-fight-in-dark-souls-slightly-civil-war/

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Which Is The Best Boss Fight in Dark Souls? | Slightly Civil War
 - [https://www.youtube.com/watch?v=k-GJEBXiBjE](https://www.youtube.com/watch?v=k-GJEBXiBjE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-11-30 00:00:00+00:00

Watch the Post-War podcast: https://youtu.be/VC6KJREJqBQ

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## The Open World Bloat Problem (and How Assassin's Creed Valhalla Kinda Fixes It)
 - [https://www.youtube.com/watch?v=eWkSQJXuAoA](https://www.youtube.com/watch?v=eWkSQJXuAoA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-11-29 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

This week on The Escapist Show, Jack is back in Dark Souls, Nick finished Sekiro and we discuss the open world bloat problem currently plaguing the AAA games industry.

Timestamps:
Jack's back on Dark Souls and Salt & Sanctuary - 0:00 - 5:17
Nick finally finished Sekiro - 5:18 - 10:19
The open world bloat problem - 10:20 - 24:35



Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

