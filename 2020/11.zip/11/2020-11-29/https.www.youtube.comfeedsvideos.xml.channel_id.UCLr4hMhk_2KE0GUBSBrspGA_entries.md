# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week: Fake Friday
 - [https://www.youtube.com/watch?v=tBkmoaYOfwM](https://www.youtube.com/watch?v=tBkmoaYOfwM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-11-29 00:00:00+00:00

Stories są wszędzie! Za chwilę będą też w Uberze. Elon Musk jest coraz bogatszy, a smartfony rosną wszerz. 
Książka o instagramie po polsku: http://wydawnictwofeeria.pl/pl/ksiazka/instagram
Moje sociale:
Insta: http://bit.ly/InstaKlawiatur 
Twitter: http://bit.ly/TTKlawitera
FB: http://bit.ly/FBKlawiatur

Źródła: 
Elon Musk jeszcze bogatszy: https://bit.ly/3qby6SX
Oppo X 2021: https://bit.ly/2JnbwGe
Nowe słuchawki Samsunga nie będą fasolkami: https://bit.ly/2Vh20ak
OnePlus 8T CyberPunk Edition: https://youtu.be/652XQSLjTcE
POCO M3: https://bit.ly/33nbEN1
Jabra Elite 85T: https://bit.ly/3lhm5YE
Snap Spotlight: https://cnb.cx/3mlxR5o
Snap ma 250 milionów aktywnych użytkowników: https://bit.ly/3llyOt4
Autonomiczny kurczak z KFC: https://cnet.co/3fK1hrA

