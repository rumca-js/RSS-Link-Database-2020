# Source:Ryan George, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ, language:en-US

## How They Wrote Classic Christmas Songs
 - [https://www.youtube.com/watch?v=6eBS73uwVHs](https://www.youtube.com/watch?v=6eBS73uwVHs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ
 - date published: 2020-11-30 00:00:00+00:00

Special Cyber deal! Every purchase of a 2 year plan will get 70% off + 1 month FREE! Go to https://nordpass.com/ryangeorge and get NordPass for only $1.49 a month.

In the meadow we can build a snowman
And pretend that he is Parson Brown
He'll say "Are you married?"
We'll say "No man"
You can do the job
When you're in town

Hi there hello please click the subscribe button and turn on notifications so I can feed my cats.
Twitter/Instagram: @TheRyanGeorge

