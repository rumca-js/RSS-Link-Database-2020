# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## How I Found My Purpose In Life | Russell Brand
 - [https://www.youtube.com/watch?v=bdUn_5SxEsU](https://www.youtube.com/watch?v=bdUn_5SxEsU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-11-29 00:00:00+00:00

How I found my purpose and sense of meaning in life. 
I look back at the firs time I stood on stage and embarked on my acting career, and how it made me feel. I also end this video with a short guided meditation.

Here are some more videos like this one: https://www.youtube.com/watch?v=wmPPvPkEaEA&list=PL5BY9veyhGt47NoUFchwKbpfjv5jRbC8s

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

