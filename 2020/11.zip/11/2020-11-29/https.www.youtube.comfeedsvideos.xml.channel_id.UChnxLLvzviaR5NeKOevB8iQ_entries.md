# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Intellijel Shifty - Hocketing for Fun and Profit
 - [https://www.youtube.com/watch?v=RJyUbhJYVT8](https://www.youtube.com/watch?v=RJyUbhJYVT8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2020-11-30 00:00:00+00:00

Intellijel Shifty can do fun things to your melodies by spreading them all over your rack. Let's give it a try! Watch just jams from this process over here: https://youtu.be/MrgB-_35W14

https://intellijel.com/shop/eurorack/shifty/
------------------------------------
Thank you for watching. My name is Jeremy, and this is Red Means Recording. I've been making music for a few decades now, and this channel is a place to make music and to talk about the tools and techniques to make music with. We'll use synths, drum machines, modular gear, and software. 

If you'd like to support the channel, I have a Patreon:  http://bit.ly/rmrpatreon

I have music as "Jeremy Blake" on all the major services: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

I have some merch here: http://bit.ly/rmrshirts

And you can connect with me here: 
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

