# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Tricky - Performance & Interview (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=nx1D_A9wAQc](https://www.youtube.com/watch?v=nx1D_A9wAQc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-11-30 00:00:00+00:00

http://KEXP.ORG presents Tricky sharing a live session recorded exclusively for KEXP and talking to the Afternoon Show's Larry Mizell, Jr.. Recorded November 23, 2020.

Songs:
Thinking Of
Chills Me To The Bone
Fall Please
Breathe Me Right In
Hate This Pain

Recorded and mixed at JRS Studios in Berlin

Music and vocals - Tricky
Vocals - Marta Zlakowska
Guitar and keys - Mariin Kallikorm
Cello - Marie-Claire Schaemus
Additional guitar - Jose Torelli

Filming and editing - Sander Houtkruijer
DOP & Gaffer - Carlos Vasquez
Recording engineer & mixing - Axel Reinemer
Assistant recording engineer - Jose Torelli

https://www.trickysite.com
http://kexp.org

