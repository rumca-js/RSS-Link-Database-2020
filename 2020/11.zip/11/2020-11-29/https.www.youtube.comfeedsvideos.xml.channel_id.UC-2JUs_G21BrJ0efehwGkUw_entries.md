# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Give Me One Reason | Tracy Chapman | funk cover ft. George Krikes
 - [https://www.youtube.com/watch?v=zdQTMX6-qug](https://www.youtube.com/watch?v=zdQTMX6-qug)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2020-11-30 00:00:00+00:00

Patreon: http://modal.scarypocketsfunk.com/patreon
Store: https://www.scarypocketsfunk.com
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A cover of "Give Me One Reason" by Scary Pockets.

CREDITS
Lead vocal: George Krikes
Drums: Kyle Crane
Bass: Sam Wilkes
Keys: Jack Conte
Guitar: Ryan Lerman
Additional keys, guitar, drums, BGVs: Jeremy Most

Recording Engineer: Caleb Parker
Mixing/Mastering: Caleb Parker
Producer: Jeremy Most
Assistant Producer: Brian Green
Cinematography: Ricky Chavez
Camera Operators: Sammy Rothman, Joey Graziano, Ricky Chavez
Video editor: Adam Kritzberg
Director: Mike Dempsey

Recorded Live at Valentine Studios in Los Angeles, CA.

Watch more videos! 
Scary Pockets: https://youtube.com/playlist?list=PLL3xcB0B80KV06T2lqZhG5zUZuwojwuex&playnext=1 
90s Hits Funkified: https://youtube.com/playlist?list=PLL3xcB0B80KX25RsNBxJeuiO0YuJNWH46&playnext=1 
Scary Goldings: https://youtube.com/playlist?list=PLL3xcB0B80KWCRIVdgwL5ayqAczyccWNW&playnext=1 
Most Popular: https://youtube.com/playlist?list=PLL3xcB0B80KWzWR4-NxRrmRDwAnZfEXXr&playnext=1 

About Scary Pockets 
We are Scary Pockets, a funk band that releases weekly music videos, in pursuit of the funk. Scary Pockets is Ryan Lerman and Jack Conte, with the help and support from a rotating roster of the best session musicians in the LA area. Make sure to subscribe and enable ALL notifications! 

#ScaryPockets #Funk #GiveMeOneReason #TracyChapman #GeorgeKrikes

