# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 GENIUS Game Concepts of 2020
 - [https://www.youtube.com/watch?v=JEgcXQE7DRE](https://www.youtube.com/watch?v=JEgcXQE7DRE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-11-30 00:00:00+00:00

Many new games from 2020 introduced creative game concepts we think are worth highlighting. 
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 10 WEIRD Gaming Stories of November 2020
 - [https://www.youtube.com/watch?v=oYtir-SQ_BY](https://www.youtube.com/watch?v=oYtir-SQ_BY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-11-30 00:00:00+00:00

November 2020 was filled with surprises in gaming news, with crazy stories involving Cyberpunk 2077, virtual football games, PS5 mistakes, and more.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

