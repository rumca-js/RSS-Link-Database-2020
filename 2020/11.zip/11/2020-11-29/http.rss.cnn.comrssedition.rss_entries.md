# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Cher sings to 'the world's loneliest elephant'
 - [https://www.cnn.com/videos/travel/2020/11/29/cher-elephant-rescue-kaavan-pakistan-travel-orig-ch.cnn](https://www.cnn.com/videos/travel/2020/11/29/cher-elephant-rescue-kaavan-pakistan-travel-orig-ch.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-29 22:17:33+00:00

Kaavan the elephant had languished in a zoo in Pakistan for decades. But thanks to Cher and a social media campaign, he's on his way to a new home in Cambodia.

## Trump admits 'it's hard to get to the Supreme Court'
 - [https://www.cnn.com/videos/media/2020/11/29/donald-trump-fox-news-legal-cases-supreme-court-nr-vpx.cnn](https://www.cnn.com/videos/media/2020/11/29/donald-trump-fox-news-legal-cases-supreme-court-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-29 19:57:23+00:00

CNN's Amara Walker and Carl Bernstein discuss President Trump's admission during a Fox News interview that "it's hard" to get cases to the Supreme Court and how Trump's continued legal challenges could undermine future election processes.

## Jon Ossoff defends claim that GOP senator is a 'crook'
 - [https://www.cnn.com/videos/politics/2020/11/29/jon-ossoff-perdue-pushback-bash-intv-sotu-vpx.cnn](https://www.cnn.com/videos/politics/2020/11/29/jon-ossoff-perdue-pushback-bash-intv-sotu-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-29 16:31:13+00:00

CNN's Dana Bash pushed back on Georgia Senate-challenger Jon Ossoff's claim that Sen. David Perdue (R-GA) is a "crook."

## David Prowse, the original Darth Vader, dies aged 85
 - [https://www.cnn.com/2020/11/29/entertainment/david-prowse-darth-vadar-star-wars-dies-gbr-scli-intl/index.html](https://www.cnn.com/2020/11/29/entertainment/david-prowse-darth-vadar-star-wars-dies-gbr-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-29 16:02:04+00:00

British actor David Prowse, who played Darth Vader in the original "Star Wars" trilogy, has died aged 85, his management company announced Sunday.

## F1 driver Grosjean involved in horror crash during Bahrain GP
 - [https://www.cnn.com/2020/11/29/motorsport/formula-one-crash-romain-grosjean-bahrain-grand-prix-spt-intl/index.html](https://www.cnn.com/2020/11/29/motorsport/formula-one-crash-romain-grosjean-bahrain-grand-prix-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-29 15:57:34+00:00

Formula One driver Romain Grosjean was involved in a horrific crash that left his car engulfed in flames at the Bahrain Grand Prix on Sunday, causing the race to be halted.

## Car bomb kills at least 40 Afghan soldiers
 - [https://www.cnn.com/2020/11/29/middleeast/car-bomb-afghanistan-intl/index.html](https://www.cnn.com/2020/11/29/middleeast/car-bomb-afghanistan-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-29 15:52:16+00:00

A car bomb attack in Afghanistan's central province of Ghazni killed at least 40 Afghan soldiers and wounded 24, Ghazni public health department told CNN on Sunday.

## Republican senator says he hopes Trump will attend inauguration
 - [https://www.cnn.com/videos/politics/2020/11/29/roy-blunt-trump-biden-inauguration-intv-sotu-bash-vpx.cnn](https://www.cnn.com/videos/politics/2020/11/29/roy-blunt-trump-biden-inauguration-intv-sotu-bash-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-29 15:10:12+00:00

During an interview with CNN's Dana Bash, Sen. Roy Blunt (R-MO) said he hopes President Trump will attend the inauguration of President-elect Joe Biden.

## Biden administration prepares to inherit controversial Trump immigration policies
 - [https://www.cnn.com/2020/11/29/politics/biden-trump-immigration/index.html](https://www.cnn.com/2020/11/29/politics/biden-trump-immigration/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-29 15:02:48+00:00

When President-elect Joe Biden comes into office, he will inherit the Trump administration's restrictionist immigration agenda, which cut access to asylum and has kept migrants in limbo in Mexico while they await humanitarian protection in the US.

## Opinion: Trump transition show is jumping the shark
 - [https://www.cnn.com/2020/11/29/opinions/trump-transition-jumping-shark-opinion-column-carr/index.html](https://www.cnn.com/2020/11/29/opinions/trump-transition-jumping-shark-opinion-column-carr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-29 14:47:03+00:00

If your grandparents or great-grandparents were living in Mississippi, Colorado or Texas in 1939 (like two of mine were), they may have celebrated Thanksgiving twice, thanks to Franklin D. Roosevelt's effort to bail out struggling retailers by moving Thanksgiving up a week -- thus extending the holiday shopping season.

## Analysis: The worsening pandemic raises the stakes for Biden's economic program
 - [https://www.cnn.com/2020/11/29/politics/biden-economic-policies-covid/index.html](https://www.cnn.com/2020/11/29/politics/biden-economic-policies-covid/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-29 14:15:35+00:00

Sitting in an Iowa diner a year ago, candidate Joe Biden aimed his economic agenda at the widening gap between America's rich and everyone else.

## Denver Broncos have no quarterbacks for Saints game due to NFL Covid-19 protocols
 - [https://www.cnn.com/2020/11/29/sport/nfl-denver-broncos-quarterbacks-ineligible/index.html](https://www.cnn.com/2020/11/29/sport/nfl-denver-broncos-quarterbacks-ineligible/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-29 12:44:03+00:00

The Denver Broncos have lost all of their quarterbacks for Sunday's game against the New Orleans Saints, after they were declared ineligible for play due to NFL Covid-19 protocols.

## Mike Tyson's boxing comeback ends in draw
 - [https://www.cnn.com/2020/11/29/sport/mike-tyson-roy-jones-jr-wins-frontline-battle-trnd/index.html](https://www.cnn.com/2020/11/29/sport/mike-tyson-roy-jones-jr-wins-frontline-battle-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-29 12:02:04+00:00

The 8-round exhibition fight between Mike Tyson and Roy Jones Jr. on Saturday ended in a draw.

## In Japan, more people died from suicide last month than from Covid in all of 2020
 - [https://www.cnn.com/2020/11/28/asia/japan-suicide-women-covid-dst-intl-hnk/index.html](https://www.cnn.com/2020/11/28/asia/japan-suicide-women-covid-dst-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-29 11:46:44+00:00

• Covid's horrific toll on Japanese women
• Covid updates: Hong Kong reports highest single-day increase since August

## The mysterious silver monolith in the Utah desert has disappeared
 - [https://www.cnn.com/2020/11/28/us/utah-monolith-disappears-trnd/index.html](https://www.cnn.com/2020/11/28/us/utah-monolith-disappears-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-29 11:15:33+00:00

A tall, silver, shining metal monolith discovered in the desert in southeastern Utah -- which prompted theories of alien placement and drew determined hikers to its secret location -- has now disappeared, the state's Bureau of Land Management said Saturday.

## All Blacks great Dan Carter on the 'roller coaster of emotions' of his playing career and the importance of mental health
 - [https://www.cnn.com/2020/11/29/sport/dan-carter-mental-health-rugby-spt-intl-cmd/index.html](https://www.cnn.com/2020/11/29/sport/dan-carter-mental-health-rugby-spt-intl-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-29 11:15:20+00:00

Rugby, like any professional sport, comes with ecstatic highs and gut-wrenching lows -- something Dan Carter knows better than most.

## Was Chopin gay? The awkward question in one of EU's worst countries for LGBTQ rights
 - [https://www.cnn.com/2020/11/29/europe/chopin-sexuality-poland-lgbtq-debate-scli-intl/index.html](https://www.cnn.com/2020/11/29/europe/chopin-sexuality-poland-lgbtq-debate-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-29 08:35:32+00:00

Each year, millions of visitors to Poland are introduced to the country's favorite son before they even set foot on its soil.

## Catch a lunar eclipse during the full beaver moon this weekend
 - [https://www.cnn.com/2020/11/29/world/lunar-eclipse-full-beaver-moon-2020-scn-trnd/index.html](https://www.cnn.com/2020/11/29/world/lunar-eclipse-full-beaver-moon-2020-scn-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-29 08:01:08+00:00

Take a break from online holiday shopping this weekend to enjoy the full moon and a penumbral lunar eclipse.

## Christmas movies you didn't know were Christmas movies
 - [https://www.cnn.com/2020/11/29/entertainment/christmas-movies-2020-trnd/index.html](https://www.cnn.com/2020/11/29/entertainment/christmas-movies-2020-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-29 07:03:45+00:00

There are only so many times you can watch "The Princess Switch."

## Most Shazamed song of all time revealed
 - [https://www.cnn.com/2020/11/29/entertainment/dance-monkey-shazam-record-trnd/index.html](https://www.cnn.com/2020/11/29/entertainment/dance-monkey-shazam-record-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-29 06:07:44+00:00

"Dance Monkey" by Tones and I has become the most popular song on Shazam, according to Guinness World Records.

## Sydney endures hottest November night ever
 - [https://www.cnn.com/2020/11/29/australia/australia-fire-danger-intl-hnk/index.html](https://www.cnn.com/2020/11/29/australia/australia-fire-danger-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-29 05:31:30+00:00

Parts of Australia, including Sydney, sweltered through the hottest November night on record with temperatures likely to stay high on Sunday -- prompting authorities to issue a total fire ban.

## Pennsylvania dismisses another Republican lawsuit trying to block vote certification
 - [https://www.cnn.com/2020/11/28/politics/pennsylvania-state-supreme-court-election-case/index.html](https://www.cnn.com/2020/11/28/politics/pennsylvania-state-supreme-court-election-case/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-29 02:21:15+00:00

• Watch: Former Trump official reacts to Trump's 'farcical' election claims
• Analysis: Defeats pile up as GOP worries over Trump's Georgia comments

## Secret warehouse parties get shut down
 - [https://www.cnn.com/videos/us/2020/11/29/secret-warehouse-parties-busted-pandemic-coronavirus-elam-dnt-nr-vpx.cnn](https://www.cnn.com/videos/us/2020/11/29/secret-warehouse-parties-busted-pandemic-coronavirus-elam-dnt-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-29 00:56:43+00:00

Even as cases and hospitalizations spike across the country, police are seeing a spate of crowded underground parties -- in violation of local coronavirus guidelines. CNN's Stephanie Elam reports these parties are getting shut down.

