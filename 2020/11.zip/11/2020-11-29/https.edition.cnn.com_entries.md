## In Japan, more people died from suicide last month than from Covid in all of 2020 | CNN
 - [https://edition.cnn.com/2020/11/28/asia/japan-suicide-women-covid-dst-intl-hnk/index.html](https://edition.cnn.com/2020/11/28/asia/japan-suicide-women-covid-dst-intl-hnk/index.html)
 - RSS feed: https://edition.cnn.com
 - date published: 2020-11-29 19:49:32+00:00

In Japan, more people died from suicide last month than from Covid in all of 2020 | CNN

