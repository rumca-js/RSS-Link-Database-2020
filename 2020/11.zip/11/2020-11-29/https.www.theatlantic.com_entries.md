## Car Tires Are a Major Pollution Problem - The Atlantic
 - [https://www.theatlantic.com/science/archive/2020/11/car-tires-pollution-microplastic/617216/](https://www.theatlantic.com/science/archive/2020/11/car-tires-pollution-microplastic/617216/)
 - RSS feed: https://www.theatlantic.com
 - date published: 2020-11-29 11:27:42+00:00

Car Tires Are a Major Pollution Problem - The Atlantic

