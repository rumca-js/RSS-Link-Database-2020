# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Covid symptoms: Is it a cold, flu or coronavirus?
 - [https://www.bbc.co.uk/news/health-54145299](https://www.bbc.co.uk/news/health-54145299)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-12 17:49:15+00:00

With similar symptoms, deciding whether or not you need to get tested for coronavirus can be tricky.

## Wrexham Roman villa uncovered by metal detectorists
 - [https://www.bbc.co.uk/news/uk-wales-54919775](https://www.bbc.co.uk/news/uk-wales-54919775)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-12 14:20:08+00:00

The villa near Wrexham is the first to be uncovered in north-east Wales, say archaeologists.

## Coronavirus: What is a recession and how could it affect me?
 - [https://www.bbc.co.uk/news/business-52986863](https://www.bbc.co.uk/news/business-52986863)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-12 13:45:20+00:00

The UK recession is over but the economy is not actually doing that well, so what does it all mean?

## Five Covid numbers to watch: Is Scotland turning a corner?
 - [https://www.bbc.co.uk/news/uk-scotland-54535938](https://www.bbc.co.uk/news/uk-scotland-54535938)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-12 12:17:44+00:00

The rate of new coronavirus cases appears to be slowing, but there are big variations in different parts of the country.

## Nottinghamshire councillor fist-pumps on learning grandfather news
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-54906695](https://www.bbc.co.uk/news/uk-england-nottinghamshire-54906695)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-12 01:57:47+00:00

Councillor John Cottee says he was "gobsmacked" when he learned the news.

## AC/DC: 'We're too stubborn to change'
 - [https://www.bbc.co.uk/news/entertainment-arts-54872166](https://www.bbc.co.uk/news/entertainment-arts-54872166)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2020-11-12 00:26:48+00:00

How the rock legends defied death, hearing loss and criminal charges to make their new album.

