# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## Bubble Breakup (ft. Rodrigo Fernandez-Stoll)
 - [https://www.youtube.com/watch?v=h40XGoolmiQ](https://www.youtube.com/watch?v=h40XGoolmiQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2020-11-12 00:00:00+00:00

Breakups are never easy, especially the one's regarding social distancing. Huge thank you to Rod for being in this video with me! Check him out on insta @rodontheinternet or on imdb: https://www.imdb.com/name/nm2162499/?ref_=vp_back

