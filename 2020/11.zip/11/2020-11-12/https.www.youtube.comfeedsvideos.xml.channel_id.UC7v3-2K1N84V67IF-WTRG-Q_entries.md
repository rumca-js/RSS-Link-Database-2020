# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Freaky - Movie Review
 - [https://www.youtube.com/watch?v=rnm_f7FwlR4](https://www.youtube.com/watch?v=rnm_f7FwlR4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-11-13 00:00:00+00:00

A Blumhouse Freaky Friday-ish body swap with a serial Killer and a Teen. Here's my review for FREAKY!

#Freaky #FreakyFriday

