# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Co było spontaniczne, a co wyreżyserowane na Marszu Niepodległości? Kulisy odwołania gen. Szymczyka
 - [https://www.youtube.com/watch?v=SXsUZxhJ4GY](https://www.youtube.com/watch?v=SXsUZxhJ4GY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2020-11-12 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Mroczne Podcasty: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
👀 Tatusiek: http://bit.ly/3aSCheE
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
🔒 Dołącz do Spółdzielni
https://discord.gg/RSEUaR3
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/2ETKSyN
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
🖼Grafika - wykorzystano elementy ze strony: 
policja.pl - http://bit.ly/2uCWMZ5
-------------------------------------------------------------
✅źródła:
https://bit.ly/3nhRWK3
https://bit.ly/32C2tIg
https://bit.ly/2GWNGQL
https://bit.ly/2Ujyu36
https://bit.ly/3njEntI
https://bit.ly/3f0Vz47
https://bit.ly/2Q1veXO
-------------------------------------------------------------

## Marsz Niepodległości: analiza filmów i zdjęć!
 - [https://www.youtube.com/watch?v=t2sOt003178](https://www.youtube.com/watch?v=t2sOt003178)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2020-11-12 00:00:00+00:00

🤪 Miło, że tutaj zajrzałeś.  Zapraszam do oglądania.

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Mroczne Podcasty: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
👀 Tatusiek: http://bit.ly/3aSCheE
------------------------------------------------------------
👀 twitter: http://bit.ly/2B6jTPd
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/2ETKSyN
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
---------------------------------------------------------------
✅źródła:
https://bit.ly/35luTYH
https://bit.ly/3nhIp5Q
https://bit.ly/32CReiN
https://bit.ly/3kojCet
https://bit.ly/35oSIi9
https://bit.ly/35metz6
https://bit.ly/2Ulludu
-------------------------------------------------------------

