# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## How a Civil War Could Start!
 - [https://www.youtube.com/watch?v=6luFJvZt-og](https://www.youtube.com/watch?v=6luFJvZt-og)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-11-12 00:00:00+00:00

Get your Magnesium Breakthrough Here - https://MagnesiumBreakthrough.com/JP

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Here’s the scenario of how a Civil War could start! Post 2020 election with the Associated Press announcing Biden as the winner yet the official vote count, recounts, and legal challenges are still in process, The wheels could potentially be set in motion for a Civil War if Donald Trump is found to be the legal winner of the election. Here’s how it could all happen!

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

