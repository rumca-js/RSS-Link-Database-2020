# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Hot Tub (the first track on our album!!!) - Pomplamoose
 - [https://www.youtube.com/watch?v=9YdQ6O7MJ30](https://www.youtube.com/watch?v=9YdQ6O7MJ30)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2020-11-12 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 Get the new album now + 50% off merch: http://www.patreon.com/pomplamoose
Space helmets: http://Etsy.com/shop/mwgray

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

An original song by Pomplamoose.

CREDITS

Lead Vocals: Nataly Dawn
Keys/Vibraphone: Jack Conte
Guitar: Ryan Lerman
Bass: Nick Campbell (video), Sam Wilkes (audio)
Drums: Ben Rose (video), Kyle Crane (audio)
Engineers: Chris Sorem & Tim Sonnefeld
Mixing/Mastering: Jack Conte
Directed by Jack Conte
Cinematography by George Sloan
Produced by Nataly Dawn & George Sloan
Edited by George Sloan
VFX by Jeremiah Durian-Williams
Colored by Anthony Tocchio
Playback and Production Assistance by Michael Dominguez

Recorded in Los Angeles.

LYRICS

Saturday is coming
And the forecast has improved
If you’re feeling sunny
Oh I might be in the mood
I’ve been waiting for this
Like a dog begs for his food
So if you’re feeling restless
Baby I’ve got plans for you
Just for you
 
Oh let’s go chill in the hot tub
I know we have work to do
But let’s blow it off
Cause enough is enough
Oh let’s go chill in the hot tub
I think it would do you good
To let off some steam
If you know what I mean
 
Saturday is coming
Oh the possibilities
Take me to the countryside
I don’t want to be reached
Baby you’ve been running
Like a dog chasing his tail
So tell me when you want it
Cause it’s time to treat yourself
Yeah it’s true

Oh let’s go chill in the hot tub
I think we have an extra suit
It’s a little bit small
You might not need it at all
Oh let’s go chill in the hot tub
There’s nothing I would rather do
We could live like kings
Put your beer in that floaty thing

