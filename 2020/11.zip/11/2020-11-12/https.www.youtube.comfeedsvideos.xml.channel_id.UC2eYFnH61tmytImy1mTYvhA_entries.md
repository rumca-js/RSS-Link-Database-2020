# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## Making the Best of Consooooomerism (Clark Howard meets Unabomber)
 - [https://www.youtube.com/watch?v=CUssEBApVPA](https://www.youtube.com/watch?v=CUssEBApVPA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-11-13 00:00:00+00:00

Every dollar you spend should make you more independent and less reliant on spending money. I talk about some of my autistic ways of penny-pinching. Buy cheap and quality stuff. Always constrain your buys.

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE: https://lukesmith.xyz/donate 💰😎👌💯
OR affiliate links to things l use:
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://brave.com/luk005 Get the Brave browser.
https://lbry.tv/$/invite/@Luke View my videos on LBRY. Get a bonus for joining.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase. We both get $10 in Bitcoin when you buy or sell $100 in cryptocurrencies.

## THE PLAN for Good Internet: Help and Suggestions Requested!
 - [https://www.youtube.com/watch?v=QLtU2cJE1d0](https://www.youtube.com/watch?v=QLtU2cJE1d0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-11-12 00:00:00+00:00

I'm about to put down a lot of money to finally getting good internet out here. I'm going to get a 4G LTE router to turn cell reception into internet usable at my house. The issue is I don't have cell reception either...

The three things I'm going to get are:
1) A Verizon unlimited and unmetered plan
2) A 4G LTE router that works with the Verizon system and has coaxial cable inputs
3) An antenna system that can connect to the router to get distant connections. The closest cell tower is a little under 10 miles away.

The issue is that I'm not sure how to get the *best* deals and best products for each of these purposes so I'm asking for help. I hope to buy what I need by the end of the week or maybe next week at the latest.

People have suggested the Mofi router and getting a parabolic grid or directional MIMO/Yagi antennas. If anyone has had experience please share them. I'll also need some Verizon plan, so if anyone knows where I can get an old grandfathered plan, feel free to tell me.

I'll be putting up videos of getting all of this stuff working.

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE: https://lukesmith.xyz/donate 💰😎👌💯
OR affiliate links to things l use:
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://brave.com/luk005 Get the Brave browser.
https://lbry.tv/$/invite/@Luke View my videos on LBRY. Get a bonus for joining.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase. We both get $10 in Bitcoin when you buy or sell $100 in cryptocurrencies.

