## Covid-19 vaccines may have potentially unpleasant side effects
 - [https://www.nbcnews.com/health/health-news/covid-19-vaccines-may-have-potentially-unpleasant-side-effects-n1247485](https://www.nbcnews.com/health/health-news/covid-19-vaccines-may-have-potentially-unpleasant-side-effects-n1247485)
 - RSS feed: https://www.nbcnews.com
 - date published: 2020-11-12 20:08:06+00:00

Covid-19 vaccines may have potentially unpleasant side effects

