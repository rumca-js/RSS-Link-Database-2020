# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## HomePod Mini Review: Big Sound, Tiny Box!
 - [https://www.youtube.com/watch?v=b7RhbRujjUA](https://www.youtube.com/watch?v=b7RhbRujjUA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-11-12 00:00:00+00:00

HomePod Mini gets better, the deeper you are in the ecosystem.

The 🍎 Ecosystem: https://youtu.be/KB4_WIPE7vo

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Arcades by C2C
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Speaker provided by Apple for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

