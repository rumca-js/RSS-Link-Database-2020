# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Upon A Burning Throne - REVIEW
 - [https://www.youtube.com/watch?v=QVXgg7WTnBA](https://www.youtube.com/watch?v=QVXgg7WTnBA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-11-13 00:00:00+00:00

My review of the indian inspired epic, Upon A Burning Throne. A TRULY epic fantasy well worth a lot of discussion. 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

## Way Of Kings Leather Bound ( KICKSTARTER ) Review
 - [https://www.youtube.com/watch?v=V86AQS2D7JU](https://www.youtube.com/watch?v=V86AQS2D7JU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-11-12 00:00:00+00:00

My review of the Way Of Kings Kickstarter leather bound editions. This kickstarter broke records, lets see if this version of the way of kings lives up to the hype! 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
Subreddit: https://www.reddit.com/r/danielgreene
Podcast: https://afictionalconversation.podbean.com/

