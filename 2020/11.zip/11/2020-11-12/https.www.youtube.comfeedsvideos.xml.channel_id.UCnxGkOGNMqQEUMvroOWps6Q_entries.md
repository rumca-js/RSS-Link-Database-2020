# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Is the Pandemic Enabling Phone Addiction?
 - [https://www.youtube.com/watch?v=d4K4oKXAz8I](https://www.youtube.com/watch?v=d4K4oKXAz8I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-11-13 00:00:00+00:00

#1564 w/Adam Alter:
https://open.spotify.com/episode/3olbOHISF2QiU27IwGf2xb?si=jKzVLCBDTvaohuW_cLYddA

## The Ethical Responsibilities of Tech Companies
 - [https://www.youtube.com/watch?v=2rIDRwS_NGI](https://www.youtube.com/watch?v=2rIDRwS_NGI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-11-13 00:00:00+00:00

#1564 w/Adam Alter:
https://open.spotify.com/episode/3olbOHISF2QiU27IwGf2xb?si=jKzVLCBDTvaohuW_cLYddA

## The Next Steps of Immersive Gaming
 - [https://www.youtube.com/watch?v=2lnmNN2zmgU](https://www.youtube.com/watch?v=2lnmNN2zmgU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-11-13 00:00:00+00:00

#1564 w/Adam Alter:
https://open.spotify.com/episode/3olbOHISF2QiU27IwGf2xb?si=jKzVLCBDTvaohuW_cLYddA

## Joe Reflects on Crazy David Blaine Podcast
 - [https://www.youtube.com/watch?v=0dQSxf5Hp70](https://www.youtube.com/watch?v=0dQSxf5Hp70)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-11-12 00:00:00+00:00

#1563 w/Tony Hinchcliffe:
https://open.spotify.com/episode/4qZHl4Mz0vh7poHKmgrd0B?si=cVdqFEsQTGiDmg-Y1aQJbQ

## Joe Rogan Talks About Chimp Attacks
 - [https://www.youtube.com/watch?v=bUV-tEhuwyU](https://www.youtube.com/watch?v=bUV-tEhuwyU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-11-12 00:00:00+00:00

#1563 w/Tony Hinchcliffe:
https://open.spotify.com/episode/4qZHl4Mz0vh7poHKmgrd0B?si=cVdqFEsQTGiDmg-Y1aQJbQ

## Joe Rogan on Possible Pacquiao vs. McGregor Fight
 - [https://www.youtube.com/watch?v=8_fZneeSYMI](https://www.youtube.com/watch?v=8_fZneeSYMI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-11-12 00:00:00+00:00

#1563 w/Tony Hinchcliffe:
https://open.spotify.com/episode/4qZHl4Mz0vh7poHKmgrd0B?si=cVdqFEsQTGiDmg-Y1aQJbQ

## Post Malone's Alien Moment - JRE Toons
 - [https://www.youtube.com/watch?v=CC_7903s8vo](https://www.youtube.com/watch?v=CC_7903s8vo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-11-12 00:00:00+00:00

Another hilarious moment animated by PaulyToon from the Joe Rogan Experience #1516 with Post Malone (https://youtu.be/G42RJ4mKj1k)

