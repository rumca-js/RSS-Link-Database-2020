# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Find It Hard To Meditate? Then Watch This... | Russell Brand
 - [https://www.youtube.com/watch?v=sbMWZZaT4Lk](https://www.youtube.com/watch?v=sbMWZZaT4Lk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-11-12 00:00:00+00:00

Do you Find It Hard To Meditate? Do you struggle with a chatty mind? 
Here are some of the advice and tips I was given about meditating when I first learning to meditate that still apply today!

If you enjoyed this video, check out my playlist on spirituality: https://www.youtube.com/playlist?list...

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

