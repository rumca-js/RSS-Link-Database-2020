# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## The Queen's Gambit - Review
 - [https://www.youtube.com/watch?v=7V5Rlwds4KM](https://www.youtube.com/watch?v=7V5Rlwds4KM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-11-09 00:00:00+00:00

The story of a girl who learns she has a natural talent for Chess who becomes a woman determined to be the best in the world. Here's my review for Netflix's THE QUEEN'S GAMBIT!

#TheQueensGambit #Netflix

