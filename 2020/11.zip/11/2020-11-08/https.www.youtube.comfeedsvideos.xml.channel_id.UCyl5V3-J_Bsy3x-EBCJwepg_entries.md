# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Austin Petersen on The Babylon Bee Podcast | Preview
 - [https://www.youtube.com/watch?v=KoJOPDD4Yug](https://www.youtube.com/watch?v=KoJOPDD4Yug)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-11-09 00:00:00+00:00

🎙 Tomorrow Austin Petersen joins Kyle and Ethan on The Babylon Bee podcast.

SUBSCRIBE TODAY! ▶️ http://bit.ly/TheBeeYouTube

## The Babylon Bee Reads An Angry Tweet
 - [https://www.youtube.com/watch?v=Dvh1Qs9gqDo](https://www.youtube.com/watch?v=Dvh1Qs9gqDo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-11-09 00:00:00+00:00

Kyle and Ethan from the Babylon Bee read hate mail from a military member that didn’t approve of a joke comparing McConnell to a sea turtle. We even read a love mail from an enthusiastic new member of the Babylon Bee subscribers. Every week the Babylon Bee will read the hate mail sent to us. 

See the full show here: https://youtu.be/-gHBdHTvRlw

Subscribe to the Babylon Bee to continue our reading of delicious hate mail. 

Hit the Bell to get your daily dose of fake news that you can trust.

