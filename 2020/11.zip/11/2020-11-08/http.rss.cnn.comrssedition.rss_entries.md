# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Alex Trebek, long-running 'Jeopardy' host, dead at 80
 - [https://www.cnn.com/2020/11/08/entertainment/alex-trebek-jeopardy-host-death-trnd/index.html](https://www.cnn.com/2020/11/08/entertainment/alex-trebek-jeopardy-host-death-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 23:28:09+00:00

Alex Trebek, the genial "Jeopardy!" host with all the answers and a reassuring presence in the TV game-show landscape for five decades, has died. He was 80 years old.

## Kamala Harris represents a new face of political power
 - [https://www.cnn.com/collections/intl-kamala-harris-content-11082020/](https://www.cnn.com/collections/intl-kamala-harris-content-11082020/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 23:22:41+00:00



## Biden plans executive actions that would undo Trump's policies
 - [https://www.cnn.com/collections/intl-biden-1107/](https://www.cnn.com/collections/intl-biden-1107/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 23:20:30+00:00



## Can Biden heal America?
 - [https://www.cnn.com/2020/11/08/world/meanwhile-in-america-november-8-intl/index.html](https://www.cnn.com/2020/11/08/world/meanwhile-in-america-november-8-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 22:38:53+00:00

The world took a momentous turn at 11:24 a.m. ET on Saturday: In the instant that CNN projected Joe Biden would become the 46th president, the United States embarked on a starkly different road than the one it would have barreled down had President Donald Trump won a second term.

## 'I had chills': 'Jeopardy!' producer on taping Trebek's final episode
 - [https://www.cnn.com/videos/media/2020/11/08/alex-trebek-jeopardy-executive-producer-mike-richards-intv-nr-vpx.cnn](https://www.cnn.com/videos/media/2020/11/08/alex-trebek-jeopardy-executive-producer-mike-richards-intv-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 22:29:08+00:00

"Jeopardy!" Executive Producer Mike Richards reflects on Alex Trebek's life after the longtime game show host passed away at age 80.

## Kevin de Bruyne misses penalty as Manchester City and Liverpool draw
 - [https://www.cnn.com/2020/11/08/football/manchester-city-liverpool-kevin-de-bruyne-spt-intl/index.html](https://www.cnn.com/2020/11/08/football/manchester-city-liverpool-kevin-de-bruyne-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 22:10:16+00:00

Kevin de Bruyne missed a penalty as Manchester City and Premier League champion shared a 1-1 draw on Sunday at the Etihad Stadium.

## Arkansas police chief resigns after calling for violence against Democrats
 - [https://www.cnn.com/2020/11/08/us/arkansas-police-chief-violence-parler-invs/index.html](https://www.cnn.com/2020/11/08/us/arkansas-police-chief-violence-parler-invs/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 22:01:57+00:00

An Arkansas police chief who posted calls for violence against Democrats on social media resigned from his job on Saturday.

## US sets another new record for the highest number of daily Covid-19 cases
 - [https://www.cnn.com/2020/11/08/health/us-coronavirus-sunday/index.html](https://www.cnn.com/2020/11/08/health/us-coronavirus-sunday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 21:44:55+00:00

After a week of dauntingly high numbers in all parameters of the pandemic, the US has reached another sobering mark: its highest number of new daily Covid-19 cases since the virus entered the country.

## Alex Trebek's life in pictures
 - [https://www.cnn.com/2020/11/08/entertainment/gallery/alex-trebek/index.html](https://www.cnn.com/2020/11/08/entertainment/gallery/alex-trebek/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 21:18:28+00:00

Alex Trebek, the genial "Jeopardy!" host with all the answers and a reassuring presence in the TV game-show landscape for five decades, has died. He was 80.

## Jared Kushner has approached Trump about conceding 2020 election
 - [https://www.cnn.com/2020/11/08/politics/jared-kushner-donald-trump-concession/index.html](https://www.cnn.com/2020/11/08/politics/jared-kushner-donald-trump-concession/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 20:52:26+00:00

Jared Kushner, President Donald Trump's son-in-law and senior adviser, has approached the President about conceding the election, two sources told CNN.

## Inside Trump's loss: A culmination of self-destructive decisions
 - [https://www.cnn.com/collections/intl-elex-trump-11082020/](https://www.cnn.com/collections/intl-elex-trump-11082020/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 19:41:25+00:00



## 'Trump can still win': The President's supporters remain defiant after Biden's victory
 - [https://www.cnn.com/2020/11/08/politics/trump-voters-react-to-election/index.html](https://www.cnn.com/2020/11/08/politics/trump-voters-react-to-election/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 19:39:38+00:00

When CNN and other news outlets projected on Saturday that Joe Biden had won the presidency, the streets of Democratic strongholds like New York, Washington and Chicago erupted in celebrations that lasted into the night.

## See Kamala Harris' ancestral village in India celebrate her election win
 - [https://www.cnn.com/videos/world/2020/11/08/kamala-harris-us-election-win-celebrated-in-thulasendrapuram-india-orig-kj.cnn](https://www.cnn.com/videos/world/2020/11/08/kamala-harris-us-election-win-celebrated-in-thulasendrapuram-india-orig-kj.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 18:56:29+00:00

The village of Thulasendrapuram celebrated Harris' election win with fireworks, music and a mural in her honor.

## Brian Stelter turned off Trump tweet notifications live on air
 - [https://www.cnn.com/2020/11/08/media/stelter-trump-tweet-notifications/index.html](https://www.cnn.com/2020/11/08/media/stelter-trump-tweet-notifications/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 18:45:50+00:00

With 73 days left of the Trump presidency, CNN's Chief Media Correspondent Brian Stelter turned off his notifications for Donald Trump's tweets live on air Sunday during "Reliable Sources."

## After 14 sons, couple welcomes a baby girl
 - [https://www.cnn.com/videos/us/2020/11/07/jay-kateri-schwandt-daughter-15-children-orig-llr.cnn](https://www.cnn.com/videos/us/2020/11/07/jay-kateri-schwandt-daughter-15-children-orig-llr.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 18:14:20+00:00

Jay and Kateri Schwandt are celebrating the birth of their first daughter, Maggie Jayne, who is the only girl out of 14 brothers.

## Bolivia's Luis Arce set to be sworn in as president as socialists return to power
 - [https://www.cnn.com/2020/11/08/americas/bolivia-luis-arce-inauguration-intl/index.html](https://www.cnn.com/2020/11/08/americas/bolivia-luis-arce-inauguration-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 16:21:19+00:00

Bolivia's Luis Arce will be inaugurated as President on Sunday, capping a tumultuous period for the Andean nation and ushering the socialists back into power after long-term leftist leader Evo Morales was ousted amid angry protests late last year.

## Stacey Abrams: It's a privilege to see yourself reflected in leadership
 - [https://www.cnn.com/videos/politics/2020/11/08/sotu-stacey-abrams-on-kamala-harris-postelex-sot-vpx.cnn](https://www.cnn.com/videos/politics/2020/11/08/sotu-stacey-abrams-on-kamala-harris-postelex-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 15:55:15+00:00

Stacey Abrams joins CNN's Jake Tapper to reflect on President-elect Joe Biden and Vice President-elect Kamala Harris' historic win, and what it means to have a woman of color elected to the office.

## Claims that dead people voted went viral. These are the facts
 - [https://www.cnn.com/2020/11/08/tech/michigan-dead-voter-fact-debunking/index.html](https://www.cnn.com/2020/11/08/tech/michigan-dead-voter-fact-debunking/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 15:47:32+00:00

To hear some people tell it -- including a handful of prominent Republicans, such as members of President Trump's family and supporters like former House Speaker Newt Gingrich and former acting Director of National Intelligence Richard Grenell -- you might think that Democrats were using dead people to steal Michigan's Electoral College votes from Trump.

## Tropical Storm Eta crashes into the coast of Cuba
 - [https://www.cnn.com/2020/11/08/weather/tropical-storm-eta-sunday-florida-gulf/index.html](https://www.cnn.com/2020/11/08/weather/tropical-storm-eta-sunday-florida-gulf/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 15:44:13+00:00

After Tropical Storm Eta moves through Cuba Sunday, it is expected to head straight for Florida -- and not just one part of Florida, but almost the entire state may feel the effects of Eta over the next several days.

## What Trump's four years taught me about the two White Americas
 - [https://www.cnn.com/2020/11/08/politics/trump-white-voters-blake/index.html](https://www.cnn.com/2020/11/08/politics/trump-white-voters-blake/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 15:14:22+00:00

Many scoffed when President Trump declared that he's done more for Black people than any president since Abraham Lincoln. But as I contemplate the end of Trump's presidency, I realize that he has set millions of Black Americans free in at least one disturbing way:

## Bayern Munich is 'best team in the world,' says rival
 - [https://www.cnn.com/2020/11/08/football/bayern-munich-borussia-dortmund-der-klassiker-spt-intl/index.html](https://www.cnn.com/2020/11/08/football/bayern-munich-borussia-dortmund-der-klassiker-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 15:10:58+00:00

It pitted two of European football's top strikers -- Robert Lewandowski and Erling Haaland -- against one another in arguably the Bundesliga's most prestigious game between champion Bayern Munich and long-time rival Borussia Dortmund.

## A small Irish town claims victory after Biden wins
 - [https://www.cnn.com/collections/intl-elex-colletion-misc-content-11082020/](https://www.cnn.com/collections/intl-elex-colletion-misc-content-11082020/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 15:00:15+00:00



## 'SNL' shows off Biden and Harris' victory speeches and a fictional Trump 'concession'
 - [https://www.cnn.com/collections/intl-snl-1108/](https://www.cnn.com/collections/intl-snl-1108/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 14:09:24+00:00



## Markets have had their election party. Is there a hangover coming?
 - [https://www.cnn.com/2020/11/08/investing/stocks-week-ahead/index.html](https://www.cnn.com/2020/11/08/investing/stocks-week-ahead/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 14:00:43+00:00

Like presidential elections, markets can be full of surprises. Despite protracted uncertainty surrounding the race for the White House and rising coronavirus cases in the United States and elsewhere, stocks ended the week higher.

## Emojis and emotion: LeBron James and Megan Rapinoe delight in Joe Biden and Kamala Harris win
 - [https://www.cnn.com/2020/11/08/sport/lebron-james-megan-rapinoe-biden-harris-us-presidential-election-spt-intl/index.html](https://www.cnn.com/2020/11/08/sport/lebron-james-megan-rapinoe-biden-harris-us-presidential-election-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 13:00:07+00:00

Emojis and emotion abounded on the social media accounts of LeBron James and Megan Rapinoe -- two of US President Donald Trump's fiercest critics from the sporting sphere -- as they congratulated President-elect Joe Biden and Vice President-elect Kamala Harris.

## In Georgia, John Lewis' district delivers poetic justice
 - [https://www.cnn.com/2020/11/08/politics/john-lewis-voting-legacy-atlanta-joe-biden-kamala-harris/index.html](https://www.cnn.com/2020/11/08/politics/john-lewis-voting-legacy-atlanta-joe-biden-kamala-harris/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 12:22:13+00:00

As the 2020 presidential election draws closer to a conclusion in Georgia, the state has offered a moving piece of poetic justice.

## Palestinian prisoner ends hunger strike after making deal with Israeli authorities
 - [https://www.cnn.com/2020/11/08/middleeast/maher-al-akhras-hunger-strike-israel-intl/index.html](https://www.cnn.com/2020/11/08/middleeast/maher-al-akhras-hunger-strike-israel-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 11:28:15+00:00

A Palestinian detainee held by Israel has ended a hunger strike lasting more than 100 days, after Israeli authorities agreed he would be freed at the end of the month and his administrative detention order would not be renewed, according to the Palestinian Prisoners Club, a Ramallah-based non-governmental organization that looks after the interests of Palestinian prisoners held in Israeli jails.

## Rory McIlroy bids to join golf's greats with career grand slam at Masters
 - [https://www.cnn.com/2020/11/08/golf/rory-mcilroy-masters-grand-slam-2020-spt-intl/index.html](https://www.cnn.com/2020/11/08/golf/rory-mcilroy-masters-grand-slam-2020-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 10:59:43+00:00

Rory McIlroy and his caddie Harry Diamond used to have a bet with each other during practice rounds.

## Six ways to take care of yourself and your community postelection
 - [https://www.cnn.com/2020/11/08/health/post-election-stress-anxiety-self-care-wellness/index.html](https://www.cnn.com/2020/11/08/health/post-election-stress-anxiety-self-care-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 10:39:58+00:00

No matter where you fall on the political spectrum, it's time to take a time-out and give yourself and your community a little TLC.

## Europe can shut down terror attacks quickly. But it's still unable to prevent them
 - [https://www.cnn.com/2020/11/08/europe/europe-terror-wave-intl/index.html](https://www.cnn.com/2020/11/08/europe/europe-terror-wave-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 09:44:52+00:00

As the horrors of Vienna unfurled, the timing and abhorrent methodology was familiar -- indiscriminate lethal violence against the undefended, the night before Austria's lockdown set in, and on the eve of the US presidential elections.

## Photos show a deserted Italy with new curfew regulations
 - [https://www.cnn.com/travel/article/italy-second-lockdown-photos/index.html](https://www.cnn.com/travel/article/italy-second-lockdown-photos/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 09:35:06+00:00

Hotels treating their few customers like royalty, empty art galleries where solo guests stand nose-to-nose with Renaissance art; and some of Europe's most famous open spaces with just a handful of people in them. The Italy of November 2020 is unlike anything that has gone before in the age of mass tourism.

## 'SNL' takes aim at the US presidential election
 - [https://www.cnn.com/videos/media/2020/11/08/snl-election-dave-chappelle-monologue-orig.cnn](https://www.cnn.com/videos/media/2020/11/08/snl-election-dave-chappelle-monologue-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 09:14:08+00:00

In the first episode since the election, "Saturday Night Live" took on the unusual presidential election and host Dave Chappelle offered some somber advice during his monologue.

## Scientists 3D print microscopic Star Trek spaceship that moves on its own
 - [https://www.cnn.com/2020/11/08/us/star-trek-3d-microscopic-spaceship-scn-trnd/index.html](https://www.cnn.com/2020/11/08/us/star-trek-3d-microscopic-spaceship-scn-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 06:17:20+00:00

A team of physicists at a university in the Netherlands have 3D-printed a microscopic version of the USS Voyager, an Intrepid-class starship from Star Trek.

## In photos: America reacts to Biden's victory
 - [https://www.cnn.com/2020/11/07/politics/gallery/america-reacts-to-new-president-2020/index.html](https://www.cnn.com/2020/11/07/politics/gallery/america-reacts-to-new-president-2020/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 03:16:32+00:00

It took several days of vote counting, but we finally have a projected winner in the 2020 presidential race.

## This was President-elect Biden's third run at the White House
 - [https://www.cnn.com/videos/politics/2020/11/07/president-elect-joe-biden-political-career-orig-me.cnn](https://www.cnn.com/videos/politics/2020/11/07/president-elect-joe-biden-political-career-orig-me.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 02:39:39+00:00

President-elect Joe Biden has been a politician for more than 50 years. From the Newcastle County Council to the White House, these are the moments that have defined his career.

## Cities erupt in celebration after Biden named winner
 - [https://www.cnn.com/collections/intl-elex-celebrations11082020/](https://www.cnn.com/collections/intl-elex-celebrations11082020/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 02:30:32+00:00



## Kamala Harris: Americans ushered in a new day
 - [https://www.cnn.com/videos/politics/2020/11/08/kamala-harris-speech-john-lewis-2020-election-postelex-sot-vpx.cnn](https://www.cnn.com/videos/politics/2020/11/08/kamala-harris-speech-john-lewis-2020-election-postelex-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 02:13:54+00:00

Vice President-elect Kamala Harris invoked the life and legacy of the late Rep. John Lewis during her opening remarks tonight, reminding Americans that "democracy is not guaranteed."

## Joe Biden pledges to unify, not divide, as president
 - [https://www.cnn.com/videos/politics/2020/11/07/joe-biden-victory-election-speech-president-pledge-national-address-sot-postelex-vpx.cnn](https://www.cnn.com/videos/politics/2020/11/07/joe-biden-victory-election-speech-president-pledge-national-address-sot-postelex-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 01:56:58+00:00

President-elect Joe Biden delivered his first address after American voters chose the Democrat as its 46th president, pledging "not to divide, but unify."

## Democrats won't know if they control the Senate until January
 - [https://www.cnn.com/collections/intl-congress-1108/](https://www.cnn.com/collections/intl-congress-1108/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2020-11-08 01:23:14+00:00



