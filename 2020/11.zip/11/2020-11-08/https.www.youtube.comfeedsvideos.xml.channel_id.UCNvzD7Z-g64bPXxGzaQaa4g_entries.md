# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 8 Little Things That ANNOY Gamers
 - [https://www.youtube.com/watch?v=bVJvkrCA0rU](https://www.youtube.com/watch?v=bVJvkrCA0rU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-11-09 00:00:00+00:00

Sometimes it's the tiny/meaningless issues in games that bother us the most. Here are some petty examples of things in games that drive us crazy.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Sources:

https://youtu.be/gv0DTcsHPfs

https://youtu.be/GK4PjNMlzUU

## 20 BIG Games That Have Been DELAYED
 - [https://www.youtube.com/watch?v=BYkkG9tSFkw](https://www.youtube.com/watch?v=BYkkG9tSFkw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-11-08 00:00:00+00:00

Sometimes the best video games are worth the wait. Here are a bunch of games delayed until 2021 at the very least.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

20 AVATAR: THE VIDEO GAME

PLATFORM: TBA

RELEASE DATE: TBA 



#19 HALO INFINITE

PLATFORM: PC XBOX ONE XSX

RELEASE DATE TBA 2021



#18 NO MORE HEROES 3

PLATFORM: SWITCH

RELEASE DATE 2021



#17 TALES OF ARISE

PLATFORM: PC PS4 XBOX ONE

RELEASE DATE TBA 2021



#16 DYING LIGHT 2

PLATFORM: PC PS5 PS4  XBOX ONE XSX

RELEASE DATE : TBA



#15 THE SETTLERS

PLATFORM: PC

RELEASE DATE TBA



#14 FAR CRY 6

PLATFORM: PC PS5 PS4  XBOX ONE XSX STADIA

RELEASE DATE TBA



#13 KENA BRIDGE OF SPIRITS

PLATFORM: PC PS4 PS5

RELEASE DATE Q1 2021



#12 OUTRIDERS 

PLATFORM: PC PS5 PS4  XBOX ONE XSX 

FEBRUARY 2, 2021

RELEASE DATE STADIA 2021



#11 DEATHLOOP

PLATFORM: PC PS5

RELEASE DATE Q2 2021



#10 CYBERPUNK 2077

PLATFORM: PC PS5 PS4  XBOX ONE XSX STADIA

RELEASE DATE 10 DECEMBER 2020



#9 CHIVALRY 2

PLATFORM:PC PS5 PS4  XBOX ONE XSX

RELEASE DATE TBA 2021 



#8 RAINBOW SIX QUARANTINE

PLATFORM: TBA

RELEASE DATE TBA 2021



#7 THE MEDIUM

PLATFORM : PC XSX

RELEASE DATE: JANUARY 28, 2021



#6 DESTRUCTION ALL STARS

PLATFORM: PS5

RELEASE DATE FEBRUARY 2021



#5 KERBAL SPACE PROGRAM 2

PLATFORM: PC PS4 PS5 XBOX ONE XSX

RELEASE DATE 2022



#4 PATH OF EXILE 3.13 EXPANSION

PLATFORM: PC

RELEASE DATE : TBA



#3 EVERSPACE 2

PLATFORM: PC PS4 XBOX ONE

RELEASE DATE TBA 2021



#2 NEW WORLD

PLATFORM: PC

RELEASE DATE Q2 2021



#1 VAMPIRE MASQUERADE THE BLOODLINES 2

PLATFORM: PC PS4 PS5 XBOX ONE XSX

RELEASE DATE 2021

