# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week: Musimy podbić Słowację. Aston Martin Fold, OnePlus 8T Cyberpunk, Xiaomi Mi Box 8K
 - [https://www.youtube.com/watch?v=YpQmzrA3ttg](https://www.youtube.com/watch?v=YpQmzrA3ttg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-11-08 00:00:00+00:00

Oraz kilka innych krajów. Ale najpierw Słowację. 
Link do koszulek: https://znosne.pl

Źródła:
Scam fajkowego Muska: https://bit.ly/3n98io3
Latający samochód: https://youtu.be/QAnIjwwzupI
Poprzedni latający samochód: https://youtu.be/gmirx_JPrnc
Aston Martin Fold: https://bit.ly/2U6izVH
Japończycy gubią słuchawki na torach: https://bit.ly/2IgNhct
OnePlus 8T Cyberpunk: https://bit.ly/3p6nmVs
Xiaomi Mi Box 8K: https://bit.ly/3eI5kE7
Konferencja Apple: https://youtu.be/5AwdkGKmZ0I
Czym będzie Airtag: https://bit.ly/3kcfDBF
Jakie będą AirPods Studio: https://bit.ly/38nzbR3
"Windowsowa" piosenka: https://bit.ly/35bCo4l
Szpara w Pixelu 5 jest ok: https://bit.ly/3lbO0de
Netflixowy kanał TV we Francji: https://bit.ly/2JDVdET

