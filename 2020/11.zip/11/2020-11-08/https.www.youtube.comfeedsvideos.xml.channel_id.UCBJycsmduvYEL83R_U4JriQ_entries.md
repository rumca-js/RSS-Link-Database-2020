# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## iPhone 12 Mini Review: Tiny Tradeoffs!
 - [https://www.youtube.com/watch?v=Yhze-aRR6o0](https://www.youtube.com/watch?v=Yhze-aRR6o0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-11-09 00:00:00+00:00

iPhone 12 Mini is truly a shrunken version of iPhone 12. Compact flagships aren't dead!
iPhone 12 Review: https://youtu.be/X1b3C2081-Q
iPhone 12 Pro Max: https://youtu.be/qrzCLgDplTw

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: http://youtube.com/20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by Apple for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

## iPhone 12 Pro Max Review: The Biggest Ever!
 - [https://www.youtube.com/watch?v=qrzCLgDplTw](https://www.youtube.com/watch?v=qrzCLgDplTw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-11-09 00:00:00+00:00

iPhone 12 Pro Max is massive in every way... And that's what it's best at.
iPhone 12 Pro: https://youtu.be/eWI_BtcDJu0
iPhone 12 Mini: https://youtu.be/Yhze-aRR6o0

Dbrand skins: http://dbrand.com/12-pro-max

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Who Are You by C2C
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by Apple for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

