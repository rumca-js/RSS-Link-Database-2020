# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Theoretical Physicist On How Physics Effects Morality | Russell Brand
 - [https://www.youtube.com/watch?v=-L7JMnpDueg](https://www.youtube.com/watch?v=-L7JMnpDueg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-11-08 00:00:00+00:00

A clip from my #UnderTheSkin podcast with theoretical physicist Carlo Rovelli on morality and science. You can listen to the rest of this podcast on Luminary: http://luminary.link/russell

Carlo’s latest book:
https://www.penguin.co.uk/books/318/318988/there-are-places-in-the-world-where-rules-are-less-important-tha/9780241454688.html

Twitter: @carlorovelli
Website: www.cpt.univ-mrs.fr/~rovelli/

If you're into Under The Skin - here's a playlist with more videos: https://www.youtube.com/playlist?list=PL5BY9veyhGt7eapYiWXyxGuSxTcysPpJ7

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

