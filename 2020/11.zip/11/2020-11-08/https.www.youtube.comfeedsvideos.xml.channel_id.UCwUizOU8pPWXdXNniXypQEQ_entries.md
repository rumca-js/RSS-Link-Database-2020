# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Biden Won! Here’s What You Need To Know
 - [https://www.youtube.com/watch?v=lBZ-KiYoU68](https://www.youtube.com/watch?v=lBZ-KiYoU68)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-11-08 00:00:00+00:00

Check out BLUblox, my favorite evidence based blue light glasses: https://www.blublox.com/jp
To get 15% off, use the discount code: JP

Biden won, here’s what you need to know! With our newly elected president, There are just a few things you definitely need to know so you can have absolute certainty and dispel any confusion.

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Listen and Subscribe to my NEW Podcast here: 
https://apple.co/3fFTbPC
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

