# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Let's Talk Eurorack Clock
 - [https://www.youtube.com/watch?v=bcIQIHxUsv4](https://www.youtube.com/watch?v=bcIQIHxUsv4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2020-11-09 00:00:00+00:00

Eurorack clock, gate, reset, and run are important parts of a Eurorack system, but not a lot of people consider them when building up their rack. I want to talk about what clock is, how it works, and what we can do with it.

00:00 - intro to clock (0-coast and noodblebox)
06:14 - intermediate clock (syncing sequencers and creative gates)
23:41 - advanced clock (big rack)

Gear: 
ultrapalace midinome: http://ultrapalace.com/midinome.html
sixtyfour pixels noodlebox: https://six4pix.net/product/noodlebox/
erica synths sample drum: https://reverb.grsm.io/ericasampledrum
instruo vinca: https://reverb.grsm.io/vinca
make noise rene: https://reverb.grsm.io/rene1
tinrs tuesday: https://reverb.grsm.io/tinrstuesday
make noise mimeophon: https://reverb.grsm.io/mimeophon
make noise tempi: https://reverb.grsm.io/tempi
intellijel quad vca: https://reverb.grsm.io/intquadvca
intellijel quadrax: https://reverb.grsm.io/quadrax
intellijel steppy: https://reverb.grsm.io/steppy3u
pamelas new workout: https://reverb.grsm.io/pams
Squarp Hermod: https://reverb.grsm.io/hermod
Make Noise 0-Coast: https://reverb.grsm.io/0coast
Arturia Rackbrute: https://reverb.grsm.io/rackbrute
Arturia Keystep Pro: https://reverb.grsm.io/keysteppro
IME Piston Honda MKIII: https://reverb.grsm.io/pistonhonda
QD Quad Drum Module: https://reverb.grsm.io/vpmeqd
------------------------------------
Thank you for watching. My name is Jeremy, and this is Red Means Recording. I've been making music for a few decades now, and this channel is a place to make music and to talk about the tools and techniques to make music with. We'll use synths, drum machines, modular gear, and software. 

If you'd like to support the channel, I have a Patreon:  http://bit.ly/rmrpatreon

I have music as "Jeremy Blake" on all the major services: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

I have some merch here: http://bit.ly/rmrshirts

And you can connect with me here: 
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

## Seattle Modular Nights - Full Performance (November 2020)
 - [https://www.youtube.com/watch?v=ZcTJ5ISWNCM](https://www.youtube.com/watch?v=ZcTJ5ISWNCM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2020-11-08 00:00:00+00:00

This is my full set (pre-recorded) for the Seattle Modular Nights streaming event. It aired November 7th over here: https://www.twitch.tv/modularseattle

I wanted to get back to the Big Rack and give it some attention, so all three tracks are written and performed with that in mind. All three tracks started with 3 different custom sample sets on the Squarp Rample. The first used marimbas and handclaps in round-robin cycling, the second used bass samples from Massive X and vocal chops from BT's "Surrounded". The third used chord and vocal samples from this video of Oscar Peterson talking about synthesizers: https://www.youtube.com/watch?v=FI-4HNQg1JI&ab_channel=RudyCortes

The Tetrapad is being used as the main manual performance tool. In the first, it's hooked up to the Qu-Bit Prism to wonk out the timing of the delay and the wavetable modulation inputs of the Piston Honda, as well as the wet-dry mix of the reverb on Rings. On the second it's processing the wet-dry of Monsoon and the filter/decay of the Rample samples. Its gates are also set to glitch things out. In the 3rd it's going to Timbre and Morph of Plaits (doing chords) to brighten the sound, as well as the Harvestman filter cutoff to give expression to the solo line from the Erica Synths Pico Voice.

I made multiple sequences in the Hermod for each track and use track mutes and sequence changes to shape the track progression. In some cases, I also had blank patterns with quantization set up to switch to and record a whole new sequence on the fly. 

Main sounds are: 

Piston Honda through the SSF Stereo Dipole
Plaits through the Tip Top z5000
Rings through the Erica Synth DSP
Generate 3 through the Happy Nerding VCF into Qu-Bit Prism
Pico Voice through the Harvestman R-1982

Drums are: 
Squarp Rample
VPME Quad Drum

Sequencing:
Hermod
Varigate 8+

Modulation and Stuff:
Tetrapad
Quart
Quad VCA
Pam's
RND Step
OCHD
Lifeforms Mico Sequencer
Abstract Data ADE-32
------------------------------------
Thank you for watching. My name is Jeremy, and this is Red Means Recording. I've been making music for a few decades now, and this channel is a place to make music and to talk about the tools and techniques to make music with. We'll use synths, drum machines, modular gear, and software. 

If you'd like to support the channel, I have a Patreon:  http://bit.ly/rmrpatreon

I have music as "Jeremy Blake" on all the major services: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

I have some merch here: http://bit.ly/rmrshirts

And you can connect with me here: 
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

