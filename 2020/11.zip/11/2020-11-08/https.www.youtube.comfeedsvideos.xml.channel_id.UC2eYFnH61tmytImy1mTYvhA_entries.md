# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## Intellectual "Property" is a Spook (GNU Boomer Rants)
 - [https://www.youtube.com/watch?v=hrE4Xc63uNQ](https://www.youtube.com/watch?v=hrE4Xc63uNQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-11-09 00:00:00+00:00

"Property" doesn't mean anything if you consider intellectual property property. If you want to exploit American law to get free money, be my guest, but don't LARP as if you have some universal moral right to extract money from everyone that thinks an idea you first thought, or hums a tune you wrote or makes software based off of yours.

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE: https://lukesmith.xyz/donate 💰😎👌💯
OR affiliate links to things l use:
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://brave.com/luk005 Get the Brave browser.
https://lbry.tv/$/invite/@Luke View my videos on LBRY. Get a bonus for joining.
https://www.coinbase.com/join/smith_5to1 Get crypto-rich on Coinbase. We both get $10 in Bitcoin when you buy or sell $100 in cryptocurrencies.

