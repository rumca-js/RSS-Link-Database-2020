# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Songhoy Blues - Interview & Performance (Live on KEXP at Home)
 - [https://www.youtube.com/watch?v=RQJN65PokyE](https://www.youtube.com/watch?v=RQJN65PokyE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-11-09 00:00:00+00:00

http://KEXP.ORG presents Songhoy Blues sharing special live set performed on the riverside in Bamako, Mali, recorded exclusively for KEXP and lead singer Aliou Touré talking live with Kevin Cole. Recorded November 3, 2020. 

Songs:
Badala
Dournia
Worry
Barre
Ai Tchere Bele

https://songhoyblues.com
http://kexp.org

