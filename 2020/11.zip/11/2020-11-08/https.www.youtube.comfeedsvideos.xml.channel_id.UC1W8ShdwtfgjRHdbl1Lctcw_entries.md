# Source:NASS, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw, language:en-US

## Portland, 1917 in Color! [60fps,Remastered]
 - [https://www.youtube.com/watch?v=pB6p-7ZErak](https://www.youtube.com/watch?v=pB6p-7ZErak)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw
 - date published: 2020-11-09 00:00:00+00:00

I colorized, restored and created a sound design for this video of Portland, 1917, footage apparently were shot at the end of spring in 1917: the marquee at the long-gone Majestic Theatre, at Washington and Park, is seen heralding “A Small Town Girl,” a silent movie starring “winsome June Caprice.” Ads in The Oregonian and the Oregon Journal at the time state that the picture would play only from May 31 through June 2 of that year. (Over at the Lyric, at Fourth and Stark, you could put down 15 cents to check out a chorus-girls contest.)

Video Restoration Process:
✔ FPS boosted to 60 frames per second 
✔ Image resolution boosted up to HD 
✔ Improved video sharpness and brightness
✔ Colorized only for the ambiance
✔added sound only for the ambiance
✔restoration:(stabilisation,denoise,deblur) 

Please, be aware that colorization colors are not real and fake, colorization was made only for the ambiance and do not represent real historical data.

For any Copyright issues, please reach out to us first before filing a claim with YouTube. Send us a message or email detailing your concerns and we'll make sure the matter is resolved immediately. All contact details in our channel's "About" page!  Thank You!

#1917 #Upscale #old #Portland

