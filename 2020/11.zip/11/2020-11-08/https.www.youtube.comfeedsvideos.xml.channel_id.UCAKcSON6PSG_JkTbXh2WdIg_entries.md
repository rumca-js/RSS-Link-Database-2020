# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Deep Sea Diver: Virtual Session
 - [https://www.youtube.com/watch?v=iFzz4rw8L48](https://www.youtube.com/watch?v=iFzz4rw8L48)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-11-09 00:00:00+00:00

Seattle's Deep Sea Diver join us to catch up with Jade and play a few songs from their latest record, 'Impossible Weight'.

Songs Performed: 
06:43 Impossible Weight
17:35 Shattering The Hourglass
22:49 Switchblade

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

