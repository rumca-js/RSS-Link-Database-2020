# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## 'Jeopardy’ host Alex Trebek dead at 80 after cancer battle
 - [https://www.nydailynews.com/snyde/ny-jeopardy-host-alex-trebek-dead-20201108-yxqn7dgnv5dsjj4e6uqte3twee-story.html](https://www.nydailynews.com/snyde/ny-jeopardy-host-alex-trebek-dead-20201108-yxqn7dgnv5dsjj4e6uqte3twee-story.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2020-11-08 17:34:39+00:00

<p>Article URL: <a href="https://www.nydailynews.com/snyde/ny-jeopardy-host-alex-trebek-dead-20201108-yxqn7dgnv5dsjj4e6uqte3twee-story.html">https://www.nydailynews.com/snyde/ny-jeopardy-host-alex-trebek-dead-20201108-yxqn7dgnv5dsjj4e6uqte3twee-story.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=25027279">https://news.ycombinator.com/item?id=25027279</a></p>
<p>Points: 23</p>
<p># Comments: 3</p>

