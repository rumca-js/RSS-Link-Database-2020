# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Leaving New York? AVOID NEW JERSEY! IT'S A TRAP!
 - [https://www.youtube.com/watch?v=TxFhMVIPodk](https://www.youtube.com/watch?v=TxFhMVIPodk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-11-08 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
🔵 https://www.truthinaccounting.org/library/doclib/NJ-2018-2pager.pdf
🔵 https://www.njpp.org/wp-content/uploads/2016/09/NJPPNotorious9Sept2016.pdf
🔵 https://ballotpedia.org/New_Jersey_state_budget_and_finances
🔵 http://www.shorenewsnetwork.com/2020/06/19/new-jersey-leads-country-in-people-leaving-the-state-but-its-been-that-way-since-before-murphy/
👉 This video was recorded with the following:
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://amzn.to/2GoiSb0
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://amzn.to/2SiCG1W

## NYC reacts to election results
 - [https://www.youtube.com/watch?v=a5qY30sHIuI](https://www.youtube.com/watch?v=a5qY30sHIuI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-11-08 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545

