# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## Are Electric Airplanes Doomed? | Answers With Joe
 - [https://www.youtube.com/watch?v=FzvrNhsR-4c](https://www.youtube.com/watch?v=FzvrNhsR-4c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2020-11-09 00:00:00+00:00

Get a full year of CuriosityStream and Nebula for only $14.75 when you sign up at http://www.curiositystream.com/joescott
We've heard a lot about electric cars lately, but what about electric airplanes? The air transportation industry is a huge contributor to greenhouse gasses. Could we electrify our air fleet as well?
Turns out... it might be next to impossible.

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

https://interestingengineering.com/a-brief-history-of-drones-the-remote-controlled-unmanned-aerial-vehicles-uavs

https://www.cbsnews.com/news/amazon-unveils-futuristic-plan-delivery-by-drone/

https://evtol.news/aircraft

https://www.aviationtoday.com/2020/05/11/heres-uber-designing-skyports-future-air-taxis/

https://www.smartcitiesdive.com/news/inclusive-urban-air-mobility-LA-world-economic-forum/585440/

https://www.forbes.com/sites/erictegler/2020/09/23/as-boeing-and-airbus-pull-back-from-urban-air-mobility-volocopters-advance-sale-of-air-taxi-rides-sends-a-mixed-message/#220537832e86

https://greentransportation.info/energy-transportation/energy-density.html

https://insideevs.com/news/446842/rolls-royce-fastest-electric-plane-testing/, https://www.flightdeckfriend.com/how-fast-do-commercial-aeroplanes-fly

ttps://electrek.co/2019/03/26/harbour-seaplanes-electric-airline/

