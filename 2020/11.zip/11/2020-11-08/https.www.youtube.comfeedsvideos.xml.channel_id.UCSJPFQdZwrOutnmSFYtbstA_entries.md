# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Annihilation - It's Dumber Than You Think
 - [https://www.youtube.com/watch?v=7SIhMGrhNcY](https://www.youtube.com/watch?v=7SIhMGrhNcY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-11-09 00:00:00+00:00

Annihilation was one of those movies that conned people into thinking it was smart. Join me as I explain why it isn't.

