# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Happy Easter! We Can Be ReBorn! | Russell Brand
 - [https://www.youtube.com/watch?v=MgYS5SxJ7Wg](https://www.youtube.com/watch?v=MgYS5SxJ7Wg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-04-12 00:00:00+00:00

Happy Easter! We Can Be ReBorn! Or watch HOP!

Check out my wife's new book The Joy Journal: https://www.amazon.co.uk/Joy-Journal-Magical-Everyday-Play/dp/1529025591/ref=sr_1_2?dchild=1&keywords=the+joy+journal&qid=1586860365&sr=8-2

Here instagram is @thejoyjournal 

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

