# Source:Glink, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNTqu16j3F6RbtHZI-3untg, language:en-US

## The Lonely Fans of OnlyFans
 - [https://www.youtube.com/watch?v=djMojvschs0](https://www.youtube.com/watch?v=djMojvschs0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNTqu16j3F6RbtHZI-3untg
 - date published: 2020-04-12 00:00:00+00:00

Disrupting the dating market and alluring both men and women, OnlyFans and services like it have changed the internet forever. Each day more people decide they are ready to become a model, showcasing their bodies for the chance at a lucrative source of income, the men follow suit. I interviewed models and fans alike only to discover a dark thread tying them together.

SPECIAL THANKS TO THE MODELS:

Skynyx - https://twitter.com/Skynyx

Emiok -  https://twitch.tv/Emiok

Cellutron -  https://twitter.com//Cellutron_

Nickey Huntsman -  https://twitter.com//NickeyHuntsman

BuckleysPants -  https://twitter.com//BuckleysPants

Mia Rose -  https://twitter.com//MiaRosexxx

MUSIC CREDITS: 

Wake Me Up Before You Go Go - 8 Bit Universe
https://www.youtube.com/watch?v=TAVBgNqlu2Y

Lofi hip hop radio - beats to relax/study to type beat by Oppsato

High Stakes by Oppsato
https://soundcloud.com/oppsato/high-stakes-2 

https://www.youtube.com/watch?v=XCr0bsng60Y

https://www.youtube.com/watch?v=9EApn11lFfE&list=PLi-jQY80rpqBq18-xSnglvyRXcfk-paDq&index=16

Elysium in Dreams
https://www.youtube.com/watch?v=TV0uYFPEkks&feature=youtu.be

Holland 1945 by Neutral Milk Hotel 8 Bit Remix 

https://youtu.be/uUXBwOsaYMA

Aviscerall - Lullabyes
https://youtu.be/RXcv5W1Da3M

Love Lockdown by Kanye West 8 Bit Remix
https://youtu.be/1AtrhHoqlRM

The World Has Turned And Left Me Here cover by Slush

ANIME SHOWN:
Neon Genesis Evangelion
Welcome To The N.H.K.
Recovery of an MMO Junkie
Sword Art Online
FLCL
and 2 other romantic ones that I honestly forgot the name of, just ask in a comment, someone will probably tell you idk

Special Thanks:
Slush for helping with the intro and ending song
Lindie for making an egirl account
Krissy for helping with the thumbnail
Danipls for filming herself play league
TOBYMANNANA 

My stuff:
Patreon - Patreon.com/Glink
Twitter - https://twitter.com/GlinkLive
Reddit - https://www.reddit.com/r/glink/
Instagram - https://www.instagram.com/glink_between_worlds/
Discord server - https://discord.gg/xtwYypf

