# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## SID music: It's Jeff again - some old, some new (U64E real 6581 dual mono bx_🎧)
 - [https://www.youtube.com/watch?v=ktDa9Fsj4Ds](https://www.youtube.com/watch?v=ktDa9Fsj4Ds)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-04-12 00:00:00+00:00

A compilation of 10 tracks from Jeff (Søren Lund). 5 not previously featured in my channel, the rest are familiar (but worth reuploading in bx_). These are all fresh recordings from my most Jeff-like chips (based on some recordings from his own chip). However, i don't know if all these were composed using that same chip. Whatever the case is, i like these. The darker filter curve gives these some nice character (i think at least). For the pixel art i used Christopherjam palette this time (more saturated colors). Headphones recommended as always.

Jumplist
00:00 Evolver 6581 (2nd at X'2010), art "Synastry" (2020) by Rail Slave
03:41 Commodore 64 (2004), art "Exodus" (2020) by Arcane
06:14 X-Large 5 (2004), art "Ernie" by redcrab (1st at X'2018)
07:36 6581 Doped Cows (1st at X'2006), art "Eye of the Storm" by Malmix (1st at Datastorm 2019)
10:21 Reflex Tune (1996), art "Cyberwolf" by Mythus (1st at Flashback 2019)
12:23 X-Large 4 (2002), art "It's So Weird" (2020) by Creep      
14:00 Ode to C64 (2003), art "Resting Ronin" by MisBug (9th at Zoo 2019)
16:51 Tanzen Jahh (1993), art "Seeing is Believing" by Facet (1st at Xenium 2019)
19:06 X-Large 6 (2006), art "4n____ki" by Deev (1st at Syntax 2019)
20:43 System F - Cry (2005), art "October" by Joe (1st at Syntax 2015)

Some of these tracks were featured in my stereo Dolbyfied compilation ages ago (lighter filter curve):
https://www.youtube.com/watch?v=MiSlPuCqEoM

Ultimate64 Elite real 6581 dual mono setup (identical audio data output for both chips, full channel separation):

Left channel: MOS 6581R4AR 0187 14/Hong Kong HH512134 HC-30
Right channel: MOS 6581 3584/Korea AH325137

Ultimate64 Elite:
https://ultimate64.com/Ultimate-64-Elite

