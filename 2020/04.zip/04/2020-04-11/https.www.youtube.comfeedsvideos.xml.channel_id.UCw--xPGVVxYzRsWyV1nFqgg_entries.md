# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## My Thoughts on Sanderson's Wheel Of Time Show Comments
 - [https://www.youtube.com/watch?v=HURiYXm4LVw](https://www.youtube.com/watch?v=HURiYXm4LVw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-04-12 00:00:00+00:00

Just my two cents on some comments that sparked some convo around the show coming down the road from Amazon about The Wheel Of Time! 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

#TheWheelOfTime #WheelOfTime

## NEW STORMLIGHT ARCHIVE SYMBOL, WoT Director Rundown, Free D&D Content - FANTASY NEWS
 - [https://www.youtube.com/watch?v=DlyFY7LprWM](https://www.youtube.com/watch?v=DlyFY7LprWM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-04-11 00:00:00+00:00

Idk you think of a fantasy news description. I am tired. Fantasy things. Stormlight Archive stuff. Wheel of Time thingys. News news news. Fantasy, Daniel Greene. 

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

NEWS: 

Beetlejuice Documentary: https://www.slashfilm.com/making-of-beetlejuice-documentary-trailer/

Batman Director Comments: https://screenrant.com/batman-movie-director-dceu-creative-freedom/

Batman not an origin story: https://screenrant.com/batman-movie-no-origin-story-matt-reeves/

Stormlight Symbol: https://www.brandonsanderson.com/alternate-stormlight-symbol-reveal/

New World Release: https://www.newworld.com/en-us/news/articles/release-date-update

Free D&D Content: https://www.polygon.com/2020/4/7/21212094/dungeons-dragons-free-content-release-schedule

Black Sun: https://twitter.com/sagasff/status/1247917121981612032?s=12

Purge Siren: https://www.indiewire.com/2020/04/louisiana-police-purge-siren-coronavirus-curfew-1202223466/

No Jar Jar In Obi-wan show: https://screenrant.com/star-wars-obi-wan-show-jar-jar-rumor-debunked/

Hugo Awards Finalists: http://www.thehugoawards.org/hugo-history/2020-hugo-awards/

Wheel Of Time Directors: https://dragonmount.com/news/tv-show/adams-wheel-of-television-meet-the-wot-directors-r1098/

