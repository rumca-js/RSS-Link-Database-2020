# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Tiger King is Absolutely Insane, And I Love It
 - [https://www.youtube.com/watch?v=konipsWUwqE](https://www.youtube.com/watch?v=konipsWUwqE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-04-11 00:00:00+00:00

Grab a cold one as I venture into the world of madness, mayhem and murder that is... Tiger King.

