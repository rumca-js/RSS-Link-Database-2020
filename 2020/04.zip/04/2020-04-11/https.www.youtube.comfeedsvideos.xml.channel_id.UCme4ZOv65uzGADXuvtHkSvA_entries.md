# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Jonasz z 2B [#09] Niezwykłe Triduum
 - [https://www.youtube.com/watch?v=tqwDur4WI1E](https://www.youtube.com/watch?v=tqwDur4WI1E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-12 00:00:00+00:00

#triduum #spowiedź #rezurekcja @Dominikanieplportal @Langustanapalmie 

To już ostatni odcinek naszego serialu, ale mamy nadzieję, że tak naprawdę to dopiero początek kolejnych serii… Tymczasem dojdźmy razem z Jonaszem od grobu do zmartwychwstania i zobaczmy, kto pojawi się na porannej rezurekcji…

Scenariusz: Angelika Olszewska
Reżyseria: Mateusz Olszewski
Zdjęcia: Marcin Lesisz
Montaż i czołówka: Agata Przygodzka
Mistrz Oświetlenia: Ireneusz Chojnacki
Kierownik produkcji: Angelika Olszewska
Kierownik planu: Magdalena Gonera
Korekta barwna: Przemysław Jurkiewicz
Fotosy: Halina Irena Jasińska
Grafiki: Jakub Dudek
Reżyseria dźwięku: Iga Kałduńska
Scenografia: Michał Pańczyk
Kostiumy: Justyna Jabłońska
Charakteryzacja: Beata Czerniszewska
Jonasz: Piotr Bondyra
Ksiądz: Ksawery Szlenkier
Ewka: Angelika Olszewska
Ojciec: Piotr Cyrwus
Matka: Natasza Sierocka
Magda: Julia Biesiada
Piotrek: Krzysztof Godlewski
I inni.



Serial jest wyprodukowany przez Stowarzyszenie Działań Twórczych Republika Warszawa dla Langusta na Palmie.

Śledź JONASZA na FB 
→ https://www.facebook.com/Jonasz-z-2b-101044304824327/ 
oraz na Instagramie: 
→ https://www.instagram.com/jonasz_z_2b/

Dziękujemy braciom Dominikanom z klasztoru na Warszawskim Służewie za udostępnienie miejsca do nagrania II http://www.sluzew.dominikanie.pl
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

## Wielkanocne Błogosławieństwo Pokarmów
 - [https://www.youtube.com/watch?v=f2nqnVrOOJY](https://www.youtube.com/watch?v=f2nqnVrOOJY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-12 00:00:00+00:00

@langustanapalmie @dominikanie.pl #wielkanoc #zostanwdomu ________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Świąteczny LIVE z o. Adamem
 - [https://www.youtube.com/watch?v=j3PGu74aLgg](https://www.youtube.com/watch?v=j3PGu74aLgg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-12 00:00:00+00:00

@langustanapalmie @dominikanie.pl #wielkanoc #zostanwdomu ________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#176] Pościel łóżko!
 - [https://www.youtube.com/watch?v=lXWW3vnVSVU](https://www.youtube.com/watch?v=lXWW3vnVSVU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-11 00:00:00+00:00

#cnn #slowonaniedziele #kazankodookienka

Kazanie Niedziela Zmartwychwstania Pańskiego, ROK A

1. czytanie (Dz 10, 34a. 37-43)

Gdy Piotr przybył do domu setnika Korneliusza w Cezarei, przemówił w dłuższym wywodzie: «Wiecie, co się działo w całej Judei, począwszy od Galilei, po chrzcie, który głosił Jan. Znacie sprawę Jezusa z Nazaretu, którego Bóg namaścił Duchem Świętym i mocą. Dlatego że Bóg był z Nim, przeszedł On, dobrze czyniąc i uzdrawiając wszystkich, którzy byli pod władzą diabła.

A my jesteśmy świadkami wszystkiego, co zdziałał w ziemi żydowskiej i w Jeruzalem. Jego to zabili, zawiesiwszy na drzewie. Bóg wskrzesił Go trzeciego dnia i pozwolił Mu ukazać się nie całemu ludowi, ale nam, wybranym uprzednio przez Boga na świadków, którzy z Nim jedliśmy i piliśmy po Jego zmartwychwstaniu.

On nam rozkazał ogłosić ludowi i dać świadectwo, że Bóg ustanowił Go sędzią żywych i umarłych. Wszyscy prorocy świadczą o tym, że każdy, kto w Niego wierzy, przez Jego imię otrzymuje odpuszczenie grzechów».

2. czytanie (Kol 3, 1-4)

Bracia: Jeśli razem z Chrystusem powstaliście z martwych, szukajcie tego, co w górze, gdzie przebywa Chrystus, zasiadający po prawicy Boga. Dążcie do tego, co w górze, nie do tego, co na ziemi.

Umarliście bowiem i wasze życie jest ukryte z Chrystusem w Bogu. Gdy się ukaże Chrystus, nasze Życie, wtedy i wy razem z Nim ukażecie się w chwale.

Albo do wyboru:

2. czytanie (1 Kor 5, 6b-8)

Czyż nie wiecie, że odrobina kwasu całe ciasto zakwasza? Wyrzućcie więc stary kwas, abyście się stali nowym ciastem, bo przecież przaśni jesteście. Chrystus bowiem został złożony w ofierze jako nasza Pascha. Tak przeto odprawiajmy święto nasze, nie przy użyciu starego kwasu złości i przewrotności, lecz na przaśnym chlebie czystości i prawdy.

Ewangelia (J 20, 1-9)

Pierwszego dnia po szabacie, wczesnym rankiem, gdy jeszcze było ciemno, Maria Magdalena udała się do grobu i zobaczyła kamień odsunięty od grobu. Pobiegła więc i przybyła do Szymona Piotra oraz do drugiego ucznia, którego Jezus kochał, i rzekła do nich: «Zabrano Pana z grobu i nie wiemy, gdzie Go położono».

Wyszedł więc Piotr i ów drugi uczeń i szli do grobu. Biegli obydwaj razem, lecz ów drugi uczeń wyprzedził Piotra i przybył pierwszy do grobu. A kiedy się nachylił, zobaczył leżące płótna, jednakże nie wszedł do środka.

Nadszedł potem także Szymon Piotr, idący za nim. Wszedł on do wnętrza grobu i ujrzał leżące płótna oraz chustę, która była na Jego głowie, leżącą nie razem z płótnami, ale oddzielnie zwiniętą w jednym miejscu. Wtedy wszedł do wnętrza także i ów drugi uczeń, który przybył pierwszy do grobu. Ujrzał i uwierzył. Dotąd bowiem nie rozumieli jeszcze Pisma, które mówi, że On ma powstać z martwych.
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Targ intencji || kwiecień 2020
 - [https://www.youtube.com/watch?v=Tcx_ofb8Q5U](https://www.youtube.com/watch?v=Tcx_ofb8Q5U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-11 00:00:00+00:00

Targ intencji na kwiecień 2020.

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wprowadzenie do Liturgii Wigilii Paschalnej
 - [https://www.youtube.com/watch?v=-T4uXFLCm_k](https://www.youtube.com/watch?v=-T4uXFLCm_k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-11 00:00:00+00:00

@langustanapalmie @dominikanie.pl #zmartwychwstanie #zostanwdomu ________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

