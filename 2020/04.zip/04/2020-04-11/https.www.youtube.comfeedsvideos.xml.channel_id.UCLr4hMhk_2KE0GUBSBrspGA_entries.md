# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week #11: Szkoła życia. Precision Health Toilet, nowy pad do PS5, autonomiczne auta i drony
 - [https://www.youtube.com/watch?v=n9KR-EbKsEY](https://www.youtube.com/watch?v=n9KR-EbKsEY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-04-12 00:00:00+00:00

Dzisiaj o tęsknocie za prawdziwym biurem, robotach, które zastąpiły studentów i słońcu które wychodzi po burzy. 

Moje sociale: insta: http://bit.ly/InstaKlawiatur twitter: http://bit.ly/TTKlawitera i FB: http://bit.ly/FBKlawiatur.

Źródła:
Tęsknota za biurem: https://bit.ly/2yaroGa
Roboty zamiast studentów: https://cnet.co/2VkDMvu
Samsung zarabia lepiej niż w zeszłym roku: https://bit.ly/3a3xW6W
Salvador Dali o odcisku: https://bit.ly/2XschT8
Smart toaleta z kamerami: https://bit.ly/3cdcduC
Nowy pad do PS5: https://bit.ly/2XwfwJo
Samsungowe średniaki z obsługą 5G: https://bit.ly/2ybXD8g
Zrzutka na drona, żeby walczyć z 5G: https://bit.ly/2wypb7f
Wspólny projekt Google i Apple: https://bit.ly/2RwDEIe
Autonomiczne auta dostarczające żarcie: https://engt.co/2XuLN3m
Autonomiczne auta przewożące testy: https://bit.ly/3cbCsl9
Autonomiczne drony: https://bit.ly/2Xvq4bC

