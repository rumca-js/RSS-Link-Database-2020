# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Best Coast - Different Light (Live at The Current)
 - [https://www.youtube.com/watch?v=6XP13wgz0Zs](https://www.youtube.com/watch?v=6XP13wgz0Zs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-11 00:00:00+00:00

Best Cost perform "Different Light" at The Current.

Bethany Consentino says, "I think part of what I've learned through my music and my lyrics is that, yeah, I've struggled with a lot of things, but I needed to go through all that stuff to come out on the other side."

From Best Coast's 2020 album, Always Tomorrow, available on Concord Records.


PERSONNEL
Bethany Consentino, Vocals, keyboards
Bobb Bruno, Guitar
Joseph Bautista, Guitar
Brett Mielke, Bass
Dylan Fujioka, Drums

CREDITS
Audio: Michael DeMark
Video: Peter Ecklund
Production: Jesse Wiza

MORE FROM THIS SESSION
Everything Has Changed https://youtu.be/WHaKcIEN6vc
For the First Time https://youtu.be/1keNgAUJKCg

## Best Coast - Everything Has Changed (Live at The Current)
 - [https://www.youtube.com/watch?v=WHaKcIEN6vc](https://www.youtube.com/watch?v=WHaKcIEN6vc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-11 00:00:00+00:00

Best Coast perform "Everything Has Changed" at The Current.

"I think a lot of prior songs were a lot of me grappling with codependent relationships and toxic things in my life — not even necessarily romantic, but people, places, things in my life that were not good for me," Cosentino says. "And I feel like I was constantly going to battle for things that I should have learned years ago weren't worth going to battle for because they were just kind of keeping me in my sort of 'pool of darkness,' I suppose, if you want to call it that."

From Best Coast's 2020 album, Always Tomorrow, available on Concord Records.

PERSONNEL
Bethany Consentino, Vocals, keyboards
Bobb Bruno, Guitar
Joseph Bautista, Guitar
Brett Mielke, Bass
Dylan Fujioka, Drums

CREDITS
Audio: Michael DeMark
Video: Peter Ecklund
Production: Jesse Wiza

MORE FROM THIS SESSION
Different Light https://youtu.be/6XP13wgz0Zs
For the First Time https://youtu.be/1keNgAUJKC

## Best Coast - For The First Time (Live at The Current)
 - [https://www.youtube.com/watch?v=1keNgAUJKCg](https://www.youtube.com/watch?v=1keNgAUJKCg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-11 00:00:00+00:00

Best Coast perform "For The First Time" at The Current. 

Bethany Cosentino expounds on the album title 'Always Tomorrow.' "I think the overall theme of the album is very much the idea that at times we can be our own worst enemies, and learning to get out of our way and let life happen," she says.

From Best Coast's 2020 album, Always Tomorrow, available on Concord Records.

PERSONNEL
Bethany Consentino, Vocals, keyboards
Bobb Bruno, Guitar
Joseph Bautista, Guitar
Brett Mielke, Bass
Dylan Fujioka, Drums

CREDITS
Audio: Michael DeMark
Video: Peter Ecklund
Production: Jesse Wiza

MORE FROM THIS SESSION
Different Light https://youtu.be/6XP13wgz0Zs
Everything Has Changed https://youtu.be/WHaKcIEN6vc

## Salute to John Prine (United States of Americana)
 - [https://www.youtube.com/watch?v=aN-9yX2tpnI](https://www.youtube.com/watch?v=aN-9yX2tpnI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-11 00:00:00+00:00

Host Bill DeVille features two hours of music by John Prine this week on United States of Americana.
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/
https://www.facebook.com/RadioHeartlandMPR/
https://twitter.com/RadioHeartland

