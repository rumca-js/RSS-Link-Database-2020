# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Settlers of Middle-earth - My Custom Lord of the Rings Catan Game
 - [https://www.youtube.com/watch?v=QBDVv-IELHA](https://www.youtube.com/watch?v=QBDVv-IELHA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2020-04-12 00:00:00+00:00

Combining my love for Settlers of Catan with my love of all things Tolkien, I creating my own variation - Settlers of Middle-earth. This was a labor of love as I sought to make every element say “Middle-earth”. Since then, it’s become a hit with friends who also enjoy Catan, even if they aren’t into Lord of the Rings or The Hobbit. All materials were acquired from a local craft store. I designed all the cards myself in Photoshop and had them printed online. 


If this is your first time checking out the channel and you enjoy The Lord of the Rings and the world of Middle-earth, please subscribe (and click the bell) and check out my other videos!


Game Pieces (including expansion):
Mithril Hexes - Erebor, Moria, Ered Luin, Helm's Deep, Iron Hills
Lembas Hexes - Grey Havens, Lorien, Halls of Thranduil, Rivendell, Lindon (2)
Pipeweed Hexes - The Shire (various)
Wood Hexes - Fangorn, Mirkwood (4), Trollshaws
Horse Hexes - Minas Tirith, Dale, Gap of Rohan, Bree, Beorn's House, Edoras
Desert Hexes - Mordor, Angmar

Warrior Cards:
Gimli, Beorn, Radagast, Dwalin, King of the Dead, Thranduil, Faramir, Arwen, Gandalf the Grey, Gandalf the White, Bilbo, Sauron, Balin, The Hobbits, Smaug, Tauriel, Azog, Durin's Bane, Galadriel, Thorin, Treebeard, Boromir, Legolas, Bard, Saruman, Aragorn, Eowyn, Elrond, The Witch King, Eomer, Theoden, 

Victory Point Cards: 
The Green Dragon, Sting, The Arkenstone, The Silmarils, Phial of Galadriel, Shards of Narsil, The Argonath


-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner. 


#lordoftherings #catan #boardgame

