# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Amoeba Music says 'we don't know that we can get through COVID-19' (The Current Music News)
 - [https://www.youtube.com/watch?v=tM4EAeCGJ0M](https://www.youtube.com/watch?v=tM4EAeCGJ0M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-21 00:00:00+00:00

April 21, 2020: Amoeba Music is asking supporters for direct donations, the chain fearing it may not survive the pandemic. Meanwhile, independent concert venues are banding together to fight for their own survival. A new virtual festival has been announced to support musicians reeling from economic and health shocks, while Sharon Van Etten will join Fountains of Wayne to pay tribute to Adam Schlesinger. Also, what musician should compose the sound of your electric car?
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Hamilton Leithauser - Full performance (Live Virtual Session)
 - [https://www.youtube.com/watch?v=qSkqGqsmPsM](https://www.youtube.com/watch?v=qSkqGqsmPsM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-21 00:00:00+00:00

Hamilton Leithauser (and his Family Quarantine Band) shares a few songs and talks with Mark Wheat from The Current.

00:47 Isabella
06:36 Here They Come
12:50 1000 Times

## Joey Burns (Calexico) - Full performance (Live Virtual Session with The Current)
 - [https://www.youtube.com/watch?v=tMbJ2fMYBsQ](https://www.youtube.com/watch?v=tMbJ2fMYBsQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-21 00:00:00+00:00

#Calexico's Joey Burns in Tucson, Arizona joined The Current's Mark Wheat in St. Paul for a live virtual session. The recording/video quality is slightly subpar, but the connection and conversation is genuine.

Songs played:
02:23 Sunken Waltz
05:25 Flatten the Curve
15:57 Fortune Teller

## Laura Marling - Live Virtual Session
 - [https://www.youtube.com/watch?v=YbAW75EHYCI](https://www.youtube.com/watch?v=YbAW75EHYCI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-21 00:00:00+00:00

Laura Marling joins The Current from her home in London to play three songs from her 2020 album, 'Song for our Daughter.' 
Songs Played:
00:00 "Only The Strong Survive"
02:46 "The End of the Affair"
05:49 "Held Down"

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Margaret Glaspy - Full performance (Live Virtual Session)
 - [https://www.youtube.com/watch?v=v-CV6yOdFog](https://www.youtube.com/watch?v=v-CV6yOdFog)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-21 00:00:00+00:00

#MargaretGlaspy connects with Jade to play music from her new album 'Devotion,' and to discuss what she's up to while sheltering in place, (hint: there's quite a bit of baking going on).

Songs performed:
00:21 Devotion
04:58 Stay With Me

Both songs are from Glaspy's new album 'Devotion,' out now on ATO Records.

## Michael Kiwanuka - Final Frame (Acoustic, Live at The Current, 2017)
 - [https://www.youtube.com/watch?v=Kkso8s_Gl3c](https://www.youtube.com/watch?v=Kkso8s_Gl3c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-21 00:00:00+00:00

Michael Kiwanuka normally uses electric guitar in "The Final Frame," but as he sways through it at The Current, it's all #acoustic. 

MORE FROM THIS SESSION
Cold Little Heart https://www.youtube.com/watch?v=kIBtqXj3Ftk
Love & Hate https://www.youtube.com/watch?v=Wfotg_q5Bkc
Full session https://youtu.be/TRh_-tKHe3o

From Michael Kiwanuka's 2016 release, Love & Hate, available via Interscope Records.

CREDITS
Production: Derrick Stevens
Audio: Michael DeMark and Matt Lentz
Video: by Nate Ryan

SUPPORT THE CURRENT
https://support.mpr.org/current-web?var=youtube-description

## Michael Kiwanuka - Full solo acoustic session (Live at The Current, 2017)
 - [https://www.youtube.com/watch?v=TRh_-tKHe3o](https://www.youtube.com/watch?v=TRh_-tKHe3o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-20 00:00:00+00:00

In these performances, recorded in 2017, #MichaelKiwanuka sounds lonely, a quiet #singersongwriter who might just be playing in his bedroom for himself. Back-up vocalists join him during the studio version of "Cold Little Heart," but here, he's on his own. He normally uses electric guitar in "The Final Frame," but as he sways through it at The Current, it's all #acoustic. His album is "dense and full," he says, and he's right -- but these recordings strip the songs down to their bones.

SONGS
00:00 Love & Hate
04:41 The Final Frame
08:45 Cold Little Heart

MORE FROM THIS SESSION
Cold Little Heart https://www.youtube.com/watch?v=kIBtqXj3Ftk
Love & Hate https://www.youtube.com/watch?v=Wfotg_q5Bkc

All songs from Michael Kiwanuka's 2016 release, Love & Hate, available via Interscope Records.

CREDITS
Production: Derrick Stevens
Audio: Michael DeMark and Matt Lentz
Video: by Nate Ryan

SUPPORT THE CURRENT
https://support.mpr.org/current-web?var=youtube-description

#michaelkiwanuka

## One World concert raises $128 million to fight COVID-19 (The Current Music News)
 - [https://www.youtube.com/watch?v=uvote6prxfI](https://www.youtube.com/watch?v=uvote6prxfI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-20 00:00:00+00:00

April 20, 2020: An all-star, live-streamed concert called 'One World: Together at Home' raised $128 million to fight the coronavirus. The virus continues to devastate the music world, with bassist Matthew Seligman among those lost to the pandemic. Willie Nelson is planning his own streaming event, and it is keyed to one of his favorite days, April 20. Also today: updates on Live Nation refunds and a look at Charli XCX's new crowdsourced music video.

