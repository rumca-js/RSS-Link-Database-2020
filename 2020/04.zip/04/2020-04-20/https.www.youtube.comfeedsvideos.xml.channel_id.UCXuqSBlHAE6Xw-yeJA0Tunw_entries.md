# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I spent $100 to save 20 bucks... and it was TOTALLY worth it!
 - [https://www.youtube.com/watch?v=aHNmVV7THBs](https://www.youtube.com/watch?v=aHNmVV7THBs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-04-21 00:00:00+00:00

Thanks to Anker for sponsoring this video! Grab a brand new Anker PowerBank at the links below!

PowerCore 10000
US: https://ankerfast.club/2U7d3ps
UK: https://ankerfast.club/3jI93Vk
DE: https://ankerfast.club/3CDMXvx

PowerCore+ 26800 PD 45W
US: https://ankerfast.club/2X6Hqxl
UK: https://ankerfast.club/3skkneh
DE: https://ankerfast.club/3yCjL60

PowerCore Fusion
US: https://ankerfast.club/3yFiHOv

We breathe new life into an old battery bank by building our own DIY Spot welder!

Buy Anker Portable Chargers
On Amazon (PAID LINK): https://geni.us/XHsadhE
On Newegg (PAID LINK): https://geni.us/HLBeiA
On BHPhoto (PAID LINK): https://geni.us/lqsevV

Buy 18650 cells
On Amazon (PAID LINK): https://geni.us/vw5Gi

Buy a battery spot welder 
On Amazon (PAID LINK): https://geni.us/uldj
On Newegg (PAID LINK): https://geni.us/Fk7SRD

Buy Nickel strip
On Amazon (PAID LINK): https://geni.us/gXZ31rB
On Newegg (PAID LINK): https://geni.us/hD5oa0

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1181702-i-spent-100-to-save-20-bucks-and-it-was-totally-worth-it/


GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Support a Creator code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Test Benches on Amazon: https://lmg.gg/HOx0z
Our Production Gear: https://lmg.gg/4oPzt
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

## Ultimate IKEA Gaming Desk
 - [https://www.youtube.com/watch?v=yB_NtELI3uY](https://www.youtube.com/watch?v=yB_NtELI3uY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-04-20 00:00:00+00:00

Big shoutout to MSI for sponsoring this video! 
Buy MSI MEG X570 ACE Motherboard on Amazon: https://geni.us/bNPD5iZ
Buy MSI MEG X570 ACE Motherboard on Newegg: https://geni.us/aAnWc0

Buy MSI Optix MAG272CQR on Amazon: https://geni.us/baTo
Buy MSI Optix MAG272CQR on Newegg: https://geni.us/RYw1
 
Buy MSI Radeon RX 5700 XT MECH OC on Amazon: https://geni.us/9SV0bX
Buy MSI Radeon RX 5700 XT MECH OC on Newegg: https://geni.us/ru3TbX
 
Buy MSI Vigor GK50 Low Profile Keyboard on Amazon: https://geni.us/qvJR
Buy MSI Vigor GK50 Low Profile Keyboard on Newegg: https://geni.us/dUMNj
 
Buy MSI Clutch GM50 Gaming Mouse on Amazon: https://geni.us/6EXlh
Buy MSI Clutch GM50 Gaming Mouse on Newegg: https://geni.us/y0krXg
 
Buy MSI Immerse GH50 Gaming Headset on Amazon: https://geni.us/chP9rU
Buy MSI Immerse GH50 Gaming Headset on Newegg: https://geni.us/5pDsd1

Hole Saw used: https://geni.us/aT10QSE
Cable hole cover: https://geni.us/61Yp

Purchases made through some store links may provide some compensation to Linus Media Group.

Whether its homework or Minecraft this build will have you covered. We took IKEA's Malm desk, paired it with a bunch of MSI goodies, like the Optix MAG272CQR, RX 5700 XT Mech OC, and built sweet stealth gaming desk. 

Discuss on the forum: https://lmg.gg/mhXX8
Links to plans: Coming soon

GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Support a Creator code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Test Benches on Amazon: https://lmg.gg/HOx0z
Our Production Gear: https://lmg.gg/4oPzt
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

