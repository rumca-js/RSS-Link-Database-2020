# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## New OP-Z Videopaks by Tony Grisey
 - [https://www.youtube.com/watch?v=VsmQlYPICb0](https://www.youtube.com/watch?v=VsmQlYPICb0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2020-04-20 00:00:00+00:00

Introducing 6 new cool videopaks for the OP-Z by Tony Grisey.
They hit me up on Discord and hooked me up with the packs. I really liked them so I made a video showing them off, with a musical performance for each.
Get the pack here: https://gumroad.com/l/tWunq
Use the code "crystalsun" at checkout for 30% off.
Follow (intsa): @tony_greesee
Check out the streaming festival I'll be doing a set for: http://lofi-festival.com/
My previous video on OP-Z videopaks: https://youtu.be/4bFapQt__MU
------------------------------------
Patreon: http://bit.ly/rmrpatreon
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe
T-Shirts: http://bit.ly/rmrshirts
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

