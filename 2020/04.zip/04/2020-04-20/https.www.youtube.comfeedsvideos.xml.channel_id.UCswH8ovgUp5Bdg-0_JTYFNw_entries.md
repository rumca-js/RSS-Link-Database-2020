# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Russell Brand & Neuroscientist David Eagleman | Under The Skin Podcast
 - [https://www.youtube.com/watch?v=FaqR87Sa9dg](https://www.youtube.com/watch?v=FaqR87Sa9dg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-04-21 00:00:00+00:00

A clip from today's #UnderTheSkin podcast where I ppoke to David Eagleman - the Brian Cox of Neuroscience, the Neil deGrasse Tyson of the mind, brilliant, lucid humorous, great storyteller of scientific narratives.
If you want to listen to the rest of this fascinating episode, you can on Luminary, here's a link for the app: http://luminary.link/russell

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)
#RussellBrandPodcast

## Laura & Russell Brand Make Upcycled Shadow Puppets!
 - [https://www.youtube.com/watch?v=xWp4PJDJ8lo](https://www.youtube.com/watch?v=xWp4PJDJ8lo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-04-20 00:00:00+00:00

More craft from me and the woman I’m the husband of Laura (Instagram @thejoyjournal) this time home made shadow puppets. All these crafts are in her book #TheJoyJournal for Magical Everyday Play https://www.waterstones.com/book/the-joy-journal-for-magical-everyday-play/laura-brand/fearne-cotton/9781529025590?awc=3787_1587379006_0f4fd2ca28a45f2c0f1a0a7edf377350&utm_source=259955&utm_medium=affiliate&utm_campaign=Genie+Shopping

Amazon link: https://tinyurl.com/ybcz223d

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

