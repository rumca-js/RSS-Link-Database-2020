# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Animal Crossing: New Horizons - Nature Day, May Day, & More Explained
 - [https://www.youtube.com/watch?v=3ryVcfiC5qQ](https://www.youtube.com/watch?v=3ryVcfiC5qQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-04-21 00:00:00+00:00

Animal Crossing: New Horizons is getting more island visitors on April 23 thanks to a new update. Starting that day, Leif the sloth will make periodic visits to your plaza to sell seeds for flowers and shrubs, the latter being new to the game. Redd will also dock his boat at your private beach to sell furniture and art. And yes, that art can be donated to the museum's new art wing.

The game's next named event is Nature Day, which adds special Nook Miles+ objectives for tending to your trees, flowers, and new shrubs. The event runs from April 23 - May 4, as detailed in the video above.

This is one of several upcoming events headed to the game in the near future. May Day, which includes island tours not available via Nook Miles tickets, will overlap with Nature Day by a bit. International Museum Day and Wedding Season will follow after that.

#AnimalCrossing #NatureDay #GameSpot

## New Cyberpunk 2077 Xbox One X Revealed
 - [https://www.youtube.com/watch?v=Kl7sdNQsmlE](https://www.youtube.com/watch?v=Kl7sdNQsmlE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-04-21 00:00:00+00:00

Microsoft announced its last ever Limited Edition Xbox One X console for CD Projekt Red’s Cyberpunk 2077, Infinity Ward teases a Modern Warfare sequel, and Fortnite’s Astronomical event locks in its headliner. 

Welcome to your GameSpot daily news round-up of the biggest gaming stories. Today Microsoft announced a new Limited Edition Xbox One X bundle for CD Projekt Red's upcoming Cyberpunk 2077, take a look at it in action. It's... breathtaking. 

Meanwhile, Infinity Ward's narrative director teases a potential sequel to 2019's Modern Warfare, and Travis Scott announces a concert in Fortnite's upcoming Astronomical Event. We also take a look at a cool new mod that's bringing Dino Crisis to Resident Evil 3, and Otherside, the developers of System Shock 3, break their silence on what they're working on. Sort of. 

#Cyberpunk2077 #GameSpot

## Let's Play God Of War - 2 Year Anniversary
 - [https://www.youtube.com/watch?v=ApJvwpZ_HWs](https://www.youtube.com/watch?v=ApJvwpZ_HWs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-04-20 00:00:00+00:00

Happy birthday, God Of War! To celebrate its second anniversary, Persia hunts for Valkyries in the award-winning comeback.

