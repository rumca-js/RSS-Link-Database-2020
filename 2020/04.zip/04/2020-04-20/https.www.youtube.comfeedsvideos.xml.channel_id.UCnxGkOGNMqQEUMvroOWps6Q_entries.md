# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Best of the Week - April 12, 2020 - Joe Rogan Experience
 - [https://www.youtube.com/watch?v=Bt0nVl1Nlj4](https://www.youtube.com/watch?v=Bt0nVl1Nlj4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-20 00:00:00+00:00

#1457 w/Tim Dillon:
https://www.youtube.com/watch?v=ig9yh8iVZWI

#1458 w/Chris D'Elia:
https://www.youtube.com/watch?v=98mh3jxcuxI

#1459 w/Tom O'Neill:
https://www.youtube.com/watch?v=J36xPWBLcG8

#1460 w/Donnell Rawlings:
https://www.youtube.com/watch?v=IXFlwSr5u_k

