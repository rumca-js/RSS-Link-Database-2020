# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## BookSzpan [#02] Zespół nieprawdziwych wspomnień
 - [https://www.youtube.com/watch?v=Bcs9GDy79dE](https://www.youtube.com/watch?v=Bcs9GDy79dE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-21 00:00:00+00:00

@langustanapalmie #zostańwdomu #książki #bookszpan
________________________________________
Drugi odcinek serii o książkach BookSzpan.

Spis książek z tego odcinka:
Roman Brandstaetter, Jezus z Nazaretu
Fulton J. Sheen, Siedem grzechów głównych
Kevin Vost, Siedem grzechów głównych
Philip Yancey, Zaskoczeni łaską
Hermann Hesse, Siddhartha
Bolesław Prus, Faraon
Kazuo Ishiguro, Nokturny
R.O Kwon, Podpalacze
Gregory David Roberts, Shantaram
Gaston Dorren, Babel
Maja Sontag, Majubaju, czyli żyrafy wychodzą z szafy
Marcin Jacoby, Korea Południowa. Republika żywiołów 
Blake Crouch, Rekursja

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Karaluchy pod poduchy [#07] Skok na tacę
 - [https://www.youtube.com/watch?v=G3pnyvbV6oY](https://www.youtube.com/watch?v=G3pnyvbV6oY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-21 00:00:00+00:00

@Langusta na palmie #dobranocka #karaluchypodpoduchy #zostanwdomu 

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Codzienne wieczorne spotkania z dobranckami i kompletą. 

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#484] Użytek
 - [https://www.youtube.com/watch?v=czKPzVCWv5Y](https://www.youtube.com/watch?v=czKPzVCWv5Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-21 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#177] Zamknięci w lęku
 - [https://www.youtube.com/watch?v=KnudFSLox_o](https://www.youtube.com/watch?v=KnudFSLox_o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-20 00:00:00+00:00

#cnn #slowonaniedziele #kazankodookienka

Kazanie Niedziela Miłosierdzia Bożego, ROK A

1. czytanie (Dz 2, 42-47)

Uczniowie trwali w nauce apostołów i we wspólnocie, w łamaniu chleba i w modlitwach.
Bojaźń ogarniała każdego, gdyż apostołowie czynili wiele znaków i cudów. Ci wszyscy, którzy uwierzyli, przebywali razem i wszystko mieli wspólne. Sprzedawali majątki i dobra i rozdzielali je każdemu według potrzeby.
Codziennie trwali jednomyślnie w świątyni, a łamiąc chleb po domach, spożywali posiłek w radości i prostocie serca. Wielbili Boga, a cały lud odnosił się do nich życzliwie. Pan zaś przymnażał im codziennie tych, którzy dostępowali zbawienia.

2. czytanie (1 P 1, 3-9)

Niech będzie błogosławiony Bóg i Ojciec Pana naszego, Jezusa Chrystusa. On w swoim wielkim miłosierdziu przez powstanie z martwych Jezusa Chrystusa na nowo zrodził nas do żywej nadziei: do dziedzictwa niezniszczalnego i niepokalanego, i niewiędnącego, które jest zachowane dla was w niebie. Wy bowiem jesteście przez wiarę strzeżeni mocą Bożą dla zbawienia, gotowego objawić się w czasie ostatecznym.
Dlatego radujcie się, choć teraz musicie doznać trochę smutku z powodu różnorodnych doświadczeń. Przez to wartość waszej wiary okaże się o wiele cenniejsza od niszczalnego złota, które przecież próbuje się w ogniu, na sławę, chwałę i cześć przy objawieniu Jezusa Chrystusa. Wy, choć nie widzieliście, miłujecie Go; wy w Niego teraz, choć nie widzicie, przecież wierzycie, a ucieszycie się radością niewymowną i pełną chwały wtedy, gdy osiągniecie cel waszej wiary – zbawienie dusz.
Można odmawiać sekwencję: Niech w święto radosne Paschalnej Ofiary

Ewangelia (J 20, 19-31)

Wieczorem w dniu zmartwychwstania, tam gdzie przebywali uczniowie, choć drzwi były zamknięte z obawy przed Żydami, przyszedł Jezus, stanął pośrodku i rzekł do nich: «Pokój wam!» A to powiedziawszy, pokazał im ręce i bok. Uradowali się zatem uczniowie, ujrzawszy Pana.
A Jezus znowu rzekł do nich: «Pokój wam! Jak Ojciec Mnie posłał, tak i Ja was posyłam». Po tych słowach tchnął na nich i powiedział im: «Weźmijcie Ducha Świętego! Którym odpuścicie grzechy, są im odpuszczone, a którym zatrzymacie, są im zatrzymane».
Ale Tomasz, jeden z Dwunastu, zwany Didymos, nie był razem z nimi, kiedy przyszedł Jezus. Inni więc uczniowie mówili do niego: «Widzieliśmy Pana!»
Ale on rzekł do nich: «Jeżeli na rękach Jego nie zobaczę śladu gwoździ i nie włożę palca mego w miejsce gwoździ, i ręki mojej nie włożę w bok Jego, nie uwierzę».
A po ośmiu dniach, kiedy uczniowie Jego byli znowu wewnątrz domu i Tomasz z nimi, Jezus przyszedł, choć drzwi były zamknięte, stanął pośrodku i rzekł: «Pokój wam!» Następnie rzekł do Tomasza: «Podnieś tutaj swój palec i zobacz moje ręce. Podnieś rękę i włóż w mój bok, i nie bądź niedowiarkiem, lecz wierzącym».
Tomasz w odpowiedzi rzekł do Niego: «Pan mój i Bóg mój!»
Powiedział mu Jezus: «Uwierzyłeś dlatego, że Mnie ujrzałeś? Błogosławieni, którzy nie widzieli, a uwierzyli».
I wiele innych znaków, których nie zapisano w tej księdze, uczynił Jezus wobec uczniów. Te zaś zapisano, abyście wierzyli, że Jezus jest Mesjaszem, Synem Bożym, i abyście wierząc, mieli życie w imię Jego.
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Karaluchy pod poduchy [#06] Pucybut
 - [https://www.youtube.com/watch?v=aE7wroi8QnU](https://www.youtube.com/watch?v=aE7wroi8QnU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-20 00:00:00+00:00

@Langusta na palmie #dobranocka #karaluchypodpoduchy #zostanwdomu 

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Codzienne wieczorne spotkania z dobranckami i kompletą. 

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Ksiądz gra w grę: Uncharted 4 [#02] Odważ się być samodzielnym
 - [https://www.youtube.com/watch?v=qggIuWWQuJ8](https://www.youtube.com/watch?v=qggIuWWQuJ8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-20 00:00:00+00:00

@langustanapalmie #ksiadzgrawgre #uncharted
 ________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Miniaturkę stworzył dla nas: Sebastian Gwóźdź. 

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#483] Za bardzo
 - [https://www.youtube.com/watch?v=LgQt-aptOss](https://www.youtube.com/watch?v=LgQt-aptOss)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-20 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

