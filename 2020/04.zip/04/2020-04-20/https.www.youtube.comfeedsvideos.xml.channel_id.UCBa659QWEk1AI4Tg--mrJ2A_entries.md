# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## Why You Can't Name A File CON In Windows
 - [https://www.youtube.com/watch?v=bC6tngl0PTI](https://www.youtube.com/watch?v=bC6tngl0PTI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2020-04-20 00:00:00+00:00

The short answer is "backwards compatibility". The long answer is... well, it's the rest of this video.

MORE BASICS: https://www.youtube.com/playlist?list=PL96C35uN7xGLLeET0dOWaKHkAlPsrkcha

Written with Sean Elliott https://twitter.com/SeanMElliott/
Graphics by William Marler https://wmad.co.uk
Audio mix by Graham Haerther https://haerther.net/

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

