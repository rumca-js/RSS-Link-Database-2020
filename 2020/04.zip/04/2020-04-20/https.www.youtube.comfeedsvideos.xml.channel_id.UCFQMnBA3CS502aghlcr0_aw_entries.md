# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## the GREATEST opportunity of your LIFETIME - Fake Guru #55
 - [https://www.youtube.com/watch?v=vJsz6Di8ksA](https://www.youtube.com/watch?v=vJsz6Di8ksA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-04-21 00:00:00+00:00

the truth about the YTA method finally comes out....
CLICK HERE if you want to join the fake guru SPOTTING COURSE (must like and subscribe first)👉👉👉 https://bit.ly/2Kqpy7b
Caleb maddix is a motivational "guru" who got his start when his dad introduced him to this world. His dad is also a motivational speaker. Now Caleb Maddix is launching a new course and running thousands of ads on Youtube promoting what he calls "the greatest opportunity of our era" and insists that this money making plan is the best he's ever seen. 

We uncover the truth in this review of his paid course.

