# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga Paula does XM: Algar - Lust for Life (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=76iXTGmLjOM](https://www.youtube.com/watch?v=76iXTGmLjOM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-04-21 00:00:00+00:00

"Lust for Life" by Algar (Jimmy Granath). Art "Utube" by Schlörb, 3rd at Gerp 2015. This upload is intended for headphones.

DeliTracker 2.34 with 14Bit-NotePlayer 4.30. Normal mixing with actual mixing frequency of 48587 Hz. No panning, no 3D, no anti-click and DSP off. Auto boost enabled. 100% flawless playback not guaranteed. The track reports 4 channels. Screenmode was Euro72 Productivity.

Made using real A1200 audio. A recapped Rev 1D.4 (AWK 364720-04) mobo with resistors R321 and R331 = 680 ohms. More info about these two resistors here (RetroGameModz):
https://www.youtube.com/watch?v=7sZ7vLcURK4&t=0s

Visit my channel for more Amiga music.

## Amiga music: Dascon - Begrenzt Viruzid (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=h4yQ8gpWtZY](https://www.youtube.com/watch?v=h4yQ8gpWtZY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-04-21 00:00:00+00:00

"Begrenzt Viruzid" by Dascon/The Deadliners^Haujobb^DSR (Bernd Hoffmann), 2nd at Revision 2020 oldskool music competition. Art "Devilish" by Otro, 3rd at Little Computer People 2009. This upload is intended for headphones only.

Made using real A1200 audio. A recapped Rev 1D.4 (AWK 364720-04) mobo with resistors R321 and R331 = 680 ohms. More info about these two resistors here (RetroGameModz):
https://www.youtube.com/watch?v=7sZ7vLcURK4&t=0s

Visit my channel for more Amiga music.

## Amiga music: Teo, Juice & Virgill - The AmigaKlang experience (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=jR5vuUX1JGY](https://www.youtube.com/watch?v=jR5vuUX1JGY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-04-21 00:00:00+00:00

3 tracks made with Virgill's AmigaKlang modular synth software. These were some of the Revision 2020 oldskool music compo entries. All instruments are synthetic of course (no prerecorded samples). Trivia: I had to switch off ACA1233n/40 accelerator on my A1200 to get the executables play the audio correctly. This upload is intended for headphones only.

Jumplist:
00:00 Teo - Optimal Workflow (placed 3rd), 9872 byte exe. Art "Whirl" (1995) by Lazur
02:49 Juice - Tremors (placed 13th), 10472 byte exe. Art "HK Sides" by Otro (3rd at Datastorm 2010)
05:40 Virgill - redruM redruM (winner), 27740 byte exe. Art "Serenity" by Jok & Slummy (1st at Datastorm 2017 Summer)

AmigaKlang on Pouet.net:
https://www.pouet.net/prod.php?which=85351

Virgill on SoundCloud:
https://soundcloud.com/virgill

Made using real A1200 audio. A recapped Rev 1D.4 (AWK 364720-04) mobo with resistors R321 and R331 = 680 ohms. More info about these two resistors here (RetroGameModz):
https://www.youtube.com/watch?v=7sZ7vLcURK4&t=0s

Visit my channel for more Amiga music.

