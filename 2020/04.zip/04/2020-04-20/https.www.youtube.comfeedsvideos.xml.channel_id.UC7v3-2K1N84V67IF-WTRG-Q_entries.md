# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Final Fantasy 7 Remake - SPOILER Talk
 - [https://www.youtube.com/watch?v=CvBmpJBycj8](https://www.youtube.com/watch?v=CvBmpJBycj8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-04-21 00:00:00+00:00

Final Fantasy 7 Remake actually had some unexpected turns taken. I'll unpack them here in my FINAL FANTASY 7 REMAKE SPOILER TALK!

#FinalFantasy7Remake

