# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## The Most Dangerous Way to Meditate (Funny)
 - [https://www.youtube.com/watch?v=RUeaykhrw2s](https://www.youtube.com/watch?v=RUeaykhrw2s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-04-21 00:00:00+00:00

Get 10% off Onnit Supplements Here - https://onnit.com/jp

Sign up for my Livestream Comedy Show Friday Night, Still Alive! - https://www.awakenwithjp.com/live

If your meditation practice isn't giving you mild ptsd, then you're not meditating hard enough. Meditation Bootcamp is the first movement to combine the best of meditation with the best of military bootcamp so you can experience even more bliss and enlightenment faster.

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Click Here to join my PATREON - https://awakenwithjp.com/patron
---- Want to be the first to see my new videos with 24 hour early access? Just click this to receive the alerts! - https://m.me/awakenwithjp?ref=w6836464

Listen and Subscribe to my NEW Podcast here: 
https://podcasts.apple.com/ca/podcast/awaken-with-jp-sears-show/id1436938686
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

-Order my new book at: http://HowToBeUltraSpiritual.com/

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

