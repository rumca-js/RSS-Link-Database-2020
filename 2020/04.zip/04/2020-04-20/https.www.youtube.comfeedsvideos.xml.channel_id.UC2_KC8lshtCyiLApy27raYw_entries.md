# Source:KnowledgeHusk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw, language:en-US

## The Oldest Surviving Media In History
 - [https://www.youtube.com/watch?v=gl9z_3aIHko](https://www.youtube.com/watch?v=gl9z_3aIHko)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw
 - date published: 2020-04-21 00:00:00+00:00

We like to fill stuff, take pics, record those slappin’EPs, but ya know what, it used to be hard to do that stuff. Really hard. And so any experiments from those early days of recapturing the world are now the oldest surviving media we have.

And today I look at some of them. Cause it’s fun.


Twitter: https://twitter.com/KnowledgeHubTy
Soundcloud: https://soundcloud.com/user-503704039
Patreon: https://www.patreon.com/theknowledgehub
Second Channel: https://www.youtube.com/channel/UC-KL04Ra6E1Du0pFawN4pWg
Spotify: https://open.spotify.com/artist/3STpelEilrthF8UxsQTaaw?si=52TH_ZKTQhaKhfnK1Jomfg

