# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## Burn Water Selected Tracks [2014 - 2020]
 - [https://www.youtube.com/watch?v=uZ_fkDj-bqQ](https://www.youtube.com/watch?v=uZ_fkDj-bqQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2020-04-20 00:00:00+00:00

Hope you're all staying safe out there. Enjoy this mix of my music while I work on more videos.
0:00 Intro (Guitar Jam)
3:14 Does it Get Easier?
5:52 Hide
9:23 Never Lose Sight
13:00 Burning Love
16:27 Butterfly Culture
20:20 I found U
23:19 Call to Earth
27:48 She Shines
31:21 Melbourne
35:15 Miss U
39:28 I Just Want You Close
43:55 Movement
46:50 Trust
50:31 Little Thoughts
53:49 Dreamin’
57:09 Assurance
1:02:05 Stay
1:05:41 Wish You Were Here
1:09:48 Closer
1:13:54 Light Up
1:16:54 Inventor
1:18:48 Sonder [Reprise]
1:22:06 Shelter
1:26:40 Gone For Good
1:30:56 Sonder
1:34:48 Time
1:38:20 So Alive
1:40:00 Bright Eyed Angel
1:44:58 Star Rider


» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater

