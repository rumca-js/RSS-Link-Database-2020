# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## VR is facing a MASSIVE issue in 2020
 - [https://www.youtube.com/watch?v=_s6vLarEdsE](https://www.youtube.com/watch?v=_s6vLarEdsE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-04-21 00:00:00+00:00

Hello and welcome to TUESDAY NEWSDAY! Your number one resource for the entire weeks worth of VR news. 

Links to stream for Swords of Gurrah giveaway:


Today I covered:

Oculus Del Mar and Jedi controller firmware leaks:
https://uploadvr.com/oculus-del-mar-quest-2/
https://uploadvr.com/oculus-jedi-controller-driver-found/

Oculus Connect 6 cancelled for digital version:
https://www.roadtovr.com/oculus-connect-7-digital-coronavirus/

Meme break inspiration:
https://www.reddit.com/r/VR_memes/comments/fvxls3/when_your_siblings_think_that_your_family_is_a/

VR is facing a massive issue currently:
https://www.wired.com/story/opinion-vr-is-here-to-help-with-our-new-reality/
https://www.marketplace.org/shows/marketplace-tech/covid-19-virtual-reality-headsets/
https://techcrunch.com/2020/03/30/despite-pandemic-gaming-is-well-positioned-to-withstand-recession/

Swords of Gurrah releasing TODAY!
https://store.steampowered.com/app/833090/Swords_of_Gurrah/

Pixel Ripped 1995 Releases on April 23rd (I have a cameo in it)

Bethesda's Elder Scrolls: Blades likely cancelled:
https://www.roadtovr.com/elder-scrolls-blades-vr-bethesda-no-update/

