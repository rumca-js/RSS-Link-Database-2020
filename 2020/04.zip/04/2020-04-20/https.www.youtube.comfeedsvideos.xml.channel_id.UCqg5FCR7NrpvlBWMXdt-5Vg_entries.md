# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Darkest Dungeon Documentary Trailer | Gameumentary
 - [https://www.youtube.com/watch?v=V6aRHZ4VyyM](https://www.youtube.com/watch?v=V6aRHZ4VyyM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-04-21 00:00:00+00:00

The Escapist is proud to share the reveal trailer for our Darkest Dungeon documentary. Join us as we tell the story of Red Hook Studios and their journey in creating Darkest Dungeon. The full documentary will release on Monday, April 27th. YouTube Members get the video this Friday! 

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►► https://sharkrobot.com/collections/zero-punctuation 

Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 

Like us on Facebook ►► http://www.facebook.com/EscapistMag

Follow us on Twitter ►► https://twitter.com/EscapistMag

#DarkestDungeon #Documentary

## Introducing The Escapist + & YouTube Memberships
 - [https://www.youtube.com/watch?v=PSm45ggwzmY](https://www.youtube.com/watch?v=PSm45ggwzmY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-04-21 00:00:00+00:00

Welcome to The Escapist + & YouTube Memberships! We're excited to offer some new premium options for our subscribers to help support the content we create. Please check the comments for all the links you need!

The Escapist + https://www.escapistmagazine.com/v2/the-escapist
New Merch Store: https://teespring.com/stores/the-escapist-store
New Forums: https://forums.escapistmagazine.com/

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►► https://sharkrobot.com/collections/zero-punctuation 

Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 

Like us on Facebook ►► http://www.facebook.com/EscapistMag

Follow us on Twitter ►► https://twitter.com/EscapistMag

## Was The Legend of Zelda: Breath of the Wild Really That Good? | Slightly Civil War
 - [https://www.youtube.com/watch?v=V12qpZOQ9_I](https://www.youtube.com/watch?v=V12qpZOQ9_I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-04-20 00:00:00+00:00

Yahtzee and Jack Packard debate whether or not The Legend of Zelda: Breath of the Wild was as good as everyone says it is.

Watch today's episode of Slightly Civil War where Yahtzee and Jack debate whether or not Doom 2016 was better than Doom Eternal. https://www.escapistmagazine.com/v2/was-doom-2016-better-than-doom-eternal-slightly-civil-war/

Get the Podcast:

Soundcloud: https://soundcloud.com/user-944993929/slightly-civil-war-was-doom-2016-better-than-doom-eternal
Spotify: https://open.spotify.com/show/553m016S05GYKGLAJCkvIQ?si=FT_wuURcQCCahp2ibSlzLA
iTunes: https://podcasts.apple.com/ca/podcast/the-escapist/id1466955951

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►► https://sharkrobot.com/collections/zero-punctuation 

Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 

Like us on Facebook ►► http://www.facebook.com/EscapistMag

Follow us on Twitter ►► https://twitter.com/EscapistMag

