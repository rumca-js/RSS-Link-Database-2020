# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## WHAT!? They Put MINECRAFT In REAL LIFE!?!?!?
 - [https://www.youtube.com/watch?v=Cu6VSf5aOaM](https://www.youtube.com/watch?v=Cu6VSf5aOaM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-04-21 00:00:00+00:00

All the info you need about the newest Minecraft update right here! GET OFF MY LAWN!

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE NOW: https://lukesmith.xyz/donate 💰😎👌💯

## Why I DON'T Use EMACS!
 - [https://www.youtube.com/watch?v=1mr3issv79s](https://www.youtube.com/watch?v=1mr3issv79s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-04-20 00:00:00+00:00

What I'm actually referring to Emacs is, in fact, GNU Emacs. Why don't I use it? 👉 Let's find out!

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE NOW: https://lukesmith.xyz/donate 💰😎👌💯

