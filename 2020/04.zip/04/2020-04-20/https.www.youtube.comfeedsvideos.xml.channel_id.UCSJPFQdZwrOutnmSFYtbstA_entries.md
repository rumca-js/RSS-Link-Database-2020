# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Resident Evil 3 Remake - A Wasted Opportunity
 - [https://www.youtube.com/watch?v=UxfvgMp9xdU](https://www.youtube.com/watch?v=UxfvgMp9xdU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-04-20 00:00:00+00:00

Grab your Jill Sandwiches as we review the disappointing, overpriced expansion pack that is Resident Evil 3.

