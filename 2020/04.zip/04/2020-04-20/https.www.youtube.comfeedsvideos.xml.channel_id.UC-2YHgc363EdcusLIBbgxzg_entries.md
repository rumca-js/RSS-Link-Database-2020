# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## Ball Lightning: Weather's Biggest Mystery | Answers With Joe
 - [https://www.youtube.com/watch?v=_gOlQCI9Tgg](https://www.youtube.com/watch?v=_gOlQCI9Tgg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2020-04-20 00:00:00+00:00

Get 1 month of CuriosityStream for free when you sign up at http://www.curiositystream.com/joescott
Ball lightning is a mysterious phenomena that's been seen since the beginning of recorded history, but it's so rare most people put it in the category of folklore or pseudoscience.

However, there's some new studies that seem to show that ball lightning is not only real, but there's possibly many different kinds, and there's a lot we can learn from it.

Watch this video ad-free on Nebula: https://nebula.tv/videos/joe-scott-ball-lightning-weathers-biggest-mystery

Want to support the channel? Here's some ways to do it!

Patreon: http://www.patreon.com/answerswithjoe

Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join

Merch: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

https://phys.org/news/2017-10-lightning-afterglow-gamma.html

https://envronozone.com/science/ozone_science.htm

https://www.nationalgeographic.com/environment/weather/reference/ball-lightning/#close

Animation: https://www.youtube.com/watch?v=lQGFvKAujb8

https://www.livescience.com/42731-weird-lightning-types.html

https://www.newscientist.com/article/dn24886-natural-ball-lightning-probed-for-the-first-time/

https://www.pbs.org/wgbh/nova/article/great-balls-of-fire/

https://www.nationalgeographic.com/news/2010/5/100514-science-ball-lightning-hallucinations-magnetic-fields/

Spectrograph results
http://physics.aps.org/articles/v7/5 

https://www.researchgate.net/publication/260789338_Solid_charged-core_model_of_ball_lightning_2

