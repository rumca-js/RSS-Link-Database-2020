# Source:Ryan George, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ, language:en-US

## Please Pay Attention To Celebrity Guy!
 - [https://www.youtube.com/watch?v=Pa6wHHbqRqU](https://www.youtube.com/watch?v=Pa6wHHbqRqU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ
 - date published: 2020-04-21 00:00:00+00:00

Hi there hello please subscribe: http://bit.ly/2wscuFf
Twitter/Instagram: @TheRyanGeorge

Please pay attention to Celebrity Guy. It is very important. He would like it very much. Thank you.

