# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Caroline Polachek - Door (Live on KEXP)
 - [https://www.youtube.com/watch?v=kb_a_6-mS_Y](https://www.youtube.com/watch?v=kb_a_6-mS_Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-04-20 00:00:00+00:00

http://KEXP.ORG presents Caroline Polachek performing "Door" live in the KEXP studio. Recorded December 18, 2019.

Host: Kevin Cole
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann & Scott Holpainen
Editor: Justin Wilmore

http://kexp.org
https://www.carolinepolachek.com

## Caroline Polachek - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=QsqObMOwmtE](https://www.youtube.com/watch?v=QsqObMOwmtE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-04-20 00:00:00+00:00

http://KEXP.ORG presents Caroline Polachek performing live in the KEXP studio. Recorded December 18, 2019.

Songs:
Go As A Dream
Door
So Hot You're Hurting My Feelings
Ocean Of Tears

Host: Kevin Cole
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann & Scott Holpainen
Editor: Justin Wilmore

http://kexp.org
https://www.carolinepolachek.com

## Caroline Polachek - Go As A Dream (Live on KEXP)
 - [https://www.youtube.com/watch?v=HUc9rBacmd4](https://www.youtube.com/watch?v=HUc9rBacmd4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-04-20 00:00:00+00:00

http://KEXP.ORG presents Caroline Polachek performing "Go As A Dream" live in the KEXP studio. Recorded December 18, 2019.

Host: Kevin Cole
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann & Scott Holpainen
Editor: Justin Wilmore

http://kexp.org
https://www.carolinepolachek.com

## Caroline Polachek - Ocean Of Tears (Live on KEXP)
 - [https://www.youtube.com/watch?v=8UU8Jw7zhO4](https://www.youtube.com/watch?v=8UU8Jw7zhO4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-04-20 00:00:00+00:00

http://KEXP.ORG presents Caroline Polachek performing "Ocean Of Tears" live in the KEXP studio. Recorded December 18, 2019.

Host: Kevin Cole
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann & Scott Holpainen
Editor: Justin Wilmore

http://kexp.org
https://www.carolinepolachek.com

## Caroline Polachek - So Hot You're Hurting My Feelings (Live on KEXP)
 - [https://www.youtube.com/watch?v=fFwuZTPaesY](https://www.youtube.com/watch?v=fFwuZTPaesY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-04-20 00:00:00+00:00

http://KEXP.ORG presents Caroline Polachek performing "So Hot You're Hurting My Feelings" live in the KEXP studio. Recorded December 18, 2019.

Host: Kevin Cole
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann & Scott Holpainen
Editor: Justin Wilmore

http://kexp.org
https://www.carolinepolachek.com

