# Source:Jeff Gerling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg, language:en-US

## Drupal 7 to 8 LIVE Migration - Ep 12 - Pathauto and redirect SEO migration and config split
 - [https://www.youtube.com/watch?v=Ql_-krnxv3U](https://www.youtube.com/watch?v=Ql_-krnxv3U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg
 - date published: 2020-04-21 00:00:00+00:00

In this twelfth livestream, we finished migrating redirects to preserve URLs and prevent link rot, added the pathauto module and a migration of pathauto patterns and settings, and started working on configuring a Configuration Split for the local development environment!

Support me on Patreon: https://www.patreon.com/geerlingguy

Sponsor me on GitHub: https://github.com/sponsors/geerlingguy

See more: https://www.jeffgeerling.com/blog/2020/migrating-jeffgeerlingcom-drupal-7-drupal-8-how-video-series

