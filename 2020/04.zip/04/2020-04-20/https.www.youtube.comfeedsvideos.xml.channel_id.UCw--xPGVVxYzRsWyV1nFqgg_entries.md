# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## My Problem With YA Fantasy - PT. 2 (Lies & Limitations)
 - [https://www.youtube.com/watch?v=7dkXYiaeSJI](https://www.youtube.com/watch?v=7dkXYiaeSJI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-04-21 00:00:00+00:00

In this video, I go over the Limitations & Lies of modern Young Adult Literature. This is part 2 in a two-part series on the subject. 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## Aleron Kong Talks LitRPG's and New Age Writing - FANTASY CHAT
 - [https://www.youtube.com/watch?v=EtsxBOkcd6c](https://www.youtube.com/watch?v=EtsxBOkcd6c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-04-20 00:00:00+00:00

I had a talk with Aleron Kong. The author of The Land Founding and the Choas Seeds series. 
Check out The Land Founding here: https://amzn.to/2VFCfQz

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

