# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Just the Two of Us | Bill Withers | Pomplamoose
 - [https://www.youtube.com/watch?v=pU2CGfIuxUU](https://www.youtube.com/watch?v=pU2CGfIuxUU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2020-04-09 00:00:00+00:00

Gardenview out now, listen on Spotify (https://sptfy.com/gardenview) or wherever you listen to music.

 Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

A cover of Just the Two of Us by Pomplamoose.

CREDITS

Lead Vocals / Acoustic Bass: Nataly Dawn
Piano: Jack Conte
Mixing/Mastering: Caleb Parker
Video Editor: Dominic Mercurio

Recorded at our home studio in San Francisco.

