# Source:Snazzy Labs, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w, language:en-US

## Is Apple Worth It in 2020?
 - [https://www.youtube.com/watch?v=RdibdUNuJKo](https://www.youtube.com/watch?v=RdibdUNuJKo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w
 - date published: 2020-04-10 00:00:00+00:00

Snazzy Labs host, Quinn Nelson, talks about the state of Apple in 2020.
Go to https://hostinger.com/snazzy AND use code snazzy to get up to 91% OFF yearly web hosting plans.

Purchase iMac Pro - https://geni.us/94rrTln
Purchase 27" i9 iMac - https://geni.us/LZyC4Y
Purchase 16" MacBook Pro - https://geni.us/mCDfCh5
Don't purchase the 13" MacBook Pro
Purchase 2020 MacBook Air - https://geni.us/DKK6 
Don't purchase the Mac mini
Purchase iPad Pro 12.9" - https://geni.us/fBEGWx
Purchase iPad Pro 11" - https://geni.us/pyF2hmt
Don't purchase the iPad Air
Purchase the "cheap" iPad - https://geni.us/9VkQZ0j
Don't purchase iPad mini
Purchase iPhone 11 Pro - http://apple.com/iphone-11-pro
Purchase iPhone 11 - http://apple.com/iphone-11
Purchase AirPods Pro - https://geni.us/OsVlZcw

Subscribe to my podcast Flashback! - http://relay.fm/flashback
Follow me on Twitter - http://twitter.com/snazzyq
Follow me on Instagram - http://instagram.com/snazzyq

It's a new year and while we're all stuck here at home, Quinn of Snazzy Labs decided it was probably time to talk about Apple in 2020 and the state of Apple's lineup. With the butterfly keyboard gone, Apple's laptops are starting to look good once again. The Mac Pro is expensive but has a market. iMac Pro is looking a bit awkward and iMac is pretty good except a dated design. Boy, this sure is rambly isn't it? Gotta get them keywords though. We'll also talk a look at iPad Pro and it's upcoming Magic Keyboard for iPad Pro—cursor support—finally! iPhone 12 rumors as well as iPhone SE 2 or iPhone 9 rumors are going wild so I'm hopeful that things will turn at. All OLED screens, a smaller size, support for AR with the new LIDAR camera sensor, and more. This video is a fun one—and I didn't proofread this at all—so buckle up. Hey guys.

