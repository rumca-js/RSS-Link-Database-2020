# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## BEST SERVED COLD - REVIEW
 - [https://www.youtube.com/watch?v=VXKzndKp2K4](https://www.youtube.com/watch?v=VXKzndKp2K4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-04-10 00:00:00+00:00

My review of Best Served Cold. The first of the First Law series stand-alone books by Joe Abercrombie.
GET THE BOOK: https://amzn.to/2VeFIFv

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## The Grohalind - Magic System Explained (My Book)
 - [https://www.youtube.com/watch?v=4Pho1avhSOc](https://www.youtube.com/watch?v=4Pho1avhSOc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-04-09 00:00:00+00:00

So here is a purely technical look into one of the magic systems I am crafting for my fantasy world. I would love any and all feedback in the comments down there! Hope you enjoy this fantasy magic system. 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

