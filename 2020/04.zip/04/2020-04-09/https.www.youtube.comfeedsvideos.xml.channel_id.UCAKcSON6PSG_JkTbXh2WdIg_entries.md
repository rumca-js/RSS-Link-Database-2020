# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Artists get creative with music videos, Marilia Mendonca, Dr. Dre, and more (The Current Music News)
 - [https://www.youtube.com/watch?v=n4coyKl7S10](https://www.youtube.com/watch?v=n4coyKl7S10)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-10 00:00:00+00:00

April 10, 2020: Artists including Thao Nguyen and Phoebe Bridgers are getting creative with music videos shot and released during social distancing. Also today: is there a workable business model for DJs spinning sets online? Rogue Wave and Aesop Rock are trading namechecks for a good cause, Marilia Mendonca becomes a livestreaming global sensation, and Dr. Dre picks a very apt date for 'The Chronic' to hit streaming services.
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Brian Setzer and Stray Cats (Teenage Kicks from The Current)
 - [https://www.youtube.com/watch?v=z_-Sk-OVC2k](https://www.youtube.com/watch?v=z_-Sk-OVC2k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-10 00:00:00+00:00

Host Jim McGuinn spotlights Brian Setzer and Stray Cats, who helped lead a rockabilly revival in the late 70s and early 80s, and who are still playing today.
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Angry fans accuse ticketers of deceptive concert refund policies (The Current Music News)
 - [https://www.youtube.com/watch?v=9rdi7Mk3v-Y](https://www.youtube.com/watch?v=9rdi7Mk3v-Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-09 00:00:00+00:00

April 9, 2020: Fans are accusing agencies like Ticketmaster and StubHub of holding their ticket money hostage as concerts are postponed inevitably. Also today: hip-hop artist Chynna has died at 25, Radiohead announce plans to stream past concert films, Bob Dylan gets his first number one, Randy Newman advises 'Stay Away,' and Billie Eilish is actually kind of enjoying the solitude.
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

