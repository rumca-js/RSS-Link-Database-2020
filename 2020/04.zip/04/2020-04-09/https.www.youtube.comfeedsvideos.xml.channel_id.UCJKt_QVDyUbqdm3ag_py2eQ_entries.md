# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## 2SID music: Flex - Electric City (FPGASID 8580 custom stereo bx_🎧)
 - [https://www.youtube.com/watch?v=vyZ05Usl8eI](https://www.youtube.com/watch?v=vyZ05Usl8eI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-04-10 00:00:00+00:00

"Electric City" C64 version (2020) by Flex/Artline Designs, Contex (Antti Hannula). Original (2000) Amiga AHX by JazzCat (Piotr Pacyna). Pixel art "Reflected" (2012) by Joe (2nd at Flashback 2012 C64 graphics competition). Headphones recommended.

This is a custom stereo (pan enveloped) edit with Brainworx processing.

Original pure stereo version (Demoscene 'n' Stuff, emulated):
https://www.youtube.com/watch?v=JRZWyZPojC8

My A1200 Dolbyfied upload of the AHX original:
https://www.youtube.com/watch?v=ZOd_rnxMtRo

Made using FPGASID fw 0A running in C64 Reloaded MK2.

FPGASID:
http://www.fpgasid.de/

## Atari (YM2149) music: 505 & Michu - Mutative (bx_🎧)
 - [https://www.youtube.com/watch?v=FAH3Q1trgr4](https://www.youtube.com/watch?v=FAH3Q1trgr4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-04-09 00:00:00+00:00

"Mutative" (2012) by 505 & Michu. Winner of Sillyventure 2012. This track has DMA audio.

Emulated with AY-3-8910/12 Emulator version 2.9 beta 26. With its detailed channel controls and .wav recording abilites, i can get each channel as a mono track into a multitrack editor for full pan envelope editing.

AY-3-8910/12 Emulator:
http://bulba.untergrund.net/emulator_e.htm

SNDH Atari ST YM2149 collection:
http://sndh.atari.org/about.php

## Atari (YM2149) music: AceMan - Pumpkin Hop (bx_🎧)
 - [https://www.youtube.com/watch?v=f5uqMY2AO6U](https://www.youtube.com/watch?v=f5uqMY2AO6U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-04-09 00:00:00+00:00

"Pumpkin Hop" (2016) by AceMan (Jakub Szelag). Winner of Sillyventure 2016. This track has DMA audio.

Emulated with AY-3-8910/12 Emulator version 2.9 beta 26. With its detailed channel controls and .wav recording abilites, i can get each channel as a mono track into a multitrack editor for full pan envelope editing. The Reaper screenshot in the video shows the final result (orange line indicates position in the stereo field, center of waveform=center, top=100% left and bottom=100% right).

AceMan's upload:
https://www.youtube.com/watch?v=MDXWCQl7N8Q

AY-3-8910/12 Emulator:
http://bulba.untergrund.net/emulator_e.htm

SNDH Atari ST YM2149 collection:
http://sndh.atari.org/about.php

