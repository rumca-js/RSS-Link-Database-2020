# Source:SssethTzeentach, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCD6VugMZKRhSyzWEWA9W2fg, language:en-US

## Total Annihilation Kingdoms Review | Shared Suffering™
 - [https://www.youtube.com/watch?v=se6Y2o3OqJQ](https://www.youtube.com/watch?v=se6Y2o3OqJQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCD6VugMZKRhSyzWEWA9W2fg
 - date published: 2020-04-10 00:00:00+00:00

In my darkest dreams I still hear them.
Squawking. Cacawing. Shrieking.

If you're feeling masochistic or just curious
of how far the path of progress has taken us,
you can grab a copy off GOG.com:
https://af.gog.com/game/total_annihilation_kingdoms?as=1630110786


-----------------------
Send Sseth Shekels: https://www.paypal.me/SsethTzeentachGB
Send Sseth Shekels per video:  https://www.patreon.com/Sseth
Send Sseth Shekels / crypto: https://www.subscribestar.com/ssethtzeentach

Website: https://ssethtzeentach.com/
Twitter: https://twitter.com/SsethTzeentach
FB: https://www.facebook.com/sseth672/

