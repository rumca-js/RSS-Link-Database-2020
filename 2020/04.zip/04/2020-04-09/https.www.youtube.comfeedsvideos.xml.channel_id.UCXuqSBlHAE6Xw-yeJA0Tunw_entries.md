# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## The Fear of Technology is REAL... - WAN Show April 10, 2020
 - [https://www.youtube.com/watch?v=hXp3STQpakQ](https://www.youtube.com/watch?v=hXp3STQpakQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-04-10 00:00:00+00:00

Visit https://www.squarespace.com/WAN and use offer code WAN for 10% off

Sign up for Private Internet Access VPN at https://lmg.gg/piawan

Save 15% today with offer code LTT on Displate at https://lmg.gg/displatewan

Buy LTX 2020 Presented by Intel Tickets: https://lmg.gg/ltx20tickets
Learn more about LTX 2020: https://www.ltxexpo.com/
LTX 2020 Activities: https://www.ltxexpo.com/attractions
LTX 2020 Special Guests: https://www.ltxexpo.com/guests

Buy an LTT shirt, hoodie, hat, and even our own water bottle at https://lmg.gg/wanlttstore

Check out Carpool Critics, our new movie podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Podcast Download: http://traffic.libsyn.com/linustechtips/Why_do_People_Hate_Technology..._-_WAN_Show_April_10_2020.mp3

Timestamps: (Courtesy of JBSTheGamer)

10:46 Apple and google Teams up to use your data.
24:40 5G towers has been set fire to
33:17 This video's sponsor
37:15 PlayStation 5 controller
55:18 AMD 4th Gen CPUs rumored to release September 2020
1:02:26 LTT Store updates
1:12:00 Intel XE HP GPU
1:18:03 Linus asks questions people have asked and says things about messages people have sent

## This was fun... until it wasn't! - Giant 55" Screen Protector!
 - [https://www.youtube.com/watch?v=ffPHJi4oNUA](https://www.youtube.com/watch?v=ffPHJi4oNUA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-04-09 00:00:00+00:00

Get iFixit's NEW Mahi Driver Kit today at https://www.ifixit.com/linus

Add Honey for FREE and start saving today at https://joinhoney.com/ltt
Thanks, Honey for sponsoring!

We tried the kick-proof TV, and it was AWESOME... but what about a kick-proof screen protector?...

Buy TV Screen Protectors
On Best Buy (PAID LINK): https://shop-links.co/1722180675279752159
On Amazon (PAID LINK): https://geni.us/7vpOV18
On Newegg (PAID LINK): https://geni.us/yM9A

Buy Smart TVs
On Best Buy (Paid Link): https://shop-links.co/1722180824018661817
On World Wide Stereo (Paid Link): https://shop-links.co/1722180830002771519
On Crutchfield (Paid Link): https://shop-links.co/1722180831857322109
On Amazon (Paid Link): https://geni.us/GEpxA4
On Newegg (Paid Link): https://geni.us/fTmhl
On BHPhoto(Paid Link): https://geni.us/taw1K

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1175490-we-got-a-55-screen-protector-from-china/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Get your ticket to LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

