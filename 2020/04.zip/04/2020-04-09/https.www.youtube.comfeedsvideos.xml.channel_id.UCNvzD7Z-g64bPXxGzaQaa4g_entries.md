# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## CYBERPUNK DLC COULD BE HUGE, DEAD ISLAND 2 RETURNS, & MORE
 - [https://www.youtube.com/watch?v=IfTYW2zmkvQ](https://www.youtube.com/watch?v=IfTYW2zmkvQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-04-10 00:00:00+00:00

Go to http://buyraycon.com/gameranx for 15% off your order! Brought to you buy Raycon.

The Final Fantasy VII remake launches, PS5 controller is revealed, Dead Island returns to the news, and much more in a week full of gaming news.
Subscribe for more: http://youtube.com/gameranxtv 

*Jakes twitter: https://twitter.com/jakebaldino 
*Instagram: https://goo.gl/HH6mTW 

 discord.gg/gameranx 

 Weekly giveaway link: https://goo.gl/forms/a7zCtr1HuTkzWuOo2 



 ~~~~STORIES~~~~



Cyberpunk news
https://www.videogameschronicle.com/news/cyberpunk-2077-dlc-and-expansions/
https://www.resetera.com/threads/cd-projekt-red-2019-financial-results-teleconference-all-the-cyberpunk-2077-related-info.181902/
https://www.dsogaming.com/news/cyberpunk-2077-is-in-a-complete-form-cd-projekt-red-is-now-only-fixing-and-polishing-it/

Logo art https://wccftech.com/cyberpunk-2077-gang-corporate-names-logos/

DualSense controller
https://youtu.be/Ilwip_l6oq0

Dead Island 2 returns
https://www.gamesradar.com/dead-island-2-will-be-a-cross-gen-game-according-to-a-new-job-listing/



Valorant https://youtu.be/g8amyzDHOKw
Good explainer
https://youtu.be/Xm6sC2b7BBA


Final Fantasy VII developer thank you video
https://youtu.be/WqKFZRmXJlg

Animal Crossing music
https://youtu.be/pdSCuJqrrsA

No Man’s Sky mechs
https://www.youtube.com/watch?v=M0U8gEjjJHk&feature=youtu.be

Saint’s Row 3 remastered
https://twitter.com/SaintsRow/status/1247162340476403712?s=20


Stadia free right now
https://www.theverge.com/2020/4/8/21213679/google-stadia-free-pro-trial-launch-price-features

More RE remakes coming?
https://twistedvoxel.com/capcom-asking-fans-resident-evil-remake-survey/

## 10 SURPRISE Single Player Hits of the Last 10 Years
 - [https://www.youtube.com/watch?v=gOlx2JDf8DI](https://www.youtube.com/watch?v=gOlx2JDf8DI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-04-09 00:00:00+00:00

We wanted an excuse to talk about some of our favorite surprisingly brilliant single-player games for PC, PS4, Xbox One, and more.
Subscribe for more: http://youtube.com/gameranxtv

