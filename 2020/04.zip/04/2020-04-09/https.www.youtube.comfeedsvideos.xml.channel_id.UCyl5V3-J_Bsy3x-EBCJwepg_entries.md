# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## The Elusive Pro-Life Democrat: The Kristen Day Interview
 - [https://www.youtube.com/watch?v=6t9M_6FyECU](https://www.youtube.com/watch?v=6t9M_6FyECU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-04-10 00:00:00+00:00

This is the Babylon Bee Interview Show.

 Kyle and Ethan talk to Kristen Day, the Executive Director of Democrats For Life of America. She caught the Bee’s eye after putting Pete Buttigieg on the spot about whether or not there is a place in the Democratic Party for pro-life voters. Kyle and Ethan chat with her about abortion, pro-life activism, and partisan divides. 

 Topics Discussed

   There are 21 million pro-life democrats that aren’t being served by their party

   Kristen’s pro-life convictions based on religious worldview and science

   Having an opinion on abortion without a uterus

   Safe, Legal, and Rare becoming Legal… ‘Shout Your Abortion’

   Confronting Pete Buttigieg on whether there is room in the party for pro-life Dems

   The goals and activism of Democrats For Life of America

   How the pro-abortion lobby took control of the party

   The Democrats For Life are not officially endorsing Joe Biden

   “Pro-life for the whole life”

   Political strategies and strange alliances

   Adoption and pregnancy centers

