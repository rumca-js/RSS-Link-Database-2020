# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Big Mistake: A Guy Broke Into UFC Fighter Anthony Smith's House
 - [https://www.youtube.com/watch?v=vEIS2JUAQ7Q](https://www.youtube.com/watch?v=vEIS2JUAQ7Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-10 00:00:00+00:00

Taken from JRE MMA #94 w/Brendan Schaub: https://youtu.be/cF7_AaY9tCg

## Charles Manson's CIA Connections w/Brendan Schaub | Joe Rogan
 - [https://www.youtube.com/watch?v=APp8EGUTmgg](https://www.youtube.com/watch?v=APp8EGUTmgg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-10 00:00:00+00:00

Taken from JRE MMA Show #94 w/Brendan Schaub: https://www.youtube.com/watch?v=cF7_AaY9tCg&feature=youtu.be

## How Fox Got Greedy and Lost "The Fighter and the Kid"
 - [https://www.youtube.com/watch?v=b_yboxM33gg](https://www.youtube.com/watch?v=b_yboxM33gg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-10 00:00:00+00:00

Taken from JRE MMA #94 w/Brendan Schaub: https://youtu.be/cF7_AaY9tCg

## How Much Freedom Are We Willing to Sacrifice to the Coronavirus?
 - [https://www.youtube.com/watch?v=6r5T7_CaEQI](https://www.youtube.com/watch?v=6r5T7_CaEQI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-10 00:00:00+00:00

Taken from JRE MMA #94 w/Brendan Schaub: https://youtu.be/cF7_AaY9tCg

## Joe Rogan Remembers Visiting Shady Video Stores Back in the Day
 - [https://www.youtube.com/watch?v=Bw5tdphFpfg](https://www.youtube.com/watch?v=Bw5tdphFpfg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-10 00:00:00+00:00

Taken from JRE MMA #94 w/Brendan Schaub: https://youtu.be/cF7_AaY9tCg

## Joe Rogan on Bernie Dropping Out, Coronavirus Effects on 2020 Election
 - [https://www.youtube.com/watch?v=YXl6BOpgh0I](https://www.youtube.com/watch?v=YXl6BOpgh0I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-10 00:00:00+00:00

Taken from JRE MMA Show #94 w/Brendan Schaub: https://youtu.be/cF7_AaY9tCg

## Joe Rogan: Daniel Craig is the Greatest James Bond of All Time!
 - [https://www.youtube.com/watch?v=u4-M0EFMIcU](https://www.youtube.com/watch?v=u4-M0EFMIcU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-10 00:00:00+00:00

Taken from JRE MMA #94 w/Brendan Schaub: https://youtu.be/cF7_AaY9tCg

## Opie & Anthony and Stern Helped Make Podcasts What They Are
 - [https://www.youtube.com/watch?v=HR5Fdju1PYc](https://www.youtube.com/watch?v=HR5Fdju1PYc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-10 00:00:00+00:00

Taken from JRE MMA #94 w/Brendan Schaub: https://youtu.be/cF7_AaY9tCg

## UFC Indefinitely Postponed  - Joe Rogan Reacts
 - [https://www.youtube.com/watch?v=z5oZP53-WKA](https://www.youtube.com/watch?v=z5oZP53-WKA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-10 00:00:00+00:00

Taken from JRE MMA Show #94 w/Brendan Schaub: https://youtu.be/cF7_AaY9t

## Will Harvey Weinstein Go the Way of Jeffrey Epstein?
 - [https://www.youtube.com/watch?v=ib6Hpr79glY](https://www.youtube.com/watch?v=ib6Hpr79glY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-10 00:00:00+00:00

Taken from JRE MMA #94 w/Brendan Schaub: https://youtu.be/cF7_AaY9tCg

## Is Contact Tracing Worth the Loss to Civil Liberties? w/Michael Shermer | Joe Rogan
 - [https://www.youtube.com/watch?v=0a9f9hKSHC4](https://www.youtube.com/watch?v=0a9f9hKSHC4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-09 00:00:00+00:00

Taken from JRE #1456 w/Michael Shermer: https://youtu.be/TOiTI5LrCSA

## Michael Shermer Suggests Possibly Rallying Around Trump During Coronavirus Crisis |  Joe Rogan
 - [https://www.youtube.com/watch?v=bXGZ_wjk_Jc](https://www.youtube.com/watch?v=bXGZ_wjk_Jc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-09 00:00:00+00:00

Taken from JRE #1456 w/Michael Shermer: https://youtu.be/TOiTI5LrCSA

## Michael Shermer: How to Discuss Issues in an Age of Tribal Politics
 - [https://www.youtube.com/watch?v=o2su32xqmFc](https://www.youtube.com/watch?v=o2su32xqmFc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-09 00:00:00+00:00

Taken from JRE #1456 w/Michael Shermer: https://youtu.be/TOiTI5LrCSA

## Michael Shermer: Real Social Change Happens From the Bottom Up
 - [https://www.youtube.com/watch?v=9XHhuBsoEzg](https://www.youtube.com/watch?v=9XHhuBsoEzg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-09 00:00:00+00:00

Taken from JRE #1456 w/Michael Shermer: https://youtu.be/TOiTI5LrCSA

## Michael Shermer: The Problem With Hate Speech Legislation
 - [https://www.youtube.com/watch?v=0C5h_06g9ZQ](https://www.youtube.com/watch?v=0C5h_06g9ZQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-09 00:00:00+00:00

Taken from JRE #1456 w/Michael Shermer: https://youtu.be/TOiTI5LrCSA

## Skeptic Michael Shermer on Epstein, 5G Conspiracies | Joe Rogan
 - [https://www.youtube.com/watch?v=7lTtNxS2X7E](https://www.youtube.com/watch?v=7lTtNxS2X7E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-09 00:00:00+00:00

Taken from JRE #1456 w/Michael Shermer: https://youtu.be/TOiTI5LrCSA

## The Economic Trade-off of Coronavirus w/Michael Shermer | Joe Rogan
 - [https://www.youtube.com/watch?v=jtHnIX52TxI](https://www.youtube.com/watch?v=jtHnIX52TxI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-09 00:00:00+00:00

Taken from JRE #1456 w/Michael Shermer: https://youtu.be/TOiTI5LrCSA

## Why Did Liberals Reverse Their Position on Cultural Appropriation?
 - [https://www.youtube.com/watch?v=8Xdnu4-h03A](https://www.youtube.com/watch?v=8Xdnu4-h03A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-09 00:00:00+00:00

Taken from JRE #1456 w/Michael Shermer: https://youtu.be/TOiTI5LrCSA

