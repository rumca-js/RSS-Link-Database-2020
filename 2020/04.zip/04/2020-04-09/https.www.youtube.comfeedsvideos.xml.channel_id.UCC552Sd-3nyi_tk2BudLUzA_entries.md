# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## Are Young People Safe? | Coronavirus
 - [https://www.youtube.com/watch?v=yWUHQaeTf9U](https://www.youtube.com/watch?v=yWUHQaeTf9U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2020-04-10 00:00:00+00:00

The cases of young people being hospitalized for COVID-19 are increasing, what happened? 
Check out http://KiwiCo.com/AsapSCIENCE and get your first month free! 
Join Our Email List: https://mailchi.mp/072240d817d6/asapscience

Subscribe for more asapscience, and hit that bell :)
Created by: Mitchell Moffit and Gregory Brown

FOLLOW US!
Mitch
Instagram: https://instagram.com/mitchellmoffit
Twitter: https://twitter.com/mitchellmoffit 

Greg
Instagram: https://instagram.com/whalewatchmeplz 
Twitter: https://twitter.com/whalewatchmeplz 

AsapSCIENCE
Instagram: https://instagram.com/asapscience 
Facebook: https://facebook.com/asapscience 
Twitter: https://twitter.com/asapscience
Tumblr: https://asapscience.tumblr.com 

Send us stuff!
ASAPSCIENCE INC.
P.O. Box 93, Toronto P
Toronto, ON, M5S2S6

Further Reading/Sources:

CDC Severe Cases information:
https://www.cdc.gov/mmwr/volumes/69/wr/mm6912e2.htm?s_cid=mm6912e2_w

Up to date numbers from NYC
https://www1.nyc.gov/site/doh/covid/covid-19-data.page#download

Italian Study on Deaths
https://www.epicentro.iss.it/coronavirus/bollettino/Infografica_23marzo%20ENG.pdf

Why do some young people die?
https://www.theguardian.com/world/2020/apr/09/why-do-some-young-people-die-of-coronavirus-covid-19-genes-viral-load

General reading on young people's risk and the virus
https://www.bbc.com/news/health-52003804
https://www.bloomberg.com/news/articles/2020-04-01/coronavirus-in-young-people-ny-patients-skew-younger-some-die

