# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## My Cat Died.
 - [https://www.youtube.com/watch?v=GtHuQItYspI](https://www.youtube.com/watch?v=GtHuQItYspI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-04-10 00:00:00+00:00

My cat Morrissey died. 
I had him for him for 16 years. This is how it has affected me.

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

## The World After Lockdown: A Message Of Hope | Russell Brand Podcast
 - [https://www.youtube.com/watch?v=w0zr_9cFxSU](https://www.youtube.com/watch?v=w0zr_9cFxSU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-04-09 00:00:00+00:00

A clip from the upcoming #UnderTheSkin podcast with Helena Norberg-Hodge. Helena is founder and director of Local Futures, previously known as the International Society for Ecology and Culture.
If you want to listen to the entire podcast you can on Luminary - get it here: http://luminary.link/russell

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

