# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Joey Quinones & Thee Sinseers - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=CfnB7A05zbg](https://www.youtube.com/watch?v=CfnB7A05zbg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-04-10 00:00:00+00:00

http://KEXP.ORG presents Joey Quinones & Thee Sinseers performing live at the La Chapelle by le Studio in Rennes, France, during Trans Musicales 2019. Recorded December 7, 2019.

Songs:
Give It Up You Fool
Voodoo Man
It's Only Love Lost
What's His Name?

Audio Engineer & Mixer: Matt Ogaz
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

Additional support by 
Jean Baptiste Le Clec’h
Jean-Marc Meleard
Jeremy Meleard

Festival Artwork by Brendan Monroe

Special thanks to Gwenola Le Bris at Trans Musicales, Valérian Mercier at La Chapelle by le Studio, and Destination Renne

http://kexp.org
https://www.lestrans.com
https://www.tourisme-rennes.com
https://www.lachapellebylestudio.com

## Joey Quinones & Thee Sinseers - Give It Up You Fool (Live on KEXP)
 - [https://www.youtube.com/watch?v=BDHT7Dk9DTg](https://www.youtube.com/watch?v=BDHT7Dk9DTg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-04-10 00:00:00+00:00

http://KEXP.ORG presents Joey Quinones & Thee Sinseers performing “Give It Up You Fool” live at the La Chapelle by le Studio in Rennes, France, during Trans Musicales 2019. Recorded December 7, 2019.

Audio Engineer & Mixer: Matt Ogaz
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

Additional support by 
Jean Baptiste Le Clec’h
Jean-Marc Meleard
Jeremy Meleard

Festival Artwork by Brendan Monroe

Special thanks to Gwenola Le Bris at Trans Musicales, Valérian Mercier at La Chapelle by le Studio, and Destination Renne

http://kexp.org
https://www.lestrans.com
https://www.tourisme-rennes.com
https://www.lachapellebylestudio.com

## Joey Quinones & Thee Sinseers - It's Only Love Lost (Live on KEXP)
 - [https://www.youtube.com/watch?v=yoFC44PgMlA](https://www.youtube.com/watch?v=yoFC44PgMlA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-04-10 00:00:00+00:00

http://KEXP.ORG presents Joey Quinones & Thee Sinseers performing “It's Only Love Lost” live at the La Chapelle by le Studio in Rennes, France, during Trans Musicales 2019. Recorded December 7, 2019.

Audio Engineer & Mixer: Matt Ogaz
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

Additional support by 
Jean Baptiste Le Clec’h
Jean-Marc Meleard
Jeremy Meleard

Festival Artwork by Brendan Monroe

Special thanks to Gwenola Le Bris at Trans Musicales, Valérian Mercier at La Chapelle by le Studio, and Destination Renne

http://kexp.org
https://www.lestrans.com
https://www.tourisme-rennes.com
https://www.lachapellebylestudio.com

## Joey Quinones & Thee Sinseers - Voodoo Man (Live on KEXP)
 - [https://www.youtube.com/watch?v=McvbMXo8yB8](https://www.youtube.com/watch?v=McvbMXo8yB8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-04-10 00:00:00+00:00

http://KEXP.ORG presents Joey Quinones & Thee Sinseers performing “Voodoo Man” live at the La Chapelle by le Studio in Rennes, France, during Trans Musicales 2019. Recorded December 7, 2019.

Audio Engineer & Mixer: Matt Ogaz
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

Additional support by 
Jean Baptiste Le Clec’h
Jean-Marc Meleard
Jeremy Meleard

Festival Artwork by Brendan Monroe

Special thanks to Gwenola Le Bris at Trans Musicales, Valérian Mercier at La Chapelle by le Studio, and Destination Renne

http://kexp.org
https://www.lestrans.com
https://www.tourisme-rennes.com
https://www.lachapellebylestudio.com

## Joey Quinones & Thee Sinseers - What's His Name? (Live on KEXP)
 - [https://www.youtube.com/watch?v=OMKHVKgVsN4](https://www.youtube.com/watch?v=OMKHVKgVsN4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-04-10 00:00:00+00:00

http://KEXP.ORG presents Joey Quinones & Thee Sinseers performing “What's His Name?” live at the La Chapelle by le Studio in Rennes, France, during Trans Musicales 2019. Recorded December 7, 2019.

Audio Engineer & Mixer: Matt Ogaz
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Scott Holpainen

Additional support by 
Jean Baptiste Le Clec’h
Jean-Marc Meleard
Jeremy Meleard

Festival Artwork by Brendan Monroe

Special thanks to Gwenola Le Bris at Trans Musicales, Valérian Mercier at La Chapelle by le Studio, and Destination Renne

http://kexp.org
https://www.lestrans.com
https://www.tourisme-rennes.com
https://www.lachapellebylestudio.com

