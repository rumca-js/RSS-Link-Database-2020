# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## Explaining the Pandemic to my Past Self
 - [https://www.youtube.com/watch?v=Ms7capx4Cb8](https://www.youtube.com/watch?v=Ms7capx4Cb8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2020-04-09 00:00:00+00:00

What would happen if I tried to explain what's happening now to the January 2020 version of myself?

