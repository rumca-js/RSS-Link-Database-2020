# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Dogma - Movie Review
 - [https://www.youtube.com/watch?v=c7K74RulD0I](https://www.youtube.com/watch?v=c7K74RulD0I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-04-10 00:00:00+00:00

I revisit a Kevin Smith favorite of mine from 1999. Does it hold up? Here's my review for DOGMA!

#Dogma

