# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Gotham High is EXACTLY what the Comic Industry Needs
 - [https://www.youtube.com/watch?v=v-UvZHu3DH0](https://www.youtube.com/watch?v=v-UvZHu3DH0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-04-09 00:00:00+00:00

Ever wondered what it would be like if Batman, Joker and Catwoman were all teenage high school students caught in a love triangle? Well, the release of the new DC graphic novel Gotham High will answer all your questions.

