# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Let's Play God Of War - 2 Year Anniversary
 - [https://www.youtube.com/watch?v=ApJvwpZ_HWs](https://www.youtube.com/watch?v=ApJvwpZ_HWs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2020-04-20 00:00:00+00:00

Happy birthday, God Of War! To celebrate its second anniversary, Persia hunts for Valkyries in the award-winning comeback.

