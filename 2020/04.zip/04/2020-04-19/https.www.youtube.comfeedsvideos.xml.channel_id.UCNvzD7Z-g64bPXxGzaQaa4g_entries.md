# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Best Unlockables You CAN'T PAY TO UNLOCK - Part 2
 - [https://www.youtube.com/watch?v=eLPGTvKxlYg](https://www.youtube.com/watch?v=eLPGTvKxlYg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-04-20 00:00:00+00:00

Unlocking stuff in video games is way more fun when you can't pay for it. Here are some of our favorite things you unlock the old school way.
Subscribe for more: http://youtube.com/gameranxtv

## 10 Scary Games You Should NEVER Play Alone
 - [https://www.youtube.com/watch?v=K1LI9kiIH4g](https://www.youtube.com/watch?v=K1LI9kiIH4g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-04-19 00:00:00+00:00

When games have good tension and jumpscares, sometimes you don't want to play alone. Here are some terrifying examples.
Subscribe for more: http://youtube.com/gameranxtv

