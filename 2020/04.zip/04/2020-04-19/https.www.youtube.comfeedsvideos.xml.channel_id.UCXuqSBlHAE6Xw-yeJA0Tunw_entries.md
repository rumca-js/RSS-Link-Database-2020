# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Ultimate IKEA Gaming Desk
 - [https://www.youtube.com/watch?v=yB_NtELI3uY](https://www.youtube.com/watch?v=yB_NtELI3uY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-04-20 00:00:00+00:00

Big shoutout to MSI for sponsoring this video! 
Buy MSI MEG X570 ACE Motherboard on Amazon: https://geni.us/bNPD5iZ
Buy MSI MEG X570 ACE Motherboard on Newegg: https://geni.us/aAnWc0

Buy MSI Optix MAG272CQR on Amazon: https://geni.us/baTo
Buy MSI Optix MAG272CQR on Newegg: https://geni.us/RYw1
 
Buy MSI Radeon RX 5700 XT MECH OC on Amazon: https://geni.us/9SV0bX
Buy MSI Radeon RX 5700 XT MECH OC on Newegg: https://geni.us/ru3TbX
 
Buy MSI Vigor GK50 Low Profile Keyboard on Amazon: https://geni.us/qvJR
Buy MSI Vigor GK50 Low Profile Keyboard on Newegg: https://geni.us/dUMNj
 
Buy MSI Clutch GM50 Gaming Mouse on Amazon: https://geni.us/6EXlh
Buy MSI Clutch GM50 Gaming Mouse on Newegg: https://geni.us/y0krXg
 
Buy MSI Immerse GH50 Gaming Headset on Amazon: https://geni.us/chP9rU
Buy MSI Immerse GH50 Gaming Headset on Newegg: https://geni.us/5pDsd1

Hole Saw used: https://geni.us/aT10QSE
Cable hole cover: https://geni.us/61Yp

Purchases made through some store links may provide some compensation to Linus Media Group.

Whether its homework or Minecraft this build will have you covered. We took IKEA's Malm desk, paired it with a bunch of MSI goodies, like the Optix MAG272CQR, RX 5700 XT Mech OC, and built sweet stealth gaming desk. 

Discuss on the forum: https://lmg.gg/mhXX8
Links to plans: Coming soon

GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Support a Creator code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Test Benches on Amazon: https://lmg.gg/HOx0z
Our Production Gear: https://lmg.gg/4oPzt
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

## Who is Video Rendering KING? Transcode Server Upgrade!
 - [https://www.youtube.com/watch?v=JwETLRMandY](https://www.youtube.com/watch?v=JwETLRMandY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-04-19 00:00:00+00:00

About a year ago we tried to upgrade our rendering server and failed abysmally. Today, we try again with the help of AMD's Ryzen 3000 CPUs!

Buy Intel Core i9-10980XE:
On Amazon (PAID LINK): https://geni.us/iJVJJc
On Newegg (PAID LINK): https://geni.us/nkIagF

Buy ASUS WS X299 PRO/SE Mobo
On Amazon (PAID LINK): https://geni.us/EVI6R
On Newegg (PAID LINK): https://geni.us/2ETuFI

Buy AMD 3970X
On Amazon (PAID LINK): https://geni.us/VNwP
On Newegg (PAID LINK): https://geni.us/odtc

But ASUS ROG Strix TRX40-E
On Amazon (PAID LINK): https://geni.us/SwcA
On Newegg (PAID LINK): https://geni.us/SIMH6

Buy ZOTAC GeForce GPUs (GTX 1080 Ti)
On Amazon (PAID LINK): https://geni.us/xgMxY
On Newegg (PAID LINK): https://geni.us/3zyyNP5

Buy Corsair SF750 SFX Power Supply:
On Amazon (PAID LINK): https://geni.us/ynXo
On Newegg (PAID LINK): https://geni.us/ry7DV

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1180608-who-is-video-rendering-king-transcode-server-upgrade/

GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Support a Creator code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Test Benches on Amazon: https://lmg.gg/HOx0z
Our Production Gear: https://lmg.gg/4oPzt
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

