# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Commentary with Clinton the cat
 - [https://www.youtube.com/watch?v=W5EDp0JNWP0](https://www.youtube.com/watch?v=W5EDp0JNWP0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-04-20 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
Eli the Computer guy hit 1,000,000 subscribers - go say hi! https://www.youtube.com/user/elithecomputerguy/videos

