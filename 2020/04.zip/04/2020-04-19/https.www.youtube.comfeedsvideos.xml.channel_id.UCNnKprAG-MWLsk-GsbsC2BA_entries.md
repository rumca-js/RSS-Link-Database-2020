# Source:FlashGitz, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA, language:en-US

## Animal Crossing: Tiger King
 - [https://www.youtube.com/watch?v=Ohg8bsJwO7A](https://www.youtube.com/watch?v=Ohg8bsJwO7A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA
 - date published: 2020-04-19 00:00:00+00:00

Install Raid for Free ✅ IOS: https://clcr.me/XdxwzN ✅ ANDROID: https://clcr.me/BetfR9 ✅ PC: https://clcr.me/2tleab and get a special starter pack 💥Available only for the next 30 days Disclaimer: GamerBread is a parody, and not a real product available for purchase.

Flashgitz presents "Tiger Crossing" a Tiger King / Animal Crossing parody. This cartoon is based off of the Netflix series "Tiger King" and the Nintendo Switch video game "Animal Crossing" featuring Joe Exotic, Isabelle, and Bianca.

Merch ►
https://sharkrobot.com/flashgitz

Patreon ►
https://www.patreon.com/flashgitz

Special thanks to our Patron Producers, really going the extra mile to make this possible:

Bradoess
Ethan Hunt
David Murphy
Andrew Palmer
Albert Hutchins
Adam Knopow
Morgan Collins

Thank you gents, seriously.

Voice Over ►
Meatcanyon (Joe Exotic)

Additional Animation ► 
YasHGG
Lewis Bown

Backgrounds ► 
Greg Bartlett

Sound ► 
Justin Greger

Thumbnail ► 
Josh Floyd

Instagram ►
https://www.instagram.com/flashgitz/

Twitter ►
https://www.twitter.com/flashgitzanims
https://www.twitter.com/flashgitztom
https://www.twitter.com/flashgitzdon

Discord ►
https://discord.gg/b5ekXbK

