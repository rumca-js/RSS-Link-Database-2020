# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week #12: Twój oddział banku Google. iPhone SE, dron DJI, Lime kupuje Boosted, rakieta Space X
 - [https://www.youtube.com/watch?v=HlT9TX-1sI0](https://www.youtube.com/watch?v=HlT9TX-1sI0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-04-19 00:00:00+00:00

Tak będzie wyglądać przyszłość bankowości. W Łomiankach. Link do czapki:
https://znosne.pl

Źródła:
Nowy iPhone SE: https://apple.co/2ROXdLE
Dotrze do klientów z opóźnieniem: https://bit.ly/2RPfYig
Dom dla kota z pudła po telewizorze: https://bit.ly/2ViJ8bK
W kwarantannie jesteśmy bardziej seksi: https://bit.ly/3bnhjoj
Online town do robienia online imprez: https://bit.ly/2RPBUdf
Video chatbot: https://bit.ly/2wPDvs0
Post na Tech Ekipie: https://bit.ly/3amLevw
Zapowiedź drona od DJI: https://bit.ly/3csxctC
Lime kupuje Boosted: https://bit.ly/3amJG4H
Karta google'a: https://tcrn.ch/2xxaVw7
Siatka babci na kickstarterze: https://bit.ly/2Kj8vni
Rakieta Space X z załogą leci w kosmos: https://cnet.co/3cw7Lr0
Maszty zniszczone w UK: https://bit.ly/34OL8f5

