# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Michael Kiwanuka - Full solo acoustic session (Live at The Current, 2017)
 - [https://www.youtube.com/watch?v=TRh_-tKHe3o](https://www.youtube.com/watch?v=TRh_-tKHe3o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-20 00:00:00+00:00

In these performances, recorded in 2017, #MichaelKiwanuka sounds lonely, a quiet #singersongwriter who might just be playing in his bedroom for himself. Back-up vocalists join him during the studio version of "Cold Little Heart," but here, he's on his own. He normally uses electric guitar in "The Final Frame," but as he sways through it at The Current, it's all #acoustic. His album is "dense and full," he says, and he's right -- but these recordings strip the songs down to their bones.

SONGS
00:00 Love & Hate
04:41 The Final Frame
08:45 Cold Little Heart

MORE FROM THIS SESSION
Cold Little Heart https://www.youtube.com/watch?v=kIBtqXj3Ftk
Love & Hate https://www.youtube.com/watch?v=Wfotg_q5Bkc

All songs from Michael Kiwanuka's 2016 release, Love & Hate, available via Interscope Records.

CREDITS
Production: Derrick Stevens
Audio: Michael DeMark and Matt Lentz
Video: by Nate Ryan

SUPPORT THE CURRENT
https://support.mpr.org/current-web?var=youtube-description

#michaelkiwanuka

## One World concert raises $128 million to fight COVID-19 (The Current Music News)
 - [https://www.youtube.com/watch?v=uvote6prxfI](https://www.youtube.com/watch?v=uvote6prxfI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-20 00:00:00+00:00

April 20, 2020: An all-star, live-streamed concert called 'One World: Together at Home' raised $128 million to fight the coronavirus. The virus continues to devastate the music world, with bassist Matthew Seligman among those lost to the pandemic. Willie Nelson is planning his own streaming event, and it is keyed to one of his favorite days, April 20. Also today: updates on Live Nation refunds and a look at Charli XCX's new crowdsourced music video.

