# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## Why I DON'T Use EMACS!
 - [https://www.youtube.com/watch?v=1mr3issv79s](https://www.youtube.com/watch?v=1mr3issv79s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-04-20 00:00:00+00:00

What I'm actually referring to Emacs is, in fact, GNU Emacs. Why don't I use it? 👉 Let's find out!

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE NOW: https://lukesmith.xyz/donate 💰😎👌💯

## What to do with $1,200 free dollars?
 - [https://www.youtube.com/watch?v=vkRLxK5nAdo](https://www.youtube.com/watch?v=vkRLxK5nAdo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2020-04-19 00:00:00+00:00

"Noooo!!! You can't use your money to actually improve your life over the long-term by increasing the viability of your survivalist homestead! You have to stimulate the economerino!!!! Don't you care about increasing the effective demand of consoooomer products to make the line go up?"

WEBSITE: https://lukesmith.xyz 🌐❓🔎
DONATE NOW: https://lukesmith.xyz/donate 💰😎👌💯

