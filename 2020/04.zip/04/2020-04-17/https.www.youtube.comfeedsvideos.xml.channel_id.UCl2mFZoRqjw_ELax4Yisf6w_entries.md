# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Quality content
 - [https://www.youtube.com/watch?v=2ogtNgOUQYk](https://www.youtube.com/watch?v=2ogtNgOUQYk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-04-18 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
I sound shrill, this is why I usually use that pocket shotgun microphone with my phone, because the microphone built into the LG G8 is unusably shrill garbage. However, my cat is adorable. :)

## Thoughts
 - [https://www.youtube.com/watch?v=Q3M50R6CbOw](https://www.youtube.com/watch?v=Q3M50R6CbOw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-04-18 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
it's a stream

## Hot air station shootout: Atten ST-862D vs. Quick 861DW
 - [https://www.youtube.com/watch?v=wYCmU6jMLo8](https://www.youtube.com/watch?v=wYCmU6jMLo8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2020-04-17 00:00:00+00:00

https://tinyurl.com/rossmatrix
Let's get Right to Repair passed! https://gofund.me/1cba2545
How does the Quick 861DW compare to the Atten 862D? Watch and find out. 



Don't delay, pre-order today! These will start shipping in JULY:


Yes, before you click the link or scroll, just to make sure you heard that right: JULY 2020!


https://store.rossmanngroup.com/index.php/atten-862.html

