# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## iPhone SE (2020) Honest Thoughts...
 - [https://www.youtube.com/watch?v=UK8HH3_q4yI](https://www.youtube.com/watch?v=UK8HH3_q4yI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-04-17 00:00:00+00:00

iPhone SE costs $399 and just went on sale. I have many thoughts.

Latest episode of the WVFRM Podcast: http://bit.ly/WaveformMKBHD

MKBHD Merch: http://shop.MKBHD.com

Video Gear I use: http://kit.co/MKBHD/video-gear#recom...
Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: http://youtube.com/20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

