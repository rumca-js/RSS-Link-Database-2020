# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## God, Liberty, And Gold: The Ron Paul Interview
 - [https://www.youtube.com/watch?v=hXcMmVORGQo](https://www.youtube.com/watch?v=hXcMmVORGQo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-04-17 00:00:00+00:00

Kyle and Ethan talk to former congressman Dr. Ron Paul. Dr. Paul advocated for non-interventionism, sound money, and individual liberty throughout his career and became the figurehead of a libertarian movement through his presidential campaigns. He is the author of several books including  End The Fed and  Swords Into Plowshares.  Kyle and Ethan ask Dr. Paul about his faith, attempt to get libertarian answers on various modern problems, and try to get him to spill on how much gold he has under his mattress. We find out if Ethan accepts Ron Paul into his heart to become a full-blown libertarian in the subscriber portion. 

 You can see more Ron Paul on his Liberty Report.

 Topics Discussed

   How Ron’s faith and politics intersect and on setting an example

   Non-interventionism; blaming America, blowback, &amp; war

   Ron Paul’s foundations for his pro-life views

   On refusing to endorse McCain or Romney

   What is sound money and what is wrong with the dollar? The gold standard

   The Boom-Bust cycle. Ron Paul thinks the virus is being blamed instead of where the real problem lies at the Federal Reserve

   Subscriber Portion (Begins At 00:43:45)

   Coronavirus- is the government cure worse than the disease? Is it a  HOAX? 

   Is there hope for the future?

   Dan tries to explain inflation

   Kyle and Ethan discuss non-interventionism

   Does Ethan accept Ron Paul into his heart?

   The full interview is for Babylon Bee subscribers, so...

 Become a paid subscriber at https://babylonbee.com/plans

