# Source:Hugh Jeffreys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA, language:en-US

## Restoring The First iPhone  - Retro Repair
 - [https://www.youtube.com/watch?v=KT73jaaGBkY](https://www.youtube.com/watch?v=KT73jaaGBkY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA
 - date published: 2020-04-18 00:00:00+00:00

Designed without repair in mind, this retro iPhone is badly damaged and in need of repair.
--------------------------------------Socials-------------------------------------
Website: https://www.hughjeffreys.com 
Twitter: https://twitter.com/hughjeffreys
Instagram: http://instagram.com/hughjeffreys
---------------------------------------Links---------------------------------------
Get parts, tools, and thousands of free repair guides from iFixit at: 
    https://iFixit.com/hughjeffreys
Australia Store: https://ifix.gd/2FPxhKy
(DISCLAIMER: This description contains affiliate links, which means that if you click on one of the product links, l will receive a small commission.)

