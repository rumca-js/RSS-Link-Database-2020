# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Are You Creatively Constipated or Constantly Creating? - Authentic JP
 - [https://www.youtube.com/watch?v=s5WfZeIQmVE](https://www.youtube.com/watch?v=s5WfZeIQmVE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-04-18 00:00:00+00:00

Would you like to trade in your boredom, frustration, and stress into joy in your heart and curiosity in your mind? Constant creativity is your answer.
#AuthenticJP #SincereSaturday

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Click Here to join my PATREON - https://awakenwithjp.com/patron
---- Want to be the first to see my new videos with 24 hour early access? Just click this to receive the alerts! - https://m.me/awakenwithjp?ref=w6836464

Listen and Subscribe to my NEW Podcast here: 
https://podcasts.apple.com/ca/podcast/awaken-with-jp-sears-show/id1436938686
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

-Order my new book at: http://HowToBeUltraSpiritual.com/

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

