# Source:Luetin09, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC8RfCCzWsMgNspTI-GTFenQ, language:en-US

## 40K - NECRONS - ILLUMINOR SZERAS | PARIAHS AND THEIR RETURN? - WARHAMMER 40,000 Lore/History
 - [https://www.youtube.com/watch?v=d3nSQbxye3Y](https://www.youtube.com/watch?v=d3nSQbxye3Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC8RfCCzWsMgNspTI-GTFenQ
 - date published: 2020-04-18 00:00:00+00:00

► Subscribe: http://goo.gl/oeZMBS 
► Patreon: https://www.patreon.com/Luetin 
► Siege Studios: https://siegestudios.co.uk/
► Goblin Gaming: (Get - 20% off 40K Products) https://tinyurl.com/6vwcayvj
► Premium Storage Solutions: https://www.crystal-fortress.com/
► Twitch: http://www.twitch.tv/Luetin
► Twitter: http://twitter.com/luetin09

► BGM Credits:
► Kevin MacLeod (Royalty Free Music): http://incompetech.com/music/
► https://epidemicsound.com

This video is an opinion editorial commentary.
Copyright Disclaimer Under Section 107 of the Copyright Act 1976, allowance is made for fair use purposes such as criticism, commentary, parody, news reporting, teaching, scholarship, and research.

All works used in this video (Images, audio etc) belong to their respective authors
(This does not include the audio commentary or licensed BGM).

Games workshop, Warhammer 40,000, Warhammer, 40k, Space Marine Etc are all Trademarks of Games Workshop Ltd. Games Workshop does not endorse or support the 'Lore' videos. All views and opinions expressed in this video belong to Luetin09 and in no way reflect the views or opinions of Games Workshop Ltd.

