# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## He Lost $50,000 To a Thailand TEFL Scam... DON'T DO THIS!
 - [https://www.youtube.com/watch?v=SfznoL3IPS8](https://www.youtube.com/watch?v=SfznoL3IPS8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-04-18 00:00:00+00:00

this story is insane. $50,000 was the price of Levi choosing to go with a TEFL "franchise" opportunity with Jimmy Crangle. It wasn't what he was promised.

Note: Teaching english as a foreign language isn't always a scam, but this is a serious reminder that extreme due diligence is required. Scammers are out there, ready to take your money.

