# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Last of Us Part 2 - BIGGEST CHANGES
 - [https://www.youtube.com/watch?v=OPsnlNuRIa0](https://www.youtube.com/watch?v=OPsnlNuRIa0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-04-18 00:00:00+00:00

The Last of Us: Part II is still likely months away, but we wanted to talk about some stuff we've seen in gameplay videos.
Subscribe for more: http://youtube.com/gameranxtv

## Fallout 76 Wastelanders - Before You Buy
 - [https://www.youtube.com/watch?v=lntMeTLEaPE](https://www.youtube.com/watch?v=lntMeTLEaPE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-04-17 00:00:00+00:00

Fallout 76 Wastelanders (PC, PS4, Xbox One) is a big update to the initially disappointing online Fallout game. Does this update save the game? Let's talk.
Subscribe for more: http://youtube.com/gameranxtv ▼▼

Our friend Jimmy: https://www.youtube.com/watch?v=e14-bUi8VhI

Watch more 'Before You Buy': https://bit.ly/2kfdxI6

## GTA 6 TO BE RELEASED IN PARTS? PS5 SHORTAGES EXPECTED, & MORE
 - [https://www.youtube.com/watch?v=Lrc8WhK8NOU](https://www.youtube.com/watch?v=Lrc8WhK8NOU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-04-17 00:00:00+00:00

Thanks to ExpressVPN for sponsoring this video. Go to https://expressvpn.com/gameranx to take back your Internet privacy TODAY and find out how you can get 3 months free.

We finally hear something on the future of Grand Theft Auto, PS5 faces price issues, Crysis returns, Cyberpunk 2077 gets a cool custom console, and more!
Subscribe for more: http://youtube.com/gameranxtv 

*Jakes twitter: https://twitter.com/jakebaldino 
*Instagram: https://goo.gl/HH6mTW 

 discord.gg/gameranx 

 Weekly giveaway link: https://goo.gl/forms/a7zCtr1HuTkzWuOo2 



 ~~~~STORIES~~~~


GTA 6?
https://kotaku.com/18-months-after-red-dead-redemption-2-rockstar-has-mad-1842880524
Crysis
https://youtu.be/ZqBP3kXi9jM

PS5 scarcity
https://www.polygon.com/2020/4/16/21223516/ps5-launch-numbers-price-availability-playstation-5-sony

Cyberpunk
https://www.gamesradar.com/xbox-could-be-teasing-a-special-edition-cyberpunk-2077-console/

Spongebob
https://youtu.be/ITBa5oTzxNg

Master Chief Pizza
https://www.youtube.com/watch?time_continue=1&v=AIMGJL2yCUo&feature=emb_logo

More Dark Pictures Anthology
https://www.youtube.com/watch?v=jsb0suybJQs&feature=emb_title

RE4 remake rumors:
https://www.pcgamer.com/rumor-a-resident-evil-4-remake-is-in-development/

Minecraft ray tracing: https://youtu.be/yq6lecRKyjU

Jeremy Jahns' review:
https://youtu.be/S2YLlwoT6BM

Free stuff:
Mike Bithell audiobook adventure:
https://www.pocketgamer.biz/news/73135/mike-bithell-launches-a-six-part-episodic-audiobook-about-space/

Just Cause 4 free on Epic
https://www.windowscentral.com/grab-just-cause-4-absolutely-free-right-now-epic-games-store

Assassin's Creed free
https://www.eurogamer.net/articles/2020-04-15-assassins-creed-2-is-currently-free-on-pc-until-friday

Free playstation games https://blog.us.playstation.com/2020/04/14/announcing-the-play-at-home-initiative/


Xcom Chimera Squad
https://youtu.be/39fhpegVBQQ

ESRB loot box warning
https://www.pcgamer.com/esrb-adds-a-new-warning-label-for-loot-boxes/


No gamescom
https://www.techradar.com/news/gamescom-2020-in-doubt-as-germany-extends-ban-on-large-gatherings

