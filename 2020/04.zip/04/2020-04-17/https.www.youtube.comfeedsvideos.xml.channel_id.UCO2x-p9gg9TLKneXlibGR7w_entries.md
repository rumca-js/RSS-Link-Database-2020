# Source:Snazzy Labs, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w, language:en-US

## What’s on My Tech I Use Everyday
 - [https://www.youtube.com/watch?v=Tdkw5mNfCrw](https://www.youtube.com/watch?v=Tdkw5mNfCrw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w
 - date published: 2020-04-17 00:00:00+00:00

Snazzy Labs host Quinn Nelson shows you what tech he uses on the daily and what’s on his phone.

Spyderco Ladybug - https://amzn.to/34MlAil
Secrid Wallet - https://amzn.to/3ev3UfW
iPhone 11 Pro - http://apple.com/iphone-11-pro
Samsung Galaxy Z Flip - https://amzn.to/2Vi6aj2
WNDRD PRVKE - https://amzn.to/2xvrjx8
Nintendo Switch Lite - https://amzn.to/2RL5MaA
Kobo Forma - https://amzn.to/2XLCbS6
Fujifilm X-T30 - https://amzn.to/2XIL6ni
Fujinon XF 35mm f/2 - https://amzn.to/2Kg7IUa
iPad Pro - https://amzn.to/2XF1rcK

Subscribe to my podcast Flashback! - http://relay.fm/flashback
Follow me on Twitter - http://twitter.com/snazzyq
Follow me on Instagram - http://instagram.com/snazzyq

Snazzy Labs host Quinn Nelson takes a spin on the classic “What’s on my phone” video and takes it a bit further by discussing what tech he uses on the daily and weekly amongst his hundreds of tech products. We talk about the Kobo Forma—a high-end Kindle Oasis killer as well as why I use the Nintendo Switch Lite instead of the full-size Joy-con sporting Nintendo Switch. This isn’t your average EDC.

