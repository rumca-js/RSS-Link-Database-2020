## Heilung Norupo [Official Music Video]
 - [https://www.youtube.com/watch?v=64CACoHNBEI](https://www.youtube.com/watch?v=64CACoHNBEI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3Jvz7FpBsY73_wEjFV67wQ
 - date published: 2020-04-17 00:00:00+00:00

Heilung is Amplified History from early medieval northern Europe and should not be mistaken for a modern political or religious statement of any kind. 

Remember, that we all are brothers
All people, beasts, trees and stone and wind
We all descend from the one great being
That was always there
Before people lived and named it
Before the first seed sprouted

https://www.facebook.com/amplifiedhistory

Credits:

Heilung:
Christopher Juul
Kai Uwe Faust
Maria Franz

Location: 
Les Menhirs de Monteneuf - France

Film crew:
Director of Photography: Roderik Patijn // instagram: @roderikpatijn
Aerial Cinematography: Maarten Slooves // instagram: @maartenfilms
Gaffer: Ryan Schaminee // instagram: @ryanschaminee
Best boy: Dirk Zijlstra // instagram: @dirk_zijlstra

Stylist, make up and set coordinator:
Annicke Shireen // Instagram: @annickeshireen

Catering crew:
David Thiérrée
Virginie Ropars
Rachel Daucé

Edit, Color, Audio, VFX:
Christopher Juul

Visual Artwork:
Kai Uwe Faust

Producer:
Maria Franz

Supported by:
Season of Mist and SCPP

Our heartfelt gratitude to the helpers on this side and the other side.

