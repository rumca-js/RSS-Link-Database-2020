# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Midnight Oil (Teenage Kicks from The Current)
 - [https://www.youtube.com/watch?v=fUQugcy0deg](https://www.youtube.com/watch?v=fUQugcy0deg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-18 00:00:00+00:00

Host Jim McGuinn talks about Australian band Midnight Oil, and its extraordinary frontman Peter Garrett, who has enjoyed a career as a musician, politician and environmentalist. 
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Sudan Archives - Did You Know (Live at The Current)
 - [https://www.youtube.com/watch?v=UpXtospJShw](https://www.youtube.com/watch?v=UpXtospJShw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-18 00:00:00+00:00

Throughout her set in The Current studio, Sudan Archives consistently cooked up a savory roux of genres: folk, ambient, hip-hop, classical, and contemporary R&B. It is the contrasting mixture of cultures that defines her sound.

Starting off her set with "Did You Know," the opener on her latest Stones Throw LP, Athena, she explained that she got into the violin when she saw folk fiddlers perform at her elementary school. As a fourth-grader, she was immediately captivated and began learning what she said were "Irish jigs." This opened the door for her own musical ethnography. She soon learned about Sudanese, Czech, and Irish fiddlers. This was in part inspired by eclectic African music pioneer Francis Bebes, who also advocated for an internationalist perspective on music.

MORE FROM THIS SESSION
Nont for Sale https://youtu.be/47YlI7LtpCo
Pelicans in the Summer https://youtu.be/NQ-96t-1xt4

CREDITS
Video: Nate Ryan
Audio: Michael DeMark
Production: Derrick Stevens

#Electro #RNB #Violin

## Event companies pivot from festival stages to virus-testing tents (The Current Music News)
 - [https://www.youtube.com/watch?v=NiP8dGcD364](https://www.youtube.com/watch?v=NiP8dGcD364)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-17 00:00:00+00:00

April 17, 2020: With music festivals called off, some live event companies are putting their skills to work building hospital extensions and virus-testing tents. Also in the news today: AEG opens a ticket refund window, CHVRCHES score a sweet Netflix deal, Fiona Apple's new album released to acclaim, yet another (!) new Bob Dylan song, and Beyoncé sings 'When You Wish Upon a Star.'
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

