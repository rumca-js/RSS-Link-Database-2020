# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Kaśka Sochacka - koncert (MUZO.FM)
 - [https://www.youtube.com/watch?v=r9oARuL8lv0](https://www.youtube.com/watch?v=r9oARuL8lv0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-04-18 00:00:00+00:00

Kaśka Sochacka na żywo w MUZO.FM. Artystka zagrała w naszym studiu specjalne wersje kawałków: Mróz, Trochę tu pusto i Zachody. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Kaśka Schacka: http://www.facebook.com/sochacka.kaska
Instagram Kaśka Sochacka: http://www.instagram.com/sochacka_kaska
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm 

#popolsku

