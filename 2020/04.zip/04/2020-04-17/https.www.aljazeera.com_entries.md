## Trump, aides flirt with China lab coronavirus conspiracy theory | Coronavirus pandemic News | Al Jazeera
 - [https://www.aljazeera.com/news/2020/4/17/trump-aides-flirt-with-china-lab-coronavirus-conspiracy-theory](https://www.aljazeera.com/news/2020/4/17/trump-aides-flirt-with-china-lab-coronavirus-conspiracy-theory)
 - RSS feed: https://www.aljazeera.com
 - date published: 2020-04-17 14:25:08+00:00

Trump, aides flirt with China lab coronavirus conspiracy theory | Coronavirus pandemic News | Al Jazeera

