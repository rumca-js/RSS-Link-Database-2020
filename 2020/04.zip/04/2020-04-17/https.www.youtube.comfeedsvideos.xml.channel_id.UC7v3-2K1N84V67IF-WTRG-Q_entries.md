# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Final Fantasy VII Remake - Game Review
 - [https://www.youtube.com/watch?v=S2YLlwoT6BM](https://www.youtube.com/watch?v=S2YLlwoT6BM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-04-17 00:00:00+00:00

Final Fantasy VII released in 1997, and instantly became one of the most legendary RPGs in the hearts & minds of gamers everywhere. Now, in 2020, Square Enix releases a remake telling the story of the Midgar segment of FF7. Here's my review of the FINAL FANTASY VII REMAKE!

#FinalFantasy7 #FinalFantasy7Remake

