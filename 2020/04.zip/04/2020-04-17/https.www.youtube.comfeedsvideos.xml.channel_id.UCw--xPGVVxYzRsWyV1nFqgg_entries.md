# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Ghost Story/Cold Days/Skin Game Discussion!
 - [https://www.youtube.com/watch?v=FV-KgE1z3mY](https://www.youtube.com/watch?v=FV-KgE1z3mY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-04-18 00:00:00+00:00

My review/discussion of Dresden Files Ghost Stories, Cold Days, and Skin Game! 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## RHYTHM OF WAR COVER REVEAL! 🛡️ GRRM Blog Post. 🖋️New Epic Fantasy Series!📚 - FANTASY NEWS
 - [https://www.youtube.com/watch?v=NIit4tQ9trk](https://www.youtube.com/watch?v=NIit4tQ9trk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-04-17 00:00:00+00:00

I am rapidly feeling worse so all videos this weekend will be prerecorded ones I have had on the back burner. Meanwhile, enjoy the Fantasy News! 
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

NEWS: 

Rhythm of War Caver: https://twitter.com/BrandSanderson/status/1250846461698269184/photo/1

GRRM BlogPost: https://georgerrmartin.com/notablog/2020/04/14/this-that-and-tother-thing-3/

Crysis Remastered: https://twitter.com/Nibellion/status/1250734400830148608

Myst Show: https://collider.com/myst-tv-show-writer-ashley-edward-miller/

Comic Book Relief: https://www.nytimes.com/2020/04/14/arts/comic-book-auction-virus.html

Justice League Dark: https://variety.com/2020/tv/news/justice-league-dark-series-the-shining-series-hbo-max-jj-abrams-1234582489/amp/?__twitter_impression=true

New World Gameplay: https://www.dualshockers.com/new-world-gameplay-combat-details/

The Second Bell: https://www.tor.com/2020/04/14/slavic-inspired-fantasy-from-the-viewpoint-of-the-striga-angry-robot-books-acquires-debut-from-author-gabriela-houston/

Disney Gallery: The Mandalorian: https://www.tor.com/2020/04/15/star-wars-the-mandalorian-disney-plus-gallery-behind-the-scenes-series/

New Daniel Abraham epic fantasy: https://thewertzone.blogspot.com/2020/04/new-daniel-abraham-epic-fantasy-novel.html

