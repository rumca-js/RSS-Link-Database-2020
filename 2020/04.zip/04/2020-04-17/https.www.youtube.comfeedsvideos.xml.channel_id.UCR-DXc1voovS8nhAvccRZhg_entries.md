# Source:Jeff Gerling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg, language:en-US

## I will donate $1 per like to the Drupal Association #DrupalCares
 - [https://www.youtube.com/watch?v=fdk7zUwDQdM](https://www.youtube.com/watch?v=fdk7zUwDQdM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg
 - date published: 2020-04-17 00:00:00+00:00

Please like this video; for every like (up to 1,000) I will download $1 to the Drupal Association through my service Hosted Apache Solr. And that $1 will be matched by Dries and Vanessa Buytaert, in addition to a coalition of Drupal companies, meaning every person who likes this video donates $3!

#drupal #opensource #drupalcares

You can also directly support the Drupal Association: https://www.drupal.org/association/donate

