# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Companies Are Microchipping Their Employees: Should We Be Worried?
 - [https://www.youtube.com/watch?v=3YrIqEyBVH0](https://www.youtube.com/watch?v=3YrIqEyBVH0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-17 00:00:00+00:00

Taken from Donnell Rawlings #1460: https://youtu.be/IXFlwSr5u_k

## Donnell Rawlings on His Ongoing War With Charlemagne Tha God
 - [https://www.youtube.com/watch?v=j5fKXpnVM20](https://www.youtube.com/watch?v=j5fKXpnVM20)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-17 00:00:00+00:00

Taken from Donnell Rawlings #1460: https://youtu.be/IXFlwSr5u_k

## Donnell Rawlings: CNN is Like a Nagging Girlfriend!
 - [https://www.youtube.com/watch?v=F-t0kdPzf8Y](https://www.youtube.com/watch?v=F-t0kdPzf8Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-17 00:00:00+00:00

Taken from Donnell Rawlings #1460: https://youtu.be/IXFlwSr5u_k

## Joe Rogan Offers a Powerful Argument for a Humane Healthcare System
 - [https://www.youtube.com/watch?v=D50DMzBSX7Q](https://www.youtube.com/watch?v=D50DMzBSX7Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-17 00:00:00+00:00

Taken from Donnell Rawlings #1460: https://youtu.be/IXFlwSr5u_k

## Joe Rogan Reflects on Herschel Walker's MMA Career
 - [https://www.youtube.com/watch?v=V1sjHb3GkLQ](https://www.youtube.com/watch?v=V1sjHb3GkLQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-17 00:00:00+00:00

Taken from #1460 w/Donnell Rawlings:
https://youtu.be/IXFlwSr5u_k

## Joe Rogan Talks Hockey Fights, Real Life Happy Gilmore Drive
 - [https://www.youtube.com/watch?v=3BSl8qp0AMI](https://www.youtube.com/watch?v=3BSl8qp0AMI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-17 00:00:00+00:00

Taken from #1460 w/Donnell Rawlings:
https://youtu.be/IXFlwSr5u_k

## The Racial Divide on Car Air Fresheners w/Donnell Rawlings | Joe Rogan
 - [https://www.youtube.com/watch?v=5xbr32HYkt4](https://www.youtube.com/watch?v=5xbr32HYkt4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-17 00:00:00+00:00

Taken from #1460 w/Donnell Rawlings:
https://youtu.be/IXFlwSr5u_k

