# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## 2SID music: PCH times three (SIDFX 8580 stereo bx_🎧)
 - [https://www.youtube.com/watch?v=NgqKplD42Ds](https://www.youtube.com/watch?v=NgqKplD42Ds)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-04-18 00:00:00+00:00

3 tracks from PCH/Unreal (Petr Chlud). Headphones recommended.

Jumplist:
00:00 Get Up and Jump (10th at Revision 2018), art "Mythus The Warrior" by Mythus (6th at Fjälldata 2020)
02:04 Just One Life (1st at Revision 2017), art "I Will Show That Stupid Bunny" by redcrab (1st at Datastorm 2013)
05:06 Hard(Re)Start (1st at Revision 2019), art "Steampunk Evening" (2012) by redcrab

Made using real C64 audio in SIDFX true stereo config (unique audio data output for each SID chip):

Left channel: CSG 6582A 2792 25/Philippines NM235N18 1200T
Right channel: CSG 8580R5 0590 25/Hong Kong HH032232 HC-30

Project SIDFX:
http://www.sidfx.dk/

