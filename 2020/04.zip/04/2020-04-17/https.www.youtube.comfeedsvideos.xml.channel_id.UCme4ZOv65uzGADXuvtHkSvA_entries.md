# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Karaluchy pod poduchy [#04] Kiedy kończy się noc?
 - [https://www.youtube.com/watch?v=eH8mWQJm0Vs](https://www.youtube.com/watch?v=eH8mWQJm0Vs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-18 00:00:00+00:00

@langustanapalmie @dominikanie.pl #dobranocka #karaluchypodpoduchy #zostanwdomu ________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Codzienne wieczorne spotkania z dobranckami i kompletą. 

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Ksiądz gra w grę? Uncharted 4 [#01] Będzie nowa seria?
 - [https://www.youtube.com/watch?v=EyP1XHrGOKI](https://www.youtube.com/watch?v=EyP1XHrGOKI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-18 00:00:00+00:00

@langustanapalmie #bedegralwgre #zostanwdomu
________________________________________
Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Miniaturkę stworzył dla nas: Sebastian Gwóźdź. 

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Miriam [#32] Wieża z kości słoniowej
 - [https://www.youtube.com/watch?v=pXoNNghecrw](https://www.youtube.com/watch?v=pXoNNghecrw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-18 00:00:00+00:00

#LitaniaLoretańska
Zapraszamy na  kontynuację serii o Miriam, czyli komentarz do Litanii Loretańskiej do Najświętszej Maryi Panny.

Kyrie, elejson. 
Chryste, elejson. 
Kyrie, elejson.
Chryste, usłysz nas. 
Chryste, wysłuchaj nas.
 
Ojcze z nieba, Boże, zmiłuj się nad nami.
Synu, Odkupicielu świata, Boże, zmiłuj się nad nami.
Duchu Święty, Boże, zmiłuj się nad nami.
Święta Trójco, Jedyny Boże, zmiłuj się nad nami.
 
Święta Maryjo, módl się za nami.
Święta Boża Rodzicielko, módl się za nami.
Święta Panno nad pannami, módl się za nami.
Matko Chrystusowa, módl się za nami.
Matko Kościoła, módl się za nami.
Matko łaski Bożej, módl się za nami.
Matko Miłosierdzia, módl się za nami.
Matko nieskalana, módl się za nami.
Matko najczystsza, módl się za nami.
Matko dziewicza, módl się za nami.
Matko nienaruszona, módl się za nami.
Matko najmilsza, módl się za nami.
Matko przedziwna, módl się za nami.
Matko dobrej rady, módl się za nami.
Matko Stworzyciela, módl się za nami.
Matko Zbawiciela, módl się za nami.
Panno roztropna, módl się za nami.
Panno czcigodna, módl się za nami.
Panno wsławiona, módl się za nami.
Panno można, módl się za nami.
Panno łaskawa, módl się za nami.
Panno wierna, módl się za nami.
Zwierciadło sprawiedliwości, módl się za nami.
Stolico mądrości, módl się za nami.
Przyczyno naszej radości, módl się za nami.
Przybytku Ducha Świętego, módl się za nami.
Przybytku chwalebny, módl się za nami.
Przybytku sławny pobożności, módl się za nami.
Różo duchowna, módl się za nami.
Wieżo Dawidowa, módl się za nami.
Wieżo z kości słoniowej, módl się za nami.
Domie złoty, módl się za nami.
Arko przymierza, módl się za nami.
Bramo niebieska, módl się za nami.
Gwiazdo zaranna, módl się za nami.
Uzdrowienie chorych, módl się za nami.
Ucieczko grzesznych, módl się za nami.
Pocieszycielko strapionych, módl się za nami.
Wspomożenie wiernych, módl się za nami.
Królowo Aniołów, módl się za nami.
Królowo Patriarchów, módl się za nami.
Królowo Proroków, módl się za nami.
Królowo Apostołów, módl się za nami.
Królowo Męczenników, módl się za nami.
Królowo Wyznawców, módl się za nami.
Królowo Dziewic, módl się za nami.
Królowo wszystkich Świętych, módl się za nami.
Królowo bez zmazy pierworodnej poczęta, módl się za nami.
Królowo wniebowzięta, módl się za nami.
Królowo różańca świętego, módl się za nami.
Królowo rodzin, módl się za nami.
Królowo pokoju, módl się za nami.
Królowo Polski, módl się za nami.
 
Baranku Boży, który gładzisz grzechy świata, przepuść nam Panie.
Baranku Boży, który gładzisz grzechy świata, wysłuchaj nas Panie
Baranku Boży, który gładzisz grzechy świata, zmiłuj się nad nami.

K. Módl się za nami, Święta Boża Rodzicielko.
W. Abyśmy się stali godnymi obietnic Chrystusowych.

Módlmy się. Panie, nasz Boże, daj nam, sługom swoim, cieszyć się trwałym zdrowiem duszy i ciała, i za wstawiennictwem Najświętszej Maryi, zawsze Dziewicy,  uwolnij nas od doczesnych utrapień i obdarz wieczną radością. Przez Chrystusa, Pana naszego. Amen.

Muzyka:  https://soundcloud.com/dyallas
_______________________________________
Tu nas można wesprzeć: https://patronite.pl/langustanapalmie 

Więcej nagrań o. Adama znajdziesz na:  
http://www.langustanapalmie.pl 

Można nas również znaleźć na:
Facebooku: https://www.facebook.com/LangustaNaPalmie 
Twitterze: https://twitter.com/LangustaPalmowa 
Instagramie: https://www.instagram.com/langustanapalmie 

Zapraszamy.

## Wstawaki [#482] Jak bobry
 - [https://www.youtube.com/watch?v=Rz1Pt_zcMIk](https://www.youtube.com/watch?v=Rz1Pt_zcMIk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-18 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Karaluchy pod poduchy [#03] Na pustyni
 - [https://www.youtube.com/watch?v=9vBQWMB3jCA](https://www.youtube.com/watch?v=9vBQWMB3jCA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-17 00:00:00+00:00

@langustanapalmie @dominikanie.pl #dobranocka #karaluchypodpoduchy #zostanwdomu ________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Codzienne wieczorne spotkania z dobranckami i kompletą. 

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#481] Największa
 - [https://www.youtube.com/watch?v=FQZzRHXpyMU](https://www.youtube.com/watch?v=FQZzRHXpyMU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-17 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

