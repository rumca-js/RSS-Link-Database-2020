# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Derek Gripper Live On KEXP At Home
 - [https://www.youtube.com/watch?v=NuHsX62ij9E](https://www.youtube.com/watch?v=NuHsX62ij9E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-04-17 00:00:00+00:00

Derek Gripper performs live on KEXP from his home in Cape Town. He will be live on Wo’ Pop with Darek Mazzone  at 12pm Pacific Time on Thursday, April 16th.
http://www.kexp.org

## L'Eclair - Castor MacDavid (Live on KEXP)
 - [https://www.youtube.com/watch?v=ZdvnlknnOPo](https://www.youtube.com/watch?v=ZdvnlknnOPo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-04-17 00:00:00+00:00

http://KEXP.ORG presents L'Eclair performing “Castor MacDavid” live at the La Chapelle by le Studio in Rennes, France, during Trans Musicales 2019. Recorded December 8, 2019.

Audio Engineer: Matt Ogaz
Audio Mixer: Benoît Erard
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

Additional support by 
Jean Baptiste Le Clec’h
Jean-Marc Meleard
Jeremy Meleard

Festival Artwork by Brendan Monroe

Special thanks to Gwenola Le Bris at Trans Musicales, Valérian Mercier at La Chapelle by le Studio, and Destination Renne

http://kexp.org
https://www.lestrans.com
https://www.tourisme-rennes.com
https://www.lachapellebylestudio.com
https://leclairbbib.bandcamp.com

## L'Eclair - Coke Mountain (Live on KEXP)
 - [https://www.youtube.com/watch?v=GEc2Pn1tNj0](https://www.youtube.com/watch?v=GEc2Pn1tNj0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-04-17 00:00:00+00:00

http://KEXP.ORG presents L'Eclair performing “Coke Mountain” live at the La Chapelle by le Studio in Rennes, France, during Trans Musicales 2019. Recorded December 8, 2019.

Audio Engineer: Matt Ogaz
Audio Mixer: Benoît Erard
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

Additional support by 
Jean Baptiste Le Clec’h
Jean-Marc Meleard
Jeremy Meleard

Festival Artwork by Brendan Monroe

Special thanks to Gwenola Le Bris at Trans Musicales, Valérian Mercier at La Chapelle by le Studio, and Destination Renne

http://kexp.org
https://www.lestrans.com
https://www.tourisme-rennes.com
https://www.lachapellebylestudio.com
https://leclairbbib.bandcamp.com

## L'Eclair - Dallas (Live on KEXP)
 - [https://www.youtube.com/watch?v=JmevYR0xv3k](https://www.youtube.com/watch?v=JmevYR0xv3k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-04-17 00:00:00+00:00

http://KEXP.ORG presents L'Eclair performing “Dallas” live at the La Chapelle by le Studio in Rennes, France, during Trans Musicales 2019. Recorded December 8, 2019.

Audio Engineer: Matt Ogaz
Audio Mixer: Benoît Erard
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

Additional support by 
Jean Baptiste Le Clec’h
Jean-Marc Meleard
Jeremy Meleard

Festival Artwork by Brendan Monroe

Special thanks to Gwenola Le Bris at Trans Musicales, Valérian Mercier at La Chapelle by le Studio, and Destination Renne

http://kexp.org
https://www.lestrans.com
https://www.tourisme-rennes.com
https://www.lachapellebylestudio.com
https://leclairbbib.bandcamp.com

## L'Eclair - Disco Dino / Suite / Suite No. 2 (Live on KEXP)
 - [https://www.youtube.com/watch?v=l8ZU6E33fSc](https://www.youtube.com/watch?v=l8ZU6E33fSc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-04-17 00:00:00+00:00

http://KEXP.ORG presents L'Eclair performing “Disco Dino / Suite / Suite No. 2” live at the La Chapelle by le Studio in Rennes, France, during Trans Musicales 2019. Recorded December 8, 2019.

Audio Engineer: Matt Ogaz
Audio Mixer: Benoît Erard
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

Additional support by 
Jean Baptiste Le Clec’h
Jean-Marc Meleard
Jeremy Meleard

Festival Artwork by Brendan Monroe

Special thanks to Gwenola Le Bris at Trans Musicales, Valérian Mercier at La Chapelle by le Studio, and Destination Renne

http://kexp.org
https://www.lestrans.com
https://www.tourisme-rennes.com
https://www.lachapellebylestudio.com
https://leclairbbib.bandcamp.com

## L'Eclair - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=Df6w7k33Wus](https://www.youtube.com/watch?v=Df6w7k33Wus)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-04-17 00:00:00+00:00

http://KEXP.ORG presents L'Eclair performing live at the La Chapelle by le Studio in Rennes, France, during Trans Musicales 2019. Recorded December 8, 2019.

Songs:
Dallas
Coke Mountain
Castor MacDavid
Disco Dino / Suite / Suite No. 2

Audio Engineer: Matt Ogaz
Audio Mixer: Benoît Erard
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Jim Beckmann

Additional support by 
Jean Baptiste Le Clec’h
Jean-Marc Meleard
Jeremy Meleard

Festival Artwork by Brendan Monroe

Special thanks to Gwenola Le Bris at Trans Musicales, Valérian Mercier at La Chapelle by le Studio, and Destination Renne

http://kexp.org
https://www.lestrans.com
https://www.tourisme-rennes.com
https://www.lachapellebylestudio.com
https://leclairbbib.bandcamp.com

