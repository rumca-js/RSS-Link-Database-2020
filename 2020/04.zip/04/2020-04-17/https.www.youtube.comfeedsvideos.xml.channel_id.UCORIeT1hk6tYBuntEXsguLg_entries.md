# Source:PostmodernJukebox, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg, language:en-US

## Last Nite - The Strokes (Vintage "Trad Jazz" Style Cover) ft. Sweet Megg
 - [https://www.youtube.com/watch?v=9KbsU4KrhyQ](https://www.youtube.com/watch?v=9KbsU4KrhyQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg
 - date published: 2020-04-17 00:00:00+00:00

Download & Stream "Last Nite" Here: https://pmjlive.com/okcrooner
Experience PMJ Live on Tour: http://www.pmjtour.com
Shop PMJ Music / Merch: http://www.shoppmj.com
Follow us on Spotify: http://www.pmjlive.com/pmjspotify


Brooklyn's own Sweet Megg puts her own sweet & low-down spin on The Strokes' 2001 hit, "Last Nite" in her PMJ debut, filmed before the days of quarantine.

Follow The Musicians:
Sweet Megg (Vocals):
YouTube: https://youtube.com/channel/UCNvyTfPb0zwwxlXUBMsHZgA
Instagram: https://instagram.com/sweet.megg/
http://sweetmeggswayfarers.com

Chloe Feoranzo (Clarinet):
Instagram: https://instagram.com/chloejazz3/

Mike Chisnall (Banjo):
Instagram: https://instagram.com/mikechisnallmusic/

Eric Heveron-Smith (Bass):
Instagram: https://instagram.com/eheveronsmith/

Dave Tedeschi (Drums):
Instagram: https://instagram.com/davetedeschi/

Scott Bradlee (Piano):
YouTube: http://youtube.com/scottbradlee
Scott's Book: http://smarturl.it/outsidethejukebox

Arrangement by: Scott Bradlee
Engineered by: Thai Long Ly (https://instagram.com/tl2bass/) 
Video by: Andrew Rozario & Mike Stryker

#TheStrokes #LastNite #Cover

