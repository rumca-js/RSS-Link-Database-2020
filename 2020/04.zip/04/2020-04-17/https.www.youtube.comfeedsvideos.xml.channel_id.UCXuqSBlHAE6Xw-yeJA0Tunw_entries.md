# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## RTX Finally Has a Reason to Exist: Minecraft!
 - [https://www.youtube.com/watch?v=DD0nHDb5_bE](https://www.youtube.com/watch?v=DD0nHDb5_bE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-04-18 00:00:00+00:00

Check out the Drop x Sennheiser HD 6XX Headphones at https://dro.ps/ltt-6xx-april

Use code LINUS to get 10% off at Cablemod's configurator at https://lmg.gg/8KVKY

MINECRAFT IS RTX ON BABY!

New Intro by https://www.instagram.com/mbarek_abdel/

Buy an AMD Ryzen 3900X
On Amazon (PAID LINK): https://geni.us/EIYP4
On Newegg (PAID LINK): https://geni.us/JfcEd

Buy an ASUS X570-Ace WS Mobo:
On Amazon (PAID LINK): https://geni.us/5fetcB
On Newegg (PAID LINK): https://geni.us/MqY7W

Buy 16GB DDR4 RAM
On Amazon (PAID LINK): https://geni.us/5TBhi6
On Newegg (PAID LINK): https://geni.us/r2EA2

Buy an EVGA RTX 2060 KO
On Amazon (PAID LINK): https://geni.us/AAAxJ6
On Newegg (PAID LINK): https://geni.us/4y4V36l

Buy an NVIDIA RTX 2070 SUPER
On Amazon (PAID LINK): https://geni.us/XzKZ4
On Newegg (PAID LINK): https://geni.us/vAT5A8z

Buy a Gigabyte RTX 2080 SUPER
On Amazon (PAID LINK): https://geni.us/aSXnB
On Newegg (PAID LINK): https://geni.us/3YfOaO

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1180073-rtx-finally-has-a-reason-to-exist-minecraft/

GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Support a Creator code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Test Benches on Amazon: https://lmg.gg/HOx0z
Our Production Gear: https://lmg.gg/4oPzt
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Reyboard by vadimmihalkevich / CC BY 4.0
https://sketchfab.com/3d-models/monitor-and-reyboard-eb5fd505420248d7901da8fa13cdfc42

Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0
https://sketchfab.com/3d-models/mechanical-rgb-keyboard-4650f5bafe934a90b9f09396b843a966

Mouse Gamer free Model By Oscar creativo / CC BY 4.0
https://sketchfab.com/3d-models/mouse-gamer-free-model-by-oscar-creativo-212f2713f3704907a2ca16c1546cb8f7

## Apple's "Cheap" iPhone is still $400... - WAN Show April 17, 2020
 - [https://www.youtube.com/watch?v=tF28TY2qZww](https://www.youtube.com/watch?v=tF28TY2qZww)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-04-17 00:00:00+00:00

Use offer code LTT to save 10% on Savage Jerky at https://lmg.gg/savagejerky

Get 20% OFF + Free Shipping at Manscaped.com with code WAN at https://mnscpd.com/2ML8ni3

Sign up for Private Internet Access VPN at https://lmg.gg/piawan

Buy LTX 2020 Presented by Intel Tickets: https://lmg.gg/ltx20tickets
Learn more about LTX 2020: https://www.ltxexpo.com/
LTX 2020 Activities: https://www.ltxexpo.com/attractions
LTX 2020 Special Guests: https://www.ltxexpo.com/guests

Buy an LTT shirt, hoodie, hat, and even our own water bottle at https://lmg.gg/wanlttstore

Check out Carpool Critics, our new movie podcast: https://www.youtube.com/channel/UCt-oJR5teQIjOAxCmIQvcgA

Podcast Download: http://dts.podtrac.com/redirect.mp3/traffic.libsyn.com/linustechtips/Apples__Cheap__iPhone_is_still_400..._-_WAN_Show_April_17_2020.mp3

Timestamps: (Courtesy of Imp3rial St0rm)

2:49 - Apple Made an iPhone SE Gen-2 
20:00 - Apple Rumored to Make Modular Headphones
28:45 - Sponsors and Advertisements 
33:02 - Linus' Ghetto Air Conditioning Project
49:55 - Building a Nintendo Switch from Scratch
54:01 - Product Price Gouging
1:02:15 - Steam Controller Patent
1:04:25 - Quad-Core Zen 2 CPUs
1:06:55 - Streaming, Beards, and Other Random Crap
1:29:32 - Crysis Remastered
1:31:47 - Luke Loses All Credibility with his Girlfriend

