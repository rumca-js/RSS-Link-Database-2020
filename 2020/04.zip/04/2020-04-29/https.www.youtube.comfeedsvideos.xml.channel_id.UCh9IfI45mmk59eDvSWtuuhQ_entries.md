# Source:Ryan George, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ, language:en-US

## Obligatory "In These Uncertain Times" Commercial
 - [https://www.youtube.com/watch?v=iuZTch7FJgU](https://www.youtube.com/watch?v=iuZTch7FJgU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ
 - date published: 2020-04-30 00:00:00+00:00

http://prettybigpickles.com
Subscribe for more videos: http://bit.ly/2wscuFf
Twitter/Instagram: @TheRyanGeorge

In these uncertain times, it's not always certain what time it is. That's why now more than ever, it's important for corporations to spend millions of dollars on commercials to show that they care. Now more than ever. Uncertainly. Thank you. 

The First Guy To Ever Make A Commercial
https://www.youtube.com/watch?v=qQiui9h71l8

Pexels Stock Footage by:
Kelly Lacy, Pressmaster, Edward Jenner, Victor Varetto, Cottonbro, Koen De Zutter, Pixabay, Ruvim Miksanskiy, Caleb Oquendo, Matthias Groeneveld, George Morina, Adailton, Batista,

