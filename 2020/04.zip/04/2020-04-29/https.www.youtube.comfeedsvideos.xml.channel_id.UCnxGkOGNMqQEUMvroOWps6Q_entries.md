# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Former SEAL Jack Carr on Navy Dismissal of Captain Brett Crozier
 - [https://www.youtube.com/watch?v=0Ul-coWNFtw](https://www.youtube.com/watch?v=0Ul-coWNFtw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-30 00:00:00+00:00

Taken from JRE #1467 w/Jack Carr: https://youtu.be/Ra4522ikFoU

## How Navy SEAL Author Jack Carr Got Chris Pratt’s Attention
 - [https://www.youtube.com/watch?v=Jq8DbdwPrCI](https://www.youtube.com/watch?v=Jq8DbdwPrCI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-30 00:00:00+00:00

Taken from JRE #1467 w/Jack Carr: https://youtu.be/Ra4522ikFoU

## Jack Carr's Journey from Navy SEAL to Author | Joe Rogan
 - [https://www.youtube.com/watch?v=zvpaPpPrHio](https://www.youtube.com/watch?v=zvpaPpPrHio)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-30 00:00:00+00:00

Taken from JRE #1467 w/Jack Carr:
https://youtu.be/Ra4522ikFoU

## Navy SEAL Author Jack Carr on What We Learned from Operation Eagle Claw
 - [https://www.youtube.com/watch?v=iQ2LhuRo70o](https://www.youtube.com/watch?v=iQ2LhuRo70o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-30 00:00:00+00:00

Taken from JRE #1467 w/Jack Carr: https://youtu.be/Ra4522ikFoU

## Navy Seal Novelist Jack Carr on Dealing with the Real NCIS
 - [https://www.youtube.com/watch?v=26MpojPtRJw](https://www.youtube.com/watch?v=26MpojPtRJw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-30 00:00:00+00:00

Taken from JRE #1467 w/Jack Carr: https://youtu.be/Ra4522ikFoU

## SEAL Turned Author Jack Carr Hopes People Learn Self-Reliance from Pandemic
 - [https://www.youtube.com/watch?v=RdcxuI3-O3Y](https://www.youtube.com/watch?v=RdcxuI3-O3Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-30 00:00:00+00:00

Taken from JRE #1467 w/Jack Carr: https://youtu.be/Ra4522ikFoU

## The Latest Speculation on the Wuhan Lab Theory w/Jack Carr | Joe Rogan
 - [https://www.youtube.com/watch?v=FJYEk1pTLIU](https://www.youtube.com/watch?v=FJYEk1pTLIU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-30 00:00:00+00:00

Taken from JRE #1467 w/Jack Carr:
https://youtu.be/Ra4522ikFoU

## Are Coronavirus Tracking Apps Necessary? w/Jessiemae Peluso | Joe Rogan
 - [https://www.youtube.com/watch?v=Mt6Jt2Enuuo](https://www.youtube.com/watch?v=Mt6Jt2Enuuo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-29 00:00:00+00:00

Taken from JRE #1466 w/Jessimae Peluso:
https://youtu.be/sqsBfhCbMjw

## Did Chris Cuomo Fake Self-Quarantine for CNN? w/Tim Poole | Joe Rogan
 - [https://www.youtube.com/watch?v=CntSHGSWCfI](https://www.youtube.com/watch?v=CntSHGSWCfI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-29 00:00:00+00:00

Taken from #1465 w/Tim Poole:
https://youtu.be/Cs_mDpIkUOY

## If We're not Careful Chinese-Style Oppression Could Happen Here!
 - [https://www.youtube.com/watch?v=jrWa8qjHdwc](https://www.youtube.com/watch?v=jrWa8qjHdwc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-29 00:00:00+00:00

Taken from JRE #1466 w/Jessimae Pelluso: https://youtu.be/sqsBfhCbMjw

## Jessimae Pelluso: Our Brains Are Universes in and of Themselves
 - [https://www.youtube.com/watch?v=JLlXO9a9Cgg](https://www.youtube.com/watch?v=JLlXO9a9Cgg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-29 00:00:00+00:00

Taken from JRE #1466 w/Jessimae Pelluso: https://youtu.be/sqsBfhCbMjw

## Joe Rogan Talks Battlefield Earth, Tom Cruise, and Everything Scientology
 - [https://www.youtube.com/watch?v=CqtX5fPHaGM](https://www.youtube.com/watch?v=CqtX5fPHaGM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-29 00:00:00+00:00

Taken from JRE #1466 w/Jessimae Peluso:
https://youtu.be/sqsBfhCbMjw

## Tim Poole Talks Media Bias on Chloroquine Coverage | Joe Rogan
 - [https://www.youtube.com/watch?v=iYSD9SLFByY](https://www.youtube.com/watch?v=iYSD9SLFByY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-29 00:00:00+00:00

Taken from #1465 w/Tim Poole:
https://youtu.be/Cs_mDpIkUOY

## Why Do People on Ayahuasca Trips See Jaguars?
 - [https://www.youtube.com/watch?v=uPOba9Ab79c](https://www.youtube.com/watch?v=uPOba9Ab79c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-29 00:00:00+00:00

Taken from JRE #1466 w/Jessimae Pelluso: https://youtu.be/sqsBfhCbMjw

