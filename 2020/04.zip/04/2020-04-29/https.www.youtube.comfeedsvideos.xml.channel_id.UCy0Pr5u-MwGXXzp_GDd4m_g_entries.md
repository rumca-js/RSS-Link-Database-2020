# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## Where missing puzzle pieces go
 - [https://www.youtube.com/watch?v=LJIBNCIV7nM](https://www.youtube.com/watch?v=LJIBNCIV7nM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2020-04-30 00:00:00+00:00

There's always that point in time, during a puzzle, when you are convinced, without a doubt, that a piece has gone missing... I'm here to tell you, you're not wrong.

