# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I Made my Own Keyboard Keycaps!!
 - [https://www.youtube.com/watch?v=-scV7LLvdh8](https://www.youtube.com/watch?v=-scV7LLvdh8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-04-30 00:00:00+00:00

SimpliSafe is an awesome home security service that helps keep your home safe around the clock. It's reliable, inexpensive, easy to use, and there are no contracts. Check SimpliSafe out today at http://simplisafe.com/LTT - Thanks to SimpliSafe for sponsoring this video!


Is your keyboard just not.. YOURS enough? Today we’re building our own heat press to show you how to dye sublimate images directly INTO blank keys to truly customize your keyboard.

Intro by Mbarek Abdelwassaa -  https://www.instagram.com/mbarek_abdel/

Buy Epson Workforce WF-7710 Printer
On Amazon (PAID LINK): https://geni.us/Ceoh
On Newegg (PAID LINK): https://geni.us/ejTf

Buy J-B Weld High Heat Epoxy
On Amazon (PAID LINK): https://geni.us/4tVX
On Newegg (PAID LINK): https://geni.us/iZmhkE

Buy Polyamide (Kapton) Tape
On Amazon (PAID LINK): https://geni.us/yLHn3tK
On Newegg (PAID LINK): https://geni.us/kDNf

Buy Sublimation Paper
On Amazon (PAID LINK): https://geni.us/BNXA1
On Newegg (PAID LINK): https://geni.us/xUIi2

Buy Dye Sublimation ink
On Amazon (PAID LINK): https://geni.us/onZd
On Newegg (PAID LINK): https://geni.us/zWs1

Buy 12V Heating Element
On Amazon (PAID LINK): https://geni.us/ndppG
On Newegg (PAID LINK): https://geni.us/fij7

Buy Empty Ink Cartridge
On Amazon (PAID LINK): https://geni.us/5jjQRJ
On Newegg (PAID LINK): https://geni.us/9wtBc2

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1186809-i-made-my-own-keyboard-keycaps/

GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Get SimpliSafe Home Security at simplisafe.com/LTT
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Support a Creator code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Test Benches on Amazon: https://lmg.gg/HOx0z
Our Production Gear: https://lmg.gg/4oPzt

Thanks to Dixie Mech for providing the Keycaps - https://dixiemech.com/
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC + INTRO CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0 https://lmg.gg/fxHYK
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://lmg.gg/Q9yyQ
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://lmg.gg/8upii

## Building our NEW Video Editing Workstation - Start to Finish
 - [https://www.youtube.com/watch?v=EXBGRxmLqOU](https://www.youtube.com/watch?v=EXBGRxmLqOU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-04-29 00:00:00+00:00

Get a Joan board and use offer code LINUSHOME5 to get 5% off at https://getjoan.com/

Buy AMD Ryzen Threadripper 3960X CPU:
On Amazon (PAID LINK): https://geni.us/YcBX5
On B&H (PAID LINK): https://geni.us/hJ6Oz

Buy G.SKILL DDR4 RAM
On Amazon (PAID LINK): https://geni.us/sK2zlWn
On Newegg (PAID LINK): https://geni.us/EWQ15

Buy Seasonic 1000w PRIME ULTRA
On Amazon (PAID LINK): https://geni.us/cNU6
On Newegg (PAID LINK): https://geni.us/ROwd9uH

Buy ROG ASUS Zenith Extreme Mobo:
On Amazon (PAID LINK): https://geni.us/24Xc9
On B&H (PAID LINK): https://geni.us/BX38U7A

Buy Noctua NH-U14S
On Amazon (PAID LINK): https://geni.us/YB7Ar
On B&H (PAID LINK): https://geni.us/zpf4v

Buy Phanteks P600S
On Amazon (PAID LINK): https://geni.us/VClS
On Newegg (PAID LINK): https://geni.us/bLtaFI

Buy Intel Optane 380gb M.2 SSD
On Amazon (PAID LINK): https://geni.us/Ihfz
On B&H (PAID LINK): https://geni.us/boJPq

Buy NVIDIA RTX GPU's
On Amazon (PAID LINK): https://geni.us/tru7
On Newegg (PAID LINK): https://geni.us/B7Mx4

Buy ASUS PA32UCX Gaming Monitor
On Amazon (PAID LINK): https://geni.us/R1J74b
On B&H (PAID LINK): https://geni.us/vmeQ6Vt

