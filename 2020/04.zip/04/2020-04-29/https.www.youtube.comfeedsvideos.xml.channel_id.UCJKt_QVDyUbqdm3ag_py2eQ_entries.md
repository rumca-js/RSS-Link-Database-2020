# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga Paula does XM: AceMan - Drop The Hake (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=o9zJs0jQ3HA](https://www.youtube.com/watch?v=o9zJs0jQ3HA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-04-30 00:00:00+00:00

"Drop The Hake" by AceMan/Appendix^Dreamweb (Jakub Szelag), 6th at Revision 2016. Art "The Bitch" (1994) by Grandma. This upload is intended for headphones only.

Made using real A1200 Rev. 1D.4  audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Normal mixing with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- Module reports 8 channels
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.

