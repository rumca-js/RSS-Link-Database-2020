# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Youtube's Copyright System is being Abused to Dox, Threaten, and Blackmail Creators
 - [https://www.youtube.com/watch?v=tyJhurbs51M](https://www.youtube.com/watch?v=tyJhurbs51M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-04-30 00:00:00+00:00

this has to stop. Now.

## Plagiarizin' with Andrei Jikh - YOUTUBE AUTOMATION WORKS!!!
 - [https://www.youtube.com/watch?v=cGCxUSteR60](https://www.youtube.com/watch?v=cGCxUSteR60)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-04-29 00:00:00+00:00

i have a confession to make...

i was wrong about the YTA method. It just might be the greatest income opportunity of our era. :O

Andrei Jikh seems like a pretty entertaining dude, but this plagiarism is pretty nasty stuff. you've gotta give CREDIT to people who do the research, and stop passing other people's work as your own. You can teach people Robinhood, webull, real estate investing, stock market investing, or how to build wealth without plagiarizing it. Not cool. 

SOURCES: 
CNBC
https://www.cnbc.com/2019/04/24/the-10-highest-paying-jobs-you-can-get-without-a-college-degree.html
Andrei Jikh's video
https://www.cnbc.com/2019/04/24/the-10-highest-paying-jobs-you-can-get-without-a-college-degree.html

