# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## The Raid: Redemption - Movie Review
 - [https://www.youtube.com/watch?v=RRc4yYc-1VU](https://www.youtube.com/watch?v=RRc4yYc-1VU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-04-29 00:00:00+00:00

I've been getting requests to talk about this movie for years. Does it live up to the hype? Here's my review for THE RAID: REDEMPTION!

