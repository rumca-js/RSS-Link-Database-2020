# Source:FRONTLINE PBS | Official, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ, language:en-US

## Covering Coronavirus: Indian Country (podcast) | FRONTLINE
 - [https://www.youtube.com/watch?v=_N1YSxKPPJY](https://www.youtube.com/watch?v=_N1YSxKPPJY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ
 - date published: 2020-04-29 00:00:00+00:00

Native American communities were already dealing with underfunded health services. Then the coronavirus outbreak began. Journalist Antonia Gonzales, herself a member of the Native community, reports from New Mexico — where Navajo Nation, one of the largest tribes in the country, has seen a higher rate of confirmed COVID-19 cases than most states. And Gonzales finds that tribes say their requests for federal help are being ignored.

This journalism is made possible by viewers like you. Support your local PBS station here: http://www.pbs.org/donate

Subscribe on YouTube: http://bit.ly/1BycsJW

#COVID-19 #Coronavirus #Podcast #Documentary #frontlinePBS 

Instagram: https://www.instagram.com/frontlinepbs
Twitter: https://twitter.com/frontlinepbs
Facebook: https://www.facebook.com/frontline

FRONTLINE is streaming more than 200 documentaries online, for free, here: http://to.pbs.org/hxRvQP 

The FRONTLINE Dispatch is produced at FRONTLINE’s headquarters at WGBH in Boston and distributed by PRX, a leading podcast creator and distributor working closely with WGBH on a range of podcast initiatives. The FRONTLINE Dispatch is made possible by a generous gift from the Abrams Foundation Journalism Initiative.

