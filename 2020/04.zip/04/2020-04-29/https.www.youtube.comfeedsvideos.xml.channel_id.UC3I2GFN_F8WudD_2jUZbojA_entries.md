# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Travis Thompson - Don't Run (Live on KEXP)
 - [https://www.youtube.com/watch?v=shu-8V3TFbI](https://www.youtube.com/watch?v=shu-8V3TFbI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-04-29 00:00:00+00:00

http://KEXP.ORG presents Travis Thompson performing "Don't Run" live in the KEXP studio. Recorded January 7, 2020.

Host: Eva Walker
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
https://www.facebook.com/TravisThompsonMusic

## Travis Thompson - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=Ddiyg6c0x2c](https://www.youtube.com/watch?v=Ddiyg6c0x2c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-04-29 00:00:00+00:00

http://KEXP.ORG presents Travis Thompson performing live in the KEXP studio. Recorded January 7, 2020.

Songs:
The Move
Malice
Mad Mad World
Don't Run

Host: Eva Walker
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
https://www.facebook.com/TravisThompsonMusic

## Travis Thompson - Mad Mad World (Live on KEXP)
 - [https://www.youtube.com/watch?v=E0Pp1AnZkrY](https://www.youtube.com/watch?v=E0Pp1AnZkrY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-04-29 00:00:00+00:00

http://KEXP.ORG presents Travis Thompson performing "Mad Mad World" live in the KEXP studio. Recorded January 7, 2020.

Host: Eva Walker
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
https://www.facebook.com/TravisThompsonMusic

## Travis Thompson - Malice (Live on KEXP)
 - [https://www.youtube.com/watch?v=swL3OzL3NYM](https://www.youtube.com/watch?v=swL3OzL3NYM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-04-29 00:00:00+00:00

http://KEXP.ORG presents Travis Thompson performing "Malice" live in the KEXP studio. Recorded January 7, 2020.

Host: Eva Walker
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
https://www.facebook.com/TravisThompsonMusic

## Travis Thompson - The Move (Live on KEXP)
 - [https://www.youtube.com/watch?v=ewXEDHpBmLg](https://www.youtube.com/watch?v=ewXEDHpBmLg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-04-29 00:00:00+00:00

http://KEXP.ORG presents Travis Thompson performing "The Move" live in the KEXP studio. Recorded January 7, 2020.

Host: Eva Walker
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann, Scott Holpainen & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
https://www.facebook.com/TravisThompsonMusic

