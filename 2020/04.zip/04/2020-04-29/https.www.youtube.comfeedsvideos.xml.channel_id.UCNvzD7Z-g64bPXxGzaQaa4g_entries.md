# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Assassin's Creed Valhalla - Things the Trailer DOESN'T Tell You
 - [https://www.youtube.com/watch?v=9EUt0OC2ZhU](https://www.youtube.com/watch?v=9EUt0OC2ZhU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-04-30 00:00:00+00:00

Assassin's Creed Valhalla has been revealed for PC, PS5, Xbox Series X, PS4, and Xbox One. Here's what we know.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Sources:

https://www.eurogamer.net/articles/2020-04-30-assassins-creed-valhalla-reshapes-the-series-rpg-storytelling-by-giving-you-a-viking-settlement

https://www.gameinformer.com/2020/04/30/25-things-weve-learned-about-assassins-creed-valhalla

https://www.ign.com/articles/assassins-creed-valhalla-ps5-xbox-series-x-2020-gameplay-story

## PS5 vs Xbox Series X Controller
 - [https://www.youtube.com/watch?v=sMpvCAAxlo0](https://www.youtube.com/watch?v=sMpvCAAxlo0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-04-29 00:00:00+00:00

The PS5 DualSense and the new Xbox Series X controller have both been revealed, so let's stack them up against one another.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

