# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Go Down Donald
 - [https://www.youtube.com/watch?v=Q0dzwjPtAwY](https://www.youtube.com/watch?v=Q0dzwjPtAwY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-04-29 00:00:00+00:00

The Babylon Bee's Kyle Mann and Ethan Nicolle present a new take on an old classic.

## Let My People Go
 - [https://www.youtube.com/watch?v=3OkIbDUqFSg](https://www.youtube.com/watch?v=3OkIbDUqFSg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2020-04-29 00:00:00+00:00

This is the Babylon Bee weekly news podcast for the week of 4/29/2020.

 In this episode of The Babylon Bee podcast, editor-in-chief Kyle Mann and creative director Ethan Nicolle talk about the biggest stories of the week like Kim Jong Un being Un-dead, doctor Trump talking about disinfectant being used to clean the body, and the oppression of the American people under this lockdown being so bad that Trump has to tell the governors to “let my people go!” This episode is a must listen for the ‘Go Down Donald’ music track alone which we spent way too much time on. They also talk about why staring at a TV isn’t church.

 In the subscriber portion, subscribers get to listen to Kyle and Ethan dig into the mail bag where they find an audio file sent to us by a subscriber! They talk about worship songs or worship leader habits that really bug them and answer other deep questions from subscribers. 

 Send your emails to podcast@babylonbee.com and maybe we will answer you in our next Mailbag segment!

 If you are hurting financially right now, check out our $100,000 COVID relief fund set up by Seth Dillon which you can find out more about by contacting us at our website. If you need financial help contact us! Also donate if you are able to chip in to help!

  Pre-order the new Babylon Bee Best-Of Coffee Table Book coming in 2020!

 Show Outline

 Introduction - Kyle and Ethan talk about waterslides and hotdogs and shampoo.

 Stuff That’s Good - 

 Kyle:  H.P. Lovecraft - At the Mountains of Madness, The Festival, Rats in the Walls, The Hound

 Ethan:  Like Trees Walking Podcast

 These Things Are Weird - 

 Ontario woman’s life saved by breast implant that deflected bullet

  Dirt bikers make use of sand-covered skate park in California

  Oregon man drove to 11 different Wendy's restaurants twice in 1 day to stock up on free nuggets, report says

  Woman ‘wakes up in a body bag after mistakenly being declared dead’

 Stories of the Week

 Story 1 - North Korea Reports Kim Jong Un Is 'Most Alive Person In Universe'

   NBC’s Katy Tur tweeted then quickly deleted a tweet saying he was brain dead

   Conflicting rumors were circulating that the North Korean dictator had to have heart surgery to put a stent put in and that he was either dead or in a vegitative state

    Liberals started thirsting for a woman dictator in his sister Kim Yo Jong

   North Korea is going to get a woman leader before the US? LET THAT SINK IN PEOPLE

    Other countries that beat the US to a woman leader

   Kyle reads a very real and not fake at all statement from the People's Republic Of North Korea

   Story 2 -  Trump Threatens More Plagues Unless State Governors Let His People Go

  Trump wants to start recommending phases of opening up the economy. But California, Oregon &amp; Washington Announce Western States Pact in which they will only open up their states when SCIENCE says to.  Kyle and Ethan hit the guitar and banjo for a new version of an old classic, Let My People Go. 

 (Begins at 00:29:11)

 Go down Donald, way down in Michigan

 Tell old Whitmer to let my people go

 When buyin’ guns and seeds was banned

 (Let my people go)

 Oppressed so hard they could not stand

 (Let My people go)

 “Go down ,  Donald  

 way down in Cali Land

 Tell old Gavin to let the skaters go” (LET THE SKATERS GO)

 So Trump spoke to the press and there decreed

 (Let My people go)

 But CNN -wouldn’t air the feed

 (Let My people go)

 Yes the protesters said, “come down (COME DOWN), Donald, (DONALD) 

 way (WAY)  down (DOWN) at the Bass Pro” BASS PRO

 Tell those governors to let them buy ammo (LET THEM BUY AMMO)

 Trump said, “If you want to end the quarantine,

 (Why not give bleach a go?)

 Hit em with hydroxychloroquine

 (Let the Clorox flow!”)

 God, The Lord said, “Go down, (GO DOWN)  Donald,(DONALD) way (WAY) down (DOWN) to America”

 Tell Dem TELL DEM governors GOVERNORS  to let My people go

 Tell Dem TELL DEM governors GOVERNORS let My people go 

 Story 3 - Trump Says To Drink Lots Of Water, Media Reports He Told Everyone To Drown Themselves

   Trump seemed to be pontificating before the press about things he was discussing with his experts about in coming up with possible treatments to defeat coronavirus.

   The corporate press immediately reported that Trump was advising the public to drink bleach and disinfectants and blue checks and Democrats jumped over it.

   Topic of the Week - Why go to church?

   With most people streaming church services, is there a reason to go back? Why should Christians have fellowship in person?

   Broader cultural effects of religion and church attendance

   Hebrews 10:25 - And let us consider how we may spur one another on toward love and good deeds, 25 not giving up meeting together, as some are in the habit of doing, but encouraging one...

