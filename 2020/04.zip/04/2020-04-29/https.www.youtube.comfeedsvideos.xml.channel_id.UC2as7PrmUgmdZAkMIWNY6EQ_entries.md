## Parcels - Live Vol. 1 (Complete Footage)
 - [https://www.youtube.com/watch?v=e4TFD2PfVPw](https://www.youtube.com/watch?v=e4TFD2PfVPw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2as7PrmUgmdZAkMIWNY6EQ
 - date published: 2020-04-30 00:00:00+00:00

Live Vol. 1 out now: http://lnk.to/parcelslive
Subscribe to Parcels channel: http://bit.ly/2hUbkPq
Listen to their essentials here: https://parcels.lnk.to/essentials

This project and the footage captured was all pre-quarantine.

00:15 Enter
03:15 Myenemy
06:45 Bemyself
11:13 Comedown
14:53 Lightenup
19:48 Gamesofluck
23:26 Intrude
24:22 Withorwithout
29:04 Retuned
29:49 Everyroad
37:40 Overnight
41:38 Untried
43:05 Yourfault
47:37 Closetowhy
51:46 Redline
54:44 IknowhowIfeel
57:39 Elude
01:00:39 Tieduprightnow

Official website & merch store  → www.parcelsmusic.com
 
Follow Parcels:

Like on Facebook: https://www.facebook.com/parcelsmusic
Follow on Instagram https://www.instagram.com/parcelsmusic/
Follow on Soundcloud https://soundcloud.com/parcels-music

Recorded at Hansa Studios, Berlin
Director: Carmen Crommelin
DoP: Frederick Gomoll & Jean Raclet
Editor: Sven Arning
Fashion: De Bonne Facture
Styling&MakeUp: Juliane Polak
1st Assistant Camera: Tim Klein
DIT: Sören Klein
Gaffer: Frederic Adam
Electrician: Leo Wolters
Recording Engineer: Nanni Johansson
Recording Assistant: Frida Claeson Johansson
Executive Producer: Birger Luedemann & Ute Ressler
Producer: Denise Weller
Production Assist: Vivien Ott
Runner: Uwe Palecki

Recordings produced by Parcels
Recordings mixed by Perceval Carré 
Recordings mastered by Zino Mikorey

Executive Production: KKT & NOKTO Film

2020 Because Music

#Parcels

