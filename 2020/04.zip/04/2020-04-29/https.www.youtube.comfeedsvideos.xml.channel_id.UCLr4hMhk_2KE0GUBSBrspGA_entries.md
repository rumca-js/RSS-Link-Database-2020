# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Kwarantanna Show #5 - skaner do wina, kamera Pet Chatz, dron S-Series s20W, słuchawki Vinci
 - [https://www.youtube.com/watch?v=WHTVBXfPpz4](https://www.youtube.com/watch?v=WHTVBXfPpz4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-04-30 00:00:00+00:00

Ostatnio odcinek naszego ukochanego show, bardzo mi przykro.

