# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Today We Try Warsaw, A Roguelike Similar to Darkest Dungeon
 - [https://www.youtube.com/watch?v=ap8_Sc9GzhI](https://www.youtube.com/watch?v=ap8_Sc9GzhI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-04-30 00:00:00+00:00



## Animal Crossing: New Horizons (Zero Punctuation)
 - [https://www.youtube.com/watch?v=9pKhKStN--0](https://www.youtube.com/watch?v=9pKhKStN--0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-04-29 00:00:00+00:00

Watch the Final Fantasy VII Remake Zero Punctuation episode early: https://www.escapistmagazine.com/v2/final-fantasy-vii-remake-zero-punctuation/

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

This week on Zero Punctuation, Yahtzee reviews Animal Crossing: New Horizons. 

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►► https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

#ZeroPunctuation #AnimalCrossingNewHorizons

## Streets of Rage 4 | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=zH0JAwMFlJo](https://www.youtube.com/watch?v=zH0JAwMFlJo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-04-29 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Jesse Galena reviews Streets of Rage 4, developed by Dotemu, Guard Crush Games and Lizardcube.

Streets of Rage 4 on Steam: https://store.steampowered.com/app/985890/Streets_of_Rage_4/

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Yahtzee and Jack Play Final Fantasy VII Remake | Post-ZP Stream
 - [https://www.youtube.com/watch?v=XDFC-xI9egM](https://www.youtube.com/watch?v=XDFC-xI9egM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-04-29 00:00:00+00:00

We play two hours of the FF7 remake, which should get us about 0.01% of the way through the plot.

