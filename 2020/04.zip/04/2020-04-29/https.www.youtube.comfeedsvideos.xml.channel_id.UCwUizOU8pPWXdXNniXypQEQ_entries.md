# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## What Spiritual People Are Like During the Quarantine
 - [https://www.youtube.com/watch?v=d1HIopKBb3w](https://www.youtube.com/watch?v=d1HIopKBb3w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-04-30 00:00:00+00:00

What are spiritual people like during the quarantine? Obviously incredibly grounded. This video will show you the wisdom and spiritual perspective about the coronavirus quarantine crisis that ultra spiritual people have. When spiritual people aren't fighting about what plant based food has more nutrients, they're sharing more than helpful perspectives about why this challenging time is happening and how to cope. Join me for my Friday Night LIVE Stream comedy show here! - https://awakenwithjp.com/live

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Click Here to join my PATREON - https://awakenwithjp.com/patron
---- Want to be the first to see my new videos with 24 hour early access? Just click this to receive the alerts! - https://m.me/awakenwithjp?ref=w6836464

Listen and Subscribe to my NEW Podcast here: 
https://podcasts.apple.com/ca/podcast/awaken-with-jp-sears-show/id1436938686
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

-Order my new book at: http://HowToBeUltraSpiritual.com/

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

