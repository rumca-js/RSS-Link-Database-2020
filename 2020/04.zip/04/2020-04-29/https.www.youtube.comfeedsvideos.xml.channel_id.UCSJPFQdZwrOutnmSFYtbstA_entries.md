# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Justice League - Anatomy of a Disaster (Part 1)
 - [https://www.youtube.com/watch?v=ji7gJ9hWS9w](https://www.youtube.com/watch?v=ji7gJ9hWS9w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2020-04-29 00:00:00+00:00

Join me as I explore the problems, failures and mistakes that led to Justice League, one of the biggest cinematic failures of all time.

