# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## 7 Ways You're Using Your Phone WRONG!
 - [https://www.youtube.com/watch?v=J1uF_GtoiSY](https://www.youtube.com/watch?v=J1uF_GtoiSY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2020-04-29 00:00:00+00:00

You may think you know everything about your phone, but I bet you don't!

⇒ Become a channel member for exclusive features! Check it out here: https://www.youtube.com/ThioJoe/join

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe

⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV

My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

#Smartphone#Tech #ThioJoe

