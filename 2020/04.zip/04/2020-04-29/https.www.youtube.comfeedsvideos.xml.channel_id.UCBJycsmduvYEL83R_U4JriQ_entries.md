# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Moto Edge+ Review: We Need to Talk!
 - [https://www.youtube.com/watch?v=WIVUbBIrbM4](https://www.youtube.com/watch?v=WIVUbBIrbM4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2020-04-30 00:00:00+00:00

Motorola's Edge+ is here... and we need to talk about waterfall displays!

Thanks to Honey for sponsoring this video! Join free: http://joinhoney.com/MKBHD

5G Explained: https://youtu.be/_CTUs_2hq6Y

MKBHD Merch: http://shop.MKBHD.com

Video Gear I use: http://kit.co/MKBHD/video-gear#recom...
Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: 
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

