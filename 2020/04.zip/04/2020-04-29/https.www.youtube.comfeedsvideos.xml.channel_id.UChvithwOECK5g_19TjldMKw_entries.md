# Source:Laowhy86, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw, language:en-US

## Can We Compare China to Nazi Germany?
 - [https://www.youtube.com/watch?v=wD53MEbLDIE](https://www.youtube.com/watch?v=wD53MEbLDIE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw
 - date published: 2020-04-29 00:00:00+00:00

Hey Laowinners!

There is a question going around, are there more similarities with Mainland China and the Soviet Union, or Germany? I delve into that question with a reasonable comparison.

Ushanka Show - Guy from the Soviet Union - https://www.youtube.com/channel/UClXTAMdHwvWdmFyOlQmEtpQ

◘ Support me on Patreon for early release, and much more! http://www.patreon.com/laowhy86

◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

◘ OR Become a Sponsor on YouTube:
https://www.youtube.com/channel/UChvithwOECK5g_19TjldMKw/sponsor

Thanks to Snarky Guy for the footage - Check his China channel here - https://www.youtube.com/channel/UCaUlyGQGo6RFBVk_z8hqT2g

◘ My TV show: Conquering Northern China:
https://vimeo.com/ondemand/conqueringnorthernchina

◘ Conquering Southern China
https://vimeo.com/ondemand/conqueringsouthernchina

◘ Discount code for both shows: laowinning

◘ Join me every week for videos about China! Don't forget to subscribe!
http://www.youtube.com/laowhy86

Be a Laowinner!
Like comment subscribe!

◘ Facebook:
http://www.facebook.com/laowhy86

◘ Instagram: 
http://instagram.com/laowhy86

Music in this video - The Muse Maker
https://soundcloud.com/themusemaker

◘ Music used most of the time - New World Hip Hop
https://soundcloud.com/apollodrivenz
https://www.youtube.com/channel/UCgirAE5d8ufiotRXmBZZbBQ

