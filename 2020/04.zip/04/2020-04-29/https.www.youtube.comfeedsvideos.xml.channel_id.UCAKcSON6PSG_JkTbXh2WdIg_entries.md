# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Jack Garratt - Live Virtual Session from The Current
 - [https://www.youtube.com/watch?v=rE7FyJJQzAc](https://www.youtube.com/watch?v=rE7FyJJQzAc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-30 00:00:00+00:00

Jack Garratt checks in from his spare bedroom/studio in his London flat to talk with The Current's Jill Riley about his new record, self-acceptance, and trying to make his music sound the best it possibly can.
Songs performed:
02:23 "Better"
07:25 "Weathered"
29:04 "Time"
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Nervous fans in 'no rush' to return to concert venues (The Current Music News)
 - [https://www.youtube.com/watch?v=G7B77s1Jg_g](https://www.youtube.com/watch?v=G7B77s1Jg_g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-30 00:00:00+00:00

April 30, 2020: Music fans are eager to return to concert venues - but they're also understandably worried about COVID-19, and a new survey indicates most plan to wait a while to return to crowded venues. Also: a tide of happy songs is coming, Record Store Day's splitting into three 'drop' days, St. Vincent's hosting a shower-stall podcast, and Billie Joe Armstrong covers 'I Think We're Alone Now' with his kids.
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Listen to Looch: 'Beastie Boys Story' presents band's timeline in their own words
 - [https://www.youtube.com/watch?v=iV35HEqafJk](https://www.youtube.com/watch?v=iV35HEqafJk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-29 00:00:00+00:00

Mary Lucia talks about a new Beastie Boys documentary, from director Spike Jonze, that's streaming now on Apple TV+.
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Los Angeles company announces protective 'Micrashell' for concertgoers (The Current Music News)
 - [https://www.youtube.com/watch?v=7XsemxPtDYQ](https://www.youtube.com/watch?v=7XsemxPtDYQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-29 00:00:00+00:00

April 29, 2020: It looks like a spacesuit, but one company is hoping you'll buy it...to go to a concert. Also today, SXSW faces a class-action lawsuit over ticket refunds, Statler Brothers bass vocalist Harold Reid dies at 80, and hip-hop videos turn to sanitizer for swag.
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

