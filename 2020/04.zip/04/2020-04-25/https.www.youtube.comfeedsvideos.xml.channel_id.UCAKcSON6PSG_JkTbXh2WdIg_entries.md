# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Soul Asylum - Live Virtual Session
 - [https://www.youtube.com/watch?v=E0OnwBBejpo](https://www.youtube.com/watch?v=E0OnwBBejpo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-26 00:00:00+00:00

Ryan Smith and Dave Pirner of Soul Asylum perform a Live Virtual Session for The Current, hosted by Mark Wheat.
Songs Performed:
01:34 "New World"
06:27 "If I Told You"
25:12 "Closer to the Stars"
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Minnesota artists of the Kicks era (Teenage Kicks from The Current)
 - [https://www.youtube.com/watch?v=zEmkCr1qn0k](https://www.youtube.com/watch?v=zEmkCr1qn0k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-25 00:00:00+00:00

Host Jiim McGuinn features pioneering Minnesota bands from the '70s, '80s and '90s on this week's Teenage Kicks: Hüsker Dü, the Replacements, Soul Asylum, the Jayhawks and more.
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

