# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Confronting a 19 yr old “Millionaire Visionary” on alleged scam
 - [https://www.youtube.com/watch?v=p6JGTQZhP18](https://www.youtube.com/watch?v=p6JGTQZhP18)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-04-25 00:00:00+00:00

After a video I made about Caleb, he wanted to come on the show and get interviewed LIVE about some of the issues I brought up, including Reddit Copypasta, the YTA method and his infamous $10,000 sales phone call.

