# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Live at lofi-festival.com With the Synthstrom Deluge
 - [https://www.youtube.com/watch?v=-h5myC9KEJ8](https://www.youtube.com/watch?v=-h5myC9KEJ8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2020-04-25 00:00:00+00:00

A live set on the Synthstrom Deluge for lofi-festival.com, a 3-day streaming concert event.
Patrons get the set: https://www.patreon.com/posts/36430983
Tracklist: 
00:00 Love (Unreleased)
05:10 Fantastic Negrito - Dark Windows (Jeremy Blake Unreleased Remix)
09:18 Wander (from https://soundvision.bandcamp.com/album/vanitas)
14:36 Dear (Unreleased)
21:01 Boards Ripoff for Toka (from https://soundvision.bandcamp.com/album/vanitas)
24:55 Change My (Unreleased)
30:00 Hælo (from https://soundvision.bandcamp.com/album/two-thousand-and-sixteen-super-hits)
37:11 Evangaline (Unreleased Live Mix)
43:50 The Last of Summer (from https://soundvision.bandcamp.com/album/pataphysical)
------------------------------------
Patreon: http://bit.ly/rmrpatreon
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe
T-Shirts: http://bit.ly/rmrshirts
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

