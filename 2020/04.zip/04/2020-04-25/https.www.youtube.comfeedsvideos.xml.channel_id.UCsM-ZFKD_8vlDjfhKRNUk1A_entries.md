# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Josef Salvat - live (MUZO.FM)
 - [https://www.youtube.com/watch?v=kb1c67dZmUE](https://www.youtube.com/watch?v=kb1c67dZmUE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2020-04-25 00:00:00+00:00

Josef Salvat na żywo w MUZO.FM. Artysta zagrał w naszym studiu specjalny koncert, podczas którego wykonał wyjątkowe wersje kawałków: Hustler, Paradise i Open Season.
 
Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Josef Salvat: http://www.facebook.com/JosefSalvatMusic
Instagram Josef Salvat: http://www.instagram.com/josefsalvat
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm

