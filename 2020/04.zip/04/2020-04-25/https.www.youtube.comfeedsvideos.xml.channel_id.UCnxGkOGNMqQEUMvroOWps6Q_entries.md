# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Best of the Week - April 19, 2020 - Joe Rogan Experience
 - [https://www.youtube.com/watch?v=FTiX_eKvT0g](https://www.youtube.com/watch?v=FTiX_eKvT0g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-26 00:00:00+00:00

#1461 w/Owen Smith:
https://www.youtube.com/watch?v=mrNZUaaaEtI

#1462 w/Kurt Metzger:
https://www.youtube.com/watch?v=17pIBFcGB0k

#1463 w/Tom Green:
https://www.youtube.com/watch?v=CzqONHtFiHQ

#1464 w/Duncan Trussell:
https://www.youtube.com/watch?v=4YqZ08GxV1c

## Duncan Trussell Explains the Coronavirus Asteroid Conspiracy | Joe Rogan
 - [https://www.youtube.com/watch?v=uu8ykWgOWbc](https://www.youtube.com/watch?v=uu8ykWgOWbc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-25 00:00:00+00:00

Taken from JRE #1464 w/Duncan Trussell:
https://youtu.be/4YqZ08GxV1c

## Duncan Trussell Got High and Applied for a Job at the CIA
 - [https://www.youtube.com/watch?v=u5G4muD5yLo](https://www.youtube.com/watch?v=u5G4muD5yLo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-25 00:00:00+00:00

Taken from JRE #1464 w/Duncan Trussell: #1464 LINK: https://youtu.be/4YqZ08GxV1c

## Duncan Trussell Introduces Joe Rogan to the World of Mud Fetishists
 - [https://www.youtube.com/watch?v=LTHVijptM8s](https://www.youtube.com/watch?v=LTHVijptM8s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-25 00:00:00+00:00

Taken from JRE #1464 w/Duncan Trussell: #1464 LINK: https://youtu.be/4YqZ08GxV1c

## Duncan Trussell Talks New Netflix Show The Midnight Gospel | Joe Rogan
 - [https://www.youtube.com/watch?v=pJe-zbua4cw](https://www.youtube.com/watch?v=pJe-zbua4cw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-25 00:00:00+00:00

Taken from JRE #1464 w/Duncan Trussell:
https://youtu.be/4YqZ08GxV1c

## Joe Rogan and Duncan Trussell Go Deep on Art and Psychedelics
 - [https://www.youtube.com/watch?v=mra0csdjduU](https://www.youtube.com/watch?v=mra0csdjduU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-25 00:00:00+00:00

Taken from JRE #1464 w/Duncan Trussell: #1464 LINK: https://youtu.be/4YqZ08GxV1c

## Joe Rogan and Duncan Trussell Rip on the Skull and Bones Society
 - [https://www.youtube.com/watch?v=W5_pniShZXY](https://www.youtube.com/watch?v=W5_pniShZXY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-25 00:00:00+00:00

Taken from JRE #1464 w/Duncan Trussell: #1464 LINK: https://youtu.be/4YqZ08GxV1c

## Joe Rogan and Duncan Trussell Watch Trump’s “Disinfectant” Video
 - [https://www.youtube.com/watch?v=ha1jXdK53Zs](https://www.youtube.com/watch?v=ha1jXdK53Zs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-25 00:00:00+00:00

Taken from JRE #1464 w/Duncan Trussell: #1464 LINK: https://youtu.be/4YqZ08GxV1c

