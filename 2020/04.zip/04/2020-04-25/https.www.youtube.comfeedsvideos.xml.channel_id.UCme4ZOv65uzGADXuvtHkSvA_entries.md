# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Do Galilei [#02] Spojrzenie
 - [https://www.youtube.com/watch?v=Ef3FUlRPk0I](https://www.youtube.com/watch?v=Ef3FUlRPk0I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-26 00:00:00+00:00

#rekolekcje2020 #AdamSzustakOP  @Langustanapalmie @Dominikanieplportal 

Zapraszamy Was w podróż do przeszłości. Do takiej właśnie podróży zaprosił Pan Jezus Apostołów po swoim Zmartwychwstaniu. Wracamy więc razem z nimi do Galilei. Dlaczego znów przemierzymy tę drogę? Zobaczcie! 
Odcinki w każdą Niedzielę Wielkanocną.

zdjęcia i montaż: Marcin Jończyk
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Droga Światła z modlitwą wstawienniczą
 - [https://www.youtube.com/watch?v=-0w36lMpRvI](https://www.youtube.com/watch?v=-0w36lMpRvI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-26 00:00:00+00:00

@Langusta na palmie #drogaświatła #zostanwdomu 

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Droga Światła z modlitwą wstawienniczą || Zapowiedź
 - [https://www.youtube.com/watch?v=2B36xp3hwaM](https://www.youtube.com/watch?v=2B36xp3hwaM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-26 00:00:00+00:00

#DrogaŚwiatła #Adoracja #modlitwawstawiennicza
________________________________________

Zapraszamy na wieczorną modlitwę.
Już dziś o 20:10 LIVE - Droga Światła z modlitwą wstawienniczą

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Msza św. online - niedziela godz. 19.00
 - [https://www.youtube.com/watch?v=mgz0b3-Mn14](https://www.youtube.com/watch?v=mgz0b3-Mn14)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-26 00:00:00+00:00

​#msza #zostanwdomu @Langustanapalmie 

III Niedziela Wielkanocna, ROK A
pełen tekst czytań → https://niezbednik.niedziela.pl/liturgia/2020-04-26

Ewangelia (Łk 24, 13-35)

W pierwszy dzień tygodnia dwaj uczniowie Jezusa byli w drodze do wsi, zwanej Emaus, oddalonej o sześćdziesiąt stadiów od Jeruzalem. Rozmawiali oni z sobą o tym wszystkim, co się wydarzyło. Gdy tak rozmawiali i rozprawiali z sobą, sam Jezus przybliżył się i szedł z nimi. Lecz oczy ich były jakby przesłonięte, tak że Go nie poznali. On zaś ich zapytał: «Cóż to za rozmowy prowadzicie z sobą w drodze?» Zatrzymali się smutni. A jeden z nich, imieniem Kleofas, odpowiedział Mu: «Ty jesteś chyba jedynym z przebywających w Jerozolimie, który nie wie, co się tam w tych dniach stało». Zapytał ich: «Cóż takiego?» Odpowiedzieli Mu: «To, co się stało z Jezusem Nazarejczykiem, który był prorokiem potężnym w czynie i słowie wobec Boga i całego ludu; jak arcykapłani i nasi przywódcy wydali Go na śmierć i ukrzyżowali. A my spodziewaliśmy się, że On właśnie miał wyzwolić Izraela. Ale po tym wszystkim dziś już trzeci dzień, jak się to stało. Nadto, jeszcze niektóre z naszych kobiet przeraziły nas: były rano u grobu, a nie znalazłszy Jego ciała, wróciły i opowiedziały, że miały widzenie aniołów, którzy zapewniają, iż On żyje. Poszli niektórzy z naszych do grobu i zastali wszystko tak, jak kobiety opowiadały, ale Jego nie widzieli». Na to On rzekł do nich: «O, nierozumni, jak nieskore są wasze serca do wierzenia we wszystko, co powiedzieli prorocy! Czyż Mesjasz nie miał tego cierpieć, aby wejść do swej chwały?» I zaczynając od Mojżesza, poprzez wszystkich proroków, wykładał im, co we wszystkich Pismach odnosiło się do Niego. Tak przybliżyli się do wsi, do której zdążali, a On okazywał, jakby miał iść dalej. Lecz przymusili Go, mówiąc: «Zostań z nami, gdyż ma się ku wieczorowi i dzień się już nachylił». Wszedł więc, aby zostać wraz z nimi. Gdy zajął z nimi miejsce u stołu, wziął chleb, odmówił błogosławieństwo, połamał go i dawał im. Wtedy otworzyły się im oczy i poznali Go, lecz On zniknął im z oczu. I mówili między sobą: «Czy serce nie pałało w nas, kiedy rozmawiał z nami w drodze i Pisma nam wyjaśniał?»
W tej samej godzinie zabrali się i wrócili do Jeruzalem. Tam zastali zebranych Jedenastu, a z nimi innych, którzy im oznajmili: «Pan rzeczywiście zmartwychwstał i ukazał się Szymonowi». Oni również opowiadali, co ich spotkało w drodze i jak Go poznali przy łamaniu chleba.
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Karaluchy pod poduchy [#11] Po pijaku
 - [https://www.youtube.com/watch?v=HGzPPDfUsRg](https://www.youtube.com/watch?v=HGzPPDfUsRg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-25 00:00:00+00:00

@Langusta na palmie #dobranocka #karaluchypodpoduchy #zostanwdomu 

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Codzienne wieczorne spotkania z dobranckami i kompletą. 

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Ksiądz gra w grę: Uncharted 4 [#04] Wielkie rzeczy zaczynają się od miłości
 - [https://www.youtube.com/watch?v=OBFa9uO8W7E](https://www.youtube.com/watch?v=OBFa9uO8W7E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-25 00:00:00+00:00

@Langustanapalmie  #ksiadzgrawgre #zostanwdomu #bedegralwgre
________________________________________

Aby nas wesprzeć kliknij tu → https://patronite.pl/langustanapalmie

Miniaturkę stworzył dla nas: Sebastian Gwóźdź

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Miriam [#33] Dom złoty
 - [https://www.youtube.com/watch?v=KO7J51euvMw](https://www.youtube.com/watch?v=KO7J51euvMw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-25 00:00:00+00:00

#LitaniaLoretańska

Zapraszamy na  kontynuację serii o Miriam, czyli komentarz do Litanii Loretańskiej do Najświętszej Maryi Panny.

Kyrie, elejson. 
Chryste, elejson. 
Kyrie, elejson.
Chryste, usłysz nas. 
Chryste, wysłuchaj nas.
 
Ojcze z nieba, Boże, zmiłuj się nad nami.
Synu, Odkupicielu świata, Boże, zmiłuj się nad nami.
Duchu Święty, Boże, zmiłuj się nad nami.
Święta Trójco, Jedyny Boże, zmiłuj się nad nami.
 
Święta Maryjo, módl się za nami.
Święta Boża Rodzicielko, módl się za nami.
Święta Panno nad pannami, módl się za nami.
Matko Chrystusowa, módl się za nami.
Matko Kościoła, módl się za nami.
Matko łaski Bożej, módl się za nami.
Matko Miłosierdzia, módl się za nami.
Matko nieskalana, módl się za nami.
Matko najczystsza, módl się za nami.
Matko dziewicza, módl się za nami.
Matko nienaruszona, módl się za nami.
Matko najmilsza, módl się za nami.
Matko przedziwna, módl się za nami.
Matko dobrej rady, módl się za nami.
Matko Stworzyciela, módl się za nami.
Matko Zbawiciela, módl się za nami.
Panno roztropna, módl się za nami.
Panno czcigodna, módl się za nami.
Panno wsławiona, módl się za nami.
Panno można, módl się za nami.
Panno łaskawa, módl się za nami.
Panno wierna, módl się za nami.
Zwierciadło sprawiedliwości, módl się za nami.
Stolico mądrości, módl się za nami.
Przyczyno naszej radości, módl się za nami.
Przybytku Ducha Świętego, módl się za nami.
Przybytku chwalebny, módl się za nami.
Przybytku sławny pobożności, módl się za nami.
Różo duchowna, módl się za nami.
Wieżo Dawidowa, módl się za nami.
Wieżo z kości słoniowej, módl się za nami.
Domie złoty, módl się za nami.
Arko przymierza, módl się za nami.
Bramo niebieska, módl się za nami.
Gwiazdo zaranna, módl się za nami.
Uzdrowienie chorych, módl się za nami.
Ucieczko grzesznych, módl się za nami.
Pocieszycielko strapionych, módl się za nami.
Wspomożenie wiernych, módl się za nami.
Królowo Aniołów, módl się za nami.
Królowo Patriarchów, módl się za nami.
Królowo Proroków, módl się za nami.
Królowo Apostołów, módl się za nami.
Królowo Męczenników, módl się za nami.
Królowo Wyznawców, módl się za nami.
Królowo Dziewic, módl się za nami.
Królowo wszystkich Świętych, módl się za nami.
Królowo bez zmazy pierworodnej poczęta, módl się za nami.
Królowo wniebowzięta, módl się za nami.
Królowo różańca świętego, módl się za nami.
Królowo rodzin, módl się za nami.
Królowo pokoju, módl się za nami.
Królowo Polski, módl się za nami.
 
Baranku Boży, który gładzisz grzechy świata, przepuść nam Panie.
Baranku Boży, który gładzisz grzechy świata, wysłuchaj nas Panie
Baranku Boży, który gładzisz grzechy świata, zmiłuj się nad nami.

K. Módl się za nami, Święta Boża Rodzicielko.
W. Abyśmy się stali godnymi obietnic Chrystusowych.

Módlmy się. Panie, nasz Boże, daj nam, sługom swoim, cieszyć się trwałym zdrowiem duszy i ciała, i za wstawiennictwem Najświętszej Maryi, zawsze Dziewicy,  uwolnij nas od doczesnych utrapień i obdarz wieczną radością. Przez Chrystusa, Pana naszego. Amen.

Muzyka:  https://soundcloud.com/dyallas
_______________________________________
Tu nas można wesprzeć: https://patronite.pl/langustanapalmie 

Więcej nagrań o. Adama znajdziesz na:  
http://www.langustanapalmie.pl 

Można nas również znaleźć na:
Facebooku: https://www.facebook.com/LangustaNaPalmie 
Twitterze: https://twitter.com/LangustaPalmowa 
Instagramie: https://www.instagram.com/langustanapalmie 

Zapraszamy.

## Wstawaki [#488] Transfuzja
 - [https://www.youtube.com/watch?v=tvKOoUmIQIw](https://www.youtube.com/watch?v=tvKOoUmIQIw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2020-04-25 00:00:00+00:00

#Wstawaki #zróbmydobrydzień #AdamSzustakOP

Zapraszamy na nowy portal 
→ http://www.dominikanie.pl
Polecamy subskrypcje portalu na YT
→ https://www.youtube.com/c/Dominikanieplportal  
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/dominikanie

Więcej nagrań o. Adama znajdziesz na: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

