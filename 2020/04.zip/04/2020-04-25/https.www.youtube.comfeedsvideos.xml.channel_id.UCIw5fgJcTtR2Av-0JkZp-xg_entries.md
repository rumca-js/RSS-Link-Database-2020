# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## COVID-19 ("Blow The Wind" Remix)
 - [https://www.youtube.com/watch?v=RAm_ySvjsUg](https://www.youtube.com/watch?v=RAm_ySvjsUg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2020-04-25 00:00:00+00:00

Support my music on Patreon: https://www.patreon.com/yuriwong Watch more remixes: https://www.youtube.com/playlist?list=PLt2eCVD-XR3OA0iHPSF6TypN1zOljswpT

American televangelist Kenneth Copeland, who recently claimed that the coronavirus pandemic will be “over much sooner you think”, has summoned the “wind of God” to destroy the novel coronavirus during a recent sermon.

Before blowing at the camera, he said: ”I blow the wind of God on you. You are destroyed forever, and you’ll never be back. Thank you, God. Let it happen. Cause it to happen.”

Leading a chant surrounded by members of his church and preaching to an empty room, he called out: “Wind, almighty, strong, south wind, Heat: Burn this thing, in the name of Jesus. I say, you bow your knees. You fall on your face.”

In a sermon last month, the pastor “executed judgment” on Covid-19, which he declared ”finished” and “over” and made the US ”healed and well again.”

