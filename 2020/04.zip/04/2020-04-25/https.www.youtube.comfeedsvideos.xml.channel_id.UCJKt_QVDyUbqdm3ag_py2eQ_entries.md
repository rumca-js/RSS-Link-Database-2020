# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga music: cTrix - gmz (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=kGYPpOgy9rA](https://www.youtube.com/watch?v=kGYPpOgy9rA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-04-26 00:00:00+00:00

"gmz" by cTrix (Chris Mylrae). Art "Metal Girl" by Fox, 25th at The Party 1992. This upload is intended for headphones only.

cTrix on Youtube:
https://www.youtube.com/user/debuglive

...and on SoundCloud:
https://soundcloud.com/ctrix

Made using real A1200 audio. A recapped Rev 1D.4 (AWK 364720-04) mobo with resistors R321 and R331 = 680 ohms. More info about these two resistors here (RetroGameModz):
https://www.youtube.com/watch?v=7sZ7vLcURK4&t=0s

Visit my channel for more Amiga music.

