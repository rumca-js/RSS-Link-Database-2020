# Source:Hugh Jeffreys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA, language:en-US

## Fixing My Filthy Overheating MacBook Pro
 - [https://www.youtube.com/watch?v=zC-0MhPsCmk](https://www.youtube.com/watch?v=zC-0MhPsCmk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA
 - date published: 2020-04-25 00:00:00+00:00

Its time I addressed my MacBook which is reaching temperatures over 90 degrees!
--------------------------------------Socials-------------------------------------
Website: https://www.hughjeffreys.com 
Twitter: https://twitter.com/hughjeffreys
Instagram: http://instagram.com/hughjeffreys
---------------------------------------Links---------------------------------------
Federico: https://www.logicboardrepair.london | https://www.instagram.com/federicocerva
Macs Fan Control: https://crystalidea.com/macs-fan-control

Get parts, tools, and thousands of free repair guides from iFixit at: 
    https://iFixit.com/hughjeffreys
Australia Store: https://ifix.gd/2FPxhKy
(DISCLAIMER: This description contains affiliate links, which means that if you click on one of the product links, l will receive a small commission.)

