# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week #13: Komu wolno jeździć autobusem? A także Fortnite, iPad Pro M1, Canon EOS R5
 - [https://www.youtube.com/watch?v=b3ZkTVCkAfA](https://www.youtube.com/watch?v=b3ZkTVCkAfA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2020-04-26 00:00:00+00:00

Oraz gdzie na koncert i jakie lokale są otwarte? A także: co potrafi narysować sztuczna inteligencja.
Czapki jeszcze są, ale już się kończą: https://znosne.pl
Moje sociale: insta: http://bit.ly/InstaKlawiatur Tu Twitter: http://bit.ly/TTKlawitera i FB: http://bit.ly/FBKlawiatur.

Źródła: 
Pokoje na messengerze: https://bit.ly/2VXEnn8
Travis Scott w Fortnite: https://bit.ly/2zxi6F7
Sztuczna inteligencja rysuje penisy: https://bit.ly/2Y6iVyY
Sztuczny pies w szpitalu: https://bit.ly/2Sp3f6n
Nowy iPad Pro: https://apple.co/2S8v4j3
NASA apeluje: https://bit.ly/2y00gtY
OnePlus zwalnia: https://bit.ly/2W0rRDm
Canon EOS R5: https://bit.ly/3bGB1LV
Drony mierzą temperaturę zdalnie: https://bit.ly/2VBdh66
Aplikacja pandemiczna zostanie zamknięta po pandemii: https://bit.ly/3aKVcal

