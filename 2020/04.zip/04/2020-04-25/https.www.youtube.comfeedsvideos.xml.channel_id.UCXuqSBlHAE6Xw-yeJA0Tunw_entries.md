# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## This Motorized Gaming Seat took THREE DAYS to set up...
 - [https://www.youtube.com/watch?v=Q2wAsxbLyMM](https://www.youtube.com/watch?v=Q2wAsxbLyMM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-04-26 00:00:00+00:00

It takes a bit and if you're willing to put in the work, the YAW VR can up your level of immersion in the gaming world!

Check out Yaw VR at https://www.yawvr.com/

Buy a VR Headset:
On Amazon (PAID LINK): https://geni.us/PdEWmD
On Newegg (PAID LINK): https://geni.us/s33fKoR
On B&H (PAID LINK): https://geni.us/FOAs

Buy VR Accessories:
On Amazon (PAID LINK): https://geni.us/rH7ljL
On Newegg (PAID LINK): https://geni.us/ITMDU

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1184498-this-gaming-seat-took-three-days-to-set-up/

GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Support a Creator code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Test Benches on Amazon: https://lmg.gg/HOx0z
Our Production Gear: https://lmg.gg/4oPzt
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

## The New MacBook Air’s Biggest Problem
 - [https://www.youtube.com/watch?v=5hMie-xZFzQ](https://www.youtube.com/watch?v=5hMie-xZFzQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-04-25 00:00:00+00:00

The 2020 MacBook Air gets a lot of things right, but is it enough to beat the XPS 13 or Spectre x360?

Buy Macbook Air
On Amazon (PAID LINK): https://geni.us/hvsDK
On Newegg: https://geni.us/zDlm7

Buy Dell XPS 13
On Amazon (PAID LINK): https://geni.us/ccBlms
On Newegg: https://geni.us/ThjiP2s

Buy HP Spectre x360
On Amazon (PAID LINK): https://geni.us/jU8l
On Newegg: https://geni.us/9yHM

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1183968-the-macbook-air%E2%80%99s-biggest-problem/

GET MERCH: http://www.LTTStore.com/
SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Support a Creator code LINUSMEDIAGROUP on Epic Games Store: https://lmg.gg/kRTpY
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v
Our Test Benches on Amazon: https://lmg.gg/HOx0z
Our Production Gear: https://lmg.gg/4oPzt
 
FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
Carpool Critics: https://lmg.gg/carpoolcriticsyt

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

