# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Dresden Files Cover Reveal!🔮 ATLA Coming to Netflix🔥 Special Edition ASOIAF 📚- FANTASY NEWS
 - [https://www.youtube.com/watch?v=HBuX2DQxym4](https://www.youtube.com/watch?v=HBuX2DQxym4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-04-26 00:00:00+00:00

Let’s just get to the Fantasy News shall we?
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

Spiderverse Update - https://www.instagram.com/p/B_YXbZADNM7/?igshid=dbjym1ho8wb5

Battle Ground Cover Reveal: https://www.reddit.com/r/Fantasy/comments/g7i3y3/surprise_rfantasy_exclusive_cover_reveal_for_jim/?utm_medium=android_app&utm_source=share

Dr. Strange Delay: https://twitter.com/thr/status/1253811013792804866?s=12

Spider-Man Delay: https://variety.com/2020/film/news/spider-man-sequels-delayed-1234589657/

New Ryan Reynolds sci-fi project: https://www.hollywoodreporter.com/amp/heat-vision/ryan-reynolds-shawn-levy-reteam-time-travel-movie-1291613?__twitter_impression=true

Special Edition Dresden Files Book: https://www.penguinrandomhouse.com/books/301616/storm-front-by-jim-butcher/9780593199947

Wheel Of Time Read Along: https://twitter.com/WOTonPrime/status/1253715327478718465

Jaskier Reads The Witcher: https://www.youtube.com/watch?v=0AQBanTw60w

Great Fantasy Debate: https://www.eventbrite.com/e/the-great-fantasy-debate-preview-party-tickets-102905539238

Avatar The Last Airbender on Netflix: https://twitter.com/NXOnNetflix/status/1253432206070108160

23 D&D books pay what you want: https://www.tor.com/2020/04/23/23-dungeons-dragons-ebooks-are-now-pay-what-you-want-thanks-to-humble-bundle/

Westworld Season 4: https://www.hollywoodreporter.com/live-feed/westworld-renewed-season-4-at-hbo-1291307

Folio Society A Clash Of Kings: https://www.foliosociety.com/row/a-clash-of-kings.html

## TIGANA - REVIEW (Spoiler Free)
 - [https://www.youtube.com/watch?v=rXqMu7rrW1Q](https://www.youtube.com/watch?v=rXqMu7rrW1Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-04-25 00:00:00+00:00

My review of Guy Gavriel Kay's Tigana. A stand alone fantasy book that is damn near perfection in my opinion! 
You can get the book here: https://amzn.to/3bAaa3T

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Twitch: https://www.twitch.tv/fantasynews
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

