# Source:BezPlanu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g, language:pl-PL

## Obóz dla uchodźców - Rwanda
 - [https://www.youtube.com/watch?v=Jp2x3EEnPFc](https://www.youtube.com/watch?v=Jp2x3EEnPFc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g
 - date published: 2020-04-25 00:00:00+00:00

Wszystkie odcinki chronologicznie: http://bit.ly/2MqAO7Q
(można też klikać w kartę "Następny odcinek" pojawiającą się pod koniec każdego filmu po prawej stronie u góry) 

Opuszczamy Kigali i ruszamy na północ zapakowani do malutkiego busika, w tym jedna z dwóch dużych walizek, jakie niezbyt rozsądnie postanowiłem zabrać do Afryki. Podróż do Gihembe - o którym zaraz opowiemy - trwa ponad godzinę. Drogę urozmaicają nam stare rwandyjskie piosenki

Obóz dla uchodźców Gihembe prawie w całości zamieszkały jest przez kongijskich uchodźców ocalałych po masakrze dokonanej  w innym  obozie:  Mudende, która miała miejsce w 1997 roku. Ten drugi, położony blisko Demokratycznej Republiki Konga obóz, został zaatakowany przez uzbrojone grupy Hutu, które przedostały się tam wtedy właśnie z tego kraju. Ich ofiarami padło blisko 300 Kongijczyków, etnicznie Tutsi, którzy znaleźli schronienie w Rwandzie. Po tym wydarzeniu cały obok został przeniesiony do Gihembe, dokąd właśnie dojeżdżamy. Obóz w Gihembe jest znany z tego, że zamiast dawać rybę, daje wędkę, stawia na rozwój inicjatywy gospodarczej swoich mieszańców. Właśnie dlatego Ania, która interesuje się tematyka pomocy humanitarnej, zaproponowała, żebyśmy tu przyjechali, na co chętnie przystałem

Linki o obozie w Gihembe (po angielsku):
https://www.kiva.org/blog/building-the-economy-within-rwandas-refugee-camps
https://www.irishtimes.com/news/survivors-of-refugee-camp-massacre-give-account-of-brutality-at-hands-of-hutus-1.137007
https://www.laprogressive.com/gihembe-refugee-camp/
https://www.unhcr.ca/news/refugee-and-sexual-violence-survivor-restores-hope-in-rwanda/
https://worldpix.org/causes-2/africa-2/rwanda/gihembe-refugee-camp/
https://www.academia.edu/5021315/Mudende_Trauma_and_Massacre_in_a_Refugee_Camp

Ania Markowska:
https://instagram.com/annmarelo

Pierwszy odcinek BezPlanu z Anią (miejsce: Bogota, Kolumbia):
http://bit.ly/31ZCE3l

Muzyka : Youth Novels - "Runaway" - dziękuję i polecam:
https://open.spotify.com/artist/3Mnsk5N6fdCc5svXTunb3D?si=UTBklZ5HRwOlKlDdVth1cg

Wsparcie na Patronite: http://bit.ly/2KsFTZk 
Instagram: http://instagram.com/bezplanu_czukesky 
Facebook: https://www.facebook.com/BezPlanu.tv 

Czas akcji: wrzesień 2019r.

Tłumaczenie na angielski: Michał Stadryniak
www.linkedin.com/in/michał-stadryniak-82b8491a6

