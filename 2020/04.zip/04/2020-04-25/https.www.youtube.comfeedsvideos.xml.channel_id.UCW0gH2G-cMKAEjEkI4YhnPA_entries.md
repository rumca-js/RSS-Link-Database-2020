# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Fili and Kili | Tolkien Explained - Dwarves of Erebor
 - [https://www.youtube.com/watch?v=XG-DnO7khEg](https://www.youtube.com/watch?v=XG-DnO7khEg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2020-04-26 00:00:00+00:00

We're taking a brief look at the lives of Fili and Kili - the sister-sons of Thorin Oakenshield.  Fili, being the eldest, is heir to Thorin's kingship.  The two are the youngest of the company by at least 50 years at the time of The Quest of Erebor.  This will the the shortest video in the series, as the brothers had tragically short lives themselves.

Hit subscribe - and the bell - so you never miss a video from Nerd of the Rings! 

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner. 

#thehobbit #tolkien #dwarves

