# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Ricky Gervais & Russell Brand: God VS Atheism - Full Episode
 - [https://www.youtube.com/watch?v=5Szj5jJeUec](https://www.youtube.com/watch?v=5Szj5jJeUec)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-04-25 00:00:00+00:00

#UnderTheSkin with #RickyGervais!
Get the Luminary app with this special promo code to get tO all the latest episodes of Under The Skin: http://lumninary.link/ricky

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at http://apple.co/russell 

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary.

SEE ME LIVE! Check out my live events and buy tickets here https://www.russellbrand.com/live-dates/ 

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/AwakeningWithRussell

Instagram: 
http://instagram.com/russellbrand/

Twitter: 
http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

