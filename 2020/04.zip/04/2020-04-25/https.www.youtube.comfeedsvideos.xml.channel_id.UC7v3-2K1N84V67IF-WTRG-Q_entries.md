# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Extraction - Movie Review
 - [https://www.youtube.com/watch?v=-smrSP5MrzE](https://www.youtube.com/watch?v=-smrSP5MrzE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-04-25 00:00:00+00:00

A NEW MOVIE REVIEW! So let's talk about the Nexflix action fest film EXTRACTION!

#Extraction

