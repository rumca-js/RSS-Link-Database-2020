# Source:KnowledgeHusk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw, language:en-US

## The Most Influential Song Of All Time
 - [https://www.youtube.com/watch?v=P2oBxOvfRe0](https://www.youtube.com/watch?v=P2oBxOvfRe0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw
 - date published: 2020-04-13 00:00:00+00:00

Modern people like modern music. There’s a reason for that, and a reason why how people perceive music is far different today than it was, say, 150 years ago. 
Basically, one song changed a lot. One song that hit the mark, really shifted how we wrote music. Cause inspiration drives inspiration and so on and so forth.

Either way, enjoy.�
Twitter: https://twitter.com/KnowledgeHubTy
Soundcloud: https://soundcloud.com/user-503704039
Patreon: https://www.patreon.com/theknowledgehub
Second Channel: https://www.youtube.com/channel/UC-KL04Ra6E1Du0pFawN4pWg

