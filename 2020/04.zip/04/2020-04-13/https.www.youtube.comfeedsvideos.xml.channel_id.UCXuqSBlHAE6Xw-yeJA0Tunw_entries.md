# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## It’s time to eat my words… OnePlus 8 and 8 Pro
 - [https://www.youtube.com/watch?v=Tri2WUiDNbo](https://www.youtube.com/watch?v=Tri2WUiDNbo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-04-14 00:00:00+00:00

Sign up for Private Internet Access VPN at https://lmg.gg/pialinus2

Thanks to Thermal Grizzly for sponsoring today's episode! Buy Thermal Grizzly Conductonaut on Amazon (PAID LINK) at https://lmg.gg/conductonaut

The OnePlus 8 and 8 Pro are here – literally, both are in North America for the first time! But with prices ranging from $700 to nearly $1,000 USD, is it still good value compared to an iPhone 11 or Pixel 4?

Check out the OnePlus 8 at https://lmg.gg/LGnoH
Check out the OnePlus 8 Pro at https://lmg.gg/c5VZN

Buy OnePlus Smartphones
On Amazon (PAID LINK): https://geni.us/CVoW    
On Newegg (PAID LINK): https://geni.us/Gpyy    
On BHPhoto (PAID LINK): https://geni.us/tfIRWc    

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1177812-it%E2%80%99s-time-to-eat-my-words%E2%80%A6-oneplus-8-and-8-pro/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Support a Creator code LINUSMEDIAGROUP on Epic Games Store: https://geni.us/G8iG71
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Get your ticket to LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

## I FINALLY Upgraded My Streaming Setup!
 - [https://www.youtube.com/watch?v=PGqU_stcXDw](https://www.youtube.com/watch?v=PGqU_stcXDw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2020-04-13 00:00:00+00:00

Visit https://www.squarespace.com/LTT and use offer code LTT for 10% off

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire

I've been streaming Anno 1800 a ton from home, but my setup has always been a bit lackluster, so it's time for an upgrade!

Buy the Rode Broadcaster Microphone:
On Newegg: https://geni.us/TZdPC
On Amazon: https://geni.us/Q9lA5J

Buy a Rode PSA1 Boom Arm: 
On Amazon: https://geni.us/B3PmOj
On Newegg: https://geni.us/87aR2cY

Buy a GoXLR XLR Interface
On Amazon: https://geni.us/Vh1zNJ

Buy an Elgato StreamDeck:
On Elgato.com: https://geni.us/AtgvQx
On Amazon: https://geni.us/6RFgY

Buy an Elgato Cam Link 4K:
On Elgato.com: https://geni.us/eesxT
On Amazon: https://geni.us/5QILN

Buy an Elgato Key Light Air:
On Elgato.com: https://geni.us/fNlVyd
On Amazon: https://geni.us/Hmign

Buy an Elgato Multi Mount:
On Elgato.com: https://geni.us/7jBnV7

Buy a Mini HDMI to HDMI Cable:
On Amazon: https://geni.us/Eg1OItd

Buy a Canon T6i Camera:
On Amazon: https://geni.us/UnRC
On B&H: https://geni.us/8CCDu

Buy a Canon T6i AC Adapter:
On Best Buy: https://shop-links.co/1721624333476888312
On Amazon: https://geni.us/JFpbr
On B&H: https://geni.us/AtNrml

Buy a Canon 24mm Lens:
On Best Buy: https://shop-links.co/1721624335159790357
On Amazon: https://geni.us/UB1Nuux
On B&H: https://geni.us/1lxtE4

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/main/topic/1177440-i-finally-upgraded-my-streaming-setup/

Our Affiliates, Referral Programs, and Sponsors: https://lmg.gg/sponsors
Get Private Internet Access VPN at https://lmg.gg/pialinus2
Get a Displate Metal Print at https://lmg.gg/displateltt
Support a Creator code LINUSMEDIAGROUP on Epic Games Store: https://geni.us/G8iG71
Get a 30-day free trial of Amazon Prime at https://lmg.gg/8KV1v

Linus Tech Tips merchandise at http://www.LTTStore.com/ 
Our Test Benches on Amazon: https://www.amazon.com/shop/linustechtips 
Our production gear: http://geni.us/cvOS
Get your ticket to LTX 2020: https://www.ltxexpo.com/

Twitter - https://twitter.com/linustech
Facebook - http://www.facebook.com/LinusTech
Instagram - https://www.instagram.com/linustech
Twitch - https://www.twitch.tv/linustech 

Intro Screen Music Credit:
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

