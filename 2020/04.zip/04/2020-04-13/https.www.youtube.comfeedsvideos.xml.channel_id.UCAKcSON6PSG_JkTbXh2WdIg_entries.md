# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Maggie Rogers  - On + Off (Live at The Current, 2017)
 - [https://www.youtube.com/watch?v=lV8y2W-6UmI](https://www.youtube.com/watch?v=lV8y2W-6UmI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-14 00:00:00+00:00

Maggie Rogers performs "On + Off" live at The Current, recorded in April, 2017. "On + Off" appears on Rogers' debut EP 'Now That the Light is Fading.'

PERSONNEL
Maggie Rogers, guitar, vocals
Dana LaMarca, percussion
Grant Zubritsky, keyboard
Alan Markley, keyboard

CREDITS
Video: Jules Ameel, Helen Teague
Audio: Michael DeMark,  Elijah Deaton-Berg

MORE FROM THIS SESSION
Dog Years https://youtu.be/8mvleHjAZcM
Alaska https://youtu.be/dfthiWHul60
Full session https://youtu.be/jf5QhiaBVHI

#indiepop #artpop

## Maggie Rogers -  Dog Years (Live at The Current, 2017)
 - [https://www.youtube.com/watch?v=8mvleHjAZcM](https://www.youtube.com/watch?v=8mvleHjAZcM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-14 00:00:00+00:00

Maggie Rogers performs "Dog Years" live at The Current, recorded in April, 2017. "Dog Years" appears on Rogers' debut EP 'Now That the Light is Fading.'

PERSONNEL
Maggie Rogers, guitar, vocals
Dana LaMarca, percussion
Grant Zubritsky, keyboard
Alan Markley, keyboard

CREDITS
Video: Jules Ameel, Helen Teague
Audio: Michael DeMark,  Elijah Deaton-Berg

MORE FROM THIS SESSION
On + Off https://youtu.be/lV8y2W-6UmI
Alaska https://youtu.be/dfthiWHul60
Full session https://youtu.be/jf5QhiaBVHI

#indiepop #artpop

## Maggie Rogers - Full performance (Live at The Current, 2017)
 - [https://www.youtube.com/watch?v=jf5QhiaBVHI](https://www.youtube.com/watch?v=jf5QhiaBVHI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-14 00:00:00+00:00

From The Current archives, we are sharing the full three-song session from Maggie Rogers, recorded in April 2017, fresh off the release of her debut EP, 'Now That the Light is Fading.'

Songs performed: 
00:00 Dog Years
04:05 On + Off
08:03 Alaska

PERSONNEL
Maggie Rogers, guitar, vocals
Dana LaMarca, percussion
Grant Zubritsky, keyboard
Alan Markley, keyboard

CREDITS
Video: Jules Ameel, Helen Teague
Audio: Michael DeMark,  Elijah Deaton-Berg

MORE FROM THIS SESSION
Dog Years https://youtu.be/8mvleHjAZcM
On + Off https://youtu.be/lV8y2W-6UmI
Alaska https://youtu.be/dfthiWHul60

#indiepop #artpop

## Will big concerts return before 2021? (The Current Music News)
 - [https://www.youtube.com/watch?v=3Ox9JXDsqlg](https://www.youtube.com/watch?v=3Ox9JXDsqlg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-14 00:00:00+00:00

April 14, 2020: The music world is buzzing about a New York Times report that cites a health expert questioning whether shows with big crowds can safely return before fall 2021. Also in the news today: Live Nation CEO gives up his $3 million salary, and Drake matches a Mariah Carey chart feat. Plus, what was the most-played song of the 2010s in the United Kingdom? The answer might give you...a feeling.
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Coachella cancellation upends festival fashion industry
 - [https://www.youtube.com/watch?v=lZyBs2CF77U](https://www.youtube.com/watch?v=lZyBs2CF77U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2020-04-13 00:00:00+00:00

April 13, 2020: With Coachella off, the festival fashion industry has been disrupted. Also off: Burning Man, though organizers are going to try to convene their crowd online. Meanwhile Sturgill Simpson reveals he had COVID-19, and Caroline Polachek believes she likely did. Paul McCartney's handwritten 'Hey Jude' lyrics sold for $910,000, and 'Saturday Night Live' paid tribute to the late Hal Willner.
Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

