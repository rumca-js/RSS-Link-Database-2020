# Source:Jeff Gerling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg, language:en-US

## Drupal 7 to 8 LIVE Migration - Ep 11 - Migrating redirects
 - [https://www.youtube.com/watch?v=Le82L7EAcaY](https://www.youtube.com/watch?v=Le82L7EAcaY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg
 - date published: 2020-04-14 00:00:00+00:00

In this eleventh livestream, we worked on migrating redirects to preserve URLs and prevent link rot, and quickly realized how much OBS streaming software hurt the performance of Jeff's laptop, to the point where opening files was taking many seconds!

Support me on Patreon: https://www.patreon.com/geerlingguy

Sponsor me on GitHub: https://github.com/sponsors/geerlingguy

See more: https://www.jeffgeerling.com/blog/2020/migrating-jeffgeerlingcom-drupal-7-drupal-8-how-video-series

