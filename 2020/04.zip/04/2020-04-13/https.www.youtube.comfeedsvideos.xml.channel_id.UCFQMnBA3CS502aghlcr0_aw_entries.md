# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Bill Gates is CANCELLED 😡😡😡
 - [https://www.youtube.com/watch?v=tvOzCMe0t-k](https://www.youtube.com/watch?v=tvOzCMe0t-k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2020-04-14 00:00:00+00:00

one of the stranger tides of the internet... 
please insert your preexisting opinion in the complement section.

bill gates is cancelled for some reason, mostly due to people citing easily refuted, out-of-context TED Talks clips and an "event 201"

Ellen Show clip where they had to remove public comments - https://www.youtube.com/watch?v=5oEcxMfwJnw&
Event 201 & Bill Gates - http://www.centerforhealthsecurity.org/event201/scenario.html
People have been predicting pandemics forever - https://www.businessinsider.com/people-who-seemingly-predicted-the-coronavirus-pandemic-2020-3#self-proclaimed-psychic-sylvia-browne-was-also-said-to-have-predicted-a-global-pandemic-similar-to-the-coronavirus-9

