# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## The (Not) Final Analysis | Yahtzee's Dev Diary
 - [https://www.youtube.com/watch?v=a-n5wbeXCe8](https://www.youtube.com/watch?v=a-n5wbeXCe8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-04-14 00:00:00+00:00

VOTE ON YOUR FAVORITE DEV DIARY GAME: https://www.strawpoll.me/19749852

DOWNLOAD BUNKER BUSTIN - https://yzcroshaw.itch.io/bunker-bustin

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►► https://sharkrobot.com/collections/zero-punctuation 

Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 

Like us on Facebook ►► http://www.facebook.com/EscapistMag

Follow us on Twitter ►► https://twitter.com/EscapistMag

## Yahtzee's Dev Diary - Jack Provides A Final Playtest of Bunker Bustin
 - [https://www.youtube.com/watch?v=oSwrdBGM5Qs](https://www.youtube.com/watch?v=oSwrdBGM5Qs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-04-14 00:00:00+00:00

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Jack Packard tries Yahtzee's final Dev Diary project, Bunker Bustin. 

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►► https://sharkrobot.com/collections/zero-punctuation 

Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 

Like us on Facebook ►► http://www.facebook.com/EscapistMag

Follow us on Twitter ►► https://twitter.com/EscapistMag

## Should Games Like Dark Souls Have Difficulty Settings? | Slightly Civil War
 - [https://www.youtube.com/watch?v=ZVCWyMtQt3g](https://www.youtube.com/watch?v=ZVCWyMtQt3g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2020-04-13 00:00:00+00:00

DOWNLOAD THE PODCAST: https://www.buzzsprout.com/987874/3251902

WATCH EPISODE 2 - Is Breath of the Wild Really As Good As Everyone Says It Is? https://www.escapistmagazine.com/v2/was-the-legend-of-zelda-breath-of-the-wild-really-that-good-slightly-civil-war/

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Welcome to the series premiere of Slightly Civil War, a humorous video game debate show featuring Yahtzee Croshaw and Jack Packard!

Inspired by the fan-favorite Escapist show, Uncivil War, Yahtzee and Jack will be randomly assigned a position on a contentious video game topic and head to battle to make their point. This week is about difficulty settings in games like Dark Souls.

Episodes will air each week on Monday at noon EDT and the following Monday on YouTube.

There will also be a companion podcast for the show where Yahtzee and Jack discuss their true thoughts on the subject debated in the video.

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►► https://sharkrobot.com/collections/zero-punctuation 

Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 

Like us on Facebook ►► http://www.facebook.com/EscapistMag

Follow us on Twitter ►► https://twitter.com/EscapistMag

