# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Resident Evil 4 Remake: 7 Things We DON'T WANT
 - [https://www.youtube.com/watch?v=stzOGM-fePo](https://www.youtube.com/watch?v=stzOGM-fePo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-04-14 00:00:00+00:00

If the rumored Resident Evil 4 remake is destined to happen, here are some things we don't want Capcom to do.
Subscribe for more: http://youtube.com/gameranxtv

## Final Fantasy 7: Top 10 Secrets, Easter Eggs & References
 - [https://www.youtube.com/watch?v=nLRKH-gYhmc](https://www.youtube.com/watch?v=nLRKH-gYhmc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2020-04-13 00:00:00+00:00

The Final Fantasy VII Remake is filled with tons of exciting Easter eggs, references, and callbacks to the beloved series. Here are some of our favorite examples.
Subscribe for more: http://youtube.com/gameranxtv

