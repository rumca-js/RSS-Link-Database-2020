# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Matthew Dear - Bad Ones (Live on KEXP)
 - [https://www.youtube.com/watch?v=PBznmv6FPmQ](https://www.youtube.com/watch?v=PBznmv6FPmQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-04-13 00:00:00+00:00

http://KEXP.ORG presents Matthew Dear performing "Bad Ones" live in the KEXP studio. Recorded December 18, 2019.

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
http://www.matthewdear.com

## Matthew Dear - Deserter (Live on KEXP)
 - [https://www.youtube.com/watch?v=R05qttl4Ids](https://www.youtube.com/watch?v=R05qttl4Ids)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-04-13 00:00:00+00:00

http://KEXP.ORG presents Matthew Dear performing "Deserter" live in the KEXP studio. Recorded December 18, 2019.

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
http://www.matthewdear.com

## Matthew Dear - Echo (Live on KEXP)
 - [https://www.youtube.com/watch?v=pDvSlmeExM8](https://www.youtube.com/watch?v=pDvSlmeExM8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-04-13 00:00:00+00:00

http://KEXP.ORG presents Matthew Dear performing "Echo" live in the KEXP studio. Recorded December 18, 2019.

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
http://www.matthewdear.com

## Matthew Dear - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=MQ2xD1EjldA](https://www.youtube.com/watch?v=MQ2xD1EjldA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-04-13 00:00:00+00:00

http://KEXP.ORG presents Matthew Dear performing live in the KEXP studio. Recorded December 18, 2019.

Songs:
Modafinil Blues
Bad Ones
Echo
Deserter

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann & Justin Wilmore
Editor: Justin Wilmore

Thumbnail photo by Alley Rutzel

http://kexp.org
http://www.matthewdear.com

## Matthew Dear - Modafinil Blues (Live on KEXP)
 - [https://www.youtube.com/watch?v=r2KZgABnG9Y](https://www.youtube.com/watch?v=r2KZgABnG9Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2020-04-13 00:00:00+00:00

http://KEXP.ORG presents Matthew Dear performing "Modafinil Blues" live in the KEXP studio. Recorded December 18, 2019.

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Cameras: Jim Beckmann & Justin Wilmore
Editor: Justin Wilmore

http://kexp.org
http://www.matthewdear.com

