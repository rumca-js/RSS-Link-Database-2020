# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## DRESDEN FILES BOOKS RANKED!
 - [https://www.youtube.com/watch?v=0Qpapq6KI8g](https://www.youtube.com/watch?v=0Qpapq6KI8g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-04-14 00:00:00+00:00

My ranking of every Dresden Files Book! Let me know what your ranking would be either in the comments down below of tweet them at me. :) 
Create Your Own List Here: https://tiermaker.com/create/dresden-files-books-143444
Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

## The Fires of Vengeance COVER REVEAL! The Burning Book 2 - Fantasy Chat
 - [https://www.youtube.com/watch?v=kzvE1Kbpz0A](https://www.youtube.com/watch?v=kzvE1Kbpz0A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2020-04-13 00:00:00+00:00

I had the pleasure of sitting down with Even Winter again to roll out the cover for the sequel to Rage of Dragons, The Fires of Vengeance. Book 2 in The Burning series.
Preorder Link: https://amzn.to/3a7g5MB
You can check out the cover in all its glory here: https://imgur.com/a/wYotsie
Order Rage of Dragons here: https://amzn.to/3a2FXc7
Evan’s Twitter: https://twitter.com/EvanWinter

Merch: https://teespring.com/stores/fantasy-news-2
Patreon: https://www.patreon.com/DanielBGreene
Amazon: https://www.amazon.com/shop/danielgreene
Discord Server: https://discord.gg/xUzhVv4
Twitter: https://twitter.com/DanielBGreene?lang=en
Instagram: https://www.instagram.com/dgreene101/
GoodReads: https://www.goodreads.com/user/show/82239739-daniel-greene
Subreddit: https://www.reddit.com/r/danielgreene

