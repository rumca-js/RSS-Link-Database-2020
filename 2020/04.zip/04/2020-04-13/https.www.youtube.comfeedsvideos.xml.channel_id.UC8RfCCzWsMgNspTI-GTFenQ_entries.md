# Source:Luetin09, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC8RfCCzWsMgNspTI-GTFenQ, language:en-US

## 40K - I WAS RIGHT ABOUT ABADDON!!  & OTHER STUPID PRONUNCIATIONS | Lore Lite Discuss
 - [https://www.youtube.com/watch?v=7eQEz3HHqvM](https://www.youtube.com/watch?v=7eQEz3HHqvM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC8RfCCzWsMgNspTI-GTFenQ
 - date published: 2020-04-13 00:00:00+00:00

► Subscribe: http://goo.gl/oeZMBS 
► Patreon: https://www.patreon.com/Luetin
► Siege Studios: https://siegestudios.co.uk/
► Goblin Gaming: (Get - 20% off 40K Products) https://tinyurl.com/6vwcayvj
► Premium Storage Solutions: https://www.crystal-fortress.com/
► Twitch: http://www.twitch.tv/Luetin
► Twitter: http://twitter.com/luetin09

► BGM Credits:
► Kevin MacLeod (Royalty Free Music): http://incompetech.com/music/
► https://epidemicsound.com

This video is an opinion editorial commentary.
Copyright Disclaimer Under Section 107 of the Copyright Act 1976, allowance is made for fair use purposes such as criticism, commentary, parody, news reporting, teaching, scholarship, and research.

All works used in this video (Images, audio etc) belong to their respective authors
(This does not include the audio commentary or licensed BGM).

Games workshop, Warhammer 40,000, Warhammer, 40k, Space Marine Etc are all Trademarks of Games Workshop Ltd. Games Workshop does not endorse or support the 'Lore' videos. All views and opinions expressed in this video belong to Luetin09 and in no way reflect the views or opinions of Games Workshop Ltd.

## 40K - MALICE/MALAL - THE 5TH GOD OF CHAOS & RENEGADE ASTARTES | Warhammer 40,000 Lore/History
 - [https://www.youtube.com/watch?v=TXwMUjqH7mA](https://www.youtube.com/watch?v=TXwMUjqH7mA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC8RfCCzWsMgNspTI-GTFenQ
 - date published: 2020-04-13 00:00:00+00:00

► Subscribe: http://goo.gl/oeZMBS 
► Patreon: https://www.patreon.com/Luetin 
► Siege Studios: https://siegestudios.co.uk/
► Goblin Gaming: (Get - 20% off 40K Products) https://tinyurl.com/6vwcayvj
► Premium Storage Solutions: https://www.crystal-fortress.com/
► Twitch: http://www.twitch.tv/Luetin
► Twitter: http://twitter.com/luetin09

Read Labyrinth and the Sons of Malice from BL: https://www.blacklibrary.com/warhammer-40000/quick-reads/the-labyrinth-ebook.html

 ► BGM Credits:
► https://epidemicsound.com
► Kevin MacLeod (Royalty Free Music): http://incompetech.com/music/

This video is an opinion editorial commentary.
Copyright Disclaimer Under Section 107 of the Copyright Act 1976, allowance is made for fair use purposes such as criticism, commentary, parody, news reporting, teaching, scholarship, and research.

All works used in this video (Images, audio etc) belong to their respective authors
(This does not include the audio commentary or licensed BGM).

Games workshop, Warhammer 40,000, Warhammer, 40k, Space Marine Etc are all Trademarks of Games Workshop Ltd. Games Workshop does not endorse or support the 'Lore' videos. All views and opinions expressed in this video belong to Luetin09 and in no way reflect the views or opinions of Games Workshop Ltd.

