# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## This is now the BEST VR Headset available
 - [https://www.youtube.com/watch?v=EDGyDZvrZWA](https://www.youtube.com/watch?v=EDGyDZvrZWA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2020-04-14 00:00:00+00:00

Hello and welcome to: TUESDAY NEWSDAY! Your number one resource for the entire weeks worth of VR News. 

Links:
My Stream:
https://www.twitch.tv/thrilluwu
Join my discord for good times
https://discord.gg/thrill
Patreon link:Join
https://www.patreon.com/Thrillseeker

20% off for TODAY ONLY: GAMERSUPPS Discount Code: THRILL
http://gamersupps.gg/?afmc=thrill

Things I cover today: 
Air guitar Oculus Quest game:
https://uploadvr.com/unplugged-air-guitar-quest/

Etee Steam VR Controllers with finger tracking:
https://www.roadtovr.com/etee-steamvr-controller-half-life-alyx-gameplay-qa/
https://www.kickstarter.com/projects/tg0/etee-complete-control-in-3d/


StarVR One VR headset:
https://www.roadtovr.com/starvr-one-launch-acer-starbreeze/

Meme Break:
https://www.reddit.com/r/VR_memes/comments/fwr6cq/i_tried/

Half Life Alyx Mod:
https://uploadvr.com/half-life-alyx-xenthung-mod/

Echo Arena coming to quest/ Lone Echo 2 delayed:
https://www.roadtovr.com/lone-echo-2-release-date-further-delayed/

Swords of Gurrah: 
https://store.steampowered.com/app/833090/Swords_of_Gurrah/

