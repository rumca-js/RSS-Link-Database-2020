# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Dori, Nori, & Ori | Tolkien Explained - Dwarves of Erebor
 - [https://www.youtube.com/watch?v=Jthp7Bu8NeI](https://www.youtube.com/watch?v=Jthp7Bu8NeI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2020-04-14 00:00:00+00:00

The first in a series of videos covering the Dwarves of Thorin’s Company.  Today, we cover brothers Dori, Nori, and Ori from their origins in the Blue Mountains to their post-Quest of Erebor adventures in Moria and the Battle of Dale.  Since details are scarce on some of the dwarves, we will look to the Peter Jackson adaptations for further background details.  My hope is that this will help enrich our enjoyment of these characters in The Hobbit Trilogy.

Hit subscribe - and the bell - so you never miss a video from Nerd of the Rings! 

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner. 

The Hobbit: An Unexpected Journey Chronicles II: Characters and Creatures by Daniel Falconer
Bag End – Wictorian Art
Ori – Fantasy Flight Games
Dori carries Bilbo – Fantasy Flight Games

#thehobbit #tolkien #dwarves

