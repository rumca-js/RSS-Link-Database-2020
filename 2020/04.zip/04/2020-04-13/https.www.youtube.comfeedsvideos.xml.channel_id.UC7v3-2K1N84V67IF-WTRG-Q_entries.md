# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Night Trap: The GREATEST "Bad" Game of All Time!
 - [https://www.youtube.com/watch?v=bswEiQIqk-Y](https://www.youtube.com/watch?v=bswEiQIqk-Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2020-04-13 00:00:00+00:00

I have a love for the entertainingly cheesy. This includes video games. Especially this cult classic that was wrongfully annexed into the great "violent video games" debate of the early 90's. Here are my thoughts of the infamous video game NIGHT TRAP!

Watch the documentary "Night Trap: 25 Years Later" here: https://www.youtube.com/watch?v=df2zptiviBo&t=933s

#NightTrap

