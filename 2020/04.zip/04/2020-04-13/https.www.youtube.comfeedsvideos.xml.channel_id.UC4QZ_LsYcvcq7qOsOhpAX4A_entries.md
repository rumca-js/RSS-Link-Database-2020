# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## COVID-19 - How Tech is Helping
 - [https://www.youtube.com/watch?v=KEG_sQrXtzE](https://www.youtube.com/watch?v=KEG_sQrXtzE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2020-04-13 00:00:00+00:00

Part 2 of our look at COVID-19
Previous video: https://youtu.be/RFnSmcfKWQo
--- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. 

If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- New Thinking Book written by Dagogo Altraide ---
Learn the stories of those who invented the things we use everyday.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

--- ColdFusion Social Media ---
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusionTV

--- ColdFusion Podcast links ---
Google Podcasts - http://bit.ly/2xo8doR
Apple Podcasts - https://apple.co/2WI2IeU
Spotify - https://spoti.fi/2KT1taB
Stitcher - http://bit.ly/2WI4f4E

Sources:

 https://techcrunch.com/2020/03/19/open-source-project-spins-up-3d-printed-ventilator-validation-prototype-in-just-one-week/

https://smallcaps.com.au/resapp-coviu-provide-remote-respiratory-tests-telehealth-platform/

https://nextstrain.org/

https://twitter.com/LuxSecond/status/1246319869177421826?s=20

https://smartairfilters.com/en/blog/best-materials-make-diy-face-mask-virus/

https://www.bbva.com/en/technology-against-coronavirus/

https://www.youtube.com/watch?v=zZbDg24dfN0&feature=youtu.be

https://www.weforum.org/agenda/2020/03/asia-technology-coronavirus-covid19-solutions

https://www.independent.co.uk/news/world/europe/coronavirus-spain-police-lockdown-drones-latest-cases-a9403771.html

https://qz.com/1816762/coronavirus-hong-kongs-mtr-subway-uses-robot-to-disinfect-trains/

https://www.aljazeera.com/news/2020/03/urges-world-test-test-test-covid-19-live-updates-200316234425373.html

https://thenextweb.com/neural/2020/03/02/alibabas-new-ai-system-can-detect-coronavirus-in-seconds-with-96-accuracy/

https://www.gpsworld.com/china-fights-coronavirus-with-delivery-drones/

https://www.bbc.com/news/technology-51717164

https://www.zdnet.com/article/google-deepminds-effort-on-covid-19-coronavirus-rests-on-the-shoulders-of-giants/

https://edition.cnn.com/2020/03/19/tech/netflix-internet-overload-eu/index.html

https://www.nytimes.com/2020/03/17/technology/china-schools-coronavirus.html


//Soundtrack//

Oren Lavie - locked in a room

Grifta – Dawn

Siarate – Float

Roald Velden – Peaceful

Hiatus - As Close To Me As You Are Now

Paddy Mulcahy - On A Hill In Swinford

BUCK UK // Once

Owen - Bad News

Burn Water - Hold On (Unreleased) 

» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide

Why are you still reading?

