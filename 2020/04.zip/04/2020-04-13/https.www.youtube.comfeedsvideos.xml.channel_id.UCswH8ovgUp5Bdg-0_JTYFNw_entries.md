# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Is Your Life Your Prison?! | Russell Brand Podcast
 - [https://www.youtube.com/watch?v=G3wVe2vMAXs](https://www.youtube.com/watch?v=G3wVe2vMAXs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2020-04-14 00:00:00+00:00

A clip from today's Under The Skin podcast with the incredible thinker and philosopher (though he wouldn't call himself that) Charles Eisenstein.
You need to listen to this entire conversation, particularly if this clip has resonated with you in any way.
I was particularly inspired by Charles's latest essay The Coronation - you can read it here: https://charleseisenstein.org/essays/the-coronation/

Subscribe to my channel here: http://tinyurl.com/opragcg
(make sure to hit the BELL icon to be notified of new videos!)

Listen to my Under The Skin podcast here: 
http://luminary.link/russell

Get my book "Recovery" here: https://amzn.to/2R7c810
Get my book "Mentors" here (and as an audiobook!): https://amzn.to/2t0Zu9U

Instagram: http://instagram.com/russellbrand/
Twitter: http://twitter.com/rustyrockets

Produced by Jenny May Finn (Instagram: @jennymayfinn)

