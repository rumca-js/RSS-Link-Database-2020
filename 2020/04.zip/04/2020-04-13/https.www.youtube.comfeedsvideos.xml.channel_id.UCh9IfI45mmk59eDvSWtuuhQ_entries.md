# Source:Ryan George, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ, language:en-US

## The First Guy To Ever Make A Friend
 - [https://www.youtube.com/watch?v=ajAFuCkpTXY](https://www.youtube.com/watch?v=ajAFuCkpTXY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ
 - date published: 2020-04-13 00:00:00+00:00

Go to https://buyraycon.com/ryangeorge for 15% off your order! Brought to you by Raycon.
Subscribe: http://bit.ly/2wscuFf
Twitter/Instagram: @TheRyanGeorge

Hi there hello good news I have chosen you as a person that I want to hang out with and warn when large animals are nearby.

