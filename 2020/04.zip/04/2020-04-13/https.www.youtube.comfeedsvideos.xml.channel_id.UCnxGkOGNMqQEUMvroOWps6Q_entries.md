# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Alex Jones Has Been Texting Joe About the Coronavirus
 - [https://www.youtube.com/watch?v=e65jDjZE4lg](https://www.youtube.com/watch?v=e65jDjZE4lg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-14 00:00:00+00:00

Taken from Joe Rogan Experience #1457 w/Tim Dillon:
https://youtu.be/ig9yh8iVZWI

## Bill Gates' Vaccine Initiative, Good or Bad? w/Tim Dillon  | Joe Rogan
 - [https://www.youtube.com/watch?v=Abm5nn8chKw](https://www.youtube.com/watch?v=Abm5nn8chKw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-14 00:00:00+00:00

Taken from Joe Rogan Experience #1457 w/Tim Dillon:
https://youtu.be/ig9yh8iVZWI

## Joe Biden's New Sexual Assault Allegations | Joe Rogan
 - [https://www.youtube.com/watch?v=4n-EP1t7jpU](https://www.youtube.com/watch?v=4n-EP1t7jpU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-14 00:00:00+00:00

Taken from Joe Rogan Experience #1457 w/Tim Dillon:
https://youtu.be/ig9yh8iVZWI

## Tim Dillon Rants About His Time Working on a Cruise Ship
 - [https://www.youtube.com/watch?v=fmSpQq60-Ls](https://www.youtube.com/watch?v=fmSpQq60-Ls)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-14 00:00:00+00:00

Taken from JRE #1457 w/Tim Dillon: https://youtu.be/ig9yh8iVZWI

## Tim Dillon: Donald Trump Is a Creation of Hollywood
 - [https://www.youtube.com/watch?v=bouIQQZwuu4](https://www.youtube.com/watch?v=bouIQQZwuu4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-14 00:00:00+00:00

Taken from JRE #1457 w/Tim Dillon: https://youtu.be/ig9yh8iVZWI

## Trump's Coronavirus Response w/Tim Dillon | Joe Rogan
 - [https://www.youtube.com/watch?v=A3RhXTxwDvA](https://www.youtube.com/watch?v=A3RhXTxwDvA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2020-04-14 00:00:00+00:00

Taken from Joe Rogan Experience #1457 w/Tim Dillon:
https://youtu.be/ig9yh8iVZWI

