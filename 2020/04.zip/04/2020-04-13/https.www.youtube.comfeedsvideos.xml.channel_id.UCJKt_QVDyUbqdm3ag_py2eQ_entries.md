# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga Paula does XM: 8bm - Valkyr 2049 (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=zfNxpXtOl9A](https://www.youtube.com/watch?v=zfNxpXtOl9A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-04-14 00:00:00+00:00

"Valkyr 2049" (2020) by 8bm (e!ghtbm), 4th at Revision 2020 tracked music competition. Art "Bad Trip" (1994) by Pal/Offence, 9th at The Gathering 1994. This upload is intended for headphones only.

DeliTracker 2.34 with 14Bit-NotePlayer 4.30. Normal mixing with actual mixing frequency of 48587 Hz. No panning, no 3D and DSP off. Auto boost and anti-click enabled. 100% flawless playback not guaranteed. The track reports 4 channels. Screenmode was Euro72 Productivity.

Made using real A1200 audio. A recapped Rev 1D.4 (AWK 364720-04) mobo with resistors R321 and R331 = 680 ohms. More info about these two resistors here (RetroGameModz):
https://www.youtube.com/watch?v=7sZ7vLcURK4&t=0s

Visit my channel for more Amiga music.

## Amiga music: Hoffman - Way Too Rude (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=2K0zQW9Mrx8](https://www.youtube.com/watch?v=2K0zQW9Mrx8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-04-14 00:00:00+00:00

"Way Too Rude" (2020) by Hoffman (Ian Ford). Art "Julekake" by Devilstar, 13th at The Gathering 1994. This upload is intended for headphones only.

Made using real A1200 audio. A recapped Rev 1D.4 (AWK 364720-04) mobo with resistors R321 and R331 = 680 ohms. More info about these two resistors here (RetroGameModz):
https://www.youtube.com/watch?v=7sZ7vLcURK4&t=0s

Visit my channel for more Amiga music.

## Amiga music: Virgill - Reshoot Proxima 3 (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=u-CuzV975Is](https://www.youtube.com/watch?v=u-CuzV975Is)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-04-14 00:00:00+00:00

"Reshoot Proxima 3" by Virgill/Maniacs of Noise (Jochen Feldkötter), 1st at Revision 2020 tracked music competition. Art "Silent Dance" by Koyot1222, 4th at Decrunch 2016. This upload is intended for headphones only.

Made using real A1200 audio. A recapped Rev 1D.4 (AWK 364720-04) mobo with resistors R321 and R331 = 680 ohms. More info about these two resistors here (RetroGameModz):
https://www.youtube.com/watch?v=7sZ7vLcURK4&t=0s

Visit my channel for more Amiga music.

## Amiga music: Zombie Cats & Comatron - Amigaism (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=9t_7upUEDCk](https://www.youtube.com/watch?v=9t_7upUEDCk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-04-14 00:00:00+00:00

"Amigaism" by Zombie Cats & Comatron, 7th at Revision 2020 tracked music competition. Art "Alien" (1992) by R.W.O. This upload is intended for headphones only.

Made using real A1200 audio. A recapped Rev 1D.4 (AWK 364720-04) mobo with resistors R321 and R331 = 680 ohms. More info about these two resistors here (RetroGameModz):
https://www.youtube.com/watch?v=7sZ7vLcURK4&t=0s

Visit my channel for more Amiga music.

## Amiga music: AceMan - Homunculi (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=GIYeWnCtMw4](https://www.youtube.com/watch?v=GIYeWnCtMw4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2020-04-13 00:00:00+00:00

"Homunculi" (2020) by AceMan (Jakub Szelag), 3rd at Revision 2020 tracked music competition. Art (Ouroboros mark from FMA) by someone somewhere, the dl site didn't have further info (vippng.com). This upload is intended for headphones only.

Made using real A1200 audio. A recapped Rev 1D.4 (AWK 364720-04) mobo with resistors R321 and R331 = 680 ohms. More info about these two resistors here (RetroGameModz):
https://www.youtube.com/watch?v=7sZ7vLcURK4&t=0s

Visit my channel for more Amiga music.

