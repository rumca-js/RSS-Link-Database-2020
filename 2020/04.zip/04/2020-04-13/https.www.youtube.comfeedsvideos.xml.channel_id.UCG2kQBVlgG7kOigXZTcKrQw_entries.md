# Source:Kołem się toczy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw, language:pl-PL

## WSZYSTKO O PINGWINACH 🐧 Dlaczego od stania w śniegu nie marzną im stopy? Ushuaia i Ziemia ognista
 - [https://www.youtube.com/watch?v=9wJqmHcsglA](https://www.youtube.com/watch?v=9wJqmHcsglA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw
 - date published: 2020-04-13 00:00:00+00:00

Mój kurs filmowania i montażu online 👉 https://www.kursfilmowaniaimontazu.pl/
 Zapraszam szczególnie mocno, jeśli ktoś chce nauczyć się robić filmy, uporządkować wiedzę lub nauczyć się filmować i montować jak ja. Przekażę w nim całą swoją wiedzę :)

►►Zachęcam do subskrypcji: http://bit.ly/2cmWbSO 

W dzisiejszym odcinku wybierzemy się do Ziemi Ognistej, gdzie odwiedzimy piękną i ogromną kolonię pingwinów. A właściwie to dwie kolonie pingwinów! W pierwszej żyją Pingwiny Maggelanallana, w drugiej dużo większe pingwiny Królewskie.

Poopowiadamy sobie o zwyczajach pingwinów, zachowaniach i tym dlaczego pingwinom nie zamarzają nogi od ciągłego stania w śniegu.

Dodatkowo dowiecie się dlaczego Ziemia Ognista, oddzielona od reszty Ameryki Południowej Cieśniną Magellana wcale nie powinna nazywać się ziemią Ognistą. 

Zapraszam też do innych filmów z Ameryki, a także wpisu na blogu o Pingwinach:

https://kolemsietoczy.pl/pingwiny-gdzie-zobaczyc-patagonia-chile-argentyna-ciekawostki/

Muzyka: Artlist oraz soundclud: https://soundcloud.com/nevaxh

Zapraszam też na:
Facebook: http://bit.ly/2flU84f
Instagram: http://bit.ly/2eTrIMc
Blog: http://kolemsietoczy.pl/

Rozdziały:
0:00 Wstęp
0:56 Cabo Virgenes
2:04 Kolonia Pingwinów Magellańskich
4:21 Kolonia Pingwinów Królewskich
11:17 Ushuaia
14:44 Ziemia Ognista

