# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## 4 Mysterious Deaths and Disappearances | Answers With Joe
 - [https://www.youtube.com/watch?v=T-wQmE3jY4c](https://www.youtube.com/watch?v=T-wQmE3jY4c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2020-04-13 00:00:00+00:00

Get 20% off a subscription for life when you sign up at http://www.brilliant.org/answerswithjoe
As humans, we abhor unanswered questions. So when people go missing or die mysteriously, we turn to some pretty out-there answers. Here are 4 famous ones and what we think really happened.

Watch this video ad-free on Nebula: https://nebula.tv/videos/joe-scott-4-mysterious-deaths-disappearances


Want to support the channel? Thank you! Here are some ways to help:
Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
Merchandise: http://www.answerswithjoe.com/store

Join me on the Our Ludicrous Future Podcast:
https://www.youtube.com/channel/UCvUf_yOU_swE6PtOuv2yBqg

Interested in getting a Tesla? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
Snapchat: https://www.snapchat.com/add/answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

Michael Rockefeller:
https://www.dailymail.co.uk/news/article-2946787/Is-proof-lost-Rockefeller-heir-joined-tribe-naked-cannibals-Picture-shows-white-man-Papuan-man-eaters-eight-years-mysterious-disappearance.html

https://www.smithsonianmag.com/history/What-Really-Happened-to-Michael-Rockefeller-180949813/

The Highway of Tears:
https://www.thecanadianencyclopedia.ca/en/article/highway-of-tears

https://www.gq.com.au/lifestyle/travel/highway-of-tears-the-canadian-road-where-dozens-of-women-vanish/news-story/80309915849abd2938fb9fd993be803e

Dyatlov Pass:
https://dyatlovpass.com/page.php?language_id=1&id=12786&flp=1#beginning

Mary Celeste:
https://slate.com/human-interest/2011/12/the-mary-celeste-the-unluckiest-ship-to-ever-sail-the-seven-seas.html

https://www.smithsonianmag.com/history/abandoned-ship-the-mary-celeste-174488104/

