# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## Why the Heck Are We Ticklish?
 - [https://www.youtube.com/watch?v=y7wKcDTS_rA](https://www.youtube.com/watch?v=y7wKcDTS_rA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2020-04-14 00:00:00+00:00

PBS Member Stations rely on viewers like you. To support your local station, go to: http://to.pbs.org/DonateOKAY
↓ More info and sources below ↓

We’re on PATREON now! Join the community ►► https://www.patreon.com/itsokaytobesmart
SUBSCRIBE so you don’t miss a video! ►► http://bit.ly/iotbs_sub 

I’ve explained a lot of weird bodily functions on this show but there’s one that we haven’t covered that’s always confused me: Tickling. What are you for, tickling? What’s the point of you? Why do you exist? Why do you make us laugh even though we hate you? Let’s dig into our evolutionary past to try and find an answer.

References:

Laughing, tickling, and speech http://untiredwithloving.org/dhahak.pdf
Pathogenic laughter https://n.neurology.org/content/64/12/2154.short
Tickling review http://charris.ucsd.edu/articles/Harris_EHB2012.pdf
Darwin-Hecker http://charris.ucsd.edu/articles/Harris&Christenfeld_CE1997.pdf
Early thoughts https://www.jstor.org/stable/1411471?seq=1#page_scan_tab_contents 
Neural correlates of laughter https://academic.oup.com/cercor/article/23/6/1280/426218 
Neural correlates of laughter https://academic.oup.com/brain/article/126/10/2121/314497  Experience of pleasure https://www.ncbi.nlm.nih.gov/pubmed/6877978
Tickling and laughter https://www.sciencedirect.com/science/article/pii/030105119090023P
Ticklish rats https://science.sciencemag.org/content/354/6313/757
Social laughter and pain https://royalsocietypublishing.org/doi/full/10.1098/rspb.2011.1373 


Special thanks to our Brain Trust Patrons:
AlecZero
Oliver and Arden Bradshaw
Brent M.
Diego Lombeida
Dustin
Ernesto Silva
George Gladding
Marcus Tuepker
Ron Kakar
vincbis

-----------
Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/

