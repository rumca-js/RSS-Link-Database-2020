# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## What Every Fitness Influencer Is Like
 - [https://www.youtube.com/watch?v=-RQ7Je3rfEY](https://www.youtube.com/watch?v=-RQ7Je3rfEY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2020-04-14 00:00:00+00:00

Get 10% off supplements here - https://www.onnit.com/jp

Sign up for my Livestream Comedy Show Friday Night, Still Alive! - https://www.awakenwithjp.com/live

As a fitness influencer, I like to use my narcissism to inspire you to be as jealous of my body as possible. While I'm busy not giving you any useful information, I am giving you plenty of photos of my body in beautiful locations that we both pretend is valuable content.

*For Comedy Show schedule and tickets: https://awakenwithjp.com/events/
-My NEW Awakened Shirts are available! Claim yours here: https://awakenwithjp.com/shop

Click Here to join my PATREON - https://awakenwithjp.com/patron
---- Want to be the first to see my new videos with 24 hour early access? Just click this to receive the alerts! - https://m.me/awakenwithjp?ref=w6836464

Listen and Subscribe to my NEW Podcast here: 
https://podcasts.apple.com/ca/podcast/awaken-with-jp-sears-show/id1436938686
It's also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

-Order my new book at: http://HowToBeUltraSpiritual.com/

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

